package org.example.recombointegration.document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.index.Indexed;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * MongoDB document for storing complete form templates.
 * This allows dynamic form rendering in the UI without code changes.
 *
 * @author Generated
 * @version 1.0
 */
@Document(collection = "form_templates")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FormTemplate {

    @Id
    private String id;

    /**
     * Unique identifier for the form (e.g., "idea-submission-form")
     */
    @Indexed(unique = true)
    private String formId;

    /**
     * Display name for the form
     */
    private String formTitle;

    /**
     * Description of the form
     */
    private String formDescription;

    /**
     * Version of the form configuration
     */
    private String version;

    /**
     * List of form sections
     */
    private List<FormSection> sections;

    /**
     * Global form settings
     */
    private FormSettings formSettings;

    /**
     * Whether this form template is active
     */
    @Builder.Default
    private Boolean active = true;

    /**
     * Created timestamp
     */
    private LocalDateTime createdAt;

    /**
     * Last updated timestamp
     */
    private LocalDateTime updatedAt;

    /**
     * Form section inner class
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FormSection {
        private String sectionId;
        private String sectionTitle;
        private String sectionDescription;
        private Integer displayOrder;
        private List<FormField> fields;
        private Boolean collapsible;
        private Boolean defaultExpanded;
    }

    /**
     * Form field inner class
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FormField {
        private String fieldId;
        private String fieldKey;
        private String label;
        private String fieldType;
        private String placeholder;
        private String helpText;
        private Boolean required;
        private Integer displayOrder;
        private Integer maxLength;
        private Integer minLength;
        private List<FieldOption> options;
        private Map<String, Object> validation;
        private Map<String, Object> attributes;
        private String defaultValue;
        private Boolean multiSelect;
        private Boolean allowOther;
        private String otherFieldKey;
        private List<String> dependsOn;
        private Map<String, Object> conditionalLogic;
        private String fileUploadType;
        private Integer maxFileSize;
        private List<String> acceptedFileTypes;
    }

    /**
     * Field option inner class
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FieldOption {
        private String value;
        private String label;
        private String description;
        private Boolean disabled;
        private String icon;
        private Map<String, Object> metadata;
    }

    /**
     * Form settings inner class
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FormSettings {
        private Boolean allowDraft;
        private Boolean showProgressBar;
        private Boolean enableAutoSave;
        private Integer autoSaveInterval;
        private String submitButtonText;
        private String draftButtonText;
        private String successMessage;
        private String errorMessage;
        private Boolean enableEmailCapture;
        private String emailFieldLabel;
        private Boolean emailRequired;
        private Map<String, Object> customSettings;
    }
}

