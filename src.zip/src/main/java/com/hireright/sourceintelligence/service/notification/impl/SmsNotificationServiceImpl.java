package com.hireright.sourceintelligence.service.notification.impl;

import com.hireright.sourceintelligence.api.dto.notification.SmsNotificationDTO;
import com.hireright.sourceintelligence.service.notification.SmsNotificationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Implementation of SMS notification service
 * Following Single Responsibility Principle - handles only SMS sending
 * 
 * This is a base implementation that can be extended for specific providers:
 * - TwilioSmsNotificationServiceImpl
 * - AwsSnsNotificationServiceImpl
 * - VonageSmsNotificationServiceImpl
 * 
 * Current implementation provides a framework/stub for actual provider integration
 */
@Slf4j
@Service
public class SmsNotificationServiceImpl implements SmsNotificationService {
    
    @Value("${notification.sms.enabled:false}")
    private boolean smsEnabled;
    
    @Value("${notification.sms.from:}")
    private String defaultFromNumber;
    
    @Value("${notification.sms.provider:DEFAULT}")
    private String defaultProvider;
    
    // Statistics tracking
    private final AtomicInteger sentCount = new AtomicInteger(0);
    private final AtomicInteger deliveredCount = new AtomicInteger(0);
    private final AtomicInteger failedCount = new AtomicInteger(0);
    
    // Simple in-memory delivery tracking (replace with database in production)
    private final ConcurrentHashMap<String, SmsDeliveryStatus> deliveryStatusMap = new ConcurrentHashMap<>();
    
    @Override
    public String sendSms(SmsNotificationDTO smsNotification) {
        log.info("Sending SMS notification to {} recipient(s)", 
                smsNotification.getPhoneNumbers().size());
        
        if (!smsEnabled) {
            log.warn("SMS notifications are disabled. Set notification.sms.enabled=true to enable.");
            return null;
        }
        
        if (!validateSmsNotification(smsNotification)) {
            throw new IllegalArgumentException("Invalid SMS notification request");
        }
        
        try {
            String notificationId = UUID.randomUUID().toString();
            
            // Set default provider if not specified
            if (smsNotification.getProvider() == null) {
                smsNotification.setProvider(SmsNotificationDTO.SmsProvider.valueOf(defaultProvider));
            }
            
            // Set default from number if not specified
            if (smsNotification.getFrom() == null || smsNotification.getFrom().isEmpty()) {
                smsNotification.setFrom(defaultFromNumber);
            }
            
            // Route to appropriate provider
            sendViaSmsProvider(smsNotification, notificationId);
            
            // Track delivery status
            deliveryStatusMap.put(notificationId, SmsDeliveryStatus.SENT);
            sentCount.incrementAndGet();
            
            log.info("SMS notification sent successfully. Notification ID: {}", notificationId);
            return notificationId;
            
        } catch (Exception e) {
            failedCount.incrementAndGet();
            log.error("Failed to send SMS notification: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to send SMS notification", e);
        }
    }
    
    @Async("notificationExecutor")
    @Override
    public CompletableFuture<String> sendSmsAsync(SmsNotificationDTO smsNotification) {
        log.debug("Sending SMS notification asynchronously");
        
        return CompletableFuture.supplyAsync(() -> {
            try {
                return sendSms(smsNotification);
            } catch (Exception e) {
                log.error("Async SMS sending failed: {}", e.getMessage(), e);
                throw new RuntimeException("Async SMS sending failed", e);
            }
        });
    }
    
    @Override
    public boolean validateSmsNotification(SmsNotificationDTO smsNotification) {
        if (smsNotification == null) {
            log.warn("SMS notification is null");
            return false;
        }
        
        if (smsNotification.getPhoneNumbers() == null || smsNotification.getPhoneNumbers().isEmpty()) {
            log.warn("SMS notification has no recipients");
            return false;
        }
        
        if (smsNotification.getMessage() == null || smsNotification.getMessage().isEmpty()) {
            log.warn("SMS notification has no message");
            return false;
        }
        
        // Validate message length (standard SMS is 160 characters, concatenated up to 1600)
        if (smsNotification.getMessage().length() > 1600) {
            log.warn("SMS message exceeds maximum length of 1600 characters");
            return false;
        }
        
        // Validate phone number format (E.164 format)
        for (String phoneNumber : smsNotification.getPhoneNumbers()) {
            if (!phoneNumber.matches("^\\+?[1-9]\\d{1,14}$")) {
                log.warn("Invalid phone number format: {}", phoneNumber);
                return false;
            }
        }
        
        return true;
    }
    
    @Override
    public SmsDeliveryStatus getDeliveryStatus(String notificationId) {
        return deliveryStatusMap.getOrDefault(notificationId, SmsDeliveryStatus.UNKNOWN);
    }
    
    @Override
    public SmsStatistics getStatistics() {
        int total = sentCount.get();
        int delivered = deliveredCount.get();
        double rate = total > 0 ? (double) delivered / total * 100 : 0.0;
        
        return new SmsStatistics(
                total,
                delivered,
                failedCount.get(),
                rate
        );
    }
    
    /**
     * Route SMS to appropriate provider
     * This method should be overridden or extended for specific provider implementations
     * 
     * @param smsNotification SMS details
     * @param notificationId Generated notification ID
     */
    protected void sendViaSmsProvider(SmsNotificationDTO smsNotification, String notificationId) {
        SmsNotificationDTO.SmsProvider provider = smsNotification.getProvider();
        
        log.info("Routing SMS to provider: {}", provider);
        
        switch (provider) {
            case TWILIO -> sendViaTwilio(smsNotification, notificationId);
            case AWS_SNS -> sendViaAwsSns(smsNotification, notificationId);
            case VONAGE -> sendViaVonage(smsNotification, notificationId);
            case MESSAGEBIRD -> sendViaMessageBird(smsNotification, notificationId);
            case SINCH -> sendViaSinch(smsNotification, notificationId);
            default -> sendViaDefaultProvider(smsNotification, notificationId);
        }
    }
    
    /**
     * Twilio SMS implementation
     * Override this method to integrate with Twilio SDK
     */
    protected void sendViaTwilio(SmsNotificationDTO smsNotification, String notificationId) {
        log.info("Twilio SMS provider - To be implemented");
        // TODO: Integrate Twilio SDK
        // Example:
        // Message message = Message.creator(
        //     new PhoneNumber(phoneNumber),
        //     new PhoneNumber(smsNotification.getFrom()),
        //     smsNotification.getMessage()
        // ).create();
    }
    
    /**
     * AWS SNS SMS implementation
     * Override this method to integrate with AWS SNS
     */
    protected void sendViaAwsSns(SmsNotificationDTO smsNotification, String notificationId) {
        log.info("AWS SNS SMS provider - To be implemented");
        // TODO: Integrate AWS SNS SDK
        // Example:
        // PublishRequest publishRequest = PublishRequest.builder()
        //     .message(smsNotification.getMessage())
        //     .phoneNumber(phoneNumber)
        //     .build();
        // snsClient.publish(publishRequest);
    }
    
    /**
     * Vonage SMS implementation
     */
    protected void sendViaVonage(SmsNotificationDTO smsNotification, String notificationId) {
        log.info("Vonage SMS provider - To be implemented");
        // TODO: Integrate Vonage SDK
    }
    
    /**
     * MessageBird SMS implementation
     */
    protected void sendViaMessageBird(SmsNotificationDTO smsNotification, String notificationId) {
        log.info("MessageBird SMS provider - To be implemented");
        // TODO: Integrate MessageBird SDK
    }
    
    /**
     * Sinch SMS implementation
     */
    protected void sendViaSinch(SmsNotificationDTO smsNotification, String notificationId) {
        log.info("Sinch SMS provider - To be implemented");
        // TODO: Integrate Sinch SDK
    }
    
    /**
     * Default SMS provider implementation
     * Logs the SMS for testing/development
     */
    protected void sendViaDefaultProvider(SmsNotificationDTO smsNotification, String notificationId) {
        log.info("=== SMS Notification (DEFAULT PROVIDER) ===");
        log.info("Notification ID: {}", notificationId);
        log.info("From: {}", smsNotification.getFrom());
        log.info("To: {}", smsNotification.getPhoneNumbers());
        log.info("Message: {}", smsNotification.getMessage());
        log.info("Priority: {}", smsNotification.getPriority());
        log.info("Track Delivery: {}", smsNotification.getTrackDelivery());
        log.info("==========================================");
    }
}

