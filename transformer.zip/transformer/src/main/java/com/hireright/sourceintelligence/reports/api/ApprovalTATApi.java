package com.hireright.sourceintelligence.reports.api;

import com.hireright.sourceintelligence.api.ApiConstants;
import com.hireright.sourceintelligence.reports.dto.ReportResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;

import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.API_PATH_REPORTS;

@RequestMapping(value = API_PATH_REPORTS)
@Tag(name = "Reports", description = "Endpoints for managing Reports")
public interface ApprovalTATApi {

    @PostMapping(value = ApiConstants.ApiPath.APPROVAL_TAT, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    ResponseEntity<ReportResponseDTO> getApprovalAverageTAT(@RequestBody ReportsRequestDTO reportsRequestDTO);

}
