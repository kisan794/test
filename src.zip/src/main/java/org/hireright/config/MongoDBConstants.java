package org.hireright.config;

public final class MongoDBConstants {

    private MongoDBConstants() {
        throw new AssertionError("Cannot instantiate constants class");
    }

    public static final String DEV_MONGODB_URI = "mongodb://localhost:27017";
    public static final String DEV_DATABASE = "dev_db";
    public static final String DEV_SOURCE_COLLECTION = "education_source_temp";
    public static final String DEV_FINAL_COLLECTION = "education_source_final_collection";

    public static final String TEST_MONGODB_URI = "mongodb://localhost:27017";
    public static final String TEST_DATABASE = "test_db";
    public static final String TEST_SOURCE_COLLECTION = "education_source";

    public static final int BATCH_SIZE = 1000;
    public static final int LOG_FREQUENCY = 5000;
    public static final int MAX_RETRIES = 3;
    public static final long RETRY_DELAY_MS = 1000;

    public static final int CONNECTION_POOL_MIN_SIZE = 10;
    public static final int CONNECTION_POOL_MAX_SIZE = 100;
    public static final int CONNECTION_TIMEOUT_MS = 30000;
    public static final int SOCKET_TIMEOUT_MS = 60000;
    public static final int SERVER_SELECTION_TIMEOUT_MS = 30000;
}

