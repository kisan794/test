package hireright.applications.fulfillment_task_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-25  ATS-1045 initial version
 */

public class CPropertyResources extends CResources<CProperty> {
    private CPropertyResources() {
        super();
    }

    protected CPropertyResources(Builder builder) {
        super(builder);
    }

    @Override
    public String toString() {
        return "CPropertyResources{} " + super.toString();
    }

    public static class Builder extends CResources.Builder<CProperty> {
        public Builder() {
            super();
        }

        public Builder(CResources<CProperty> copy) {
            super(copy);
        }

        public Builder(CPropertyResources copy) {
            super(copy);
        }

        @Override
        public CPropertyResources build() {
            super.build();
            kind(EKind.PROPERTY_LIST);

            return new CPropertyResources(this);
        }
    }
}
