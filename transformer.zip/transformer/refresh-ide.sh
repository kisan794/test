#!/bin/bash

# Script to refresh IDE dependencies

echo "Refreshing Gradle dependencies..."
./gradlew clean build --refresh-dependencies -x test

echo ""
echo "Generating IDE metadata..."
./gradlew cleanIdea idea

echo ""
echo "Done! Please restart your IDE (IntelliJ IDEA or Eclipse) to pick up the changes."
echo ""
echo "If using IntelliJ IDEA:"
echo "1. File -> Invalidate Caches / Restart"
echo "2. Or: File -> Reload All from Disk"
echo ""
echo "If using VS Code:"
echo "1. Reload Window (Cmd+Shift+P -> 'Reload Window')"
echo "2. Or restart VS Code"

