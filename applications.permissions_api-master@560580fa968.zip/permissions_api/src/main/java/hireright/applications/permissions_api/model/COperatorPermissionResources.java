package hireright.applications.permissions_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-17  HRG-330191 initial version
 */

public class COperatorPermissionResources extends CResources<COperatorPermission>
{
	private COperatorPermissionResources()
	{
		super();
	}

	protected COperatorPermissionResources(Builder builder)
	{
		super(builder);
	}

	@Override
	public String toString()
	{
		return "COperatorPermissionResources{} " + super.toString();
	}

	public static class Builder extends CResources.Builder<COperatorPermission>
	{
		public Builder()
		{
			super();
		}

		public Builder(CResources<COperatorPermission> copy)
		{
			super(copy);
		}

		public Builder(COperatorPermissionResources copy)
		{
			super(copy);
		}

		@Override
		public COperatorPermissionResources build()
		{
			super.build();
			kind(EKind.operatorPermissions);

			return new COperatorPermissionResources(this);
		}
	}
}
