package com.hireright.sourceintelligence.service.notification.validator;

import com.hireright.sourceintelligence.api.dto.notification.AttachmentDTO;
import com.hireright.sourceintelligence.exception.EmailValidationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Base64;
import java.util.List;

/**
 * Validator for email attachments.
 * Follows Single Responsibility Principle - only validates attachment data.
 */
@Slf4j
@Component
public class AttachmentValidator {
    
    @Value("${notification.email.attachment.maxSize:26214400}")
    private long maxAttachmentSize; // 25MB in bytes
    
    @Value("${notification.email.attachment.maxCount:10}")
    private int maxAttachmentCount;
    
    /**
     * Validates all attachments
     *
     * @param attachments list of attachments to validate
     * @throws EmailValidationException if validation fails
     */
    public void validate(List<AttachmentDTO> attachments) {
        if (attachments == null || attachments.isEmpty()) {
            return; // No attachments to validate
        }
        
        log.debug("Validating {} attachments", attachments.size());
        
        validateAttachmentCount(attachments);
        
        for (int i = 0; i < attachments.size(); i++) {
            validateAttachment(attachments.get(i), i);
        }
        
        log.debug("Attachment validation successful");
    }
    
    /**
     * Validates attachment count
     */
    private void validateAttachmentCount(List<AttachmentDTO> attachments) {
        if (attachments.size() > maxAttachmentCount) {
            throw new EmailValidationException(
                    String.format("Attachment count (%d) exceeds maximum allowed (%d)", 
                            attachments.size(), maxAttachmentCount),
                    "attachments"
            );
        }
    }
    
    /**
     * Validates a single attachment
     */
    private void validateAttachment(AttachmentDTO attachment, int index) {
        String fieldPrefix = String.format("attachments[%d]", index);
        
        // Validate filename
        if (attachment.getFilename() == null || attachment.getFilename().trim().isEmpty()) {
            throw new EmailValidationException(
                    "Attachment filename cannot be empty",
                    fieldPrefix + ".filename"
            );
        }
        
        // Validate content
        if (attachment.getContent() == null || attachment.getContent().trim().isEmpty()) {
            throw new EmailValidationException(
                    "Attachment content cannot be empty",
                    fieldPrefix + ".content"
            );
        }
        
        // Validate content type
        if (attachment.getContentType() == null || attachment.getContentType().trim().isEmpty()) {
            throw new EmailValidationException(
                    "Attachment content type cannot be empty",
                    fieldPrefix + ".contentType"
            );
        }
        
        // Validate Base64 encoding
        validateBase64Encoding(attachment, fieldPrefix);
        
        // Validate size
        validateAttachmentSize(attachment, fieldPrefix);
    }
    
    /**
     * Validates Base64 encoding of attachment content
     */
    private void validateBase64Encoding(AttachmentDTO attachment, String fieldPrefix) {
        try {
            byte[] decodedBytes = Base64.getDecoder().decode(attachment.getContent());
            attachment.setSizeBytes((long) decodedBytes.length);
        } catch (IllegalArgumentException e) {
            throw new EmailValidationException(
                    String.format("Invalid Base64 encoding for attachment '%s'", 
                            attachment.getFilename()),
                    fieldPrefix + ".content"
            );
        }
    }
    
    /**
     * Validates attachment size
     */
    private void validateAttachmentSize(AttachmentDTO attachment, String fieldPrefix) {
        long sizeBytes = attachment.getSizeBytes() != null ? attachment.getSizeBytes() : 0;
        
        if (sizeBytes > maxAttachmentSize) {
            double sizeMB = sizeBytes / (1024.0 * 1024.0);
            double maxSizeMB = maxAttachmentSize / (1024.0 * 1024.0);
            
            throw new EmailValidationException(
                    String.format("Attachment '%s' size (%.2f MB) exceeds maximum allowed (%.2f MB)", 
                            attachment.getFilename(), sizeMB, maxSizeMB),
                    fieldPrefix + ".content"
            );
        }
    }
    
    /**
     * Calculates total size of all attachments
     */
    public long calculateTotalSize(List<AttachmentDTO> attachments) {
        if (attachments == null || attachments.isEmpty()) {
            return 0;
        }
        
        return attachments.stream()
                .mapToLong(a -> a.getSizeBytes() != null ? a.getSizeBytes() : 0)
                .sum();
    }
}

