package org.example.recombointegration.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.recombointegration.document.FormFieldConfig;
import org.example.recombointegration.dto.FormFieldConfigRequest;
import org.example.recombointegration.dto.FormFieldConfigResponse;
import org.example.recombointegration.repository.FormFieldConfigRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service for managing form field configurations.
 * Handles business logic for creating, updating, and retrieving form configurations.
 *
 * @author Generated
 * @version 1.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class FormFieldConfigService {

    private final FormFieldConfigRepository formFieldConfigRepository;

    /**
     * Create a new form field configuration.
     */
    public FormFieldConfigResponse createConfig(FormFieldConfigRequest request) {
        log.info("Creating new form field configuration: {}", request.getFieldKey());

        if (formFieldConfigRepository.existsByFieldKey(request.getFieldKey())) {
            throw new RuntimeException("Field configuration already exists with key: " + request.getFieldKey());
        }

        FormFieldConfig config = mapToDocument(request);
        config.setCreatedAt(LocalDateTime.now());
        config.setUpdatedAt(LocalDateTime.now());

        FormFieldConfig savedConfig = formFieldConfigRepository.save(config);
        log.info("Form field configuration created successfully with ID: {}", savedConfig.getId());

        return mapToResponse(savedConfig);
    }

    /**
     * Update an existing form field configuration.
     */
    public FormFieldConfigResponse updateConfig(String fieldKey, FormFieldConfigRequest request) {
        log.info("Updating form field configuration: {}", fieldKey);

        FormFieldConfig config = formFieldConfigRepository.findByFieldKey(fieldKey)
                .orElseThrow(() -> new RuntimeException("Field configuration not found with key: " + fieldKey));

        updateConfigFromRequest(config, request);
        config.setUpdatedAt(LocalDateTime.now());

        FormFieldConfig updatedConfig = formFieldConfigRepository.save(config);
        log.info("Form field configuration updated successfully");

        return mapToResponse(updatedConfig);
    }

    /**
     * Get configuration by field key.
     */
    public FormFieldConfigResponse getConfigByFieldKey(String fieldKey) {
        log.info("Fetching form field configuration: {}", fieldKey);
        FormFieldConfig config = formFieldConfigRepository.findByFieldKey(fieldKey)
                .orElseThrow(() -> new RuntimeException("Field configuration not found with key: " + fieldKey));
        return mapToResponse(config);
    }

    /**
     * Get all configurations.
     */
    public List<FormFieldConfigResponse> getAllConfigs() {
        log.info("Fetching all form field configurations");
        return formFieldConfigRepository.findAllByOrderByDisplayOrderAsc().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    /**
     * Get all active configurations.
     */
    public List<FormFieldConfigResponse> getActiveConfigs() {
        log.info("Fetching all active form field configurations");
        return formFieldConfigRepository.findByActiveTrueOrderByDisplayOrderAsc().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    /**
     * Get configurations by section.
     */
    public List<FormFieldConfigResponse> getConfigsBySection(String section) {
        log.info("Fetching form field configurations for section: {}", section);
        return formFieldConfigRepository.findBySection(section).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    /**
     * Get active configurations by section.
     */
    public List<FormFieldConfigResponse> getActiveConfigsBySection(String section) {
        log.info("Fetching active form field configurations for section: {}", section);
        return formFieldConfigRepository.findBySectionAndActiveTrue(section).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    /**
     * Delete a configuration.
     */
    public void deleteConfig(String fieldKey) {
        log.info("Deleting form field configuration: {}", fieldKey);
        FormFieldConfig config = formFieldConfigRepository.findByFieldKey(fieldKey)
                .orElseThrow(() -> new RuntimeException("Field configuration not found with key: " + fieldKey));
        formFieldConfigRepository.delete(config);
        log.info("Form field configuration deleted successfully");
    }

    /**
     * Initialize default configurations.
     */
    public void initializeDefaultConfigs() {
        log.info("Initializing default form field configurations");

        if (formFieldConfigRepository.count() > 0) {
            log.info("Configurations already exist, skipping initialization");
            return;
        }

        createDefaultConfigs();
        log.info("Default configurations initialized successfully");
    }

    // Helper methods
    private FormFieldConfig mapToDocument(FormFieldConfigRequest request) {
        List<FormFieldConfig.FieldOption> options = request.getOptions() != null
                ? request.getOptions().stream()
                .map(opt -> FormFieldConfig.FieldOption.builder()
                        .value(opt.getValue())
                        .label(opt.getLabel())
                        .description(opt.getDescription())
                        .order(opt.getOrder())
                        .active(opt.getActive() != null ? opt.getActive() : true)
                        .build())
                .collect(Collectors.toList())
                : null;

        return FormFieldConfig.builder()
                .fieldKey(request.getFieldKey())
                .fieldLabel(request.getFieldLabel())
                .fieldDescription(request.getFieldDescription())
                .fieldType(request.getFieldType())
                .options(options)
                .required(request.getRequired() != null ? request.getRequired() : false)
                .displayOrder(request.getDisplayOrder())
                .active(request.getActive() != null ? request.getActive() : true)
                .section(request.getSection())
                .build();
    }

    private void updateConfigFromRequest(FormFieldConfig config, FormFieldConfigRequest request) {
        config.setFieldLabel(request.getFieldLabel());
        config.setFieldDescription(request.getFieldDescription());
        config.setFieldType(request.getFieldType());
        config.setRequired(request.getRequired() != null ? request.getRequired() : false);
        config.setDisplayOrder(request.getDisplayOrder());
        config.setActive(request.getActive() != null ? request.getActive() : true);
        config.setSection(request.getSection());

        if (request.getOptions() != null) {
            List<FormFieldConfig.FieldOption> options = request.getOptions().stream()
                    .map(opt -> FormFieldConfig.FieldOption.builder()
                            .value(opt.getValue())
                            .label(opt.getLabel())
                            .description(opt.getDescription())
                            .order(opt.getOrder())
                            .active(opt.getActive() != null ? opt.getActive() : true)
                            .build())
                    .collect(Collectors.toList());
            config.setOptions(options);
        }
    }

    private FormFieldConfigResponse mapToResponse(FormFieldConfig config) {
        List<FormFieldConfigResponse.FieldOptionResponse> options = config.getOptions() != null
                ? config.getOptions().stream()
                .map(opt -> FormFieldConfigResponse.FieldOptionResponse.builder()
                        .value(opt.getValue())
                        .label(opt.getLabel())
                        .description(opt.getDescription())
                        .order(opt.getOrder())
                        .active(opt.getActive())
                        .build())
                .collect(Collectors.toList())
                : null;

        return FormFieldConfigResponse.builder()
                .id(config.getId())
                .fieldKey(config.getFieldKey())
                .fieldLabel(config.getFieldLabel())
                .fieldDescription(config.getFieldDescription())
                .fieldType(config.getFieldType())
                .options(options)
                .required(config.getRequired())
                .displayOrder(config.getDisplayOrder())
                .active(config.getActive())
                .section(config.getSection())
                .createdAt(config.getCreatedAt())
                .updatedAt(config.getUpdatedAt())
                .build();
    }

    private void createDefaultConfigs() {
        LocalDateTime now = LocalDateTime.now();

        // 1. Impact Areas
        FormFieldConfig impactAreas = FormFieldConfig.builder()
                .fieldKey("impactAreas")
                .fieldLabel("Which area does this idea impact?")
                .fieldDescription("Select all that apply")
                .fieldType(FormFieldConfig.FieldType.MULTI_SELECT)
                .section("Area of Impact")
                .displayOrder(1)
                .required(false)
                .active(true)
                .createdAt(now)
                .updatedAt(now)
                .options(List.of(
                        FormFieldConfig.FieldOption.builder()
                                .value("PROCESS")
                                .label("Process")
                                .description("Streamlining workflows, automation, reducing errors")
                                .order(1)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("PEOPLE")
                                .label("People")
                                .description("Training, morale, collaboration, safety")
                                .order(2)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("QUALITY")
                                .label("Quality")
                                .description("Product/service quality, customer experience, compliance")
                                .order(3)
                                .active(true)
                                .build()
                ))
                .build();

        // 2. Improvement Types
        FormFieldConfig improvementTypes = FormFieldConfig.builder()
                .fieldKey("improvementTypes")
                .fieldLabel("Type of Improvement")
                .fieldDescription("Select one or more")
                .fieldType(FormFieldConfig.FieldType.MULTI_SELECT)
                .section("Type of Improvement")
                .displayOrder(2)
                .required(false)
                .active(true)
                .createdAt(now)
                .updatedAt(now)
                .options(List.of(
                        FormFieldConfig.FieldOption.builder()
                                .value("INCREMENTAL")
                                .label("Incremental")
                                .description("Small improvements to existing systems")
                                .order(1)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("INNOVATIVE")
                                .label("Innovative")
                                .description("Completely new ways of doing things")
                                .order(2)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("COST_SAVING")
                                .label("Cost Saving / Efficiency")
                                .description("Reduces resources or time")
                                .order(3)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("QUALITY_ENHANCEMENT")
                                .label("Quality Enhancement")
                                .description("Improves product/service quality or compliance")
                                .order(4)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("OTHER")
                                .label("Other")
                                .description("Please specify")
                                .order(5)
                                .active(true)
                                .build()
                ))
                .build();

        // 3. Impact Categories
        FormFieldConfig impactCategories = FormFieldConfig.builder()
                .fieldKey("impactCategories")
                .fieldLabel("Impact Areas")
                .fieldDescription("Select all that apply")
                .fieldType(FormFieldConfig.FieldType.MULTI_SELECT)
                .section("Expected Impact")
                .displayOrder(3)
                .required(false)
                .active(true)
                .createdAt(now)
                .updatedAt(now)
                .options(List.of(
                        FormFieldConfig.FieldOption.builder()
                                .value("TIME_EFFICIENCY")
                                .label("Time efficiency")
                                .description("")
                                .order(1)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("COST_SAVINGS")
                                .label("Cost savings")
                                .description("")
                                .order(2)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("EMPLOYEE_ENGAGEMENT")
                                .label("Employee engagement")
                                .description("")
                                .order(3)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("CUSTOMER_SATISFACTION")
                                .label("Customer satisfaction")
                                .description("")
                                .order(4)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("COMPLIANCE_RISK_REDUCTION")
                                .label("Compliance / Risk reduction")
                                .description("")
                                .order(5)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("OTHER")
                                .label("Other")
                                .description("Please specify")
                                .order(6)
                                .active(true)
                                .build()
                ))
                .build();

        // 4. Implementation Complexity
        FormFieldConfig implementationComplexity = FormFieldConfig.builder()
                .fieldKey("implementationComplexity")
                .fieldLabel("Implementation Complexity")
                .fieldDescription("Select the complexity level")
                .fieldType(FormFieldConfig.FieldType.DROPDOWN)
                .section("Implementation Details")
                .displayOrder(4)
                .required(false)
                .active(true)
                .createdAt(now)
                .updatedAt(now)
                .options(List.of(
                        FormFieldConfig.FieldOption.builder()
                                .value("LOW")
                                .label("Low")
                                .description("Quick win, minimal resources needed")
                                .order(1)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("MEDIUM")
                                .label("Medium")
                                .description("Requires planning, moderate resources")
                                .order(2)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("HIGH")
                                .label("High")
                                .description("Significant changes or investment needed")
                                .order(3)
                                .active(true)
                                .build()
                ))
                .build();

        // 5. Timeline Type
        FormFieldConfig timelineType = FormFieldConfig.builder()
                .fieldKey("timelineType")
                .fieldLabel("Short-term or Long-term Idea?")
                .fieldDescription("Select the timeline")
                .fieldType(FormFieldConfig.FieldType.DROPDOWN)
                .section("Implementation Details")
                .displayOrder(5)
                .required(false)
                .active(true)
                .createdAt(now)
                .updatedAt(now)
                .options(List.of(
                        FormFieldConfig.FieldOption.builder()
                                .value("SHORT_TERM")
                                .label("Short-term")
                                .description("Quick Win")
                                .order(1)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("LONG_TERM")
                                .label("Long-term")
                                .description("Strategic Impact")
                                .order(2)
                                .active(true)
                                .build()
                ))
                .build();

        // 6. Idea Status
        FormFieldConfig ideaStatus = FormFieldConfig.builder()
                .fieldKey("ideaStatus")
                .fieldLabel("Idea Status")
                .fieldDescription("Current status of the idea")
                .fieldType(FormFieldConfig.FieldType.DROPDOWN)
                .section("Status Tracking")
                .displayOrder(6)
                .required(false)
                .active(true)
                .createdAt(now)
                .updatedAt(now)
                .options(List.of(
                        FormFieldConfig.FieldOption.builder()
                                .value("SUBMITTED")
                                .label("Submitted")
                                .description("Idea has been submitted")
                                .order(1)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("UNDER_REVIEW")
                                .label("Under Review")
                                .description("Idea is being reviewed")
                                .order(2)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("APPROVED")
                                .label("Approved")
                                .description("Idea has been approved")
                                .order(3)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("IMPLEMENTED")
                                .label("Implemented")
                                .description("Idea is being implemented")
                                .order(4)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("COMPLETED")
                                .label("Completed")
                                .description("Idea implementation is complete")
                                .order(5)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("REJECTED")
                                .label("Rejected")
                                .description("Idea has been rejected")
                                .order(6)
                                .active(true)
                                .build(),
                        FormFieldConfig.FieldOption.builder()
                                .value("ON_HOLD")
                                .label("On Hold")
                                .description("Idea is on hold")
                                .order(7)
                                .active(true)
                                .build()
                ))
                .build();

        // Save all configurations
        formFieldConfigRepository.saveAll(List.of(
                impactAreas,
                improvementTypes,
                impactCategories,
                implementationComplexity,
                timelineType,
                ideaStatus
        ));
    }
}

