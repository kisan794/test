package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.InstitutionRecord;
import com.hireright.sourceintelligence.service.impl.ExcelParserService;
import com.hireright.sourceintelligence.service.impl.MigrationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequiredArgsConstructor
@Validated
@CrossOrigin
public class ParchmentMigrationApiController implements ParchmentMigrationApi {

    private final ExcelParserService excelParserService;
    private final MigrationService migrationService;

    @Override
    public ResponseEntity<Map<String, Object>> uploadExcelFile(MultipartFile file) {
        log.info("Received file upload request: {}", file.getOriginalFilename());

        try {
            if (file.isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(createErrorResponse("File is empty"));
            }

            String filename = file.getOriginalFilename();
            if (filename == null || (!filename.endsWith(".xlsx") && !filename.endsWith(".xls"))) {
                return ResponseEntity.badRequest()
                        .body(createErrorResponse("Invalid file format. Please upload an Excel file (.xlsx or .xls)"));
            }

            log.info("Parsing Excel file: {}", filename);
            List<InstitutionRecord> records = excelParserService.parseExcelFile(file);

            if (records.isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(createErrorResponse("No records found in the Excel file"));
            }

            log.info("Found {} records in Excel file", records.size());

            Map<String, Object> result = migrationService.processInstitutionRecords(records);

            result.put("status", "success");
            result.put("message", "File processed successfully");
            result.put("filename", filename);

            log.info("Processing completed successfully");
            return ResponseEntity.ok(result);

        } catch (Exception e) {
            log.error("Error processing file", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Error processing file: " + e.getMessage()));
        }
    }

    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "error");
        response.put("message", message);
        return response;
    }
}