package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.SearchOrganizationDTO;
import com.hireright.sourceintelligence.api.dto.rds.VendorsDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.entity.Vendors;
import org.mapstruct.Mapper;
import org.mapstruct.NullValueCheckStrategy;

import java.util.List;

import static org.mapstruct.ReportingPolicy.IGNORE;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        unmappedTargetPolicy = IGNORE)
public interface RDSMapper {

    VendorsDTO entityToVendorsDTO(Vendors entity);

    List<VendorsDTO> toVendorsDTOList(List<Vendors> entityList);

}
