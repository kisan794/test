package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.rds.LanguageDTO;
import com.hireright.sourceintelligence.domain.entity.Language;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.math.BigDecimal;
import java.util.List;

import static org.mapstruct.ReportingPolicy.IGNORE;

@Mapper(componentModel = "spring", unmappedTargetPolicy = IGNORE)
public interface LanguageMapper {

    @Mapping(target = "id", expression = "java(convertBigDecimalToString(entity.getLanguageId()))")
    @Mapping(target = "name", expression = "java(entity.getName())")
    @Mapping(target = "iso6391", expression = "java(entity.getIso6391())")
    @Mapping(target = "iso6392t", expression = "java(entity.getIso6392t())")
    @Mapping(target = "languageTag", expression = "java(entity.getLanguageTag())")
    LanguageDTO entityToDTO(Language entity);

    List<LanguageDTO> entityToDTOList(List<Language> entityList);

    default String convertBigDecimalToString(BigDecimal value) {
        if (value == null) {
            return null;
        }
        return value.stripTrailingZeros().toPlainString();
    }
}