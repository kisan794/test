package com.hireright.sourceintelligence.domain.repository;


import com.hireright.sourceintelligence.exception.Location;
import com.mongodb.bulk.BulkWriteResult;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.*;
import org.springframework.data.mongodb.core.query.*;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

@Slf4j
@Component
@RequiredArgsConstructor
public class CommonRepository {
	private final MongoTemplate mongoTemplate;

	@Value("${shard.location}")
	private String shardLocation;

	public <T> int bulkUpdates(List<T> list, Class<T> clzz, Function<T, String> idFun, String collectionName) {
		if (CollectionUtils.isEmpty(list)) {
			return 0;
		}

		BulkOperations bulkUpdates = mongoTemplate.bulkOps(BulkOperations.BulkMode.ORDERED, clzz,collectionName);
		list.forEach(e -> {
			Query query = new Query();
			query.addCriteria(Criteria.where("_id").in(new ObjectId(idFun.apply(e))));
			query.addCriteria(Criteria.where("location").is(Location.getLocationValueForSharding(shardLocation)));
			bulkUpdates.replaceOne(query, e);
			log.info("updated successfully"+"in collection:"+collectionName);
		});
		BulkWriteResult bulkWriteResult = bulkUpdates.execute();
		return bulkWriteResult.getModifiedCount();
	}

}
