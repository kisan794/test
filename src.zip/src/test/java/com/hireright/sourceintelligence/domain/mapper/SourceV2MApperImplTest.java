package com.hireright.sourceintelligence.domain.mapper;public class SourceV2MApperImplTest {
}
