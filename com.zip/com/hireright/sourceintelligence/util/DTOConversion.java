package com.hireright.sourceintelligence.util;

import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.api.v2.dto.SourceDTO;
import com.hireright.sourceintelligence.domain.mapper.SourceV2Mapper;
import lombok.RequiredArgsConstructor;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
@Service
public class DTOConversion {

    private static final String ADDIONAL_INFO = "addionalInfo";
    private static final String STATE = "state";



    private final SourceV2Mapper sourceV2Mapper;


    public SourceOrganizationDTO convertV2DtoToV1Dto(SourceDTO source) {
        SourceOrganizationDTO sourceOrganizationDTO = sourceV2Mapper.sourceDTOtoSourceOrganizationDTO(source);
        if(sourceOrganizationDTO.getPayload() != null){
            JSONObject payload = sourceOrganizationDTO.getPayload();
            payload.put(ADDIONAL_INFO, new JSONArray().put(source.getPayload().get(ADDIONAL_INFO)));
            sourceOrganizationDTO.setPayload(payload);

            JSONArray address = (JSONArray)source.getPayload().get("address");
            JSONObject addressObj = (JSONObject)address.get(0);

            if(addressObj.has("city")){
                if(addressObj.get("city") != "" || addressObj.get("city") != null){
                    sourceOrganizationDTO.setCity((String) addressObj.get("city"));
                }
            }
            if(addressObj.has(STATE)){
                if(addressObj.get(STATE) != "" || addressObj.get(STATE) != null){
                    sourceOrganizationDTO.setState((String) addressObj.get(STATE));
                }
            }
            if(addressObj.has("countryCode")){
                sourceOrganizationDTO.setCountry((String)addressObj.get("countryCode"));
            }
        }

        return sourceOrganizationDTO;
    }

    public SourceDTO convertV1DtoToV2Dto(SourceOrganizationDTO source) {
        SourceDTO sourceDTO = sourceV2Mapper.sourceOrganizationDTOtoSourceDTO(source);
        JSONObject resPayload = sourceDTO.getPayload();
        JSONArray resAddionalInfo = resPayload.getJSONArray(ADDIONAL_INFO);
        resPayload.put(ADDIONAL_INFO, resAddionalInfo.get(0));
        sourceDTO.setPayload(resPayload);

        return sourceDTO;
    }

    public List<SourceDTO> convertV1ListToV2List(List<SourceOrganizationDTO> sourceV1List) {
        List<SourceDTO> sourceList = sourceV2Mapper.toSourceDTOList(sourceV1List);
        List<SourceDTO> result = new ArrayList<>();
        for(SourceDTO source : sourceList){
            if(source.getPayload() != null){
                JSONObject resPayload = source.getPayload();
                JSONArray resAddionalInfo = resPayload.getJSONArray(ADDIONAL_INFO);
                resPayload.put(ADDIONAL_INFO, resAddionalInfo.get(0));
                source.setPayload(resPayload);
            }
            result.add(source);
        }
        return result;
    }

}
