/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.log;

import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.Direction;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.RecipientName;

import java.util.Map;

import static hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.Direction.OUT;
import static java.util.Collections.emptyMap;
import static java.util.Objects.requireNonNull;

public record LogOptions(String transactionId, String recipientClass, String recipientId,
						 String protocol, RecipientName recipientName, Direction direction,
						 Map<String, String> parameters)
{

	public LogOptions
	{
		requireNonNull(transactionId, "transactionId cannot be null");
		requireNonNull(recipientClass, "recipientClass cannot be null");
		requireNonNull(recipientId, "recipientId cannot be null");
		requireNonNull(protocol, "protocol cannot be null");
		requireNonNull(recipientName, "recipientName cannot be null");
		requireNonNull(direction, "direction cannot be null");
		requireNonNull(parameters, "parameters cannot be null");
	}

	public static final class LogOptionsBuilder
	{
		private String transactionId;
		private String recipientClass;
		private String recipientId;
		private String protocol;
		private RecipientName recipientName;
		private Direction direction;
		private Map<String, String> parameters = emptyMap();

		private LogOptionsBuilder()
		{
		}

		public static LogOptionsBuilder aLogOptions()
		{
			return new LogOptionsBuilder();
		}

		public static LogOptionsBuilder cdm2LogOptions()
		{
			return aLogOptions().direction(OUT)
				.recipientClass("BACKEND")
				.recipientID("RECOMBO.REST_API")
				.protocol("RECOMBO.REST-API/1.0");
		}

		public LogOptionsBuilder transactionId(String transactionId)
		{
			this.transactionId = transactionId;
			return this;
		}

		public LogOptionsBuilder recipientClass(String recipientClass)
		{
			this.recipientClass = recipientClass;
			return this;
		}

		public LogOptionsBuilder recipientID(String recipientID)
		{
			this.recipientId = recipientID;
			return this;
		}

		public LogOptionsBuilder protocol(String protocol)
		{
			this.protocol = protocol;
			return this;
		}

		public LogOptionsBuilder recipientName(RecipientName recipientName)
		{
			this.recipientName = recipientName;
			return this;
		}

		public LogOptionsBuilder direction(Direction direction)
		{
			this.direction = direction;
			return this;
		}

		public LogOptionsBuilder parameters(Map<String, String> parameters)
		{
			this.parameters = parameters;
			return this;
		}

		public LogOptions build()
		{
			return new LogOptions(transactionId, recipientClass, recipientId, protocol,
				recipientName, direction, parameters);
		}
	}
}
