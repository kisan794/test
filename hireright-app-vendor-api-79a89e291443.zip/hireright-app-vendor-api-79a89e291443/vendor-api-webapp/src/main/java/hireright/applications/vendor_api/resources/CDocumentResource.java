package hireright.applications.vendor_api.resources;
/*
 * @(#)$RCSfile: $ $Revision: $ $Date: $ $Author: $
 *
 * Copyright 2001-2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Logachyov		2017-10-15	Created
 *	A.Logachyov		2017-11-16	Added JackRabbit documents
 */

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;

import org.apache.commons.codec.binary.Base64;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import hireright.applications.vendor_api.EHostReference;
import hireright.applications.vendor_api.EVendorReference;
import hireright.applications.vendor_api.exchange.handler.utils.CExchangeUtils;
import hireright.applications.vendor_api.facades.DocumentMetadataFacade;
import hireright.applications.vendor_api.model.CUploadedDocumentsResponse;
import hireright.applications.vendor_api.responses.FileResponse;
import hireright.applications.vendor_api.services.DocumentService;
import hireright.components.domain.dialects.vendor_api.Document;
import hireright.components.domain.dialects.vendor_api.Document.Content;
import hireright.components.domain.dialects.vendor_api.DocumentBundle;
import hireright.components.domain.dialects.vendor_api.DocumentMetadata;
import hireright.document_repository.core.document.IDocumentID;
import hireright.objects.applicant.CApplicant;
import hireright.objects.application.CApplication;
import hireright.objects.application.CApplicationManager;
import hireright.objects.application.CApplicationOrder;
import hireright.objects.application.CApplicationOrderFactory;
import hireright.objects.documents.supporting_document.CSupportingDocumentDescription;
import hireright.objects.documents.supporting_document.CSupportingDocumentService;
import hireright.objects.is.CEvent;
import hireright.objects.order.COrder;
import hireright.objects.order2.COrderManager;
import hireright.objects.order2.COrderProperty;
import hireright.objects.order2.COrderServiceManager;
import hireright.objects.order2.COrderServiceProperty;
import hireright.objects.order2.loaders.COrderLoader;
import hireright.objects.rollout_feature.CRolloutFeatureFactory;
import hireright.objects.vendor_api.document_sync.CDocumentSyncRegistry;
import hireright.objects.vendor_api.document_sync.CDocumentSyncRegistryRepository;
import hireright.objects.vendor_api.document_sync.EStorage;
import hireright.objects.vendor_api.document_sync.providers.DocumentProviderFactory;
import hireright.objects.vendor_api.document_sync.providers.IDocumentProvider;
import hireright.sdk.db.CMultitenantDB;
import hireright.sdk.db3.DB;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.CStringUtils;

@RestController
public class CDocumentResource extends AResource
{
	private final long MAX_FILE_SIZE = 25L*1024L*1024L;
	
	private final List<String> supportedMimeTypes = Arrays.asList(
			"application/msword",
			"application/vnd.openxmlformats-officedocument.wordprocessingml.document",
			"application/pdf",
			"image/jpeg",
			"image/gif",
			"image/tiff",
			"image/png",
			"application/vnd.ms-powerpoint",
			"application/vnd.openxmlformats-officedocument.presentationml.presentation",
			"text/plain",
			"application/vnd.ms-excel",
			"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
			"application/rtf");
	
	private static final int EVENT_TYPE_START_DOC_SYNC = 755;
	
	private static final String RF_HTTP_DOCUMENT_REPOSITORY_PROXY_ENABLED = "HTTP_DOCUMENT_REPOSITORY_PROXY_ENABLED";	

	@RequestMapping(path = DocumentService.PATH_GET,
			method = RequestMethod.GET,
			produces = MediaType.APPLICATION_XML_VALUE)
	public DocumentBundle getDocuments(@PathVariable(name=DocumentService.VAR_ORDER_REF) final String sOrderRef)
		throws Exception
	{
		String sTenantCode = CExchangeUtils.getTenantCodeByOrderCode(sOrderRef);

		return CMultitenantDB.execute(sTenantCode, () -> {

		return DB.execute(new Callable<DocumentBundle>()
		{
			@Override
			public DocumentBundle call() 
				throws Exception
			{
				DB.requestReadOnly();
				
				DocumentBundle documentBundle = new DocumentBundle();
				List<DocumentMetadata> documentMetadatas = documentBundle.getDocumentMetadatas();
				
				Long nOrderID = COrder.findOrderByRegID(DB.connection(), sOrderRef);
				Integer nCustomerID = COrderManager.getCustomerID(nOrderID);

				List<DocumentMetadataFacade> documents = new ArrayList<>();
				
				boolean isProxyMode = CRolloutFeatureFactory.isFeatureGranted(RF_HTTP_DOCUMENT_REPOSITORY_PROXY_ENABLED, "CUSTOMER", String.valueOf(nCustomerID));
				
				for (EStorage storage : EStorage.values())
				{
					if ((storage.isSearchableInProxyMode() && isProxyMode )
					    || (storage.isSearchableInDirectMode() && !isProxyMode ))
					{
						IDocumentProvider documentProvider = DocumentProviderFactory.get(storage);
						documents.addAll(getDocumentMetadatas(documentProvider, nOrderID, nCustomerID));
					}
				}
				
				if (!documents.isEmpty())
				{
					List<CDocumentSyncRegistry> syncedDocuments = CDocumentSyncRegistryRepository.find(COrder.OBJECT_CLASS, String.valueOf(nOrderID));
				
					documents.stream()
						.filter(metadata -> isOriginal(metadata, syncedDocuments))
						.forEach(metadata -> documentMetadatas.add(metadata.getDocumentMetadata()));
				}
				
				return documentBundle;
			}
		});
		});
	}

	private List<DocumentMetadataFacade> getDocumentMetadatas(IDocumentProvider documentProvider, Long nOrderID, Integer nCustomerID)
	{
		List<DocumentMetadataFacade> documents = new ArrayList<>();

		if (nOrderID == null)
		{
			return documents;
		}
		
		CApplicationOrder applicationOrder = CApplicationOrderFactory.loadByOrderID(nOrderID);
		
		String sApplicationID =  applicationOrder != null ? String.valueOf(applicationOrder.getApplicationID()) : null;
		
		documents.addAll(documentProvider.getDocuments(COrder.OBJECT_CLASS, String.valueOf(nOrderID), COrderManager.getOrderCode(nOrderID), nCustomerID));
		
		if (!CStringUtils.isEmpty(sApplicationID))
		{
			for (DocumentMetadataFacade document : documentProvider.getDocuments(CApplication.OBJECT_CLASS, sApplicationID, nCustomerID))
			{
				addUniqueDocument(documents, document);
			}
			
			Integer nApplicantID = CApplicationManager.getApplicantID(applicationOrder.getApplicationID());
			
			if (nApplicantID != null)
			{
				for (DocumentMetadataFacade document : documentProvider.getDocuments(CApplicant.OBJECT_CLASS, String.valueOf(nApplicantID), nCustomerID))
				{
					addUniqueDocument(documents, document);
				}
			}
		}
		
		return documents;
	}
	
	private void addUniqueDocument(List<DocumentMetadataFacade> existingDocuments, DocumentMetadataFacade document)
	{
		for (DocumentMetadataFacade existingDocument : existingDocuments )
		{
			if (existingDocument.getReference().equals(document.getReference())
				&& existingDocument.getStorage().equals(document.getStorage()))
			{
				return;
			}
		}
		
		existingDocuments.add(document);
	}
	
	protected boolean isOriginal(DocumentMetadataFacade metadata, List<CDocumentSyncRegistry> syncedDocuments) 
	{
		for (CDocumentSyncRegistry syncedDocument : syncedDocuments)
		{
			if (syncedDocument.getVendorStorageReference().equals(metadata.getStorage())
					&& syncedDocument.getVendorDocumentReference().equals(metadata.getReference()))
			{
				return false;
			}
		}
		
		return true;
	}

	@RequestMapping(path = DocumentService.PATH_GET_CONTENT,
			method = RequestMethod.GET,
			produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<InputStreamResource> getDocumentContent(@PathVariable(name=DocumentService.VAR_ORDER_REF) final String sOrderRef,
			@PathVariable(name=DocumentService.VAR_STORAGE_REF) final String sStorageRef,
			@PathVariable(name=DocumentService.VAR_DOCUMENT_REF) final String sDocumentRef)
		throws Exception
	{
		String sTenantCode = CExchangeUtils.getTenantCodeByOrderCode(sOrderRef);

		return CMultitenantDB.execute(sTenantCode, () -> {

		return DB.execute(() ->
		{
			try
			{
				DB.requestTransaction();
				Long nOrderID = COrder.findOrderByRegID(DB.connection(), sOrderRef);
				Integer nCustomerID = COrderManager.getCustomerID(nOrderID);
				
				IDocumentProvider documentProvider = DocumentProviderFactory.get(EStorage.valueOf(sStorageRef));
				List<DocumentMetadataFacade> documents = getDocumentMetadatas(documentProvider, nOrderID, nCustomerID);
				
				FileResponse fileResponse = null;
				
				for (DocumentMetadataFacade document : documents)
				{
					if (document.getReference().equals(sDocumentRef))
					{
						fileResponse = documentProvider.getContent(sDocumentRef, nCustomerID);
						break;
					}
				}
				
				if (fileResponse == null)
				{
					throw new CRuntimeException("Document content is not found");
					
				}
				
				return createFileResponseEntity(fileResponse);
			}
			catch(Throwable e)
			{
				return ResponseEntity.notFound().build();
			}
		});
		});
	}
	
	private  ResponseEntity<InputStreamResource> createFileResponseEntity(FileResponse fileResponse)
	{
		if(fileResponse.getContent() != null && fileResponse.getContent().length > 0)
		{
			InputStreamResource resource = new InputStreamResource(new ByteArrayInputStream(fileResponse.getContent()), fileResponse.getFileName());
			return new ResponseEntity<>(resource, fileResponse.getHeaders(), HttpStatus.OK);
		}
		return ResponseEntity.notFound().build();
	}
	
	
	@RequestMapping(path = DocumentService.PATH_POST,
			method = RequestMethod.POST,
			consumes = MediaType.APPLICATION_XML_VALUE,
			produces = MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity postDocument(@PathVariable(name = DocumentService.VAR_ORDER_REF) String orderRef, @RequestBody Document document) throws Exception
	{
		String sTenantCode = CExchangeUtils.getTenantCodeByOrderCode(orderRef);

		return CMultitenantDB.execute(sTenantCode, () -> {
			
		
		Long nOrderID = DB.execute(() -> {
			DB.requestReadOnly();
			return COrder.findOrderByRegID(DB.connection(), orderRef);
		});
		
		if(nOrderID == null)
		{
			return ResponseEntity.badRequest().body("Invalid 'orderRef'");
		}
		
		CUploadedDocumentsResponse response = new CUploadedDocumentsResponse();
		response.setFileName(document.getFileName());
		response.setTitle(document.getTitle());
		
		Content content = document.getContent();
		
		if(content == null || content.getValue() == null || !Base64.isBase64(content.getValue()))
		{
			response.setStatus("Empty or invalid document content");
			return ResponseEntity.badRequest().body(response);
		}
		
		byte[] payload = Base64.decodeBase64(content.getValue().getBytes());
		
		if(payload.length > MAX_FILE_SIZE && supportedMimeTypes.contains(content.getContentType()))
		{
			response.setStatus("Not Attached - Document is too large");
		}
		else if(payload.length <= MAX_FILE_SIZE && !supportedMimeTypes.contains(content.getContentType()))
		{
			response.setStatus("Not Attached - Extension not supported");
		}
		
		if(CStringUtils.isNotEmpty(response.getStatus()))
		{
			return ResponseEntity.badRequest().body(response);
		}
		
		// document DMS manipulation
		String sStatus = DB.execute(new Callable<String>()
		{		
			@Override
			public String call() 
				throws Exception
			{
				DB.requestTransaction();
				Integer nCustomerID = (new COrderLoader()).loadOrderInfo(nOrderID).getCustomerId();
				
				CSupportingDocumentService service = CSupportingDocumentService.getInstance();
		
				CSupportingDocumentDescription desc = service.createDocumentDescription(nCustomerID);
				desc.setOrderID(nOrderID);
				desc.setCustomerID(nCustomerID);
				desc.setFilename(document.getFileName());
				desc.setMimeType(document.getContent().getContentType());
				
				try
				{
					IDocumentID uploadedDocID = service.putDocument(desc, payload);
					return "Attached";
				}
				catch(Exception e)
				{
					CProperties props = new CProperties();
					
					props.setProperty("orderId", nOrderID);
					props.setProperty("fileName", document.getFileName());
					props.setProperty("mimeType", content.getContentType());
					props.setProperty("fileSize", payload.length);
					CTraceLog.error("Failed to upload file to JackRabbit DMS", this.getClass().getName() + ".postDocument()", props);
					return "Not Attached - Failed to upload";
				}
			}
		});
		response.setStatus(sStatus);		
		
		if(!"Attached".equals(sStatus))
		{
			// original code returns ok() with empty status in such case
			response.setStatus("");				
			return ResponseEntity.ok().body(response);
		}		
	
		return ResponseEntity.ok().body(response);
		});
	}

		@RequestMapping(path = DocumentService.PATH_SYNC,
				method = RequestMethod.POST,
				produces = MediaType.TEXT_PLAIN_VALUE)
		public String raiseDocumentSyncEvent(@PathVariable(name=DocumentService.VAR_ORDER_REF) final String sOrderRef,
				@PathVariable(name=DocumentService.VAR_ORDER_SERVICE_REF) final String sOrderServiceRef)
				throws Exception
		{
			String sTenantCode = CExchangeUtils.getTenantCodeByOrderCode(sOrderRef);

			return CMultitenantDB.execute(sTenantCode, () -> {
				return DB.execute(new Callable<String>()
				{
						@Override
						public String call()
								throws Exception
						{
								Long nOrderID = COrder.findOrderByRegID(DB.connection(), sOrderRef);

								COrderProperty orderProperty = COrderProperty.loadPropertyByName(nOrderID, EHostReference.HOST_INSTANCE_REF.getPropertyName());
								CProperties properties = new CProperties();
								
								if (orderProperty != null && !CStringUtils.isEmpty(orderProperty.getValue()))
								{
									properties.setProperty("orderID", nOrderID);	
								}
								else
								{
									Long nOrderServiceID = COrderServiceManager.getOrderServiceID(nOrderID, sOrderServiceRef);
									
									COrderServiceProperty orderServiceProperty = COrderServiceProperty.getPropertyByName(nOrderServiceID, EVendorReference.VENDOR_INSTANCE_REF.getPropertyName());
									
									if (orderServiceProperty != null && !CStringUtils.isEmpty(orderServiceProperty.getValue()))
									{
										properties.setProperty("orderServiceID", nOrderServiceID);	
									}
									else
									{
										return "Remote request is not found";
									}
								}
								
								
								CEvent.create(EVENT_TYPE_START_DOC_SYNC, "BASE", properties);

								DB.commit();

								return "Syncronization initialized";
						}
				});
			});
		}

}
