/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.config;

import hireright.applications.fulfillment_task_api.rest.recombointegration.http.config.HttpClientConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.net.http.HttpClient;
import java.time.Duration;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit tests for HttpClientConfig
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@DisplayName("HttpClientConfig Tests")
class HttpClientConfigTest
{

	private HttpClientConfig config;

	@BeforeEach
	void setUp()
	{
		config = new HttpClientConfig();
	}

	@Test
	@DisplayName("Should initialize with valid configuration")
	void testInitWithValidConfig()
	{
		// Given
		ReflectionTestUtils.setField(config, "connectTimeoutSeconds", 10);
		ReflectionTestUtils.setField(config, "requestTimeoutSeconds", 30);
		ReflectionTestUtils.setField(config, "httpVersionString", "HTTP_2");
		ReflectionTestUtils.setField(config, "redirectPolicyString", "NORMAL");
		ReflectionTestUtils.setField(config, "enableCompression", true);

		// When & Then
		assertDoesNotThrow(() -> config.init());
	}

	@Test
	@DisplayName("Should throw exception when connect timeout is zero")
	void testInitWithZeroConnectTimeout()
	{
		// Given
		ReflectionTestUtils.setField(config, "connectTimeoutSeconds", 0);
		ReflectionTestUtils.setField(config, "requestTimeoutSeconds", 30);

		// When & Then
		assertThrows(IllegalStateException.class, () -> config.init());
	}

	@Test
	@DisplayName("Should throw exception when connect timeout is negative")
	void testInitWithNegativeConnectTimeout()
	{
		// Given
		ReflectionTestUtils.setField(config, "connectTimeoutSeconds", -5);
		ReflectionTestUtils.setField(config, "requestTimeoutSeconds", 30);

		// When & Then
		assertThrows(IllegalStateException.class, () -> config.init());
	}

	@Test
	@DisplayName("Should throw exception when request timeout is zero")
	void testInitWithZeroRequestTimeout()
	{
		// Given
		ReflectionTestUtils.setField(config, "connectTimeoutSeconds", 10);
		ReflectionTestUtils.setField(config, "requestTimeoutSeconds", 0);

		// When & Then
		assertThrows(IllegalStateException.class, () -> config.init());
	}

	@Test
	@DisplayName("Should throw exception when request timeout is negative")
	void testInitWithNegativeRequestTimeout()
	{
		// Given
		ReflectionTestUtils.setField(config, "connectTimeoutSeconds", 10);
		ReflectionTestUtils.setField(config, "requestTimeoutSeconds", -10);

		// When & Then
		assertThrows(IllegalStateException.class, () -> config.init());
	}

	@Test
	@DisplayName("Should return correct connect timeout duration")
	void testGetConnectTimeout()
	{
		// Given
		ReflectionTestUtils.setField(config, "connectTimeoutSeconds", 15);

		// When
		Duration timeout = config.getConnectTimeout();

		// Then
		assertEquals(Duration.ofSeconds(15), timeout);
	}

	@Test
	@DisplayName("Should return correct request timeout duration")
	void testGetRequestTimeout()
	{
		// Given
		ReflectionTestUtils.setField(config, "requestTimeoutSeconds", 45);

		// When
		Duration timeout = config.getRequestTimeout();

		// Then
		assertEquals(Duration.ofSeconds(45), timeout);
	}

	@Test
	@DisplayName("Should return HTTP_2 version")
	void testGetHttpVersionHTTP2()
	{
		// Given
		ReflectionTestUtils.setField(config, "httpVersionString", "HTTP_2");

		// When
		HttpClient.Version version = config.getHttpVersion();

		// Then
		assertEquals(HttpClient.Version.HTTP_2, version);
	}

	@Test
	@DisplayName("Should return HTTP_1_1 version")
	void testGetHttpVersionHTTP11()
	{
		// Given
		ReflectionTestUtils.setField(config, "httpVersionString", "HTTP_1_1");

		// When
		HttpClient.Version version = config.getHttpVersion();

		// Then
		assertEquals(HttpClient.Version.HTTP_1_1, version);
	}

	@Test
	@DisplayName("Should default to HTTP_2 for invalid version string")
	void testGetHttpVersionInvalid()
	{
		// Given
		ReflectionTestUtils.setField(config, "httpVersionString", "INVALID_VERSION");

		// When
		HttpClient.Version version = config.getHttpVersion();

		// Then
		assertEquals(HttpClient.Version.HTTP_2, version);
	}

	@Test
	@DisplayName("Should return NORMAL redirect policy")
	void testGetRedirectPolicyNormal()
	{
		// Given
		ReflectionTestUtils.setField(config, "redirectPolicyString", "NORMAL");

		// When
		HttpClient.Redirect policy = config.getRedirectPolicy();

		// Then
		assertEquals(HttpClient.Redirect.NORMAL, policy);
	}

	@Test
	@DisplayName("Should return NEVER redirect policy")
	void testGetRedirectPolicyNever()
	{
		// Given
		ReflectionTestUtils.setField(config, "redirectPolicyString", "NEVER");

		// When
		HttpClient.Redirect policy = config.getRedirectPolicy();

		// Then
		assertEquals(HttpClient.Redirect.NEVER, policy);
	}

	@Test
	@DisplayName("Should return ALWAYS redirect policy")
	void testGetRedirectPolicyAlways()
	{
		// Given
		ReflectionTestUtils.setField(config, "redirectPolicyString", "ALWAYS");

		// When
		HttpClient.Redirect policy = config.getRedirectPolicy();

		// Then
		assertEquals(HttpClient.Redirect.ALWAYS, policy);
	}

	@Test
	@DisplayName("Should default to NORMAL for invalid redirect policy")
	void testGetRedirectPolicyInvalid()
	{
		// Given
		ReflectionTestUtils.setField(config, "redirectPolicyString", "INVALID_POLICY");

		// When
		HttpClient.Redirect policy = config.getRedirectPolicy();

		// Then
		assertEquals(HttpClient.Redirect.NORMAL, policy);
	}

	@Test
	@DisplayName("Should return compression enabled status")
	void testIsEnableCompressionTrue()
	{
		// Given
		ReflectionTestUtils.setField(config, "enableCompression", true);

		// When
		boolean enabled = config.isEnableCompression();

		// Then
		assertTrue(enabled);
	}

	@Test
	@DisplayName("Should return compression disabled status")
	void testIsEnableCompressionFalse()
	{
		// Given
		ReflectionTestUtils.setField(config, "enableCompression", false);

		// When
		boolean enabled = config.isEnableCompression();

		// Then
		assertFalse(enabled);
	}

	@Test
	@DisplayName("Should get connect timeout seconds")
	void testGetConnectTimeoutSeconds()
	{
		// Given
		ReflectionTestUtils.setField(config, "connectTimeoutSeconds", 20);

		// When
		int seconds = config.getConnectTimeoutSeconds();

		// Then
		assertEquals(20, seconds);
	}

	@Test
	@DisplayName("Should get request timeout seconds")
	void testGetRequestTimeoutSeconds()
	{
		// Given
		ReflectionTestUtils.setField(config, "requestTimeoutSeconds", 60);

		// When
		int seconds = config.getRequestTimeoutSeconds();

		// Then
		assertEquals(60, seconds);
	}

	@Test
	@DisplayName("Should get HTTP version string")
	void testGetHttpVersionString()
	{
		// Given
		ReflectionTestUtils.setField(config, "httpVersionString", "HTTP_2");

		// When
		String versionString = config.getHttpVersionString();

		// Then
		assertEquals("HTTP_2", versionString);
	}

	@Test
	@DisplayName("Should get redirect policy string")
	void testGetRedirectPolicyString()
	{
		// Given
		ReflectionTestUtils.setField(config, "redirectPolicyString", "NORMAL");

		// When
		String policyString = config.getRedirectPolicyString();

		// Then
		assertEquals("NORMAL", policyString);
	}
}