package com.hireright.sourceintelligence.api.v1;

import static com.hireright.sourceintelligence.api.ApiConstants.*;

import static com.hireright.sourceintelligence.constants.ErrorConstants.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.StatusCode.FAILURE2_CODE;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.StatusCode.SUCCESS_CODE;
import static com.hireright.sourceintelligence.util.LoggingThrowable.*;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchResponseDTO;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.exception.ApiError;
import com.hireright.sourceintelligence.service.*;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.*;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * Controller to trigger CRUD operations on SourceOrganization Document
 */

@RestController
@EnableRetry
@RequiredArgsConstructor
@Validated
@Slf4j
@CrossOrigin
public class SourceApiController implements SourceApi {

    private final SourceService sourceService;

    @Override
    public ResponseEntity<SourceOrganizationDTO> createSourceOrganization(@Valid @RequestBody SourceRequestDTO sourceRequest, HttpServletRequest httpServletRequest) {
        SourceOrganizationDTO sourceOrganizationDTO = sourceRequest.getSourceOrganizationDTO();
        UIActionsDTO uiActionsDTO = sourceRequest.getUiActionsDTO();
        return new ResponseEntity<>(sourceService.createSource(sourceOrganizationDTO, uiActionsDTO),
                HttpStatus.CREATED);
    }

    @Override
    public ResponseEntity<SourceOrganizationDTO> updateSourceOrganization(@PathVariable(value = HON) @NotBlank final String hon,
                                                                          @Valid @RequestBody SourceRequestDTO sourceRequest, HttpServletRequest httpServletRequest) {

        SourceOrganizationDTO sourceOrganizationDTO = sourceRequest.getSourceOrganizationDTO();
        UIActionsDTO uiActionsDTO = sourceRequest.getUiActionsDTO();
        validateSourceOrganization(hon, sourceOrganizationDTO);
        return new ResponseEntity<>(sourceService.updateSource(sourceOrganizationDTO, uiActionsDTO),
                HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ResponseObject> archiveSource(String hon, SourceRequestDTO sourceRequestDTO, HttpServletRequest httpServletRequest) {
        ResponseObject response = sourceService.archiveSource(hon,sourceRequestDTO.getUiActionsDTO());
        var responseHeaders = new HttpHeaders();
        return new ResponseEntity<>(response, responseHeaders, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Object> getSourceOrganization(@PathVariable(value = HON) @NotNull final String hon,
                                                                       String mode, ApprovalStatus approvalStatus, String action,
                                                                       Boolean isRam) {
        if(hon == null || hon.isEmpty()){
            logAndThrowInvalidRequest(INVALID_INPUT, null);
        }
        SourceOrganizationDTO response = null;
        if(Boolean.TRUE.equals(isRam)){
            response = sourceService.getSourceByHonAndApprovalStatus(hon, approvalStatus);

        }else{
            if(VIEW.equalsIgnoreCase(mode)){
                response = sourceService.getSourceByHonAndApprovalStatus(hon, approvalStatus);
            }else if(EDIT.equalsIgnoreCase(mode)){
                response = sourceService.getSourceForEditByHon(hon, action);
            }else if(OPTOOL_VIEW.equalsIgnoreCase(mode)){
                response = sourceService.getSourceByHonForOpTool(hon);
            }else if(OPTOOL_EDIT.equalsIgnoreCase(mode)){
               response = sourceService.getSourceForEditByHon(hon, action);
            }
        }
        if(response != null){
            return new ResponseEntity<>(response, HttpStatus.OK);
        }else{
            ApiError error = new ApiError(HttpStatus.NOT_FOUND);
            error.setErrorCode("404");
            error.setMessage("Source Not Found");
            return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
        }
    }

    @Override
    public ResponseEntity<AutoMatchResponseDTO> updateVerificationData(String hon,
                                                                       VerificationRequest verificationRequest) {
        Instant requestTime = Instant.now();
        var response = sourceService.manualSelectSource(hon,verificationRequest.getApprovalStatus());
        var responseHeaders = new HttpHeaders();
        response.setStartTime(Instant.now().toEpochMilli());
        response.setRequestTime(Duration.between(requestTime, Instant.now()).toMillis());
        return new ResponseEntity<>(response, responseHeaders, HttpStatus.OK);
    }

    //Validate the input payload before updating the SourceOrganization
    private void validateSourceOrganization(String hon, SourceOrganizationDTO dto) {
        String errorMessage = null;
        if (StringUtils.isBlank(hon)) {
            errorMessage = "Path Variable hon is empty or blank.";
        }
        if (StringUtils.isBlank(dto.getHon())) {
            errorMessage = "Hon field is empty or blank in the payload.";
        }
        if (!hon.equals(dto.getHon())) {
            errorMessage = "Hon mismatch between path variable and payload.";
        }
        if (errorMessage != null) {
            logAndThrowInvalidRequest(VALIDATION_FAILURE,null,errorMessage);
        }
    }

    @Override
    public ResponseEntity<List<SourceOrganizationDTO>> getSourceOrganizationsByHonIds(
            @RequestBody List<String> honIds){
        if(honIds.size() > 100){
            logAndThrowInvalidRequest(LIMIT_VALIDATION_FAILURE,null);
        }
        return new ResponseEntity<>(sourceService
                .getSourcesByHonIds(honIds), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ResponseObject> assignApproveManagerToSource(ApprovalRequestDTO approvalRequestDTO) {
        var response = sourceService.assignApproveManagerToSource(approvalRequestDTO);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ResponseObject> updateFlagForPriority(String hon, Double version) {
        boolean updatedFlag = sourceService.updateFlagForPriority(hon, version);
        ResponseObject response = new ResponseObject();
        response.setMessage("Organization with hon : " + hon + " flagged " +updatedFlag + " for priority");
        response.setStatus(HttpStatus.OK.toString());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Boolean> updateUsedCount(UsedCountIncrementDTO usedCountIncrementDTO) {
        if(usedCountIncrementDTO.getHon() == null || usedCountIncrementDTO.getHon().isEmpty()){
            logAndThrowInvalidRequest(VALIDATION_FAILURE,null,"Hon is missing");
        }
        var response = sourceService.updateUsedCount(usedCountIncrementDTO.getHon(),usedCountIncrementDTO.isAutoMatch());
        var responseHeaders = new HttpHeaders();
        return new ResponseEntity<>(response, responseHeaders, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ResponseObject> deleteSource(String hon, DeleteRequestDTO deleteRequestDTO) {
        var response = sourceService.deleteSource(hon, deleteRequestDTO);
        var responseHeaders = new HttpHeaders();
        return new ResponseEntity<>(response, responseHeaders, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ResponseObject> lockSource(String hon, UIActionsDTO uiActionsDTO) {
        var response = sourceService.lockSource(hon, uiActionsDTO);
        var responseHeaders = new HttpHeaders();
        return new ResponseEntity<>(response, responseHeaders, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ResponseObject> unlockSource(String hon, UIActionsDTO uiActionsDTO) {
        var response = sourceService.unlockSource(hon, uiActionsDTO);
        var responseHeaders = new HttpHeaders();
        return new ResponseEntity<>(response, responseHeaders, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ResponseObject> updateSourceStatus(String hon, ApprovalStatus approvalStatus, String version, String tempVersion) {
        boolean updatedFlag = sourceService.updateSourceStatus(hon, version, tempVersion, approvalStatus);
        ResponseObject response;
        if(updatedFlag){
            response =  ResponseObject.baseBuilder(SUCCESS,"Updated the status successfully",SUCCESS_CODE).build();
        }else{
            response =  ResponseObject.baseBuilder(FAILURE,"Update failed",FAILURE2_CODE).build();
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<RamResponseDTO> getSourceOrganizationForRAM(@PathVariable String hon,@RequestBody SourceRequestDTO sourceRequestDTO) {
       RamResponseDTO response = sourceService.getSourceForRAM(hon, sourceRequestDTO);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
