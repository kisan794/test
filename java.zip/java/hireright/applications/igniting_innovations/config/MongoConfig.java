package hireright.applications.igniting_innovations.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

/**
 * @author Keshav Ladha
 * @version 1.0
 */
@Configuration
@EnableMongoRepositories(basePackages = "hireright.applications.igniting_innovations.repository")
public class MongoConfig {
}