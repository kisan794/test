package com.hireright.sourceintelligence.service.impl;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.constants.ErrorConstants.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.AggregationPipelineStages.DOC;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchScore.SCORE;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.VERSION;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SortFields.SORT_LAST_MODIFIED_BY;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowResourceNotFound;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.dto.AutocompleteSearchDTO;
import com.hireright.sourceintelligence.api.dto.history.ChangeLogFilters;
import com.hireright.sourceintelligence.domain.entity.*;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.UserRoles;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import java.util.*;

import com.hireright.sourceintelligence.service.SearchHistoryService;
import com.hireright.sourceintelligence.util.Helper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.aggregation.ConditionalOperators.Cond;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

@Slf4j
@RequiredArgsConstructor
@Service
public class SearchHistoryServiceImpl implements SearchHistoryService {

  private final SourceMapper sourceMapper;
  private final CommonSearchImpl commonSearchImpl;
  private final CustomSourceRepository<Source> customSourceRepository;

  /* Aliases are array of strings in collection which mongo autocomplete does not support .
      Aliases are being obtained by wildcard search and thus being handled separately.
  */
  @Override
  public List<AutocompleteSearchDTO>  getAutocompletedFilters(OrganizationType organizationType, String keyword, UserInfo userInfo) {

    Map<String, String> searchFilters = new HashMap<>();
    String collectionName = Helper.getCollectionName(organizationType.getType(), SOURCE_HISTORY_COLLECTION_SUFFIX);
    return commonSearchImpl.getAutocompletedFilters(keyword, false, searchFilters, collectionName);
  }

  //TODO - Remove - Not needed
    @Override
  public SearchResponseDTO getSourceOrganizationsByFilters(
            OrganizationType organizationType, Map<String, Set<String>> searchFilter, List<ApprovalStatus> approvalStatuses, int startPage, int pageSize , UserInfo userInfo) {

    AggregationOptions aggregationOptionsToAllowDiskUse = AggregationOptions.builder().allowDiskUse(true).build();

    Criteria criteria = QueryBuilder.buildDocumentByFilter(searchFilter);
      criteria.and(ASSIGNED_TO).is(UNASSIGNED);
    Criteria criteriaForUnAssigned = Criteria.where(ASSIGNED_TO).is(UNASSIGNED);

    /* Projecting ASSIGNED_TO with UnAssigned value as empty string inorder to get them at the bottom
    as desired after sorting by the field in desc order */
    ProjectionOperation projectSelectiveData = project(HON,ORGANIZATION_NAME, ORGANIZATION_ALIAS,
            ORGANIZATION_TYPE, LAST_MODIFIED_DATE, CITY, STATE, COUNTRY, SCORE,POSTAL_CODE,
            COMMENT,REQUESTED_BY,REQUESTER_ID,ASSIGNED_ID,APPROVAL_STATUS,FLAG_PRIORITY,VERSION, CREATED_DATE)
            .andExpression(ASSIGNED_TO).applyCondition(
                    Cond.when(criteriaForUnAssigned).then("").otherwiseValueOf(ASSIGNED_TO));

    List<String> roles = userInfo.getRoles();

    /*Handling approval status in match operation as search is causing problem.
    On searching by approval status immediately after updating approval status gives incorrect read as
    there is a lag while updating search indexes.*/
    Criteria[] orApprovalStatus = new Criteria[approvalStatuses.size()];
    MatchOperation matchOperation;
    MatchOperation matchOperationForApprovalStatus;

    if(org.apache.commons.lang3.ObjectUtils.isNotEmpty(approvalStatuses)) {
      int i=0;
      for(ApprovalStatus approvalStatus: approvalStatuses) {
        orApprovalStatus[i] = new Criteria(APPROVAL_STATUS).is(approvalStatus.getStatus());
        i++;
      }
      matchOperation = match(
              criteria.and(REQUESTER_ID).is(userInfo.getUsername()).andOperator(new Criteria().orOperator(orApprovalStatus)));

      matchOperationForApprovalStatus = match(new Criteria().orOperator(orApprovalStatus));
    } else{
      matchOperation = match(
              criteria.and(REQUESTER_ID).is(userInfo.getUsername()));
      matchOperationForApprovalStatus = new MatchOperation(new Criteria());
    }

    SortOperation sort =Aggregation.sort(Direction.DESC,FLAG_PRIORITY,ASSIGNED_TO,LAST_MODIFIED_DATE);

    Aggregation aggregation;

    //Quality analyst do not have filter by approval status, so matchOperationForApprovalStatus is not used in aggregation
    if(!searchFilter.isEmpty()) {
      if(isQualityAnalystOnly(roles)){
        aggregation = Aggregation.newAggregation(
                matchOperation,projectSelectiveData,sort,
                QueryBuilder.facetOperation(startPage, pageSize),
                QueryBuilder.finalProjectionWithTotalCountInPipeline()).withOptions(aggregationOptionsToAllowDiskUse);

      } else {
        aggregation = newAggregation(matchOperation,
                projectSelectiveData,matchOperationForApprovalStatus,sort,
                QueryBuilder.facetOperation(startPage, pageSize),
                QueryBuilder.finalProjectionWithTotalCountInPipeline()).withOptions(aggregationOptionsToAllowDiskUse);
      }
    } else {
      if(isQualityAnalystOnly(roles)){
        aggregation = Aggregation.newAggregation(
                projectSelectiveData,matchOperation,sort,
                QueryBuilder.facetOperation(startPage, pageSize),
                QueryBuilder.finalProjectionWithTotalCountInPipeline()).withOptions(aggregationOptionsToAllowDiskUse);
      } else {
        aggregation = Aggregation.newAggregation(
                projectSelectiveData,matchOperationForApprovalStatus,sort,
                QueryBuilder.facetOperation(startPage, pageSize),
                QueryBuilder.finalProjectionWithTotalCountInPipeline()).withOptions(aggregationOptionsToAllowDiskUse);
      }
    }

    String collectionName = Helper.getCollectionName(organizationType.getType(), SOURCE_HISTORY_COLLECTION_SUFFIX);
    var searchResult = customSourceRepository.customAggregate(aggregation, collectionName, MongoSearchResult.class);

    if (CollectionUtils.isEmpty(searchResult.getOrganizationList())) {
      logAndThrowResourceNotFound(NO_SEARCH_FOUND_WITH_FILTERS, null, searchFilter);
    }
    List<SourceOrganizationDTO> sourceDTO = sourceMapper.toSourceDTOList(searchResult.getOrganizationList());

    return SearchResponseDTO.builder()
            .sourceList(sourceDTO)
            .currentPage((startPage))
            .totalItems(searchResult.getTotal())
            .totalPages(QueryBuilder.getTotalPages(searchResult.getTotal(), pageSize))
            .build();
  }

  private boolean isQualityAnalystOnly(List<String> roles){
    return (!ObjectUtils.isEmpty(roles) && roles.contains(UserRoles.QUALITY_ANALYST.getRole()) && !roles.contains(UserRoles.SUPERVISOR.getRole())
            && !roles.contains(UserRoles.MANAGER.getRole()));
  }

  @Override
  public SearchResponseDTO getChangeLogsByFilters(ChangeLogFilters changeLogFilters) {

    AggregationOptions aggregationOptionsToAllowDiskUse = AggregationOptions.builder().allowDiskUse(true).build();

    Criteria criteria = QueryBuilder.buildDocumentForChangeLog(changeLogFilters);
    MatchOperation matchOperation = QueryBuilder.buildMatch(criteria);
    ProjectionOperation projectSelectiveData = QueryBuilder.changeLogProjection();
    if(changeLogFilters.getStartPage() < 1){
      changeLogFilters.setStartPage(1);
    }
    if(changeLogFilters.getPageSize() < 1){
      changeLogFilters.setPageSize(10);
    }

    SortOperation sort =QueryBuilder.buildSortOperation(LAST_MODIFIED_DATE, String.valueOf(Direction.DESC));
    if(changeLogFilters.getSort() != null && changeLogFilters.getOrder() != null){
      if(changeLogFilters.getSort().equals(ORGANIZATION_NAME)){
        changeLogFilters.setSort(SEARCH_ORG);
      }
      if(changeLogFilters.getSort().equals(LAST_MODIFIED_BY)){
        changeLogFilters.setSort(SORT_LAST_MODIFIED_BY);
      }
      sort =QueryBuilder.buildSortOperation(changeLogFilters.getSort(), changeLogFilters.getOrder());
    }
    AddFieldsOperation addFieldsOperation = QueryBuilder.addLastModifiedBy();
    SkipOperation skip = QueryBuilder.skipOperation(changeLogFilters.getStartPage(), changeLogFilters.getPageSize());
    LimitOperation limit = QueryBuilder.limitOperation(changeLogFilters.getPageSize());
    Aggregation aggregation;
    if(changeLogFilters.getSort() != null && changeLogFilters.getSort().equals(SORT_LAST_MODIFIED_BY)){
        aggregation = Aggregation.newAggregation(matchOperation, addFieldsOperation, group(HON).first(Aggregation.ROOT).as(DOC),
                replaceRoot(DOC), sort, skip, limit, projectSelectiveData).withOptions(aggregationOptionsToAllowDiskUse);
    } else {
        aggregation = Aggregation.newAggregation(matchOperation, group(HON).first(Aggregation.ROOT).as(DOC), replaceRoot(DOC), sort,
                skip, limit, addFieldsOperation, projectSelectiveData).withOptions(aggregationOptionsToAllowDiskUse);
    }
    String collectionName = Helper.getCollectionName(changeLogFilters.getOrganizationType().getType(), SOURCE_COLLECTION_SUFFIX);
    log.info("changelog query:{}", aggregation);
    Query query = Query.query(criteria);
    long searchCountResult = customSourceRepository.queryCount(query, collectionName, Source.class);
    List<Source> searchResult = customSourceRepository.aggregate(aggregation, collectionName, Source.class);
    log.info("changelog response:size: {}, list:{}", searchCountResult, searchResult);
    if (CollectionUtils.isEmpty(searchResult)) {
      return SearchResponseDTO.builder()
              .sourceList(new ArrayList<>())
              .currentPage((changeLogFilters.getStartPage())).totalItems(0).totalPages(0)
              .build();
    }
    int total = (int)searchCountResult;
    List<SourceOrganizationDTO> sourceDTO = sourceMapper.toSourceDTOList(searchResult);
    return SearchResponseDTO.builder()
            .sourceList(sourceDTO)
            .currentPage((changeLogFilters.getStartPage()))
            .totalItems(total)
            .totalPages(QueryBuilder.getTotalPages(total, changeLogFilters.getPageSize()))
            .build();
  }


}
