package com.hireright.sourceintelligence.reports.domain.mapper;

import com.hireright.sourceintelligence.reports.domain.entity.Reports;
import com.hireright.sourceintelligence.reports.domain.entity.ResponseReport;
import com.hireright.sourceintelligence.reports.dto.GenericResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportsDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class ReportMapperImplTest {

    private ReportMapperImpl mapper;

    @BeforeEach
    void setUp() {
        mapper = new ReportMapperImpl();
    }

    @Test
    void constructor_shouldCreateInstance() {
        assertNotNull(new ReportMapperImpl());
    }

    @Test
    void dtoToEntity_shouldReturnNull_whenDtoIsNull() {
        assertNull(mapper.dtoToEntity(null));
    }

    @Test
    void dtoToEntity_shouldMapAllFields_whenDtoHasValues() throws Exception {
        ReportsDTO dto = new ReportsDTO();
        populateBean(dto);

        Reports entity = mapper.dtoToEntity(dto);

        assertNotNull(entity);
        assertSamePropertyValue(dto, entity, "hon");
        assertSamePropertyValue(dto, entity, "organizationName");
        assertSamePropertyValue(dto, entity, "address");
        assertSamePropertyValue(dto, entity, "verificationValidationDate");
        assertSamePropertyValue(dto, entity, "organizationType");
        assertSamePropertyValue(dto, entity, "origin");
        assertSamePropertyValue(dto, entity, "approvalStatus");
        assertSamePropertyValue(dto, entity, "approvedBy");
        assertSamePropertyValue(dto, entity, "approvedId");
        assertSamePropertyValue(dto, entity, "autoMatch");
        assertSamePropertyValue(dto, entity, "action");
        assertSamePropertyValue(dto, entity, "createdBy");
        assertSamePropertyValue(dto, entity, "reason");
        assertSamePropertyValue(dto, entity, "version");
        assertSamePropertyValue(dto, entity, "tempVersion");
        assertSamePropertyValue(dto, entity, "txnType");
    }

    @Test
    void dtoToEntity_shouldLeaveNullableFieldsUnset_whenDtoFieldsAreNull() throws Exception {
        ReportsDTO dto = new ReportsDTO();

        setProperty(dto, "autoMatch", 1);
        setProperty(dto, "version", 11.0d);
        setProperty(dto, "tempVersion", 22.0d);

        Reports entity = mapper.dtoToEntity(dto);

        assertNotNull(entity);
        assertNull(getProperty(entity, "hon"));
        assertNull(getProperty(entity, "organizationName"));
        assertNull(getProperty(entity, "address"));
        assertNull(getProperty(entity, "verificationValidationDate"));
        assertNull(getProperty(entity, "organizationType"));
        assertNull(getProperty(entity, "origin"));
        assertNull(getProperty(entity, "approvalStatus"));
        assertNull(getProperty(entity, "approvedBy"));
        assertNull(getProperty(entity, "approvedId"));

        assertEquals(1, getProperty(entity, "autoMatch"));

        assertNull(getProperty(entity, "action"));
        assertNull(getProperty(entity, "createdBy"));
        assertNull(getProperty(entity, "reason"));

        assertEquals(11.0d, (Double) getProperty(entity, "version"));
        assertEquals(22.0d, (Double) getProperty(entity, "tempVersion"));

        assertNull(getProperty(entity, "txnType"));
    }

    @Test
    void entityToDTO_shouldReturnNull_whenEntityIsNull() {
        assertNull(mapper.entityToDTO(null));
    }

    @Test
    void entityToDTO_shouldMapAllFields_whenEntityHasValues() throws Exception {
        Reports entity = new Reports();
        populateBean(entity);

        ReportsDTO dto = mapper.entityToDTO(entity);

        assertNotNull(dto);
        assertSamePropertyValue(entity, dto, "hon");
        assertSamePropertyValue(entity, dto, "organizationName");
        assertSamePropertyValue(entity, dto, "address");
        assertSamePropertyValue(entity, dto, "verificationValidationDate");
        assertSamePropertyValue(entity, dto, "organizationType");
        assertSamePropertyValue(entity, dto, "origin");
        assertSamePropertyValue(entity, dto, "approvalStatus");
        assertSamePropertyValue(entity, dto, "approvedBy");
        assertSamePropertyValue(entity, dto, "approvedId");
        assertSamePropertyValue(entity, dto, "autoMatch");
        assertSamePropertyValue(entity, dto, "action");
        assertSamePropertyValue(entity, dto, "createdBy");
        assertSamePropertyValue(entity, dto, "reason");
        assertSamePropertyValue(entity, dto, "version");
        assertSamePropertyValue(entity, dto, "tempVersion");
        assertSamePropertyValue(entity, dto, "txnType");
    }

    @Test
    void entityToDTO_shouldLeaveNullableFieldsUnset_whenEntityFieldsAreNull() throws Exception {
        Reports entity = new Reports();

        setProperty(entity, "autoMatch", 0);
        setProperty(entity, "version", 5.0d);
        setProperty(entity, "tempVersion", 6.0d);

        ReportsDTO dto = mapper.entityToDTO(entity);

        assertNotNull(dto);
        assertNull(getProperty(dto, "hon"));
        assertNull(getProperty(dto, "organizationName"));
        assertNull(getProperty(dto, "address"));
        assertNull(getProperty(dto, "verificationValidationDate"));
        assertNull(getProperty(dto, "organizationType"));
        assertNull(getProperty(dto, "origin"));
        assertNull(getProperty(dto, "approvalStatus"));
        assertNull(getProperty(dto, "approvedBy"));
        assertNull(getProperty(dto, "approvedId"));
        assertEquals(0, getProperty(dto, "autoMatch"));
        assertNull(getProperty(dto, "action"));
        assertNull(getProperty(dto, "createdBy"));
        assertNull(getProperty(dto, "reason"));
        assertEquals(5.0d, (Double) getProperty(dto, "version"));
        assertEquals(6.0d, (Double) getProperty(dto, "tempVersion"));
        assertNull(getProperty(dto, "txnType"));
    }

    @Test
    void entityToContactUtilizationDTOList_shouldReturnNull_whenInputIsNull() {
        assertNull(mapper.entityToContactUtilizationDTOList(null));
    }

    @Test
    void entityToContactUtilizationDTOList_shouldMapList() throws Exception {
        Reports entity1 = new Reports();
        Reports entity2 = new Reports();
        populateBean(entity1);
        populateBean(entity2);

        List<ReportsDTO> result = mapper.entityToContactUtilizationDTOList(List.of(entity1, entity2));

        assertNotNull(result);
        assertEquals(2, result.size());
        assertSamePropertyValue(entity1, result.get(0), "hon");
        assertSamePropertyValue(entity2, result.get(1), "hon");
    }

    @Test
    void reportToGenericResponseDTO_shouldReturnNull_whenResponseReportIsNull() {
        assertNull(mapper.reportToGenericResponseDTO(null));
    }

    @Test
    void reportToGenericResponseDTO_shouldMapAllFields_whenResponseReportHasValues() throws Exception {
        ResponseReport report = new ResponseReport();
        populateBean(report);

        GenericResponseDTO dto = mapper.reportToGenericResponseDTO(report);

        assertNotNull(dto);
        assertEquals(getProperty(report, "createdDate"), getProperty(dto, "usedDate"));
        assertSamePropertyValue(report, dto, "organizationName");
        assertSamePropertyValue(report, dto, "hon");
        assertSamePropertyValue(report, dto, "address");
        assertSamePropertyValue(report, dto, "verificationValidationDate");
        assertSamePropertyValue(report, dto, "organizationType");
        assertSamePropertyValue(report, dto, "origin");
        assertSamePropertyValue(report, dto, "approvalStatus");
        assertSamePropertyValue(report, dto, "approvedBy");
        assertSamePropertyValue(report, dto, "usedCount");
        assertSamePropertyValue(report, dto, "operatorName");
        assertSamePropertyValue(report, dto, "researcherName");
        assertSamePropertyValue(report, dto, "added");
        assertSamePropertyValue(report, dto, "changed");
        assertSamePropertyValue(report, dto, "archived");
        assertSamePropertyValue(report, dto, "onHold");
        assertSamePropertyValue(report, dto, "inProgress");
        assertSamePropertyValue(report, dto, "reason");
        assertSamePropertyValue(report, dto, "action");
        assertSamePropertyValue(report, dto, "approvalDuration");
        assertSamePropertyValue(report, dto, "totalApprovalDuration");
        assertSamePropertyValue(report, dto, "createdBy");

        Object expectedAutoMatch = mapper.mapAutoMatch(report);
        assertEquals(expectedAutoMatch, getProperty(dto, "isAutoMatch"));
    }

    @Test
    void reportToGenericResponseDTO_shouldHandleNullOptionalFields() throws Exception {
        ResponseReport report = new ResponseReport();

        setProperty(report, "usedCount", 7);
        setProperty(report, "added", 1);
        setProperty(report, "changed", 2);
        setProperty(report, "archived", 3);
        setProperty(report, "onHold", 4);
        setProperty(report, "inProgress", 5);

        GenericResponseDTO dto = mapper.reportToGenericResponseDTO(report);

        assertNotNull(dto);
        assertNull(getProperty(dto, "usedDate"));
        assertNull(getProperty(dto, "organizationName"));
        assertNull(getProperty(dto, "hon"));
        assertNull(getProperty(dto, "address"));
        assertNull(getProperty(dto, "verificationValidationDate"));
        assertNull(getProperty(dto, "organizationType"));
        assertNull(getProperty(dto, "origin"));
        assertNull(getProperty(dto, "approvalStatus"));
        assertNull(getProperty(dto, "approvedBy"));
        assertEquals(7, getProperty(dto, "usedCount"));
        assertNull(getProperty(dto, "operatorName"));
        assertNull(getProperty(dto, "researcherName"));
        assertEquals(1, getProperty(dto, "added"));
        assertEquals(2, getProperty(dto, "changed"));
        assertEquals(3, getProperty(dto, "archived"));
        assertEquals(4, getProperty(dto, "onHold"));
        assertEquals(5, getProperty(dto, "inProgress"));
        assertNull(getProperty(dto, "reason"));
        assertNull(getProperty(dto, "action"));
        assertNull(getProperty(dto, "approvalDuration"));
        assertNull(getProperty(dto, "totalApprovalDuration"));
        assertNull(getProperty(dto, "createdBy"));

        Object expectedAutoMatch = mapper.mapAutoMatch(report);
        assertEquals(expectedAutoMatch, getProperty(dto, "isAutoMatch"));
    }

    @Test
    void toDTOList_shouldReturnNull_whenInputIsNull() {
        assertNull(mapper.toDTOList(null));
    }

    @Test
    void toDTOList_shouldMapList() throws Exception {
        ResponseReport report1 = new ResponseReport();
        ResponseReport report2 = new ResponseReport();
        populateBean(report1);
        populateBean(report2);

        List<GenericResponseDTO> result = mapper.toDTOList(List.of(report1, report2));

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(getProperty(report1, "hon"), getProperty(result.get(0), "hon"));
        assertEquals(getProperty(report2, "hon"), getProperty(result.get(1), "hon"));
    }

    // ---------------- helper methods ----------------

    private void assertSamePropertyValue(Object source, Object target, String property) throws Exception {
        assertEquals(getProperty(source, property), getProperty(target, property), "Mismatch for property: " + property);
    }

    private Object getProperty(Object bean, String propertyName) throws Exception {
        for (PropertyDescriptor pd : Introspector.getBeanInfo(bean.getClass()).getPropertyDescriptors()) {
            if (pd.getName().equals(propertyName) && pd.getReadMethod() != null) {
                Method readMethod = pd.getReadMethod();
                readMethod.setAccessible(true);
                return readMethod.invoke(bean);
            }
        }
        fail("Getter not found for property: " + propertyName + " in class " + bean.getClass().getName());
        return null;
    }

    private void setProperty(Object bean, String propertyName, Object value) throws Exception {
        for (PropertyDescriptor pd : Introspector.getBeanInfo(bean.getClass()).getPropertyDescriptors()) {
            if (pd.getName().equals(propertyName) && pd.getWriteMethod() != null) {
                Method writeMethod = pd.getWriteMethod();
                writeMethod.setAccessible(true);
                writeMethod.invoke(bean, value);
                return;
            }
        }
        fail("Setter not found for property: " + propertyName + " in class " + bean.getClass().getName());
    }

    private void populateBean(Object bean) throws Exception {
        for (PropertyDescriptor pd : Introspector.getBeanInfo(bean.getClass()).getPropertyDescriptors()) {
            if ("class".equals(pd.getName()) || pd.getWriteMethod() == null) {
                continue;
            }

            Class<?> type = pd.getPropertyType();
            Object sampleValue = sampleValue(type, pd.getName());
            if (sampleValue != null) {
                Method writeMethod = pd.getWriteMethod();
                writeMethod.setAccessible(true);
                writeMethod.invoke(bean, sampleValue);
            }
        }
    }

    private Object sampleValue(Class<?> type, String fieldName) {
        try {
            if (type == String.class) {
                return fieldName + "_value";
            }
            if (type == Integer.class || type == int.class) {
                return 10;
            }
            if (type == Long.class || type == long.class) {
                return 20L;
            }
            if (type == Boolean.class || type == boolean.class) {
                return Boolean.TRUE;
            }
            if (type == Double.class || type == double.class) {
                return 12.5d;
            }
            if (type == Float.class || type == float.class) {
                return 5.5f;
            }
            if (type == Short.class || type == short.class) {
                return (short) 2;
            }
            if (type == Byte.class || type == byte.class) {
                return (byte) 1;
            }
            if (type == BigDecimal.class) {
                return BigDecimal.valueOf(99);
            }
            if (type == Date.class) {
                return new Date();
            }
            if (type == LocalDate.class) {
                return LocalDate.now();
            }
            if (type == LocalDateTime.class) {
                return LocalDateTime.now();
            }
            if (type == Instant.class) {
                return Instant.now();
            }
            if (type == OffsetDateTime.class) {
                return OffsetDateTime.now();
            }
            if (type == ZonedDateTime.class) {
                return ZonedDateTime.now();
            }
            if (List.class.isAssignableFrom(type)) {
                return new ArrayList<>();
            }
            if (type.isEnum()) {
                Object[] constants = type.getEnumConstants();
                return constants.length > 0 ? constants[0] : null;
            }

            Constructor<?> constructor = type.getDeclaredConstructor();
            constructor.setAccessible(true);
            Object instance = constructor.newInstance();

            return instance;
        } catch (Exception e) {
            return null;
        }
    }
}