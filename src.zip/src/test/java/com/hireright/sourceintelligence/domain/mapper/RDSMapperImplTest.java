package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.rds.VendorsDTO;
import com.hireright.sourceintelligence.domain.entity.Vendors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class RDSMapperImplTest {

    private RDSMapperImpl mapper;

    @BeforeEach
    void setUp() {
        mapper = new RDSMapperImpl();
    }

    @Test
    void entityToVendorsDTO_shouldReturnNull_whenEntityIsNull() {
        assertNull(mapper.entityToVendorsDTO(null));
    }

    @Test
    void entityToVendorsDTO_shouldMapAllFields_whenEntityHasValues() throws Exception {
        Vendors entity = new Vendors();

        entity.setProviderId(101);
        entity.setVendor("Vendor A");
        entity.setWebsite("https://vendor-a.com");

        Object organizationTypeValue = buildNonNullOrganizationTypeValue(entity);
        setField(entity, "organizationType", organizationTypeValue);

        VendorsDTO result = mapper.entityToVendorsDTO(entity);

        assertNotNull(result);
        assertEquals(101, result.getProviderId());
        assertEquals("Vendor A", result.getVendor());
        assertEquals("https://vendor-a.com", result.getWebsite());
        assertEquals(organizationTypeValue, result.getOrganizationType());
    }

    @Test
    void entityToVendorsDTO_shouldSkipNullableFields_whenValuesAreNull() {
        Vendors entity = new Vendors();
        entity.setProviderId(202);

        VendorsDTO result = mapper.entityToVendorsDTO(entity);

        assertNotNull(result);
        assertEquals(202, result.getProviderId());
        assertNull(result.getVendor());
        assertNull(result.getWebsite());
        assertNull(result.getOrganizationType());
    }

    @Test
    void toVendorsDTOList_shouldReturnNull_whenEntityListIsNull() {
        assertNull(mapper.toVendorsDTOList(null));
    }

    @Test
    void toVendorsDTOList_shouldReturnEmptyList_whenEntityListIsEmpty() {
        List<VendorsDTO> result = mapper.toVendorsDTOList(Collections.emptyList());

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void toVendorsDTOList_shouldMapAllItems() throws Exception {
        Vendors first = new Vendors();
        first.setProviderId(1);
        first.setVendor("Vendor One");
        first.setWebsite("https://one.com");
        Object firstOrgType = buildNonNullOrganizationTypeValue(first);
        setField(first, "organizationType", firstOrgType);

        Vendors second = new Vendors();
        second.setProviderId(2);
        // keep vendor and website null to cover false branches during list mapping too

        List<VendorsDTO> result = mapper.toVendorsDTOList(Arrays.asList(first, second));

        assertNotNull(result);
        assertEquals(2, result.size());

        assertEquals(1, result.get(0).getProviderId());
        assertEquals("Vendor One", result.get(0).getVendor());
        assertEquals("https://one.com", result.get(0).getWebsite());
        assertEquals(firstOrgType, result.get(0).getOrganizationType());

        assertEquals(2, result.get(1).getProviderId());
        assertNull(result.get(1).getVendor());
        assertNull(result.get(1).getWebsite());
        assertNull(result.get(1).getOrganizationType());
    }

    /**
     * Creates a non-null value for the entity.organizationType field without needing
     * to know at test-writing time whether it is a String, enum, or some other type.
     */
    private Object buildNonNullOrganizationTypeValue(Vendors entity) throws Exception {
        Field field = findField(entity.getClass(), "organizationType");
        Class<?> type = field.getType();

        if (type == String.class) {
            return "TYPE_A";
        }
        if (type.isEnum()) {
            Object[] constants = type.getEnumConstants();
            if (constants != null && constants.length > 0) {
                return constants[0];
            }
        }

        throw new IllegalStateException("Unsupported organizationType field type: " + type.getName());
    }

    private void setField(Object target, String fieldName, Object value) throws Exception {
        Field field = findField(target.getClass(), fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    private Field findField(Class<?> type, String fieldName) throws NoSuchFieldException {
        Class<?> current = type;
        while (current != null) {
            try {
                return current.getDeclaredField(fieldName);
            } catch (NoSuchFieldException ignored) {
                current = current.getSuperclass();
            }
        }
        throw new NoSuchFieldException(fieldName);
    }
}