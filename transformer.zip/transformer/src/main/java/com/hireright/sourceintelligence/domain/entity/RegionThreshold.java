package com.hireright.sourceintelligence.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Document(collection = "region_threshold")
public class RegionThreshold {

    @Id
    private String id;
    private int AMERICAS;
    private int US;
    private int INDIA;
    private int EMEA;
    private int LATAM;
    private int CANADA;
    private int APAC;
    private int AUSTRALIA;
    private String thresholdType;
}
