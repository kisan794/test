package org.example.recombointegration.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

/**
 * MongoDB configuration.
 * Enables MongoDB repositories for form field configuration management.
 *
 * @author Generated
 * @version 1.0
 */
@Configuration
@EnableMongoRepositories(basePackages = "org.example.recombointegration.repository")
public class MongoConfig {
    // MongoDB configuration is handled by Spring Boot auto-configuration
    // This class just enables MongoDB repositories
}

