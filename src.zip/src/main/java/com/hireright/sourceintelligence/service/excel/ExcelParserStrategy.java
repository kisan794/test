package com.hireright.sourceintelligence.service.excel;

import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface ExcelParserStrategy<T> {

    List<T> parse(MultipartFile file) throws IOException;

    String getParserType();

    ExcelColumnMapping getColumnMapping();

    ExcelRowMapper<T> getRowMapper();
}