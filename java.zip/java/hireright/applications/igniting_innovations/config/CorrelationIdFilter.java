package hireright.applications.igniting_innovations.config;

import hireright.applications.igniting_innovations.util.CorrelationIdHolder;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * Servlet filter that manages correlation IDs for HTTP requests.
 * <p>
 * This filter:
 * 1. Extracts correlation ID from incoming request header (X-Correlation-ID)
 * 2. Generates a new correlation ID if not present
 * 3. Sets the correlation ID in MDC for logging
 * 4. Adds the correlation ID to the response header
 * 5. Cleans up MDC after request processing
 * <p>
 * The filter runs with highest priority (Order 1) to ensure correlation ID
 * is available for all subsequent filters and request processing.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
@Component
@Order(1)
public class CorrelationIdFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        try {
            String correlationId = httpRequest.getHeader(CorrelationIdHolder.CORRELATION_ID_HEADER);

            if (correlationId == null || correlationId.isEmpty()) {
                correlationId = CorrelationIdHolder.generate();
                log.debug("Generated new correlation ID: {}", correlationId);
            } else {
                CorrelationIdHolder.set(correlationId);
                log.debug("Using existing correlation ID from request: {}", correlationId);
            }

            httpResponse.setHeader(CorrelationIdHolder.CORRELATION_ID_HEADER, correlationId);

            chain.doFilter(request, response);

        } finally {
            CorrelationIdHolder.clear();
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        log.info("CorrelationIdFilter initialized");
    }

    @Override
    public void destroy() {
        log.info("CorrelationIdFilter destroyed");
    }
}

