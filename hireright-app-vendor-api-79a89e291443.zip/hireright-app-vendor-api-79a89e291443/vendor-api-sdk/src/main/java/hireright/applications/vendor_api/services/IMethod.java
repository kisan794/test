package hireright.applications.vendor_api.services;
/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	2017-08-16	Created
 *	M.Kuznetsov	2025-10-29	HRG-345322. Openjdk21-migration
 */

import org.springframework.web.bind.annotation.RequestMethod;

public interface IMethod {
    String getPath();

    RequestMethod getRequestMethod();

    Class<?> getRequestBodyClass();

    Class<?> getResponseBodyClass();

    boolean isValidRequest(Object request);
}
