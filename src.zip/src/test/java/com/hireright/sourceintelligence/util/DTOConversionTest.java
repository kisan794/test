package com.hireright.sourceintelligence.util;

import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.api.v2.dto.SourceDTO;
import com.hireright.sourceintelligence.domain.mapper.SourceV2Mapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DTOConversionTest {

    @Mock
    private SourceV2Mapper sourceV2Mapper;

    @InjectMocks
    private DTOConversion dtoConversion;

    @Test
    void convertV2DtoToV1Dto_shouldReturnMappedDto_whenPayloadIsNull() {
        SourceDTO sourceDTO = new SourceDTO();
        SourceOrganizationDTO mappedDto = new SourceOrganizationDTO();
        mappedDto.setPayload(null);

        when(sourceV2Mapper.sourceDTOtoSourceOrganizationDTO(sourceDTO)).thenReturn(mappedDto);

        SourceOrganizationDTO result = dtoConversion.convertV2DtoToV1Dto(sourceDTO);

        assertNotNull(result);
        assertNull(result.getPayload());
        assertNull(result.getCity());
        assertNull(result.getState());
        assertNull(result.getCountry());
    }

    @Test
    void convertV2DtoToV1Dto_shouldWrapAddionalInfoAndSetAddressFields_whenPresent() {
        JSONObject sourcePayload = new JSONObject();
        sourcePayload.put("addionalInfo", new JSONObject().put("releaseType", "Econsent"));

        JSONArray addressArray = new JSONArray();
        JSONObject addressObj = new JSONObject();
        addressObj.put("city", "Chicago");
        addressObj.put("state", "Illinois");
        addressObj.put("countryCode", "USA");
        addressArray.put(addressObj);
        sourcePayload.put("address", addressArray);

        SourceDTO sourceDTO = new SourceDTO();
        sourceDTO.setPayload(sourcePayload);

        SourceOrganizationDTO mappedDto = new SourceOrganizationDTO();
        mappedDto.setPayload(new JSONObject());

        when(sourceV2Mapper.sourceDTOtoSourceOrganizationDTO(sourceDTO)).thenReturn(mappedDto);

        SourceOrganizationDTO result = dtoConversion.convertV2DtoToV1Dto(sourceDTO);

        assertNotNull(result);
        assertNotNull(result.getPayload());

        JSONArray addionalInfoArray = result.getPayload().getJSONArray("addionalInfo");
        assertEquals(1, addionalInfoArray.length());
        assertEquals("Econsent",
                addionalInfoArray.getJSONObject(0).getString("releaseType"));

        assertEquals("Chicago", result.getCity());
        assertEquals("Illinois", result.getState());
        assertEquals("USA", result.getCountry());
    }

    @Test
    void convertV2DtoToV1Dto_shouldNotSetCityStateCountry_whenAddressFieldsMissing() {
        JSONObject sourcePayload = new JSONObject();
        sourcePayload.put("addionalInfo", new JSONObject().put("releaseType", "Not Needed"));

        JSONArray addressArray = new JSONArray();
        JSONObject addressObj = new JSONObject();
        addressArray.put(addressObj);
        sourcePayload.put("address", addressArray);

        SourceDTO sourceDTO = new SourceDTO();
        sourceDTO.setPayload(sourcePayload);

        SourceOrganizationDTO mappedDto = new SourceOrganizationDTO();
        mappedDto.setPayload(new JSONObject());

        when(sourceV2Mapper.sourceDTOtoSourceOrganizationDTO(sourceDTO)).thenReturn(mappedDto);

        SourceOrganizationDTO result = dtoConversion.convertV2DtoToV1Dto(sourceDTO);

        assertNotNull(result);
        assertNotNull(result.getPayload());
        assertTrue(result.getPayload().has("addionalInfo"));

        assertNull(result.getCity());
        assertNull(result.getState());
        assertNull(result.getCountry());
    }

    @Test
    void convertV2DtoToV1Dto_shouldAlsoHandleEmptyCityAndStateValues() {
        JSONObject sourcePayload = new JSONObject();
        sourcePayload.put("addionalInfo", new JSONObject().put("releaseType", "Mouse Only"));

        JSONArray addressArray = new JSONArray();
        JSONObject addressObj = new JSONObject();
        addressObj.put("city", "");
        addressObj.put("state", "");
        addressObj.put("countryCode", "US");
        addressArray.put(addressObj);
        sourcePayload.put("address", addressArray);

        SourceDTO sourceDTO = new SourceDTO();
        sourceDTO.setPayload(sourcePayload);

        SourceOrganizationDTO mappedDto = new SourceOrganizationDTO();
        mappedDto.setPayload(new JSONObject());

        when(sourceV2Mapper.sourceDTOtoSourceOrganizationDTO(sourceDTO)).thenReturn(mappedDto);

        SourceOrganizationDTO result = dtoConversion.convertV2DtoToV1Dto(sourceDTO);

        assertEquals("", result.getCity());
        assertEquals("", result.getState());
        assertEquals("US", result.getCountry());
    }

    @Test
    void convertV1DtoToV2Dto_shouldUnwrapFirstAddionalInfoElement() {
        JSONObject payload = new JSONObject();
        JSONArray addionalInfoArray = new JSONArray();
        JSONObject addionalInfo = new JSONObject();
        addionalInfo.put("releaseType", "Hand Signed");
        addionalInfoArray.put(addionalInfo);
        payload.put("addionalInfo", addionalInfoArray);

        SourceDTO mappedDto = new SourceDTO();
        mappedDto.setPayload(payload);

        SourceOrganizationDTO sourceOrganizationDTO = new SourceOrganizationDTO();

        when(sourceV2Mapper.sourceOrganizationDTOtoSourceDTO(sourceOrganizationDTO)).thenReturn(mappedDto);

        SourceDTO result = dtoConversion.convertV1DtoToV2Dto(sourceOrganizationDTO);

        assertNotNull(result);
        assertNotNull(result.getPayload());
        assertTrue(result.getPayload().get("addionalInfo") instanceof JSONObject);
        assertEquals("Hand Signed",
                result.getPayload().getJSONObject("addionalInfo").getString("releaseType"));
    }

    @Test
    void convertV1ListToV2List_shouldConvertAndUnwrapPayload_whenPayloadIsPresent() {
        SourceOrganizationDTO sourceOrganizationDTO = new SourceOrganizationDTO();

        JSONObject payload = new JSONObject();
        JSONArray addionalInfoArray = new JSONArray();
        JSONObject addionalInfo = new JSONObject();
        addionalInfo.put("releaseType", "Source Specific");
        addionalInfoArray.put(addionalInfo);
        payload.put("addionalInfo", addionalInfoArray);

        SourceDTO sourceDTO = new SourceDTO();
        sourceDTO.setPayload(payload);

        when(sourceV2Mapper.toSourceDTOList(List.of(sourceOrganizationDTO)))
                .thenReturn(List.of(sourceDTO));

        List<SourceDTO> result = dtoConversion.convertV1ListToV2List(List.of(sourceOrganizationDTO));

        assertNotNull(result);
        assertEquals(1, result.size());
        assertTrue(result.get(0).getPayload().get("addionalInfo") instanceof JSONObject);
        assertEquals("Source Specific",
                result.get(0).getPayload().getJSONObject("addionalInfo").getString("releaseType"));
    }

    @Test
    void convertV1ListToV2List_shouldKeepItemUnchanged_whenPayloadIsNull() {
        SourceOrganizationDTO sourceOrganizationDTO = new SourceOrganizationDTO();

        SourceDTO sourceDTO = new SourceDTO();
        sourceDTO.setPayload(null);

        when(sourceV2Mapper.toSourceDTOList(List.of(sourceOrganizationDTO)))
                .thenReturn(List.of(sourceDTO));

        List<SourceDTO> result = dtoConversion.convertV1ListToV2List(List.of(sourceOrganizationDTO));

        assertNotNull(result);
        assertEquals(1, result.size());
        assertNull(result.get(0).getPayload());
    }

    @Test
    void convertV1ListToV2List_shouldReturnEmptyList_whenInputListIsEmpty() {
        when(sourceV2Mapper.toSourceDTOList(Collections.emptyList()))
                .thenReturn(Collections.emptyList());

        List<SourceDTO> result = dtoConversion.convertV1ListToV2List(Collections.emptyList());

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
}