package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.CycleResult;
import com.hireright.sourceintelligence.service.impl.MongoSourceService;
import com.hireright.sourceintelligence.service.impl.UserCycleEvaluator;
import com.hireright.sourceintelligence.service.impl.helperservices.SourceUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.lang.reflect.Field;

import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.PENDING_APPROVAL;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.SAVE_PENDING_APPROVAL;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SourceUtilsTest {

    @Mock
    private MongoSourceService mongoSourceService;

    @Mock
    private UserCycleEvaluator evaluator;

    @InjectMocks
    private SourceUtils sourceUtils;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);

        Field field = SourceUtils.class.getDeclaredField("approvalWorkFlowDisabled");
        field.setAccessible(true);
        field.set(sourceUtils, false);
    }
    @Test
    void checkForAutoApproval_workflowDisabled_shouldReturnNull_andNotCallDependencies() throws Exception {
        Field field = SourceUtils.class.getDeclaredField("approvalWorkFlowDisabled");
        field.setAccessible(true);
        field.set(sourceUtils, true);

        CycleResult result = sourceUtils.checkForAutoApproval(70, "Asia", "lazy");

        assertNull(result);
        verifyNoInteractions(mongoSourceService);
        verifyNoInteractions(evaluator);
    }

    @Test
    void checkForAutoApproval_workflowEnabled_shouldFetchThreshold_andCallEvaluator() {
        when(mongoSourceService.getThresholdForRegion("Asia")).thenReturn(60);

        CycleResult expected = mock(CycleResult.class);
        when(evaluator.processRequest("lazy", "Asia", 70, 60)).thenReturn(expected);

        CycleResult result = sourceUtils.checkForAutoApproval(70, "Asia", "lazy");

        assertSame(expected, result);
        verify(mongoSourceService).getThresholdForRegion("Asia");
        verify(evaluator).processRequest("lazy", "Asia", 70, 60);
        verifyNoMoreInteractions(mongoSourceService, evaluator);
    }

    @Test
    void testIsEligibleForAutoApproval_workflowDisabled_shouldReturnTrue() throws Exception {
        Field field = SourceUtils.class.getDeclaredField("approvalWorkFlowDisabled");
        field.setAccessible(true);
        field.set(sourceUtils, true);

        boolean result = sourceUtils.isEligibleForAutoApproval(10, "Asia");
        assertTrue(result);
    }

    @Test
    void testIsEligibleForAutoApproval_userScoreAboveThreshold_shouldReturnTrue() {
        when(mongoSourceService.getThresholdForRegion("Asia")).thenReturn(60);

        boolean result = sourceUtils.isEligibleForAutoApproval(70, "Asia");

        assertTrue(result);
        verify(mongoSourceService).getThresholdForRegion("Asia");
    }

    @Test
    void testIsEligibleForAutoApproval_userScoreBelowThreshold_shouldReturnFalse() {
        when(mongoSourceService.getThresholdForRegion("Europe")).thenReturn(80);

        boolean result = sourceUtils.isEligibleForAutoApproval(60, "Europe");

        assertFalse(result);
    }

    @Test
    void testIsPendingOrSavePendingApproval_shouldReturnTrueForPending() {
        boolean result = sourceUtils.isPendingOrSavePendingApproval(PENDING_APPROVAL.getStatus());
        assertTrue(result);
    }

    @Test
    void testIsPendingOrSavePendingApproval_shouldReturnTrueForSavePending() {
        boolean result = sourceUtils.isPendingOrSavePendingApproval(SAVE_PENDING_APPROVAL.getStatus());
        assertTrue(result);
    }

    @Test
    void testIsPendingOrSavePendingApproval_shouldReturnFalseForOtherStatus() {
        boolean result = sourceUtils.isPendingOrSavePendingApproval("APPROVED");
        assertFalse(result);
    }
}
