package org.example.recombointegration.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.recombointegration.repository.FormTemplateRepository;
import org.example.recombointegration.service.DynamicFormService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration class to initialize default form templates on application startup.
 * This ensures that the Idea Submission form configuration is available when the application starts.
 *
 * @author Generated
 * @version 1.0
 */
@Slf4j
@Configuration
@RequiredArgsConstructor
public class FormInitializationConfig {

    private final DynamicFormService dynamicFormService;
    private final FormTemplateRepository formTemplateRepository;

    /**
     * Initialize default form templates on application startup.
     * Only initializes if the form doesn't already exist.
     */
    @Bean
    public CommandLineRunner initializeFormTemplates() {
        return args -> {
            log.info("Checking if default form templates need to be initialized...");
            
            // Check if Idea Submission form already exists
            if (!formTemplateRepository.existsByFormId("idea-submission-form")) {
                log.info("Idea Submission form not found. Initializing default configuration...");
                dynamicFormService.initializeIdeaSubmissionForm();
                log.info("Idea Submission form initialized successfully");
            } else {
                log.info("Idea Submission form already exists. Skipping initialization.");
            }
        };
    }
}

