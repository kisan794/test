package com.hireright.sourceintelligence.service.notification.impl;

import com.hireright.sourceintelligence.api.dto.notification.DataExtractionNotificationDTO;
import com.hireright.sourceintelligence.api.dto.notification.EmailNotificationDTO;
import com.hireright.sourceintelligence.api.dto.notification.NotificationResponseDTO;
import com.hireright.sourceintelligence.service.notification.DataExtractionNotificationService;
import com.hireright.sourceintelligence.service.notification.EmailNotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * Implementation of DataExtractionNotificationService
 * Following Single Responsibility Principle - handles data extraction notification logic
 * Following Composition over Inheritance - uses EmailNotificationService
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DataExtractionNotificationServiceImpl implements DataExtractionNotificationService {
    
    private final EmailNotificationService emailNotificationService;
    
    @Value("${notification.dataextraction.subject:Data Extraction Completed}")
    private String defaultSubject;
    
    @Override
    public NotificationResponseDTO sendDataExtractionNotification(DataExtractionNotificationDTO notification) {
        log.info("Sending data extraction notification for type: {}, filename: {}", 
                notification.getDataExtractionType(), notification.getFilename());
        
        try {
            EmailNotificationDTO emailNotification = buildEmailNotification(notification);
            String notificationId = emailNotificationService.sendEmail(emailNotification);
            
            return NotificationResponseDTO.success(notificationId, UUID.randomUUID().toString(), 
                    notification.getRecipients().size());
                    
        } catch (Exception e) {
            log.error("Failed to send data extraction notification: {}", e.getMessage(), e);
            return NotificationResponseDTO.failure(UUID.randomUUID().toString(), e.getMessage());
        }
    }
    
    private EmailNotificationDTO buildEmailNotification(DataExtractionNotificationDTO notification) {
        String subject = String.format("%s - %s", defaultSubject, notification.getDataExtractionType());
        String body = buildEmailBody(notification);
        
        return EmailNotificationDTO.builder()
                .to(notification.getRecipients())
                .subject(subject)
                .body(body)
                .htmlContent(true)
                .build();
    }
    
    private String buildEmailBody(DataExtractionNotificationDTO notification) {
        StringBuilder body = new StringBuilder();
        body.append("<html><body>");
        body.append("<h2>Data Extraction Completed</h2>");
        body.append("<p>The data extraction process has been completed with the following results:</p>");
        body.append("<table border='1' cellpadding='10' cellspacing='0' style='border-collapse: collapse;'>");
        body.append("<tr><th align='left'>Property</th><th align='left'>Value</th></tr>");
        
        body.append("<tr><td>Extraction Type</td><td>").append(notification.getDataExtractionType()).append("</td></tr>");
        
        if (notification.getFilename() != null) {
            body.append("<tr><td>Filename</td><td>").append(notification.getFilename()).append("</td></tr>");
        }
        
        if (notification.getTotalRecords() != null) {
            body.append("<tr><td>Total Records</td><td>").append(notification.getTotalRecords()).append("</td></tr>");
        }
        
        if (notification.getTotalSourcesUpdated() != null) {
            body.append("<tr><td>Sources Updated</td><td>").append(notification.getTotalSourcesUpdated()).append("</td></tr>");
        }
        
        if (notification.getNotFoundRecords() != null) {
            body.append("<tr><td>Not Found Records</td><td>").append(notification.getNotFoundRecords()).append("</td></tr>");
        }
        
        if (notification.getProcessingTimeMs() != null) {
            body.append("<tr><td>Processing Time</td><td>").append(notification.getProcessingTimeMs()).append(" ms</td></tr>");
        }
        
        body.append("</table>");
        body.append("<br/>");
        body.append("<p>This is an automated notification from the Source Intelligence Data Extraction Service.</p>");
        body.append("</body></html>");
        
        return body.toString();
    }
}

