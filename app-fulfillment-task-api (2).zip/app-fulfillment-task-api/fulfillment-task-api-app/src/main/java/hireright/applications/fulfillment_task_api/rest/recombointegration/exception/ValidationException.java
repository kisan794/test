/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.exception;


import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.ValidationDetail;
import lombok.Getter;

import java.util.List;

/**
 * Exception thrown when request validation fails.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Getter
public class ValidationException extends RuntimeException {

	private final String requestId;
	private final transient List<ValidationDetail> details;

	public ValidationException(String message, String requestId, List<ValidationDetail> details) {
		super(message);
		this.requestId = requestId;
		this.details = details;
	}

}
