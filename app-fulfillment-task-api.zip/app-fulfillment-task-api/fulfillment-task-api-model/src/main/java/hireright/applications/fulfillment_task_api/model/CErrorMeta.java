package hireright.applications.fulfillment_task_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-13  HRG-332327 initial version
 */

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.Objects;

public class CErrorMeta implements Serializable {
    @JsonProperty ("path")
    private String m_sPath;

    @JsonProperty ("id")
    private String m_sID;

    @JsonProperty ("details")
    private String m_sDetails;

    private CErrorMeta() {
    }

    private CErrorMeta(Builder builder) {
        this.m_sPath = builder.m_sPath;
        this.m_sID = builder.m_sID;
        this.m_sDetails = builder.m_sDetails;
    }

    public String getPath() {
        return this.m_sPath;
    }

    public String getID() {
        return this.m_sID;
    }

    public String getDetails() {
        return this.m_sDetails;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CErrorMeta that = (CErrorMeta) o;

        if (!Objects.equals(this.m_sPath, that.m_sPath)) {
            return false;
        }
        if (!Objects.equals(this.m_sID, that.m_sID)) {
            return false;
        }
        return Objects.equals(this.m_sDetails, that.m_sDetails);
    }

    @Override
    public int hashCode() {
        int result = this.m_sPath != null ? this.m_sPath.hashCode() : 0;
        result = 31 * result + (this.m_sID != null ? this.m_sID.hashCode() : 0);
        result = 31 * result + (this.m_sDetails != null ? this.m_sDetails.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "CErrorMeta{" + "m_sPath='" + this.m_sPath + '\'' + ", m_sID='" + this.m_sID + '\'' + ", m_sDetails='" +
                this.m_sDetails + '\'' + '}';
    }

    public static final class Builder {
        private String m_sPath;
        private String m_sID;
        private String m_sDetails;

        public Builder() {
        }

        public Builder(CErrorMeta copy) {
            this.m_sPath = copy.getPath();
            this.m_sID = copy.getID();
            this.m_sDetails = copy.getDetails();
        }

        public Builder path(String sPath) {
            this.m_sPath = sPath;
            return this;
        }

        public Builder id(String sID) {
            this.m_sID = sID;
            return this;
        }

        public Builder details(String sDetails) {
            this.m_sDetails = sDetails;
            return this;
        }

        public CErrorMeta build() {
            return new CErrorMeta(this);
        }
    }
}
