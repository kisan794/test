package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.reports.api.ReportsApiController;
import com.hireright.sourceintelligence.reports.dto.ReportResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;
import com.hireright.sourceintelligence.reports.service.ReportService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReportApiControllerTest {

    @Mock
    private ReportService reportService;

    @InjectMocks
    private ReportsApiController reportsApiController;

    @Test
    void getDeletedSourceReport_shouldReturnOkResponseWithBodyAndHeaders() {
        ReportsRequestDTO request = new ReportsRequestDTO();
        ReportResponseDTO responseDTO = new ReportResponseDTO();

        when(reportService.deleteReport(request)).thenReturn(responseDTO);

        ResponseEntity<ReportResponseDTO> response =
                reportsApiController.getDeletedSourceReport(request);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(responseDTO, response.getBody());
        assertNotNull(response.getHeaders());
        assertEquals(new HttpHeaders(), response.getHeaders());

        verify(reportService).deleteReport(request);
        verifyNoMoreInteractions(reportService);
    }

    @Test
    void getDeletedSourceReport_shouldHandleNullResponse() {
        ReportsRequestDTO request = new ReportsRequestDTO();

        when(reportService.deleteReport(request)).thenReturn(null);

        ResponseEntity<ReportResponseDTO> response =
                reportsApiController.getDeletedSourceReport(request);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody());
        assertTrue(response.getHeaders().isEmpty());

        verify(reportService).deleteReport(request);
        verifyNoMoreInteractions(reportService);
    }
}