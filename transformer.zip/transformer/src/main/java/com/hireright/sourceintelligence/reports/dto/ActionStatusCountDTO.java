package com.hireright.sourceintelligence.reports.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ActionStatusCountDTO {
    
    @JsonProperty("new")
    private int newCount;
    
    @JsonProperty("inProgress")
    private int inProgress;
    
    @JsonProperty("onHold")
    private int onHold;
    
    @JsonProperty("cancelled")
    private int cancelled;
    
    @JsonProperty("completed")
    private int completed;
    
    @JsonProperty("total")
    private int total;
}

