package com.hireright.sourceintelligence.service.impl;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.ACTION_SAVE;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.ADDRESS;
import static com.hireright.sourceintelligence.constants.ErrorConstants.HON_MISSING_IN_REQUEST;
import static com.hireright.sourceintelligence.constants.ErrorConstants.INACTIVE_SOURCE;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowInvalidRequest;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.service.AddressService;
import com.hireright.sourceintelligence.service.SearchService;
import com.hireright.sourceintelligence.service.SourceService;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Slf4j
@Transactional
@Service
@RequiredArgsConstructor
public class AddressServiceImpl implements AddressService {

    private final SourceService sourceService;
    private final SearchService searchService;

    @Override
    public void updateAddress(AddressDTO addressDTO, UserInfo userInfo) {

        if (StringUtils.isEmpty(addressDTO.getHon())) {
            logAndThrowInvalidRequest(HON_MISSING_IN_REQUEST, null);
        }
        String msg = "UpdateAddress received HON: " + addressDTO.getHon();
        SourceOrganizationDTO sourceDto = sourceService.getSourceByHon(addressDTO.getHon());
        if (sourceDto.getStatus() != SourceOrganizationStatus.ACTIVE) {
            logAndThrowInvalidRequest(INACTIVE_SOURCE, null, msg);
        }
        sourceDto.getPayload().put(ADDRESS, addressDTO.getAddress().toList().toArray());
        UIActionsDTO uiActionsDTO = new UIActionsDTO();
        uiActionsDTO.setUserAction(ACTION_SAVE);
        sourceService.updateSource(sourceDto,uiActionsDTO);
    }

    @Override
    public SearchResponseDTO getAddressListByHon(SearchDTO searchDTO) {
        return searchService.getSourceOrganizationAddressByHon(searchDTO);
    }
}
