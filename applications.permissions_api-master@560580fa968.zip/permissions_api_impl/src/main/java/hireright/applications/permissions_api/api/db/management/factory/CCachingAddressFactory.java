package hireright.applications.permissions_api.api.db.management.factory;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-02-05  HRG-330191 initial version
 */

import hireright.objects.address.CAddress;
import hireright.sdk.db2.CSessionFactory;
import hireright.sdk.db3.DB;
import hireright.sdkex.as_cache.CCache;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class CCachingAddressFactory
{
	private static final CCache<CAddress> CACHE = new CCache<>(CAddress.class);

	public static CAddress getAddress(Long nAddressId)
	{
		if(nAddressId == null)
		{
			return null;
		}

		try
		{
			return CACHE.get(nAddressId, () -> getAddressNoCache(nAddressId));
		}
		catch(Exception ignored)
		{
			return getAddressNoCache(nAddressId);
		}
	}

	private static CAddress getAddressNoCache(Long nAddressId)
	{
		if (nAddressId == null)
		{
			return null;
		}

		return (CAddress) CSessionFactory
			.getSessionFactory()
			.getCurrentSession()
			.get(CAddress.class, nAddressId);
	}

	@SuppressWarnings("unchecked")
	public static Collection<CAddress> getAddresses(Collection<Long> ids)
	{
		if(ids == null || ids.isEmpty())
		{
			return Collections.emptyList();
		}

		Collection<CAddress> records = new ArrayList<>(ids.size());

		ids = new ArrayList<>(ids);

		for(Long nID : new ArrayList<>(ids))
		{
			CAddress record = null;

			try
			{
				record = CACHE.get(nID.toString(), () -> null);
			}
			catch(Exception ignored)
			{
			}

			if(record != null)
			{
				records.add(record);
				ids.remove(nID);
			}
		}

		if(!ids.isEmpty())
		{
			Criteria query = DB.session().createCriteria(CAddress.class);
			query.add(Restrictions.in("ID", ids));

			Collection<CAddress> dbRecords = query.list();

			for(CAddress record : dbRecords)
			{
				records.add(record);

				try
				{
					CACHE.put(record.getID().toString(), record);
				}
				catch(Exception ignored)
				{
				}
			}
		}

		return records;
	}
}
