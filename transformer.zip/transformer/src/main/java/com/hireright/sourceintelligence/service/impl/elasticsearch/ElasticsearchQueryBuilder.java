package com.hireright.sourceintelligence.service.impl.elasticsearch;


import co.elastic.clients.elasticsearch._types.FieldValue;
import co.elastic.clients.elasticsearch._types.query_dsl.*;
import com.hireright.sourceintelligence.api.dto.AutoMatchDTO;
import com.hireright.sourceintelligence.api.dto.ElasticsearchDTO;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

import static com.hireright.sourceintelligence.service.impl.SearchConstants.PayloadFields.CITY_CONSTANT;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.PayloadFields.STATE_CONSTANT;
import static com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchConstants.EsFields.*;
import static com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchConstants.Regions.NON_US;
import static com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchConstants.Regions.US;
import static com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchConstants.SearchFields.*;

public class ElasticsearchQueryBuilder {

    private ElasticsearchQueryBuilder() {
        throw new IllegalStateException("Query Builder class");
    }


    protected static void address(ElasticsearchDTO elasticsearchDTO, List<Query> mustQueries) {
        if (!StringUtils.isEmpty(elasticsearchDTO.getCountry())) {
            mustQueries.add(TermQuery.of(m -> m.field(COUNTRY).value(elasticsearchDTO.getCountry().trim()))._toQuery());
        }
        if (!StringUtils.isEmpty(elasticsearchDTO.getState())) {
            mustQueries.add(TermQuery.of(m -> m.field(STATE).value(elasticsearchDTO.getState().trim()))._toQuery());
        }
        if (!StringUtils.isEmpty(elasticsearchDTO.getCity())) {
            mustQueries.add(TermQuery.of(m -> m.field(CITY).value(elasticsearchDTO.getCity().trim().toLowerCase()))._toQuery());
        }
        if (!StringUtils.isEmpty(elasticsearchDTO.getPostalCode())) {
            mustQueries.add(TermQuery.of(m -> m.field(POSTAL_CODE).value(elasticsearchDTO.getPostalCode().trim()))._toQuery());
        }

    }

    protected static void contacts(ElasticsearchDTO elasticsearchDTO, List<Query> mustQueries) {
        if (!StringUtils.isEmpty(elasticsearchDTO.getAutomatedService())) {
            mustQueries.add(TermQuery.of(m -> m.field(AUTOMATED_SERVICE).value(elasticsearchDTO.getAutomatedService().trim()))._toQuery());
            if (!StringUtils.isEmpty(elasticsearchDTO.getCode())) {
                mustQueries.add(TermQuery.of(m -> m.field(CODE).value(elasticsearchDTO.getCode().trim()))._toQuery());
            }
        }

        if (!StringUtils.isEmpty(elasticsearchDTO.getEmail())) {
            mustQueries.add(TermQuery.of(m -> m.field(EMAIL).value(elasticsearchDTO.getEmail().trim()))._toQuery());
        }
        if (!StringUtils.isEmpty(elasticsearchDTO.getPhoneNumber())) {
            mustQueries.add(TermQuery.of(m -> m.field(PHONE_NUMBER).value(elasticsearchDTO.getPhoneNumber().trim()))._toQuery());
        }
        if (!StringUtils.isEmpty(elasticsearchDTO.getFaxNumber())) {
            mustQueries.add(TermQuery.of(m -> m.field(FAX_NUMBER).value(elasticsearchDTO.getFaxNumber().trim()))._toQuery());
        }
    }

    protected static Query smartSearchQuery(ElasticsearchDTO elasticsearchDTO, Boolean isDropDownSelected) {

        List<Query> mustQueries = mustQueriesForSmartSearch(elasticsearchDTO);
        List<Query> shouldQueries;
        if (Boolean.TRUE.equals(isDropDownSelected)) {
            shouldQueries = shouldQueriesForDropDownSearch(elasticsearchDTO.getOrganizationName());
        } else {
            shouldQueries = shouldQueriesForTextBox(elasticsearchDTO.getOrganizationName());
        }

        List<Query> finalShouldQueries = shouldQueries;
        if (mustQueries.isEmpty() && shouldQueries.isEmpty()) {
            return null;
        } else if (!mustQueries.isEmpty() && finalShouldQueries.isEmpty()) {
            return Query.of(q -> q
                    .bool(b -> b
                            .must(mustQueries)
                    )
            );
        } else if (mustQueries.isEmpty() && !finalShouldQueries.isEmpty()) {
            return Query.of(q -> q
                    .bool(b -> b
                            .should(finalShouldQueries)
                            .minimumShouldMatch("1")
                    )
            );
        } else {
            return Query.of(q -> q
                    .bool(b -> b
                            .must(mustQueries)
                            .should(finalShouldQueries)
                            .minimumShouldMatch("1")
                    )
            );
        }
    }

    protected static List<Query> shouldQueriesForTextBox(String organizationName) {
        List<Query> queries = new ArrayList<>();
        if (!StringUtils.isEmpty(organizationName)) {
            queries.add(MatchQuery.of(m -> m.field(ORG_NAME_EXACT).query(organizationName.trim()).boost(75F))._toQuery());
            queries.add(MatchQuery.of(m -> m.field(ORG_ALIAS_EXACT).query(organizationName.trim()).boost(75F))._toQuery());

            queries.add(MatchQuery.of(m -> m.field(ORG_NAME_FUZZY).query(organizationName.trim()).boost(2F).fuzziness("1").operator(Operator.And))._toQuery());
            queries.add(MatchQuery.of(m -> m.field(ORG_ALIAS_FUZZY).query(organizationName.trim()).boost(1F).fuzziness("1").operator(Operator.And))._toQuery());
        }
        return queries;
    }

    protected static List<Query> shouldQueriesForDropDownSearch(String organizationName) {
        List<Query> queries = new ArrayList<>();
        if (!StringUtils.isEmpty(organizationName)) {
            queries.add(MatchQuery.of(m -> m.field(ORG_NAME_EXACT).query(organizationName.trim()))._toQuery());
            queries.add(MatchQuery.of(m -> m.field(ORG_ALIAS_EXACT).query(organizationName.trim()))._toQuery());

        }
        return queries;
    }

    private static List<Query> mustQueriesForDropDown() {
        List<Query> mustQueries = new ArrayList<>();
        mustQueries.add(TermQuery.of(m -> m.field(APPROVAL_STATUS).value(ApprovalStatus.APPROVED.getStatus()))._toQuery());
        return mustQueries;
    }

    protected static List<Query> shouldQueriesForDropDown(String organizationName) {
        List<Query> queries = new ArrayList<>();
        if (!StringUtils.isEmpty(organizationName)) {
            queries.add(MatchQuery.of(m -> m.field(ORG_NAME_EXACT).query(organizationName.trim()).boost(10F))._toQuery());
            queries.add(MatchQuery.of(m -> m.field(ORG_ALIAS_EXACT).query(organizationName.trim()).boost(10F))._toQuery());

            queries.add(MatchQuery.of(m -> m.field(ORG_NAME_AUTOCOMPLETE).query(organizationName.trim()).operator(Operator.And).boost(3F))._toQuery());
            queries.add(MatchQuery.of(m -> m.field(ORG_ALIAS_AUTOCOMPLETE).query(organizationName.trim()).operator(Operator.And).boost(1F))._toQuery());

        }
        return queries;
    }

    protected static Query dropDownSearchQuery(ElasticsearchDTO elasticsearchDTO) {

        List<Query> mustQueries = mustQueriesForDropDown();
        List<Query> shouldQueries = shouldQueriesForDropDown(elasticsearchDTO.getOrganizationName());

        return Query.of(q -> q
                .bool(b -> b
                        .filter(mustQueries)
                        .should(shouldQueries)
                        .minimumShouldMatch("1")
                )
        );
    }

    protected static Query autoMatchQuery(AutoMatchDTO autoMatchDTO) {

        List<Query> mustQueries = mustQueries(autoMatchDTO, US);
        List<Query> shouldQueries = shouldQueriesForUS(autoMatchDTO);

        return Query.of(q -> q
                .bool(b -> b
                        .must(mustQueries)
                        .should(shouldQueries)
                        .minimumShouldMatch("1")
                )
        );
    }

    private static List<Query> mustQueriesForSmartSearch(ElasticsearchDTO elasticsearchDTO) {
        List<Query> mustQueries = new ArrayList<>();

        if (!StringUtils.isEmpty(elasticsearchDTO.getDepartment())) {
            mustQueries.add(MatchPhraseQuery.of(m -> m.field(DEPARTMENT).query(elasticsearchDTO.getDepartment()))._toQuery());
        }
        if (!StringUtils.isEmpty(elasticsearchDTO.getAddressLine())) {
            mustQueries.add(MatchPhraseQuery.of(m -> m.field(ADDRESS_LINE).query(elasticsearchDTO.getAddressLine()))._toQuery());
        }
        if (!StringUtils.isEmpty(elasticsearchDTO.getWebsite())) {
            mustQueries.add(TermQuery.of(m -> m.field(WEBSITE).value(elasticsearchDTO.getWebsite().trim().toLowerCase()))._toQuery());
        }
        if (!StringUtils.isEmpty(elasticsearchDTO.getStatus())) {
            mustQueries.add(TermQuery.of(m -> m.field(STATUS).value(elasticsearchDTO.getStatus()))._toQuery());
        }
        if (!StringUtils.isEmpty(elasticsearchDTO.getApprovalStatus())) {
            mustQueries.add(TermQuery.of(m -> m.field(APPROVAL_STATUS).value(elasticsearchDTO.getApprovalStatus()))._toQuery());
        }
        if (!StringUtils.isEmpty(elasticsearchDTO.getCountry()) || !StringUtils.isEmpty(elasticsearchDTO.getState()) || !StringUtils.isEmpty(elasticsearchDTO.getCity()) || !StringUtils.isEmpty(elasticsearchDTO.getPostalCode())) {
            address(elasticsearchDTO, mustQueries);
        }
        if (!StringUtils.isEmpty(elasticsearchDTO.getAutomatedService()) || !StringUtils.isEmpty(elasticsearchDTO.getPhoneNumber()) || !StringUtils.isEmpty(elasticsearchDTO.getFaxNumber()) || !StringUtils.isEmpty(elasticsearchDTO.getEmail())) {
            contacts(elasticsearchDTO, mustQueries);
        }
        return mustQueries;
    }

    private static List<Query> mustQueries(AutoMatchDTO autoMatchDTO, String region) {
        List<Query> mustQueries = new ArrayList<>();
        if (!StringUtils.isEmpty(autoMatchDTO.getCountry())) {
            mustQueries.add(TermQuery.of(m -> m.field(COUNTRY).value(autoMatchDTO.getCountry().trim()))._toQuery());
        }
        String sourceType = autoMatchDTO.getSourceType();
        boolean isUSEducation = US.equalsIgnoreCase(region) && OrganizationType.EDUCATION.getType().equals(sourceType);
        boolean isEMEAEducationOrEmployment = NON_US.equalsIgnoreCase(region)
                && (OrganizationType.EDUCATION.getType().equals(sourceType) || OrganizationType.EMPLOYMENT.getType().equals(sourceType));

        if (isUSEducation) {
            if (!StringUtils.isEmpty(autoMatchDTO.getState())) {
                FieldValue fv = new FieldValue.Builder().stringValue(autoMatchDTO.getState().trim()).build();
                FieldValue fv2 = new FieldValue.Builder().stringValue(STATE_CONSTANT).build();
                mustQueries.add(TermsQuery.of(t -> t.field(STATE).terms(v -> v.value(List.of(
                        fv, fv2))))._toQuery());
            }
            if (!StringUtils.isEmpty(autoMatchDTO.getCity()) && !autoMatchDTO.getCity().equalsIgnoreCase(CITY_CONSTANT)) {
                FieldValue fv = new FieldValue.Builder().stringValue(autoMatchDTO.getCity().trim().toLowerCase()).build();
                FieldValue fv2 = new FieldValue.Builder().stringValue(CITY_CONSTANT.toLowerCase()).build();
                mustQueries.add(TermsQuery.of(t -> t.field(CITY).terms(v -> v.value(List.of(
                        fv, fv2))))._toQuery());
            }
        } else if (isEMEAEducationOrEmployment) {
            if (!StringUtils.isEmpty(autoMatchDTO.getCity()) && !autoMatchDTO.getCity().equalsIgnoreCase(CITY_CONSTANT)) {
                FieldValue fv = new FieldValue.Builder().stringValue(autoMatchDTO.getCity().trim().toLowerCase()).build();
                FieldValue fv2 = new FieldValue.Builder().stringValue(CITY_CONSTANT.toLowerCase()).build();
                mustQueries.add(TermsQuery.of(t -> t.field(CITY).terms(v -> v.value(List.of(
                        fv, fv2))))._toQuery());
            }
        }
        mustQueries.add(TermQuery.of(m -> m.field(STATUS).value(SourceOrganizationStatus.ACTIVE.getStatus()))._toQuery());
        mustQueries.add(TermQuery.of(m -> m.field(APPROVAL_STATUS).value(ApprovalStatus.APPROVED.getStatus()))._toQuery());
        return mustQueries;
    }

    private static List<Query> shouldQueriesForNonUS(AutoMatchDTO autoMatchDTO) {
        return getQueriesForNonUS(autoMatchDTO);
    }

    @NotNull
    private static List<Query> getQueries(AutoMatchDTO autoMatchDTO, String region) {
        List<Query> shouldQueries = new ArrayList<>();
        if (!StringUtils.isEmpty(autoMatchDTO.getSourceName())) {
            shouldQueries.add(MatchPhraseQuery.of(m -> m.field(ORG_NAME).query(autoMatchDTO.getSourceName().trim()).slop(2).boost(5F))._toQuery());
            shouldQueries.add(MatchPhraseQuery.of(m -> m.field(ORG_ALIAS).query(autoMatchDTO.getSourceName().trim()).slop(2).boost(5F))._toQuery());
        }
        if (region.equals(US) && !StringUtils.isEmpty(autoMatchDTO.getSourceName())) {
            shouldQueries.add(MatchQuery.of(m -> m.field(ORG_NAME).query(autoMatchDTO.getSourceName().trim()).operator(Operator.And).fuzziness("1").maxExpansions(50).boost(3F))._toQuery());
            shouldQueries.add(MatchQuery.of(m -> m.field(ORG_ALIAS).query(autoMatchDTO.getSourceName().trim()).operator(Operator.And).fuzziness("1").maxExpansions(50).boost(3F))._toQuery());
        }
        return shouldQueries;
    }

    @NotNull
    private static List<Query> getQueriesForNonUS(AutoMatchDTO autoMatchDTO) {
        List<Query> shouldQueries = new ArrayList<>();
        if (!StringUtils.isEmpty(autoMatchDTO.getSourceName())) {
            shouldQueries.add(MatchPhraseQuery.of(m -> m.field(ORG_NAME_EXACT).query(autoMatchDTO.getSourceName().trim()).slop(2).boost(25F))._toQuery());
            shouldQueries.add(MatchPhraseQuery.of(m -> m.field(ORG_ALIAS_EXACT).query(autoMatchDTO.getSourceName().trim()).slop(2).boost(1F))._toQuery());
        }
        return shouldQueries;
    }

    @NotNull
    private static List<Query> getQueriesForUS(AutoMatchDTO autoMatchDTO) {
        List<Query> shouldQueries = new ArrayList<>();
        if (!StringUtils.isEmpty(autoMatchDTO.getSourceName())) {
            shouldQueries.add(MatchPhraseQuery.of(m -> m.field(ORG_NAME_FUZZY).query(autoMatchDTO.getSourceName().trim()).slop(2).boost(5F))._toQuery());
            shouldQueries.add(MatchPhraseQuery.of(m -> m.field(ORG_ALIAS_FUZZY).query(autoMatchDTO.getSourceName().trim()).slop(2).boost(5F))._toQuery());

            shouldQueries.add(MatchQuery.of(m -> m.field(ORG_NAME_FUZZY).query(autoMatchDTO.getSourceName().trim()).operator(Operator.And).fuzziness("1").maxExpansions(50).boost(3F))._toQuery());
            shouldQueries.add(MatchQuery.of(m -> m.field(ORG_ALIAS_FUZZY).query(autoMatchDTO.getSourceName().trim()).operator(Operator.And).fuzziness("1").maxExpansions(50).boost(3F))._toQuery());
        }
        return shouldQueries;
    }

    private static List<Query> shouldQueriesForUS(AutoMatchDTO autoMatchDTO) {
        return getQueriesForUS(autoMatchDTO);
    }

    private static void shouldQueriesForSmartSearch(ElasticsearchDTO elasticsearchDTO, List<Query> shouldQueries) {
        getQueriesForSmartSearch(elasticsearchDTO, shouldQueries);
    }

    private static void getQueriesForSmartSearch(ElasticsearchDTO elasticsearchDTO, List<Query> shouldQueries) {
        if (!StringUtils.isEmpty(elasticsearchDTO.getDepartment())) {
            shouldQueries.add(MatchQuery.of(m -> m.field(DEPARTMENT).query(elasticsearchDTO.getDepartment()).fuzziness("2").operator(Operator.And))._toQuery());
        }
        if (!StringUtils.isEmpty(elasticsearchDTO.getAddressLine())) {
            shouldQueries.add(MatchQuery.of(m -> m.field(ADDRESS_LINE).query(elasticsearchDTO.getAddressLine()).fuzziness("2").operator(Operator.And))._toQuery());
        }
    }

    protected static Query nonUSAutoMatchQuery(AutoMatchDTO autoMatchDTO) {

        List<Query> mustQueries = mustQueries(autoMatchDTO, NON_US);
        List<Query> shouldQueries = shouldQueriesForNonUS(autoMatchDTO);

        return Query.of(q -> q
                .bool(b -> b
                        .filter(mustQueries)
                        .should(shouldQueries)
                        .minimumShouldMatch("1")
                )
        );
    }

}
