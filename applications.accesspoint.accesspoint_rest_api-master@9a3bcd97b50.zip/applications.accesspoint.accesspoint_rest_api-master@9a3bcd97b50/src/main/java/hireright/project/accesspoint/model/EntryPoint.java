/*
 * @(#)$RCSfilev$ $Revision: 1.2 $ $Date: 2014/07/28 14:48:44 $ $Author: aputintsev $
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/resources/src/main/java/hireright/project/accesspoint/model/EntryPoint.java,v $
 *
 * Copyright 2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	J.Burlakova		2012-05-14	Created
 *	S.Sablin		2017-10-26 	Added addParameter method.
 */
package hireright.project.accesspoint.model;

import hireright.applications.accesspoint.types.CParameterBean;
import hireright.applications.accesspoint.types.CParametersListWrapper;
import hireright.objects.utilities.CEntryPoint;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Jekaterina Burlakova
 */
@XmlRootElement(name = "EntryPoint")
public class EntryPoint implements Serializable 
{
	private static final long serialVersionUID = 1L;
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: aputintsev $";

	private String authenticationMode;

	private String login;

	private Integer expirationTime;

	private String userId;

	private String userClass;

	private String entryPointType;

	private Integer designNr;

	private String domainId;

	private Integer entriesAllowed;

	private Integer failuresAllowed;

	private String createSession;

	private String redirectUrl;

	private List<CParameterBean> parameters;

	public EntryPoint() {}

	public EntryPoint(CEntryPoint entryPoint)
	{
		this.authenticationMode = entryPoint.getAuthenticationMode();
		this.redirectUrl = entryPoint.getRedirectURL().replaceAll( "%KEY%", entryPoint.getKey() );
		this.designNr = entryPoint.getDesignNr();
		this.domainId = entryPoint.getDomainID();
		this.userClass = entryPoint.getUserClass();
		this.userId = entryPoint.getUserID();

		this.parameters = CParametersListWrapper.createParameters(entryPoint.getMultiProperties());
	}

	@XmlElement(name = "AuthenticationMode")
	public String getAuthenticationMode()
	{
		return authenticationMode;
	}

	public void setAuthenticationMode( String authenticationMode )
	{
		this.authenticationMode = authenticationMode;
	}

	@XmlElement(name = "Login")
	public String getLogin()
	{
		return login;
	}

	public void setLogin( String login )
	{
		this.login = login;
	}

	@XmlElement(name = "ExpirationTime")
	public Integer getExpirationTime()
	{
		return expirationTime;
	}

	public void setExpirationTime( Integer expirationTime )
	{
		this.expirationTime = expirationTime;
	}

	@XmlElement(name = "UserId")
	public String getUserId()
	{
		return userId;
	}

	public void setUserId( String userId )
	{
		this.userId = userId;
	}

	@XmlElement(name = "UserClass")
	public String getUserClass()
	{
		return userClass;
	}

	public void setUserClass( String userClass )
	{
		this.userClass = userClass;
	}

	@XmlElement(name = "EntryPointType")
	public String getEntryPointType()
	{
		return entryPointType;
	}

	public void setEntryPointType( String entryPointType )
	{
		this.entryPointType = entryPointType;
	}

	@XmlElement(name = "DesignNr")
	public Integer getDesignNr()
	{
		return designNr;
	}

	public void setDesignNr( Integer designNr )
	{
		this.designNr = designNr;
	}

	@XmlElement(name = "DomainId")
	public String getDomainId()
	{
		return domainId;
	}

	public void setDomainId( String domainId )
	{
		this.domainId = domainId;
	}

	@XmlElement(name = "EntriesAllowed")
	public Integer getEntriesAllowed()
	{
		return entriesAllowed;
	}

	public void setEntriesAllowed( Integer entriesAllowed )
	{
		this.entriesAllowed = entriesAllowed;
	}

	@XmlElement(name = "FailuresAllowed")
	public Integer getFailuresAllowed()
	{
		return failuresAllowed;
	}

	public void setFailuresAllowed( Integer failuresAllowed )
	{
		this.failuresAllowed = failuresAllowed;
	}

	@XmlElement(name = "CreateSession")
	public String getCreateSession()
	{
		return createSession;
	}

	public void setCreateSession( String createSession )
	{
		this.createSession = createSession;
	}

	@XmlElement(name = "RedirectUrl")
	public String getRedirectUrl()
	{
		return redirectUrl;
	}

	public void setRedirectUrl( String redirectUrl )
	{
		this.redirectUrl = redirectUrl;
	}

	@XmlElementWrapper(name = "ParametersList")
	@XmlElement(name = "Parameter")
	public List<CParameterBean> getParameters()
	{
		return parameters;
	}

	public void setParameters( List<CParameterBean> parameters )
	{
		this.parameters = parameters;
	}
	
	public EntryPoint addParameter( String name, String value )
	{
		if( this.parameters == null )
			this.parameters = new ArrayList<CParameterBean>();
		
		CParameterBean paramBeam = new CParameterBean();
		paramBeam.setName( name );
		paramBeam.setValue( value );
		parameters.add( paramBeam );
		
		return this;
	}
	
	public CParameterBean getParameter(String sParameterName)
	{
		if (parameters != null)
		{
			for (CParameterBean parameter : parameters)
			{
				if (parameter.getName().equals(sParameterName))
				{
					return parameter;
				}
			}
		}
		
		return null;
	}
	
	public void addParameter( CParameterBean parameter )
	{
		if( this.parameters == null )
			this.parameters = new ArrayList<CParameterBean>();
			
		parameters.add( parameter );
	}
}
