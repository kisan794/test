package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.DataExtractionResponseDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH;

/**
 * API interface for data extraction operations.
 * Uses a strategy pattern to support multiple extraction types (e.g., Parchment etc.).
 */
@RequestMapping(value = BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + "/extraction")
@Tag(name = "Data Extraction", description = "Endpoints for extracting data from Excel files to database")
public interface DataExtractionApi {

    @Operation(
            summary = "Upload Excel file for data extraction",
            description = "Upload an Excel file data extract into the database. " +
                         "Specify the extraction type parameter (e.g., 'parchment') to route to the appropriate processor. " +
                         "The system will parse the Excel file and update source organizations accordingly.",
            responses = {
                    @ApiResponse(
                            description = "File processed successfully",
                            responseCode = "200",
                            content = @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = DataExtractionResponseDTO.class)
                            )
                    ),
                    @ApiResponse(
                            description = "Invalid file format, empty file, or unsupported extract type",
                            responseCode = "400",
                            content = @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = Map.class)
                            )
                    ),
                    @ApiResponse(
                            description = "Internal server error",
                            responseCode = "500",
                            content = @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = Map.class)
                            )
                    )
            }
    )
    @ResponseStatus(HttpStatus.OK)
    @PostMapping(
            value = "/upload",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    ResponseEntity<DataExtractionResponseDTO> uploadDataExtractionExcelFile(
            @RequestParam("file") @NotNull MultipartFile file,
            @RequestParam(value = "type", defaultValue = "parchment") String dataExtractionType
    );

}