package org.hireright;

import org.hireright.config.MongoDBConfig;
import org.hireright.service.EducationSourceMigrationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.core.MongoTemplate;

@SpringBootApplication
public class Main {
    private static final Logger logger = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) {
        SpringApplication.run(Main.class, args);
    }

    @Bean
    public CommandLineRunner run(MongoDBConfig mongoDBConfig,
                                  @Qualifier("devMongoTemplate") MongoTemplate devMongoTemplate,
                                  @Qualifier("testMongoTemplate") MongoTemplate testMongoTemplate) {
        return args -> {
            try {
                EducationSourceMigrationService migrationService =
                        new EducationSourceMigrationService(mongoDBConfig, devMongoTemplate, testMongoTemplate);

                logger.info("========================================");
                logger.info("Phase 1: Migration by HON");
                logger.info("========================================");
                long startTime1 = System.currentTimeMillis();

                migrationService.migrateByHon();

                long endTime1 = System.currentTimeMillis();
                long duration1 = (endTime1 - startTime1) / 1000;

                logger.info("Phase 1 completed in {} seconds", duration1);

                logger.info("========================================");
                logger.info("Phase 2: Migration by 8 Parameters");
                logger.info("========================================");
                long startTime2 = System.currentTimeMillis();

                migrationService.migrateBy8Params();

                long endTime2 = System.currentTimeMillis();
                long duration2 = (endTime2 - startTime2) / 1000;

                logger.info("Phase 2 completed in {} seconds", duration2);

                logger.info("========================================");
                logger.info("Migration completed successfully!");
                logger.info("Total time: {} seconds", duration1 + duration2);
                logger.info("========================================");

            } catch (Exception e) {
                logger.error("Migration failed with error", e);
                System.exit(1);
            }
        };
    }
}
