package com.hireright.sourceintelligence.util;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.*;

public class ObjectDiff {

    private ObjectDiff() {
        throw new IllegalStateException("ObjectDiff class");
    }

    private static final Set<String> SKIP_FIELDS = Set.of("createdDate", "lastModifiedDate", "createdBy",
            "creatorId", "action", "tempVersion", "version", "logFlag", "approvalStatus", "status",
            "assignedTo", "assignedId", "payload.usedCount", "payload.lastUsedDateTime");

    public static List<String> findChangedFields(Object obj1, Object obj2) {
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> map1 = mapper.convertValue(obj1, Map.class);
        Map<String, Object> map2 = mapper.convertValue(obj2, Map.class);

        List<String> changedFields = new ArrayList<>();
        for (String key : map1.keySet()) {
            if (SKIP_FIELDS.contains(key)) {
                continue; // Skip fields
            }
            Object val1 = map1.get(key);
            Object val2 = map2.get(key);
            if (!Objects.equals(val1, val2)) {
                changedFields.add(key);
            }
        }
        return changedFields;
    }


}
