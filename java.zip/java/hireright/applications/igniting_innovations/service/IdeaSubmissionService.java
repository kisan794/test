package hireright.applications.igniting_innovations.service;

import hireright.applications.igniting_innovations.document.IdeaSubmission;
import hireright.applications.igniting_innovations.dto.IdeaSubmissionRequest;
import hireright.applications.igniting_innovations.dto.IdeaSubmissionResponse;
import hireright.applications.igniting_innovations.exception.ResourceNotFoundException;
import hireright.applications.igniting_innovations.repository.IdeaSubmissionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class IdeaSubmissionService {

    private final IdeaSubmissionRepository ideaSubmissionRepository;

    public IdeaSubmissionResponse createIdea(IdeaSubmissionRequest request) {
        log.info("Creating new idea submission: {}", request.getFormData().getTitle());

        LocalDateTime now = LocalDateTime.now();

        IdeaSubmission idea = IdeaSubmission.builder()
                .title(request.getFormData().getTitle())
                .submittedBy(request.getFormData().getSubmittedBy())
                .emailAddress(request.getEmailAddress())
                .name(request.getName())
                .submissionDate(now)
                .description(request.getFormData().getDescription())
                .objective(request.getFormData().getObjective())
                .impactAreas(request.getFormData().getImpactAreas())
                .improvementTypes(request.getFormData().getImprovementTypes())
                .improvementTypeOther(request.getFormData().getImprovementTypeOther())
                .expectedBenefit(request.getFormData().getExpectedBenefit())
                .impactCategories(request.getFormData().getImpactCategories())
                .impactCategoryOther(request.getFormData().getImpactCategoryOther())
                .implementationComplexity(request.getFormData().getImplementationComplexity())
                .suggestedSteps(request.getFormData().getSuggestedSteps())
                .timelineType(request.getFormData().getTimelineType())
                .supportingDocuments(request.getFormData().getSupportingDocuments())
                .additionalComments(request.getFormData().getAdditionalComments())
                .status(request.getStatus())
                .createdAt(now)
                .updatedAt(now)
                .build();

        IdeaSubmission savedIdea = ideaSubmissionRepository.save(idea);
        log.info("Idea submission created successfully with ID: {}", savedIdea.getId());

        return mapToResponse(savedIdea);
    }

    public IdeaSubmissionResponse getIdeaById(String id) {
        log.info("Fetching idea with ID: {}", id);
        IdeaSubmission idea = ideaSubmissionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Idea not found with ID: " + id));
        return mapToResponse(idea);
    }

    public Page<IdeaSubmissionResponse> getAllIdeas(Pageable pageable) {
        log.info("Fetching all ideas with pagination");
        return ideaSubmissionRepository.findAll(pageable)
                .map(this::mapToResponse);
    }

    public void deleteIdea(String id) {
        log.info("Deleting idea with ID: {}", id);
        if (!ideaSubmissionRepository.existsById(id)) {
            throw new ResourceNotFoundException("Idea not found with ID: " + id);
        }
        ideaSubmissionRepository.deleteById(id);
        log.info("Idea deleted successfully");
    }

    public Page<IdeaSubmissionResponse> getIdeasByEmailAddressLastThreeMonths(String emailAddress, Pageable pageable) {
        log.info("Fetching ideas for email: {} modified in last 3 months", emailAddress);
        LocalDateTime threeMonthsAgo = LocalDateTime.now().minusMonths(3);
        return ideaSubmissionRepository.findByEmailAddressAndUpdatedAtAfter(emailAddress, threeMonthsAgo, pageable)
                .map(this::mapToResponse);
    }

    public IdeaSubmissionResponse updateIdea(String id, IdeaSubmissionRequest request) {
        log.info("Updating idea submission with ID: {}", id);

        // Check if idea exists
        IdeaSubmission existingIdea = ideaSubmissionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Idea not found with ID: " + id));

        // Update all fields from request
        existingIdea.setTitle(request.getFormData().getTitle());
        existingIdea.setSubmittedBy(request.getFormData().getSubmittedBy());
        existingIdea.setEmailAddress(request.getEmailAddress());
        existingIdea.setName(request.getName());
        existingIdea.setDescription(request.getFormData().getDescription());
        existingIdea.setObjective(request.getFormData().getObjective());
        existingIdea.setImpactAreas(request.getFormData().getImpactAreas());
        existingIdea.setImprovementTypes(request.getFormData().getImprovementTypes());
        existingIdea.setImprovementTypeOther(request.getFormData().getImprovementTypeOther());
        existingIdea.setExpectedBenefit(request.getFormData().getExpectedBenefit());
        existingIdea.setImpactCategories(request.getFormData().getImpactCategories());
        existingIdea.setImpactCategoryOther(request.getFormData().getImpactCategoryOther());
        existingIdea.setImplementationComplexity(request.getFormData().getImplementationComplexity());
        existingIdea.setSuggestedSteps(request.getFormData().getSuggestedSteps());
        existingIdea.setTimelineType(request.getFormData().getTimelineType());
        existingIdea.setSupportingDocuments(request.getFormData().getSupportingDocuments());
        existingIdea.setAdditionalComments(request.getFormData().getAdditionalComments());
        existingIdea.setStatus(request.getStatus());
        existingIdea.setUpdatedAt(LocalDateTime.now());

        IdeaSubmission updatedIdea = ideaSubmissionRepository.save(existingIdea);
        log.info("Idea submission updated successfully with ID: {}", updatedIdea.getId());

        return mapToResponse(updatedIdea);
    }

    private IdeaSubmissionResponse mapToResponse(IdeaSubmission idea) {
        return IdeaSubmissionResponse.builder()
                .id(idea.getId())
                .title(idea.getTitle())
                .submittedBy(idea.getSubmittedBy())
                .emailAddress(idea.getEmailAddress())
                .name(idea.getName())
                .submissionDate(idea.getSubmissionDate())
                .description(idea.getDescription())
                .objective(idea.getObjective())
                .impactAreas(idea.getImpactAreas())
                .improvementTypes(idea.getImprovementTypes())
                .improvementTypeOther(idea.getImprovementTypeOther())
                .expectedBenefit(idea.getExpectedBenefit())
                .impactCategories(idea.getImpactCategories())
                .impactCategoryOther(idea.getImpactCategoryOther())
                .implementationComplexity(idea.getImplementationComplexity())
                .suggestedSteps(idea.getSuggestedSteps())
                .timelineType(idea.getTimelineType())
                .supportingDocuments(idea.getSupportingDocuments())
                .additionalComments(idea.getAdditionalComments())
                .status(idea.getStatus())
                .createdAt(idea.getCreatedAt())
                .updatedAt(idea.getUpdatedAt())
                .build();
    }
    
}

