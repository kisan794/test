package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.api.dto.history.ChangeLogResponse;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;

import jakarta.validation.constraints.NotNull;
import java.util.List;

public interface SourceHistoryService {


	SourceOrganizationDTO getSourceByHonAndVersion(@NotNull String hon, @NotNull Double version);

	//TODO - Revisit after approval mechanism[Dont touch till approval process]
	List<SourceOrganizationDTO> getSourcesByHonAndApprovalStatusAndVersionLessThanOrderByVersionDesc(String hon, ApprovalStatus approvalStatus, Double version);

	//Modified - need to verify on the status checking in history
	List<SourceOrganizationDTO> getSourcesForDiff(String hon, Double version, String sourceType);

	//TODO - Revisit after approval mechanism[Dont touch till approval process]
	List<SourceOrganizationDTO> getSourcesByHonAndApprovalStatusOrderByVersionDesc(String hon, ApprovalStatus approvalStatus);

	ChangeLogResponse getChangeLogByHon(String hon, ApprovalStatus approvalStatus);



}
