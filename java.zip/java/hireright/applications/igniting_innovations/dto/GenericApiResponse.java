package hireright.applications.igniting_innovations.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

/**
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Generic API response")
public class GenericApiResponse {

    @Schema(description = "Response timestamp")
    @JsonProperty("timestamp")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    private OffsetDateTime timestamp;

    @Schema(description = "HTTP status code")
    @JsonProperty("statusCode")
    private Integer statusCode;

    @Schema(description = "status")
    @JsonProperty("status")
    private String status;

    @Schema(description = "Response message")
    @JsonProperty("message")
    private String message;

    public static GenericApiResponse success(Integer statusCode) {
        return GenericApiResponse.builder()
                .timestamp(OffsetDateTime.now())
                .statusCode(statusCode)
                .status("SUCCESS")
                .build();
    }

    public static GenericApiResponse created() {
        return success(201);
    }

}

