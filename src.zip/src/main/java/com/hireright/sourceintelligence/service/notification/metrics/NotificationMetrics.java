package com.hireright.sourceintelligence.service.notification.metrics;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.ConcurrentHashMap;
import java.time.LocalDateTime;
import java.util.Map;

/**
 * Metrics collector for notification system.
 * Tracks success/failure rates, circuit breaker state, and DLQ size.
 * 
 * This provides in-memory metrics that can be exposed via Spring Actuator
 * or integrated with monitoring systems (Prometheus, Datadog, etc.)
 */
@Slf4j
@Component
public class NotificationMetrics {
    
    private final AtomicLong totalNotificationsSent = new AtomicLong(0);
    private final AtomicLong totalNotificationsFailed = new AtomicLong(0);
    private final AtomicLong totalValidationErrors = new AtomicLong(0);
    private final AtomicLong totalCircuitBreakerOpen = new AtomicLong(0);
    private final AtomicLong totalDLQEntries = new AtomicLong(0);
    private final AtomicLong totalAsyncNotifications = new AtomicLong(0);
    private final AtomicLong totalSyncNotifications = new AtomicLong(0);
    
    private final Map<String, NotificationTypeMetrics> metricsByType = new ConcurrentHashMap<>();
    private volatile LocalDateTime lastResetTime = LocalDateTime.now();
    
    /**
     * Records a successful notification
     */
    public void recordSuccess(String notificationType, boolean isAsync) {
        totalNotificationsSent.incrementAndGet();
        
        if (isAsync) {
            totalAsyncNotifications.incrementAndGet();
        } else {
            totalSyncNotifications.incrementAndGet();
        }
        
        getOrCreateTypeMetrics(notificationType).successCount.incrementAndGet();
        
        log.debug("Notification success recorded - type: {}, async: {}", notificationType, isAsync);
    }
    
    /**
     * Records a failed notification
     */
    public void recordFailure(String notificationType, String errorCode) {
        totalNotificationsFailed.incrementAndGet();
        getOrCreateTypeMetrics(notificationType).failureCount.incrementAndGet();
        getOrCreateTypeMetrics(notificationType).errorCounts.merge(errorCode, 1L, Long::sum);
        
        log.debug("Notification failure recorded - type: {}, errorCode: {}", notificationType, errorCode);
    }
    
    /**
     * Records a validation error
     */
    public void recordValidationError(String notificationType, String field) {
        totalValidationErrors.incrementAndGet();
        getOrCreateTypeMetrics(notificationType).validationErrors.incrementAndGet();
        
        log.debug("Validation error recorded - type: {}, field: {}", notificationType, field);
    }
    
    /**
     * Records circuit breaker open event
     */
    public void recordCircuitBreakerOpen() {
        totalCircuitBreakerOpen.incrementAndGet();
        log.warn("Circuit breaker open event recorded - total: {}", totalCircuitBreakerOpen.get());
    }
    
    /**
     * Records DLQ entry
     */
    public void recordDLQEntry() {
        totalDLQEntries.incrementAndGet();
        log.debug("DLQ entry recorded - total: {}", totalDLQEntries.get());
    }
    
    /**
     * Records DLQ processing (retry)
     */
    public void recordDLQRetry(boolean success) {
        if (success) {
            log.debug("DLQ retry successful");
        } else {
            log.debug("DLQ retry failed");
        }
    }
    
    /**
     * Gets success rate as percentage
     */
    public double getSuccessRate() {
        long total = totalNotificationsSent.get() + totalNotificationsFailed.get();
        if (total == 0) {
            return 100.0;
        }
        return (totalNotificationsSent.get() * 100.0) / total;
    }
    
    /**
     * Gets failure rate as percentage
     */
    public double getFailureRate() {
        return 100.0 - getSuccessRate();
    }
    
    /**
     * Gets total notifications processed
     */
    public long getTotalNotifications() {
        return totalNotificationsSent.get() + totalNotificationsFailed.get();
    }
    
    /**
     * Gets metrics summary as a map
     */
    public Map<String, Object> getMetricsSummary() {
        Map<String, Object> summary = new ConcurrentHashMap<>();
        
        summary.put("totalSent", totalNotificationsSent.get());
        summary.put("totalFailed", totalNotificationsFailed.get());
        summary.put("totalValidationErrors", totalValidationErrors.get());
        summary.put("totalCircuitBreakerOpen", totalCircuitBreakerOpen.get());
        summary.put("totalDLQEntries", totalDLQEntries.get());
        summary.put("totalAsyncNotifications", totalAsyncNotifications.get());
        summary.put("totalSyncNotifications", totalSyncNotifications.get());
        summary.put("successRate", String.format("%.2f%%", getSuccessRate()));
        summary.put("failureRate", String.format("%.2f%%", getFailureRate()));
        summary.put("lastResetTime", lastResetTime.toString());
        
        return summary;
    }
    
    /**
     * Gets metrics for a specific notification type
     */
    public Map<String, Object> getMetricsForType(String notificationType) {
        NotificationTypeMetrics metrics = metricsByType.get(notificationType);
        if (metrics == null) {
            return Map.of();
        }
        
        Map<String, Object> typeMetrics = new ConcurrentHashMap<>();
        typeMetrics.put("successCount", metrics.successCount.get());
        typeMetrics.put("failureCount", metrics.failureCount.get());
        typeMetrics.put("validationErrors", metrics.validationErrors.get());
        typeMetrics.put("errorCounts", metrics.errorCounts);
        
        long total = metrics.successCount.get() + metrics.failureCount.get();
        if (total > 0) {
            double successRate = (metrics.successCount.get() * 100.0) / total;
            typeMetrics.put("successRate", String.format("%.2f%%", successRate));
        }
        
        return typeMetrics;
    }
    
    /**
     * Resets all metrics
     */
    public void reset() {
        totalNotificationsSent.set(0);
        totalNotificationsFailed.set(0);
        totalValidationErrors.set(0);
        totalCircuitBreakerOpen.set(0);
        totalDLQEntries.set(0);
        totalAsyncNotifications.set(0);
        totalSyncNotifications.set(0);
        metricsByType.clear();
        lastResetTime = LocalDateTime.now();
        
        log.info("Notification metrics reset");
    }
    
    /**
     * Gets or creates metrics for a notification type
     */
    private NotificationTypeMetrics getOrCreateTypeMetrics(String notificationType) {
        return metricsByType.computeIfAbsent(notificationType, k -> new NotificationTypeMetrics());
    }
    
    /**
     * Metrics for a specific notification type
     */
    private static class NotificationTypeMetrics {
        private final AtomicLong successCount = new AtomicLong(0);
        private final AtomicLong failureCount = new AtomicLong(0);
        private final AtomicLong validationErrors = new AtomicLong(0);
        private final Map<String, Long> errorCounts = new ConcurrentHashMap<>();
    }
    
    /**
     * Logs current metrics summary
     */
    public void logMetricsSummary() {
        Map<String, Object> summary = getMetricsSummary();
        log.info("===== Notification Metrics Summary =====");
        log.info("Total Sent: {}", summary.get("totalSent"));
        log.info("Total Failed: {}", summary.get("totalFailed"));
        log.info("Success Rate: {}", summary.get("successRate"));
        log.info("Failure Rate: {}", summary.get("failureRate"));
        log.info("Validation Errors: {}", summary.get("totalValidationErrors"));
        log.info("Circuit Breaker Opens: {}", summary.get("totalCircuitBreakerOpen"));
        log.info("DLQ Entries: {}", summary.get("totalDLQEntries"));
        log.info("Async Notifications: {}", summary.get("totalAsyncNotifications"));
        log.info("Sync Notifications: {}", summary.get("totalSyncNotifications"));
        log.info("=====================================");
    }
}

