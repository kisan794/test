package com.hireright.sourceintelligence.config;

import lombok.extern.slf4j.Slf4j;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
public class OpenApiConfig {

    @Value("${api.v1.base-path}")
    private String v1BasePath;

    @Value("${api.v2.base-path}")
    private String v2BasePath;

    @Bean
    public GroupedOpenApi apiV1() {
        log.info("v1BasePath:{}",v1BasePath);
        return GroupedOpenApi.builder()
                .group("v1")
                .pathsToMatch(v1BasePath)
                .build();
    }

    @Bean
    public GroupedOpenApi apiV2() {
        log.info("v2BasePath:{}",v2BasePath);
        return GroupedOpenApi.builder()
                .group("v2")
                .pathsToMatch(v2BasePath)
                .build();
    }
}
