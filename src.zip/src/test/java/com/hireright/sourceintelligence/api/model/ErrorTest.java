package com.hireright.sourceintelligence.api.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ErrorTest {

	@Test
	void testGettersAndSetters() {
		Error error = new Error();

		error.setErrorCode("ERR001");
		error.setField("fieldName");
		error.setMessage("Some error message");

		assertEquals("ERR001", error.getErrorCode());
		assertEquals("fieldName", error.getField());
		assertEquals("Some error message", error.getMessage());
	}
}