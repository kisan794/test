package com.hireright.sourceintelligence.api.dto.notification;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * Data Transfer Object for email attachments.
 * Follows Single Responsibility Principle - only handles attachment data.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AttachmentDTO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * Filename of the attachment
     */
    @NotBlank(message = "Attachment filename cannot be blank")
    @Size(max = 255, message = "Filename cannot exceed 255 characters")
    private String filename;
    
    /**
     * Base64 encoded content of the attachment
     */
    @NotBlank(message = "Attachment content cannot be blank")
    private String content;
    
    /**
     * MIME type of the attachment (e.g., application/pdf, image/png)
     */
    @NotBlank(message = "Content type cannot be blank")
    private String contentType;
    
    /**
     * Size of the attachment in bytes (calculated after decoding base64)
     */
    private Long sizeBytes;
}

