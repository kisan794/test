package com.hireright.sourceintelligence.config;

import com.mongodb.client.MongoClient;
import org.junit.jupiter.api.Test;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.MongoTransactionManager;
import org.springframework.test.util.ReflectionTestUtils;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.PRODUCTION;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.STAGE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class DatabaseConfigurationTest {

    @Test
    void constructor_shouldCreateInstance() {
        DatabaseConfiguration configuration = new DatabaseConfiguration();
        assertNotNull(configuration);
    }

    @Test
    void transactionManager_shouldReturnMongoTransactionManager() {
        DatabaseConfiguration configuration = new DatabaseConfiguration();
        MongoDatabaseFactory dbFactory = mock(MongoDatabaseFactory.class);

        MongoTransactionManager transactionManager = configuration.transactionManager(dbFactory);

        assertNotNull(transactionManager);
    }

    @Test
    void getDatabaseName_shouldReturnPrimaryDatabaseName() {
        DatabaseConfiguration configuration = new DatabaseConfiguration();
        ReflectionTestUtils.setField(configuration, "primaryDatabaseName", "source_intelligence_db");

        String databaseName = ReflectionTestUtils.invokeMethod(configuration, "getDatabaseName");

        assertEquals("source_intelligence_db", databaseName);
    }

    @Test
    void mongoClient_shouldCreateClient_whenEnvIsStage() {
        DatabaseConfiguration configuration = new DatabaseConfiguration();
        ReflectionTestUtils.setField(configuration, "dbConnectionString", "mongodb://localhost:27017/test");
        ReflectionTestUtils.setField(configuration, "elasticsearchEnvType", STAGE);

        MongoClient mongoClient = configuration.mongoClient();

        assertNotNull(mongoClient);
        mongoClient.close();
    }

    @Test
    void mongoClient_shouldCreateClient_whenEnvIsProduction() {
        DatabaseConfiguration configuration = new DatabaseConfiguration();
        ReflectionTestUtils.setField(configuration, "dbConnectionString", "mongodb://localhost:27017/test");
        ReflectionTestUtils.setField(configuration, "elasticsearchEnvType", PRODUCTION);

        MongoClient mongoClient = configuration.mongoClient();

        assertNotNull(mongoClient);
        mongoClient.close();
    }

    @Test
    void mongoClient_shouldCreateClient_whenEnvIsNotStageOrProduction() {
        DatabaseConfiguration configuration = new DatabaseConfiguration();
        ReflectionTestUtils.setField(configuration, "dbConnectionString", "mongodb://localhost:27017/test");
        ReflectionTestUtils.setField(configuration, "elasticsearchEnvType", "DEV");

        MongoClient mongoClient = configuration.mongoClient();

        assertNotNull(mongoClient);
        mongoClient.close();
    }
}