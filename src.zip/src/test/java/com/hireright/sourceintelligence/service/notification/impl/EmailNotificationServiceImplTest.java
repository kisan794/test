package com.hireright.sourceintelligence.service.notification.impl;

import com.hireright.sourceintelligence.api.dto.notification.EmailNotificationDTO;
import jakarta.mail.internet.MimeMessage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for EmailNotificationServiceImpl
 */
@ExtendWith(MockitoExtension.class)
class EmailNotificationServiceImplTest {
    
    @Mock
    private JavaMailSender mailSender;
    
    @Mock
    private MimeMessage mimeMessage;
    
    @InjectMocks
    private EmailNotificationServiceImpl emailNotificationService;
    
    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(emailNotificationService, "fromEmail", "test@example.com");
        ReflectionTestUtils.setField(emailNotificationService, "emailEnabled", true);
    }
    
    @Test
    void testSendEmail_Success() {
        // Given
        EmailNotificationDTO emailNotification = EmailNotificationDTO.builder()
                .to(List.of("recipient@example.com"))
                .subject("Test Subject")
                .body("Test Body")
                .htmlContent(false)
                .build();
        
        when(mailSender.createMimeMessage()).thenReturn(mimeMessage);
        
        // When
        String notificationId = emailNotificationService.sendEmail(emailNotification);
        
        // Then
        assertNotNull(notificationId);
        verify(mailSender, times(1)).send(any(MimeMessage.class));
    }
    
    @Test
    void testSendEmail_WhenDisabled() {
        // Given
        ReflectionTestUtils.setField(emailNotificationService, "emailEnabled", false);
        
        EmailNotificationDTO emailNotification = EmailNotificationDTO.builder()
                .to(List.of("recipient@example.com"))
                .subject("Test Subject")
                .body("Test Body")
                .build();
        
        // When
        String notificationId = emailNotificationService.sendEmail(emailNotification);
        
        // Then
        assertNull(notificationId);
        verify(mailSender, never()).send(any(MimeMessage.class));
    }
    
    @Test
    void testSendEmail_InvalidNotification() {
        // Given
        EmailNotificationDTO emailNotification = EmailNotificationDTO.builder()
                .to(List.of())
                .subject("Test Subject")
                .body("Test Body")
                .build();
        
        // When & Then
        assertThrows(IllegalArgumentException.class, () -> 
                emailNotificationService.sendEmail(emailNotification));
    }
    
    @Test
    void testValidateEmailNotification_Valid() {
        // Given
        EmailNotificationDTO emailNotification = EmailNotificationDTO.builder()
                .to(List.of("recipient@example.com"))
                .subject("Test Subject")
                .body("Test Body")
                .build();
        
        // When
        boolean isValid = emailNotificationService.validateEmailNotification(emailNotification);
        
        // Then
        assertTrue(isValid);
    }
    
    @Test
    void testValidateEmailNotification_NullNotification() {
        // When
        boolean isValid = emailNotificationService.validateEmailNotification(null);
        
        // Then
        assertFalse(isValid);
    }
    
    @Test
    void testValidateEmailNotification_EmptyRecipients() {
        // Given
        EmailNotificationDTO emailNotification = EmailNotificationDTO.builder()
                .to(List.of())
                .subject("Test Subject")
                .body("Test Body")
                .build();
        
        // When
        boolean isValid = emailNotificationService.validateEmailNotification(emailNotification);
        
        // Then
        assertFalse(isValid);
    }
    
    @Test
    void testValidateEmailNotification_EmptySubject() {
        // Given
        EmailNotificationDTO emailNotification = EmailNotificationDTO.builder()
                .to(List.of("recipient@example.com"))
                .subject("")
                .body("Test Body")
                .build();
        
        // When
        boolean isValid = emailNotificationService.validateEmailNotification(emailNotification);
        
        // Then
        assertFalse(isValid);
    }
    
    @Test
    void testValidateEmailNotification_EmptyBody() {
        // Given
        EmailNotificationDTO emailNotification = EmailNotificationDTO.builder()
                .to(List.of("recipient@example.com"))
                .subject("Test Subject")
                .body("")
                .build();
        
        // When
        boolean isValid = emailNotificationService.validateEmailNotification(emailNotification);
        
        // Then
        assertFalse(isValid);
    }
}

