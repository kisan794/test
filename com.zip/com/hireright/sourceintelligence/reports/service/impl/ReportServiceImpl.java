package com.hireright.sourceintelligence.reports.service.impl;

import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.reports.domain.entity.ReportSearchResult;
import com.hireright.sourceintelligence.reports.domain.entity.Reports;
import com.hireright.sourceintelligence.reports.domain.mapper.ReportMapper;
import com.hireright.sourceintelligence.reports.dto.GenericResponseDTO;
import com.hireright.sourceintelligence.reports.dto.MetaDTO;
import com.hireright.sourceintelligence.reports.dto.ReportResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;
import com.hireright.sourceintelligence.reports.service.ReportService;
import com.hireright.sourceintelligence.service.impl.QueryBuilder;
import com.hireright.sourceintelligence.service.impl.helperservices.CountryRegionMappingUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.REPORTS_COLLECTION;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.RESPONSE_REPORT_LIST;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.ReportTypes.DELETE_SOURCE_REPORT;
import static com.hireright.sourceintelligence.reports.service.impl.ReportUtils.getMetaDataByReport;

@AllArgsConstructor
@Slf4j
@Service
public class ReportServiceImpl implements ReportService {

    private final ReportMapper reportMapper;

    private final CustomSourceRepository<Reports> customSourceRepository;

    private final CountryRegionMappingUtils countryRegionMappingUtils;

    @Override
    public ReportResponseDTO deleteReport(ReportsRequestDTO reportsRequestDTO) {
        List<String> countryList = null;
        if(reportsRequestDTO.getRegion() != null && !reportsRequestDTO.getRegion().isEmpty()){
            countryList = countryRegionMappingUtils.findDistinctCountriesByRegion(reportsRequestDTO.getRegion());
        }
        Criteria criteria = ReportsQueryBuilder.queryBuilderForDelete(reportsRequestDTO, countryList);
        MatchOperation matchOperation = ReportsQueryBuilder.matchOperation(criteria);
        GroupOperation groupOperation = ReportsQueryBuilder.deleteGroupOperation();
        SortOperation sortOperation = ReportsQueryBuilder.buildSortOperation(reportsRequestDTO.getSort(), reportsRequestDTO.getOrder());
        FacetOperation facetOperation = ReportsQueryBuilder.facetOperationWithGroup(sortOperation, reportsRequestDTO.getStartPage(), reportsRequestDTO.getBatchSize(), groupOperation);
        ProjectionOperation finalProject = ReportsQueryBuilder.finalProjectionWithTotalCountInPipeline(RESPONSE_REPORT_LIST);
        AggregationOptions aggregationOptionsToAllowDiskUse = AggregationOptions.builder()
                .allowDiskUse(true).build();
        Aggregation aggregation;
        aggregation = Aggregation.newAggregation(matchOperation,groupOperation, facetOperation, finalProject).withOptions(aggregationOptionsToAllowDiskUse);
        var response = customSourceRepository.reportCustomAggregate(aggregation,REPORTS_COLLECTION, ReportSearchResult.class);
        log.info("Response: {}", response);

        List<GenericResponseDTO> responseDTOS = new ArrayList<>();
        if(!response.getResponseReportList().isEmpty()){
            responseDTOS = reportMapper.toDTOList(response.getResponseReportList());
        }
        List<MetaDTO> metaDTOList = getMetaDataByReport(DELETE_SOURCE_REPORT);
        return ReportResponseDTO.builder().
                meta(metaDTOList).response(responseDTOS)
               .currentPage(reportsRequestDTO.getStartPage())
                .totalItems(response.getTotal())
                .totalPages(QueryBuilder.getTotalPages(response.getTotal(), reportsRequestDTO.getBatchSize()))
                .reportType(DELETE_SOURCE_REPORT).build();
    }

}
