package hireright.applications.igniting_innovations.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FormConfigurationResponse {
    private String formId;
    private String formTitle;
    private String formDescription;
    private String version;
    private List<FormSection> sections;
    private Map<String, Object> formSettings;
    private List<String> requiredFields;
    private Map<String, String> validationRules;
}

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
class FormSection {
    private String sectionId;
    private String sectionTitle;
    private String sectionDescription;
    private Integer displayOrder;
    private List<FormField> fields;
    private Boolean collapsible;
    private Boolean defaultExpanded;
}

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
class FormField {
    private String fieldId;
    private String fieldKey;
    private String label;
    private String fieldType;
    private String placeholder;
    private String helpText;
    private Boolean required;
    private Integer displayOrder;
    private Integer maxLength;
    private Integer minLength;
    private List<FieldOption> options;
    private Map<String, Object> validation;
    private Map<String, Object> attributes;
    private String defaultValue;
    private Boolean multiSelect;
    private Boolean allowOther;
    private String otherFieldKey;
    private List<String> dependsOn;
    private Map<String, Object> conditionalLogic;
}

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
class FieldOption {
    private String value;
    private String label;
    private String description;
    private Boolean disabled;
    private String icon;
    private Map<String, Object> metadata;
}