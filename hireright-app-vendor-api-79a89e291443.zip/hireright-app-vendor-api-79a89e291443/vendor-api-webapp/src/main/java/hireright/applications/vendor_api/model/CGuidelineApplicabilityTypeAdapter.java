/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-08-18	Created
 */
package hireright.applications.vendor_api.model;

import jakarta.xml.bind.annotation.adapters.XmlAdapter;

public class CGuidelineApplicabilityTypeAdapter extends XmlAdapter<String, EGuidelineApplicabilityType>
{
	@Override
	public String marshal(EGuidelineApplicabilityType unmarshalled) throws Exception
	{
		return unmarshalled.stringValue();
	}

	@Override
	public EGuidelineApplicabilityType unmarshal(String marshalled) throws Exception
	{
		return EGuidelineApplicabilityType.ofStringValue(marshalled);
	}
}
