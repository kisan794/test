package com.hireright.sourceintelligence.api.dto.notification;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * DTO for email notification details
 * Following DTO pattern for data transfer between layers
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EmailNotificationDTO {
    
    @NotEmpty(message = "At least one recipient email address is required")
    private List<@Email(message = "Invalid email address") String> to;
    
    private List<@Email(message = "Invalid CC email address") String> cc;
    
    private List<@Email(message = "Invalid BCC email address") String> bcc;
    
    @NotNull(message = "Email subject is required")
    private String subject;
    
    @NotNull(message = "Email body is required")
    private String body;
    
    private boolean htmlContent;
    
    private Map<String, String> metadata;
    
    private List<AttachmentDTO> attachments;
}

