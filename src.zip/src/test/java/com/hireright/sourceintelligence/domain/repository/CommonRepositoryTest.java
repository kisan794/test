package com.hireright.sourceintelligence.domain.repository;

import com.mongodb.bulk.BulkWriteResult;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import java.lang.reflect.Field;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class CommonRepositoryTest {

    @Mock
    private MongoTemplate mongoTemplate;

    @Mock
    private BulkOperations bulkOperations;

    @Mock
    private BulkWriteResult bulkWriteResult;

    @InjectMocks
    private CommonRepository commonRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        commonRepository = new CommonRepository(mongoTemplate);
    }

    @Test
    void bulkUpdates_shouldReturnZeroWhenInputListIsEmpty() {
        int result = commonRepository.bulkUpdates(List.of(), DummyEntity.class, DummyEntity::getId, "testCollection");
        assertThat(result).isZero();
    }

    @Test
    void bulkUpdates_shouldPerformUpdateAndReturnModifiedCount() throws Exception {
        DummyEntity entity = new DummyEntity("645e9fd8581f1e4a1cb0a780");
        List<DummyEntity> entityList = List.of(entity);

        when(mongoTemplate.bulkOps(any(), eq(DummyEntity.class), eq("testCollection")))
                .thenReturn(bulkOperations);
        when(bulkOperations.replaceOne(any(Query.class), eq(entity))).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        Field field = CommonRepository.class.getDeclaredField("shardLocation");
        field.setAccessible(true);
        field.set(commonRepository, "US");

        int modifiedCount = commonRepository.bulkUpdates(entityList, DummyEntity.class, DummyEntity::getId, "testCollection");

        assertThat(modifiedCount).isEqualTo(1);
        verify(bulkOperations, times(1)).replaceOne(any(Query.class), eq(entity));
        verify(bulkOperations, times(1)).execute();
    }


    // Dummy class for test
    static class DummyEntity {
        private final String id;

        DummyEntity(String id) {
            this.id = id;
        }

        public String getId() {
            return id;
        }
    }
}
