package hireright.applications.igniting_innovations.document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Keshav Ladha
 * @version 1.0
 */
@Document(collection = "idea_submissions")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IdeaSubmission {

    @Id
    private String id;

    // Section 1: Basic Information
    @Indexed
    private String title;

    @Indexed
    private String submittedBy;

    private String emailAddress;

    private String name;

    @Indexed
    private LocalDateTime submissionDate;

    // Section 2: Idea Details
    private String description;

    private String objective;

    // Section 3: Area of Impact (stored as list)
    private List<String> impactAreas;

    // Section 4: Type of Improvement (stored as list)
    private List<String> improvementTypes;

    private String improvementTypeOther;

    // Section 5: Expected Impact
    private String expectedBenefit;

    private List<String> impactCategories;

    private String impactCategoryOther;

    // Section 6: Implementation Details
    private String implementationComplexity;

    private String suggestedSteps;

    private String timelineType;

    // Section 7: Supporting Information
    private List<String> supportingDocuments;

    private String additionalComments;

    // Status Tracking
    @Indexed
    private String status;

    // Audit Fields
    @Indexed
    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;
}

