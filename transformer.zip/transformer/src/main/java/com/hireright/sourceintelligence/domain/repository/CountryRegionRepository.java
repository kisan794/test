package com.hireright.sourceintelligence.domain.repository;

import com.hireright.sourceintelligence.domain.entity.CountryRegion;
import org.bson.types.ObjectId;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CountryRegionRepository extends MongoRepository<CountryRegion, ObjectId> {
    
    Page<CountryRegion> findByCountryId(Integer countryId, Pageable pageable);
    
    long countByCountryId(Integer countryId);
}

