package org.example.recombointegration.document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.index.Indexed;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * MongoDB document representing an Idea Submission.
 * Stores all information related to submitted ideas including basic info,
 * impact areas, implementation details, and tracking status.
 *
 * @author Generated
 * @version 1.0
 */
@Document(collection = "idea_submissions")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IdeaSubmission {

    @Id
    private String id;

    // Section 1: Basic Information
    @Indexed
    private String title;

    @Indexed
    private String submittedBy;

    private String emailAddress;

    @Indexed
    private String department;

    @Indexed
    private LocalDateTime submissionDate;

    // Section 2: Idea Details
    private String description;

    private String objective;

    // Section 3: Area of Impact (stored as list)
    private List<String> impactAreas;

    // Section 4: Type of Improvement (stored as list)
    private List<String> improvementTypes;

    private String improvementTypeOther;

    // Section 5: Expected Impact
    private String expectedBenefit;

    private List<String> impactCategories;

    private String impactCategoryOther;

    // Section 6: Implementation Details
    private ImplementationComplexity implementationComplexity;

    private String suggestedSteps;

    private TimelineType timelineType;

    // Section 7: Supporting Information
    private List<String> supportingDocuments;

    private String additionalComments;

    // Status Tracking
    @Indexed
    @Builder.Default
    private IdeaStatus status = IdeaStatus.SUBMITTED;

    // Engagement Metrics
    @Builder.Default
    private Integer upvoteCount = 0;

    // Audit Fields
    @Indexed
    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    private LocalDateTime reviewedAt;

    private String reviewedBy;

    private String reviewComments;

    // Embedded comments
    @Builder.Default
    private List<IdeaComment> comments = new ArrayList<>();

    /**
     * Implementation Complexity Enum
     */
    public enum ImplementationComplexity {
        LOW("Low - Quick win, minimal resources needed"),
        MEDIUM("Medium - Requires planning, moderate resources"),
        HIGH("High - Significant changes or investment needed");

        private final String description;

        ImplementationComplexity(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

    /**
     * Timeline Type Enum
     */
    public enum TimelineType {
        SHORT_TERM("Short-term (Quick Win)"),
        LONG_TERM("Long-term (Strategic Impact)");

        private final String description;

        TimelineType(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

    /**
     * Idea Status Enum for tracking workflow
     */
    public enum IdeaStatus {
        SUBMITTED("Submitted"),
        UNDER_REVIEW("Under Review"),
        APPROVED("Approved"),
        IMPLEMENTED("Implemented"),
        COMPLETED("Completed"),
        REJECTED("Rejected"),
        ON_HOLD("On Hold");

        private final String description;

        IdeaStatus(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

    /**
     * Embedded comment class
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class IdeaComment {
        private String id;
        private String commenterName;
        private String commenterEmail;
        private String comment;
        private LocalDateTime createdAt;
    }
}

