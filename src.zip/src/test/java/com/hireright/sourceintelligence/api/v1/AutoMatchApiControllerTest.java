package com.hireright.sourceintelligence.api.v1;

//import com.hireright.common.api.exception.ResourceNotFoundException;
import com.hireright.sourceintelligence.api.dto.AutoMatchDTO;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchResponseDTO;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.service.AutoMatchRegionService;
import com.hireright.sourceintelligence.service.impl.RegionServiceFactory;
import com.hireright.sourceintelligence.service.impl.helperservices.CountryRegionMappingUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class) // Added this to initialize mocks automatically!
class AutoMatchApiControllerTest {

    @InjectMocks
    private AutoMatchApiController autoMatchApiController;

    @Mock
    private RegionServiceFactory regionServiceFactory;

    @Mock
    private AutoMatchRegionService autoMatchRegionService;

    @Mock
    private CountryRegionMappingUtils countryRegionMappingUtils;

    private AutoMatchDTO input;

    // add this helper method inside the test class
    private static String b64Utf16(String s) {
        return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_16BE));
    }


    @BeforeEach
    void setup() {
        input = new AutoMatchDTO();
        input.setCountry("Germany");
        input.setState("Berlin");
        input.setCity("Berlin");      // default; will override in “valid” tests
        input.setSourceName("");      // IMPORTANT: avoid null -> .isEmpty() NPE in controller
        input.setSourceType(OrganizationType.EDUCATION.getType());
    }

    @Test
    void testAutoMatch_CountryEmpty_ThrowsException() {
        input.setCountry("");

        ResponseEntity<AutoMatchResponseDTO> response = autoMatchApiController.autoMatch(input);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("No auto match found, country is missing", response.getBody().getError());
    }

    @Test
    void testAutoMatch_RegionEmpty_ThrowsException() {
        when(countryRegionMappingUtils.getRegion("Germany")).thenReturn("");

        ResponseEntity<AutoMatchResponseDTO> response = autoMatchApiController.autoMatch(input);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("No auto match found, region not found for the given country", response.getBody().getError());
    }


    @Test
    void testAutoMatch_EMEARegion_CityMissing_ThrowsException() {
        when(countryRegionMappingUtils.getRegion("Germany")).thenReturn("EMEA");
        input.setCity("");

        ResponseEntity<AutoMatchResponseDTO> response = autoMatchApiController.autoMatch(input);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("No auto match found, city is missing", response.getBody().getError());
    }


    @Test
    void testAutoMatch_USRegion_EducationType_CityOrStateMissing_ReturnsErrorInResponse() {
        when(countryRegionMappingUtils.getRegion("USA")).thenReturn("US");
        input.setCountry("USA");
        input.setCity("");
        input.setSourceType(OrganizationType.EDUCATION.getType());

        ResponseEntity<AutoMatchResponseDTO> response = autoMatchApiController.autoMatch(input);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("No auto match found, state or city is missing", response.getBody().getError());
    }


    @Test
    void testAutoMatch_ValidEMEA_ReturnsResponse() {
        when(countryRegionMappingUtils.getRegion("Germany")).thenReturn("EMEA");
        when(regionServiceFactory.getService("EMEA")).thenReturn(autoMatchRegionService);
        input.setCity(b64Utf16("Berlin"));

        AutoMatchResponseDTO resultDTO = new AutoMatchResponseDTO();
        when(autoMatchRegionService.autoMatch(input)).thenReturn(resultDTO);

        ResponseEntity<AutoMatchResponseDTO> response = autoMatchApiController.autoMatch(input);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(resultDTO, response.getBody());
    }


    @Test
    void testAutoMatch_ValidUS_ReturnsResponse() {
        input.setCountry("USA");
        when(countryRegionMappingUtils.getRegion("USA")).thenReturn("US");
        when(regionServiceFactory.getService("US")).thenReturn(autoMatchRegionService);

        input.setCity(b64Utf16("New York"));

        AutoMatchResponseDTO resultDTO = new AutoMatchResponseDTO();
        when(autoMatchRegionService.autoMatch(input)).thenReturn(resultDTO);

        ResponseEntity<AutoMatchResponseDTO> response = autoMatchApiController.autoMatch(input);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(resultDTO, response.getBody());
    }
}