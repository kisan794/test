package com.hireright.sourceintelligence.api.dto.rds;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CountryRegionDTO {

    @JsonProperty("Id")
    private String id;

    @JsonProperty("CountryId")
    private String countryId;

    @JsonProperty("OldRegionId")
    private String oldRegionId;

    @JsonProperty("RegionName")
    private String regionName;

    @JsonProperty("ParentId")
    private String parentId;

    @JsonProperty("RegionLevel")
    private String regionLevel;

    @JsonProperty("Iso31662")
    private String iso31662;

    @JsonProperty("Obsolete")
    private String obsolete;

    @JsonProperty("Table")
    private String table;

    @JsonProperty("Scn")
    private String scn;

    @JsonProperty("OpType")
    private String opType;

    @JsonProperty("OpTs")
    private Object opTs;

    @JsonProperty("CurrentTs")
    private Object currentTs;

    @JsonProperty("RowId")
    private String rowId;

    @JsonProperty("Username")
    private String username;

    @JsonProperty("HrCode")
    private String hrCode;

    @JsonProperty("areaCodes")
    private List<String> areaCodes;
}

