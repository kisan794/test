package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.service.impl.NonUSRegionAutoMatchServiceImpl;
import com.hireright.sourceintelligence.service.impl.RegionServiceFactory;
import com.hireright.sourceintelligence.service.impl.USRegionAutoMatchServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.ObjectProvider;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.*;

class RegionServiceFactoryTest {

    private USRegionAutoMatchServiceImpl usRegionService;
    private NonUSRegionAutoMatchServiceImpl nonUsRegionService;
    private ObjectProvider<USRegionAutoMatchServiceImpl> usRegionProvider;
    private ObjectProvider<NonUSRegionAutoMatchServiceImpl> nonUsRegionProvider;
    private RegionServiceFactory regionServiceFactory;

    @BeforeEach
    void setUp() {
        usRegionService = mock(USRegionAutoMatchServiceImpl.class);
        nonUsRegionService = mock(NonUSRegionAutoMatchServiceImpl.class);
        usRegionProvider = mock(ObjectProvider.class);
        nonUsRegionProvider = mock(ObjectProvider.class);

        when(usRegionProvider.getIfAvailable()).thenReturn(usRegionService);
        when(nonUsRegionProvider.getIfAvailable()).thenReturn(nonUsRegionService);

        regionServiceFactory = new RegionServiceFactory(usRegionProvider, nonUsRegionProvider);
    }

    @ParameterizedTest(name = "getService(\"{0}\") -> expect US: {1}")
    @CsvSource({
            "us, true",
            "canada, true",
            "latam, true",
            "europe, false",
            "CaNaDa, true"
    })
    void getService_ReturnsExpectedService(String region, boolean expectUs) {
        AutoMatchRegionService result = regionServiceFactory.getService(region);

        AutoMatchRegionService expected =
                expectUs ? usRegionService : nonUsRegionService;
        assertSame(expected, result);
    }
}
