package com.hireright.sourceintelligence.reports.service;

import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.reports.domain.entity.Reports;
import com.hireright.sourceintelligence.reports.domain.entity.ReportSearchResult;
import com.hireright.sourceintelligence.reports.domain.entity.ResponseReport;
import com.hireright.sourceintelligence.reports.domain.mapper.ReportMapper;
import com.hireright.sourceintelligence.reports.dto.GenericResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;
import com.hireright.sourceintelligence.reports.service.impl.ContactUtilizationServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class ContactUtilizationServiceImplTest {

    @InjectMocks
    private ContactUtilizationServiceImpl contactUtilizationService;

    @Mock
    private ReportMapper reportMapper;

    @Mock
    private CustomSourceRepository<Reports> customSourceRepository;

    @Test
    void testGetContactUtilization_WithValidRequest() {
        ReportsRequestDTO requestDTO = new ReportsRequestDTO();
        requestDTO.setBatchSize(10);
        requestDTO.setStartPage(1);

        ReportSearchResult mockReportSearchResult = new ReportSearchResult();
        List<ResponseReport> list = new ArrayList<>();
        list.add(new ResponseReport());
        mockReportSearchResult.setResponseReportList(list);
        mockReportSearchResult.setTotal(10);

        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class)))
                .thenReturn(mockReportSearchResult);
        when(reportMapper.toDTOList(anyList()))
                .thenReturn(Collections.singletonList(new GenericResponseDTO()));

        ReportResponseDTO response = contactUtilizationService.getContactUtilization(requestDTO);

        assertNotNull(response, "Response should not be null");
        assertEquals(10, response.getTotalItems(), "Total count should be 10");
        assertFalse(response.getResponse().isEmpty(), "Response list should not be empty");
    }

    @Test
    void testGetContactUtilization_WithEmptyResponse() {
        ReportsRequestDTO requestDTO = new ReportsRequestDTO();
        requestDTO.setBatchSize(10);
        requestDTO.setStartPage(1);

        ReportSearchResult mockReportSearchResult = new ReportSearchResult();
        mockReportSearchResult.setResponseReportList(Collections.emptyList());
        mockReportSearchResult.setTotal(0);

        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class)))
                .thenReturn(mockReportSearchResult);

        ReportResponseDTO response = contactUtilizationService.getContactUtilization(requestDTO);

        assertNotNull(response, "Response should not be null");
        assertEquals(0, response.getTotalItems(), "Total count should be zero"); 
        assertTrue(response.getResponse().isEmpty(), "Response list should be empty");

        verify(reportMapper, never()).toDTOList(anyList());
    }

    @Test
    void testGetContactUtilization_WithException() {
        ReportsRequestDTO requestDTO = new ReportsRequestDTO();

        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class)))
                .thenThrow(new RuntimeException("Database error"));

        Exception exception = assertThrows(RuntimeException.class, () -> {
            contactUtilizationService.getContactUtilization(requestDTO);
        });

        assertEquals("Database error", exception.getMessage(), "Exception message should match");
    }
}
