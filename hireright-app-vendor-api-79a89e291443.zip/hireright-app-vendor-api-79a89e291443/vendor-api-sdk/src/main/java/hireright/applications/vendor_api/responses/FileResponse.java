package hireright.applications.vendor_api.responses;
/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	2017-10-17	Created
 *	A.Logachyov	2017-11-16	Added constructor
 *	M.Kuznetsov	2025-10-29	HRG-345322. Openjdk21-migration
 */

import java.util.List;

import org.springframework.http.HttpHeaders;

public class FileResponse {
    public static final String ATTACHMENT_FILENAME_PREFIX = "attachment; filename=";
    private final HttpHeaders m_headers;
    private final byte[] m_content;

    public FileResponse(HttpHeaders headers, byte[] content) {
        this.m_headers = headers;
        this.m_content = content;
    }

    public FileResponse(String sFileName, String sContentType, byte[] content) {
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.CONTENT_TYPE, sContentType);

        if (sFileName != null) {
            headers.set(HttpHeaders.CONTENT_DISPOSITION,
                    FileResponse.ATTACHMENT_FILENAME_PREFIX + sFileName.replace(" ", "_"));
        }

        this.m_headers = headers;
        this.m_content = content;
    }

    public String getFileName() {
        List<String> dispositions = getHeaders().get(HttpHeaders.CONTENT_DISPOSITION);

        return dispositions == null || dispositions.isEmpty()
                ? ""
                : dispositions.get(0).replace(ATTACHMENT_FILENAME_PREFIX, "");
    }

    public String getContentType() {
        return getHeaders().getContentType().toString();
    }

    public byte[] getContent() {
        return this.m_content;
    }

    public HttpHeaders getHeaders() {
        return this.m_headers;
    }
}
