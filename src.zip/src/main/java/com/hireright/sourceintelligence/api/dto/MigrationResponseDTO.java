package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Response DTO for data migration operations.
 * Contains detailed information about the migration process results.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MigrationResponseDTO {
    private String status;
    private String message;
    private String migrationType;
    private String filename;
    private Integer totalRecords;
    private Integer updatedRecords;
    private Integer notFoundRecords;
    private List<String> notFoundInstitutions;
    private Integer failedRecords;
    private List<String> errors;
    private Long processingTimeMs;
}