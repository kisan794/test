package hireright.applications.vendor_api.resources;
/*
 * @(#)$RCSfile: $ $Revision: $ $Date: $ $Author: $
 *
 * Copyright 2001-2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * A.Logachyov			2017-06-20	Created
 * A.Logachyov			2017-07-20	Added content provider support
 * A.Logachyov			2017-11-03	Added initDocumentSync
 * msuhhoruki			2017-11-30	HIVPE-27872: added timestamp to message to store event/action that triggered message creation
 */

import java.util.Map;
import java.util.concurrent.Callable;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import hireright.applications.vendor_api.facades.IdValueFacade;
import hireright.applications.vendor_api.services.ScreeningReportService;
import hireright.components.domain.dialects.vendor_api.BasicResponse;
import hireright.objects.is.CMessage;
import hireright.sdk.db3.DB;

@RestController
public class CScreeningReportResource extends AResource
{
	@RequestMapping(path = ScreeningReportService.PATH_ADD,
			method = RequestMethod.POST,
			consumes = MediaType.APPLICATION_XML_VALUE,
			produces = MediaType.APPLICATION_XML_VALUE)
	public BasicResponse addScreening(final HttpServletRequest request)
		throws Exception
	{
		CMessage message = DB.execute(new Callable<CMessage>()
		{
			@Override
			public CMessage call() 
				throws Exception
			{
				DB.requestTransaction();
				
				Map<String, String> params = QueryStringParser.parse(request.getQueryString());
				String sTimestamp = params != null ? params.get("tm") : null;
				
				return CMessageFactory.createAndEnqueueMessage(
						"Datasource response", sTimestamp, IOUtils.toString(request.getInputStream()));
			}
		});
		
		BasicResponse response = new BasicResponse();
		
		if (message != null)
		{
			response.getIdValues().addAll(new IdValueFacade()
					.set(ScreeningReportService.EResponseParam.MESSAGE.name(), message.getID().toString())
					.getAll());
		}
		
		return response;
	}
}
