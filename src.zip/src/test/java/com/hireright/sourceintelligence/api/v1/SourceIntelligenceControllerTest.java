package com.hireright.sourceintelligence.api.v1;

public class SourceIntelligenceControllerTest {

}
