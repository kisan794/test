package com.hireright.sourceintelligence.service.excel;

import lombok.Getter;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import java.util.HashMap;
import java.util.Map;

@Getter
public class ExcelColumnMapping {

    private final Map<String, Integer> columnMap;
    private final Map<String, String> headerToFieldMap;
    private final int headerRowIndex;
    private final int dataStartRowIndex;
    private final int sheetIndex;

    private ExcelColumnMapping(Builder builder) {
        this.columnMap = new HashMap<>(builder.columnMap);
        this.headerToFieldMap = new HashMap<>(builder.headerToFieldMap);
        this.headerRowIndex = builder.headerRowIndex;
        this.dataStartRowIndex = builder.dataStartRowIndex;
        this.sheetIndex = builder.sheetIndex;
    }

    public static Builder builder() {
        return new Builder();
    }

    public Integer getColumnIndex(String fieldName) {
        return columnMap.get(fieldName);
    }

    public ExcelColumnMapping buildFromHeaderRow(Row headerRow) {
        if (headerToFieldMap.isEmpty()) {
            return this;
        }

        Builder builder = ExcelColumnMapping.builder()
                .headerRowIndex(this.headerRowIndex)
                .dataStartRowIndex(this.dataStartRowIndex)
                .sheetIndex(this.sheetIndex);

        int lastCellNum = headerRow.getLastCellNum();
        for (int cellIndex = 0; cellIndex < lastCellNum; cellIndex++) {
            Cell cell = headerRow.getCell(cellIndex);
            if (cell == null) {
                continue;
            }

            String headerValue = ExcelCellReader.getCellValueAsString(cell).trim();
            String fieldName = headerToFieldMap.get(headerValue);

            if (fieldName != null) {
                builder.addColumn(fieldName, cellIndex);
            }
        }

        return builder.build();
    }

    public static class Builder {
        private final Map<String, Integer> columnMap = new HashMap<>();
        private final Map<String, String> headerToFieldMap = new HashMap<>();
        private int headerRowIndex = 0;
        private int dataStartRowIndex = 1;
        private int sheetIndex = 0;

        public Builder addColumn(String fieldName, int columnIndex) {
            this.columnMap.put(fieldName, columnIndex);
            return this;
        }

        public Builder addHeaderMapping(String headerName, String fieldName) {
            this.headerToFieldMap.put(headerName, fieldName);
            return this;
        }

        public Builder headerRowIndex(int headerRowIndex) {
            this.headerRowIndex = headerRowIndex;
            return this;
        }

        public Builder dataStartRowIndex(int dataStartRowIndex) {
            this.dataStartRowIndex = dataStartRowIndex;
            return this;
        }

        public Builder sheetIndex(int sheetIndex) {
            this.sheetIndex = sheetIndex;
            return this;
        }

        public ExcelColumnMapping build() {
            return new ExcelColumnMapping(this);
        }
    }
}