package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.rds.CountryDTO;
import com.hireright.sourceintelligence.api.dto.rds.CountryRegionDTO;
import com.hireright.sourceintelligence.domain.entity.Country;
import com.hireright.sourceintelligence.domain.entity.CountryRegion;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.NullValueCheckStrategy;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mapstruct.ReportingPolicy.IGNORE;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        unmappedTargetPolicy = IGNORE)
public interface CountryMapper {

    @Mapping(target = "countryId", expression = "java(convertBigDecimalToString(entity.getCountryId()))")
    @Mapping(target = "courtIntlCharge", expression = "java(convertBigDecimalToString(entity.getCourtIntlCharge()))")
    @Mapping(target = "eduIntlCharge", expression = "java(convertBigDecimalToString(entity.getEduIntlCharge()))")
    @Mapping(target = "emplIntlCharge", expression = "java(convertBigDecimalToString(entity.getEmplIntlCharge()))")
    @Mapping(target = "mvrIntlCharge", expression = "java(convertBigDecimalToString(entity.getMvrIntlCharge()))")
    @Mapping(target = "refIntlCharge", expression = "java(convertBigDecimalToString(entity.getRefIntlCharge()))")
    @Mapping(target = "timezone", expression = "java(convertBigDecimalToString(entity.getTimezone()))")
    @Mapping(target = "opTs", expression = "java(createTimestampObject(entity.getOpTs()))")
    @Mapping(target = "currentTs", expression = "java(createTimestampObject(entity.getCurrentTs()))")
    CountryDTO entityToDTO(Country entity);

    List<CountryDTO> entityToDTOList(List<Country> entityList);

    @Mapping(target = "id", expression = "java(convertIntegerToString(entity.getRegionId()))")
    @Mapping(target = "countryId", expression = "java(convertIntegerToString(entity.getCountryId()))")
    @Mapping(target = "oldRegionId", expression = "java(convertIntegerToString(entity.getOldRegionId()))")
    @Mapping(target = "parentId", expression = "java(convertIntegerToString(entity.getParentId()))")
    @Mapping(target = "regionLevel", expression = "java(convertIntegerToString(entity.getRegionLevel()))")
    @Mapping(target = "opTs", expression = "java(createTimestampObject(entity.getOpTs()))")
    @Mapping(target = "currentTs", expression = "java(createTimestampObject(entity.getCurrentTs()))")
    CountryRegionDTO entityToRegionDTO(CountryRegion entity);

    List<CountryRegionDTO> entityToRegionDTOList(List<CountryRegion> entityList);

    default String convertBigDecimalToString(BigDecimal value) {
        if (value == null) {
            return "0";
        }
        return value.stripTrailingZeros().toPlainString();
    }

    default String convertIntegerToString(Integer value) {
        if (value == null) {
            return null;
        }
        return String.valueOf(value);
    }

    default Object createTimestampObject(String timestamp) {
        if (timestamp == null || timestamp.equals("null")) {
            return null;
        }
        Map<String, String> timestampMap = new HashMap<>();
        timestampMap.put("$timestamp", timestamp);
        return timestampMap;
    }
}

