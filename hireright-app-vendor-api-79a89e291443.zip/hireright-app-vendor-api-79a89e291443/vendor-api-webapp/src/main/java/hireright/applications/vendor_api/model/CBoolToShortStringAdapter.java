/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-09-19	Created
 */
package hireright.applications.vendor_api.model;

import jakarta.xml.bind.annotation.adapters.XmlAdapter;

import hireright.sdk.consts.Logical;

public class CBoolToShortStringAdapter extends XmlAdapter<String, Boolean>
{
	@Override
	public String marshal(Boolean v) throws Exception
	{
		if (v == null)
			return null;
		return v ? Logical.YES_SHORT : Logical.NO_SHORT;
	}

	public Boolean unmarshal(String v) throws Exception
	{
		if (v == null)
			return null;
		return Logical.YES_SHORT.equals(v) ? true : false;
	}
}
