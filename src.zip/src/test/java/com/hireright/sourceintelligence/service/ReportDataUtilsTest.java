package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.ApprovalRequestDTO;
import com.hireright.sourceintelligence.api.dto.AssignSourceDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.reports.dto.ReportsDTO;
import com.hireright.sourceintelligence.reports.service.ReportDataService;
import com.hireright.sourceintelligence.service.impl.helperservices.ReportDataUtils;
import com.mongodb.BasicDBObject;
import org.bson.Document;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;

import java.util.*;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.SIDB_APPROVAL_FLOW;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.IN_PROGRESS;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.AUTO_MATCH;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.ADDITIONAL_INFO;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.VERIFICATION_VALIDATION_DATE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(org.mockito.junit.jupiter.MockitoExtension.class)
class ReportDataUtilsTest {

    @Mock
    private ReportDataService reportDataService;

    @InjectMocks
    private ReportDataUtils reportDataUtils;

    private Source source;

    @BeforeEach
    void setUp() {
        source = new Source();
        source.setHon("HON123");
        source.setOrganizationName("OrgName");
        source.setOrganizationType(OrganizationType.values()[0]);
        source.setCreatedBy("creator");
        source.setCountry("India");
        source.setState("Assam");
        source.setCity("Guwahati");
        source.setApprovalStatus(ApprovalStatus.APPROVED);
        source.setAssignedTo("approver");
        source.setAssignedId("approverId");
    }


    @Test
    void reportData_withBasicDBObjectPayload_setsVerificationValidationDate_andOtherFields() {
        BasicDBObject payload = new BasicDBObject();

        BasicDBObject additionalInfo = new BasicDBObject();
        additionalInfo.put(VERIFICATION_VALIDATION_DATE, "2023-01-01");
        payload.put(ADDITIONAL_INFO, new ArrayList<>(List.of(additionalInfo)));

        source.setPayload(payload);

        reportDataUtils.reportData(source, "CREATE", "SIDB", 0, "someReason", 1, 0, "");
        reportDataUtils.reportData(source, "CREATE", "SIDB", 0, null, 1, 0, "");

        ArgumentCaptor<ReportsDTO> captor = ArgumentCaptor.forClass(ReportsDTO.class);
        verify(reportDataService, times(2)).createData(captor.capture());

        ReportsDTO first = captor.getAllValues().get(0);
        ReportsDTO second = captor.getAllValues().get(1);

        assertEquals("someReason", first.getReason());
        assertNull(second.getReason());

        assertEquals("2023-01-01", first.getVerificationValidationDate());
        assertEquals("2023-01-01", second.getVerificationValidationDate());
    }

    @Test
    void reportData_withDocumentPayload_setsVerificationValidationDate() {
        BasicDBObject payload = new BasicDBObject();

        Document doc = new Document();
        doc.put(VERIFICATION_VALIDATION_DATE, "2023-02-01");
        payload.put(ADDITIONAL_INFO, new ArrayList<>(List.of(doc)));

        source.setPayload(payload);

        reportDataUtils.reportData(source, "CREATE", "SIDB", 0, null, 1,0,"");

        ArgumentCaptor<ReportsDTO> captor = ArgumentCaptor.forClass(ReportsDTO.class);
        verify(reportDataService).createData(captor.capture());

        assertEquals("2023-02-01", captor.getValue().getVerificationValidationDate());
    }

    @Test
    void reportData_withMapPayload_setsVerificationValidationDate() {
        BasicDBObject payload = new BasicDBObject();

        Map<String, Object> map = new HashMap<>();
        map.put(VERIFICATION_VALIDATION_DATE, "2023-03-01");

        payload.put(ADDITIONAL_INFO, new ArrayList<>(List.of(map)));
        source.setPayload(payload);

        reportDataUtils.reportData(source, "CREATE", "SIDB", 0, null, 1,0,"");

        ArgumentCaptor<ReportsDTO> captor = ArgumentCaptor.forClass(ReportsDTO.class);
        verify(reportDataService).createData(captor.capture());

        assertEquals("2023-03-01", captor.getValue().getVerificationValidationDate());
    }

    @Test
    void reportData_withEmptyPayload_shouldStillCreateData() {
        BasicDBObject payload = new BasicDBObject();
        source.setPayload(payload);

        reportDataUtils.reportData(source, "CREATE", "SIDB", 0, null, 1,0,"");

        verify(reportDataService).createData(any(ReportsDTO.class));
    }

    @Test
    void reportData_withAdditionalInfoEmptyList_shouldNotSetVerificationValidationDate() {
        BasicDBObject payload = new BasicDBObject();
        payload.put(ADDITIONAL_INFO, new ArrayList<>());
        source.setPayload(payload);

        reportDataUtils.reportData(source, "CREATE", "SIDB", 0, null, 1, 0, "");
        reportDataUtils.reportData(source, AUTO_MATCH, "ORIGIN", 1, null, 1, 0, "");

        ArgumentCaptor<ReportsDTO> captor = ArgumentCaptor.forClass(ReportsDTO.class);
        verify(reportDataService, times(2)).createData(captor.capture());

        assertNull(captor.getAllValues().get(0).getVerificationValidationDate());
        assertNull(captor.getAllValues().get(1).getVerificationValidationDate());
    }

    @Test
    void reportData_withAdditionalInfoFirstElementNull_shouldNotSetVerificationValidationDate() {
        BasicDBObject payload = new BasicDBObject();
        ArrayList<Object> additionalInfoList = new ArrayList<>();
        additionalInfoList.add(null);
        payload.put(ADDITIONAL_INFO, additionalInfoList);
        source.setPayload(payload);

        reportDataUtils.reportData(source, "CREATE", "SIDB", 0, null,1,0,"");

        ArgumentCaptor<ReportsDTO> captor = ArgumentCaptor.forClass(ReportsDTO.class);
        verify(reportDataService).createData(captor.capture());

        assertNull(captor.getValue().getVerificationValidationDate());
    }

    @Test
    void reportData_withAdditionalInfoUnknownType_shouldNotSetVerificationValidationDate() {
        BasicDBObject payload = new BasicDBObject();
        payload.put(ADDITIONAL_INFO, new ArrayList<>(List.of("not-supported-type")));
        source.setPayload(payload);

        reportDataUtils.reportData(source, "CREATE", "SIDB", 0, null, 1, 0,"");

        ArgumentCaptor<ReportsDTO> captor = ArgumentCaptor.forClass(ReportsDTO.class);
        verify(reportDataService).createData(captor.capture());

        assertNull(captor.getValue().getVerificationValidationDate());
    }

    @Test
    void reportData_withSupportedTypeButNullDate_shouldNotSetVerificationValidationDate() {
        BasicDBObject payload = new BasicDBObject();
        BasicDBObject additionalInfo = new BasicDBObject();
        payload.put(ADDITIONAL_INFO, new ArrayList<>(List.of(additionalInfo)));

        source.setPayload(payload);

        reportDataUtils.reportData(source, "CREATE", "SIDB", 0, null,1,0,"");

        ArgumentCaptor<ReportsDTO> captor = ArgumentCaptor.forClass(ReportsDTO.class);
        verify(reportDataService).createData(captor.capture());

        assertNull(captor.getValue().getVerificationValidationDate());
    }

    @Test
    void createReportData_whenHonInList_shouldCreateDataWithExpectedFields() {
        ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();
        approvalRequestDTO.setApproverName("Approver One");

        AssignSourceDTO match = new AssignSourceDTO();
        match.setHon("HON_MATCH");
        match.setOrganizationName("Match Org");
        match.setCreatedBy("matchCreator");

        AssignSourceDTO noMatch = new AssignSourceDTO();
        noMatch.setHon("HON_NO_MATCH");
        noMatch.setOrganizationName("NoMatch Org");
        noMatch.setCreatedBy("noMatchCreator");

        approvalRequestDTO.setSourceDetails(Arrays.asList(match, noMatch));

        List<String> hons = Collections.singletonList("HON_MATCH");

        reportDataUtils.createReportData(approvalRequestDTO, hons);

        ArgumentCaptor<ReportsDTO> captor = ArgumentCaptor.forClass(ReportsDTO.class);
        verify(reportDataService, times(1)).createData(captor.capture());

        ReportsDTO dto = captor.getValue();
        assertEquals("HON_MATCH", dto.getHon());
        assertEquals("Match Org", dto.getOrganizationName());
        assertEquals("ASSIGNED", dto.getApprovalStatus());
        assertEquals("Approver One", dto.getApprovedBy());
        assertEquals("matchCreator", dto.getCreatedBy());
        assertEquals(SIDB_APPROVAL_FLOW, dto.getOrigin());
        assertEquals("Assigned", dto.getAction());
        assertEquals("Assign", dto.getTxnType());
    }

    @Test
    void createReportData_whenNoHonMatches_shouldNotCreateData() {
        ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();
        approvalRequestDTO.setApproverName("Approver One");

        AssignSourceDTO s1 = new AssignSourceDTO();
        s1.setHon("HON1");
        s1.setOrganizationName("Org1");
        s1.setCreatedBy("c1");

        approvalRequestDTO.setSourceDetails(Collections.singletonList(s1));

        List<String> hons = Collections.singletonList("SOME_OTHER_HON");

        reportDataUtils.createReportData(approvalRequestDTO, hons);

        verify(reportDataService, never()).createData(any());
    }
}
