package com.hireright.sourceintelligence.domain.entity;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.UNASSIGNED;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.Instant;
import org.springframework.util.StringUtils;

/**
 * Base abstract class for entities which will hold definitions for created, last modified, created
 * by, last modified by attributes.
 */

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public abstract class AbstractAuditingEntity {

    private String createdBy;

    private String creatorId;

    @Field("created_date")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant createdDate;

    private String lastModifiedBy;

    private String lastModifierId;

    @Field("last_modified_date")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant lastModifiedDate;

    private String requestedBy;

    private String requesterId;

    private String approvedBy;

    private String approverId;

    private String assignedTo;

    private String assignedId;

    private String lastLockedBy;
    private String lastLockedId;

    private String lastUnLockedBy;
    private String lastUnLockedId;

    @Field("last_locked_date")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant lastLockedDate;

    @Field("last_unlocked_date")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant lastUnLockedDate;

    @Field("last_approved_date")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant lastApprovedDate;

    public String getAssignedTo() {
        if(StringUtils.hasText(assignedTo)) {
            return assignedTo;
        }else{
            return UNASSIGNED;
        }
    }

}
