/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-08-18	Created
 */
package hireright.applications.vendor_api.model;

import java.util.Date;

import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlRootElement(name="Guideline")
public class CGuidelineDTO
{
	private EGuidelineApplicabilityType customerApplicability;
	private EGuidelineApplicabilityType serviceApplicability;
	private String text;
	private String operatorName;
	private Date lastModified;

	@XmlAttribute(name="service")
	@XmlJavaTypeAdapter(CGuidelineApplicabilityTypeAdapter.class)
	public EGuidelineApplicabilityType getServiceApplicability()
	{
		return serviceApplicability;
	}

	public void setServiceApplicability(EGuidelineApplicabilityType serviceApplicability)
	{
		this.serviceApplicability = serviceApplicability;
	}

	@XmlAttribute(name="customer")
	@XmlJavaTypeAdapter(CGuidelineApplicabilityTypeAdapter.class)
	public EGuidelineApplicabilityType getCustomerApplicability()
	{
		return customerApplicability;
	}

	public void setCustomerApplicability(EGuidelineApplicabilityType customerApplicability)
	{
		this.customerApplicability = customerApplicability;
	}

	@XmlElement(name="Text")
	public String getText()
	{
		return text;
	}

	public void setText(String text)
	{
		this.text = text;
	}

	@XmlElement(name="OperatorName")
	public String getOperatorName()
	{
		return operatorName;
	}

	public void setOperatorName(String operatorName)
	{
		this.operatorName = operatorName;
	}

	@XmlElement(name="LastModified")
	public Date getLastModified()
	{
		return lastModified;
	}

	public void setLastModified(Date lastModified)
	{
		this.lastModified = lastModified;
	}

	public CGuidelineDTO() {}
}
