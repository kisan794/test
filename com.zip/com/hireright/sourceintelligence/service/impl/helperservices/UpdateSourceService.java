package com.hireright.sourceintelligence.service.impl.helperservices;

import com.hireright.sourceintelligence.api.dto.CycleResult;
import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.api.dto.UIActionsDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.service.impl.SearchConstants;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import com.hireright.sourceintelligence.service.impl.MongoSourceService;
import com.hireright.sourceintelligence.util.Helper;
import com.mongodb.DBObject;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.UPDATE;
import static com.hireright.sourceintelligence.constants.ErrorConstants.*;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.USED_COUNT;
import static com.hireright.sourceintelligence.util.LoggingThrowable.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.LogFlagConstants.*;


@Primary
@Slf4j
@RequiredArgsConstructor
@Transactional
@Service
public class UpdateSourceService {

    private final SourceMapper sourceMapper;
    private final SourceUtils sourceUtils;
    private final CountryRegionMappingUtils countryRegionMappingUtils;
    private final MongoSourceService mongoSourceService;
    private final ElasticsearchService elasticsearchService;
    private final ReportDataUtils reportDataUtils;

    @Transactional
    public SourceOrganizationDTO updateSource(SourceOrganizationDTO sourceDTO, UIActionsDTO uiActionsDTO) throws Exception {
        boolean isEdit = uiActionsDTO.getUserAction().equals(ACTION_SAVE) || uiActionsDTO.getUserAction().equals(ACTION_SAVE_AND_USE);
        boolean isCreateEdit = isEdit && sourceDTO.getAction().equals(CREATE);
        boolean isVersionExists = sourceDTO.getVersion() > 0;
        Source source;
        if (isEdit && isCreateEdit && !isVersionExists) {
            //editing the creation source
            source = updateSourceByResearcher(sourceDTO, uiActionsDTO, NEW_SOURCE);
        } else if (isEdit && isVersionExists) {
            //Editing the existing source
            source = updateSourceByResearcher(sourceDTO, uiActionsDTO, EXISTING_SOURCE);
        } else if (!isEdit) {
            //Approve or reject or on hold
            source = updateSourceByApprovalManager(sourceDTO, uiActionsDTO);
        } else {
            source = null;
            logAndThrowInvalidRequest(INVALID_ACTION_REQUEST, null);
        }
        return sourceMapper.entitySourceToDTO(source);
    }

    private Source updateSourceByResearcher(SourceOrganizationDTO sourceDTO, UIActionsDTO uiActionsDTO, String sourceType) throws Exception {
        boolean isNewSource = false;
        Source entityFromDb = mongoSourceService.findSourceByHonAndApprovalStatus(sourceDTO.getHon(), sourceDTO.getApprovalStatus());
        if (entityFromDb == null && sourceType.equals(NEW_SOURCE) && sourceDTO.getAction().equals(CREATE)) {
            entityFromDb = mongoSourceService.findSourceByHon(sourceDTO.getHon());
            if (entityFromDb != null && (entityFromDb.getApprovalStatus().equals(IN_PROGRESS) || entityFromDb.getApprovalStatus().equals(ONHOLD))) {
                isNewSource = true;
            }
        }
        if (entityFromDb == null) {
            //error
            logAndThrowResourceNotFound(SOURCE_NOT_FOUND, null, sourceDTO.getHon());
        }
        assert entityFromDb != null;
        Source source;
        Source updateSource = sourceMapper.dtoToEntitySource(sourceDTO);
        Source compareSource;
        if (sourceType.equals(EXISTING_SOURCE)) {
            compareSource = mongoSourceService.findSourceByHonAndApprovalStatus(sourceDTO.getHon(), APPROVED);

            boolean isSkipApprovalFlow = Helper.checkIsSkipApprovalFlow(updateSource, compareSource);
            if (!isSkipApprovalFlow) {
                boolean isAutoApprovalFlow = Helper.checkIsAutoApproval(updateSource, compareSource);
                if (!isAutoApprovalFlow) {
                    //follow trust cycle
                    source = updateSourceBasedOnTrustCycle(entityFromDb, updateSource, sourceDTO.getCountry(), isNewSource, uiActionsDTO);
                } else {
                    //auto approved
                    source = updateSourceByResearcherWithAutoApproval(entityFromDb, updateSource, uiActionsDTO);
                }
            } else {
                //manual approval flow
                source = updateSourceByResearcherWithManual(entityFromDb, updateSource, uiActionsDTO, isNewSource);
            }
        } else {
            if (sourceDTO.getOrganizationAlias().length > 0 || entityFromDb.getOrganizationAlias().length > 0) {
                source = updateSourceByResearcherWithManual(entityFromDb, updateSource, uiActionsDTO, isNewSource);
            } else {
                //For new source follow trust cycle
                source = updateSourceBasedOnTrustCycle(entityFromDb, updateSource, sourceDTO.getCountry(), isNewSource, uiActionsDTO);
            }

        }
        return source;
    }

    private Source updateSourceBasedOnTrustCycle(Source entityFromDb, Source updateSource, String country, boolean isNewSource, UIActionsDTO uiActionsDTO) throws Exception {
        String region = countryRegionMappingUtils.getRegionByCountry(country);
        String approvalStatus = AUTO_APPOVED;
        CycleResult cycleResult;
        if (Helper.fromActionForApprovalFlow(uiActionsDTO.getUserAction()) == null) {
            cycleResult = sourceUtils.checkForAutoApproval(uiActionsDTO.getUserTrustScore(), region, uiActionsDTO.getUserEmail());
            approvalStatus = cycleResult.getStatus();
        }
        if (approvalStatus.equals(AUTO_APPOVED)) {
            return updateSourceByResearcherWithAutoApproval(entityFromDb, updateSource, uiActionsDTO);
        } else {
            //Manual flow
            return updateSourceByResearcherWithManual(entityFromDb, updateSource, uiActionsDTO, isNewSource);
        }
    }

    private Source updateSourceByResearcherWithManual(Source entityFromDb, Source updateSource, UIActionsDTO uiActionsDTO, boolean isNewSource) {
        updateSource.setVersion(entityFromDb.getVersion());
        updateSource.setTempVersion(entityFromDb.getTempVersion() + 1);
        updateSource.setAction(updateSource.getVersion() > 0 ? UPDATE : CREATE);
        updateSource.setLogFlag(updateSource.getVersion() > 0 ? DETAILS_CHANGED : NEW_RECORD);

        updateSource.setLastModifiedDate(Instant.now());
        updateSource.setLastModifiedBy(uiActionsDTO.getUserName());
        updateSource.setLastModifierId(uiActionsDTO.getUserEmail());
        updateSource.setSearchOrg(updateSource.getOrganizationName().toLowerCase().trim());
        if (updateSource.getAction().equals(CREATE)) {
            updateSource.setCreatedDate(Instant.now());
            updateSource.setCreatedBy(uiActionsDTO.getUserName());
            updateSource.setCreatorId(uiActionsDTO.getUserEmail());
            updateSource.setAssignedTo(UNASSIGNED);
            updateSource.setAssignedId(UNASSIGNED);
        }
        if (entityFromDb.getTempVersion() == 0) {
            updateSource.setAssignedTo(UNASSIGNED);
            updateSource.setAssignedId(UNASSIGNED);
        }
        copyUsedCount(entityFromDb, updateSource);
        updateSource.setApprovalStatus(Helper.fromAction(uiActionsDTO.getUserAction()));
        updateSource.setStatus(SourceOrganizationStatus.INACTIVE);
        String collectionName = Helper.getCollectionName(updateSource.getHon(), SOURCE_COLLECTION_SUFFIX);
        if (!isNewSource && (entityFromDb.getApprovalStatus().equals(PENDING_APPROVAL) || entityFromDb.getApprovalStatus().equals(SAVE_PENDING_APPROVAL))) {
            deleteSourceById(entityFromDb.getId(), collectionName);
        }
        updateSource.setLastActionDate(Instant.now());
        mongoSourceService.insert(updateSource, collectionName);
        mongoSourceService.insertSourceHistory(updateSource);
        reportDataUtils.reportData(updateSource, updateSource.getAction(), SIDB_APPROVAL_FLOW, 0, MANUAL_PROCESS, updateSource.getVersion(), updateSource.getTempVersion());
        return updateSource;
    }

    private Source updateSourceByResearcherWithAutoApproval(Source entityFromDb, Source updateSource, UIActionsDTO uiActionsDTO) throws Exception {
        updateSource.setVersion(entityFromDb.getVersion() + 1);
        updateSource.setTempVersion(0);
        if (entityFromDb.getVersion() >= 1) {
            updateSource.setAction(UPDATE);
            updateSource.setLogFlag(DETAILS_CHANGED);
        } else {
            updateSource.setAction(CREATE);
            updateSource.setLogFlag(NEW_RECORD);
        }
        updateSource.setLastModifiedDate(Instant.now());
        updateSource.setLastModifiedBy(uiActionsDTO.getUserName());
        updateSource.setLastModifierId(uiActionsDTO.getUserEmail());
        updateSource.setApprovalStatus(APPROVED);
        updateSource.setStatus(SourceOrganizationStatus.ACTIVE);
        updateSource.setSearchOrg(updateSource.getOrganizationName().toLowerCase().trim());
        updateApprovalDetails(updateSource, uiActionsDTO);
        copyUsedCount(entityFromDb, updateSource);
        String collectionName = Helper.getCollectionName(updateSource.getHon(), SOURCE_COLLECTION_SUFFIX);
        if (entityFromDb.getId() != null) {
            deleteSourceById(entityFromDb.getId(), collectionName);
        }
        mongoSourceService.insert(updateSource, collectionName);
        mongoSourceService.insertSourceHistory(updateSource);
        updateESLogic(updateSource);
        reportDataUtils.reportData(updateSource, updateSource.getAction(), SIDB_APPROVAL_FLOW, 0, SearchConstants.ReportActions.AUTO_APPROVED, updateSource.getVersion(), updateSource.getTempVersion());
        return updateSource;
    }

    private Source updateSourceByApprovalManager(SourceOrganizationDTO sourceDTO, UIActionsDTO uiActionsDTO) throws Exception {

        String collectionName = Helper.getCollectionName(sourceDTO.getHon(), SOURCE_COLLECTION_SUFFIX);
        Source entityFromDb = mongoSourceService.findSourceByHonAndApprovalStatus(sourceDTO.getHon(), IN_PROGRESS);
        if (entityFromDb == null) {
            log.error("source not found");
        }
        assert entityFromDb != null;
        Source updateSource = sourceMapper.dtoToEntitySource(sourceDTO);
        updateSource.setId(entityFromDb.getId());
        updateSource.setSearchOrg(updateSource.getOrganizationName().toLowerCase().trim());
        switch (uiActionsDTO.getUserAction()) {
            case ACTION_APPROVED:
                updateSource.setApprovalStatus(APPROVED);
                updateSource.setStatus(SourceOrganizationStatus.ACTIVE);
                updateSource.setTempVersion(0);
                updateSource.setGeneralErrors(new ArrayList<>());
                updateSource.setFieldErrors(new ArrayList<>());
                updateSource.setComments("");
                updateApprovalDetails(updateSource, uiActionsDTO);

                Source approvedDbEntity = mongoSourceService.findSourceByHonAndApprovalStatus(sourceDTO.getHon(), APPROVED);
                if (approvedDbEntity == null) {
                    updateSource.setVersion(1.0);
                    copyUsedCount(entityFromDb, updateSource);
                } else {
                    updateSource.setAction(UPDATE);
                    updateSource.setVersion(approvedDbEntity.getVersion() + 1.0);
                    deleteSourceById(approvedDbEntity.getId(), collectionName);
                    copyUsedCount(approvedDbEntity, updateSource);
                }
                mongoSourceService.updateById(updateSource, collectionName);
                updateESLogic(updateSource);
                mongoSourceService.insertSourceHistory(updateSource);
                reportDataUtils.reportData(updateSource, updateSource.getAction(), SIDB_APPROVAL_FLOW, 0, MANUAL_PROCESS, sourceDTO.getVersion(), sourceDTO.getTempVersion()+1);
                break;
            case ACTION_REJECTED:
                updateSource.setApprovalStatus(REJECTED);
                updateSource.setStatus(SourceOrganizationStatus.INACTIVE);
                updateApprovalDetails(updateSource, uiActionsDTO);
                mongoSourceService.updateById(updateSource, collectionName);
                mongoSourceService.insertSourceHistory(updateSource);
                reportDataUtils.reportData(updateSource, updateSource.getAction(), SIDB_APPROVAL_FLOW, 0, MANUAL_PROCESS, sourceDTO.getVersion(), sourceDTO.getTempVersion());
                break;
            case ACTION_ON_HOLD:
                updateSource.setApprovalStatus(ONHOLD);
                updateSource.setStatus(SourceOrganizationStatus.INACTIVE);
                updateApprovalDetails(updateSource, uiActionsDTO);
                mongoSourceService.updateById(updateSource, collectionName);
                mongoSourceService.insertSourceHistory(updateSource);
                reportDataUtils.reportData(updateSource, updateSource.getAction(), SIDB_APPROVAL_FLOW, 0,  MANUAL_PROCESS, sourceDTO.getVersion(), sourceDTO.getTempVersion());
                break;
            default:
                break;
        }
        return updateSource;
    }

    private void updateApprovalDetails(Source updateSource, UIActionsDTO uiActionsDTO) {
        updateSource.setApprovedBy(uiActionsDTO.getUserName());
        updateSource.setApproverId(uiActionsDTO.getUserEmail());
        updateSource.setLastApprovedDate(Instant.now());
        updateSource.setLastActionDate(Instant.now());
    }

    private void deleteSourceById(ObjectId id, String collectionName) {
        mongoSourceService.deleteSourceById(id, collectionName);
    }

    protected void updateESLogic(Source updateSource)
            throws IOException, IllegalAccessException {

        String action = updateSource.getAction();
        ApprovalStatus approval = updateSource.getApprovalStatus();

        if (CREATE.equals(action) && APPROVED.equals(approval)) {
            elasticsearchService.createSource(updateSource);
            return;
        }
        if (UPDATE.equals(action) && APPROVED.equals(approval)) {
            elasticsearchService.updateSourceIndex(updateSource);
        }
    }

    private void copyUsedCount(Source entityFromDb, Source updateSource) {
        DBObject obj = updateSource.getPayload();
        DBObject entityPayload = entityFromDb.getPayload();
        var usedCount = entityPayload.get(USED_COUNT);
        obj.put(USED_COUNT, usedCount);
        updateSource.setPayload(obj);
    }
}
