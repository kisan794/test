package com.hireright.sourceintelligence.service.extraction;

import com.hireright.sourceintelligence.api.dto.ParchmentRecord;

import java.util.List;
import java.util.Map;

public interface DataExtractionProcessor {
    Map<String, Object> processInstitutionRecords(List<ParchmentRecord> records);

    String getDataExtractionTypeType();

    default boolean supports(String dataExtractionType) {
        return getDataExtractionTypeType().equalsIgnoreCase(dataExtractionType);
    }
}

