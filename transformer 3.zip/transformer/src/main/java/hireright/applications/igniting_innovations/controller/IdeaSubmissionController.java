package hireright.applications.igniting_innovations.controller;

import hireright.applications.igniting_innovations.dto.GenericApiResponse;
import hireright.applications.igniting_innovations.dto.IdeaSubmissionRequest;
import hireright.applications.igniting_innovations.dto.IdeaSubmissionResponse;
import hireright.applications.igniting_innovations.service.IdeaSubmissionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * REST Controller for Idea Submission Management.
 * Provides endpoints for creating, retrieving, updating, and managing idea submissions.
 *
 * @author Generated
 * @version 1.0
 */
@Tag(name = "Idea Submission", description = "APIs for managing idea submissions and continuous improvement initiatives")
@Slf4j
@RestController
@RequestMapping("/api/v1/ideas")
@RequiredArgsConstructor
public class IdeaSubmissionController {

    private final IdeaSubmissionService ideaSubmissionService;

    /**
     * Submit a new idea.
     */
    @Operation(
            summary = "Submit a new idea",
            description = "Create a new idea submission with all required details including impact areas, implementation complexity, and expected benefits."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Idea submitted successfully",
                    content = @Content(schema = @Schema(implementation = GenericApiResponse.class))),
            @ApiResponse(responseCode = "400", description = "Invalid input data"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericApiResponse> submitIdea(@Valid @RequestBody IdeaSubmissionRequest request) {
        log.info("Received request to submit new idea: {}", request.getFormData().getTitle());
        ideaSubmissionService.createIdea(request);
        GenericApiResponse response = GenericApiResponse.created("Idea submission saved successfully");
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * Get idea by ID.
     */
    @Operation(
            summary = "Get idea by ID",
            description = "Retrieve detailed information about a specific idea submission by its ID."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Idea found",
                    content = @Content(schema = @Schema(implementation = IdeaSubmissionResponse.class))),
            @ApiResponse(responseCode = "404", description = "Idea not found")
    })
    @GetMapping("/{id}")
    public ResponseEntity<IdeaSubmissionResponse> getIdeaById(@PathVariable String id) {
        log.info("Received request to get idea with ID: {}", id);
        IdeaSubmissionResponse response = ideaSubmissionService.getIdeaById(id);
        return ResponseEntity.ok(response);
    }

    /**
     * Get all ideas with pagination.
     */
    @Operation(
            summary = "Get all ideas",
            description = "Retrieve all idea submissions with pagination and sorting support."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ideas retrieved successfully")
    })
    @GetMapping
    public ResponseEntity<Page<IdeaSubmissionResponse>> getAllIdeas(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "submissionDate") String sortBy,
            @RequestParam(defaultValue = "DESC") String sortDirection) {
        log.info("Received request to get all ideas - page: {}, size: {}", page, size);

        Sort sort = sortDirection.equalsIgnoreCase("ASC")
                ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);

        Page<IdeaSubmissionResponse> response = ideaSubmissionService.getAllIdeas(pageable);
        return ResponseEntity.ok(response);
    }


    /**
     * Delete an idea.
     */
    @Operation(
            summary = "Delete an idea",
            description = "Delete an idea submission by ID."
    )
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteIdea(
            @PathVariable String id) {
        log.info("Received request to delete idea ID: {}", id);
        ideaSubmissionService.deleteIdea(id);
        return ResponseEntity.noContent().build();
    }

}

