package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.ContactDTO;
import com.hireright.sourceintelligence.api.dto.SearchResponseDTO;
import com.hireright.sourceintelligence.api.dto.SearchDTO;
import com.hireright.sourceintelligence.api.dto.UserInfo;

public interface ContactService  {
	void updateContact(ContactDTO contactDTO, UserInfo userInfo);
	SearchResponseDTO getSourceContactListByHon(SearchDTO searchDTO);

}
