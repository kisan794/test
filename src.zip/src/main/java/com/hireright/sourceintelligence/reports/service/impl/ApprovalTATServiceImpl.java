package com.hireright.sourceintelligence.reports.service.impl;

import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.reports.domain.entity.Reports;
import com.hireright.sourceintelligence.reports.domain.entity.ReportSearchResult;
import com.hireright.sourceintelligence.reports.domain.entity.ResponseReport;
import com.hireright.sourceintelligence.reports.domain.entity.TATReport;
import com.hireright.sourceintelligence.reports.domain.mapper.ReportMapper;
import com.hireright.sourceintelligence.reports.dto.GenericResponseDTO;
import com.hireright.sourceintelligence.reports.dto.MetaDTO;
import com.hireright.sourceintelligence.reports.dto.ReportResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;
import com.hireright.sourceintelligence.reports.service.ApprovalTATService;
import com.hireright.sourceintelligence.service.impl.QueryBuilder;
import com.hireright.sourceintelligence.service.impl.helperservices.CountryRegionMappingUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.AUTO_APPOVED;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.REPORTS_COLLECTION;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.APPROVED;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.TAT_REPORT_LIST;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.ReportTypes.APPROVAL_TAT;
import static com.hireright.sourceintelligence.reports.service.impl.ReportUtils.getMetaDataByReport;

@Slf4j
@RequiredArgsConstructor
@Service
public class ApprovalTATServiceImpl implements ApprovalTATService {

    private final ReportMapper reportMapper;
    private final CustomSourceRepository<Reports> customSourceRepository;
    private final CountryRegionMappingUtils countryRegionMappingUtils;

    @Override
    public ReportResponseDTO getApprovalAverageTAT(ReportsRequestDTO reportsRequestDTO) {
        List<String> countryList = null;
        if(reportsRequestDTO.getRegion() != null && !reportsRequestDTO.getRegion().isEmpty()){
            countryList = countryRegionMappingUtils.findDistinctCountriesByRegion(reportsRequestDTO.getRegion());
        }
        Criteria criteria = ReportsQueryBuilder.queryBuilderForApprovalTat(reportsRequestDTO, countryList);
        MatchOperation matchOperation = ReportsQueryBuilder.matchOperation(criteria);

        Criteria criteria2 = ReportsQueryBuilder.queryBuilderForTatFilter();
        MatchOperation matchOperation2 = ReportsQueryBuilder.matchOperation(criteria2);

        ProjectionOperation projectionOperation = ReportsQueryBuilder.excludeProjection();
        GroupOperation groupOperation = ReportsQueryBuilder.approvalTATGroupOperation();
        SortOperation sortOperation = ReportsQueryBuilder.buildSortOperationForTAT(reportsRequestDTO.getSort(), reportsRequestDTO.getOrder());
        FacetOperation facetOperation = ReportsQueryBuilder.facetOperation(reportsRequestDTO.getStartPage(), reportsRequestDTO.getBatchSize());
        if(!reportsRequestDTO.getSort().isEmpty()){
            facetOperation = ReportsQueryBuilder.facetOperationWithSorting(sortOperation, reportsRequestDTO.getStartPage(), reportsRequestDTO.getBatchSize());
        }
        ProjectionOperation finalProject = ReportsQueryBuilder.finalProjectionWithTotalCountInPipeline(TAT_REPORT_LIST);

        AggregationOptions aggregationOptionsToAllowDiskUse = AggregationOptions.builder()
                .allowDiskUse(true).build();
        Aggregation aggregation;
        aggregation = Aggregation.newAggregation(matchOperation,projectionOperation, groupOperation, matchOperation2, facetOperation, finalProject).withOptions(aggregationOptionsToAllowDiskUse);
        log.info("Aggregation:{}",aggregation);

        var response = customSourceRepository.reportCustomAggregate(aggregation,REPORTS_COLLECTION, ReportSearchResult.class);
        log.info("Response: {}", response);
        List<GenericResponseDTO> responseDTOS = new ArrayList<>();
        var res = timeCalculations(response.getTatResponseReportList());
        if(!res.isEmpty()){
            responseDTOS = reportMapper.toDTOList(res);
            if(reportsRequestDTO.getSort() != null && !reportsRequestDTO.getSort().isEmpty() && (reportsRequestDTO.getSort().equalsIgnoreCase("Approval_Status")|| reportsRequestDTO.getSort().equalsIgnoreCase("Action"))){
               sorting(responseDTOS, reportsRequestDTO);
            }
        }
        List<MetaDTO> metaDTOList = getMetaDataByReport(APPROVAL_TAT);
        return pagination(responseDTOS, metaDTOList, reportsRequestDTO);

    }
    private ReportResponseDTO pagination(List<GenericResponseDTO> responseDTOS, List<MetaDTO> metaDTOList, ReportsRequestDTO reportsRequestDTO){

        int page = reportsRequestDTO.getStartPage();   // assuming 1-based index
        int size = reportsRequestDTO.getBatchSize();

        int totalItems = responseDTOS.size();
        int totalPages = QueryBuilder.getTotalPages(totalItems, size);

        // Convert to zero-based index
        int fromIndex = (page - 1) * size;
        int toIndex = Math.min(fromIndex + size, totalItems);

        List<GenericResponseDTO> paginatedList;

        if (fromIndex >= totalItems || fromIndex < 0) {
            paginatedList = Collections.emptyList();
        } else {
            paginatedList = responseDTOS.subList(fromIndex, toIndex);
        }

        return ReportResponseDTO.builder().
                meta(metaDTOList).response(paginatedList)
                .currentPage(reportsRequestDTO.getStartPage())
                .totalItems(totalItems)
                .totalPages(totalPages)
                .reportType(APPROVAL_TAT).build();
    }

    private List<ResponseReport> timeCalculations(List<TATReport> tatReportList){
        List<ResponseReport> responseReportList = new ArrayList<>();
        for (TATReport tatReport : tatReportList) {
            if(!tatReport.getData().isEmpty()){
                int dataSize = tatReport.getData().size();
                Instant startDate = null;
                Instant tempDate = null;
                long totalMinutes = 0;
                long minutes = 0;
                String action = "";
                boolean roundActive = false;
                Instant endDate = null;
                for (int i = 0; i < dataSize; i++) {
                    ResponseReport rsReport = tatReport.getData().get(i);
                    String status = rsReport.getApprovalStatus();
                    if (dataSize == 1 && rsReport.getApprovalStatus().equalsIgnoreCase(APPROVED)) {
                        rsReport.setApprovalDuration(String.valueOf(0));
                        rsReport.setTotalApprovalDuration(String.valueOf(0));
                        responseReportList.add(rsReport);
                    } else {
                    if (status.equals(ApprovalStatus.PENDING_APPROVAL.getStatus())
                            || status.equals(ApprovalStatus.SAVE_PENDING_APPROVAL.getStatus())) {
                        action = rsReport.getAction();
                        startDate = rsReport.getCreatedDate();
                        roundActive = true;
                        tempDate = null;
                        minutes = 0;
                        totalMinutes = 0;
                    } else if (status.equals(ApprovalStatus.IN_PROGRESS.getStatus())) {
                        tempDate = rsReport.getCreatedDate();
                    } else if (status.equals(ApprovalStatus.ONHOLD.getStatus())) {
                        if (tempDate != null && rsReport.getCreatedDate() != null) {
                            minutes += Math.abs(Duration.between(tempDate,
                                    rsReport.getCreatedDate()).toMillis());
                        }
                        tempDate = rsReport.getCreatedDate();
                    } else if (status.equals(ApprovalStatus.APPROVED.getStatus())
                            || status.equals(ApprovalStatus.REJECTED.getStatus())) {
                        if (roundActive) {
                            endDate = rsReport.getCreatedDate();
                            if (tempDate != null) {
                                minutes += Math.abs(Duration.between(tempDate,
                                        rsReport.getCreatedDate()).toMillis());
                            }
                            if (startDate != null && endDate != null && startDate.isBefore(endDate)) {
                                totalMinutes = Math.abs(Duration.between(startDate, endDate).toMillis());
                            }

                            if (!rsReport.getAction().equals(action) && action != null && !action.isEmpty()) {
                                rsReport.setAction(action);
                            }
                            rsReport.setApprovalDuration(String.valueOf(minutes));
                            rsReport.setTotalApprovalDuration(String.valueOf(totalMinutes));
                            responseReportList.add(rsReport);
                            roundActive = false;
                        }else{
                            if(rsReport.getReason().equalsIgnoreCase(AUTO_APPOVED)){
                                rsReport.setApprovalDuration(String.valueOf(0));
                                rsReport.setTotalApprovalDuration(String.valueOf(0));
                                responseReportList.add(rsReport);
                            }
                        }
                    }
                }
                }
            }
        }
        return responseReportList;
    }

    private void sorting(List<GenericResponseDTO> responseDTOS, ReportsRequestDTO reportsRequestDTO){
            String sortField = reportsRequestDTO.getSort();
            String sortOrder = reportsRequestDTO.getOrder(); // "ASC" or "DESC"

            Comparator<GenericResponseDTO> comparator = null;
            switch (sortField) {
                case "Approval_Status":
                    comparator = Comparator.comparing(GenericResponseDTO::getApprovalStatus,
                            Comparator.nullsLast(String::compareTo));
                    break;
                case "Action":
                    comparator = Comparator.comparing(GenericResponseDTO::getAction,
                            Comparator.nullsLast(String::compareTo));
                    break;
                default:
                    break;
            }

            if (comparator != null) {
                if ("DESC".equalsIgnoreCase(sortOrder)) {
                    comparator = comparator.reversed();
                }
                responseDTOS.sort(comparator);
            }
        }

}
