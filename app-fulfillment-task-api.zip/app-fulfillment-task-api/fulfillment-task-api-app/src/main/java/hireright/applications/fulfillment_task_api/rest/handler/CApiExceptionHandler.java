package hireright.applications.fulfillment_task_api.rest.handler;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-13  HRG-332327 initial version
 */

import hireright.applications.fulfillment_task_api.model.CErrorResource;
import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.ErrorResponse;
import hireright.applications.fulfillment_task_api.rest.recombointegration.exception.ValidationException;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.exception.DataExchangeLoggerException;
import hireright.lib.logging.log_trace.CTraceLogger;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.server.ResponseStatusException;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

import static org.springframework.http.HttpStatus.GATEWAY_TIMEOUT;

@RestControllerAdvice
public class CApiExceptionHandler {
    @ExceptionHandler (ResponseStatusException.class)
    public ResponseEntity<CErrorResource> handleStatus(ResponseStatusException e, WebRequest request) {
        CErrorResource.Builder error = new CErrorResource.Builder();
        error.error(e.getMessage(), e.getReason());

        return ResponseEntity.status(e.getStatusCode().value()).body(error.build());
    }

    @ExceptionHandler (HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<CErrorResource> handleStatus(HttpRequestMethodNotSupportedException e, WebRequest request) {
        CErrorResource.Builder error = new CErrorResource.Builder();
        error.error("Bad Request", e.getMessage());

        return new ResponseEntity<>(error.build(), HttpStatus.METHOD_NOT_ALLOWED);
    }

    @ExceptionHandler ({IllegalArgumentException.class, MissingRequestHeaderException.class})
    public ResponseEntity<CErrorResource> handleBadRequest(Exception e, WebRequest request) {
        CErrorResource.Builder error = new CErrorResource.Builder();
        error.error("Bad Request", e.getMessage());

        return new ResponseEntity<>(error.build(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler (RuntimeException.class)
    public ResponseEntity<CErrorResource> handleRuntimeException(RuntimeException e, WebRequest request) {
        Throwable cause = Optional.ofNullable(e.getCause()).orElse(e);

        if (cause == e) {
            return handleServerException(cause, request);
        }

        if (cause instanceof ResponseStatusException) {
            return handleStatus((ResponseStatusException) cause, request);
        }
        else if (cause instanceof IllegalArgumentException) {
            return handleBadRequest((RuntimeException) cause, request);
        }
        else if (cause instanceof RuntimeException) {
            return handleRuntimeException((RuntimeException) cause, request);
        }

        return handleServerException(cause, request);
    }

    @ExceptionHandler (Throwable.class)
    public ResponseEntity<CErrorResource> handleServerException(Throwable e, WebRequest request) {
        Map<String, ?> parameters = getRequestParameters(request);

        long lLogID = CTraceLogger.error(e, this.getClass().getName(), parameters);

        CErrorResource.Builder error = new CErrorResource.Builder();
        error.error("Unexpected server error: " + lLogID);

        return new ResponseEntity<>(error.build(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    private Map<String, ?> getRequestParameters(WebRequest request) {
        Map<String, Object> parameters = new LinkedHashMap<>();

        try {
            Iterator<String> parameterNames = request.getParameterNames();
            while (parameterNames.hasNext() && !Thread.currentThread().isInterrupted()) {
                String sParameter = parameterNames.next();
                parameters.put(sParameter, request.getParameter(sParameter));
            }

            HttpServletRequest servletRequest = ((ServletWebRequest) request).getRequest();

            String sQueryString = servletRequest.getQueryString();

            parameters.put("url", servletRequest.getRequestURL() +
                    (sQueryString != null && !sQueryString.trim().isEmpty() ? "?" + sQueryString : ""));
        } catch (Exception ignored) {
        }

        return parameters;
    }

    /**
     * Handle validation errors (400 Bad Request)
     */
	@ExceptionHandler(ValidationException.class)
	public ResponseEntity<ErrorResponse> handleValidationException(ValidationException ex) {

		ErrorResponse errorResponse = ErrorResponse.validationError(
			ex.getRequestId(),
			ex.getMessage(),
			ex.getDetails()
		);
        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

    @ExceptionHandler(DataExchangeLoggerException.class)
    public ResponseEntity<ErrorResponse> handleDataExchangeLoggerException(final DataExchangeLoggerException ex) {
        ErrorResponse errorResponse = ErrorResponse.genericError(ex.transactionId(), null, GATEWAY_TIMEOUT.value(), ex.getMessage(), GATEWAY_TIMEOUT.getReasonPhrase(),
            ex.getMessage());
        return new ResponseEntity<>(errorResponse, GATEWAY_TIMEOUT);
    }
}
