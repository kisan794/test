package org.hireright.service;

import com.mongodb.DBObject;
import com.mongodb.bulk.BulkWriteResult;
import lombok.Data;
import org.hireright.api.dto.Alias;
import org.hireright.config.MongoDBConfig;
import org.hireright.config.MongoDBConstants;
import org.hireright.domain.entity.Source;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.util.Pair;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

public class EducationSourceMigrationService {
    private static final Logger logger = LoggerFactory.getLogger(EducationSourceMigrationService.class);

    private final MongoDBConfig config;
    private final MongoTemplate devMongoTemplate;
    private final MongoTemplate testMongoTemplate;

    @Data
    public static class MigrationStats {
        private long totalProcessed = 0;
        private long insertedFromDev = 0;
        private long insertedFromTest = 0;
        private long updatedFromDev = 0;
        private long updatedFromTest = 0;
        private long skipped = 0;
        private long skippedSimilar = 0;
        private long errors = 0;
    }

    public EducationSourceMigrationService(MongoDBConfig config,
                                           MongoTemplate devMongoTemplate,
                                           MongoTemplate testMongoTemplate) {
        this.config = config;
        this.devMongoTemplate = devMongoTemplate;
        this.testMongoTemplate = testMongoTemplate;
    }

    public MigrationStats migrateByHon() {
        MigrationStats stats = new MigrationStats();
        createIndexes();

        Query query = new Query();
        long totalRecords = devMongoTemplate.count(query, Source.class, MongoDBConstants.DEV_SOURCE_COLLECTION);
        logger.info("Total records to process by HON: {}", totalRecords);

        List<Source> batch = new ArrayList<>();
        int batchSize = config.getBatchSize();
        int skip = 0;

        try {
            while (true) {
                Query paginatedQuery = new Query().skip(skip).limit(batchSize);
                List<Source> records = devMongoTemplate.find(paginatedQuery, Source.class, MongoDBConstants.DEV_SOURCE_COLLECTION);

                if (records.isEmpty()) {
                    break;
                }

                batch.addAll(records);

                if (batch.size() >= batchSize) {
                    processBatchByHon(batch, stats, totalRecords);
                    batch.clear();
                }

                skip += records.size();

                if (stats.getTotalProcessed() % config.getLogFrequency() == 0) {
                    logProgress(stats, totalRecords);
                }

            }

            if (!batch.isEmpty()) {
                processBatchByHon(batch, stats, totalRecords);
            }

        } catch (Exception e) {
            logger.error("Error during HON migration", e);
            stats.setErrors(stats.getErrors() + 1);
        }

        logFinalStats(stats);
        return stats;
    }

    public MigrationStats migrateBy8Params() {
        MigrationStats stats = new MigrationStats();

        Query query = new Query();
        long totalRecords = devMongoTemplate.count(query, Source.class, MongoDBConstants.DEV_SOURCE_COLLECTION);
        logger.info("Total records to process by 8 params: {}", totalRecords);

        List<Source> batch = new ArrayList<>();
        int batchSize = config.getBatchSize();
        int skip = 0;

        try {
            while (true) {
                Query paginatedQuery = new Query().skip(skip).limit(batchSize);
                List<Source> records = devMongoTemplate.find(paginatedQuery, Source.class, MongoDBConstants.DEV_SOURCE_COLLECTION);

                if (records.isEmpty()) {
                    break;
                }

                batch.addAll(records);

                if (batch.size() >= batchSize) {
                    processBatchBy8Params(batch, stats, totalRecords);
                    batch.clear();
                }

                skip += records.size();

                if (stats.getTotalProcessed() % config.getLogFrequency() == 0) {
                    logProgress(stats, totalRecords);
                }
            }

            if (!batch.isEmpty()) {
                processBatchBy8Params(batch, stats, totalRecords);
            }

        } catch (Exception e) {
            logger.error("Error during 8-params migration", e);
            stats.setErrors(stats.getErrors() + 1);
        }

        logFinalStats(stats);
        return stats;
    }

    private void processBatchByHon(List<Source> batch, MigrationStats stats, long totalRecords) {
        try {
            List<String> hons = batch.stream()
                    .map(Source::getHon)
                    .filter(Objects::nonNull)
                    .filter(h -> !h.trim().isEmpty())
                    .collect(Collectors.toList());

            if (hons.isEmpty()) {
                stats.setTotalProcessed(stats.getTotalProcessed() + batch.size());
                stats.setSkipped(stats.getSkipped() + batch.size());
                return;
            }

            Map<String, Source> testRecordsMap = bulkQueryByHons(testMongoTemplate, MongoDBConstants.TEST_SOURCE_COLLECTION, hons);
            Map<String, Source> finalRecordsMap = bulkQueryByHons(devMongoTemplate, MongoDBConstants.DEV_FINAL_COLLECTION, hons);

            List<Pair<Query, Source>> updates = new ArrayList<>();
            List<Source> inserts = new ArrayList<>();

            for (Source devSource : batch) {
                stats.setTotalProcessed(stats.getTotalProcessed() + 1);

                String hon = devSource.getHon();
                if (hon == null || hon.trim().isEmpty()) {
                    stats.setSkipped(stats.getSkipped() + 1);
                    continue;
                }

                Source testSource = testRecordsMap.get(hon);
                Source existingFinal = finalRecordsMap.get(hon);

                processRecord(devSource, testSource, existingFinal, updates, inserts, stats);
            }

            executeBulkOperations(updates, inserts);

        } catch (Exception e) {
            logger.error("Error processing batch by HON", e);
            stats.setErrors(stats.getErrors() + 1);
        }
    }

    private void processBatchBy8Params(List<Source> batch, MigrationStats stats, long totalRecords) {
        try {
            Map<String, Source> testRecordsMap = bulkQueryBy8Params(testMongoTemplate, MongoDBConstants.TEST_SOURCE_COLLECTION, batch);
            Map<String, Source> finalRecordsMap = bulkQueryBy8Params(devMongoTemplate, MongoDBConstants.DEV_FINAL_COLLECTION, batch);

            List<Pair<Query, Source>> updates = new ArrayList<>();
            List<Source> inserts = new ArrayList<>();

            for (Source devSource : batch) {
                stats.setTotalProcessed(stats.getTotalProcessed() + 1);

                String key = buildParamsKey(devSource);
                Source testSource = testRecordsMap.get(key);
                Source existingFinal = finalRecordsMap.get(key);

                processRecordBy8Params(devSource, testSource, existingFinal, updates, inserts, stats);
            }

            executeBulkOperations(updates, inserts);

        } catch (Exception e) {
            logger.error("Error processing batch by 8 params", e);
            stats.setErrors(stats.getErrors() + 1);
        }
    }

    private Map<String, Source> bulkQueryByHons(MongoTemplate mongoTemplate, String collectionName, List<String> hons) {
        Map<String, Source> result = new HashMap<>();
        int chunkSize = config.getBatchSize();

        for (int i = 0; i < hons.size(); i += chunkSize) {
            List<String> chunk = hons.subList(i, Math.min(hons.size(), i + chunkSize));
            Query query = new Query(Criteria.where("hon").in(chunk));
            List<Source> sources = mongoTemplate.find(query, Source.class, collectionName);

            for (Source source : sources) {
                if (source.getHon() != null) {
                    String hon = source.getHon();
                    Source existing = result.get(hon);

                    if (existing == null) {
                        result.put(hon, source);
                    } else {
                        Source better = compareRecords(source, existing);
                        result.put(hon, better);
                    }
                }
            }
        }

        return result;
    }

    private Map<String, Source> bulkQueryBy8Params(MongoTemplate mongoTemplate, String collectionName, List<Source> sources) {
        Map<String, Source> result = new HashMap<>();

        for (Source source : sources) {
            Criteria criteria = new Criteria();
            List<Criteria> andCriteria = new ArrayList<>();

            andCriteria.add(Criteria.where("organizationName").is(source.getOrganizationName()));
            andCriteria.add(Criteria.where("country").is(source.getCountry()));
            andCriteria.add(Criteria.where("state").is(source.getState()));
            andCriteria.add(Criteria.where("city").is(source.getCity()));
            andCriteria.add(Criteria.where("postalCode").is(source.getPostalCode()));

            if (source.getOrganizationAlias() != null && source.getOrganizationAlias().length > 0) {
                andCriteria.add(Criteria.where("organizationAlias").is(source.getOrganizationAlias()));
            }

            String deptName = getPayloadString(source, "departmentName");
            if (deptName != null) {
                andCriteria.add(Criteria.where("payload.departmentName").is(deptName));
            }

            String addressLine = getAddressLine(source);
            if (addressLine != null) {
                andCriteria.add(Criteria.where("payload.address.0.line").is(addressLine));
            }

            criteria.andOperator(andCriteria.toArray(new Criteria[0]));

            Query query = new Query(criteria);
            List<Source> matches = mongoTemplate.find(query, Source.class, collectionName);

            String key = buildParamsKey(source);
            for (Source match : matches) {
                Source existing = result.get(key);

                if (existing == null) {
                    result.put(key, match);
                } else {
                    Source better = compareRecords(match, existing);
                    result.put(key, better);
                }
            }
        }

        return result;
    }

    private String buildParamsKey(Source source) {
        StringBuilder sb = new StringBuilder();
        sb.append(source.getOrganizationName()).append("|");
        sb.append(source.getCountry()).append("|");
        sb.append(source.getState()).append("|");
        sb.append(source.getCity()).append("|");
        sb.append(source.getPostalCode()).append("|");

        if (source.getOrganizationAlias() != null && source.getOrganizationAlias().length > 0) {
            for (Alias alias : source.getOrganizationAlias()) {
                sb.append(alias.getName()).append(",");
            }
        }
        sb.append("|");

        String deptName = getPayloadString(source, "departmentName");
        sb.append(deptName != null ? deptName : "").append("|");

        String addressLine = getAddressLine(source);
        sb.append(addressLine != null ? addressLine : "");

        return sb.toString();
    }

    private Query build8ParamsQuery(Source source) {
        Criteria criteria = new Criteria();
        List<Criteria> andCriteria = new ArrayList<>();

        andCriteria.add(Criteria.where("organizationName").is(source.getOrganizationName()));
        andCriteria.add(Criteria.where("country").is(source.getCountry()));
        andCriteria.add(Criteria.where("state").is(source.getState()));
        andCriteria.add(Criteria.where("city").is(source.getCity()));
        andCriteria.add(Criteria.where("postalCode").is(source.getPostalCode()));

        if (source.getOrganizationAlias() != null && source.getOrganizationAlias().length > 0) {
            andCriteria.add(Criteria.where("organizationAlias").is(source.getOrganizationAlias()));
        }

        String deptName = getPayloadString(source, "departmentName");
        if (deptName != null) {
            andCriteria.add(Criteria.where("payload.departmentName").is(deptName));
        }

        String addressLine = getAddressLine(source);
        if (addressLine != null) {
            andCriteria.add(Criteria.where("payload.address.0.line").is(addressLine));
        }

        criteria.andOperator(andCriteria.toArray(new Criteria[0]));
        return new Query(criteria);
    }

    private void processRecord(Source devSource, Source testSource, Source existingFinal,
                               List<Pair<Query, Source>> updates, List<Source> inserts,
                               MigrationStats stats) {
        try {
            if (testSource == null) {
                handleRecordNotInTest(devSource, existingFinal, updates, inserts, stats);
            } else {
                handleRecordInTest(devSource, testSource, existingFinal, updates, inserts, stats);
            }
        } catch (Exception e) {
            logger.error("Error processing record for HON: {}", devSource.getHon(), e);
            stats.setErrors(stats.getErrors() + 1);
        }
    }

    private void processRecordBy8Params(Source devSource, Source testSource, Source existingFinal,
                                        List<Pair<Query, Source>> updates, List<Source> inserts,
                                        MigrationStats stats) {
        try {
            if (testSource == null) {
                handleRecordNotInTestBy8Params(devSource, existingFinal, updates, inserts, stats);
            } else {
                handleRecordInTestBy8Params(devSource, testSource, existingFinal, updates, inserts, stats);
            }
        } catch (Exception e) {
            logger.error("Error processing record by 8 params", e);
            stats.setErrors(stats.getErrors() + 1);
        }
    }

    private void handleRecordNotInTest(Source devSource, Source existingFinal,
                                       List<Pair<Query, Source>> updates, List<Source> inserts,
                                       MigrationStats stats) {
        if (existingFinal == null) {
            inserts.add(devSource);
            stats.setInsertedFromDev(stats.getInsertedFromDev() + 1);
        } else {

            Source winner = compareRecords(devSource, existingFinal);

            if (winner == devSource) {
                Query query = new Query(Criteria.where("hon").is(devSource.getHon()));
                updates.add(Pair.of(query, devSource));
                stats.setUpdatedFromDev(stats.getUpdatedFromDev() + 1);
            } else {
                stats.setSkipped(stats.getSkipped() + 1);
            }
        }
    }

    private void handleRecordInTest(Source devSource, Source testSource, Source existingFinal,
                                    List<Pair<Query, Source>> updates, List<Source> inserts,
                                    MigrationStats stats) {
        Source chosenSource = compareRecords(devSource, testSource);
        boolean isFromDev = (chosenSource == devSource);

        if (existingFinal == null) {
            inserts.add(chosenSource);
            if (isFromDev) {
                stats.setInsertedFromDev(stats.getInsertedFromDev() + 1);
            } else {
                stats.setInsertedFromTest(stats.getInsertedFromTest() + 1);
            }
        } else {

            Source winner = compareRecords(chosenSource, existingFinal);

            if (winner == chosenSource) {
                Query query = new Query(Criteria.where("hon").is(chosenSource.getHon()));
                updates.add(Pair.of(query, chosenSource));
                if (isFromDev) {
                    stats.setUpdatedFromDev(stats.getUpdatedFromDev() + 1);
                } else {
                    stats.setUpdatedFromTest(stats.getUpdatedFromTest() + 1);
                }
            } else {
                stats.setSkipped(stats.getSkipped() + 1);
            }
        }
    }

    private void handleRecordNotInTestBy8Params(Source devSource, Source existingFinal,
                                                List<Pair<Query, Source>> updates, List<Source> inserts,
                                                MigrationStats stats) {
        if (existingFinal == null) {
            inserts.add(devSource);
            stats.setInsertedFromDev(stats.getInsertedFromDev() + 1);
        } else {
            Source winner = compareRecords(devSource, existingFinal);

            if (winner == devSource) {
                Query query = build8ParamsQuery(devSource);
                updates.add(Pair.of(query, devSource));
                stats.setUpdatedFromDev(stats.getUpdatedFromDev() + 1);
            } else {
                stats.setSkipped(stats.getSkipped() + 1);
            }
        }
    }

    private void handleRecordInTestBy8Params(Source devSource, Source testSource, Source existingFinal,
                                             List<Pair<Query, Source>> updates, List<Source> inserts,
                                             MigrationStats stats) {
        Source chosenSource = compareRecords(devSource, testSource);
        boolean isFromDev = (chosenSource == devSource);

        if (existingFinal == null) {
            inserts.add(chosenSource);
            if (isFromDev) {
                stats.setInsertedFromDev(stats.getInsertedFromDev() + 1);
            } else {
                stats.setInsertedFromTest(stats.getInsertedFromTest() + 1);
            }
        } else {
            Source winner = compareRecords(chosenSource, existingFinal);

            if (winner == chosenSource) {
                Query query = build8ParamsQuery(chosenSource);
                updates.add(Pair.of(query, chosenSource));
                if (isFromDev) {
                    stats.setUpdatedFromDev(stats.getUpdatedFromDev() + 1);
                } else {
                    stats.setUpdatedFromTest(stats.getUpdatedFromTest() + 1);
                }
            } else {
                stats.setSkipped(stats.getSkipped() + 1);
            }
        }
    }

    private void handleSimilarRecords(Source source, Source existingFinal,
                                      List<Pair<Query, Source>> updates, List<Source> inserts,
                                      MigrationStats stats, boolean isFromDev) {
        if (existingFinal == null) {
            inserts.add(source);
            if (isFromDev) {
                stats.setInsertedFromDev(stats.getInsertedFromDev() + 1);
            } else {
                stats.setInsertedFromTest(stats.getInsertedFromTest() + 1);
            }
        } else {
            if (isSimilar(source, existingFinal)) {
                stats.setSkippedSimilar(stats.getSkippedSimilar() + 1);
            } else {
                Source winner = compareRecords(source, existingFinal);

                if (winner == source) {
                    Query query = new Query(Criteria.where("hon").is(source.getHon()));
                    updates.add(Pair.of(query, source));
                    if (isFromDev) {
                        stats.setUpdatedFromDev(stats.getUpdatedFromDev() + 1);
                    } else {
                        stats.setUpdatedFromTest(stats.getUpdatedFromTest() + 1);
                    }
                } else {
                    stats.setSkipped(stats.getSkipped() + 1);
                }
            }
        }
    }




    private boolean isSimilar(Source source1, Source source2) {
        if (source1 == null || source2 == null) {
            return false;
        }

        boolean orgNameMatch = areFieldsEqual(source1.getOrganizationName(), source2.getOrganizationName());
        boolean aliasMatch = areAliasesEqual(source1.getOrganizationAlias(), source2.getOrganizationAlias());
        boolean deptMatch = areFieldsEqual(getPayloadString(source1, "departmentName"), getPayloadString(source2, "departmentName"));
        boolean countryMatch = areFieldsEqual(source1.getCountry(), source2.getCountry());
        boolean stateMatch = areFieldsEqual(source1.getState(), source2.getState());
        boolean cityMatch = areFieldsEqual(source1.getCity(), source2.getCity());
        boolean addressMatch = areFieldsEqual(getAddressLine(source1), getAddressLine(source2));
        boolean postalCodeMatch = areFieldsEqual(source1.getPostalCode(), source2.getPostalCode());

        return orgNameMatch && aliasMatch && deptMatch && countryMatch &&
               stateMatch && cityMatch && addressMatch && postalCodeMatch;
    }

    private boolean areFieldsEqual(String field1, String field2) {
        if (field1 == null && field2 == null) {
            return true;
        }
        if (field1 == null || field2 == null) {
            return false;
        }
        return field1.trim().equalsIgnoreCase(field2.trim());
    }

    private boolean areAliasesEqual(Alias[] aliases1, Alias[] aliases2) {
        if (aliases1 == null && aliases2 == null) {
            return true;
        }
        if (aliases1 == null || aliases2 == null) {
            return false;
        }
        if (aliases1.length != aliases2.length) {
            return false;
        }

        for (int i = 0; i < aliases1.length; i++) {
            String name1 = aliases1[i].getName();
            String name2 = aliases2[i].getName();
            if (!areFieldsEqual(name1, name2)) {
                return false;
            }
        }
        return true;
    }

    @SuppressWarnings("unchecked")
    private String getPayloadString(Source source, String field) {
        DBObject payload = source.getPayload();
        return payload != null ? (String) payload.get(field) : null;
    }

    @SuppressWarnings("unchecked")
    private String getAddressLine(Source source) {
        DBObject payload = source.getPayload();
        if (payload != null) {
            List<DBObject> addresses = (List<DBObject>) payload.get("address");
            if (addresses != null && !addresses.isEmpty()) {
                return (String) addresses.get(0).get("line");
            }
        }
        return null;
    }

    private Source compareRecords(Source source1, Source source2) {
        Integer usedCount1 = getUsedCount(source1);
        Integer usedCount2 = getUsedCount(source2);

        if (!usedCount1.equals(usedCount2)) {
            return usedCount1 > usedCount2 ? source1 : source2;
        }

        Instant date1 = source1.getLastActionDate();
        Instant date2 = source2.getLastActionDate();

        if (date1 == null && date2 == null) return source1;
        if (date1 == null) return source2;
        if (date2 == null) return source1;

        return date1.isAfter(date2) ? source1 : source2;
    }

    private Integer getUsedCount(Source source) {
        DBObject payload = source.getPayload();
        if (payload != null) {
            Object count = payload.get("usedCount");
            return count != null ? (Integer) count : 0;
        }
        return 0;
    }

    private void executeBulkOperations(List<Pair<Query, Source>> updates, List<Source> inserts) {
        int retries = 0;
        int maxRetries = config.getMaxRetries();
        long retryDelay = config.getRetryDelayMs();

        while (retries <= maxRetries) {
            try {
                BulkOperations bulkOps = devMongoTemplate.bulkOps(BulkOperations.BulkMode.UNORDERED,
                                                                   Source.class,
                                                                   MongoDBConstants.DEV_FINAL_COLLECTION);

                if (!inserts.isEmpty()) {
                    bulkOps.insert(inserts);
                }

                for (Pair<Query, Source> update : updates) {
                    bulkOps.replaceOne(update.getFirst(), update.getSecond());
                }

                BulkWriteResult result = bulkOps.execute();
                return;
            } catch (Exception e) {
                retries++;
                if (retries > maxRetries) {
                    logger.error("Bulk write failed after {} retries", maxRetries, e);
                    throw e;
                }
                try {
                    Thread.sleep(retryDelay * retries);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new RuntimeException("Interrupted during retry", ie);
                }
            }
        }
    }

    private void createIndexes() {
        try {
            devMongoTemplate.indexOps(MongoDBConstants.DEV_SOURCE_COLLECTION).ensureIndex(
                new org.springframework.data.mongodb.core.index.Index().on("hon", org.springframework.data.domain.Sort.Direction.ASC)
            );
            testMongoTemplate.indexOps(MongoDBConstants.TEST_SOURCE_COLLECTION).ensureIndex(
                new org.springframework.data.mongodb.core.index.Index().on("hon", org.springframework.data.domain.Sort.Direction.ASC)
            );
            devMongoTemplate.indexOps(MongoDBConstants.DEV_FINAL_COLLECTION).ensureIndex(
                new org.springframework.data.mongodb.core.index.Index().on("hon", org.springframework.data.domain.Sort.Direction.ASC)
            );
        } catch (Exception e) {
        }
    }

    private void logProgress(MigrationStats stats, long total) {
        double percentage = (stats.getTotalProcessed() * 100.0) / total;
        long totalInserted = stats.getInsertedFromDev() + stats.getInsertedFromTest();
        long totalUpdated = stats.getUpdatedFromDev() + stats.getUpdatedFromTest();
        long totalSkipped = stats.getSkipped() + stats.getSkippedSimilar();

        logger.info("Progress: {}/{} ({:.2f}%) | Inserted: {} | Updated: {} | Skipped: {} | Errors: {}",
                stats.getTotalProcessed(), total, percentage,
                totalInserted, totalUpdated, totalSkipped, stats.getErrors());
    }

    private void logFinalStats(MigrationStats stats) {
        logger.info("=== Migration Complete ===");
        logger.info("Total Processed: {}", stats.getTotalProcessed());
        logger.info("Inserted from Dev: {}", stats.getInsertedFromDev());
        logger.info("Inserted from Test: {}", stats.getInsertedFromTest());
        logger.info("Updated from Dev: {}", stats.getUpdatedFromDev());
        logger.info("Updated from Test: {}", stats.getUpdatedFromTest());
        logger.info("Skipped (better existing): {}", stats.getSkipped());
        logger.info("Skipped (similar records): {}", stats.getSkippedSimilar());
        logger.info("Errors: {}", stats.getErrors());

        long totalInserted = stats.getInsertedFromDev() + stats.getInsertedFromTest();
        long totalUpdated = stats.getUpdatedFromDev() + stats.getUpdatedFromTest();
        long totalSkipped = stats.getSkipped() + stats.getSkippedSimilar();

        logger.info("Summary: {} inserted, {} updated, {} skipped, {} errors",
                totalInserted, totalUpdated, totalSkipped, stats.getErrors());
    }
}
