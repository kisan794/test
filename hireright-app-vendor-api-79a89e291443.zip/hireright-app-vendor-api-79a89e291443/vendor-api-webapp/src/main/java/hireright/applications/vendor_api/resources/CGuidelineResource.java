/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-08-18	Created
 *	T.Prikk		2017-12-12	HIVPE-25392: fixed setLastModified and operatorName usage
 *	T.Prikk		2017-12-13	HIVPE-27588: fix conditions for appending 'Do NOT contact'
 *	T.Prikk		2017-12-13	HIVPE-27588: added optional parameter to skip appending 'Do NOT contact'
 *	T.Prikk		2018-01-30	HIVPE-31899: missing 'Do NOT contact' entry
 *	A.Logachyov	2018-02-05	Added package guidelines
 */
package hireright.applications.vendor_api.resources;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Callable;

import jakarta.servlet.http.HttpServletResponse;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.http.MediaType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import hireright.applications.vendor_api.exchange.handler.utils.CExchangeUtils;
import hireright.applications.vendor_api.model.CCustomerDTO;
import hireright.applications.vendor_api.model.CGuidelineApplicability;
import hireright.applications.vendor_api.model.CGuidelineDTO;
import hireright.applications.vendor_api.model.CGuidelinesResponse;
import hireright.objects.order2.COrderManager;
import hireright.objects.order2.COrderProperty;
import hireright.objects.order2.COrderService;
import hireright.objects.order2.COrderServiceManager;
import hireright.objects.users.CCustomer;
import hireright.objects.users.CCustomerFactory;
import hireright.objects.users.persistence.CCustomerGuideline;
import hireright.sdk.consts.Logical;
import hireright.sdk.db.CMultitenantDB;
import hireright.sdk.db3.DB;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CStringUtils;

@RestController
public class CGuidelineResource
{
	private static final int ADJUDICATION_SERVICE_ID = 95;

	private static final String ORDER_PROPERTY_ALLOW_CONTACT_APPL = "allowToContactApplicant";
	private static final String VERBIAGE_CANNOT_CONTACT_APPLICANT = "Do NOT contact applicant";

	@SuppressWarnings("serial")
	private static final class CMultiMap<K, V> extends LinkedMultiValueMap<K, V>
	{
		public void addFirst(K key, V value) {
			List<V> values = this.get(key);
			if (values != null)
			{
				values.add(0, value);
			}
			else
			{
				this.add(key, value);
			}
		}
	}

	@RequestMapping(path = "/orders/{orderRef}/services/{orderServiceRef}/guidelines",
			method = RequestMethod.GET,
			produces = MediaType.APPLICATION_XML_VALUE)
	public CGuidelinesResponse getGuidelines(
			@PathVariable(name="orderRef") final String sOrderRef,
			@PathVariable(name="orderServiceRef") final String sOrderServiceRef,
			@RequestParam(name="restrictToAdjudication", required=false, defaultValue="false") final boolean bRestrictToAdjudication,
			@RequestParam(name="skipDoNotContact", required=false, defaultValue="false") final boolean bSkipDoNotContact
		) throws Exception
	{
		String sTenantCode = CExchangeUtils.getTenantCodeByOrderCode(sOrderRef);

		return CMultitenantDB.execute(sTenantCode, () -> {

		return DB.execute(new Callable<CGuidelinesResponse>()
		{
			public CGuidelinesResponse call() throws Exception
			{
				DB.requestReadOnly();
				
				List<CGuidelineDTO> guidelines = new LinkedList<CGuidelineDTO>();
				CCustomerDTO customer = new CCustomerDTO();
				CGuidelinesResponse response = new CGuidelinesResponse();
				response.setGuidelines(guidelines);
				response.setCustomer(customer);
				
				Long nOrderID = hireright.objects.order.COrder.findOrderByRegID(DB.connection(), sOrderRef);
				if (nOrderID != null && nOrderID != 0)
				{
					Integer nCustomerID = COrderManager.getCustomerID(nOrderID);
					Integer nServiceID;
					
					if (bRestrictToAdjudication)
					{
						nServiceID = ADJUDICATION_SERVICE_ID;
					}
					else
					{
						Long nOrderServiceID = COrderServiceManager.getOrderServiceID(nOrderID, sOrderServiceRef);
						if (nOrderServiceID == null)
							return response;
						
						COrderService orderService = COrderServiceManager.loadOrderService(nOrderServiceID);
						nServiceID = orderService.getServiceID();
					}
					
					CCustomer customerData = CCustomerFactory.loadCustomer(nCustomerID);
					customer.setCustomerID(customerData.getID().longValue());
					customer.setAccountName(customerData.getAccountName());
					customer.setCompanyName(customerData.getCompanyName());
					customer.setCanContactApplicant(customerData.isAllowedToCallApplicant());
					
					Criteria guidelineCriteria = DB.session().createCriteria(CCustomerGuideline.class);
					guidelineCriteria
						.add(Restrictions.eq("active", CCustomerGuideline.ACTIVE_YES));
					
					if (bRestrictToAdjudication)
					{
						guidelineCriteria
							.add(Restrictions.eq("customerID", nCustomerID.longValue()))
							.add(Restrictions.eq("serviceID", nServiceID));
					}
					else
					{
						//Human readable: customer_id = 123 and (service_id = 0 or service_id = 123)
						guidelineCriteria
							.add(Restrictions.and(Restrictions.eq("customerID", nCustomerID.longValue()), 
								Restrictions.or(Restrictions.eq("serviceID", nServiceID),Restrictions.eq("serviceID", 0))));
					}
					
					List<CCustomerGuideline> customerGuidelines = guidelineCriteria.list();
					
					Integer nPackID = COrderManager.getPackID(nOrderID);
					
					if ( nPackID != null )
					{
						List<CCustomerGuideline> packageGuidelines = DB.session().createCriteria(CCustomerGuideline.class)
							.add(Restrictions.eq("customerID", 0L))
							.add(Restrictions.eq("packID", nPackID))
							.add(Restrictions.eq("serviceID", 0))
							.list();
						
						if (!packageGuidelines.isEmpty())
						{
							Iterator<CCustomerGuideline> customerGuidelinesIterator = customerGuidelines.iterator();
							
							while (customerGuidelinesIterator.hasNext())
							{
								CCustomerGuideline customerGuideline = customerGuidelinesIterator.next();

								if (0 != customerGuideline.getCustomerID() && 0 == customerGuideline.getServiceID())
								{
									customerGuidelinesIterator.remove();
								}
							}
							
							customerGuidelines.add(packageGuidelines.get(0));
						}
					}
					
					// collect guidelines according to applicability
					CMultiMap<CGuidelineApplicability, CCustomerGuideline> mapAppToGLs = new CMultiMap<>();
					for (CCustomerGuideline customerGuideline : customerGuidelines)
					{
						CGuidelineApplicability applicability = null;
						
						if (customerGuideline.getPackID() != null && customerGuideline.getPackID() != 0)
						{
							applicability = new CGuidelineApplicability(0, nCustomerID.longValue());
						}
						else
						{
							applicability = new CGuidelineApplicability(customerGuideline.getServiceID(), customerGuideline.getCustomerID());
						}
						
						mapAppToGLs.add(applicability, customerGuideline);
					}
					
					if (!bSkipDoNotContact)
					{
						boolean bCustomerDeniesContact = !customer.getCanContactApplicant();
						COrderProperty orderProp = COrderProperty.loadPropertyByName(nOrderID, ORDER_PROPERTY_ALLOW_CONTACT_APPL);
						boolean bOrderDeniesContact = orderProp != null && Logical.NO_SHORT.equals(orderProp.getValue());
						
						if (bCustomerDeniesContact || bOrderDeniesContact)
						{
							// add 'Do NOT contact applicant' to guidelines
							CCustomerGuideline cannotContactGL = new CCustomerGuideline();
							cannotContactGL.setOperatorName(CStringUtils.EMPTY_STRING);
							cannotContactGL.setText(VERBIAGE_CANNOT_CONTACT_APPLICANT);
							cannotContactGL.setLastModified(new Date());
							
							mapAppToGLs.addFirst(CGuidelineApplicability.customerAndServiceSpecific(), cannotContactGL);
							mapAppToGLs.addFirst(CGuidelineApplicability.customerSpecific(), cannotContactGL);
						}
					}
					
					// each applicability should map to one guideline transfer-object
					for (CGuidelineApplicability applicability : mapAppToGLs.keySet())
					{
						CGuidelineDTO aggregateGuideline = new CGuidelineDTO();
						aggregateGuideline.setServiceApplicability(applicability.getServiceApplicability());
						aggregateGuideline.setCustomerApplicability(applicability.getCustomerApplicability());
						Date latestModificationDate = null;
						StringBuilder textBuf = new StringBuilder();
						Iterator<CCustomerGuideline> singleGuidelineIter = mapAppToGLs.get(applicability).iterator();
						while (singleGuidelineIter.hasNext())
						{
							CCustomerGuideline singleGuideline = singleGuidelineIter.next();
							textBuf.append(singleGuideline.getText());
							if (singleGuidelineIter.hasNext()) {
								textBuf.append("\r\n\r\n ");
							}
							
							String currOperatorName = singleGuideline.getOperatorName();
							Date currLastModified = singleGuideline.getLastModified();
							if (!CStringUtils.isEmpty(currOperatorName) && currLastModified != null)
							{
								if (latestModificationDate == null || latestModificationDate.before(currLastModified))
								{
									latestModificationDate = currLastModified;
									aggregateGuideline.setOperatorName(currOperatorName);
									aggregateGuideline.setLastModified(currLastModified);
								}
							}
						}
						
						aggregateGuideline.setText(textBuf.toString());
						guidelines.add(aggregateGuideline);
					}
				}
				
				return response;
			}
		});
		});
	}

	@ExceptionHandler({Exception.class})
	public void handleErrors(HttpServletResponse response, Exception e)
		throws IOException
	{
		Long nErrorID = CTraceLog.error(e);
		Document doc = DocumentHelper.createDocument();
		Element elRoot = doc.addElement("Error");
		elRoot.addAttribute("id", nErrorID.toString());
		elRoot.addElement("Message").setText(CStringUtils.nvl(e.getMessage()));
		
		response.setContentType(MediaType.APPLICATION_XML_VALUE);
		PrintWriter writer = response.getWriter();
		writer.write(doc.asXML());
		writer.flush();
	}
}
