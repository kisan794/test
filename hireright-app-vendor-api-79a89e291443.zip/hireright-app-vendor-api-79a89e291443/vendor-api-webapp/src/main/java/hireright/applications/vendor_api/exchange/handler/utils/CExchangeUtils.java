/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-08-14	Created
 *  H.Maibak	2025-03-11 HRG-332869 - refactored tenantCode retrieving methods
 */
package hireright.applications.vendor_api.exchange.handler.utils;

import java.util.concurrent.Callable;

import hireright.objects.order.COrder;
import hireright.objects.order2.COrderDBContainer;
import hireright.objects.order2.COrderServiceManager;
import hireright.sdk.db.CMultitenantDB;
import hireright.sdk.db3.DB;

public class CExchangeUtils
{
	public static Long getOrderServiceID(final Long nOrderID, final String sOrderServiceCode) throws Exception
	{
		return DB.execute(new Callable<Long>()
		{
			@Override
			public Long call() throws Exception
			{
				return COrderServiceManager.getOrderServiceID(nOrderID, sOrderServiceCode);
			}
		});
	}

	public static Long getOrderServiceID(final String sOrderCode, final String sOrderServiceCode) throws Exception
	{
		return DB.execute(new Callable<Long>()
		{
			@Override
			public Long call() throws Exception
			{
				Long nOrderID = COrder.findOrderByRegID(DB.connection(), sOrderCode);
				return COrderServiceManager.getOrderServiceID(nOrderID, sOrderServiceCode);
			}
		});
	}

	public static Long getOrderID(final String orderCode) throws Exception
	{
		return DB.execute(new Callable<Long>()
		{
			@Override
			public Long call() throws Exception
			{
				return COrder.findOrderByRegID(DB.connection(), orderCode);
			}
		});
	}
	
	public static String getTenantCodeByOrderID(Long nOrderID) throws Exception
	{
		return DB.execute(() -> CMultitenantDB.execute( () -> COrderDBContainer.getContainerIDByOrderID(nOrderID),
			targetTenantCode -> targetTenantCode ));
	}
	
	public static String getTenantCodeByOrderCode(String sCode) throws Exception
	{
		return DB.execute(() -> CMultitenantDB.execute(() -> COrderDBContainer.getContainerIDByOrderCode(sCode),
			targetTenantCode -> targetTenantCode));
	}
}
