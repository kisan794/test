package com.hireright.sourceintelligence.service.migration;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 * Factory for selecting the appropriate MigrationProcessor based on migration type.
 * Uses Spring's dependency injection to automatically discover all available processors.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class MigrationProcessorFactory {
    
    private final List<MigrationProcessor> processors;
    
    /**
     * Get the appropriate migration processor for the given type.
     * 
     * @param migrationType The migration type (e.g., "parchment", "clearinghouse")
     * @return The matching MigrationProcessor
     * @throws IllegalArgumentException if no processor is found for the given type
     */
    public MigrationProcessor getProcessor(String migrationType) {
        if (migrationType == null || migrationType.trim().isEmpty()) {
            throw new IllegalArgumentException("Migration type cannot be null or empty");
        }
        
        Optional<MigrationProcessor> processor = processors.stream()
            .filter(p -> p.supports(migrationType))
            .findFirst();
        
        if (processor.isEmpty()) {
            log.error("No migration processor found for type: {}", migrationType);
            throw new IllegalArgumentException(
                String.format("Unsupported migration type: '%s'. Available types: %s", 
                    migrationType, 
                    getSupportedTypes())
            );
        }
        
        log.info("Selected migration processor: {} for type: {}", 
            processor.get().getClass().getSimpleName(), migrationType);
        
        return processor.get();
    }
    
    /**
     * Get a comma-separated list of all supported migration types.
     * 
     * @return String containing all supported migration types
     */
    public String getSupportedTypes() {
        return processors.stream()
            .map(MigrationProcessor::getMigrationType)
            .reduce((a, b) -> a + ", " + b)
            .orElse("none");
    }
    
    /**
     * Check if a migration type is supported.
     * 
     * @param migrationType The migration type to check
     * @return true if supported, false otherwise
     */
    public boolean isSupported(String migrationType) {
        if (migrationType == null || migrationType.trim().isEmpty()) {
            return false;
        }
        
        return processors.stream()
            .anyMatch(p -> p.supports(migrationType));
    }
}

