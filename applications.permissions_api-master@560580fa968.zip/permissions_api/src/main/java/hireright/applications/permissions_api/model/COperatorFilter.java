package hireright.applications.permissions_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-17  HRG-330191 initial version
 */

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Objects;

public class COperatorFilter
{
	@JsonProperty("permission")
	private String m_sPermission;

	private COperatorFilter()
	{
	}

	private COperatorFilter(Builder builder)
	{
		m_sPermission = builder.m_sPermission;
	}

	public String getsPermission()
	{
		return m_sPermission;
	}

	@Override
	public String toString()
	{
		return "COperatorFilter{" + "m_sPermission='" + m_sPermission + '\'' + '}';
	}

	@Override
	public boolean equals(Object o)
	{
		if(this == o)
		{
			return true;
		}
		if(o == null || getClass() != o.getClass())
		{
			return false;
		}

		COperatorFilter that = (COperatorFilter) o;

		return Objects.equals(m_sPermission, that.m_sPermission);
	}

	@Override
	public int hashCode()
	{
		return m_sPermission != null ? m_sPermission.hashCode() : 0;
	}

	public static final class Builder
	{
		private String m_sPermission;

		public Builder()
		{
		}

		public Builder(COperatorFilter copy)
		{
			if(copy == null)
			{
				return;
			}

			this.m_sPermission = copy.getsPermission();
		}

		public Builder permission(String sPermission)
		{
			this.m_sPermission = sPermission;
			return this;
		}

		public COperatorFilter build()
		{
			return new COperatorFilter(this);
		}
	}
}
