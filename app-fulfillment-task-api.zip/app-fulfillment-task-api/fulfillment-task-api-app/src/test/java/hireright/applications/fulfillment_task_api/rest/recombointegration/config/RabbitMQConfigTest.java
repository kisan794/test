package hireright.applications.fulfillment_task_api.rest.recombointegration.config;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for RabbitMQConfig
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("RabbitMQConfig Tests")
class RabbitMQConfigTest {

    @Mock
    private ConnectionFactory connectionFactory;

    private RabbitMQConfig config;

    @BeforeEach
    void setUp() {
        config = new RabbitMQConfig();
        ReflectionTestUtils.setField(config, "screeningRequestsQueue", "screening.requests.queue");
        ReflectionTestUtils.setField(config, "screeningDlq", "screening.dlq");
        ReflectionTestUtils.setField(config, "concurrency", 5);
        ReflectionTestUtils.setField(config, "maxConcurrency", 10);
        ReflectionTestUtils.setField(config, "prefetchCount", 10);
    }

    @Test
    @DisplayName("Should create screening requests queue with DLQ configuration")
    void testScreeningRequestsQueue() {
        // When
        Queue queue = config.screeningRequestsQueue();

        // Then
        assertNotNull(queue);
        assertEquals("screening.requests.queue", queue.getName());
        assertTrue(queue.isDurable());
        assertEquals("", queue.getArguments().get("x-dead-letter-exchange"));
        assertEquals("screening.dlq", queue.getArguments().get("x-dead-letter-routing-key"));
    }

    @Test
    @DisplayName("Should create screening DLQ")
    void testScreeningDlq() {
        // When
        Queue queue = config.screeningDlq();

        // Then
        assertNotNull(queue);
        assertEquals("screening.dlq", queue.getName());
        assertTrue(queue.isDurable());
    }

    @Test
    @DisplayName("Should create rabbit listener container factory with correct configuration")
    void testRabbitListenerContainerFactory() {
        // When
        SimpleRabbitListenerContainerFactory factory = config.rabbitListenerContainerFactory(connectionFactory);

        // Then
        assertNotNull(factory);
        assertEquals(5, factory.getConcurrentConsumers());
        assertEquals(10, factory.getMaxConcurrentConsumers());
        assertEquals(10, factory.getPrefetchCount());
        assertFalse(factory.getDefaultRequeueRejected());
    }

    @Test
    @DisplayName("Should create JSON message converter")
    void testJsonMessageConverter() {
        // When
        MessageConverter converter = config.jsonMessageConverter();

        // Then
        assertNotNull(converter);
        assertEquals("org.springframework.amqp.support.converter.Jackson2JsonMessageConverter",
                converter.getClass().getName());
    }

    @Test
    @DisplayName("Should configure listener factory with custom concurrency values")
    void testListenerFactoryWithCustomConcurrency() {
        // Given
        ReflectionTestUtils.setField(config, "concurrency", 3);
        ReflectionTestUtils.setField(config, "maxConcurrency", 15);

        // When
        SimpleRabbitListenerContainerFactory factory = config.rabbitListenerContainerFactory(connectionFactory);

        // Then
        assertEquals(3, factory.getConcurrentConsumers());
        assertEquals(15, factory.getMaxConcurrentConsumers());
    }

    @Test
    @DisplayName("Should configure listener factory with custom prefetch count")
    void testListenerFactoryWithCustomPrefetchCount() {
        // Given
        ReflectionTestUtils.setField(config, "prefetchCount", 20);

        // When
        SimpleRabbitListenerContainerFactory factory = config.rabbitListenerContainerFactory(connectionFactory);

        // Then
        assertEquals(20, factory.getPrefetchCount());
    }

    @Test
    @DisplayName("Should set default requeue rejected to false")
    void testDefaultRequeueRejectedIsFalse() {
        // When
        SimpleRabbitListenerContainerFactory factory = config.rabbitListenerContainerFactory(connectionFactory);

        // Then
        assertFalse(factory.getDefaultRequeueRejected());
    }

    @Test
    @DisplayName("Should create queue with custom queue name")
    void testQueueWithCustomName() {
        // Given
        ReflectionTestUtils.setField(config, "screeningRequestsQueue", "custom.screening.queue");

        // When
        Queue queue = config.screeningRequestsQueue();

        // Then
        assertEquals("custom.screening.queue", queue.getName());
    }

    @Test
    @DisplayName("Should create DLQ with custom name")
    void testDlqWithCustomName() {
        // Given
        ReflectionTestUtils.setField(config, "screeningDlq", "custom.dlq");

        // When
        Queue queue = config.screeningDlq();

        // Then
        assertEquals("custom.dlq", queue.getName());
    }

    @Test
    @DisplayName("Should configure DLQ routing in main queue")
    void testDlqRoutingConfiguration() {
        // Given
        ReflectionTestUtils.setField(config, "screeningDlq", "my.custom.dlq");

        // When
        Queue queue = config.screeningRequestsQueue();

        // Then
        assertEquals("my.custom.dlq", queue.getArguments().get("x-dead-letter-routing-key"));
    }

    @Test
    @DisplayName("Should use empty string for dead letter exchange")
    void testDeadLetterExchangeIsEmpty() {
        // When
        Queue queue = config.screeningRequestsQueue();

        // Then
        assertEquals("", queue.getArguments().get("x-dead-letter-exchange"));
    }

    @Test
    @DisplayName("Should create durable queues")
    void testQueuesAreDurable() {
        // When
        Queue mainQueue = config.screeningRequestsQueue();
        Queue dlq = config.screeningDlq();

        // Then
        assertTrue(mainQueue.isDurable());
        assertTrue(dlq.isDurable());
    }

    @Test
    @DisplayName("Should configure listener factory with message converter")
    void testListenerFactoryHasMessageConverter() {
        // When
        SimpleRabbitListenerContainerFactory factory = config.rabbitListenerContainerFactory(connectionFactory);

        // Then
        assertNotNull(factory.getMessageConverter());
    }

    @Test
    @DisplayName("Should handle minimum concurrency configuration")
    void testMinimumConcurrency() {
        // Given
        ReflectionTestUtils.setField(config, "concurrency", 1);
        ReflectionTestUtils.setField(config, "maxConcurrency", 1);

        // When
        SimpleRabbitListenerContainerFactory factory = config.rabbitListenerContainerFactory(connectionFactory);

        // Then
        assertEquals(1, factory.getConcurrentConsumers());
        assertEquals(1, factory.getMaxConcurrentConsumers());
    }

    @Test
    @DisplayName("Should handle high concurrency configuration")
    void testHighConcurrency() {
        // Given
        ReflectionTestUtils.setField(config, "concurrency", 50);
        ReflectionTestUtils.setField(config, "maxConcurrency", 100);

        // When
        SimpleRabbitListenerContainerFactory factory = config.rabbitListenerContainerFactory(connectionFactory);

        // Then
        assertEquals(50, factory.getConcurrentConsumers());
        assertEquals(100, factory.getMaxConcurrentConsumers());
    }

    @Test
    @DisplayName("Should handle high prefetch count")
    void testHighPrefetchCount() {
        // Given
        ReflectionTestUtils.setField(config, "prefetchCount", 100);

        // When
        SimpleRabbitListenerContainerFactory factory = config.rabbitListenerContainerFactory(connectionFactory);

        // Then
        assertEquals(100, factory.getPrefetchCount());
    }

    @Test
    @DisplayName("Should create multiple queue instances independently")
    void testMultipleQueueInstances() {
        // When
        Queue queue1 = config.screeningRequestsQueue();
        Queue queue2 = config.screeningRequestsQueue();

        // Then
        assertNotSame(queue1, queue2);
        assertEquals(queue1.getName(), queue2.getName());
    }

    @Test
    @DisplayName("Should create multiple DLQ instances independently")
    void testMultipleDlqInstances() {
        // When
        Queue dlq1 = config.screeningDlq();
        Queue dlq2 = config.screeningDlq();

        // Then
        assertNotSame(dlq1, dlq2);
        assertEquals(dlq1.getName(), dlq2.getName());
    }

    @Test
    @DisplayName("Should create multiple factory instances independently")
    void testMultipleFactoryInstances() {
        // When
        SimpleRabbitListenerContainerFactory factory1 = config.rabbitListenerContainerFactory(connectionFactory);
        SimpleRabbitListenerContainerFactory factory2 = config.rabbitListenerContainerFactory(connectionFactory);

        // Then
        assertNotSame(factory1, factory2);
    }
}

