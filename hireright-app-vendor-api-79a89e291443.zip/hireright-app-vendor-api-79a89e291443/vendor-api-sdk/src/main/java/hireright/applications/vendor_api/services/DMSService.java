package hireright.applications.vendor_api.services;
/*
 *
 * Copyright 2001-2018 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	T.Prikk		2018-10-02	HIVPE-40534: Created to support DMS docs retrieval from "host" instance (CDN)
 *	M.Kuznetsov	2025-10-29	HRG-345322. Openjdk21-migration
 */
import org.springframework.web.bind.annotation.RequestMethod;

import hireright.applications.vendor_api.responses.FileResponse;
import hireright.components.domain.dialects.vendor_api.DocumentBundle;

public class DMSService {
    public static final String VAR_ORDER_REF = "orderRef";

    public static final String VAR_FOLDER_REF = "folderRef";
    public static final String VAR_DOCUMENT_REF = "documentRef";

    public static final String PATH_GET_CONTENT =
            "/dms/search/{" + VAR_ORDER_REF + "}/folders/{" + VAR_FOLDER_REF + "}/documents/{" + VAR_DOCUMENT_REF + "}";
    public static final String PATH_GET_ORDER_DOCUMENTS = "/dms/search/{" + VAR_ORDER_REF + "}";

    public enum EMethod implements IMethod {
        GET_ORDER_DOCUMENTS(PATH_GET_ORDER_DOCUMENTS, RequestMethod.GET, String.class, DocumentBundle.class),
        GET_CONTENT(PATH_GET_CONTENT, RequestMethod.GET, String.class, FileResponse.class);

        private final String path;
        private final RequestMethod requestMethod;
        private final Class<?> requestBodyClass;
        private final Class<?> responseBodyClass;

        EMethod(String sPath,
                RequestMethod requestMethod,
                Class<?> requestBodyClass,
                Class<?> responseBodyClass) {
            this.path = sPath;
            this.requestMethod = requestMethod;
            this.requestBodyClass = requestBodyClass;
            this.responseBodyClass = responseBodyClass;
        }

        public String getPath() {
            return this.path;
        }

        public RequestMethod getRequestMethod() {
            return this.requestMethod;
        }

        public Class<?> getRequestBodyClass() {
            return this.requestBodyClass;
        }

        public Class<?> getResponseBodyClass() {
            return this.responseBodyClass;
        }

        public boolean isValidRequest(Object request) {
            return true;
        }
    }
}