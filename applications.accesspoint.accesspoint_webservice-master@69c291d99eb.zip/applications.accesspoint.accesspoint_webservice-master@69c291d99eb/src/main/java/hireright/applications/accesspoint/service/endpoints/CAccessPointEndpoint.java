/*
 * @(#)$RCSfile: CAccessPointEndpoint.java,v $ $Revision: 1.4 $ $Date: 2015/01/28 18:08:56 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/service/endpoints/CAccessPointEndpoint.java,v $
 *
 * Copyright 2001-2014 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Putintsev		2014-09-22	Created
 *	A.Putintsev		2015-01-16	success parameter in doLogin() is removed
 */
package hireright.applications.accesspoint.service.endpoints;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import hireright.applications.accesspoint.service.CAccessPoint;
import hireright.applications.accesspoint.service.CEntryPointBean;
import hireright.applications.accesspoint.service.Create;
import hireright.applications.accesspoint.service.CreateResponse;
import hireright.applications.accesspoint.service.CreateResult;
import hireright.applications.accesspoint.service.DoLogin;
import hireright.applications.accesspoint.service.DoLoginResponse;
import hireright.applications.accesspoint.types.CAccessPointException;

/**
 * 
 */
@Endpoint
public class CAccessPointEndpoint {
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	private static final String TARGET_NAMESPACE = "http://hireright.com/applications/accesspoint/service";
	
	@Autowired
	private CAccessPoint m_accessPoint;
	
	@PayloadRoot(localPart = "doLogin", namespace = TARGET_NAMESPACE)
	public @ResponsePayload 
			JAXBElement<DoLoginResponse> doLogin(@RequestPayload JAXBElement<DoLogin> requestElement)
					throws CAccessPointException
	{
		DoLoginResponse response = new DoLoginResponse();
		DoLogin request = requestElement.getValue();
				
		CEntryPointBean entryPointType = m_accessPoint.doLogin(request.getKey());
		response.setReturn(entryPointType);		
				
		return new JAXBElement<DoLoginResponse>(new QName(TARGET_NAMESPACE,"doLoginResponse","tns"), DoLoginResponse.class, response);
	}
	
	@PayloadRoot(localPart = "create", namespace = TARGET_NAMESPACE)
	public @ResponsePayload 
			JAXBElement<CreateResponse> create(@RequestPayload JAXBElement<Create> requestElement)
				throws CAccessPointException
	{
		CreateResponse response = new CreateResponse();
		Create createRequest = requestElement.getValue();
		
		CreateResult createResult = m_accessPoint.create(
					createRequest.getUserID(),
					createRequest.getUserClass(),
					createRequest.getEntryPointType(),
					createRequest.getDomainID(),
					createRequest.getDesignNr(),
					createRequest.getAuthenticationMode(),
					createRequest.getLogin(),
					createRequest.getEntriesAllowed(),
					createRequest.getFailuresAllowed(),
					createRequest.getExpirationDate(),
					createRequest.isCreateSession(),
					createRequest.getParameters()
				);
		response.setReturn(createResult);
		
		return new JAXBElement<CreateResponse>(new QName(TARGET_NAMESPACE,"createResponse","tns"), CreateResponse.class, response);
	}
	
}
