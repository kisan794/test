package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;

import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VerificationRequest {

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy")
  @Valid
  private Date lastVerificationDate;

  private ApprovalStatus approvalStatus;

  //@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
  //@Valid
  private String lastUsedDate;

}
