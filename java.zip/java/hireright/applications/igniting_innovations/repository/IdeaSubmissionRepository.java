package hireright.applications.igniting_innovations.repository;

import hireright.applications.igniting_innovations.document.IdeaSubmission;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;

/**
 * @author Keshav Ladha
 * @version 1.0
 */
@Repository
public interface IdeaSubmissionRepository extends MongoRepository<IdeaSubmission, String> {

    /**
     * Find all idea submissions by email address and updated date after a specific date.
     *
     * @param emailAddress the email address to search for
     * @param updatedAfter the date after which ideas were updated
     * @param pageable pagination information
     * @return page of idea submissions
     */
    Page<IdeaSubmission> findByEmailAddressAndUpdatedAtAfter(String emailAddress, LocalDateTime updatedAfter, Pageable pageable);
}