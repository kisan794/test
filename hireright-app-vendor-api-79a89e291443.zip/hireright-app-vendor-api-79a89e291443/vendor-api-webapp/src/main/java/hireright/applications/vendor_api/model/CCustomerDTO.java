/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-09-11	Created
 */
package hireright.applications.vendor_api.model;

import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


@XmlRootElement(name="Customer")
public class CCustomerDTO
{
	private Long customerID;
	private Boolean canContactApplicant;
	private String companyName;
	private String accountName;

	@XmlAttribute(name="id")
	public Long getCustomerID()
	{
		return customerID;
	}

	public void setCustomerID(Long customerID)
	{
		this.customerID = customerID;
	}

	@XmlElement(name="CompanyName")
	public String getCompanyName()
	{
		return companyName;
	}

	public void setCompanyName(String companyName)
	{
		this.companyName = companyName;
	}

	@XmlElement(name="AccountName")
	public String getAccountName()
	{
		return accountName;
	}

	public void setAccountName(String accountName)
	{
		this.accountName = accountName;
	}

	@XmlAttribute(name="canContactApplicant")
	@XmlJavaTypeAdapter(CBoolToShortStringAdapter.class)
	public Boolean getCanContactApplicant()
	{
		return canContactApplicant;
	}

	public void setCanContactApplicant(Boolean canContactApplicant)
	{
		this.canContactApplicant = canContactApplicant;
	}
}
