package com.hireright.sourceintelligence.api.dto.notification;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * Generic notification request DTO that supports multiple notification types.
 * Follows Open/Closed Principle - can be extended with new notification types
 * without modifying existing code.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NotificationRequestDTO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * Type of notification to send
     */
    @NotNull(message = "Notification type is required")
    private NotificationType notificationType;
    
    /**
     * Whether to process the notification asynchronously
     */
    @Builder.Default
    private Boolean async = false;
    
    /**
     * Unique request identifier for tracking
     */
    private String requestId;
    
    /**
     * Email notification details (populated if notificationType is EMAIL)
     */
    @Valid
    private EmailNotificationDTO emailNotification;
    
    /**
     * SMS notification details (populated if notificationType is SMS)
     * This can be added in future implementations
     */
    // private SmsNotificationDTO smsNotification;
    
    /**
     * Timestamp when the request was created
     */
    private String createdAt;
}

