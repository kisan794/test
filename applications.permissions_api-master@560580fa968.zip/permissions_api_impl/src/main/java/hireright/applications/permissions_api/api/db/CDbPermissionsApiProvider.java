package hireright.applications.permissions_api.api.db;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-17  HRG-330191 initial version
 */

import hireright.applications.permissions_api.api.IPermissionsApi;
import hireright.applications.permissions_api.api.IPermissionsApiProvider;
import hireright.sdk.db3.DB;

public class CDbPermissionsApiProvider implements IPermissionsApiProvider
{
	@Override
	public IPermissionsApi getApi()
	{
		return new CDbPermissionsApi(DB.session());
	}
}
