package com.hireright.sourceintelligence.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Document(collection = "language")
public class Language {

    @Id
    @Field("_id")
    private ObjectId id;

    @Field("ID")
    private BigDecimal languageId;

    @Field("NAME")
    private String name;

    @Field("ISO_639_1")
    private String iso6391;

    @Field("ISO_639_2T")
    private String iso6392t;

    @Field("LANGUAGE_TAG")
    private String languageTag;

    @Field("table")
    private String table;

    @Field("scn")
    private String scn;

    @Field("op_type")
    private String opType;

    @Field("op_ts")
    private String opTs;

    @Field("current_ts")
    private String currentTs;

    @Field("row_id")
    private String rowId;

    @Field("username")
    private String username;

    @Field("location")
    private String location;
}