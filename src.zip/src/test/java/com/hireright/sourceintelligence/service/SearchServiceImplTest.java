package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.domain.entity.MongoSearchResult;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.domain.mapper.SourceDTOMapper;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.exception.InvalidRequestException;
import com.hireright.sourceintelligence.exception.ResourceNotFoundException;
import com.hireright.sourceintelligence.service.impl.SearchServiceImpl;
import com.hireright.sourceintelligence.service.impl.SearchConstants;
import com.hireright.sourceintelligence.service.impl.helperservices.CountryRegionMappingUtils;
import com.hireright.sourceintelligence.util.TestDataProvider;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.lang.reflect.Method;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class SearchServiceImplTest {

    @InjectMocks
    private SearchServiceImpl searchServiceImpl;

    @Mock
    private CustomSourceRepository<Source> customSourceRepository;

    @Mock
    private SourceMapper sourceMapper;

    @Mock
    private SourceDTOMapper sourceDTOMapper;

    @Mock
    private CountryRegionMappingUtils countryRegionMappingUtils;

    @BeforeEach
    void setUp() {

    }

    @Test
    void getOrganizationList_Success_Test() {
        SearchDTO searchDTO = TestDataProvider.getSearchDTO();
        searchDTO.setSearchText("amazon aws");

        MongoSearchResult res = new MongoSearchResult();
        res.setTotal(1);
        res.setOrganizationList(List.of(TestDataProvider.getSourceEntity()));

        when(customSourceRepository.customAggregate(any(), anyString(), eq(MongoSearchResult.class)))
                .thenReturn(res);

        assertThatNoException().isThrownBy(() -> searchServiceImpl.getSourceOrganizationList(searchDTO));
    }

    @Test
    void getDistinctOrganizationListTest_ShouldThrowServiceException() {
        SearchDTO searchDTO = TestDataProvider.getSearchDTO();
        searchDTO.setSearchText(null);
        assertThatExceptionOfType(InvalidRequestException.class)
                .isThrownBy(() -> searchServiceImpl.getSourceOrganizationList(searchDTO));
    }

    @Test
    void getOrganizationListForAutoComplete_ResourceNotFound() {
        SearchDTO searchDTO = TestDataProvider.getSearchDTO();
        searchDTO.setSearchText("awsamazon");
        searchDTO.setOrganizationType(OrganizationType.EMPLOYMENT);

        when(customSourceRepository.findByFieldDistinct(any(), any(), any()))
                .thenReturn(Collections.emptyList());

        assertThatExceptionOfType(ResourceNotFoundException.class)
                .isThrownBy(() -> searchServiceImpl.getSourceOrganizationListForAutocomplete(searchDTO))
                .withMessageContaining("No search result found");
    }

    @Test
    void getOrganizationListForAutoComplete_Success() {
        SearchDTO searchDTO = TestDataProvider.getSearchDTO();
        searchDTO.setBatchSize(10);
        searchDTO.setSearchText("awsamazon");
        searchDTO.setOrganizationType(OrganizationType.EMPLOYMENT);

        when(customSourceRepository.findByFieldDistinct(any(), any(), any()))
                .thenReturn(Arrays.asList("org1", "org2"));

        assertThatNoException().isThrownBy(() -> searchServiceImpl.getSourceOrganizationListForAutocomplete(searchDTO));
    }

    @Test
    void getOrganizationListForAutoComplete_TokenSizeGreaterThanThree_Success() {
        SearchDTO searchDTO = TestDataProvider.getSearchDTO();
        searchDTO.setBatchSize(10);
        searchDTO.setSearchText("Community College Of Rhode Island");
        searchDTO.setOrganizationType(OrganizationType.EMPLOYMENT);
        searchDTO.setSourceOrganizationStatus(SourceOrganizationStatus.INACTIVE);

        when(customSourceRepository.findByFieldDistinct(any(), any(), any()))
                .thenReturn(Arrays.asList("org1", "org2"));

        assertThatNoException().isThrownBy(() -> searchServiceImpl.getSourceOrganizationListForAutocomplete(searchDTO));
    }

    @Test
    void getOrganizationListForAutoComplete_ShouldThrowServiceException() {
        SearchDTO searchDTO = TestDataProvider.getSearchDTO();
        searchDTO.setSearchText(null);
        assertThatExceptionOfType(InvalidRequestException.class)
                .isThrownBy(() -> searchServiceImpl.getSourceOrganizationListForAutocomplete(searchDTO));
    }

    @Test
    void getOrganizationContactListByHon_Success() {
        SearchDTO searchDTO = TestDataProvider.getSearchDTO();
        List<Source> contacts = TestDataProvider.getSourceOrganizationList();

        when(customSourceRepository.findByQuery(any(), eq(Source.class), anyString()))
                .thenReturn(contacts);

        assertThatNoException().isThrownBy(() -> searchServiceImpl.getSourceOrganizationContactListByHon(searchDTO));
    }

    @Test
    void getOrganizationContactListByHon_ResourceNotFound() {
        SearchDTO searchDTO = TestDataProvider.getSearchDTO();
        searchDTO.setHon("OUEDU-02322-S38HM");
        searchDTO.setOrganizationType(OrganizationType.EDUCATION);

        when(customSourceRepository.findByQuery(any(), eq(Source.class), anyString()))
                .thenReturn(Collections.emptyList());

        assertThatExceptionOfType(ResourceNotFoundException.class)
                .isThrownBy(() -> searchServiceImpl.getSourceOrganizationContactListByHon(searchDTO));
    }

    @Test
    void getOrganizationContactListByHon_InvalidRequest() {
        SearchDTO searchDTO = TestDataProvider.getSearchDTO();
        searchDTO.setHon("");
        searchDTO.setOrganizationType(OrganizationType.EDUCATION);
        assertThatExceptionOfType(InvalidRequestException.class)
                .isThrownBy(() -> searchServiceImpl.getSourceOrganizationContactListByHon(searchDTO));
    }

    @Test
    void getOrganizationAddressByHon_Success() {
        SearchDTO searchDTO = TestDataProvider.getSearchDTO();
        List<Source> addresses = TestDataProvider.getSourceOrganizationList();

        when(customSourceRepository.findByQuery(any(), eq(Source.class), anyString()))
                .thenReturn(addresses);

        assertThatNoException().isThrownBy(() -> searchServiceImpl.getSourceOrganizationAddressByHon(searchDTO));
    }

    @Test
    void getOrganizationAddressByHon_ResourceNotFound() {
        SearchDTO searchDTO = TestDataProvider.getSearchDTO();
        searchDTO.setHon("OUEDU-02322-S38HM");
        searchDTO.setOrganizationType(OrganizationType.EDUCATION);

        when(customSourceRepository.findByQuery(any(), eq(Source.class), anyString()))
                .thenReturn(Collections.emptyList());

        assertThatExceptionOfType(ResourceNotFoundException.class)
                .isThrownBy(() -> searchServiceImpl.getSourceOrganizationAddressByHon(searchDTO));
    }

    @Test
    void getOrganizationAddressByHon_InvalidRequest() {
        SearchDTO searchDTO = TestDataProvider.getSearchDTO();
        searchDTO.setHon("");
        searchDTO.setOrganizationType(OrganizationType.EDUCATION);

        assertThatExceptionOfType(InvalidRequestException.class)
                .isThrownBy(() -> searchServiceImpl.getSourceOrganizationAddressByHon(searchDTO));
    }

    @Test
    void getDetailedAutocompletedSearchResult_Success() {
        Source sourceOrganization = TestDataProvider.getSourceOrganizationEntityThree();
        sourceOrganization.setOrganizationType(OrganizationType.EDUCATION);
        List<Source> sourceOrganizations = List.of(sourceOrganization);

        SourceOrganizationDTO sourceOrganizationDTO = TestDataProvider.getSourceOrganizationDTO();
        sourceOrganizationDTO.setHon(TestDataProvider.getHon());

        when(sourceMapper.entitySourceToDTO(any())).thenReturn(sourceOrganizationDTO);
        when(customSourceRepository.aggregate(any(), anyString(), eq(Source.class)))
                .thenReturn(sourceOrganizations);

        assertThatNoException().isThrownBy(() ->
                searchServiceImpl.getDetailedAutocompletedSearchResult("Acc",
                        OrganizationType.EDUCATION, SourceOrganizationStatus.ACTIVE, "USA"));
    }

    @Test
    void getDetailedAutocompletedSearchResult_ResourceNotFound() {
        when(customSourceRepository.aggregate(any(), anyString(), eq(Source.class)))
                .thenReturn(Collections.emptyList());

        assertThatExceptionOfType(ResourceNotFoundException.class).isThrownBy(() ->
                searchServiceImpl.getDetailedAutocompletedSearchResult("Acc",
                        OrganizationType.EDUCATION, SourceOrganizationStatus.ACTIVE, "USA"));
    }

    @Test
    void getAutocompleteSuggestionForDuplicates_Success() {
        Source sourceOrganization = TestDataProvider.getSourceOrganizationEntityThree();
        sourceOrganization.setOrganizationType(OrganizationType.EDUCATION);
        when(customSourceRepository.aggregate(any(), anyString(), eq(Source.class)))
                .thenReturn(List.of(sourceOrganization));

        assertThatNoException().isThrownBy(() ->
                searchServiceImpl.getAutocompletedSuggestionForPossibleDuplicates(
                        "Acc", OrganizationType.EDUCATION));
    }

    @Test
    void getAutocompleteSuggestionForDuplicates_KeywordLong_Success() {
        Source sourceOrganization = TestDataProvider.getSourceOrganizationEntityThree();
        sourceOrganization.setOrganizationType(OrganizationType.EDUCATION);
        when(customSourceRepository.aggregate(any(), anyString(), eq(Source.class)))
                .thenReturn(List.of(sourceOrganization));

        assertThatNoException().isThrownBy(() ->
                searchServiceImpl.getAutocompletedSuggestionForPossibleDuplicates(
                        "Community College of Rhode Island", OrganizationType.EDUCATION));
    }

    @Test
    void getAutocompleteSuggestionForDuplicates_NoResults_ReturnsEmptyList() {
        when(customSourceRepository.aggregate(any(), anyString(), eq(Source.class)))
                .thenReturn(Collections.emptyList());

        SearchResponseDTO response =
                searchServiceImpl.getAutocompletedSuggestionForPossibleDuplicates(
                        "Amwong", OrganizationType.EDUCATION);

        assertThat(response.getSourceList()).isEmpty();
    }

    @Test
    void getFiltersForSourceOrganizations_Simple() {
        assertThatNoException().isThrownBy(() -> searchServiceImpl.getFiltersForSourceOrganizations());
        SearchFilter filters = searchServiceImpl.getFiltersForSourceOrganizations();
        assertThat(filters.getStatuses()).contains(ApprovalStatus.APPROVED);
        assertThat(filters.getVerificationTypes()).contains(OrganizationType.EDUCATION);
    }


    @Test
    void getSourcesByFilters_returnsEmpty_whenNoResults() {
        SearchFilter filter = new SearchFilter();
        filter.setOrganizationType(OrganizationType.EDUCATION.getType());

        when(customSourceRepository.queryCount(any(), anyString(), eq(Source.class))).thenReturn(0L);
        when(customSourceRepository.aggregate(any(), anyString(), eq(Source.class)))
                .thenReturn(Collections.emptyList());

        SearchResponseDTO response = searchServiceImpl.getSourcesByFilters(
                filter, "desc", SearchConstants.SortFields.ORGANIZATION_NAME, 1, 10);

        assertThat(response).isNotNull();
        assertThat(response.getSearchList()).isNull();
    }


    @Test
    void getSourcesByFilters_success_withSpecialSort() {
        SearchFilter filter = new SearchFilter();
        filter.setOrganizationType(OrganizationType.EDUCATION.getType());

        Source entity = TestDataProvider.getSourceEntity();
        when(customSourceRepository.queryCount(any(), anyString(), eq(Source.class))).thenReturn(1L);
        when(customSourceRepository.aggregate(any(), anyString(), eq(Source.class)))
                .thenReturn(List.of(entity));
        when(sourceDTOMapper.entityToSourceList(anyList()))
                .thenReturn(List.of(new SourceDTO()));

        SearchResponseDTO response = searchServiceImpl.getSourcesByFilters(
                filter, "desc", SearchConstants.SortFields.LAST_MODIFIED_BY, 1, 10);

        assertThat(response).isNotNull();
        assertThat(response.getSearchList()).hasSize(1);
        assertThat(response.getTotalItems()).isEqualTo(1);
    }

    @Test
    void buildSearchResponseDTO_withPaging_shouldReturnPagedResponse() {
        SearchDTO dto = TestDataProvider.getSearchDTO();
        dto.setStartIndex(1);
        dto.setBatchSize(1);

        List<Source> sources = List.of(TestDataProvider.getSourceEntity());
        when(sourceMapper.toSourceDTOList(anyList())).thenReturn(List.of(new SourceOrganizationDTO()));

        SearchResponseDTO response = ReflectionTestUtils.invokeMethod(
                searchServiceImpl, "buildSearchResponseDTO", dto, sources, "organizationName");

        assertThat(response).isNotNull();
        assertThat(response.getCurrentPage()).isEqualTo(1);
    }

    @Test
    void buildSearchResponseDTO_noPaging_returnsAll() {
        SearchDTO dto = TestDataProvider.getSearchDTO();
        dto.setStartIndex(1);
        dto.setBatchSize(100);

        List<Source> sources = List.of(TestDataProvider.getSourceEntity());
        when(sourceMapper.toSourceDTOList(anyList())).thenReturn(List.of(new SourceOrganizationDTO()));

        SearchResponseDTO response = ReflectionTestUtils.invokeMethod(
                searchServiceImpl, "buildSearchResponseDTO", dto, sources, "organizationName");

        assertThat(response).isNotNull();
        assertThat(response.getTotalPages()).isEqualTo(1);
        assertThat(response.getTotalItems()).isEqualTo(1);
    }



    @Test
    void canDoPaging_zeroResults_shouldReturnFalse() {
        SearchDTO dto = TestDataProvider.getSearchDTO();
        dto.setStartIndex(0);
        dto.setBatchSize(10);

        boolean result = ReflectionTestUtils.invokeMethod(
                searchServiceImpl, "canDoPaging", 0, dto);

        assertThat(result).isFalse();
    }

    @Test
    void canDoPaging_trueForLargeResultSet() {
        SearchDTO dto = TestDataProvider.getSearchDTO();
        dto.setStartIndex(1);
        dto.setBatchSize(10);

        boolean result = ReflectionTestUtils.invokeMethod(
                searchServiceImpl, "canDoPaging", 100, dto);

        assertThat(result).isTrue();
    }



}
