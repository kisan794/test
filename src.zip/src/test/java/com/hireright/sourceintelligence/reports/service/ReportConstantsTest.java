package com.hireright.sourceintelligence.reports.service;
import com.hireright.sourceintelligence.reports.service.impl.ReportConstants;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

class ReportConstantsTest {

    @Test
    void testAggregateFieldsConstants() {
        assertEquals("_id", ReportConstants.AggregateFields.ID);
    }

    @Test
    void testReportTypesConstants() {
        assertEquals("auto-match", ReportConstants.ReportTypes.AUTO_MATCH);

    }

    @Test
    void testRegexConstants() {
        assertEquals("([a-z])([A-Z])", ReportConstants.Regex.CAMEL_CASE_REGEX);
        assertEquals("$1_$2", ReportConstants.Regex.SNAKE_CASE_REGEX);
    }

    @Test
    void testMetaDataConstantsUsingReflection() throws Exception {
        Class<?> metaDataClass = Class.forName("com.hireright.sourceintelligence.reports.service.impl.ReportConstants$MetaData");

        Field contactUtilField = metaDataClass.getDeclaredField("CONTACT_UTILIZATION_META_DATA");
        contactUtilField.setAccessible(true);
        assertNotNull(contactUtilField.get(null));

        Field autoMatchField = metaDataClass.getDeclaredField("AUTO_MATCH_META_DATA");
        autoMatchField.setAccessible(true);
        assertNotNull(autoMatchField.get(null));

        Field sourceInfoField = metaDataClass.getDeclaredField("SOURCE_INFORMATION_META_DATA");
        sourceInfoField.setAccessible(true);
        assertNotNull(sourceInfoField.get(null));

        Field approvalTATField = metaDataClass.getDeclaredField("APPROVAL_TAT_META_DATA");
        approvalTATField.setAccessible(true);
        assertNotNull(approvalTATField.get(null));

        Field lastUsedField = metaDataClass.getDeclaredField("LAST_USED");
        lastUsedField.setAccessible(true);
        assertEquals("Last_Used", lastUsedField.get(null));

        Field usedDateField = metaDataClass.getDeclaredField("USED_DATE");
        usedDateField.setAccessible(true);
        assertEquals("Used_Date", usedDateField.get(null));
    }

    @Test
    void testPrivateConstructors() {
        assertAll(
                () -> assertDoesNotThrow(() -> invokePrivateConstructor(ReportConstants.class)),
                () -> assertDoesNotThrow(() -> invokePrivateConstructor(ReportConstants.AggregateFields.class)),
                () -> assertDoesNotThrow(() -> invokePrivateConstructor(ReportConstants.ReportTypes.class)),
                () -> assertDoesNotThrow(() -> invokePrivateConstructorViaName(
                        "com.hireright.sourceintelligence.reports.service.impl.ReportConstants$MetaData")),
                () -> assertDoesNotThrow(() -> invokePrivateConstructor(ReportConstants.Regex.class))
        );
    }
    private void invokePrivateConstructor(Class<?> clazz) throws Exception {
        Constructor<?> constructor = clazz.getDeclaredConstructor();
        constructor.setAccessible(true);
        constructor.newInstance();
    }

    private void invokePrivateConstructorViaName(String className) throws Exception {
        Class<?> clazz = Class.forName(className);
        invokePrivateConstructor(clazz);
    }
}
