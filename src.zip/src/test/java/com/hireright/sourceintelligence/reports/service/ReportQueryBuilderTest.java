package com.hireright.sourceintelligence.reports.service;

import com.hireright.sourceintelligence.api.dto.DateRange;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;
import com.hireright.sourceintelligence.reports.service.impl.ReportsQueryBuilder;
import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.time.Instant;
import java.util.List;

import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.SortFields.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class ReportsQueryBuilderTest {

    private ReportsRequestDTO buildRequest(String orgName, String operatorName, String operatorRole, boolean withDateRange) {
        ReportsRequestDTO dto = new ReportsRequestDTO();
        dto.setOrganizationName(orgName);
        dto.setOperatorName(operatorName);
        dto.setOperatorRole(operatorRole);

        if (withDateRange) {
            DateRange dateRange = new DateRange();
            dateRange.setStartDate(Instant.parse("2024-01-01T00:00:00Z"));
            dateRange.setEndDate(Instant.parse("2024-01-31T23:59:59Z"));
            dto.setDateRange(dateRange);
        }
        return dto;
    }

    private String criteriaJson(Criteria criteria) {
        return criteria.getCriteriaObject().toJson();
    }

    @Test
    void testPrivateConstructor() throws Exception {
        Constructor<ReportsQueryBuilder> constructor = ReportsQueryBuilder.class.getDeclaredConstructor();
        constructor.setAccessible(true);

        InvocationTargetException thrown = assertThrows(InvocationTargetException.class, constructor::newInstance);
        assertInstanceOf(IllegalStateException.class, thrown.getCause());
        assertEquals("Utility class", thrown.getCause().getMessage());
    }

    @Test
    void testQueryBuilder_withAllFields() {
        ReportsRequestDTO dto = buildRequest("TestOrg", "TestOperator", "Admin", true);

        Criteria criteria = ReportsQueryBuilder.queryBuilder(dto);
        String json = criteriaJson(criteria);

        assertNotNull(criteria);
        assertTrue(json.contains("action"));
        assertTrue(json.contains("organizationName"));
        assertTrue(json.contains("createdBy"));
        assertTrue(json.contains("operatorRole"));
        assertTrue(json.contains("createdDate"));
    }

    @Test
    void testQueryBuilder_withMinimalFields() {
        ReportsRequestDTO dto = buildRequest(null, null, null, false);

        Criteria criteria = ReportsQueryBuilder.queryBuilder(dto);
        String json = criteriaJson(criteria);

        assertNotNull(criteria);
        assertTrue(json.contains("action"));
        assertFalse(json.contains("organizationName"));
        assertFalse(json.contains("createdBy"));
        assertFalse(json.contains("operatorRole"));
    }

    @Test
    void testQueryBuilder_withCountryList() {
        ReportsRequestDTO dto = buildRequest("TestOrg", "TestOperator", "Admin", true);

        Criteria criteria = ReportsQueryBuilder.queryBuilder(dto, List.of("India", "USA"));
        String json = criteriaJson(criteria);

        assertNotNull(criteria);
        assertTrue(json.contains("$expr"));
        assertTrue(json.contains("$in"));
        assertTrue(json.contains("address"));
    }

    @Test
    void testQueryBuilder_withEmptyCountryList() {
        ReportsRequestDTO dto = buildRequest(null, null, null, false);

        Criteria criteria = ReportsQueryBuilder.queryBuilder(dto, List.of());
        String json = criteriaJson(criteria);

        assertNotNull(criteria);
        assertFalse(json.contains("$expr"));
    }

    @Test
    void testQueryBuilderForSourceInformationAndTat_withOperatorAndCountry() {
        ReportsRequestDTO dto = buildRequest(null, "Maker1", null, true);

        Criteria criteria = ReportsQueryBuilder.queryBuilderForSourceInformationAndTat(dto, List.of("India"));
        String json = criteriaJson(criteria);

        assertNotNull(criteria);
        assertTrue(json.contains("createdBy"));
        assertTrue(json.contains("$expr"));
        assertTrue(json.contains("createdDate"));
    }

    @Test
    void testQueryBuilderForSourceInformationAndTat_withoutOperator() {
        ReportsRequestDTO dto = buildRequest(null, null, null, false);

        Criteria criteria = ReportsQueryBuilder.queryBuilderForSourceInformationAndTat(dto, null);
        String json = criteriaJson(criteria);

        assertNotNull(criteria);
        assertTrue(json.contains("createdBy"));
        assertTrue(json.contains("$exists"));
    }

    @Test
    void testQueryBuilderForReviewerRole_withOperatorAndCountry() {
        ReportsRequestDTO dto = buildRequest(null, "Reviewer1", null, true);

        Criteria criteria = ReportsQueryBuilder.queryBuilderForReviewerRole(dto, List.of("India"));
        String json = criteriaJson(criteria);

        assertNotNull(criteria);
        assertTrue(json.contains("approvedBy"));
        assertTrue(json.contains("$expr"));
        assertTrue(json.contains("createdDate"));
    }

    @Test
    void testQueryBuilderForReviewerRole_withoutOperator() {
        ReportsRequestDTO dto = buildRequest(null, null, null, false);

        Criteria criteria = ReportsQueryBuilder.queryBuilderForReviewerRole(dto, null);
        String json = criteriaJson(criteria);

        assertNotNull(criteria);
        assertTrue(json.contains("approvedBy"));
        assertTrue(json.contains("$exists"));
    }

    @Test
    void testQueryBuilderForDelete_withAllInputs() {
        ReportsRequestDTO dto = buildRequest("DeleteOrg", "DeleteUser", "DeleteRole", true);

        Criteria criteria = ReportsQueryBuilder.queryBuilderForDelete(dto, List.of("India"));
        String json = criteriaJson(criteria);

        assertNotNull(criteria);
        assertTrue(json.contains("organizationName"));
        assertTrue(json.contains("createdBy"));
        assertTrue(json.contains("operatorRole"));
        assertTrue(json.contains("$expr"));
        assertTrue(json.contains("createdDate"));
    }

    @Test
    void testQueryBuilderForDelete_withNullInputs() {
        ReportsRequestDTO dto = buildRequest(null, null, null, false);

        Criteria criteria = ReportsQueryBuilder.queryBuilderForDelete(dto, null);
        String json = criteriaJson(criteria);

        assertNotNull(criteria);
        assertTrue(json.contains("action"));
        assertFalse(json.contains("organizationName"));
        assertFalse(json.contains("createdBy"));
        assertFalse(json.contains("operatorRole"));
    }

    @Test
    void testQueryBuilderForApprovalTat_withOperatorName() {
        ReportsRequestDTO dto = buildRequest("Org1", "User1", null, true);

        Criteria criteria = ReportsQueryBuilder.queryBuilderForApprovalTat(dto, List.of("India"));
        String json = criteriaJson(criteria);

        assertNotNull(criteria);
        assertTrue(json.contains("organizationName"));
        assertTrue(json.contains("version"));
        assertTrue(json.contains("$or"));
        assertTrue(json.contains("txnType"));
        assertTrue(json.contains("$expr"));
        assertTrue(json.contains("createdDate"));
    }

    @Test
    void testQueryBuilderForApprovalTat_withoutOperatorName() {
        ReportsRequestDTO dto = buildRequest(null, null, null, false);

        Criteria criteria = ReportsQueryBuilder.queryBuilderForApprovalTat(dto, null);
        String json = criteriaJson(criteria);

        assertNotNull(criteria);
        assertTrue(json.contains("version"));
        assertTrue(json.contains("$or"));
        assertTrue(json.contains("txnType"));
    }

    @Test
    void testQueryBuilderForTatFilter() {
        Criteria criteria = ReportsQueryBuilder.queryBuilderForTatFilter();
        String json = criteriaJson(criteria);

        assertNotNull(criteria);
        assertTrue(json.contains("data.approvalStatus"));
    }

    @Test
    void testMatchSkipLimitCountOperations() {
        MatchOperation matchOperation = ReportsQueryBuilder.matchOperation(Criteria.where("field").is("value"));
        SkipOperation skipOperation = ReportsQueryBuilder.skipOperation(3, 10);
        LimitOperation limitOperation = ReportsQueryBuilder.limitOperation(20);
        CountOperation countOperation = ReportsQueryBuilder.countOperation();

        assertNotNull(matchOperation);
        assertNotNull(skipOperation);
        assertNotNull(limitOperation);
        assertNotNull(countOperation);
    }

    @Test
    void testFacetOperations() {
        SortOperation sortOperation = ReportsQueryBuilder.buildSortOperation(ORGANIZATION_NAME, "asc");
        GroupOperation groupOperation = ReportsQueryBuilder.contactUtilizationGroupOperation();

        FacetOperation facetOperation = ReportsQueryBuilder.facetOperation(1, 10);
        FacetOperation facetWithSorting = ReportsQueryBuilder.facetOperationWithSorting(sortOperation, 2, 5);
        FacetOperation facetWithGroup = ReportsQueryBuilder.facetOperationWithGroup(sortOperation, 1, 10, groupOperation);

        assertNotNull(facetOperation);
        assertNotNull(facetWithSorting);
        assertNotNull(facetWithGroup);
    }

    @Test
    void testProjectionOperations() {
        ProjectionOperation finalProjection =
                ReportsQueryBuilder.finalProjectionWithTotalCountInPipeline("responseList");
        ProjectionOperation operatorProjection = ReportsQueryBuilder.operatorRoleFinalProjection();
        ProjectionOperation reviewerProjection = ReportsQueryBuilder.reviewerRoleFinalProjection();
        ProjectionOperation excludeProjection = ReportsQueryBuilder.excludeProjection();

        assertNotNull(finalProjection);
        assertNotNull(operatorProjection);
        assertNotNull(reviewerProjection);
        assertNotNull(excludeProjection);
    }

    @Test
    void testGroupOperations() {
        GroupOperation contactUtilization = ReportsQueryBuilder.contactUtilizationGroupOperation();
        GroupOperation autoMatch = ReportsQueryBuilder.autoMatchGroupOperation();
        GroupOperation operatorRole = ReportsQueryBuilder.operatorRoleGroupOperation();
        GroupOperation reviewerRole = ReportsQueryBuilder.reviewerRoleGroupOperation();
        GroupOperation operatorReviewerAction = ReportsQueryBuilder.operatorAndReviewerActionGroupOperation();
        GroupOperation operatorReviewerStatus = ReportsQueryBuilder.operatorAndReviewerStatusGroupOperation();
        GroupOperation deleteGroup = ReportsQueryBuilder.deleteGroupOperation();
        GroupOperation approvalTat = ReportsQueryBuilder.approvalTATGroupOperation();

        assertNotNull(contactUtilization);
        assertNotNull(autoMatch);
        assertNotNull(operatorRole);
        assertNotNull(reviewerRole);
        assertNotNull(operatorReviewerAction);
        assertNotNull(operatorReviewerStatus);
        assertNotNull(deleteGroup);
        assertNotNull(approvalTat);
    }

    @Test
    void testAddFieldForVVD() {
        AddFieldsOperation operation = ReportsQueryBuilder.addFieldForVVD();
        assertNotNull(operation);
    }

    @Test
    void testGetSortPropertyMapped_allBranches() {
        assertEquals("hon", ReportsQueryBuilder.getSortPropertyMapped(HON));
        assertEquals("organizationName", ReportsQueryBuilder.getSortPropertyMapped(ORGANIZATION_NAME));
        assertEquals("address", ReportsQueryBuilder.getSortPropertyMapped(ADDRESS));
        assertEquals("verificationValidationDate", ReportsQueryBuilder.getSortPropertyMapped(VERIFICATION_DATE));
        assertEquals("organizationType", ReportsQueryBuilder.getSortPropertyMapped(ORGANIZATION_TYPE));
        assertEquals("approvalStatus", ReportsQueryBuilder.getSortPropertyMapped(APPROVAL_STATUS));
        assertEquals("approvedBy", ReportsQueryBuilder.getSortPropertyMapped(APPROVED_BY));
        assertEquals("createdBy", ReportsQueryBuilder.getSortPropertyMapped(CREATED_BY));
        assertEquals("autoMatch", ReportsQueryBuilder.getSortPropertyMapped(AUTO_MATCH));
        assertEquals("reason", ReportsQueryBuilder.getSortPropertyMapped(REASON));
        assertEquals("action", ReportsQueryBuilder.getSortPropertyMapped(CHANGE_TYPE));
        assertEquals("usedCount", ReportsQueryBuilder.getSortPropertyMapped(USED_COUNT));
        assertEquals("origin", ReportsQueryBuilder.getSortPropertyMapped(ORIGIN));
        assertEquals("createdDate", ReportsQueryBuilder.getSortPropertyMapped(CREATED_DATE));
        assertEquals("createdDate", ReportsQueryBuilder.getSortPropertyMapped("unknown"));
    }

    @Test
    void testGetSortPropertyMappedForReviewer_allBranches() {
        assertEquals("researcherName", ReportsQueryBuilder.getSortPropertyMappedForReviewer(RESEARCHER_NAME));
        assertEquals("newCount", ReportsQueryBuilder.getSortPropertyMappedForReviewer(NEW_COUNT));
        assertEquals("inProgress", ReportsQueryBuilder.getSortPropertyMappedForReviewer(IN_PROGRESS));
        assertEquals("onHold", ReportsQueryBuilder.getSortPropertyMappedForReviewer(ON_HOLD));
        assertEquals("cancelled", ReportsQueryBuilder.getSortPropertyMappedForReviewer(CANCELLED));
        assertEquals("completed", ReportsQueryBuilder.getSortPropertyMappedForReviewer(COMPLETED));
        assertNull(ReportsQueryBuilder.getSortPropertyMappedForReviewer("unknown"));
    }

    @Test
    void testGetSortPropertyMappedForTat_allBranches() {
        assertEquals("data.hon", ReportsQueryBuilder.getSortPropertyMappedForTAT(HON));
        assertEquals("data.organizationName", ReportsQueryBuilder.getSortPropertyMappedForTAT(ORGANIZATION_NAME));
        assertEquals("data.address", ReportsQueryBuilder.getSortPropertyMappedForTAT(ADDRESS));
        assertEquals("data.verificationValidationDate", ReportsQueryBuilder.getSortPropertyMappedForTAT(VERIFICATION_DATE));
        assertEquals("data.organizationType", ReportsQueryBuilder.getSortPropertyMappedForTAT(ORGANIZATION_TYPE));
        assertEquals("data.approvalStatus", ReportsQueryBuilder.getSortPropertyMappedForTAT(APPROVAL_STATUS));
        assertEquals("data.approvedBy", ReportsQueryBuilder.getSortPropertyMappedForTAT(APPROVED_BY));
        assertEquals("data.createdBy", ReportsQueryBuilder.getSortPropertyMappedForTAT(CREATED_BY));
        assertEquals("data.autoMatch", ReportsQueryBuilder.getSortPropertyMappedForTAT(AUTO_MATCH));
        assertEquals("data.reason", ReportsQueryBuilder.getSortPropertyMappedForTAT(REASON));
        assertEquals("data.action", ReportsQueryBuilder.getSortPropertyMappedForTAT(CHANGE_TYPE));
        assertEquals("data.usedCount", ReportsQueryBuilder.getSortPropertyMappedForTAT(USED_COUNT));
        assertEquals("data.origin", ReportsQueryBuilder.getSortPropertyMappedForTAT(ORIGIN));
        assertEquals("data.createdDate", ReportsQueryBuilder.getSortPropertyMappedForTAT(USED_DATE));
        assertNull(ReportsQueryBuilder.getSortPropertyMappedForTAT("unknown"));
    }

    @Test
    void testGetSortPropertyMappedForOperator_allBranches() {
        assertEquals("operatorName", ReportsQueryBuilder.getSortPropertyMappedForOperator(OPERATOR_NAME));
        assertEquals("addedNew", ReportsQueryBuilder.getSortPropertyMappedForOperator(ADDED_NEW));
        assertEquals("addedInProgress", ReportsQueryBuilder.getSortPropertyMappedForOperator(ADDED_IN_PROGRESS));
        assertEquals("addedOnHold", ReportsQueryBuilder.getSortPropertyMappedForOperator(ADDED_ON_HOLD));
        assertEquals("addedCancelled", ReportsQueryBuilder.getSortPropertyMappedForOperator(ADDED_CANCELLED));
        assertEquals("addedCompleted", ReportsQueryBuilder.getSortPropertyMappedForOperator(ADDED_COMPLETED));
        assertEquals("changedNew", ReportsQueryBuilder.getSortPropertyMappedForOperator(CHANGED_NEW));
        assertEquals("changedInProgress", ReportsQueryBuilder.getSortPropertyMappedForOperator(CHANGED_IN_PROGRESS));
        assertEquals("changedOnHold", ReportsQueryBuilder.getSortPropertyMappedForOperator(CHANGED_ON_HOLD));
        assertEquals("changedCancelled", ReportsQueryBuilder.getSortPropertyMappedForOperator(CHANGED_CANCELLED));
        assertEquals("changedCompleted", ReportsQueryBuilder.getSortPropertyMappedForOperator(CHANGED_COMPLETED));
        assertEquals("archivedNew", ReportsQueryBuilder.getSortPropertyMappedForOperator(ARCHIVED_NEW));
        assertEquals("archivedInProgress", ReportsQueryBuilder.getSortPropertyMappedForOperator(ARCHIVED_IN_PROGRESS));
        assertEquals("archivedOnHold", ReportsQueryBuilder.getSortPropertyMappedForOperator(ARCHIVED_ON_HOLD));
        assertEquals("archivedCancelled", ReportsQueryBuilder.getSortPropertyMappedForOperator(ARCHIVED_CANCELLED));
        assertEquals("archivedCompleted", ReportsQueryBuilder.getSortPropertyMappedForOperator(ARCHIVED_COMPLETED));
        assertEquals("deletedNew", ReportsQueryBuilder.getSortPropertyMappedForOperator(DELETED_NEW));
        assertEquals("deletedInProgress", ReportsQueryBuilder.getSortPropertyMappedForOperator(DELETED_IN_PROGRESS));
        assertEquals("deletedOnHold", ReportsQueryBuilder.getSortPropertyMappedForOperator(DELETED_ON_HOLD));
        assertEquals("deletedCancelled", ReportsQueryBuilder.getSortPropertyMappedForOperator(DELETED_CANCELLED));
        assertEquals("deletedCompleted", ReportsQueryBuilder.getSortPropertyMappedForOperator(DELETED_COMPLETED));
        assertNull(ReportsQueryBuilder.getSortPropertyMappedForOperator("unknown"));
    }

    @Test
    void testBuildSortOperation_withValues() {
        SortOperation sortOperation = ReportsQueryBuilder.buildSortOperation(ORGANIZATION_NAME, "asc");
        Document doc = sortOperation.toDocument(Aggregation.DEFAULT_CONTEXT);

        assertNotNull(sortOperation);
        assertTrue(doc.toJson().contains("organizationName"));
        assertTrue(doc.toJson().contains("1"));
    }

    @Test
    void testBuildSortOperation_defaultBranch() {
        SortOperation sortOperation = ReportsQueryBuilder.buildSortOperation(null, null);
        Document doc = sortOperation.toDocument(Aggregation.DEFAULT_CONTEXT);

        assertNotNull(sortOperation);
        assertTrue(doc.toJson().contains("createdDate"));
        assertTrue(doc.toJson().contains("-1"));
    }

    @Test
    void testBuildSortOperationForTat_withValues() {
        SortOperation sortOperation = ReportsQueryBuilder.buildSortOperationForTAT(ORGANIZATION_NAME, "desc");
        Document doc = sortOperation.toDocument(Aggregation.DEFAULT_CONTEXT);

        assertNotNull(sortOperation);
        assertTrue(doc.toJson().contains("data.organizationName"));
        assertTrue(doc.toJson().contains("-1"));
    }

    @Test
    void testBuildSortOperationForTat_defaultBranch() {
        SortOperation sortOperation = ReportsQueryBuilder.buildSortOperationForTAT(null, null);
        Document doc = sortOperation.toDocument(Aggregation.DEFAULT_CONTEXT);

        assertNotNull(sortOperation);
        assertTrue(doc.toJson().contains("createdDate"));
    }

    @Test
    void testBuildSortOperationForTat_invalidSort() {
        assertThrows(Exception.class,
                () -> ReportsQueryBuilder.buildSortOperationForTAT("invalid-field", "asc"));
    }

    @Test
    void testBuildSortOperationForReviewer_withValues() {
        SortOperation sortOperation = ReportsQueryBuilder.buildSortOperationForReviewer(RESEARCHER_NAME, "asc");
        Document doc = sortOperation.toDocument(Aggregation.DEFAULT_CONTEXT);

        assertNotNull(sortOperation);
        assertTrue(doc.toJson().contains("researcherName"));
        assertTrue(doc.toJson().contains("1"));
    }

    @Test
    void testBuildSortOperationForReviewer_defaultBranch() {
        SortOperation sortOperation = ReportsQueryBuilder.buildSortOperationForReviewer(null, null);
        Document doc = sortOperation.toDocument(Aggregation.DEFAULT_CONTEXT);

        assertNotNull(sortOperation);
        assertTrue(doc.toJson().contains("researcherName"));
        assertTrue(doc.toJson().contains("-1"));
    }

    @Test
    void testBuildSortOperationForReviewer_invalidSort() {
        assertThrows(Exception.class,
                () -> ReportsQueryBuilder.buildSortOperationForReviewer("invalid-field", "asc"));
    }

    @Test
    void testBuildSortOperationForOperator_withValues() {
        SortOperation sortOperation = ReportsQueryBuilder.buildSortOperationForOperator(OPERATOR_NAME, "desc");
        Document doc = sortOperation.toDocument(Aggregation.DEFAULT_CONTEXT);

        assertNotNull(sortOperation);
        assertTrue(doc.toJson().contains("operatorName"));
        assertTrue(doc.toJson().contains("-1"));
    }

    @Test
    void testBuildSortOperationForOperator_defaultBranch() {
        SortOperation sortOperation = ReportsQueryBuilder.buildSortOperationForOperator(null, null);
        Document doc = sortOperation.toDocument(Aggregation.DEFAULT_CONTEXT);

        assertNotNull(sortOperation);
        assertTrue(doc.toJson().contains("operatorName"));
        assertTrue(doc.toJson().contains("-1"));
    }

    @Test
    void testBuildSortOperationForOperator_invalidSort() {
        assertThrows(Exception.class,
                () -> ReportsQueryBuilder.buildSortOperationForOperator("invalid-field", "asc"));
    }

    @Test
    void testGetSortOrderDirection() {
        assertEquals(Sort.Direction.ASC, ReportsQueryBuilder.getSortOrderDirection("ASC"));
        assertEquals(Sort.Direction.ASC, ReportsQueryBuilder.getSortOrderDirection("asc"));
        assertEquals(Sort.Direction.DESC, ReportsQueryBuilder.getSortOrderDirection("desc"));
        assertEquals(Sort.Direction.DESC, ReportsQueryBuilder.getSortOrderDirection("anythingElse"));
    }
}