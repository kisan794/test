package com.hireright.sourceintelligence.service.excel;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class ExcelColumnMappingTest {

    private Workbook workbook;
    private Sheet sheet;

    @BeforeEach
    void setUp() {
        workbook = new XSSFWorkbook();
        sheet = workbook.createSheet("Test Sheet");
    }

    @AfterEach
    void tearDown() throws IOException {
        if (workbook != null) {
            workbook.close();
        }
    }

    @Test
    void builder_WithAddColumn_ShouldCreateMapping() {
        ExcelColumnMapping mapping = ExcelColumnMapping.builder()
                .addColumn("institutionName", 0)
                .addColumn("country", 1)
                .addColumn("city", 2)
                .build();

        assertEquals(0, mapping.getColumnIndex("institutionName"));
        assertEquals(1, mapping.getColumnIndex("country"));
        assertEquals(2, mapping.getColumnIndex("city"));
    }

    @Test
    void builder_WithHeaderMapping_ShouldCreateMapping() {
        ExcelColumnMapping mapping = ExcelColumnMapping.builder()
                .addHeaderMapping("Institution Name", "institutionName")
                .addHeaderMapping("Country", "country")
                .headerRowIndex(0)
                .dataStartRowIndex(1)
                .sheetIndex(0)
                .build();

        assertNotNull(mapping);
        assertEquals(0, mapping.getHeaderRowIndex());
        assertEquals(1, mapping.getDataStartRowIndex());
        assertEquals(0, mapping.getSheetIndex());
    }

    @Test
    void getColumnIndex_WithNonExistentField_ShouldReturnNull() {
        ExcelColumnMapping mapping = ExcelColumnMapping.builder()
                .addColumn("institutionName", 0)
                .build();

        assertNull(mapping.getColumnIndex("nonExistentField"));
    }

    @Test
    void buildFromHeaderRow_ShouldMapHeadersToFieldNames() {
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Institution Name");
        headerRow.createCell(1).setCellValue("Country");
        headerRow.createCell(2).setCellValue("City");

        ExcelColumnMapping baseMapping = ExcelColumnMapping.builder()
                .addHeaderMapping("Institution Name", "institutionName")
                .addHeaderMapping("Country", "country")
                .addHeaderMapping("City", "city")
                .headerRowIndex(0)
                .dataStartRowIndex(1)
                .build();

        ExcelColumnMapping dynamicMapping = baseMapping.buildFromHeaderRow(headerRow);

        assertEquals(0, dynamicMapping.getColumnIndex("institutionName"));
        assertEquals(1, dynamicMapping.getColumnIndex("country"));
        assertEquals(2, dynamicMapping.getColumnIndex("city"));
    }

    @Test
    void buildFromHeaderRow_WithMissingHeaders_ShouldMapOnlyExisting() {
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Institution Name");
        headerRow.createCell(1).setCellValue("Country");

        ExcelColumnMapping baseMapping = ExcelColumnMapping.builder()
                .addHeaderMapping("Institution Name", "institutionName")
                .addHeaderMapping("Country", "country")
                .addHeaderMapping("City", "city")
                .headerRowIndex(0)
                .dataStartRowIndex(1)
                .build();

        ExcelColumnMapping dynamicMapping = baseMapping.buildFromHeaderRow(headerRow);

        assertEquals(0, dynamicMapping.getColumnIndex("institutionName"));
        assertEquals(1, dynamicMapping.getColumnIndex("country"));
        assertNull(dynamicMapping.getColumnIndex("city"));
    }

    @Test
    void buildFromHeaderRow_WithEmptyHeaderMapping_ShouldReturnSameInstance() {
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Institution Name");

        ExcelColumnMapping baseMapping = ExcelColumnMapping.builder()
                .addColumn("institutionName", 0)
                .headerRowIndex(0)
                .dataStartRowIndex(1)
                .build();

        ExcelColumnMapping result = baseMapping.buildFromHeaderRow(headerRow);

        assertNotNull(result);
        assertEquals(0, result.getColumnIndex("institutionName"));
    }

    @Test
    void buildFromHeaderRow_WithNullCells_ShouldSkipNullCells() {
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Institution Name");
        // Cell 1 is null
        headerRow.createCell(2).setCellValue("City");

        ExcelColumnMapping baseMapping = ExcelColumnMapping.builder()
                .addHeaderMapping("Institution Name", "institutionName")
                .addHeaderMapping("Country", "country")
                .addHeaderMapping("City", "city")
                .headerRowIndex(0)
                .dataStartRowIndex(1)
                .build();

        ExcelColumnMapping dynamicMapping = baseMapping.buildFromHeaderRow(headerRow);

        assertEquals(0, dynamicMapping.getColumnIndex("institutionName"));
        assertNull(dynamicMapping.getColumnIndex("country"));
        assertEquals(2, dynamicMapping.getColumnIndex("city"));
    }

    @Test
    void buildFromHeaderRow_WithExtraWhitespace_ShouldTrimAndMatch() {
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("  Institution Name  ");
        headerRow.createCell(1).setCellValue("Country ");

        ExcelColumnMapping baseMapping = ExcelColumnMapping.builder()
                .addHeaderMapping("Institution Name", "institutionName")
                .addHeaderMapping("Country", "country")
                .headerRowIndex(0)
                .dataStartRowIndex(1)
                .build();

        ExcelColumnMapping dynamicMapping = baseMapping.buildFromHeaderRow(headerRow);

        assertEquals(0, dynamicMapping.getColumnIndex("institutionName"));
        assertEquals(1, dynamicMapping.getColumnIndex("country"));
    }

    @Test
    void builder_WithCustomIndices_ShouldRespectIndices() {
        ExcelColumnMapping mapping = ExcelColumnMapping.builder()
                .headerRowIndex(2)
                .dataStartRowIndex(5)
                .sheetIndex(3)
                .build();

        assertEquals(2, mapping.getHeaderRowIndex());
        assertEquals(5, mapping.getDataStartRowIndex());
        assertEquals(3, mapping.getSheetIndex());
    }

    @Test
    void builder_WithDefaultIndices_ShouldUseDefaults() {
        ExcelColumnMapping mapping = ExcelColumnMapping.builder()
                .build();

        assertEquals(0, mapping.getHeaderRowIndex());
        assertEquals(1, mapping.getDataStartRowIndex());
        assertEquals(0, mapping.getSheetIndex());
    }

    @Test
    void builder_WithMultipleHeaderMappings_ShouldStoreAllMappings() {
        ExcelColumnMapping mapping = ExcelColumnMapping.builder()
                .addHeaderMapping("Institution Name", "institutionName")
                .addHeaderMapping("Country", "country")
                .addHeaderMapping("City", "city")
                .addHeaderMapping("State/County/Region", "stateCountyRegion")
                .addHeaderMapping("Service Provider", "serviceProvider")
                .addHeaderMapping("Surcharge Amount", "surchargeAmount")
                .addHeaderMapping("Payment Method", "paymentMethod")
                .addHeaderMapping("Code", "code")
                .addHeaderMapping("Turnaround Time", "turnaroundTime")
                .addHeaderMapping("Follow Up Allowed", "followUpAllowed")
                .build();

        assertNotNull(mapping);
    }

    @Test
    void buildFromHeaderRow_WithParchmentHeaders_ShouldMapAllFields() {
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Institution Name");
        headerRow.createCell(1).setCellValue("Country");
        headerRow.createCell(2).setCellValue("City");
        headerRow.createCell(3).setCellValue("State/County/Region");
        headerRow.createCell(4).setCellValue("Service Provider");
        headerRow.createCell(5).setCellValue("Surcharge Amount");
        headerRow.createCell(6).setCellValue("Payment Method");
        headerRow.createCell(7).setCellValue("Code");
        headerRow.createCell(8).setCellValue("Turnaround Time");
        headerRow.createCell(9).setCellValue("Follow Up Allowed");

        ExcelColumnMapping baseMapping = ExcelColumnMapping.builder()
                .addHeaderMapping("Institution Name", "institutionName")
                .addHeaderMapping("Country", "country")
                .addHeaderMapping("City", "city")
                .addHeaderMapping("State/County/Region", "stateCountyRegion")
                .addHeaderMapping("Service Provider", "serviceProvider")
                .addHeaderMapping("Surcharge Amount", "surchargeAmount")
                .addHeaderMapping("Payment Method", "paymentMethod")
                .addHeaderMapping("Code", "code")
                .addHeaderMapping("Turnaround Time", "turnaroundTime")
                .addHeaderMapping("Follow Up Allowed", "followUpAllowed")
                .headerRowIndex(0)
                .dataStartRowIndex(1)
                .build();

        ExcelColumnMapping dynamicMapping = baseMapping.buildFromHeaderRow(headerRow);

        assertEquals(0, dynamicMapping.getColumnIndex("institutionName"));
        assertEquals(1, dynamicMapping.getColumnIndex("country"));
        assertEquals(2, dynamicMapping.getColumnIndex("city"));
        assertEquals(3, dynamicMapping.getColumnIndex("stateCountyRegion"));
        assertEquals(4, dynamicMapping.getColumnIndex("serviceProvider"));
        assertEquals(5, dynamicMapping.getColumnIndex("surchargeAmount"));
        assertEquals(6, dynamicMapping.getColumnIndex("paymentMethod"));
        assertEquals(7, dynamicMapping.getColumnIndex("code"));
        assertEquals(8, dynamicMapping.getColumnIndex("turnaroundTime"));
        assertEquals(9, dynamicMapping.getColumnIndex("followUpAllowed"));
    }

    @Test
    void buildFromHeaderRow_WithUnrecognizedHeaders_ShouldIgnoreThem() {
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Institution Name");
        headerRow.createCell(1).setCellValue("Unknown Header");
        headerRow.createCell(2).setCellValue("Country");

        ExcelColumnMapping baseMapping = ExcelColumnMapping.builder()
                .addHeaderMapping("Institution Name", "institutionName")
                .addHeaderMapping("Country", "country")
                .headerRowIndex(0)
                .dataStartRowIndex(1)
                .build();

        ExcelColumnMapping dynamicMapping = baseMapping.buildFromHeaderRow(headerRow);

        assertEquals(0, dynamicMapping.getColumnIndex("institutionName"));
        assertEquals(2, dynamicMapping.getColumnIndex("country"));
        assertNull(dynamicMapping.getColumnIndex("Unknown Header"));
    }

    @Test
    void builder_ChainedCalls_ShouldReturnBuilderInstance() {
        ExcelColumnMapping.Builder builder = ExcelColumnMapping.builder();

        assertSame(builder, builder.addColumn("field1", 0));
        assertSame(builder, builder.addHeaderMapping("Header1", "field1"));
        assertSame(builder, builder.headerRowIndex(0));
        assertSame(builder, builder.dataStartRowIndex(1));
        assertSame(builder, builder.sheetIndex(0));
    }
}