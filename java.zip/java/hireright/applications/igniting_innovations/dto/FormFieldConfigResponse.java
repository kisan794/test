package hireright.applications.igniting_innovations.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/***
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Response object containing form field configuration")
public class FormFieldConfigResponse {

    @Schema(description = "Unique identifier")
    @JsonProperty("id")
    private String id;

    @Schema(description = "Unique identifier for the field")
    @JsonProperty("fieldKey")
    private String fieldKey;

    @Schema(description = "List of options for the field")
    @JsonProperty("options")
    private List<FieldOptionResponse> options;

    @Schema(description = "Created timestamp")
    @JsonProperty("createdAt")
    private LocalDateTime createdAt;

    @Schema(description = "Last updated timestamp")
    @JsonProperty("updatedAt")
    private LocalDateTime updatedAt;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "Field option")
    public static class FieldOptionResponse {

        @Schema(description = "Option value")
        @JsonProperty("value")
        private String value;

        @Schema(description = "Option label")
        @JsonProperty("label")
        private String label;
    }
}

