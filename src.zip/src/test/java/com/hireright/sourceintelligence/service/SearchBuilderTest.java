package com.hireright.sourceintelligence.service;
import com.hireright.sourceintelligence.api.dto.DateRange;
import com.hireright.sourceintelligence.api.dto.SearchDTO;
import com.hireright.sourceintelligence.api.dto.SearchFilter;
import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.exception.InvalidRequestException;
import com.hireright.sourceintelligence.service.impl.QueryBuilder;
import com.hireright.sourceintelligence.util.TestDataProvider;
import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.aggregation.FacetOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.query.Criteria;

import java.time.Instant;
import java.util.*;

import static com.hireright.sourceintelligence.api.ApiConstants.HON;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.*;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatNoException;

@ExtendWith(MockitoExtension.class)
public class SearchBuilderTest {

    @Test
    void buildCriteriaForLikeStartsWithTest(){
        assertThatNoException().isThrownBy(()-> QueryBuilder.buildCriteriaForLikeStartsWith("fieldName","fieldValue"));
    }

//    @Test
//    void buildSearchDocumentTest(){
//        SearchDTO searchDTO = TestDataProvider.getSearchDTO();
//        searchDTO.setSearchText("searchText");
//        assertThatNoException().isThrownBy(()->QueryBuilder.buildSearchDocument(searchDTO));
//
//    }

//    @Test
//    void phraseSearchBuilderTest(){
//        assertThatNoException().isThrownBy(()->SearchBuilder.phraseSearchBuilder("searchPhrase", SourceOrganizationStatus.ACTIVE));
//
//    }

//    @Test
//    void buildMustClauseDocumentTest(){
//        List<SearchFilter> searchFilterList = new ArrayList<>();
//        SearchFilter countrySearchFilter = new SearchFilter();
//        countrySearchFilter.setSearchKey("country");
//        countrySearchFilter.setSearchField("country");
//
//        SearchFilter orgNameSearchFilter = new SearchFilter();
//        orgNameSearchFilter.setSearchKey("organizationName");
//        orgNameSearchFilter.setSearchField("organizationName");
//
//        SearchFilter orgAliasSearchFilter = new SearchFilter();
//        orgAliasSearchFilter.setSearchKey("organizationAlias.name");
//        orgAliasSearchFilter.setSearchField("organizationAlias.name");
//
//        SearchFilter citySearchFilter = new SearchFilter();
//        citySearchFilter.setSearchKey("city");
//        citySearchFilter.setSearchField("city");
//
//        SearchFilter stateSearchFilter = new SearchFilter();
//        stateSearchFilter.setSearchKey("state");
//        stateSearchFilter.setSearchField("state");
//
//        SearchFilter postalCodeSearchFilter = new SearchFilter();
//        postalCodeSearchFilter.setSearchKey("postalCode");
//        postalCodeSearchFilter.setSearchField("postalCode");
//
//        searchFilterList.add(countrySearchFilter);
//        searchFilterList.add(orgNameSearchFilter);
//        searchFilterList.add(orgAliasSearchFilter);
//        searchFilterList.add(citySearchFilter);
//        searchFilterList.add(stateSearchFilter);
//        searchFilterList.add(postalCodeSearchFilter);
//        assertThatNoException().isThrownBy(()->QueryBuilder.buildMustClauseDocument(searchFilterList));
//
//    }

//    @Test
//    void buildMustClauseDocumentInvalidRequestTest(){
//        List<SearchFilter> searchFilterList = new ArrayList<>();
//        SearchFilter countrySearchFilter = new SearchFilter();
//        countrySearchFilter.setSearchKey("invalid");
//        countrySearchFilter.setSearchField("invalid");
//
//        searchFilterList.add(countrySearchFilter);
//
//        assertThatExceptionOfType(InvalidRequestException.class).isThrownBy(()->QueryBuilder.buildMustClauseDocument(searchFilterList));
//
//    }

//    @Test
//    void phraseSearchProjectionTest(){
//
//        assertThatNoException().isThrownBy(QueryBuilder::phraseSearchProjection);
//
//    }

    @Test
    void getSortPropertyMappedOrgNameTest(){

        assertThatNoException().isThrownBy(()->QueryBuilder.getSortPropertyMapped("organizationName"));

    }

    @Test
    void getSortPropertyMappedValidatedTest(){

        assertThatNoException().isThrownBy(()->QueryBuilder.getSortPropertyMapped("validated"));

    }

    @Test
    void getSortPropertyMappedLastActiveTest(){

        assertThatNoException().isThrownBy(()->QueryBuilder.getSortPropertyMapped("lastActive"));

    }

    @Test
    void getSortPropertyMappedLocationTest(){

        assertThatNoException().isThrownBy(()->QueryBuilder.getSortPropertyMapped("location"));

    }

    @Test
    void getSortPropertyMappedPrimaryContactTest(){

        assertThatNoException().isThrownBy(()->QueryBuilder.getSortPropertyMapped("primaryContact"));

    }

    @Test
    void getSortPropertyMappedOrgTypeTest(){

        assertThatNoException().isThrownBy(()->QueryBuilder.getSortPropertyMapped("organizationType"));

    }

    @Test
    void getSortPropertyMappedDefaultTest(){

        assertThatNoException().isThrownBy(()->QueryBuilder.getSortPropertyMapped("default"));

    }

    @Test
    void searchQueryCountryTest(){
        SearchDTO searchDTO = TestDataProvider.getSearchDTO();
        searchDTO.setSearchText("searchText");
        searchDTO.setCountry("country");
        searchDTO.setState("state");
        searchDTO.setCity("city");
        assertThatNoException().isThrownBy(()->QueryBuilder.searchQuery(searchDTO));
    }

    @Test
    void getSortOrderDirectionTest(){
        assertThatNoException().isThrownBy(()->QueryBuilder.getSortOrderDirection("asc"));
    }

//    @Test
//    void addMatchStageTest(){
//        assertThatNoException().isThrownBy(()->QueryBuilder.addMatchStage(new HashMap<>()));
//    }

    @Test
    void queryCriteriaForNonArrayFieldsTest(){
        SourceOrganizationDTO sourceOrganizationDTO = new SourceOrganizationDTO();
        sourceOrganizationDTO.setOrganizationName("orgName");
        sourceOrganizationDTO.setPayload(new JSONObject("{\"lastModified\": \"2020-01-16T03:11:07+0200\","
                + "\"country\": \"USA\",\"state\": \"California\",\"created\": \"2020-01-16T03:11:07+0200\","
                + "\"lastApproverClass\": \"OPERATOR\", \"usedCount\": 30}"));
        JSONArray addressArray = new JSONArray();

        JSONObject address = new JSONObject();
        address.put("countryCode", "123");
        address.put("state", "state");
        address.put("city", "Los Angeles");
        address.put("zipCode", "90001");
        address.put("country", "USA");
        address.put("line","line");
        addressArray.put(address);
        sourceOrganizationDTO.getPayload().put("address",addressArray);
        sourceOrganizationDTO.getPayload().put("departmentName","departmentName");
        assertThatNoException().isThrownBy(()->QueryBuilder.queryCriteriaForNonArrayFields(sourceOrganizationDTO));
    }

    @Test
    void buildMustClauseDocumentWithFiltersInvalidRequestTest(){
        Map<String, Set<String>> searchFilters = TestDataProvider.getSearchFilterForSourceHistoryList();
        assertThatExceptionOfType(InvalidRequestException.class).isThrownBy(()->QueryBuilder.buildMustClauseDocumentWithFilters(searchFilters));
    }

    @Test
    void buildMustClauseDocumentWithFiltersTest(){
        Map<String, Set<String>> searchFilters = getSearchFilterList();
        assertThatNoException().isThrownBy(()->QueryBuilder.buildMustClauseDocumentWithFilters(searchFilters));
    }

    @Test
    void changeLogDateMatchDocumentTest(){
        DateRange dateRange = new DateRange();
        dateRange.setStartDate(Instant.now());
        dateRange.setEndDate(Instant.now());
        assertThatNoException().isThrownBy(()->QueryBuilder.changeLogDateMatchDocument(dateRange));
    }

    private Map<String, Set<String>>  getSearchFilterList(){
        Map<String, Set<String>> searchFilter = new HashMap<>();

        searchFilter.put(ORGANIZATION_NAME,Set.of("pedro"));
        searchFilter.put(HON,Set.of("OUEDU-090122-3O2WXF5"));
        searchFilter.put(ORGANIZATION_ALIAS,Set.of("pedro"));

        Set<String> assignees = new HashSet();
        assignees.add("Unassigned");
        searchFilter.put(ASSIGNED_TO,assignees);

        Set<String> regions = new HashSet();
        regions.add("APAC");
        searchFilter.put(STATE,regions);

        Set<String> countries = new HashSet();
        countries.add("USA");
        searchFilter.put(COUNTRY,countries);

        Set<String> cities = new HashSet();
        cities.add("US");
        searchFilter.put(CITY,cities);

        Set<String> postalCode = new HashSet();
        postalCode.add("500000");
        searchFilter.put(POSTAL_CODE,postalCode);

        Set<String> status = new HashSet();
        status.add("ACTIVE");
        searchFilter.put(STATUS,status);

        return searchFilter;
    }
}
