package com.hireright.sourceintelligence.service.notification.impl;

import com.hireright.sourceintelligence.api.dto.notification.DataExtractionNotificationDTO;
import com.hireright.sourceintelligence.api.dto.notification.EmailNotificationDTO;
import com.hireright.sourceintelligence.api.dto.notification.NotificationResponseDTO;
import com.hireright.sourceintelligence.service.notification.EmailNotificationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for DataExtractionNotificationServiceImpl
 */
@ExtendWith(MockitoExtension.class)
class DataExtractionNotificationServiceImplTest {
    
    @Mock
    private EmailNotificationService emailNotificationService;
    
    @InjectMocks
    private DataExtractionNotificationServiceImpl dataExtractionNotificationService;
    
    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(dataExtractionNotificationService, "defaultSubject", 
                "Data Extraction Completed");
    }
    
    @Test
    void testSendDataExtractionNotification_Success() {
        // Given
        DataExtractionNotificationDTO notification = DataExtractionNotificationDTO.builder()
                .recipients(List.of("test@example.com"))
                .dataExtractionType("parchment")
                .filename("test.xlsx")
                .totalRecords(100)
                .totalSourcesUpdated(80)
                .notFoundRecords(20)
                .processingTimeMs(5000L)
                .build();
        
        String expectedNotificationId = UUID.randomUUID().toString();
        when(emailNotificationService.sendEmail(any(EmailNotificationDTO.class)))
                .thenReturn(expectedNotificationId);
        
        // When
        NotificationResponseDTO response = dataExtractionNotificationService
                .sendDataExtractionNotification(notification);
        
        // Then
        assertNotNull(response);
        assertEquals("SUCCESS", response.getStatus());
        assertEquals(1, response.getRecipientCount());
        verify(emailNotificationService, times(1)).sendEmail(any(EmailNotificationDTO.class));
    }
    
    @Test
    void testSendDataExtractionNotification_Failure() {
        // Given
        DataExtractionNotificationDTO notification = DataExtractionNotificationDTO.builder()
                .recipients(List.of("test@example.com"))
                .dataExtractionType("parchment")
                .filename("test.xlsx")
                .build();
        
        when(emailNotificationService.sendEmail(any(EmailNotificationDTO.class)))
                .thenThrow(new RuntimeException("Email send failed"));
        
        // When
        NotificationResponseDTO response = dataExtractionNotificationService
                .sendDataExtractionNotification(notification);
        
        // Then
        assertNotNull(response);
        assertEquals("FAILURE", response.getStatus());
        assertNotNull(response.getError());
        verify(emailNotificationService, times(1)).sendEmail(any(EmailNotificationDTO.class));
    }
    
    @Test
    void testSendDataExtractionNotification_MultipleRecipients() {
        // Given
        List<String> recipients = List.of("test1@example.com", "test2@example.com", "test3@example.com");
        DataExtractionNotificationDTO notification = DataExtractionNotificationDTO.builder()
                .recipients(recipients)
                .dataExtractionType("parchment")
                .filename("test.xlsx")
                .totalRecords(100)
                .build();
        
        String expectedNotificationId = UUID.randomUUID().toString();
        when(emailNotificationService.sendEmail(any(EmailNotificationDTO.class)))
                .thenReturn(expectedNotificationId);
        
        // When
        NotificationResponseDTO response = dataExtractionNotificationService
                .sendDataExtractionNotification(notification);
        
        // Then
        assertNotNull(response);
        assertEquals("SUCCESS", response.getStatus());
        assertEquals(3, response.getRecipientCount());
    }
}

