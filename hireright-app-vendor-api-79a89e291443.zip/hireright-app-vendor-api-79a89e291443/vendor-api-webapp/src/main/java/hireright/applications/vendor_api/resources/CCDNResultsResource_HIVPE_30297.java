/*
 *
 * Copyright 2001-2018 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	T.Prikk		2018-04-21	HIVPE-30297: Created
 *  H.Maibak	2025-03-11  HRG-332869: Added MultitenantDB logic
 */
package hireright.applications.vendor_api.resources;

import java.util.HashMap;
import java.util.Map;

import hireright.objects.order2.COrderDBContainer;
import hireright.objects.order2.COrderServiceDBContainer;
import hireright.sdk.db.CMultitenantDB;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import hireright.applications.vendor_api.EVendorReference;
import hireright.applications.vendor_api.exchange.handler.utils.CExchangeUtils;
import hireright.applications.vendor_api.facades.ErrorResponseFacade;
import hireright.applications.vendor_api.services.IMethod;
import hireright.applications.vendor_api.vendor_api_client.VendorAPIClient;
import hireright.components.domain.dialects.vendor_api.BasicResponse;
import hireright.objects.order2.COrderServiceProperty;
import hireright.objects.utilities.CDomainPropertyFactory;
import hireright.project.global_platform.sdk_cdn_client.gateways.CResultGateway;
import hireright.sdk.db3.DB;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CStringUtils;

@RestController
public class CCDNResultsResource_HIVPE_30297
{
	private static final String VAR_ORDER_CODE = "orderCode";
	private static final String VAR_ORDER_SERVICE_CODE = "orderServiceCode";
	private static final String VAR_ORDER_SERVICE_ID = "orderServiceId";

	private static final String PATH_GET_REMOTE_RESULTS = "/get_service_result/service/{" + VAR_ORDER_SERVICE_ID + "}";
	private static final String PATH_GET_LOCAL_RESULTS = "/cdn/orders/{" + VAR_ORDER_CODE + "}/services/{" + VAR_ORDER_SERVICE_CODE+ "}";

	private static class LocalResultsMethod implements IMethod
	{
		public String getPath() {
			return PATH_GET_LOCAL_RESULTS;
		}
		public RequestMethod getRequestMethod() {
			return RequestMethod.GET;
		}
		public Class<?> getRequestBodyClass() {
			return String.class;
		}
		public Class<?> getResponseBodyClass() {
			return String.class;
		}
		public boolean isValidRequest(Object request) {
			return true;
		}
	}

	/**
	 * Temporary replacement for bdk_order_service_reports.get_externalResults() on UK.<br/>
	 * Needed to avoid changing PL-SQL when resolving HIVPE-30297
	 * 
	 * @param nOrderServiceId Local orderServiceID
	 * @return US result GW service results XML
	 */
	@RequestMapping(path = PATH_GET_REMOTE_RESULTS,
			method = RequestMethod.GET,
			produces = MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity<String> getRemoteServiceResult(
		@PathVariable(name=VAR_ORDER_SERVICE_ID) final Long nOrderServiceId
	) throws Exception
	{
		return DB.execute(() -> CMultitenantDB.execute(() -> COrderServiceDBContainer.getContainerIDByOrderServiceID(nOrderServiceId),
			targetTenantCode -> {
				String sOrderCode = getOrderServiceProp(nOrderServiceId, EVendorReference.VENDOR_ORDER_REF.getPropertyName());
				String sOrderServiceCode = getOrderServiceProp(nOrderServiceId, EVendorReference.VENDOR_ORDER_SERVICE_REF.getPropertyName());

				if(!CStringUtils.isEmpty(sOrderCode) && !CStringUtils.isEmpty(sOrderServiceCode))
				{
					Map<String, String> requestParams = new HashMap<>();
					VendorAPIClient client = getClient(nOrderServiceId);

					requestParams.put(VAR_ORDER_CODE, sOrderCode);
					requestParams.put(VAR_ORDER_SERVICE_CODE, sOrderServiceCode);

					String sResponseXML = client.execute(new LocalResultsMethod(), requestParams, null);
					return ResponseEntity.ok(sResponseXML);
				}

				return ResponseEntity.notFound().build();
			}
		));
	}

	@RequestMapping(path = PATH_GET_LOCAL_RESULTS,
			method = RequestMethod.GET,
			produces = MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity<String> getLocalServiceResult(
		@PathVariable(name=VAR_ORDER_CODE) final String sOrderCode,
		@PathVariable(name=VAR_ORDER_SERVICE_CODE) final String sOrderServiceCode
	) throws Exception
	{
		return DB.execute(() -> CMultitenantDB.execute(() -> COrderDBContainer.getContainerIDByOrderCode(sOrderCode),
			targetTenantCode -> {
				Long nOrderServiceID = CExchangeUtils.getOrderServiceID(sOrderCode, sOrderServiceCode);
				if(nOrderServiceID != null)
				{
					String sResults = CResultGateway.getServiceResults(nOrderServiceID.intValue());
					return ResponseEntity.ok(sResults);
				}

				return ResponseEntity.notFound().build();
			}
		));
	}

	private VendorAPIClient getClient(Long nOrderServiceID)
	{
		Map<String, Object> clientProperties = new HashMap<>();
		
		COrderServiceProperty domainProp = COrderServiceProperty.getPropertyByName(nOrderServiceID, 
				EVendorReference.VENDOR_INSTANCE_REF.getPropertyName(),
				"HR-USA");
		
		CDomainPropertyFactory.getProperties(domainProp.getValue()).forEach(property -> {
			clientProperties.put(property.getName(), property.getValue());
		});
		
		return VendorAPIClient.getInstance(domainProp.getValue(), clientProperties);
	}

	private String getOrderServiceProp(Long nOrderServiceId, String sProperty)
	{
		COrderServiceProperty property = COrderServiceProperty.getPropertyByName(nOrderServiceId, sProperty);
		
		if (property == null) {
			return null;
		}
		
		return property.getValue();
	}

	@ExceptionHandler({Exception.class})
	public ResponseEntity<BasicResponse> handleError(Exception ex)
	{
		Long nErrorID = CTraceLog.error(ex);
		ErrorResponseFacade errorResponseFacade =
			new ErrorResponseFacade(nErrorID.toString(), ex.getMessage());
		return new ResponseEntity<BasicResponse>(errorResponseFacade.getBasicResponse(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
