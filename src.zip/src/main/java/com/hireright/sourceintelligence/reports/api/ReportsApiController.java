package com.hireright.sourceintelligence.reports.api;

import com.hireright.sourceintelligence.reports.dto.ReportResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;
import com.hireright.sourceintelligence.reports.service.ApprovalTATService;
import com.hireright.sourceintelligence.reports.service.ReportService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequiredArgsConstructor
@Validated
@Slf4j
@CrossOrigin
public class ReportsApiController implements ReportsApi {

    private final ReportService reportService;

    @Override
    public ResponseEntity<ReportResponseDTO> getDeletedSourceReport(@RequestBody ReportsRequestDTO reportsRequestDTO) {
        var response = reportService.deleteReport(reportsRequestDTO);
        var responseHeaders = new HttpHeaders();
        return new ResponseEntity<>(response, responseHeaders, HttpStatus.OK);
    }
}
