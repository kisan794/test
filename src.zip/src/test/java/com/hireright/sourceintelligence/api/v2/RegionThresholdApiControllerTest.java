package com.hireright.sourceintelligence.api.v2;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hireright.sourceintelligence.api.v2.dto.RegionThresholdDTO;
import com.hireright.sourceintelligence.service.RegionThresholdService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;


import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class RegionThresholdApiControllerTest {

    private MockMvc mockMvc;

    @Mock
    private RegionThresholdService regionThresholdService;

    @InjectMocks
    private RegionThresholdApiController controller;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
    }

    @Test
    void testGetRegions() throws Exception {
        RegionThresholdDTO mockResponse = new RegionThresholdDTO();
        when(regionThresholdService.getRegions()).thenReturn(mockResponse);

        mockMvc.perform(get("/si/v2/region-thresholds"))
                .andExpect(status().isOk());

        verify(regionThresholdService, times(1)).getRegions();
    }

    @Test
    void testUpdateRegions() throws Exception {
        RegionThresholdDTO requestDTO = new RegionThresholdDTO();
        RegionThresholdDTO responseDTO = new RegionThresholdDTO();

        when(regionThresholdService.updateRegionThreshold(any())).thenReturn(responseDTO);

        mockMvc.perform(put("/si/v2/region-thresholds")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDTO)))
                .andExpect(status().isOk());

        verify(regionThresholdService, times(1)).updateRegionThreshold(any());
    }
}

