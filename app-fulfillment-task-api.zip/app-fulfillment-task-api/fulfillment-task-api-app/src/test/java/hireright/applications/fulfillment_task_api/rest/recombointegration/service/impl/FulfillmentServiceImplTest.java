package hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.education.request.Request;
import hireright.applications.fulfillment_task_api.rest.recombointegration.http.client.Http2ClientService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.Direction;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.RecipientName;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.service.LoggingService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.util.CorrelationIdHolder;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for FulfillmentServiceImpl
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("FulfillmentServiceImpl Tests")
class FulfillmentServiceImplTest {

    @Mock
    private Http2ClientService http2ClientService;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private LoggingService loggingService;

    @Mock
    private HttpResponse<String> httpResponse;

    private FulfillmentServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new FulfillmentServiceImpl(http2ClientService, objectMapper, loggingService);
        ReflectionTestUtils.setField(service, "recomboServiceBaseUrl", "http://localhost:8080");
        ReflectionTestUtils.setField(service, "recomboSubmitEndpoint", "/api/v1/{sourceType}/submit");
        ReflectionTestUtils.setField(service, "apiKey", "test-api-key");

        // Initialize caches
        service.initializeCaches();
    }

    @AfterEach
    void tearDown() {
        CorrelationIdHolder.clear();
    }

    @Test
    @DisplayName("Should initialize caches on PostConstruct")
    void testInitializeCaches() {
        // Given
        FulfillmentServiceImpl newService = new FulfillmentServiceImpl(http2ClientService, objectMapper, loggingService);

        // When
        newService.initializeCaches();

        // Then
        Map<String, Request> educationCache = (Map<String, Request>) ReflectionTestUtils.getField(newService, "educationCache");
        Map<String, hireright.applications.fulfillment_task_api.model.recombointegration.employment.request.Request> employmentCache =
                (Map<String, hireright.applications.fulfillment_task_api.model.recombointegration.employment.request.Request>)
                        ReflectionTestUtils.getField(newService, "employmentCache");

        assertNotNull(educationCache);
        assertNotNull(employmentCache);
    }

    @Test
    @DisplayName("Should fulfill education request successfully")
    void testFulfillEducationRequest() throws Exception {
        // Given
        String requestId = "COMP-EDU-001";
        String jsonPayload = "{\"type\":\"education\"}";

        when(objectMapper.writeValueAsString(any())).thenReturn(jsonPayload);
        when(httpResponse.statusCode()).thenReturn(200);
        when(http2ClientService.postAsync(anyString(), anyString(), anyMap()))
                .thenReturn(CompletableFuture.completedFuture(httpResponse));

        // When
        service.fulfill(requestId);

        // Then
        verify(loggingService, timeout(1000).times(1))
                .log(eq(jsonPayload), eq(requestId), eq(RecipientName.FULFILLMENT_REQUEST), eq(Direction.OUT));
        verify(http2ClientService, timeout(1000).times(1))
                .postAsync(contains("/api/v1/education/submit"), eq(jsonPayload), anyMap());
    }

    @Test
    @DisplayName("Should fulfill employment request successfully")
    void testFulfillEmploymentRequest() throws Exception {
        // Given
        String requestId = "COMP-EMP-002";
        String jsonPayload = "{\"type\":\"employment\"}";

        when(objectMapper.writeValueAsString(any())).thenReturn(jsonPayload);
        when(httpResponse.statusCode()).thenReturn(200);
        when(http2ClientService.postAsync(anyString(), anyString(), anyMap()))
                .thenReturn(CompletableFuture.completedFuture(httpResponse));

        // When
        service.fulfill(requestId);

        // Then
        verify(loggingService, timeout(1000).times(1))
                .log(eq(jsonPayload), eq(requestId), eq(RecipientName.FULFILLMENT_REQUEST), eq(Direction.OUT));
        verify(http2ClientService, timeout(1000).times(1))
                .postAsync(contains("/api/v1/employment/submit"), eq(jsonPayload), anyMap());
    }

    @Test
    @DisplayName("Should generate correlation ID if not present")
    void testGenerateCorrelationIdIfNotPresent() throws Exception {
        // Given
        String requestId = "COMP-EDU-001";
        String jsonPayload = "{\"type\":\"education\"}";

        when(objectMapper.writeValueAsString(any())).thenReturn(jsonPayload);
        when(httpResponse.statusCode()).thenReturn(200);
        when(http2ClientService.postAsync(anyString(), anyString(), anyMap()))
                .thenReturn(CompletableFuture.completedFuture(httpResponse));

        // Ensure no correlation ID is set
        CorrelationIdHolder.clear();

        // When
        service.fulfill(requestId);

        // Then
        assertNotNull(CorrelationIdHolder.get());
    }

    @Test
    @DisplayName("Should use existing correlation ID if present")
    void testUseExistingCorrelationId() throws Exception {
        // Given
        String requestId = "COMP-EDU-001";
        String jsonPayload = "{\"type\":\"education\"}";
        String existingCorrelationId = "existing-correlation-id";

        when(objectMapper.writeValueAsString(any())).thenReturn(jsonPayload);
        when(httpResponse.statusCode()).thenReturn(200);
        when(http2ClientService.postAsync(anyString(), anyString(), anyMap()))
                .thenReturn(CompletableFuture.completedFuture(httpResponse));

        CorrelationIdHolder.set(existingCorrelationId);

        // When
        service.fulfill(requestId);

        // Then
        assertEquals(existingCorrelationId, CorrelationIdHolder.get());
    }

    @Test
    @DisplayName("Should throw exception when verification data not found")
    void testThrowExceptionWhenDataNotFound() {
        // Given
        String requestId = "INVALID-EDU-999";

        // When & Then
        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> service.fulfill(requestId)
        );

        assertTrue(exception.getMessage().contains("Verification data not found"));
    }

    @Test
    @DisplayName("Should send request with correct headers")
    void testSendRequestWithCorrectHeaders() throws Exception {
        // Given
        String requestId = "COMP-EDU-001";
        String jsonPayload = "{\"type\":\"education\"}";

        when(objectMapper.writeValueAsString(any())).thenReturn(jsonPayload);
        when(httpResponse.statusCode()).thenReturn(200);

        ArgumentCaptor<Map<String, String>> headersCaptor = ArgumentCaptor.forClass(Map.class);
        when(http2ClientService.postAsync(anyString(), anyString(), headersCaptor.capture()))
                .thenReturn(CompletableFuture.completedFuture(httpResponse));

        // When
        service.fulfill(requestId);

        // Then
        verify(http2ClientService, timeout(1000).times(1))
                .postAsync(anyString(), anyString(), anyMap());

        Map<String, String> capturedHeaders = headersCaptor.getValue();
        assertEquals("test-api-key", capturedHeaders.get("x-api-key"));
    }

    @Test
    @DisplayName("Should construct correct URL for education request")
    void testConstructCorrectUrlForEducation() throws Exception {
        // Given
        String requestId = "COMP-EDU-001";
        String jsonPayload = "{\"type\":\"education\"}";

        when(objectMapper.writeValueAsString(any())).thenReturn(jsonPayload);
        when(httpResponse.statusCode()).thenReturn(200);

        ArgumentCaptor<String> urlCaptor = ArgumentCaptor.forClass(String.class);
        when(http2ClientService.postAsync(urlCaptor.capture(), anyString(), anyMap()))
                .thenReturn(CompletableFuture.completedFuture(httpResponse));

        // When
        service.fulfill(requestId);

        // Then
        verify(http2ClientService, timeout(1000).times(1))
                .postAsync(anyString(), anyString(), anyMap());

        String capturedUrl = urlCaptor.getValue();
        assertEquals("http://localhost:8080/api/v1/education/submit", capturedUrl);
    }

    @Test
    @DisplayName("Should construct correct URL for employment request")
    void testConstructCorrectUrlForEmployment() throws Exception {
        // Given
        String requestId = "COMP-EMP-002";
        String jsonPayload = "{\"type\":\"employment\"}";

        when(objectMapper.writeValueAsString(any())).thenReturn(jsonPayload);
        when(httpResponse.statusCode()).thenReturn(200);

        ArgumentCaptor<String> urlCaptor = ArgumentCaptor.forClass(String.class);
        when(http2ClientService.postAsync(urlCaptor.capture(), anyString(), anyMap()))
                .thenReturn(CompletableFuture.completedFuture(httpResponse));

        // When
        service.fulfill(requestId);

        // Then
        verify(http2ClientService, timeout(1000).times(1))
                .postAsync(anyString(), anyString(), anyMap());

        String capturedUrl = urlCaptor.getValue();
        assertEquals("http://localhost:8080/api/v1/employment/submit", capturedUrl);
    }

    @Test
    @DisplayName("Should handle education request with lowercase edu")
    void testHandleEducationRequestLowercase() throws Exception {
        // Given
        String requestId = "SINGLE-edu-005";
        String jsonPayload = "{\"type\":\"education\"}";

        when(objectMapper.writeValueAsString(any())).thenReturn(jsonPayload);
        when(httpResponse.statusCode()).thenReturn(200);
        when(http2ClientService.postAsync(anyString(), anyString(), anyMap()))
                .thenReturn(CompletableFuture.completedFuture(httpResponse));

        // When
        service.fulfill(requestId);

        // Then
        verify(http2ClientService, timeout(1000).times(1))
                .postAsync(contains("/api/v1/education/submit"), anyString(), anyMap());
    }

    @Test
    @DisplayName("Should handle employment request with lowercase emp")
    void testHandleEmploymentRequestLowercase() throws Exception {
        // Given
        String requestId = "SINGLE-emp-004";
        String jsonPayload = "{\"type\":\"employment\"}";

        when(objectMapper.writeValueAsString(any())).thenReturn(jsonPayload);
        when(httpResponse.statusCode()).thenReturn(200);
        when(http2ClientService.postAsync(anyString(), anyString(), anyMap()))
                .thenReturn(CompletableFuture.completedFuture(httpResponse));

        // When
        service.fulfill(requestId);

        // Then
        verify(http2ClientService, timeout(1000).times(1))
                .postAsync(contains("/api/v1/employment/submit"), anyString(), anyMap());
    }

    @Test
    @DisplayName("Should log request before sending")
    void testLogRequestBeforeSending() throws Exception {
        // Given
        String requestId = "COMP-EDU-001";
        String jsonPayload = "{\"type\":\"education\"}";

        when(objectMapper.writeValueAsString(any())).thenReturn(jsonPayload);
        when(httpResponse.statusCode()).thenReturn(200);
        when(http2ClientService.postAsync(anyString(), anyString(), anyMap()))
                .thenReturn(CompletableFuture.completedFuture(httpResponse));

        // When
        service.fulfill(requestId);

        // Then
        verify(loggingService, timeout(1000).times(1))
                .log(jsonPayload, requestId, RecipientName.FULFILLMENT_REQUEST, Direction.OUT);
    }

    @Test
    @DisplayName("Should handle successful HTTP response")
    void testHandleSuccessfulHttpResponse() throws Exception {
        // Given
        String requestId = "COMP-EDU-001";
        String jsonPayload = "{\"type\":\"education\"}";

        when(objectMapper.writeValueAsString(any())).thenReturn(jsonPayload);
        when(httpResponse.statusCode()).thenReturn(201);
        when(http2ClientService.postAsync(anyString(), anyString(), anyMap()))
                .thenReturn(CompletableFuture.completedFuture(httpResponse));

        // When
        service.fulfill(requestId);

        // Then - No exception should be thrown
        verify(http2ClientService, timeout(1000).times(1))
                .postAsync(anyString(), anyString(), anyMap());
    }
}

