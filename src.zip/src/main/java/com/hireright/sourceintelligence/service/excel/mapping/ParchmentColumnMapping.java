package com.hireright.sourceintelligence.service.excel.mapping;

import com.hireright.sourceintelligence.service.excel.ExcelColumnMapping;

public class ParchmentColumnMapping {

    // Field name constants
    public static final String INSTITUTION_NAME = "institutionName";
    public static final String COUNTRY = "country";
    public static final String CITY = "city";
    public static final String STATE_COUNTY_REGION = "stateCountyRegion";
    public static final String SERVICE_PROVIDER = "serviceProvider";
    public static final String SURCHARGE_AMOUNT = "surchargeAmount";
    public static final String PAYMENT_METHOD = "paymentMethod";
    public static final String CODE = "code";
    public static final String TURNAROUND_TIME = "turnaroundTime";
    public static final String FOLLOW_UP_ALLOWED = "followUpAllowed";
    // Excel header name constants (as they appear in the Excel file)
    private static final String HEADER_INSTITUTION_NAME = "Institution Name";
    private static final String HEADER_COUNTRY = "Country";
    private static final String HEADER_CITY = "City";
    private static final String HEADER_STATE_COUNTY_REGION = "State/County/Region";
    private static final String HEADER_SERVICE_PROVIDER = "Service Provider";
    private static final String HEADER_SURCHARGE_AMOUNT = "Surcharge Amount";
    private static final String HEADER_PAYMENT_METHOD = "Payment Method";
    private static final String HEADER_CODE = "Code";
    private static final String HEADER_TURNAROUND_TIME = "Turnaround Time";
    private static final String HEADER_FOLLOW_UP_ALLOWED = "Follow Up Allowed";
    private ParchmentColumnMapping() {

    }

    public static ExcelColumnMapping create() {
        return ExcelColumnMapping.builder()
                .addHeaderMapping(HEADER_INSTITUTION_NAME, INSTITUTION_NAME)
                .addHeaderMapping(HEADER_COUNTRY, COUNTRY)
                .addHeaderMapping(HEADER_CITY, CITY)
                .addHeaderMapping(HEADER_STATE_COUNTY_REGION, STATE_COUNTY_REGION)
                .addHeaderMapping(HEADER_SERVICE_PROVIDER, SERVICE_PROVIDER)
                .addHeaderMapping(HEADER_SURCHARGE_AMOUNT, SURCHARGE_AMOUNT)
                .addHeaderMapping(HEADER_PAYMENT_METHOD, PAYMENT_METHOD)
                .addHeaderMapping(HEADER_CODE, CODE)
                .addHeaderMapping(HEADER_TURNAROUND_TIME, TURNAROUND_TIME)
                .addHeaderMapping(HEADER_FOLLOW_UP_ALLOWED, FOLLOW_UP_ALLOWED)
                .headerRowIndex(0)
                .dataStartRowIndex(1)
                .sheetIndex(0)
                .build();
    }
}