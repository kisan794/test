package hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.PropertiesResponse;
import hireright.applications.fulfillment_task_api.model.recombointegration.employment.response.EmploymentResultData;
import hireright.applications.fulfillment_task_api.model.recombointegration.employment.response.EmploymentResultRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.employment.response.PositionHistory;
import hireright.applications.fulfillment_task_api.model.recombointegration.employment.response.ResponseResultData;
import hireright.applications.fulfillment_task_api.rest.recombointegration.exception.ValidationException;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.Direction;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.RecipientName;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.service.LoggingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for EmploymentResultServiceImpl
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("EmploymentResultServiceImpl Tests")
class EmploymentResultServiceImplTest {

    @Mock
    private LoggingService loggingService;

    @Mock
    private ObjectMapper objectMapper;

    private EmploymentResultServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new EmploymentResultServiceImpl(loggingService, objectMapper);
    }

    @Test
    @DisplayName("Should process employment submission successfully")
    void testProcessEmploymentSubmissionSuccess() throws JsonProcessingException {
        // Given
        String requestId = "COMP-EMP-002";
        EmploymentResultRequest request = createValidEmploymentResultRequest(requestId);
        String jsonPayload = "{\"id\":\"COMP-EMP-002\"}";

        when(objectMapper.writeValueAsString(request)).thenReturn(jsonPayload);

        // When
        service.processEmploymentSubmission(requestId, request);

        // Then
        verify(objectMapper, times(1)).writeValueAsString(request);
        verify(loggingService, times(1))
                .log(jsonPayload, requestId, RecipientName.FULFILLMENT_RESPONSE, Direction.IN);
    }

    @Test
    @DisplayName("Should throw ValidationException when request ID is null")
    void testProcessEmploymentSubmissionNullRequestId() {
        // Given
        EmploymentResultRequest request = createValidEmploymentResultRequest("COMP-EMP-002");

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEmploymentSubmission(null, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when request ID is empty")
    void testProcessEmploymentSubmissionEmptyRequestId() {
        // Given
        EmploymentResultRequest request = createValidEmploymentResultRequest("COMP-EMP-002");

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEmploymentSubmission("", request));
    }

    @Test
    @DisplayName("Should throw ValidationException when request ID in path does not match body")
    void testProcessEmploymentSubmissionMismatchedRequestId() {
        // Given
        String pathRequestId = "COMP-EMP-001";
        EmploymentResultRequest request = createValidEmploymentResultRequest("COMP-EMP-002");

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEmploymentSubmission(pathRequestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when specversion is missing")
    void testProcessEmploymentSubmissionMissingSpecversion() {
        // Given
        String requestId = "COMP-EMP-002";
        EmploymentResultRequest request = createValidEmploymentResultRequest(requestId);
        request.setSpecversion(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEmploymentSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when source is missing")
    void testProcessEmploymentSubmissionMissingSource() {
        // Given
        String requestId = "COMP-EMP-002";
        EmploymentResultRequest request = createValidEmploymentResultRequest(requestId);
        request.setSource(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEmploymentSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when type is missing")
    void testProcessEmploymentSubmissionMissingType() {
        // Given
        String requestId = "COMP-EMP-002";
        EmploymentResultRequest request = createValidEmploymentResultRequest(requestId);
        request.setType(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEmploymentSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when data is null")
    void testProcessEmploymentSubmissionNullData() {
        // Given
        String requestId = "COMP-EMP-002";
        EmploymentResultRequest request = createValidEmploymentResultRequest(requestId);
        request.setData(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEmploymentSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when decision is missing")
    void testProcessEmploymentSubmissionMissingDecision() {
        // Given
        String requestId = "COMP-EMP-002";
        EmploymentResultRequest request = createValidEmploymentResultRequest(requestId);
        request.getData().setDecision(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEmploymentSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when reviewScore is missing")
    void testProcessEmploymentSubmissionMissingReviewScore() {
        // Given
        String requestId = "COMP-EMP-002";
        EmploymentResultRequest request = createValidEmploymentResultRequest(requestId);
        request.getData().setReviewScore(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEmploymentSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when decisionDescription is missing")
    void testProcessEmploymentSubmissionMissingDecisionDescription() {
        // Given
        String requestId = "COMP-EMP-002";
        EmploymentResultRequest request = createValidEmploymentResultRequest(requestId);
        request.getData().setDecisionDescription(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEmploymentSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when resultData is missing")
    void testProcessEmploymentSubmissionMissingResultData() {
        // Given
        String requestId = "COMP-EMP-002";
        EmploymentResultRequest request = createValidEmploymentResultRequest(requestId);
        request.getData().setResultData(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEmploymentSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when audit is missing")
    void testProcessEmploymentSubmissionMissingAudit() {
        // Given
        String requestId = "COMP-EMP-002";
        EmploymentResultRequest request = createValidEmploymentResultRequest(requestId);
        request.getData().getProperties().setAudit(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEmploymentSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when rfmFlag is missing")
    void testProcessEmploymentSubmissionMissingRfmFlag() {
        // Given
        String requestId = "COMP-EMP-002";
        EmploymentResultRequest request = createValidEmploymentResultRequest(requestId);
        request.getData().getProperties().setRfmFlag(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEmploymentSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw RuntimeException when JSON serialization fails")
    void testProcessEmploymentSubmissionJsonProcessingException() throws JsonProcessingException {
        // Given
        String requestId = "COMP-EMP-002";
        EmploymentResultRequest request = createValidEmploymentResultRequest(requestId);

        when(objectMapper.writeValueAsString(request)).thenThrow(new JsonProcessingException("Serialization error") {});

        // When & Then
        assertThrows(RuntimeException.class, () -> service.processEmploymentSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should log request with correct parameters")
    void testLoggingServiceCalledWithCorrectParameters() throws JsonProcessingException {
        // Given
        String requestId = "COMP-EMP-002";
        EmploymentResultRequest request = createValidEmploymentResultRequest(requestId);
        String jsonPayload = "{\"id\":\"COMP-EMP-002\"}";

        when(objectMapper.writeValueAsString(request)).thenReturn(jsonPayload);

        // When
        service.processEmploymentSubmission(requestId, request);

        // Then
        verify(loggingService, times(1))
                .log(eq(jsonPayload), eq(requestId), eq(RecipientName.FULFILLMENT_RESPONSE), eq(Direction.IN));
    }

    @Test
    @DisplayName("Should process result data with employer name and position")
    void testProcessResultDataWithEmployerAndPosition() throws JsonProcessingException {
        // Given
        String requestId = "COMP-EMP-002";
        EmploymentResultRequest request = createValidEmploymentResultRequest(requestId);
        request.getData().getResultData().setEmployerOrgName("Acme Corporation");
        request.getData().getResultData().getPositionHistory().setTitle("Software Engineer");

        String jsonPayload = "{\"id\":\"COMP-EMP-002\"}";
        when(objectMapper.writeValueAsString(request)).thenReturn(jsonPayload);

        // When
        service.processEmploymentSubmission(requestId, request);

        // Then
        verify(loggingService, times(1))
                .log(jsonPayload, requestId, RecipientName.FULFILLMENT_RESPONSE, Direction.IN);
    }

    @Test
    @DisplayName("Should handle result data with null position history")
    void testProcessResultDataWithNullPositionHistory() throws JsonProcessingException {
        // Given
        String requestId = "COMP-EMP-002";
        EmploymentResultRequest request = createValidEmploymentResultRequest(requestId);
        request.getData().getResultData().setPositionHistory(null);

        String jsonPayload = "{\"id\":\"COMP-EMP-002\"}";
        when(objectMapper.writeValueAsString(request)).thenReturn(jsonPayload);

        // When
        service.processEmploymentSubmission(requestId, request);

        // Then
        verify(loggingService, times(1))
                .log(jsonPayload, requestId, RecipientName.FULFILLMENT_RESPONSE, Direction.IN);
    }

    @Test
    @DisplayName("Should process employment submission with sourceReference field")
    void testProcessEmploymentSubmissionWithSourceReference() throws JsonProcessingException {
        // Given
        String requestId = "COMP-EMP-002";
        EmploymentResultRequest request = createValidEmploymentResultRequest(requestId);
        request.getData().setSourceReference("SOURCE-REF-12345");

        String jsonPayload = "{\"id\":\"COMP-EMP-002\"}";
        when(objectMapper.writeValueAsString(request)).thenReturn(jsonPayload);

        // When
        service.processEmploymentSubmission(requestId, request);

        // Then
        verify(loggingService, times(1))
                .log(jsonPayload, requestId, RecipientName.FULFILLMENT_RESPONSE, Direction.IN);
    }

    private EmploymentResultRequest createValidEmploymentResultRequest(String requestId) {
        PositionHistory positionHistory = PositionHistory.builder()
                .title("Software Engineer")
                .startDate("2020-01-01")
                .endDate("2024-05-31")
                .mostRecentHireDate("2020-01-01")
                .employeeStatusCode("VERIFIED")
                .employeeStatus("Verified")
                .spokeWith("HR Manager")
                .reasonForLeaving("Career advancement")
                .build();

        EmploymentResultData resultData = EmploymentResultData.builder()
                .city("San Francisco")
                .region("CA")
                .country("USA")
                .employerOrgName("Acme Corporation")
                .positionHistory(positionHistory)
                .build();

        PropertiesResponse properties = PropertiesResponse.builder()
                .audit(true)
                .rfmFlag(false)
                .build();

        ResponseResultData data = ResponseResultData.builder()
                .decision("APPROVED")
                .reviewScore(92.0)
                .decisionDescription("Employment verified successfully")
                .sourceReference("SOURCE-REF-12345")
                .properties(properties)
                .resultData(resultData)
                .build();

        return EmploymentResultRequest.builder()
                .specversion("1.0")
                .id(requestId)
                .source("hrg:hre:recombo")
                .type("EmploymentVerification.Result")
                .datacontenttype("application/json")
                .dataschema("https://example.com/schema")
                .data(data)
                .build();
    }
}

