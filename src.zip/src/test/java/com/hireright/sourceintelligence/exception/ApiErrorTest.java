package com.hireright.sourceintelligence.exception;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;

import jakarta.validation.ConstraintViolation;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ApiErrorTest {

    @Test
    void constructor_withStatus_setsFields() {
        ApiError err = new ApiError(HttpStatus.BAD_REQUEST);
        assertEquals(HttpStatus.BAD_REQUEST, err.getStatus());
        assertNotNull(err.getTimestamp());
        err.setTraceId("trace-1");
        assertEquals("trace-1", err.getTraceId());
    }

    @Test
    void constructor_withStatusAndThrowable_setsMessage() {
        Throwable ex = new IllegalArgumentException("boom!");
        ApiError err = new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, ex);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, err.getStatus());
        assertEquals("boom!", err.getMessage());
        assertNotNull(err.getTimestamp());
    }

    @Test
    void constructor_withStatusAndMessage_setsMessage() {
        ApiError err = new ApiError(HttpStatus.NOT_FOUND, "nope");
        assertEquals(HttpStatus.NOT_FOUND, err.getStatus());
        assertEquals("nope", err.getMessage());
    }

    @Test
    void constructor_withErrorCode_populatesFromNonNulls() {
        ErrorCode code = mock(ErrorCode.class);
        when(code.getCode()).thenReturn("E123");
        when(code.getDescription()).thenReturn("Something bad");
        when(code.getHttpStatus()).thenReturn(HttpStatus.CONFLICT);

        ApiError err = new ApiError(code);
        assertEquals("E123", err.getErrorCode());
        assertEquals("Something bad", err.getMessage());
        assertEquals(HttpStatus.CONFLICT, err.getStatus());
        assertNotNull(err.getTimestamp());
    }

    @Test
    void constructor_withErrorCode_handlesNullFields_viaSetIfNotNull() {
        ErrorCode code = mock(ErrorCode.class);
        when(code.getCode()).thenReturn(null);
        when(code.getDescription()).thenReturn("desc only");
        when(code.getHttpStatus()).thenReturn(null);

        ApiError err = new ApiError(code);
        assertNull(err.getErrorCode());
        assertEquals("desc only", err.getMessage());
        assertNull(err.getStatus());
    }

    @Test
    void constructor_withErrorCodeAndThrowable_addsErrorDetail() {
        ErrorCode code = mock(ErrorCode.class);
        when(code.getCode()).thenReturn("E777");
        when(code.getDescription()).thenReturn("desc");
        when(code.getHttpStatus()).thenReturn(HttpStatus.BAD_GATEWAY);

        Throwable ex = new RuntimeException("runtime oops");
        ApiError err = new ApiError(code, ex);

        assertEquals("E777", err.getErrorCode());
        assertEquals(HttpStatus.BAD_GATEWAY, err.getStatus());
        assertNotNull(err.getErrors());
        assertEquals(1, err.getErrors().size());
        ApiError.ApiErrorDetail d = err.getErrors().get(0);
        assertEquals(RuntimeException.class.getCanonicalName(), d.getName());
        assertEquals("runtime oops", d.getMessage());
    }

    @Test
    void constructor_withErrorCodeAndMessage_addsErrorDetail() {
        ErrorCode code = mock(ErrorCode.class);
        when(code.getCode()).thenReturn("E900");
        when(code.getDescription()).thenReturn("base");
        when(code.getHttpStatus()).thenReturn(HttpStatus.EXPECTATION_FAILED);

        ApiError err = new ApiError(code, "detail msg");
        assertEquals("E900", err.getErrorCode());
        assertEquals("base", err.getMessage());
        assertEquals(HttpStatus.EXPECTATION_FAILED, err.getStatus());
        assertNotNull(err.getErrors());
        assertEquals(1, err.getErrors().size());
        assertNull(err.getErrors().get(0).getName());
        assertEquals("detail msg", err.getErrors().get(0).getMessage());
    }

    @Test
    void addError_initializesListAndAdds() {
        ApiError err = new ApiError(HttpStatus.OK);
        assertNull(err.getErrors());
        err.addError(new ApiError.ApiErrorDetail("n", "m"));
        assertNotNull(err.getErrors());
        assertEquals(1, err.getErrors().size());
        assertEquals("n", err.getErrors().get(0).getName());
        assertEquals("m", err.getErrors().get(0).getMessage());
    }

    @Test
    void addErrors_handlesEmptyAndNonEmpty() {
        ApiError err = new ApiError(HttpStatus.OK);
        err.addErrors(new ArrayList<>());
        assertNotNull(err.getErrors());
        assertTrue(err.getErrors().isEmpty());
        List<String> msgs = List.of("a", "b");
        err.addErrors(msgs);
        assertEquals(2, err.getErrors().size());
        assertNull(err.getErrors().get(0).getName());
        assertEquals("a", err.getErrors().get(0).getMessage());
    }

    @Test
    void addFieldErrors_handlesEmptyAndNonEmpty() {
        ApiError err = new ApiError(HttpStatus.OK);
        err.addFieldErrors(new ArrayList<>());
        assertNotNull(err.getValidationErrors());
        assertTrue(err.getValidationErrors().isEmpty());
        FieldError f1 = new FieldError("obj", "field1", "bad1");
        FieldError f2 = new FieldError("obj", "field2", "bad2");
        err.addFieldErrors(List.of(f1, f2));

        assertEquals(2, err.getValidationErrors().size());
    }

    private @interface DummyConstraint {}

    @Test
    @SuppressWarnings("unchecked")
    void addValidationErrors_handlesEmptyAndNonEmpty() {
        ApiError err = new ApiError(HttpStatus.OK);
        err.addValidationErrors(new java.util.HashSet<>());
        assertNotNull(err.getValidationErrors());
        assertTrue(err.getValidationErrors().isEmpty());
        ConstraintViolation<?> cv = mock(ConstraintViolation.class);
        when(cv.getRootBeanClass()).thenReturn((Class) ApiError.class);
        jakarta.validation.Path path = mock(jakarta.validation.Path.class);
        when(path.toString()).thenReturn("field1");
        when(cv.getPropertyPath()).thenReturn(path);
        when(cv.getMessage()).thenReturn("bad");
        when(cv.getInvalidValue()).thenReturn("oops");
        when(cv.getLeafBean()).thenReturn(new Object());
        jakarta.validation.metadata.ConstraintDescriptor<DummyConstraint> desc =
                mock(jakarta.validation.metadata.ConstraintDescriptor.class);
        when(cv.getConstraintDescriptor())
                .thenReturn((jakarta.validation.metadata.ConstraintDescriptor) desc);

        java.util.Set<ConstraintViolation<?>> set = new java.util.HashSet<>();
        set.add(cv);

        err.addValidationErrors(set);
        assertEquals(1, err.getValidationErrors().size());
    }




    @Test
    void addGlobalErrors_handlesEmptyAndNonEmpty() {
        ApiError err = new ApiError(HttpStatus.OK);
        err.addGlobalErrors(new ArrayList<>());
        assertNull(err.getErrors());
        ObjectError o1 = new ObjectError("obj1", "msg1");
        ObjectError o2 = new ObjectError("obj2", "msg2");
        err.addGlobalErrors(List.of(o1, o2));
        assertNotNull(err.getErrors());
        assertEquals(2, err.getErrors().size());
        assertEquals("obj1", err.getErrors().get(0).getName());
        assertEquals("msg1", err.getErrors().get(0).getMessage());
    }

    @Test
    void lombok_generated_methods_full_coverage() {
        OffsetDateTime ts = OffsetDateTime.now();

        ApiError.ApiErrorDetail detail1 = new ApiError.ApiErrorDetail("n1", "m1");
        ApiError.ApiErrorDetail detail2 = new ApiError.ApiErrorDetail("n1", "m1");
        ApiError.ApiErrorDetail detailDifferent = new ApiError.ApiErrorDetail("n2", "m1");

        ApiValidationError ve = mock(ApiValidationError.class);

        List<ApiError.ApiErrorDetail> list1 = new ArrayList<>();
        list1.add(detail1);
        List<ApiError.ApiErrorDetail> list2 = new ArrayList<>();
        list2.add(detail2);

        List<ApiValidationError> vList = new ArrayList<>();
        vList.add(ve);
        ApiError apiError1 = new ApiError("C1", HttpStatus.OK, ts, "msg", "tid", list1, vList);
        ApiError apiError2 = new ApiError("C1", HttpStatus.OK, ts, "msg", "tid", list2, vList);
        assertEquals(apiError1, apiError2);
        assertNotEquals(null, apiError1);
        assertNotEquals(new ApiError(HttpStatus.BAD_REQUEST), apiError1);

        assertEquals(apiError1.hashCode(), apiError2.hashCode());
        assertTrue(apiError1.canEqual(apiError2));
        assertFalse(apiError1.canEqual(new Object()));

        assertNotNull(apiError1.toString());


        assertEquals(detail1, detail2);
        assertNotEquals(detailDifferent, detail1);
        assertNotEquals(null, detail1);
        assertNotEquals(new Object(), detail1);
        assertEquals(detail1.hashCode(), detail2.hashCode());
        assertNotNull(detail1.toString());
    }




    @Test
    void lombok_getters_setters_and_inner_detail_accessors() {
        ApiError err = new ApiError(HttpStatus.ACCEPTED);
        err.setErrorCode("C123");
        err.setStatus(HttpStatus.IM_USED);
        OffsetDateTime ts = OffsetDateTime.now().minusDays(1);
        err.setTimestamp(ts);
        err.setMessage("hello");
        err.setTraceId("tid-42");

        List<ApiError.ApiErrorDetail> errs = new ArrayList<>();
        errs.add(new ApiError.ApiErrorDetail("n1", "m1"));
        err.setErrors(errs);

        List<ApiValidationError> vErrs = new ArrayList<>();
        vErrs.add(Mockito.mock(ApiValidationError.class));
        err.setValidationErrors(vErrs);

        assertEquals("C123", err.getErrorCode());
        assertEquals(HttpStatus.IM_USED, err.getStatus());
        assertEquals(ts, err.getTimestamp());
        assertEquals("hello", err.getMessage());
        assertEquals("tid-42", err.getTraceId());
        assertEquals(1, err.getErrors().size());
        assertEquals("n1", err.getErrors().get(0).getName());
        assertEquals("m1", err.getErrors().get(0).getMessage());
        assertEquals(1, err.getValidationErrors().size());
    }
}