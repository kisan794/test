package hireright.applications.fulfillment_task_api.model.recombointegration.education.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class EducationResultRequest {
    private String specversion;

    private String id;

    private String source;

    private String type;

    private String datacontenttype;

    private String dataschema;

    private ResponseResultData data;
}
