package com.hireright.sourceintelligence.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Document(collection = "country_region")
public class CountryRegion {

    @Id
    @Field("_id")
    private ObjectId id;

    @Field("ID")
    private Integer regionId;

    @Field("COUNTRY_ID")
    private Integer countryId;

    @Field("OLD_REGION_ID")
    private Integer oldRegionId;

    @Field("REGION_NAME")
    private String regionName;

    @Field("PARENT_ID")
    private Integer parentId;

    @Field("REGION_LEVEL")
    private Integer regionLevel;

    @Field("ISO_3166_2")
    private String iso31662;

    @Field("OBSOLETE")
    private String obsolete;

    @Field("HR_CODE")
    private String hrCode;

    @Field("table")
    private String table;

    @Field("scn")
    private String scn;

    @Field("op_type")
    private String opType;

    @Field("op_ts")
    private String opTs;

    @Field("current_ts")
    private String currentTs;

    @Field("row_id")
    private String rowId;

    @Field("username")
    private String username;

    @Field("location")
    private String location;

    @Field("areaCodes")
    private List<String> areaCodes;
}

