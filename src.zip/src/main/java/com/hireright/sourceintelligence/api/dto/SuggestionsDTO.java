package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value = JsonInclude.Include.NON_EMPTY, content = JsonInclude.Include.NON_NULL)
@Data
public class SuggestionsDTO {
    private String label;
    private String value;
    private int score;

    //EDUCATION
    private String orgUnitEduHONDomID;
    private String orgUnitEduHONVal;
    private String orgUnitEduNameDomID;
    private String orgUnitEduNameVal;
    private String orgUnitEduCountryIDDomID;
    private String orgUnitEduCountryIDVal;
    private String orgUnitEduRegionIDDomID;
    private String orgUnitEduRegionIDVal;
    private String orgUnitEduRegionDomID;
    private String orgUnitEduRegionVal;
    private String orgUnitEduMunicipalityDomID;
    private String orgUnitEduMunicipalityVal;
    private String orgUnitEduPhoneDomID;
    private String orgUnitEduPhoneCountryCode;
    private String orgUnitEduPhoneAreaCode;
    private String orgUnitEduPhoneNumber;
    private String orgUnitEduPhoneExt;
    private String providedSchoolName;

    //EMPLOYMENT
    private String providedEmployerName;
    private String orgUnitEmpHONDomID;
    private String orgUnitEmpHONVal;
    private String orgUnitEmpNameDomID;
    private String orgUnitEmpNameVal;
    private String orgUnitEmpCountryIDDomID;
    private String orgUnitEmpCountryIDVal;
    private String orgUnitEmpRegionIDDomID;
    private String orgUnitEmpRegionIDVal;
    private String orgUnitEmpRegionDomID;
    private String orgUnitEmpRegionVal;
    private String orgUnitEmpMunicipalityDomID;
    private String orgUnitEmpMunicipalityVal;
    private String orgUnitEmpPhoneDomID;
    private String orgUnitEmpPhoneCountryCode;
    private String orgUnitEmpPhoneAreaCode;
    private String orgUnitEmpPhoneNumber;
    private String orgUnitEmpPhoneExt;

}
