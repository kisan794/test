package com.hireright.sourceintelligence.reports.service.impl;

import com.hireright.sourceintelligence.reports.dto.MetaDTO;

import java.util.ArrayList;
import java.util.List;

import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.AUTO_MATCH;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.MetaData.*;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.MetaData.ACTION;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.MetaData.CHANGE_TYPE;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.MetaData.CREATED_BY;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.ReportTypes.*;

public class ReportUtils {

    private ReportUtils() {
        throw new IllegalStateException("Utility class");
    }

    public static List<MetaDTO> getMetaDataByReport(String reportType){
        List<MetaDTO> metaDTOList = new ArrayList<>();
        String[] metaData = metaDataByReportType(reportType);
        for (String s : metaData) {
            String key = convertToReadableFormat(s);
            String normalized = normalizeField(reportType, s);
            metaDTOList.add(new MetaDTO(key, normalized));
        }
        return metaDTOList;
    }

    private static String normalizeField(String reportType, String field) {
        String normalized = field;
        if (LAST_USED.equals(normalized)) {
            normalized = USED_DATE;
        }

        if (DELETE_SOURCE_REPORT.equals(reportType)) {
            return remapForDeleteReport(normalized);
        }
        if (APPROVAL_TAT.equals(reportType)) {
            return remapForApprovalTat(normalized);
        }
        return normalized;
    }

    private static String remapForDeleteReport(String field) {
        if (SOURCE_NAME.equals(field)) {
            return ORG_NAME;
        }
        if (DELETED_BY.equals(field)) {
            return APPROVED_BY;
        }
        if (DELETED_DATE.equals(field)) {
            return USED_DATE;
        }
        return field;
    }

    private static String remapForApprovalTat(String field) {
        if (REVIEWER_NAME.equals(field)) {
            return APPROVED_BY;
        }
        if (ORIGINATOR_NAME.equals(field)) {
            return CREATED_BY;
        }
        if (CHANGE_TYPE.equals(field)) {
            return ACTION;
        }
        return field;
    }

    private static String[] metaDataByReportType(String reportType){
        return switch (reportType) {
            case CONTACT_UTILIZATION -> CONTACT_UTILIZATION_META_DATA;
            case AUTO_MATCH, ReportConstants.ReportTypes.AUTO_MATCH -> AUTO_MATCH_META_DATA;
            case APPROVAL_TAT -> APPROVAL_TAT_META_DATA;
            case SOURCE_INFORMATION -> SOURCE_INFORMATION_META_DATA;
            case DELETE_SOURCE_REPORT -> DELETE_META_DATA;
            case SOURCE_INFORMATION_REVIEWER -> SOURCE_INFORMATION_REVIEWER_META_DATA;
            case SOURCE_INFORMATION_OPERATOR_REVIEWER -> SOURCE_INFORMATION_OPERATOR_REVIEWER_META_DATA;
            default -> DEFAULT_META_DATA;
        };
    }
    private static String convertToReadableFormat(String input) {
        return input.replace("_", " ");
    }

}
