package com.hireright.sourceintelligence.service.excel.strategy;

import com.hireright.sourceintelligence.api.dto.ParchmentRecord;
import com.hireright.sourceintelligence.service.excel.ExcelColumnMapping;
import com.hireright.sourceintelligence.service.excel.GenericExcelParser;
import com.hireright.sourceintelligence.service.excel.mapper.ParchmentRowMapper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ParchmentExcelParserStrategyTest {

    @Mock
    private GenericExcelParser genericExcelParser;

    @Mock
    private ParchmentRowMapper parchmentRowMapper;

    @InjectMocks
    private ParchmentExcelParserStrategy strategy;

    private MultipartFile testFile;
    private List<ParchmentRecord> sampleRecords;

    @BeforeEach
    void setUp() {
        testFile = new MockMultipartFile(
                "file",
                "test.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "test content".getBytes()
        );

        sampleRecords = Arrays.asList(
                ParchmentRecord.builder()
                        .institutionName("Harvard University")
                        .country("USA")
                        .city("Cambridge")
                        .stateCountyRegion("MA")
                        .build(),
                ParchmentRecord.builder()
                        .institutionName("MIT")
                        .country("USA")
                        .city("Cambridge")
                        .stateCountyRegion("MA")
                        .build()
        );
    }

    @Test
    void getParserType_ShouldReturnParchment() {
        String parserType = strategy.getParserType();

        assertEquals("parchment", parserType);
    }

    @Test
    void getColumnMapping_ShouldReturnNonNullMapping() {
        ExcelColumnMapping mapping = strategy.getColumnMapping();

        assertNotNull(mapping);
    }

    @Test
    void getColumnMapping_ShouldReturnConsistentMapping() {
        ExcelColumnMapping mapping1 = strategy.getColumnMapping();
        ExcelColumnMapping mapping2 = strategy.getColumnMapping();

        assertNotNull(mapping1);
        assertNotNull(mapping2);
    }

    @Test
    void getRowMapper_ShouldReturnParchmentRowMapper() {
        var mapper = strategy.getRowMapper();

        assertNotNull(mapper);
        assertEquals(parchmentRowMapper, mapper);
    }

    @Test
    void parse_ShouldCallGenericExcelParser() throws IOException {
        when(genericExcelParser.parseExcelFile(any(MultipartFile.class), 
                any(ExcelColumnMapping.class), any())).thenReturn(sampleRecords);

        List<ParchmentRecord> result = strategy.parse(testFile);

        verify(genericExcelParser).parseExcelFile(eq(testFile), 
                any(ExcelColumnMapping.class), eq(parchmentRowMapper));
        assertEquals(2, result.size());
    }

    @Test
    void parse_WithValidFile_ShouldReturnRecords() throws IOException {
        when(genericExcelParser.parseExcelFile(any(MultipartFile.class), 
                any(ExcelColumnMapping.class), any())).thenReturn(sampleRecords);

        List<ParchmentRecord> result = strategy.parse(testFile);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Harvard University", result.get(0).getInstitutionName());
        assertEquals("MIT", result.get(1).getInstitutionName());
    }

    @Test
    void parse_WithEmptyFile_ShouldReturnEmptyList() throws IOException {
        when(genericExcelParser.parseExcelFile(any(MultipartFile.class), 
                any(ExcelColumnMapping.class), any())).thenReturn(List.of());

        List<ParchmentRecord> result = strategy.parse(testFile);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void parse_WhenParserThrowsIOException_ShouldPropagateException() throws IOException {
        when(genericExcelParser.parseExcelFile(any(MultipartFile.class), 
                any(ExcelColumnMapping.class), any()))
                .thenThrow(new IOException("File read error"));

        assertThrows(IOException.class, () -> strategy.parse(testFile));
    }

    @Test
    void parse_ShouldUseCorrectColumnMapping() throws IOException {
        when(genericExcelParser.parseExcelFile(any(MultipartFile.class), 
                any(ExcelColumnMapping.class), any())).thenReturn(sampleRecords);

        strategy.parse(testFile);

        verify(genericExcelParser).parseExcelFile(
                eq(testFile),
                any(ExcelColumnMapping.class),
                eq(parchmentRowMapper)
        );
    }

    @Test
    void getColumnMapping_ShouldHaveCorrectHeaderRowIndex() {
        ExcelColumnMapping mapping = strategy.getColumnMapping();

        assertEquals(0, mapping.getHeaderRowIndex());
    }

    @Test
    void getColumnMapping_ShouldHaveCorrectDataStartRowIndex() {
        ExcelColumnMapping mapping = strategy.getColumnMapping();

        assertEquals(1, mapping.getDataStartRowIndex());
    }

    @Test
    void getColumnMapping_ShouldHaveCorrectSheetIndex() {
        ExcelColumnMapping mapping = strategy.getColumnMapping();

        assertEquals(0, mapping.getSheetIndex());
    }

    @Test
    void parse_IntegrationTest_WithRealFile() throws IOException {
        GenericExcelParser realParser = new GenericExcelParser();
        ParchmentRowMapper realMapper = new ParchmentRowMapper();
        ParchmentExcelParserStrategy realStrategy = new ParchmentExcelParserStrategy(realParser, realMapper);

        MultipartFile file = createRealParchmentExcelFile();

        List<ParchmentRecord> result = realStrategy.parse(file);

        assertNotNull(result);
        assertEquals(2, result.size());
        
        ParchmentRecord firstRecord = result.get(0);
        assertEquals("Harvard University", firstRecord.getInstitutionName());
        assertEquals("USA", firstRecord.getCountry());
        assertEquals("Cambridge", firstRecord.getCity());
        assertEquals("MA", firstRecord.getStateCountyRegion());
        assertEquals("Parchment Exchange", firstRecord.getServiceProvider());
        
        ParchmentRecord secondRecord = result.get(1);
        assertEquals("MIT", secondRecord.getInstitutionName());
    }

    @Test
    void parse_MultipleInvocations_ShouldReturnConsistentResults() throws IOException {
        when(genericExcelParser.parseExcelFile(any(MultipartFile.class), 
                any(ExcelColumnMapping.class), any())).thenReturn(sampleRecords);

        List<ParchmentRecord> result1 = strategy.parse(testFile);
        List<ParchmentRecord> result2 = strategy.parse(testFile);

        assertEquals(result1.size(), result2.size());
        verify(genericExcelParser, times(2)).parseExcelFile(
                eq(testFile),
                any(ExcelColumnMapping.class),
                eq(parchmentRowMapper)
        );
    }

    private MultipartFile createRealParchmentExcelFile() throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Parchment Data");

        // Header row
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Institution Name");
        headerRow.createCell(1).setCellValue("Country");
        headerRow.createCell(2).setCellValue("City");
        headerRow.createCell(3).setCellValue("State/County/Region");
        headerRow.createCell(4).setCellValue("Service Provider");
        headerRow.createCell(5).setCellValue("Surcharge Amount");
        headerRow.createCell(6).setCellValue("Payment Method");
        headerRow.createCell(7).setCellValue("Code");
        headerRow.createCell(8).setCellValue("Turnaround Time");
        headerRow.createCell(9).setCellValue("Follow Up Allowed");

        // Data row 1
        Row dataRow1 = sheet.createRow(1);
        dataRow1.createCell(0).setCellValue("Harvard University");
        dataRow1.createCell(1).setCellValue("USA");
        dataRow1.createCell(2).setCellValue("Cambridge");
        dataRow1.createCell(3).setCellValue("MA");
        dataRow1.createCell(4).setCellValue("Parchment Exchange");
        dataRow1.createCell(5).setCellValue("5.00");
        dataRow1.createCell(6).setCellValue("Credit Card");
        dataRow1.createCell(7).setCellValue("HARV001");
        dataRow1.createCell(8).setCellValue("3");
        dataRow1.createCell(9).setCellValue("Yes");

        // Data row 2
        Row dataRow2 = sheet.createRow(2);
        dataRow2.createCell(0).setCellValue("MIT");
        dataRow2.createCell(1).setCellValue("USA");
        dataRow2.createCell(2).setCellValue("Cambridge");
        dataRow2.createCell(3).setCellValue("MA");
        dataRow2.createCell(4).setCellValue("Parchment Exchange");
        dataRow2.createCell(5).setCellValue("5.00");
        dataRow2.createCell(6).setCellValue("Credit Card");
        dataRow2.createCell(7).setCellValue("MIT001");
        dataRow2.createCell(8).setCellValue("3");
        dataRow2.createCell(9).setCellValue("Yes");

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            workbook.write(bos);
            byte[] bytes = bos.toByteArray();
            return new MockMultipartFile(
                    "file",
                    "parchment.xlsx",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    bytes
            );
        } finally {
            workbook.close();
            bos.close();
        }
    }
}

