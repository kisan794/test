package com.hireright.sourceintelligence.reports.service.impl;

import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.SortOrder;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;
import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.constants.ErrorConstants.INVALID_SORT;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.ACTION;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.ADDRESS;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.APPROVAL_STATUS;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.APPROVED_BY;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.AUTO_MATCH;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.CANCELLED;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.COMPLETED;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.CREATE;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.CREATED_BY;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.CREATED_DATE;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.DELETE;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.HON;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.ON_HOLD;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.ORGANIZATION_NAME;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.ORGANIZATION_TYPE;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.ORIGIN;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.REASON;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.UPDATE;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.USED_COUNT;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.VERIFICATION_VALIDATION_DATE;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.VERSION;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.MetaData.RESEARCHER_NAME;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.MongoRegex.*;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.*;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.SortFields.*;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowInvalidRequest;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

public class ReportsQueryBuilder {

    // Field name constants to avoid duplication
    private static final String FIELD_OPERATOR_NAME = "operatorName";
    private static final String FIELD_RESEARCHER_NAME = "researcherName";
    private static final String FIELD_NEW_COUNT = "newCount";
    private static final String FIELD_IN_PROGRESS = "inProgress";
    private static final String FIELD_ON_HOLD = "onHold";
    private static final String FIELD_CANCELLED = "cancelled";
    private static final String FIELD_COMPLETED = "completed";

    private ReportsQueryBuilder() {
        throw new IllegalStateException("Utility class");
    }
    /* Contact Utilization & Auto Match */
    //Not needed
    public static Criteria queryBuilder(ReportsRequestDTO reportsRequestDTO){
        Criteria criteria = new Criteria();
        criteria.and(ACTION).is(ACTION_USED_COUNT);

        var dateRange = reportsRequestDTO.getDateRange();
        if (dateRange != null
                && dateRange.getStartDate() != null
                && dateRange.getEndDate() != null) {

            criteria.and(CREATED_DATE)
                    .gte(Date.from(dateRange.getStartDate()))
                    .lte(Date.from(dateRange.getEndDate()));
        }

        if(!StringUtils.isEmpty(reportsRequestDTO.getOrganizationName())){
            criteria.and(ORGANIZATION_NAME).is(reportsRequestDTO.getOrganizationName());
        }
        if(!StringUtils.isEmpty(reportsRequestDTO.getOperatorName())){
            criteria.and(CREATED_BY).is(reportsRequestDTO.getOperatorName());
        }
        if(!StringUtils.isEmpty(reportsRequestDTO.getOperatorRole())){
            criteria.and(OPERATOR_ROLE).is(reportsRequestDTO.getOperatorRole());
        }

        return criteria;
    }

    /* Contact Utilization & Auto Match with region */
    public static Criteria queryBuilder(ReportsRequestDTO reportsRequestDTO, List<String> countryList){
        Criteria criteria = new Criteria();
        criteria.and(ACTION).is(ACTION_USED_COUNT);

        var dateRange = reportsRequestDTO.getDateRange();
        if (dateRange != null && dateRange.getStartDate() != null && dateRange.getEndDate() != null) {
            criteria.and(CREATED_DATE)
                    .gte(Date.from(dateRange.getStartDate()))
                    .lte(Date.from(dateRange.getEndDate()));
        }

        if(!StringUtils.isEmpty(reportsRequestDTO.getOrganizationName())){
            criteria.and(ORGANIZATION_NAME).is(reportsRequestDTO.getOrganizationName());
        }
        if(!StringUtils.isEmpty(reportsRequestDTO.getOperatorName())){
            criteria.and(CREATED_BY).is(reportsRequestDTO.getOperatorName());
        }
        if(!StringUtils.isEmpty(reportsRequestDTO.getOperatorRole())){
            criteria.and(OPERATOR_ROLE).is(reportsRequestDTO.getOperatorRole());
        }
        if(countryList != null && !countryList.isEmpty()){
            Document expr = new Document(IN, List.of(
                    new Document(ARRAY_ELEM_AT, List.of(
                            new Document(SPLIT, List.of(DOLLAR + ADDRESS, ",")),
                            0
                    )),
                    countryList
            ));
            criteria.and(EXPR).is(expr);
        }
        return criteria;
    }

    /* Source Information & Approval Average TAT */
    public static Criteria queryBuilderForSourceInformationAndTat(ReportsRequestDTO reportsRequestDTO, List<String> countryList){
        Criteria criteria = new Criteria();
        if(!StringUtils.isEmpty(reportsRequestDTO.getOperatorName())){
            criteria.and(CREATED_BY).is(reportsRequestDTO.getOperatorName());
        } else {
            criteria.and(CREATED_BY).exists(true).ne("").ne(null);
        }
        var dateRange = reportsRequestDTO.getDateRange();
        if (dateRange != null
                && dateRange.getStartDate() != null
                && dateRange.getEndDate() != null) {

            criteria.and(CREATED_DATE)
                    .gte(Date.from(dateRange.getStartDate()))
                    .lte(Date.from(dateRange.getEndDate()));
        }
        if(countryList != null && !countryList.isEmpty()){
            Document expr = new Document(IN, List.of(
                    new Document(ARRAY_ELEM_AT, List.of(
                            new Document(SPLIT, List.of(DOLLAR+ADDRESS, ",")),
                            0
                    )),
                    countryList
            ));

            criteria.and(EXPR).is(expr);
        }

        return criteria;
    }

    public static Criteria queryBuilderForReviewerRole(ReportsRequestDTO reportsRequestDTO, List<String> countryList){
        Criteria criteria = new Criteria();
        if(!StringUtils.isEmpty(reportsRequestDTO.getOperatorName())){
            criteria.and(APPROVED_BY).is(reportsRequestDTO.getOperatorName());
        }else {
            criteria.and(APPROVED_BY).exists(true).ne("").ne(null);
        }
        var dateRange = reportsRequestDTO.getDateRange();
        if (dateRange != null
                && dateRange.getStartDate() != null
                && dateRange.getEndDate() != null) {

            criteria.and(CREATED_DATE)
                    .gte(Date.from(dateRange.getStartDate()))
                    .lte(Date.from(dateRange.getEndDate()));
        }
        if(countryList != null && !countryList.isEmpty()){
            Document expr = new Document(IN, List.of(
                    new Document(ARRAY_ELEM_AT, List.of(
                            new Document(SPLIT, List.of(DOLLAR+ADDRESS, ",")),
                            0
                    )),
                    countryList
            ));

            criteria.and(EXPR).is(expr);
        }

        return criteria;
    }


    public static MatchOperation matchOperation(Criteria criteria){
        return match(criteria);
    }

    public static SkipOperation skipOperation(int startPage, int pageSize) {
        return skip((long) (startPage - 1) * pageSize);
    }

    public static LimitOperation limitOperation(int pageSize) {
        return limit(pageSize);
    }

    public static CountOperation countOperation() {
        return count().as(COUNT);
    }
    public static FacetOperation facetOperation(int startPage, int pageSize) {
        return facet().and(countOperation()).as(TOTAL)
                .and(skipOperation(startPage, pageSize), limitOperation(pageSize)).as(DATA);
    }
    public static FacetOperation facetOperationWithSorting(SortOperation sort, int startPage, int pageSize) {
        return facet().and(countOperation()).as(TOTAL)
                .and(sort, skipOperation(startPage, pageSize), limitOperation(pageSize)).as(DATA);
    }

    public static FacetOperation facetOperationWithGroup(SortOperation sortOperation,int startPage, int pageSize, GroupOperation groupOperation) {
        return facet().and(countOperation()).as(TOTAL)
                .and(groupOperation, sortOperation, skipOperation(startPage, pageSize), limitOperation(pageSize)).as(DATA);
    }

    public static ProjectionOperation finalProjectionWithTotalCountInPipeline(String responseAs) {
        return project()
                .and(ArrayOperators.ArrayElemAt.arrayOf(TOTAL_COUNT).elementAt(0)).as(TOTAL)
                .and(DATA).as(responseAs);
    }

    public static ProjectionOperation operatorRoleFinalProjection() {
        return project()
                .and(ArrayOperators.ArrayElemAt.arrayOf(TOTAL_COUNT).elementAt(0)).as(TOTAL)
                .and(DATA).as("operatorReportFlatList");
    }

    public static ProjectionOperation reviewerRoleFinalProjection() {
        return project()
                .and(ArrayOperators.ArrayElemAt.arrayOf(TOTAL_COUNT).elementAt(0)).as(TOTAL)
                .and(DATA).as("reviewerReportList");
    }

    public static GroupOperation contactUtilizationGroupOperation() {
        return Aggregation.group(ORGANIZATION_NAME)
                .count().as(USED_COUNT)
                .first(ORGANIZATION_NAME).as(ORGANIZATION_NAME)
                .last(CREATED_DATE).as(CREATED_DATE)
                .last(VERIFICATION_VALIDATION_DATE).as(VERIFICATION_VALIDATION_DATE)
                .last(ADDRESS).as(ADDRESS)
                .last(APPROVAL_STATUS).as(APPROVAL_STATUS)
                .last(APPROVED_BY).as(APPROVED_BY)
                .last(ORGANIZATION_TYPE).as(ORGANIZATION_TYPE)
                .last(ORIGIN).as(ORIGIN)
                .last(HON).as(HON);
    }

    public static GroupOperation autoMatchGroupOperation() {
        return Aggregation.group(ORGANIZATION_NAME)
                .count().as(USED_COUNT)
                .first(ORGANIZATION_NAME).as(ORGANIZATION_NAME)
                .last(ADDRESS).as(ADDRESS)
                .last(ORGANIZATION_TYPE).as(ORGANIZATION_TYPE)
                .last(AUTO_MATCH).as(AUTO_MATCH)
                .last(CREATED_DATE).as(CREATED_DATE)
                .last(HON).as(HON);
    }

    public static GroupOperation operatorRoleGroupOperation() {
        return Aggregation.group(CREATED_BY)
                .first(CREATED_BY).as(FIELD_OPERATOR_NAME)
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).is(CREATE),
                                Criteria.where(APPROVAL_STATUS).in(ApprovalStatus.PENDING_APPROVAL.getStatus(), ApprovalStatus.SAVE_PENDING_APPROVAL.getStatus())))
                        .then(1).otherwise(0)).as("addedNew")
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).is(CREATE),
                                Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.IN_PROGRESS.getStatus())))
                        .then(1).otherwise(0)).as("addedInProgress")
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).is(CREATE),
                                Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.ONHOLD.getStatus())))
                        .then(1).otherwise(0)).as("addedOnHold")
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).is(CREATE),
                                Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.REJECTED.getStatus())))
                        .then(1).otherwise(0)).as("addedCancelled")
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).is(CREATE),
                                Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.APPROVED.getStatus())))
                        .then(1).otherwise(0)).as("addedCompleted")
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).is(UPDATE),
                                Criteria.where(APPROVAL_STATUS).in(ApprovalStatus.PENDING_APPROVAL.getStatus(), ApprovalStatus.SAVE_PENDING_APPROVAL.getStatus())))
                        .then(1).otherwise(0)).as("changedNew")
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).is(UPDATE),
                                Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.IN_PROGRESS.getStatus())))
                        .then(1).otherwise(0)).as("changedInProgress")
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).is(UPDATE),
                                Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.ONHOLD.getStatus())))
                        .then(1).otherwise(0)).as("changedOnHold")
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).is(UPDATE),
                                Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.REJECTED.getStatus())))
                        .then(1).otherwise(0)).as("changedCancelled")
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).is(UPDATE),
                                Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.APPROVED.getStatus())))
                        .then(1).otherwise(0)).as("changedCompleted")
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).is(ReportConstants.AggregateFields.ARCHIVED_ACTION),
                                Criteria.where(APPROVAL_STATUS).in(ApprovalStatus.PENDING_APPROVAL.getStatus(), ApprovalStatus.SAVE_PENDING_APPROVAL.getStatus())))
                        .then(1).otherwise(0)).as("archivedNew")
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).is(ReportConstants.AggregateFields.ARCHIVED_ACTION),
                                Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.IN_PROGRESS.getStatus())))
                        .then(1).otherwise(0)).as("archivedInProgress")
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).is(ReportConstants.AggregateFields.ARCHIVED_ACTION),
                                Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.ONHOLD.getStatus())))
                        .then(1).otherwise(0)).as("archivedOnHold")
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).is(ReportConstants.AggregateFields.ARCHIVED_ACTION),
                                Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.REJECTED.getStatus())))
                        .then(1).otherwise(0)).as("archivedCancelled")
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).is(ReportConstants.AggregateFields.ARCHIVED_ACTION),
                                Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.APPROVED.getStatus())))
                        .then(1).otherwise(0)).as("archivedCompleted")
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).in(DELETE, DELETE2),
                                Criteria.where(APPROVAL_STATUS).in(ApprovalStatus.PENDING_APPROVAL.getStatus(), ApprovalStatus.SAVE_PENDING_APPROVAL.getStatus())))
                        .then(1).otherwise(0)).as("deletedNew")
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).in(DELETE, DELETE2),
                                Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.IN_PROGRESS.getStatus())))
                        .then(1).otherwise(0)).as("deletedInProgress")
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).in(DELETE, DELETE2),
                                Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.ONHOLD.getStatus())))
                        .then(1).otherwise(0)).as("deletedOnHold")
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).in(DELETE, DELETE2),
                                Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.REJECTED.getStatus())))
                        .then(1).otherwise(0)).as("deletedCancelled")
                .sum(ConditionalOperators.Cond.when(new Criteria().andOperator(
                                Criteria.where(ACTION).in(DELETE, DELETE2),
                                Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.APPROVED.getStatus())))
                        .then(1).otherwise(0)).as("deletedCompleted");
    }

    public static GroupOperation reviewerRoleGroupOperation() {
        return Aggregation.group(APPROVED_BY)
                .first(APPROVED_BY).as(FIELD_RESEARCHER_NAME)
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).in(ApprovalStatus.PENDING_APPROVAL.getStatus(), ApprovalStatus.SAVE_PENDING_APPROVAL.getStatus()))
                        .then(1).otherwise(0)).as(FIELD_NEW_COUNT)
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.IN_PROGRESS.getStatus()))
                        .then(1).otherwise(0)).as(FIELD_IN_PROGRESS)
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.ONHOLD.getStatus()))
                        .then(1).otherwise(0)).as(FIELD_ON_HOLD)
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.REJECTED.getStatus()))
                        .then(1).otherwise(0)).as(FIELD_CANCELLED)
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.APPROVED.getStatus()))
                        .then(1).otherwise(0)).as(FIELD_COMPLETED);
    }

    public static GroupOperation operatorAndReviewerActionGroupOperation() {
        return Aggregation.group(CREATED_BY)
                .first(CREATED_BY).as(FIELD_RESEARCHER_NAME)
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(CREATE))
                        .then(1).otherwise(0)).as("added")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(UPDATE))
                        .then(1).otherwise(0)).as("changed")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(ReportConstants.AggregateFields.ARCHIVED_ACTION))
                        .then(1).otherwise(0)).as("archived")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).in(DELETE, DELETE2))
                        .then(1).otherwise(0)).as("deleted");
    }

    public static GroupOperation operatorAndReviewerStatusGroupOperation() {
        return Aggregation.group(APPROVED_BY)
                .first(APPROVED_BY).as(FIELD_RESEARCHER_NAME)
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).in(ApprovalStatus.PENDING_APPROVAL.getStatus(), ApprovalStatus.SAVE_PENDING_APPROVAL.getStatus()))
                        .then(1).otherwise(0)).as(FIELD_NEW_COUNT)
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.IN_PROGRESS.getStatus()))
                        .then(1).otherwise(0)).as(FIELD_IN_PROGRESS)
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.ONHOLD.getStatus()))
                        .then(1).otherwise(0)).as(FIELD_ON_HOLD)
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.REJECTED.getStatus()))
                        .then(1).otherwise(0)).as(FIELD_CANCELLED)
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.APPROVED.getStatus()))
                        .then(1).otherwise(0)).as(FIELD_COMPLETED);
    }


    public static Criteria queryBuilderForDelete(ReportsRequestDTO reportsRequestDTO, List<String> countryList){
        Criteria criteria = new Criteria();
        criteria.and(ACTION).in(DELETE, DELETE2);

        if(reportsRequestDTO.getDateRange() != null && reportsRequestDTO.getDateRange().getStartDate() != null && reportsRequestDTO.getDateRange().getEndDate() != null){
            criteria.and(CREATED_DATE).gte(Date.from(reportsRequestDTO.getDateRange().getStartDate()))
                    .lte(Date.from(reportsRequestDTO.getDateRange().getEndDate()));
        }

        if(countryList != null && !countryList.isEmpty()){
            Document expr = new Document(IN, List.of(
                    new Document(ARRAY_ELEM_AT, List.of(
                            new Document(SPLIT, List.of(DOLLAR+ADDRESS, ",")),
                            0
                    )),
                    countryList
            ));

            criteria.and(EXPR).is(expr);
        }

        if(!StringUtils.isEmpty(reportsRequestDTO.getOrganizationName())){
            criteria.and(ORGANIZATION_NAME).is(reportsRequestDTO.getOrganizationName());
        }
        if(!StringUtils.isEmpty(reportsRequestDTO.getOperatorName())){
            criteria.and(CREATED_BY).is(reportsRequestDTO.getOperatorName());
        }
        if(!StringUtils.isEmpty(reportsRequestDTO.getOperatorRole())){
            criteria.and(OPERATOR_ROLE).is(reportsRequestDTO.getOperatorRole());
        }

        return criteria;
    }

    public static GroupOperation deleteGroupOperation() {
        return Aggregation.group(ORGANIZATION_NAME)
                .first(ORGANIZATION_NAME).as(ORGANIZATION_NAME)
                .last(CREATED_DATE).as(CREATED_DATE)
                .last(VERIFICATION_VALIDATION_DATE).as(VERIFICATION_VALIDATION_DATE)
                .last(ADDRESS).as(ADDRESS)
                .last(APPROVED_BY).as(APPROVED_BY)
                .last(ORGANIZATION_TYPE).as(ORGANIZATION_TYPE)
                .last(REASON).as(REASON)
                .last(HON).as(HON);
    }

    public static String getSortPropertyMapped(String sort) {
        String sortOnField;
        switch (sort) {
            case ReportConstants.SortFields.HON, HON_1 -> sortOnField = HON;
            case ReportConstants.SortFields.ORGANIZATION_NAME -> sortOnField = ORGANIZATION_NAME;
            case ReportConstants.SortFields.ADDRESS -> sortOnField = ADDRESS;
            case VERIFICATION_DATE -> sortOnField = VERIFICATION_VALIDATION_DATE;
            case ReportConstants.SortFields.ORGANIZATION_TYPE -> sortOnField = ORGANIZATION_TYPE;
            case ReportConstants.SortFields.APPROVAL_STATUS -> sortOnField = APPROVAL_STATUS;
            case ReportConstants.SortFields.APPROVED_BY, REVIEWER_BY -> sortOnField = APPROVED_BY;
            case ReportConstants.SortFields.CREATED_BY, RESEARCHER_NAME -> sortOnField = CREATED_BY;
            case ReportConstants.SortFields.AUTO_MATCH, IS_AUTO_MATCH -> sortOnField = AUTO_MATCH;
            case ReportConstants.SortFields.REASON -> sortOnField = REASON;
            case ReportConstants.SortFields.CHANGE_TYPE -> sortOnField = ACTION;
            case ReportConstants.SortFields.USED_COUNT -> sortOnField = USED_COUNT;
            case ReportConstants.SortFields.ORIGIN -> sortOnField = ORIGIN;
            case ReportConstants.SortFields.USED_DATE,CREATED_DATE  -> sortOnField = CREATED_DATE;
            default -> sortOnField = CREATED_DATE;
        }
        return sortOnField;
    }

    public static SortOperation buildSortOperation(String sort, String order) {
        SortOperation sortOperation;
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            String sortOnField = getSortPropertyMapped(sort);
            if (sortOnField == null) {
                logAndThrowInvalidRequest(INVALID_SORT, null, sort);
            }
            sortOperation = new SortOperation(
                    Sort.by(getSortOrderDirection(order), sortOnField));
        } else {
            sortOperation = new SortOperation(Sort.by(Sort.Direction.DESC, CREATED_DATE));
        }
        return sortOperation;
    }
    public static SortOperation buildSortOperationForTAT(String sort, String order) {
        SortOperation sortOperation;
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            String sortOnField = getSortPropertyMappedForTAT(sort);
            if (sortOnField == null) {
                logAndThrowInvalidRequest(INVALID_SORT, null, sort);
            }
            sortOperation = new SortOperation(
                    Sort.by(getSortOrderDirection(order), sortOnField));
        } else {
            sortOperation = new SortOperation(Sort.by(Sort.Direction.DESC, CREATED_DATE));
        }
        return sortOperation;
    }

    public static Sort.Direction getSortOrderDirection(String order) {
        if (order.equalsIgnoreCase(SortOrder.ASC.getType())) {
            return Sort.Direction.ASC;
        } else {
            return Sort.Direction.DESC;
        }
    }

    public static String getSortPropertyMappedForReviewer(String sort) {
        String sortOnField;
        switch (sort) {
            case ReportConstants.SortFields.RESEARCHER_NAME -> sortOnField = FIELD_RESEARCHER_NAME;
            case ReportConstants.SortFields.NEW_COUNT -> sortOnField = FIELD_NEW_COUNT;
            case ReportConstants.SortFields.IN_PROGRESS -> sortOnField = FIELD_IN_PROGRESS;
            case ReportConstants.SortFields.ON_HOLD -> sortOnField = FIELD_ON_HOLD;
            case ReportConstants.SortFields.CANCELLED -> sortOnField = FIELD_CANCELLED;
            case ReportConstants.SortFields.COMPLETED -> sortOnField = FIELD_COMPLETED;
            default -> sortOnField = null;
        }
        return sortOnField;
    }

    public static String getSortPropertyMappedForTAT(String sort) {
        String sortOnField;
        switch (sort) {
            case ReportConstants.SortFields.HON, HON_1 -> sortOnField = DATA+"."+HON;
            case ReportConstants.SortFields.ORGANIZATION_NAME -> sortOnField = DATA+"."+ORGANIZATION_NAME;
            case ReportConstants.SortFields.ADDRESS -> sortOnField = DATA+"."+ADDRESS;
            case VERIFICATION_DATE -> sortOnField = DATA+"."+VERIFICATION_VALIDATION_DATE;
            case ReportConstants.SortFields.ORGANIZATION_TYPE -> sortOnField = DATA+"."+ORGANIZATION_TYPE;
            case ReportConstants.SortFields.APPROVAL_STATUS -> sortOnField = DATA+"."+APPROVAL_STATUS;
            case ReportConstants.SortFields.APPROVED_BY, REVIEWER_BY -> sortOnField = DATA+"."+APPROVED_BY;
            case ReportConstants.SortFields.CREATED_BY, RESEARCHER_NAME -> sortOnField = DATA+"."+CREATED_BY;
            case ReportConstants.SortFields.AUTO_MATCH, IS_AUTO_MATCH -> sortOnField = DATA+"."+AUTO_MATCH;
            case ReportConstants.SortFields.REASON -> sortOnField = DATA+"."+REASON;
            case ReportConstants.SortFields.CHANGE_TYPE, ReportConstants.SortFields.ACTION -> sortOnField = DATA+"."+ACTION;
            case ReportConstants.SortFields.USED_COUNT -> sortOnField = DATA+"."+USED_COUNT;
            case ReportConstants.SortFields.ORIGIN -> sortOnField = DATA+"."+ORIGIN;
            case ReportConstants.SortFields.USED_DATE,CREATED_DATE  -> sortOnField = DATA+"."+CREATED_DATE;
            default -> sortOnField = null;
        }
        return sortOnField;
    }


    public static SortOperation buildSortOperationForReviewer(String sort, String order) {
        SortOperation sortOperation;
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            String sortOnField = getSortPropertyMappedForReviewer(sort);
            if (sortOnField == null) {
                logAndThrowInvalidRequest(INVALID_SORT, null, sort);
            }
            sortOperation = new SortOperation(
                    Sort.by(getSortOrderDirection(order), sortOnField));
        } else {
            sortOperation = new SortOperation(Sort.by(Sort.Direction.DESC, FIELD_RESEARCHER_NAME));
        }
        return sortOperation;
    }

    public static String getSortPropertyMappedForOperator(String sort) {
        String sortOnField;
        switch (sort) {
            case ReportConstants.SortFields.OPERATOR_NAME -> sortOnField = FIELD_OPERATOR_NAME;
            case ReportConstants.SortFields.ADDED_NEW -> sortOnField = "addedNew";
            case ReportConstants.SortFields.ADDED_IN_PROGRESS -> sortOnField = "addedInProgress";
            case ReportConstants.SortFields.ADDED_ON_HOLD -> sortOnField = "addedOnHold";
            case ReportConstants.SortFields.ADDED_CANCELLED -> sortOnField = "addedCancelled";
            case ReportConstants.SortFields.ADDED_COMPLETED -> sortOnField = "addedCompleted";
            case ReportConstants.SortFields.CHANGED_NEW -> sortOnField = "changedNew";
            case ReportConstants.SortFields.CHANGED_IN_PROGRESS -> sortOnField = "changedInProgress";
            case ReportConstants.SortFields.CHANGED_ON_HOLD -> sortOnField = "changedOnHold";
            case ReportConstants.SortFields.CHANGED_CANCELLED -> sortOnField = "changedCancelled";
            case ReportConstants.SortFields.CHANGED_COMPLETED -> sortOnField = "changedCompleted";
            case ReportConstants.SortFields.ARCHIVED_NEW -> sortOnField = "archivedNew";
            case ReportConstants.SortFields.ARCHIVED_IN_PROGRESS -> sortOnField = "archivedInProgress";
            case ReportConstants.SortFields.ARCHIVED_ON_HOLD -> sortOnField = "archivedOnHold";
            case ReportConstants.SortFields.ARCHIVED_CANCELLED -> sortOnField = "archivedCancelled";
            case ReportConstants.SortFields.ARCHIVED_COMPLETED -> sortOnField = "archivedCompleted";
            case ReportConstants.SortFields.DELETED_NEW -> sortOnField = "deletedNew";
            case ReportConstants.SortFields.DELETED_IN_PROGRESS -> sortOnField = "deletedInProgress";
            case ReportConstants.SortFields.DELETED_ON_HOLD -> sortOnField = "deletedOnHold";
            case ReportConstants.SortFields.DELETED_CANCELLED -> sortOnField = "deletedCancelled";
            case ReportConstants.SortFields.DELETED_COMPLETED -> sortOnField = "deletedCompleted";
            default -> sortOnField = null;
        }
        return sortOnField;
    }

    public static SortOperation buildSortOperationForOperator(String sort, String order) {
        SortOperation sortOperation;
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            String sortOnField = getSortPropertyMappedForOperator(sort);
            if (sortOnField == null) {
                logAndThrowInvalidRequest(INVALID_SORT, null, sort);
            }
            sortOperation = new SortOperation(
                    Sort.by(getSortOrderDirection(order), sortOnField));
        } else {
            sortOperation = new SortOperation(Sort.by(Sort.Direction.DESC, FIELD_OPERATOR_NAME));
        }
        return sortOperation;
    }

    public static GroupOperation approvalTATGroupOperation() {
        return Aggregation.group(HON, VERSION, REASON)
                .push(Aggregation.ROOT).as(DATA);
    }

    public static Criteria queryBuilderForApprovalTat(ReportsRequestDTO reportsRequestDTO, List<String> countryList){
        Criteria criteria = new Criteria();
        List<Criteria> orOperator = new ArrayList<>();
        if(!StringUtils.isEmpty(reportsRequestDTO.getOrganizationName())){
            criteria.and(ORGANIZATION_NAME).is(reportsRequestDTO.getOrganizationName());
        }
        if(!StringUtils.isEmpty(reportsRequestDTO.getOperatorName())){
            orOperator.add(Criteria.where(CREATED_BY).is(reportsRequestDTO.getOperatorName()));
            orOperator.add(Criteria.where(APPROVED_BY).is(reportsRequestDTO.getOperatorName()));

            criteria.and(VERSION).exists(true).ne(null).ne("");
        }else{
            orOperator.add(Criteria.where(CREATED_BY).exists(true).ne(null).ne(""));
            orOperator.add(Criteria.where(APPROVED_BY).exists(true).ne(null).ne(""));
            criteria.and(VERSION).exists(true).ne(null).ne("");
        }
        criteria.orOperator(orOperator);
        criteria.and(TXN_TYPE).in(APPROVAL_FLOW, DELETE2, ARCHIVED2);
        if(countryList != null && !countryList.isEmpty()){
            Document expr = new Document(IN, List.of(
                    new Document(ARRAY_ELEM_AT, List.of(
                            new Document(SPLIT, List.of(DOLLAR+ADDRESS, ",")),
                            0
                    )),
                    countryList
            ));
            criteria.and(EXPR).is(expr);
        }
        var dateRange = reportsRequestDTO.getDateRange();
        if (dateRange != null
                && dateRange.getStartDate() != null
                && dateRange.getEndDate() != null) {

            criteria.and(CREATED_DATE)
                    .gte(Date.from(dateRange.getStartDate()))
                    .lte(Date.from(dateRange.getEndDate()));
        }
        return criteria;
    }


    public static AddFieldsOperation addFieldForVVD() {
        return AddFieldsOperation.builder()
                .addField(VERIFICATION_VALIDATION_DATE)
                .withValue(
                        new Document(DATE_FROM_STRING,
                                new Document(DATE_STRING, "$"+VERIFICATION_VALIDATION_DATE)
                                        .append(FORMAT, DATE_FORMAT)
                                        .append(ON_ERROR, null)
                                        .append(ON_NULL, null)
                        )
                )
                .build();
    }

    public static ProjectionOperation excludeProjection() {
        return project().andExclude(VERIFICATION_VALIDATION_DATE,ORIGIN,APPROVED_ID,ADDRESS);
    }

    public static Criteria queryBuilderForTatFilter() {
        Criteria criteria = new Criteria();
        criteria.and(DATA_APPROVAL_STATUS).in(APPROVED, REJECTED);
        return criteria;
    }
}