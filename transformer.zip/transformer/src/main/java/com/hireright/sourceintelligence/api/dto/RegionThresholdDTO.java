package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RegionThresholdDTO {

    @JsonProperty("US")
    private int US;

    @JsonProperty("EMEA")
    private int EMEA;

    @JsonProperty("LATAM")
    private int LATAM;

    @JsonProperty("CANADA")
    private int CANADA;

    @JsonProperty("APAC")
    private int APAC;

    @JsonProperty("AUSTRALIA")
    private int AUSTRALIA;

}
