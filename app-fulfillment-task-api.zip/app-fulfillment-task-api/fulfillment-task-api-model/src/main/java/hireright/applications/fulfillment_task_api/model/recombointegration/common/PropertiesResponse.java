package hireright.applications.fulfillment_task_api.model.recombointegration.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

@lombok.Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PropertiesResponse {

    private Boolean audit;

    private String noteCode;

    private Boolean rfmFlag;
}
