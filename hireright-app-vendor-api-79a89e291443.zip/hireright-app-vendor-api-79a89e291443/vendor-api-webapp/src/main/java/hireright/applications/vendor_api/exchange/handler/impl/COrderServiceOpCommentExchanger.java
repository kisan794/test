/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-08-14	Created
 *	T.Prikk		2017-12-12	HIVPE-27993: added saveWithoutStateModification()
 *	T.Prikk		2017-12-12	HIVPE-27993: added overrides for createEntity(), updateEntity() that use saveWithoutChangingState()
 *	T.Prikk		2017-12-12	HIVPE-27993: modified doTransferForUpdate(), removed setting of state-related fields
 *	T.Prikk		2018-11-04	HIVPE-26547: transfer properties from DTO in doTransferForUpdate()
 *	T.Prikk		2018-05-04	HIVPE-26547: remove extractProperties()
 */
package hireright.applications.vendor_api.exchange.handler.impl;

import hireright.applications.vendor_api.exchange.handler.AEntityExchanger;
import hireright.applications.vendor_api.exchange.handler.objects.CEntityExchangeException;
import hireright.applications.vendor_api.exchange.handler.objects.COrderServiceEntityExchangeContext;
import hireright.applications.vendor_api.model.COrderServiceOperatorCommentRequest;
import hireright.objects.order2.COrderServiceOperatorComment;

public class COrderServiceOpCommentExchanger extends AEntityExchanger<COrderServiceEntityExchangeContext<COrderServiceOperatorCommentRequest>, COrderServiceOperatorCommentRequest, COrderServiceOperatorComment>
{
	/**
	 * Use order_service_operator_comment ID field to identify commetns
	 */
	@Override
	protected String getEntityReference(COrderServiceOperatorComment comment)
	{
		return String.valueOf(comment.getID());
	}

	/**
	 * Transfer data in case of create
	 */
	@Override
	protected void doTransferForCreate(COrderServiceEntityExchangeContext<COrderServiceOperatorCommentRequest> context, COrderServiceOperatorComment comment) throws CEntityExchangeException
	{
		doTransferForUpdate(context, comment);
		
		if (context.getOrderServiceID() == null)
		{
			throw new CEntityExchangeException("Order service ID not provided in context");
		}
		comment.setOrderServiceID(context.getOrderServiceID());
	}

	/**
	 * Transfer non-insertable fields in case of create
	 */
	@Override
	protected boolean doTransferForPostCreate(COrderServiceEntityExchangeContext<COrderServiceOperatorCommentRequest> context, COrderServiceOperatorComment comment) throws CEntityExchangeException
	{
		COrderServiceOperatorCommentRequest commentDTO = context.getTransferObject();
		// timestamp field is not insertable!
		comment.setTmstmp(commentDTO.getTimestamp());
		comment.setState(COrderServiceOperatorComment.STATE_CREATED);
		return true;
	}

	@Override
	protected void createEntity(COrderServiceOperatorComment comment) throws CEntityExchangeException
	{
		saveWithoutChangingState(comment);
	}

	@Override
	protected void updateEntity(COrderServiceOperatorComment comment) throws CEntityExchangeException
	{
		saveWithoutChangingState(comment);
	}

	/**
	 * Comment operation exchanges are based on state machine transitions - in order to avoid never-ending exchanges, this method will skip state machine updates.
	 * 
	 * @param comment entity to be saved to DB
	 */
	private void saveWithoutChangingState(COrderServiceOperatorComment comment) throws CEntityExchangeException
	{
		COrderServiceOperatorComment.save(comment, true);
	}

	/**
	 * Transfer data in case of update
	 */
	@Override
	protected void doTransferForUpdate(COrderServiceEntityExchangeContext<COrderServiceOperatorCommentRequest> context, COrderServiceOperatorComment comment) throws CEntityExchangeException
	{
		COrderServiceOperatorCommentRequest commentDTO = context.getTransferObject();
		comment.setText(commentDTO.getText());
		comment.setNText(commentDTO.getNationalText());
		comment.setCommentsCode(commentDTO.getCommentsCode());
		comment.setDttm(commentDTO.getDate());
		comment.setTmstmp(commentDTO.getTimestamp());
		comment.setOperatorName(commentDTO.getOperatorName());
	}

	public COrderServiceOpCommentExchanger()
	{
		super(COrderServiceOperatorComment.class);
	}
}
