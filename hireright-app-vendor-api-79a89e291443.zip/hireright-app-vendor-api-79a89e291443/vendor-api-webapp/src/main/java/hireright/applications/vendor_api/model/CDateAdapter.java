/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-07-25	Created
 */
package hireright.applications.vendor_api.model;

import java.util.Date;

import jakarta.xml.bind.annotation.adapters.XmlAdapter;

public class CDateAdapter extends XmlAdapter<String, Date>
{
	@Override
	public Date unmarshal(String v) throws Exception
	{
		return new Date(Long.parseLong(v));
	}

	@Override
	public String marshal(Date v) throws Exception
	{
		return String.valueOf(v.getTime());
	}
}
