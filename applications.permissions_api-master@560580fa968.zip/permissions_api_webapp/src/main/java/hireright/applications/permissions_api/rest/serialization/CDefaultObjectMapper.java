package hireright.applications.permissions_api.rest.serialization;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-16  HRG-330191 initial version
 */

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

public class CDefaultObjectMapper extends ObjectMapper
{
	@SuppressWarnings("deprecation")
	public CDefaultObjectMapper()
	{
		disable(MapperFeature.AUTO_DETECT_CREATORS);
		disable(MapperFeature.AUTO_DETECT_FIELDS);
		disable(MapperFeature.AUTO_DETECT_GETTERS);

		disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
		disable(SerializationFeature.FAIL_ON_SELF_REFERENCES);
		registerModule(new JavaTimeModule());

		SimpleModule pattern = new SimpleModule();
		registerModule(pattern);

		setAnnotationIntrospector(new JacksonAnnotationIntrospector());
	}
}
