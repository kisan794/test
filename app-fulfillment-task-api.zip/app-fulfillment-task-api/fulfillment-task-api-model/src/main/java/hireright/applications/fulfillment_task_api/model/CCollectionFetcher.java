package hireright.applications.fulfillment_task_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-26  ATS-1045 initial version
 */

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class CCollectionFetcher<T> {
    private static final int DEFAULT_CHUNK_SIZE = 500;

    private final ICollectionProducer<T> m_producer;
    private final int m_nChunkSize;

    public CCollectionFetcher(ICollectionProducer<T> producer, int nChunkSize) {
        this.m_producer = producer;
        this.m_nChunkSize = nChunkSize;
    }

    public CCollectionFetcher(ICollectionProducer<T> producer) {
        this(producer, DEFAULT_CHUNK_SIZE);
    }

    public CCollectionFetcher(Collection<T> collection) {
        this(new CListProducer<>(collection), DEFAULT_CHUNK_SIZE);
    }

    public void fetch(ICollectionConsumer<T> consumer) {
        long lOffset = 0L;
        Collection<T> items;
        do {
            items = this.m_producer.produce(lOffset, this.m_nChunkSize);
            lOffset += items.size();
            consumer.consume(items);
        } while (!Thread.currentThread().isInterrupted() && !items.isEmpty());
    }

    public interface ICollectionProducer<T> {
        Collection<T> produce(Long lOffset, Integer nLimit);
    }

    public interface ICollectionConsumer<T> {
        void consume(Collection<T> collection);
    }

    public static class CListProducer<T> implements ICollectionProducer<T> {
        private final List<T> m_collection = new ArrayList<>();

        public CListProducer(Collection<T> collection) {
            this.m_collection.addAll(collection);
        }

        @Override
        public Collection<T> produce(Long lOffset, Integer nLimit) {
            if (this.m_collection.isEmpty()) {
                return Collections.emptyList();
            }

            if (lOffset == null) {
                lOffset = 0L;
            }

            if (lOffset >= this.m_collection.size()) {
                return Collections.emptyList();
            }

            if (lOffset == 0L && (nLimit == null || nLimit >= this.m_collection.size())) {
                return this.m_collection;
            }
            else {
                nLimit = (int) (lOffset + nLimit);
                if (nLimit > this.m_collection.size()) {
                    nLimit = this.m_collection.size();
                }

                try {
                    return this.m_collection.subList(lOffset.intValue(), nLimit);
                } catch (Exception ignored) {
                    return Collections.emptyList();
                }
            }
        }
    }
}
