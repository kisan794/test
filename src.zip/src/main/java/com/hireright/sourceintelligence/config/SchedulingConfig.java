package com.hireright.sourceintelligence.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Configuration to enable scheduled tasks.
 * Required for DLQ processing scheduler.
 */
@Configuration
@EnableScheduling
public class SchedulingConfig {
}

