package hireright.applications.fulfillment_task_api.rest.recombointegration.config;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.retry.support.RetryTemplate;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for RetryConfiguration
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@DisplayName("RetryConfiguration Tests")
class RetryConfigurationTest {

    private RetryConfiguration config;

    @BeforeEach
    void setUp() {
        config = new RetryConfiguration();
    }

    @Test
    @DisplayName("Should create RetryTemplate bean")
    void testRetryTemplateCreation() {
        // When
        RetryTemplate retryTemplate = config.retryTemplate();

        // Then
        assertNotNull(retryTemplate);
    }

    @Test
    @DisplayName("Should create new RetryTemplate instance each time")
    void testRetryTemplateIsNewInstance() {
        // When
        RetryTemplate template1 = config.retryTemplate();
        RetryTemplate template2 = config.retryTemplate();

        // Then
        assertNotNull(template1);
        assertNotNull(template2);
        assertNotSame(template1, template2);
    }

    @Test
    @DisplayName("Should verify RetryTemplate is of correct type")
    void testRetryTemplateType() {
        // When
        RetryTemplate retryTemplate = config.retryTemplate();

        // Then
        assertEquals("org.springframework.retry.support.RetryTemplate",
                retryTemplate.getClass().getName());
    }

    @Test
    @DisplayName("Should create RetryTemplate with default configuration")
    void testRetryTemplateDefaultConfiguration() {
        // When
        RetryTemplate retryTemplate = config.retryTemplate();

        // Then
        assertNotNull(retryTemplate);
        // RetryTemplate is created with default settings
        // Default retry policy and backoff policy will be used
    }
}

