package com.hireright.sourceintelligence.event;

import lombok.Getter;
import org.springframework.context.ApplicationEvent;

import java.util.List;
import java.util.Map;

/**
 * Event published when data extraction is completed
 * Following Observer Pattern - event represents a state change in the system
 */
@Getter
public class DataExtractionEvent extends ApplicationEvent {
    
    private final String dataExtractionType;
    private final String filename;
    private final Integer totalRecords;
    private final Integer totalSourcesUpdated;
    private final Integer notFoundRecords;
    private final Long processingTimeMs;
    private final List<Map<String, Object>> notFoundRecordsData;
    private final String status;
    
    public DataExtractionEvent(
            Object source,
            String dataExtractionType,
            String filename,
            Integer totalRecords,
            Integer totalSourcesUpdated,
            Integer notFoundRecords,
            Long processingTimeMs,
            List<Map<String, Object>> notFoundRecordsData,
            String status) {
        super(source);
        this.dataExtractionType = dataExtractionType;
        this.filename = filename;
        this.totalRecords = totalRecords;
        this.totalSourcesUpdated = totalSourcesUpdated;
        this.notFoundRecords = notFoundRecords;
        this.processingTimeMs = processingTimeMs;
        this.notFoundRecordsData = notFoundRecordsData;
        this.status = status;
    }
    
    public boolean isSuccessful() {
        return "SUCCESS".equalsIgnoreCase(status);
    }
}

