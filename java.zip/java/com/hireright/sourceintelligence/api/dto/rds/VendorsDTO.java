package com.hireright.sourceintelligence.api.dto.rds;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class VendorsDTO {
    @JsonProperty("providerID")
    private int providerId;
    private String vendor;
    private String website;
    private String organizationType;
}
