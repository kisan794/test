package com.hireright.sourceintelligence.domain.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum SourceOrganizationStatus {
    ACTIVE("ACTIVE"), INACTIVE("INACTIVE");

    private final String status;

    SourceOrganizationStatus(String status) {
        this.status = status;
    }

    @JsonCreator
    public static SourceOrganizationStatus fromString(String status) {
        return status == null ? null : SourceOrganizationStatus.valueOf(status.toUpperCase());
    }

    @Override
    public String toString() {
        return status;
    }

    @JsonValue
    public String getStatus() {
        return this.status.toUpperCase();
    }
}
