package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.Alias;
import com.hireright.sourceintelligence.api.dto.SourceDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.service.impl.SearchConstants;
import com.hireright.sourceintelligence.util.TestDataProvider;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class SourceDTOMapperTest {

    private SourceDTOMapper sourceDTOMapper;

    @BeforeEach
    void setUp() {
        sourceDTOMapper = Mappers.getMapper(SourceDTOMapper.class);
    }

    @Test
    void toSourceDTO_shouldMapAllSimpleFields() {

        Source source = TestDataProvider.getSourceOrganizationEntity();
        source.setHon("HON001");
        source.setOrganizationName("Test Org");
        source.setCountry("US");
        source.setState("CA");
        source.setCity("LA");
        source.setPostalCode("90001");
        source.setStatus(SourceOrganizationStatus.ACTIVE);


        SourceDTO dto = sourceDTOMapper.toSourceDTO(source);


        assertThat(dto).isNotNull();
        assertThat(dto.getHon()).isEqualTo("HON001");
        assertThat(dto.getOrganizationName()).isEqualTo("Test Org");
        assertThat(dto.getCountry()).isEqualTo("US");
        assertThat(dto.getState()).isEqualTo("CA");
        assertThat(dto.getCity()).isEqualTo("LA");
        assertThat(dto.getPostalCode()).isEqualTo("90001");
    }

    @Test
    void toSourceDTO_shouldHandleNullPayload() {
        Source source = new Source();
        source.setId(new ObjectId());
        source.setOrganizationName("Org with null payload");
        SourceDTO dto = sourceDTOMapper.toSourceDTO(source);

        assertThat(dto).isNotNull();
        assertThat(dto.getOrganizationName()).isEqualTo("Org with null payload");
        assertThat(dto.getDepartmentName()).isEmpty();
    }

    @Test
    void entityToSourceList_shouldReturnMappedList() {

        List<Source> sourceList = TestDataProvider.getSourceOrganizationList();
        sourceList.forEach(source -> {
            if (source.getId() == null) {
                source.setId(new ObjectId());
            }
        });

        List<SourceDTO> dtoList = sourceDTOMapper.entityToSourceList(sourceList);

        assertThat(dtoList)
                .isNotNull()
                .hasSameSizeAs(sourceList);
    }

    @Test
    void helpers_shouldHandlePayloadField_andStripHtml() {
        Source src = new Source();
        src.setPayload(BasicDBObject.parse("""
      { "notes": "<b>Hi</b>&nbsp;there", "additionalInfo":[{}], "address":[{}] }
    """));

        assertThat(sourceDTOMapper.getPayloadField(src, "notes")).isEqualTo("<b>Hi</b>&nbsp;there");
        assertThat(sourceDTOMapper.stripHtmlTags(sourceDTOMapper.getPayloadField(src, "notes")))
                .isEqualTo("Hi there");


        assertThat(sourceDTOMapper.getPayloadField(src, "missing")).isEmpty();


        Source empty = new Source();
        assertThat(sourceDTOMapper.getPayloadField(empty, "anything")).isEmpty();
    }

    @Test
    void mapUsedCount_shouldReturnValueOrZero() {
        Source with = new Source();
        with.setPayload(BasicDBObject.parse("""
        {
          "usedCount": 5,
          "additionalInfo": [{}],
          "address": [{}]
        }
        """));
        assertThat(sourceDTOMapper.mapUsedCount(with)).isEqualTo(5);

        Source without = new Source();
        with.setPayload(BasicDBObject.parse("""
        {
          "additionalInfo": [{}],
          "address": [{}]
        }
        """));
        assertThat(sourceDTOMapper.mapUsedCount(without)).isZero();
    }


    @Test
    void mapOrganizationAlias_shouldJoinNamesOrReturnNull() {
        assertThat(sourceDTOMapper.mapOrganizationAlias(null)).isNull();

        Alias a1 = new Alias(); a1.setName("One");
        Alias a2 = new Alias(); a2.setName("Two");
        assertThat(sourceDTOMapper.mapOrganizationAlias(new Alias[]{a1, a2}))
                .isEqualTo("One; Two");
    }

    @Test
    void mapDepartmentAlias_shouldReturnFirstNameOrEmpty() {
        Source src = new Source();
        src.setPayload(BasicDBObject.parse("""
        {
          "departmentAliases": [{ "name": "Legal" }],
          "additionalInfo": [{}],
          "address": [{}]
        }
        """));
        assertThat(sourceDTOMapper.mapDepartmentAlias(src)).isEqualTo("Legal");

        Source missing = new Source();
        missing.setPayload(BasicDBObject.parse("""
        {
          "additionalInfo": [{}],
          "address": [{}]
        }
        """));
        assertThat(sourceDTOMapper.mapDepartmentAlias(missing)).isEmpty();
    }


    @Test
    void getAdditionalInfo_shouldReturnValueOrEmpty() {
        Source src = new Source();
        src.setPayload(BasicDBObject.parse(
                "{ \"addionalInfo\": [{ \"releaseType\": \"Internal\", \"doNotContact\": \"false\" }], \"address\": [{}] }"
        ));

        assertThat(sourceDTOMapper.getAdditionalInfo(src, "releaseType")).isEqualTo("Internal");
        assertThat(sourceDTOMapper.getAdditionalInfo(src, "nope")).isEmpty();
    }


    @Test
    void getAddressLine_shouldSkipEmptyParts() {
        Source src = new Source();
        src.setCity("");
        src.setState(null);
        src.setCountry("US");

        src.setPayload(BasicDBObject.parse("""
        {
          "address": [{ "line": "", "postalCode": "" }]
        }
        """));

        assertThat(sourceDTOMapper.getAddressLine(src)).isEqualTo("US");
    }

    @Test
    void relationshipHelpers_shouldExtractOrReturnEmpty() {
        Source src = new Source();
        src.setPayload(BasicDBObject.parse("""
        {
          "relationships": [{ "relationship": "Partner", "name": "ACME" }],
          "additionalInfo": [{}],
          "address": [{}]
        }
        """));
        assertThat(sourceDTOMapper.getRelationship(src)).isEqualTo("Partner");
        assertThat(sourceDTOMapper.getRelationshipName(src)).isEqualTo("ACME");

        Source missing = new Source();
        missing.setPayload(BasicDBObject.parse("""
        {
          "relationships": [],
          "additionalInfo": [{}],
          "address": [{}]
        }
        """));
        assertThat(sourceDTOMapper.getRelationship(missing)).isEmpty();
        assertThat(sourceDTOMapper.getRelationshipName(missing)).isEmpty();
    }


    @Test
    void getLastModifiedDate_shouldBeNullForCreateElsePassthrough() {
        Source create = new Source();

        create.setAction(SearchConstants.ReportActions.CREATE);
        create.setLastModifiedDate(java.time.Instant.now());
        assertThat(sourceDTOMapper.getLastModifiedDate(create, "ignored")).isNull();

        Source update = new Source();
        java.time.Instant ts = java.time.Instant.now();
        update.setAction("UPDATE");
        update.setLastModifiedDate(ts);
        assertThat(sourceDTOMapper.getLastModifiedDate(update, "ignored")).isEqualTo(ts);
    }


    @Test
    void mapContactDetails_shouldParseMultipleTypesAndRespectPriority() {
        Source src = new Source();
        src.setPayload(BasicDBObject.parse(
                "{ " +
                        "  \"addionalInfo\": [{\"doNotContact\":\"false\"}]," +
                        "  \"contacts\": [{" +
                        "    \"contactDetails\": [" +
                        "      {" +
                        "        \"type\": \"contactPhones\"," +
                        "        \"priority\": \"2\"," +
                        "        \"communication\": [{" +
                        "          \"communicationInfo\": [" +
                        "            {\"type\": \"phoneNumber\", \"value\": \"1234567\"}," +
                        "            {\"type\": \"extension\", \"value\": \"ext. 89\"}," +
                        "            {\"type\": \"phoneCountryCode\", \"value\": \"+1\"}," +
                        "            {\"type\": \"areaCode\", \"value\": \"212\"}" +
                        "          ]" +
                        "        }]" +
                        "      }," +
                        "      {" +
                        "        \"type\": \"contactEmails\"," +
                        "        \"priority\": 1," +
                        "        \"communication\": [{" +
                        "          \"communicationInfo\": [" +
                        "            {\"type\": \"address\", \"value\": \"a@b.com\"}" +
                        "          ]" +
                        "        }]" +
                        "      }," +
                        "      {" +
                        "        \"type\": \"contactWebsites\"," +
                        "        \"priority\": 3," +
                        "        \"communication\": [{" +
                        "          \"communicationInfo\": [" +
                        "            {\"type\": \"addresses\", \"value\": \"https://acme.com\"}" +
                        "          ]" +
                        "        }]" +
                        "      }," +
                        "      {" +
                        "        \"type\": \"contactMails\"," +
                        "        \"priority\": 4," +
                        "        \"communication\": [{" +
                        "          \"communicationInfo\": [" +
                        "            {\"type\": \"address\", \"value\": \"10 Downing St\"}" +
                        "          ]" +
                        "        }]" +
                        "      }" +
                        "    ]" +
                        "  }]," +
                        "  \"address\": [{}]" +
                        "}"
        ));

        var list = sourceDTOMapper.mapContactDetails(src);

        assertThat(list).hasSize(4);
        assertThat(list.get(0).getType()).contains("Emails");
        assertThat(list.get(0).getEmails()).containsExactly("a@b.com");
        assertThat(list.get(1).getType()).contains("Phones");
        assertThat(list.get(1).getNumbers()).isNotEmpty();
        assertThat(list.get(1).getNumbers().get(0)).contains("+1", "212", "1234567", "ext. 89");
        assertThat(list.get(2).getType()).contains("Websites");
        assertThat(list.get(2).getWebsites()).contains("https://acme.com");
        assertThat(list.get(3).getType()).contains("Mails");
        assertThat(list.get(3).getMailAddresses()).contains("10 Downing St");
    }


    @Test
    void mapContactDetails_shouldRespectDoNotContactAndAutomatedServiceExtras() {
        Source src = new Source();
        src.setPayload(BasicDBObject.parse("""
      {
        "addionalInfo":[{ "doNotContact":"true" }],
        "contacts":[{
          "contactDetails":[
            {
              "type":"contactAutomatedServices",
              "priority": 1,
              "communication":[{
                "name":"ProviderX",
                "communicationInfo":[
                  { "type":"codes",                    "value":"PX" },
                  { "type":"branch",                   "value":"NYC" },
                  { "type":"turnAroundTime",           "value":"3"   },
                  { "type":"followUpAllowed",          "value":"true" },
                  { "type":"followUpAllowedAfter",     "value":"2"   },
                  { "type":"surChargeAmount",          "value":"10"  },
                  { "type":"surChargeCurrency",        "value":"USD" },
                  { "type":"paymentMethod",            "value":"Card" }
                ]
              }]
            }
          ]
        }],
        "address":[{}]
      }
    """));

        var list = sourceDTOMapper.mapContactDetails(src);
        assertThat(list).hasSize(1);

        var c = list.get(0);
        assertThat(c.getType()).contains("AutomatedServices");
        assertThat(c.getProvider()).isEqualTo("ProviderX");
        assertThat(c.getCode()).isEqualTo("PX");
        assertThat(c.getBranch()).isEqualTo("NYC");
        assertThat(c.getTurnAroundTime()).isEqualTo("3 days");
        assertThat(c.getFollowUpAllowedAfter()).isEqualTo("2 days");
        assertThat(c.getSurcharge()).isEqualTo("10 USD");
        assertThat(c.getPaymentMethod()).isEqualTo("Card");
    }


    @Test
    void entityToSourceList_shouldReturnEmptyForEmptyInput() {
        List<Source> emptyList = List.of();
        List<SourceDTO> dtoList = sourceDTOMapper.entityToSourceList(emptyList);
        assertThat(dtoList).isEmpty();
    }

    @Test
    void toSourceDTO_shouldStripHtmlFromNotes() {
        Source source = new Source();
        source.setId(new ObjectId());
        source.setOrganizationName("Test Org");

        String payloadWithHtmlNotes = """
            {
              "notes": "<p>Some HTML&nbsp;Notes</p>",
              "additionalInfo": [{}],
              "address": [{}]
            }
            """;

        DBObject payloadDBObject = BasicDBObject.parse(payloadWithHtmlNotes);
        source.setPayload(payloadDBObject);

        SourceDTO dto = sourceDTOMapper.toSourceDTO(source);

        assertThat(dto).isNotNull();
        assertThat(dto.getNotes()).isEqualTo("Some HTML Notes");
    }

    @Test
    void toSourceDTO_shouldMapUsedCount() {
        Source source = new Source();
        source.setId(new ObjectId());

        source.setPayload(BasicDBObject.parse("""
                {
                  "usedCount": 42,
                  "additionalInfo": [{}],
                  "address": [{}]
                }
            """));

        SourceDTO dto = sourceDTOMapper.toSourceDTO(source);

        assertThat(dto).isNotNull();
        assertThat(dto.getUsedCount()).isEqualTo(42);
    }

    @Test
    void toSourceDTO_shouldIgnoreRelationshipInfo() {
        Source source = new Source();
        source.setId(new ObjectId());

        source.setPayload(BasicDBObject.parse("""
      {
        "relationships": [{
          "relationship": "Partner",
          "name": "ABC Corp"
        }],
        "additionalInfo": [{}],
        "address": [{}]
      }
      """));

        SourceDTO dto = sourceDTOMapper.toSourceDTO(source);

        assertThat(dto).isNotNull();
        assertThat(dto.getAddress()).isEmpty();
        assertThat(dto.getContactDetails()).isEmpty();
        assertThat(dto.getUsedCount()).isZero();
    }


    @Test
    void toSourceDTO_shouldMapOrganizationAlias() {
        Source source = new Source();
        source.setId(new ObjectId());

        com.hireright.sourceintelligence.api.dto.Alias alias =
                new com.hireright.sourceintelligence.api.dto.Alias();
        alias.setName("AliasOne");
        source.setOrganizationAlias(new com.hireright.sourceintelligence.api.dto.Alias[]{alias});

        SourceDTO dto = sourceDTOMapper.toSourceDTO(source);

        assertThat(dto).isNotNull();
        assertThat(dto.getOrganizationAlias()).contains("AliasOne");
    }

    @Test
    void toSourceDTO_shouldMapUsedCountCorrectly() {
        Source source = new Source();
        source.setId(new ObjectId());

        String payload = """
    {
      "usedCount": 77,
      "additionalInfo": [{}]
    }
    """;

        source.setPayload(BasicDBObject.parse(payload));

        SourceDTO dto = sourceDTOMapper.toSourceDTO(source);

        assertThat(dto).isNotNull();
        assertThat(dto.getUsedCount()).isEqualTo(77);
    }

    @Test
    void toSourceDTO_shouldMapAddressLineFromPayload() {
        Source source = new Source();
        source.setId(new ObjectId());

        source.setCity("New York");
        source.setState("NY");
        source.setCountry("USA");

        String payload = """
    {
      "address": [{
        "line": "221B Baker Street",
        "postalCode": "10001"
      }],
      "additionalInfo": [{}]
    }
    """;

        source.setPayload(BasicDBObject.parse(payload));

        SourceDTO dto = sourceDTOMapper.toSourceDTO(source);

        assertThat(dto).isNotNull();
        assertThat(dto.getAddress())
                .contains("221B Baker Street", "10001", "New York", "NY", "USA");
    }

    @Test
    void toSourceDTO_shouldIgnoreRelationshipAndName() {
        Source source = new Source();
        source.setId(new ObjectId());

        String payload = """
    {
      "relationships": [{
        "relationship": "Subsidiary",
        "name": "ABC Group"
      }],
      "additionalInfo": [{}],
      "address": [{}]
    }
    """;

        source.setPayload(BasicDBObject.parse(payload));

        SourceDTO dto = sourceDTOMapper.toSourceDTO(source);

        assertThat(dto).isNotNull();
        assertThat(dto.getAddress()).isEmpty();
        assertThat(dto.getContactDetails()).isEmpty();
        assertThat(dto.getUsedCount()).isZero();
        assertThat(dto.getNotes()).isEmpty();
    }


    @Test
    void toSourceDTO_shouldMapOrganizationAliasFromAliasArray() {
        Source source = new Source();
        source.setId(new ObjectId());

        Alias alias1 = new Alias();
        alias1.setName("AliasOne");

        Alias alias2 = new Alias();
        alias2.setName("AliasTwo");

        source.setOrganizationAlias(new Alias[]{alias1, alias2});

        SourceDTO dto = sourceDTOMapper.toSourceDTO(source);

        assertThat(dto).isNotNull();
        assertThat(dto.getOrganizationAlias()).isEqualTo("AliasOne; AliasTwo");
    }

}
