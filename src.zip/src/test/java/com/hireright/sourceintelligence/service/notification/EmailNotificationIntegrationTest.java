package com.hireright.sourceintelligence.service.notification;

import com.hireright.sourceintelligence.api.dto.notification.*;
import com.hireright.sourceintelligence.exception.EmailValidationException;
import com.hireright.sourceintelligence.service.notification.impl.EmailNotificationServiceImpl;
import com.hireright.sourceintelligence.service.notification.provider.EmailNotificationProvider;
import com.hireright.sourceintelligence.service.notification.util.EmailSanitizer;
import com.hireright.sourceintelligence.service.notification.validator.AttachmentValidator;
import com.hireright.sourceintelligence.service.notification.validator.EmailValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Base64;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Integration tests for Email Notification System.
 * Tests the complete flow from validation to sending.
 */
@ExtendWith(MockitoExtension.class)
class EmailNotificationIntegrationTest {
    
    @Mock
    private EmailNotificationProvider emailProvider;
    
    private EmailValidator emailValidator;
    private AttachmentValidator attachmentValidator;
    private EmailSanitizer emailSanitizer;
    private EmailNotificationService emailNotificationService;
    
    @BeforeEach
    void setUp() {
        emailValidator = new EmailValidator();
        attachmentValidator = new AttachmentValidator();
        emailSanitizer = new EmailSanitizer();
        
        // Set validation properties via reflection (in real app, these come from application.properties)
        setValidatorProperty(emailValidator, "strictValidation", false);
        setValidatorProperty(emailValidator, "maxSubjectLength", 200);
        setValidatorProperty(emailValidator, "maxBodyLength", 1048576);
        setValidatorProperty(emailValidator, "maxRecipients", 100);
        setValidatorProperty(emailValidator, "domainWhitelist", "");
        setValidatorProperty(emailValidator, "domainBlacklist", "");
        
        setValidatorProperty(attachmentValidator, "maxAttachmentSize", 26214400L);
        setValidatorProperty(attachmentValidator, "maxAttachmentCount", 10);
        
        emailNotificationService = new EmailNotificationServiceImpl(
                emailValidator,
                attachmentValidator,
                emailProvider,
                emailSanitizer
        );
    }
    
    @Test
    void testSendEmail_Success() {
        // Arrange
        EmailNotificationDTO emailDTO = EmailNotificationDTO.builder()
                .to(List.of("test@example.com"))
                .subject("Test Email")
                .body("This is a test email")
                .htmlContent(false)
                .build();
        
        doNothing().when(emailProvider).sendEmail(any());
        
        // Act
        String notificationId = emailNotificationService.sendEmail(emailDTO);
        
        // Assert
        assertNotNull(notificationId);
        verify(emailProvider, times(1)).sendEmail(any());
    }
    
    @Test
    void testSendEmail_WithAttachment_Success() {
        // Arrange
        String fileContent = "Test file content";
        String base64Content = Base64.getEncoder().encodeToString(fileContent.getBytes());
        
        AttachmentDTO attachment = AttachmentDTO.builder()
                .filename("test.txt")
                .content(base64Content)
                .contentType("text/plain")
                .build();
        
        EmailNotificationDTO emailDTO = EmailNotificationDTO.builder()
                .to(List.of("test@example.com"))
                .subject("Email with Attachment")
                .body("Please see attached file")
                .htmlContent(false)
                .attachments(List.of(attachment))
                .build();
        
        doNothing().when(emailProvider).sendEmail(any());
        
        // Act
        String notificationId = emailNotificationService.sendEmail(emailDTO);
        
        // Assert
        assertNotNull(notificationId);
        verify(emailProvider, times(1)).sendEmail(any());
    }
    
    @Test
    void testSendEmail_WithCcBcc_Success() {
        // Arrange
        EmailNotificationDTO emailDTO = EmailNotificationDTO.builder()
                .to(List.of("recipient@example.com"))
                .cc(List.of("cc@example.com"))
                .bcc(List.of("bcc@example.com"))
                .subject("Test Email")
                .body("Test body")
                .htmlContent(false)
                .build();
        
        doNothing().when(emailProvider).sendEmail(any());
        
        // Act
        String notificationId = emailNotificationService.sendEmail(emailDTO);
        
        // Assert
        assertNotNull(notificationId);
        verify(emailProvider, times(1)).sendEmail(any());
    }
    
    @Test
    void testSendEmail_InvalidEmail_ThrowsException() {
        // Arrange
        EmailNotificationDTO emailDTO = EmailNotificationDTO.builder()
                .to(List.of("invalid-email"))
                .subject("Test")
                .body("Test")
                .build();
        
        // Act & Assert
        assertThrows(EmailValidationException.class, () -> {
            emailNotificationService.sendEmail(emailDTO);
        });
        
        verify(emailProvider, never()).sendEmail(any());
    }
    
    @Test
    void testSendEmail_EmptyRecipients_ThrowsException() {
        // Arrange
        EmailNotificationDTO emailDTO = EmailNotificationDTO.builder()
                .to(List.of())
                .subject("Test")
                .body("Test")
                .build();
        
        // Act & Assert
        assertThrows(EmailValidationException.class, () -> {
            emailNotificationService.sendEmail(emailDTO);
        });
    }
    
    @Test
    void testSendEmail_SubjectTooLong_ThrowsException() {
        // Arrange
        String longSubject = "a".repeat(201);
        EmailNotificationDTO emailDTO = EmailNotificationDTO.builder()
                .to(List.of("test@example.com"))
                .subject(longSubject)
                .body("Test")
                .build();
        
        // Act & Assert
        assertThrows(EmailValidationException.class, () -> {
            emailNotificationService.sendEmail(emailDTO);
        });
    }
    
    @Test
    void testSendEmail_XssSanitization() {
        // Arrange
        String maliciousHtml = "<html><body><script>alert('XSS')</script><p>Content</p></body></html>";
        EmailNotificationDTO emailDTO = EmailNotificationDTO.builder()
                .to(List.of("test@example.com"))
                .subject("Test")
                .body(maliciousHtml)
                .htmlContent(true)
                .build();
        
        doNothing().when(emailProvider).sendEmail(any());
        
        // Act
        String notificationId = emailNotificationService.sendEmail(emailDTO);
        
        // Assert
        assertNotNull(notificationId);
        // Verify sanitization removed script tag
        assertFalse(emailDTO.getBody().contains("<script>"));
        verify(emailProvider, times(1)).sendEmail(any());
    }
    
    @Test
    void testSendEmail_InvalidAttachment_ThrowsException() {
        // Arrange
        AttachmentDTO attachment = AttachmentDTO.builder()
                .filename("test.txt")
                .content("not-base64-content!")
                .contentType("text/plain")
                .build();
        
        EmailNotificationDTO emailDTO = EmailNotificationDTO.builder()
                .to(List.of("test@example.com"))
                .subject("Test")
                .body("Test")
                .attachments(List.of(attachment))
                .build();
        
        // Act & Assert
        assertThrows(EmailValidationException.class, () -> {
            emailNotificationService.sendEmail(emailDTO);
        });
    }
    
    @Test
    void testSendEmail_TooManyAttachments_ThrowsException() {
        // Arrange
        String base64Content = Base64.getEncoder().encodeToString("test".getBytes());
        List<AttachmentDTO> attachments = Arrays.asList(
                createAttachment("file1.txt", base64Content),
                createAttachment("file2.txt", base64Content),
                createAttachment("file3.txt", base64Content),
                createAttachment("file4.txt", base64Content),
                createAttachment("file5.txt", base64Content),
                createAttachment("file6.txt", base64Content),
                createAttachment("file7.txt", base64Content),
                createAttachment("file8.txt", base64Content),
                createAttachment("file9.txt", base64Content),
                createAttachment("file10.txt", base64Content),
                createAttachment("file11.txt", base64Content)
        );
        
        EmailNotificationDTO emailDTO = EmailNotificationDTO.builder()
                .to(List.of("test@example.com"))
                .subject("Test")
                .body("Test")
                .attachments(attachments)
                .build();
        
        // Act & Assert
        assertThrows(EmailValidationException.class, () -> {
            emailNotificationService.sendEmail(emailDTO);
        });
    }
    
    private AttachmentDTO createAttachment(String filename, String content) {
        return AttachmentDTO.builder()
                .filename(filename)
                .content(content)
                .contentType("text/plain")
                .build();
    }
    
    private void setValidatorProperty(Object validator, String fieldName, Object value) {
        try {
            var field = validator.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(validator, value);
        } catch (Exception e) {
            // Ignore - using default values
        }
    }
}

