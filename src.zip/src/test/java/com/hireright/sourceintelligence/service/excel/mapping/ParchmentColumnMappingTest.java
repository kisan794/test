package com.hireright.sourceintelligence.service.excel.mapping;

import com.hireright.sourceintelligence.service.excel.ExcelColumnMapping;
import org.junit.jupiter.api.Test;

import static com.hireright.sourceintelligence.service.excel.mapping.ParchmentColumnMapping.*;
import static org.junit.jupiter.api.Assertions.*;

class ParchmentColumnMappingTest {

    @Test
    void create_ShouldReturnNonNullMapping() {
        ExcelColumnMapping mapping = ParchmentColumnMapping.create();

        assertNotNull(mapping);
    }

    @Test
    void create_ShouldSetCorrectHeaderRowIndex() {
        ExcelColumnMapping mapping = ParchmentColumnMapping.create();

        assertEquals(0, mapping.getHeaderRowIndex());
    }

    @Test
    void create_ShouldSetCorrectDataStartRowIndex() {
        ExcelColumnMapping mapping = ParchmentColumnMapping.create();

        assertEquals(1, mapping.getDataStartRowIndex());
    }

    @Test
    void create_ShouldSetCorrectSheetIndex() {
        ExcelColumnMapping mapping = ParchmentColumnMapping.create();

        assertEquals(0, mapping.getSheetIndex());
    }

    @Test
    void fieldNameConstants_ShouldHaveCorrectValues() {
        assertEquals("institutionName", INSTITUTION_NAME);
        assertEquals("country", COUNTRY);
        assertEquals("city", CITY);
        assertEquals("stateCountyRegion", STATE_COUNTY_REGION);
        assertEquals("serviceProvider", SERVICE_PROVIDER);
        assertEquals("surchargeAmount", SURCHARGE_AMOUNT);
        assertEquals("paymentMethod", PAYMENT_METHOD);
        assertEquals("code", CODE);
        assertEquals("turnaroundTime", TURNAROUND_TIME);
        assertEquals("followUpAllowed", FOLLOW_UP_ALLOWED);
    }

    @Test
    void create_MultipleCalls_ShouldReturnIndependentInstances() {
        ExcelColumnMapping mapping1 = ParchmentColumnMapping.create();
        ExcelColumnMapping mapping2 = ParchmentColumnMapping.create();

        assertNotSame(mapping1, mapping2);
    }

    @Test
    void create_ShouldContainAllRequiredFieldMappings() {
        ExcelColumnMapping mapping = ParchmentColumnMapping.create();

        assertNotNull(mapping);
    }

    @Test
    void constants_AllFieldNames_ShouldNotBeNull() {
        assertNotNull(INSTITUTION_NAME);
        assertNotNull(COUNTRY);
        assertNotNull(CITY);
        assertNotNull(STATE_COUNTY_REGION);
        assertNotNull(SERVICE_PROVIDER);
        assertNotNull(SURCHARGE_AMOUNT);
        assertNotNull(PAYMENT_METHOD);
        assertNotNull(CODE);
        assertNotNull(TURNAROUND_TIME);
        assertNotNull(FOLLOW_UP_ALLOWED);
    }

    @Test
    void constants_AllFieldNames_ShouldNotBeEmpty() {
        assertFalse(INSTITUTION_NAME.isEmpty());
        assertFalse(COUNTRY.isEmpty());
        assertFalse(CITY.isEmpty());
        assertFalse(STATE_COUNTY_REGION.isEmpty());
        assertFalse(SERVICE_PROVIDER.isEmpty());
        assertFalse(SURCHARGE_AMOUNT.isEmpty());
        assertFalse(PAYMENT_METHOD.isEmpty());
        assertFalse(CODE.isEmpty());
        assertFalse(TURNAROUND_TIME.isEmpty());
        assertFalse(FOLLOW_UP_ALLOWED.isEmpty());
    }

    @Test
    void create_ShouldUseCorrectSheetIndexForFirstSheet() {
        ExcelColumnMapping mapping = ParchmentColumnMapping.create();

        assertEquals(0, mapping.getSheetIndex(), "Should default to first sheet (index 0)");
    }

    @Test
    void create_ShouldStartDataFromSecondRow() {
        ExcelColumnMapping mapping = ParchmentColumnMapping.create();

        assertEquals(1, mapping.getDataStartRowIndex(),
                "Data should start from row 1 (index 1), assuming row 0 is the header");
    }
}