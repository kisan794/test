package com.hireright.sourceintelligence.reports.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReviewerReportDTO {
    
    @JsonProperty("Researcher_Name")
    private String researcherName;
    
    @JsonProperty("New")
    private int newCount;
    
    @JsonProperty("In_Progress")
    private int inProgress;
    
    @JsonProperty("On_Hold")
    private int onHold;
    
    @JsonProperty("Cancelled")
    private int cancelled;
    
    @JsonProperty("Completed")
    private int completed;
}