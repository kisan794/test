package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsonorg.JSONArrayDeserializer;
import com.fasterxml.jackson.datatype.jsonorg.JSONArraySerializer;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.json.JSONArray;

//import javax.validation.constraints.NotNull;
import jakarta.validation.constraints.NotNull;


@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value = JsonInclude.Include.NON_EMPTY, content = JsonInclude.Include.NON_NULL)
public class AddressDTO {
    @NotNull
    private String hon;
    @NotNull
    @JsonSerialize(using = JSONArraySerializer.class)
    @JsonDeserialize(using = JSONArrayDeserializer.class)
    private JSONArray address;
}
