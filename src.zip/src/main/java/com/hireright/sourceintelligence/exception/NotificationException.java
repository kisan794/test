package com.hireright.sourceintelligence.exception;

/**
 * Base exception for all notification-related errors.
 * Follows Single Responsibility Principle.
 */
public class NotificationException extends RuntimeException {
    
    private final String errorCode;
    private final String field;
    
    public NotificationException(String message) {
        super(message);
        this.errorCode = "NOTIFICATION_ERROR";
        this.field = null;
    }
    
    public NotificationException(String message, Throwable cause) {
        super(message, cause);
        this.errorCode = "NOTIFICATION_ERROR";
        this.field = null;
    }
    
    public NotificationException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
        this.field = null;
    }
    
    public NotificationException(String message, String errorCode, String field) {
        super(message);
        this.errorCode = errorCode;
        this.field = field;
    }
    
    public NotificationException(String message, String errorCode, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        this.field = null;
    }
    
    public String getErrorCode() {
        return errorCode;
    }
    
    public String getField() {
        return field;
    }
}

