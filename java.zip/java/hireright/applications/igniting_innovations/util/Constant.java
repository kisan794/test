package hireright.applications.igniting_innovations.util;

public final class Constant {

    public static final String TITLE = "Igniting Innovations Service";
    public static final String VERSION = "1.0";
    public static final String DESCRIPTION = "REST API for Igniting Innovations - Idea Submission and Management Service";
    public static final String HEALTH = "/health";
    public static final String IGNITINGINNOVATION_SERVICE = "/ignitinginnovation-service";
    public static final String HEALTH_CHECK = "Up and running!";

    private Constant() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

}
