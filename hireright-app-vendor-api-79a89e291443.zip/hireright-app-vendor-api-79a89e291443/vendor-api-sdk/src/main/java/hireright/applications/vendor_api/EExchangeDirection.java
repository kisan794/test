
package hireright.applications.vendor_api;
/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-09-06	Created
 *	M.Kuznetsov	2025-10-29	HRG-345322. Openjdk21-migration
 */
public enum EExchangeDirection {
    HOST_TO_VENDOR,
    VENDOR_TO_HOST;

    public static final String PROPERTY_NAME = "EXCHANGE_DIRECTION";
    public static final String PARAMETER_NAME = "exchangeDirection";
}
