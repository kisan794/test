package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import org.bson.types.ObjectId;
import org.json.*;
import org.mapstruct.*;
import org.mapstruct.NullValueCheckStrategy;

import java.util.List;

import static org.mapstruct.ReportingPolicy.IGNORE;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        unmappedTargetPolicy = IGNORE)
public interface SourceMapper {

    @Named("mapToDBObject")
    static DBObject mapToDBObject(JSONObject payload) {
        return BasicDBObject.parse(payload.toString());
    }

    @Named("mapToJSONObject")
    static JSONObject mapToJSONObject(DBObject payload) throws JSONException {
        return new JSONObject((payload.toString()));
    }

    default ObjectId map(String id) {
        return id != null ? new ObjectId(id) : null;
    }

    default String mapId(ObjectId id){
        return id != null ? id.toHexString() : null;
    }

    List<SourceOrganizationDTO> toSourceDTOList(List<Source> entityList);

    @Mapping(source = "payload", target = "payload", qualifiedByName = "mapToDBObject")
    @Mapping(source="id", target = "id")
    Source dtoToEntitySource(SourceOrganizationDTO dto);

    @Mapping(source = "payload", target = "payload", qualifiedByName = "mapToJSONObject")
    @Mapping(target = "id", expression = "java(mapId(entity.getId()))")
    SourceOrganizationDTO entitySourceToDTO(Source entity);


}
