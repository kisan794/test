/*
 * @(#)$RCSfile: CParameterBean.java,v $ $Revision: 1.2 $ $Date: 2014/07/28 14:57:07 $ $Author: aputintsev $ $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/types/CParameterBean.java,v $
 *
 * History:
 *     $Log: CParameterBean.java,v $
 *     Revision 1.2  2014/07/28 14:57:07  aputintsev
 *     forked from production version - projects_src/applications/accesspoint
 *
 *     Revision 1.1.2.1  2009/08/13 13:24:23  asolntsev
 *     Created by St.Petersburg team
 *
 *     Revision 1.1.1.1  2009/07/31 11:24:26  banton
 *     Task 39986 1.1
 *
 *     Revision 1.3  2009/07/27 14:29:43  banton
 *     Fixed user exceptions
 *
 *     Revision 1.2  2009/07/23 11:31:44  banton
 *     Added some sources decorations
 *
 */

package hireright.applications.accesspoint.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;

/**
 *
 * @author banton
 */

@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(
    name = "ParameterBeanType",
    namespace = "http://hireright.com/applications/accesspoint/types"
)
public class CParameterBean
{
    String name;
    String value;

    @XmlAttribute
    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    @XmlValue
    public String getValue()
    {
        return value;
    }

    public void setValue(String value)
    {
        this.value = value;
    }


}
