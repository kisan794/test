package com.hireright.sourceintelligence.service.impl.helperservices;

import com.hireright.sourceintelligence.api.dto.UIActionsDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.service.impl.MongoSourceService;
import com.hireright.sourceintelligence.service.impl.SearchConstants;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import com.hireright.sourceintelligence.util.Helper;
import com.hireright.sourceintelligence.util.LoggingThrowable;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import java.time.Instant;
import java.util.Collections;
import java.util.List;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.DELETE;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.SIDB_ORIGIN;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.SOURCE_COLLECTION_SUFFIX;
import static com.hireright.sourceintelligence.constants.ErrorConstants.SOURCE_NOT_FOUND;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.APPROVED;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.IN_PROGRESS;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.ONHOLD;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.PENDING_APPROVAL;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.REJECTED;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.SAVE_PENDING_APPROVAL;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ArchiveSourceServiceTest {

    @Mock
    private MongoSourceService mongoSourceService;

    @Mock
    private ReportDataUtils reportDataUtils;

    @Mock
    private ElasticsearchService elasticsearchService;

    @InjectMocks
    private ArchiveSourceService archiveSourceService;

    @Test
    void archiveSource_shouldArchiveAndDeletePendingSources() throws Exception {
        String hon = "EMPLOYMENT";
        String collectionName = "employment_source";

        UIActionsDTO uiActionsDTO = new UIActionsDTO();
        uiActionsDTO.setUserName("qa.user");
        uiActionsDTO.setUserEmail("qa.user@test.com");

        Source approvedSource = new Source();
        approvedSource.setHon(hon);
        approvedSource.setVersion(1.0);
        approvedSource.setTempVersion(2.0);

        Source pendingSource = new Source();
        pendingSource.setHon(hon);

        when(mongoSourceService.findSourceByHonAndApprovalStatus(hon, APPROVED)).thenReturn(approvedSource);
        when(mongoSourceService.getSourceListByHonAndApprovalStatuses(eq(hon), anyList()))
                .thenReturn(List.of(pendingSource));
        when(mongoSourceService.updateByIdWithCustomFields(any(Query.class), any(Update.class), eq(collectionName)))
                .thenReturn(true);

        try (MockedStatic<Helper> helperMock = mockStatic(Helper.class)) {
            helperMock.when(() -> Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX)).thenReturn(collectionName);

            boolean result = archiveSourceService.archiveSource(hon, uiActionsDTO);

            assertTrue(result);

            verify(mongoSourceService).findSourceByHonAndApprovalStatus(hon, APPROVED);

            ArgumentCaptor<List<String>> statusCaptor = ArgumentCaptor.forClass(List.class);
            verify(mongoSourceService).getSourceListByHonAndApprovalStatuses(eq(hon), statusCaptor.capture());
            List<String> approvalStatuses = statusCaptor.getValue();
            assertEquals(5, approvalStatuses.size());
            assertTrue(approvalStatuses.contains(ONHOLD.toString()));
            assertTrue(approvalStatuses.contains(SAVE_PENDING_APPROVAL.toString()));
            assertTrue(approvalStatuses.contains(PENDING_APPROVAL.toString()));
            assertTrue(approvalStatuses.contains(IN_PROGRESS.toString()));
            assertTrue(approvalStatuses.contains(REJECTED.toString()));

            verify(mongoSourceService).delete(pendingSource, collectionName);
            verify(mongoSourceService).updateByIdWithCustomFields(any(Query.class), any(Update.class), eq(collectionName));

            ArgumentCaptor<Source> historyCaptor = ArgumentCaptor.forClass(Source.class);
            verify(mongoSourceService).insertSourceHistory(historyCaptor.capture());

            Source historySource = historyCaptor.getValue();
            assertEquals(APPROVED, historySource.getApprovalStatus());
            assertEquals(SourceOrganizationStatus.INACTIVE, historySource.getStatus());
            assertEquals(DELETE, historySource.getAction());
            assertEquals("qa.user", historySource.getLastModifiedBy());
            assertEquals("qa.user@test.com", historySource.getLastModifierId());
            assertEquals(SearchConstants.LogFlagConstants.ARCHIVED, historySource.getLogFlag());
            assertNotNull(historySource.getLastActionDate());
            assertNotNull(historySource.getLastModifiedDate());

            verify(elasticsearchService).updateStatusForSourceIndex(
                    approvedSource,
                    SourceOrganizationStatus.INACTIVE.getStatus(),
                    ApprovalStatus.APPROVED.getStatus()
            );

            verify(reportDataUtils).reportData(
                    approvedSource,
                    SearchConstants.ReportActions.ARCHIVED,
                    SIDB_ORIGIN,
                    0,
                    null,
                    approvedSource.getVersion(),
                    approvedSource.getTempVersion(),
                    SearchConstants.ReportActions.ARCHIVED
            );
        }
    }

    @Test
    void archiveSource_shouldArchiveWhenSourceListIsEmpty() throws Exception {
        String hon = "EMPLOYMENT";
        String collectionName = "employment_source";

        UIActionsDTO uiActionsDTO = new UIActionsDTO();
        uiActionsDTO.setUserName("qa.user");
        uiActionsDTO.setUserEmail("qa.user@test.com");

        Source approvedSource = new Source();
        approvedSource.setHon(hon);
        approvedSource.setVersion(3.0);
        approvedSource.setTempVersion(4.0);

        when(mongoSourceService.findSourceByHonAndApprovalStatus(hon, APPROVED)).thenReturn(approvedSource);
        when(mongoSourceService.getSourceListByHonAndApprovalStatuses(eq(hon), anyList()))
                .thenReturn(Collections.emptyList());
        when(mongoSourceService.updateByIdWithCustomFields(any(Query.class), any(Update.class), eq(collectionName)))
                .thenReturn(false);

        try (MockedStatic<Helper> helperMock = mockStatic(Helper.class)) {
            helperMock.when(() -> Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX)).thenReturn(collectionName);

            boolean result = archiveSourceService.archiveSource(hon, uiActionsDTO);

            assertFalse(result);
            verify(mongoSourceService, never()).delete(any(Source.class), eq(collectionName));
            verify(mongoSourceService).insertSourceHistory(approvedSource);
            verify(elasticsearchService).updateStatusForSourceIndex(
                    approvedSource,
                    SourceOrganizationStatus.INACTIVE.getStatus(),
                    ApprovalStatus.APPROVED.getStatus()
            );
            verify(reportDataUtils).reportData(
                    approvedSource,
                    SearchConstants.ReportActions.ARCHIVED,
                    SIDB_ORIGIN,
                    0,
                    null,
                    approvedSource.getVersion(),
                    approvedSource.getTempVersion(),
                    SearchConstants.ReportActions.ARCHIVED
            );
        }
    }

    @Test
    void archiveSource_shouldThrowExceptionWhenApprovedSourceNotFound() {
        String hon = "EMPLOYMENT";

        UIActionsDTO uiActionsDTO = new UIActionsDTO();
        uiActionsDTO.setUserName("qa.user");
        uiActionsDTO.setUserEmail("qa.user@test.com");

        when(mongoSourceService.findSourceByHonAndApprovalStatus(hon, APPROVED)).thenReturn(null);

        try (MockedStatic<LoggingThrowable> loggingThrowableMock = mockStatic(LoggingThrowable.class)) {
            loggingThrowableMock
                    .when(() -> LoggingThrowable.logAndThrowResourceNotFound(SOURCE_NOT_FOUND, null, hon))
                    .thenThrow(new RuntimeException("SOURCE_NOT_FOUND"));

            RuntimeException exception = assertThrows(
                    RuntimeException.class,
                    () -> archiveSourceService.archiveSource(hon, uiActionsDTO)
            );

            assertEquals("SOURCE_NOT_FOUND", exception.getMessage());

            loggingThrowableMock.verify(() ->
                    LoggingThrowable.logAndThrowResourceNotFound(SOURCE_NOT_FOUND, null, hon));

            verify(mongoSourceService, never()).getSourceListByHonAndApprovalStatuses(anyString(), anyList());
            verify(mongoSourceService, never()).updateByIdWithCustomFields(any(Query.class), any(Update.class), anyString());
            verify(mongoSourceService, never()).insertSourceHistory(any(Source.class));
            verifyNoInteractions(elasticsearchService, reportDataUtils);
        }
    }
}