package hireright.applications.fulfillment_task_api.model.serialization;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-10-21  ATS-2670 initial version
 */

import jakarta.xml.bind.annotation.adapters.XmlAdapter;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class CLocalDateTimeAdapter extends XmlAdapter<String, LocalDateTime> {
    @Override
    public LocalDateTime unmarshal(String sValue) throws Exception {
        if (sValue == null || sValue.trim().isEmpty()) {
            return null;
        }

        if (sValue.endsWith("Z")) {
            sValue = sValue.substring(0, sValue.length() - 1);
        }

        try {
            return LocalDateTime.parse(sValue, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        } catch (Exception ignored) {
            return LocalDateTime.parse(sValue);
        }
    }

    @Override
    public String marshal(LocalDateTime value) throws Exception {
        return value != null ? value.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) : null;
    }
}
