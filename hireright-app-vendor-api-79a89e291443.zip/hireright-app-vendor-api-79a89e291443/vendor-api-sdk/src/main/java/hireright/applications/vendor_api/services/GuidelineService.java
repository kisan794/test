package hireright.applications.vendor_api.services;
/*
 * Copyright 2001-2018 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import hireright.components.domain.dialects.vendor_api.GuidelinesResponse;
import org.springframework.web.bind.annotation.RequestMethod;

public class GuidelineService {
    public static final String VAR_ORDER_REF = "orderRef";
    public static final String VAR_ORDER_SERVICE_REF = "orderServiceRef";

    public static final String PATH_GET =
            "/orders/{" + VAR_ORDER_REF + "}/services/{" + VAR_ORDER_SERVICE_REF + "}/guidelines";

    public enum EMethod implements IMethod {
        GET(PATH_GET, RequestMethod.GET, null, GuidelinesResponse.class);

        private final String path;
        private final RequestMethod requestMethod;
        private final Class<?> requestBodyClass;
        private final Class<?> responseBodyClass;

        EMethod(String sPath, RequestMethod requestMethod, Class<?> requestBodyClass, Class<?> responseBodyClass) {
            this.path = sPath;
            this.requestMethod = requestMethod;
            this.requestBodyClass = requestBodyClass;
            this.responseBodyClass = responseBodyClass;
        }

        public String getPath() {
            return this.path;
        }

        public RequestMethod getRequestMethod() {
            return this.requestMethod;
        }

        public Class<?> getRequestBodyClass() {
            return this.requestBodyClass;
        }

        public Class<?> getResponseBodyClass() {
            return this.responseBodyClass;
        }

        public boolean isValidRequest(Object request) {
            return true;
        }
    }
}
