package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hireright.sourceintelligence.api.dto.history.SearchHistoryFilter;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(value = JsonInclude.Include.NON_EMPTY, content = JsonInclude.Include.NON_NULL)
public class SearchResponseDTO {
    private String status;
    private OrganizationType organizationType;
    private List<SourceOrganizationDTO> sourceList;
    private int currentPage;
    private long totalItems;
    private int totalPages;
    private String unique;
    private List<String> organizationNames;
    private List<SourceDTO> searchList;
    private List<SearchOrganizationDTO> searchOrganizationList;
    private SearchHistoryFilter searchHistoryFilter;
}
