/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.config.filter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

/**
 * JWT Token Validator for validating JWT tokens
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Component
@Slf4j
public class JwtTokenValidator {

    @Value("${http.client.jwt.recombo-secret-key}")
    private String jwtSecret;

    /**
     * Validate JWT token
     *
     * @param token JWT token to validate
     * @return true if token is valid, false otherwise
     */
    public boolean validateToken(String token) {
        SecretKey key = Keys.hmacShaKeyFor(jwtSecret.getBytes(StandardCharsets.UTF_8));

        Claims claims = Jwts.parser().verifyWith(key).build().parseSignedClaims(token).getPayload();

        // Check if token is expired
        Date expiration = claims.getExpiration();
        if (expiration != null && expiration.before(new Date())) {
            log.warn("JWT token is expired");
            return false;
        }

        log.debug("JWT token validated successfully");
        return true;
    }
}