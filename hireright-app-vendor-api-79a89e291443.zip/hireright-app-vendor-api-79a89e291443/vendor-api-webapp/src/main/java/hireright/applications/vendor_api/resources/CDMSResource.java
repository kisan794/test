package hireright.applications.vendor_api.resources;
/*
* Copyright 2001-2018 by HireRight, Inc. All rights reserved.
*
* This software is the confidential and proprietary information
* of HireRight, Inc. Use is subject to license terms.
*
* History:
*	T.Prikk		2018-10-02	HIVPE-40534: Created for routed CDN requests based on
*		hireright.project.gp_supplier_portal.dao.CDMSDocumentDAO,
*		hireright.project.global_platform.result_gateway.resources.CResultReceiver.getDocument() (pre-35.10)
*/

import java.io.ByteArrayInputStream;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.hibernate.Session;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import hireright.applications.vendor_api.facades.DocumentMetadataFacade;
import hireright.applications.vendor_api.responses.FileResponse;
import hireright.applications.vendor_api.services.DMSService;
import hireright.components.domain.dialects.vendor_api.DocumentBundle;
import hireright.components.domain.dialects.vendor_api.DocumentMetadata;
import hireright.hbc.liberty.CLibertyDocument;
import hireright.objects.dms.document.CDMSApplicantDocument;
import hireright.objects.dms.document.CDMSDocumentFactory;
import hireright.objects.order.COrder;
import hireright.objects.order2.COrderDBContainer;
import hireright.project.applications.global_platform.core.dms.CDMSDocumentViewer;
import hireright.sdk.db.CMultitenantDB;
import hireright.sdk.db3.DB;
import hireright.sdk.format_util.ThreadSafeDateFormat;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.CStringUtils;

@RestController
public class CDMSResource extends AResource
{
	private static final String DOC_PARAM_TITLE = "title";
	private static final String DOC_PARAM_GUID = "GUID";
	private static final String DOC_PARAM_DOCUMENT_TYPE = "documentType";
	private static final String DMS_LIBERTY = "LIBERTY_DMS";
	private static final String HB_CONFIG_LIBERTY = "liberty";
	private static final String JNDI_NAME_LIBERTY = "java:comp/env/jdbc/LibertyDS";

	private static final int LEN_GOV_ID_SUFFIX = 4;

	private static final String DOC_PARAM_FIRST_NAME = "firstName";
	private static final String DOC_PARAM_LAST_NAME = "lastName";
	private static final String DOC_PARAM_FOLDER_ID = "folderID";
	private static final String DOC_PARAM_DATE_RECEIVED = "receivedDate";

	private static final ThreadSafeDateFormat DATE_FORMAT_EXTERNAL = new ThreadSafeDateFormat("yyyy-MM-dd HH:mm:ss");
	private static final ThreadSafeDateFormat DATE_FORMAT_LIBERTY = new ThreadSafeDateFormat("MM/dd/yyyy HH:mm:ss");

	@RequestMapping(path = DMSService.PATH_GET_ORDER_DOCUMENTS,
			method = RequestMethod.GET,
			produces = MediaType.APPLICATION_XML_VALUE)
	public DocumentBundle getDocuments(@PathVariable(name=DMSService.VAR_ORDER_REF) final String sOrderRef)
		throws Exception
	{
        return DB.execute(() ->
        {
            DB.requestReadOnly();
            
    		DocumentBundle documentBundle = new DocumentBundle();
    		List<DocumentMetadata> documentMetadatas = documentBundle.getDocumentMetadatas();
    		
            Integer nContainerID = COrderDBContainer.getContainerIDByOrderCode(sOrderRef);
            COrder order =  CMultitenantDB.execute(
				() -> nContainerID,
				targetTenantCode -> getOrderByOrderRef(sOrderRef));
            
    		String sGovID = CStringUtils.nvl(order.getPersonalID())
    				.substring(Math.max(0, order.getPersonalID().length() - LEN_GOV_ID_SUFFIX));
    		
    		getSearchResults(order.getRequestRegID(), order.getLastName(), sGovID)
    			.stream()
    			.map(CDMSResource::toMetadata)
    			.forEach(documentMetadatas::add);
    		
    		return documentBundle;            
        });            
	}
	
	private COrder getOrderByOrderRef(String sOrderRef) throws Exception
	{
		Long nOrderID = COrder.findOrderByRegID(DB.connection(), sOrderRef);
		COrder order = new COrder(nOrderID);
		if (!order.load())
		{
			throw new CRuntimeException("Cannot load order [" + nOrderID + "]");
		}
		return order;
	}

	private static DocumentMetadata toMetadata(CDMSApplicantDocument applicantDocument)
	{
		return new DocumentMetadataFacade()
			.reference(applicantDocument.getDocumentID())
			.storage(DMS_LIBERTY)
			.parameter(DOC_PARAM_FOLDER_ID, applicantDocument.getFolderID())
			.parameter(DOC_PARAM_DOCUMENT_TYPE, applicantDocument.getDocumentType())
			.parameter(DOC_PARAM_GUID, applicantDocument.getGUID())
			.parameter(DOC_PARAM_FIRST_NAME, applicantDocument.getFirstName())
			.parameter(DOC_PARAM_LAST_NAME, applicantDocument.getLastName())
			.parameter(DOC_PARAM_TITLE, applicantDocument.getTitle())
			.parameter(DOC_PARAM_DATE_RECEIVED, applicantDocument.getFiledDate())
			.getDocumentMetadata();
	}

	private List<CDMSApplicantDocument> getSearchResults(final String sRegID, final String sLastName, final String sGovID)
			throws Exception
	{
		return (new DB.Call<List<CDMSApplicantDocument>>(JNDI_NAME_LIBERTY)
			{
				@Override
				protected List<CDMSApplicantDocument> call() throws Exception
				{
					Session session = DB.session(HB_CONFIG_LIBERTY);
					
					List<CDMSApplicantDocument> documents;
					
					if (!CStringUtils.isEmpty(sRegID))
					{
						documents = CDMSDocumentFactory
							.getApplicantDocuments(sRegID, sLastName, sGovID, session);
					}
					else
					{
						documents = CDMSDocumentFactory
							.getPartiallyMatchedApplicantDocuments(sLastName, sGovID, session);
					}
					
					documents.forEach(CDMSResource::correctFileDateFormat);
					
					return documents;
				}
			}).executeReadOnlyIsolated();
	}

	private static void correctFileDateFormat(CDMSApplicantDocument applicantDocument)
	{
		try
		{
			String sFiledDate = applicantDocument.getFiledDate();
			if (!CStringUtils.isEmpty(sFiledDate))
			{
				Date date = DATE_FORMAT_LIBERTY.parse(sFiledDate);
				applicantDocument.setFiledDate(DATE_FORMAT_EXTERNAL.format(date));
			}
		} catch (ParseException e) {}
	}

	@RequestMapping(path = DMSService.PATH_GET_CONTENT,
			method = RequestMethod.GET,
			produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<InputStreamResource> getDocumentContent(
			@PathVariable(name=DMSService.VAR_ORDER_REF) final String sOrderRef,
			@PathVariable(name=DMSService.VAR_FOLDER_REF) final String sFolderRef,
			@PathVariable(name=DMSService.VAR_DOCUMENT_REF) final String sDocumentRef
		) throws Exception
	{
		return DB.execute(() -> {
			DB.requestReadOnly();
			
			CDMSDocumentViewer documentViewer = new CDMSDocumentViewer();
			// RTE on failure; try-with-timeout included:
			CLibertyDocument document = documentViewer.getDoc(sFolderRef, sDocumentRef);
			
			// Same in result GW:
			String sTempFilename = UUID.randomUUID() + "." + document.getFilenameExtension();
			FileResponse fileResponse = new FileResponse(
					sTempFilename,
					document.getContentType(),
					document.getContent()
				);
			
			return createFileResponseEntity(fileResponse);
		});
	}

	private ResponseEntity<InputStreamResource> createFileResponseEntity(FileResponse fileResponse)
	{
		InputStreamResource resource = new InputStreamResource(new ByteArrayInputStream(fileResponse.getContent()),
				fileResponse.getFileName());
		
		return new ResponseEntity<InputStreamResource>(resource,
				fileResponse.getHeaders(),
				HttpStatus.OK);
	}
}
