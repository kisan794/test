package com.hireright.sourceintelligence.domain.mapper;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNull;

import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import java.util.List;
import org.bson.types.ObjectId;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

class SourceMapperTest {

    private SourceMapper sourceMapper;

    @BeforeEach
    void setUp() {
        sourceMapper = Mappers.getMapper(SourceMapper.class);
    }

    @Test
    void mapToDBObject_shouldConvertJSONObjectToDBObject() {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("website", "https://example.com");
        jsonObject.put("notes", "sample notes");

        DBObject dbObject = SourceMapper.mapToDBObject(jsonObject);

        assertThat(dbObject).isNotNull();
        assertThat(dbObject.get("website")).isEqualTo("https://example.com");
        assertThat(dbObject.get("notes")).isEqualTo("sample notes");
    }

    @Test
    void mapToJSONObject_shouldConvertDBObjectToJSONObject() {
        DBObject dbObject = BasicDBObject.parse("""
            {
              "website": "https://example.com",
              "notes": "sample notes"
            }
            """);

        JSONObject jsonObject = SourceMapper.mapToJSONObject(dbObject);

        assertThat(jsonObject).isNotNull();
        assertThat(jsonObject.getString("website")).isEqualTo("https://example.com");
        assertThat(jsonObject.getString("notes")).isEqualTo("sample notes");
    }

    @Test
    void map_shouldReturnObjectIdWhenIdIsNotNull() {
        String id = new ObjectId().toHexString();

        ObjectId result = sourceMapper.map(id);

        assertThat(result).isNotNull();
        assertThat(result.toHexString()).isEqualTo(id);
    }

    @Test
    void map_shouldReturnNullWhenIdIsNull() {
        ObjectId result = sourceMapper.map(null);

        assertNull(result);
    }

    @Test
    void mapId_shouldReturnHexStringWhenObjectIdIsNotNull() {
        ObjectId objectId = new ObjectId();

        String result = sourceMapper.mapId(objectId);

        assertThat(result).isEqualTo(objectId.toHexString());
    }

    @Test
    void mapId_shouldReturnNullWhenObjectIdIsNull() {
        String result = sourceMapper.mapId(null);

        assertNull(result);
    }

    @Test
    void dtoToEntitySource_shouldMapAllFieldsIncludingPayloadAndId() {
        String id = new ObjectId().toHexString();

        JSONObject payload = new JSONObject();
        payload.put("website", "https://example.com");
        payload.put("notes", "sample notes");

        SourceOrganizationDTO dto = new SourceOrganizationDTO();
        dto.setId(id);
        dto.setOrganizationName("Test University");
        dto.setPayload(payload);

        Source entity = sourceMapper.dtoToEntitySource(dto);

        assertThat(entity).isNotNull();
        assertThat(entity.getId()).isNotNull();
        assertThat(entity.getId().toHexString()).isEqualTo(id);
        assertThat(entity.getOrganizationName()).isEqualTo("Test University");
        assertThat(entity.getPayload()).isNotNull();
        assertThat(entity.getPayload().get("website")).isEqualTo("https://example.com");
        assertThat(entity.getPayload().get("notes")).isEqualTo("sample notes");
    }

    @Test
    void entitySourceToDTO_shouldMapAllFieldsIncludingPayloadAndId() {
        ObjectId objectId = new ObjectId();

        Source entity = new Source();
        entity.setId(objectId);
        entity.setOrganizationName("Test University");
        entity.setPayload(BasicDBObject.parse("""
            {
              "website": "https://example.com",
              "notes": "sample notes"
            }
            """));

        SourceOrganizationDTO dto = sourceMapper.entitySourceToDTO(entity);

        assertThat(dto).isNotNull();
        assertThat(dto.getId()).isEqualTo(objectId.toHexString());
        assertThat(dto.getOrganizationName()).isEqualTo("Test University");
        assertThat(dto.getPayload()).isNotNull();
        assertThat(dto.getPayload().getString("website")).isEqualTo("https://example.com");
        assertThat(dto.getPayload().getString("notes")).isEqualTo("sample notes");
    }

    @Test
    void toSourceDTOList_shouldMapListSuccessfully() {
        Source entity = new Source();
        entity.setId(new ObjectId());
        entity.setOrganizationName("Test University");
        entity.setPayload(BasicDBObject.parse("""
            {
              "website": "https://example.com"
            }
            """));

        List<SourceOrganizationDTO> result = sourceMapper.toSourceDTOList(List.of(entity));

        assertThat(result).isNotNull();
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getId()).isEqualTo(entity.getId().toHexString());
        assertThat(result.get(0).getOrganizationName()).isEqualTo("Test University");
        assertThat(result.get(0).getPayload()).isNotNull();
        assertThat(result.get(0).getPayload().getString("website")).isEqualTo("https://example.com");
    }
}
