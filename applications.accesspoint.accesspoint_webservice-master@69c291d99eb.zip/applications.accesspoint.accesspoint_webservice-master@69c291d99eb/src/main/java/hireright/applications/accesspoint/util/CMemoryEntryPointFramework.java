/*
 * @(#)$RCSfile: CMemoryEntryPointFramework.java,v $ $Revision: 1.2 $ $Date: 2014/07/28 14:57:11 $ $Author: aputintsev $ 
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/util/CMemoryEntryPointFramework.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *     $Log: CMemoryEntryPointFramework.java,v $
 *     Revision 1.2  2014/07/28 14:57:11  aputintsev
 *     forked from production version - projects_src/applications/accesspoint
 *
 *     Revision 1.1.2.1.2.1  2009/08/18 11:09:20  asolntsev
 *     Bugfixing and polishing
 *
 *     Revision 1.1.2.1  2009/08/13 13:24:24  asolntsev
 *     Created by St.Petersburg team
 *
 *     Revision 1.1  2009/08/06 09:37:55  banton
 *     Added simple Finite State Machine support. Tested only for memory storage
 *
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hireright.applications.accesspoint.util;

import hireright.objects.utilities.CEntryPoint;
import java.util.Map;

/**
 *
 * @author banton
 */
public class CMemoryEntryPointFramework 
		extends CBaseEntryPointFramework
{
	public void setUp()
	{
		// nothing to do
	}
	
	public void tearDown()
	{
		// nothing to do
	}
	
	public void commit()
	{
		// nothing to do
	}
	
	public void rollback()
	{
		// nothing to do
	}

		public CEntryPoint getEntryPoint(String key)
		{
				return CEntryPointStorage.getInstance().get(key);
		}

		public void saveEntryPoint(CEntryPoint entryPoint)
		{
				if (entryPoint==null)
						throw new IllegalArgumentException("entryPoint is null");

				Map<String, CEntryPoint> storage = CEntryPointStorage.getInstance();
				CEntryPoint oldEntryPoint = storage.get(entryPoint.getKey());

				if (oldEntryPoint!=null && oldEntryPoint!=entryPoint)
				{
					throw new IllegalStateException("Old entry point (" + oldEntryPoint + 
							") is not same as new entry point (" + entryPoint + ")");
				}
				
				storage.put(entryPoint.getKey(), entryPoint);
		}

		public void deleteEntryPointByKey(String key)
		{
			CEntryPointStorage.getInstance().remove(key);
		}

		public void deleteEntryPoint(CEntryPoint entryPoint)
		{
				deleteEntryPointByKey(entryPoint.getKey());
		}
}
