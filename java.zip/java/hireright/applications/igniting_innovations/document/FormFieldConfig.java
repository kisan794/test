package hireright.applications.igniting_innovations.document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Keshav Ladha
 * @version 1.0
 */
@Document(collection = "form_field_configs")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FormFieldConfig {

    @Id
    private String id;

    @Indexed(unique = true)
    private String fieldKey;

    private List<FieldOption> options;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FieldOption {
        private String value;

        private String label;
    }
}

