package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.AutoMatchDTO;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchResponseDTO;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchSourceDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.domain.mapper.AutoMatchMapper;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.searchindex.entity.ElasticsearchSource;
import com.hireright.sourceintelligence.service.AutoMatchRegionService;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import com.hireright.sourceintelligence.util.Helper;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;

@Getter
@Primary
@Slf4j
@RequiredArgsConstructor
@Transactional
@Service
@Lazy
public class NonUSRegionAutoMatchServiceImpl implements AutoMatchRegionService {

    private final CustomSourceRepository<Source> customSourceRepository;
    private final AutoMatchMapper autoMatchMapper;
    private final ElasticsearchService elasticsearchService;

    @Override
    public AutoMatchResponseDTO autoMatch(AutoMatchDTO inputData) {
        Instant requestTime = Instant.now();
        log.info("[{}] auto match service emea request: {}", inputData.getRequestId(), inputData);
        try {
            String indexName = Helper.getIndexName(inputData.getSourceType());
            List<ElasticsearchSource> searchSource = elasticsearchService.nonUSAutoMatchSearch(inputData, indexName);
            if (searchSource == null || searchSource.isEmpty()) {
                return AutoMatchResponseDTO.baseBuilder(inputData.getRequestId(), requestTime).error(NO_AUTO_MATCH_ES).build();
            }
            log.info("[{}] Elastic search result: {}", inputData.getRequestId(), searchSource);
            String hon;
            if (searchSource.size() > 1) {
                hon = findExactSource(inputData, searchSource);
                if(hon.equals(Strings.EMPTY)){
                    return AutoMatchResponseDTO.baseBuilder(inputData.getRequestId(), requestTime).error(NO_AUTO_MATCH_DUPLICATE).build();
                }
            }else{
                hon = searchSource.getFirst().getHon();
            }
            String collectionName = Helper.getCollectionName(inputData.getSourceType(), SOURCE_COLLECTION_SUFFIX);
            List<Source> source = customSourceRepository.findByHonAndStatus(hon, SourceOrganizationStatus.ACTIVE.getStatus(), Source.class, collectionName);
            if (source == null || source.isEmpty()) {
                return AutoMatchResponseDTO.baseBuilder(inputData.getRequestId(), requestTime).error(NO_AUTO_MATCH_MS).build();
            }
            log.info("[{}] auto match result: {}", inputData.getRequestId(), source.getFirst().getHon());
            AutoMatchSourceDTO autoMatchSourceDTO = autoMatchMapper.toAutoMatchDTO(source.getFirst());
            return AutoMatchResponseDTO.baseBuilder(inputData.getRequestId(), requestTime).source(autoMatchSourceDTO).build();
        } catch (Exception e) {
            return AutoMatchResponseDTO.baseBuilder(inputData.getRequestId(), requestTime).serverError(INTERNAL_SERVER_ERROR).build();
        }
    }


    public String findExactSource(AutoMatchDTO inputData, List<ElasticsearchSource> searchList) {
        String sourceName = inputData.getSourceName().trim().toLowerCase();
        String hon = Strings.EMPTY;
        int matchCount = 0;
        int cityCount = 0;
        String matchHonWithSC = Strings.EMPTY;
        for (ElasticsearchSource searchSource : searchList) {
            if(searchSource.getOrganizationName().equalsIgnoreCase(sourceName)){
                if(searchSource.getCity().equalsIgnoreCase(inputData.getCity())){
                    cityCount++;
                    matchHonWithSC = searchSource.getHon();
                }
                hon = searchSource.getHon();
                matchCount++;
            }
        }
        if (matchCount == 0) {
            hon = findOrgAlias(inputData, searchList, matchCount, cityCount);
        }
        if (matchCount > 1) {
            if(cityCount==1) return matchHonWithSC;
            return Strings.EMPTY;
        }
        return hon;
    }

    private String findOrgAlias(AutoMatchDTO inputData, List<ElasticsearchSource> searchList, int matchCount, int cityCount){
        String hon = Strings.EMPTY;
        String matchHonWithSC = Strings.EMPTY;
        for (ElasticsearchSource searchSource : searchList) {
            if (searchSource.getOrganizationAlias() != null && !searchSource.getOrganizationAlias().isEmpty()) {
                for (String alias : searchSource.getOrganizationAlias()) {
                    if(alias.equalsIgnoreCase(inputData.getSourceName())){
                        hon = searchSource.getHon();
                        break;
                    }
                }
            }
            if (!hon.isEmpty()) {
                matchCount++;
            }
            if(searchSource.getCity().equalsIgnoreCase(inputData.getCity())){
                matchHonWithSC = searchSource.getHon();
                cityCount++;
            }
        }
        if (cityCount == 1) return matchHonWithSC;
        return hon;
    }
}
