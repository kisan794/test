package com.hireright.sourceintelligence.reports.service;

import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.reports.domain.entity.ReportSearchResult;
import com.hireright.sourceintelligence.reports.domain.entity.Reports;
import com.hireright.sourceintelligence.reports.domain.mapper.ReportMapper;
import com.hireright.sourceintelligence.reports.dto.GenericResponseDTO;
import com.hireright.sourceintelligence.reports.dto.MetaDTO;
import com.hireright.sourceintelligence.reports.dto.ReportResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;
import com.hireright.sourceintelligence.reports.service.impl.ReportServiceImpl;
import com.hireright.sourceintelligence.reports.service.impl.ReportUtils;
import com.hireright.sourceintelligence.reports.service.impl.ReportsQueryBuilder;
import com.hireright.sourceintelligence.service.impl.QueryBuilder;
import com.hireright.sourceintelligence.service.impl.helperservices.CountryRegionMappingUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.FacetOperation;
import org.springframework.data.mongodb.core.aggregation.GroupOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.aggregation.SortOperation;
import org.springframework.data.mongodb.core.query.Criteria;

import java.util.ArrayList;
import java.util.List;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.REPORTS_COLLECTION;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.RESPONSE_REPORT_LIST;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.ReportTypes.DELETE_SOURCE_REPORT;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ReportServiceImplTest {

    @Mock
    private ReportMapper reportMapper;

    @Mock
    private CustomSourceRepository<Reports> customSourceRepository;

    @Mock
    private CountryRegionMappingUtils countryRegionMappingUtils;

    @Mock
    private ReportsRequestDTO reportsRequestDTO;

    @Mock
    private ReportSearchResult reportSearchResult;

    private ReportServiceImpl reportService;

    @BeforeEach
    void setUp() {
        reportService = new ReportServiceImpl(reportMapper, customSourceRepository, countryRegionMappingUtils);
    }

    @Test
    void deleteReport_shouldReturnMappedResponse_whenRegionPresentAndResponseListNotEmpty() {
        String region = "APAC";
        String sort = "createdDate";
        String order = "DESC";
        int startPage = 2;
        int batchSize = 10;
        int total = 25;

        List<String> countryList = List.of("India", "Japan");
        List<Object> responseReportList = List.of(new Object(), new Object());
        List<GenericResponseDTO> mappedDtoList = List.of(mock(GenericResponseDTO.class), mock(GenericResponseDTO.class));
        List<MetaDTO> metaDTOList = List.of(mock(MetaDTO.class));

        Criteria criteria = new Criteria();
        MatchOperation matchOperation = mock(MatchOperation.class);
        GroupOperation groupOperation = mock(GroupOperation.class);
        SortOperation sortOperation = mock(SortOperation.class);
        FacetOperation facetOperation = mock(FacetOperation.class);
        ProjectionOperation projectionOperation = mock(ProjectionOperation.class);

        when(reportsRequestDTO.getRegion()).thenReturn(region);
        when(reportsRequestDTO.getSort()).thenReturn(sort);
        when(reportsRequestDTO.getOrder()).thenReturn(order);
        when(reportsRequestDTO.getStartPage()).thenReturn(startPage);
        when(reportsRequestDTO.getBatchSize()).thenReturn(batchSize);

        when(countryRegionMappingUtils.findDistinctCountriesByRegion(region)).thenReturn(countryList);
        when(reportSearchResult.getResponseReportList()).thenReturn((List) responseReportList);
        when(reportSearchResult.getTotal()).thenReturn(total);
        when(reportMapper.toDTOList((List) responseReportList)).thenReturn(mappedDtoList);
        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), eq(REPORTS_COLLECTION), eq(ReportSearchResult.class)))
                .thenReturn(reportSearchResult);

        try (MockedStatic<ReportsQueryBuilder> reportsQueryBuilderMock = org.mockito.Mockito.mockStatic(ReportsQueryBuilder.class);
             MockedStatic<ReportUtils> reportUtilsMock = org.mockito.Mockito.mockStatic(ReportUtils.class);
             MockedStatic<QueryBuilder> queryBuilderMock = org.mockito.Mockito.mockStatic(QueryBuilder.class)) {

            reportsQueryBuilderMock.when(() -> ReportsQueryBuilder.queryBuilderForDelete(reportsRequestDTO, countryList))
                    .thenReturn(criteria);
            reportsQueryBuilderMock.when(() -> ReportsQueryBuilder.matchOperation(criteria))
                    .thenReturn(matchOperation);
            reportsQueryBuilderMock.when(ReportsQueryBuilder::deleteGroupOperation)
                    .thenReturn(groupOperation);
            reportsQueryBuilderMock.when(() -> ReportsQueryBuilder.buildSortOperation(sort, order))
                    .thenReturn(sortOperation);
            reportsQueryBuilderMock.when(() -> ReportsQueryBuilder.facetOperationWithGroup(sortOperation, startPage, batchSize, groupOperation))
                    .thenReturn(facetOperation);
            reportsQueryBuilderMock.when(() -> ReportsQueryBuilder.finalProjectionWithTotalCountInPipeline(RESPONSE_REPORT_LIST))
                    .thenReturn(projectionOperation);

            reportUtilsMock.when(() -> ReportUtils.getMetaDataByReport(DELETE_SOURCE_REPORT))
                    .thenReturn(metaDTOList);

            queryBuilderMock.when(() -> QueryBuilder.getTotalPages(total, batchSize))
                    .thenReturn(3);

            ReportResponseDTO result = reportService.deleteReport(reportsRequestDTO);

            assertNotNull(result);
            assertEquals(metaDTOList, result.getMeta());
            assertEquals(mappedDtoList, result.getResponse());
            assertEquals(startPage, result.getCurrentPage());
            assertEquals(total, result.getTotalItems());
            assertEquals(3, result.getTotalPages());
            assertEquals(DELETE_SOURCE_REPORT, result.getReportType());

            verify(countryRegionMappingUtils).findDistinctCountriesByRegion(region);
            verify(reportMapper).toDTOList((List) responseReportList);

            ArgumentCaptor<Aggregation> aggregationCaptor = ArgumentCaptor.forClass(Aggregation.class);
            verify(customSourceRepository).reportCustomAggregate(
                    aggregationCaptor.capture(),
                    eq(REPORTS_COLLECTION),
                    eq(ReportSearchResult.class)
            );
            assertNotNull(aggregationCaptor.getValue());
        }
    }

    @Test
    void deleteReport_shouldReturnEmptyResponse_whenRegionIsNullAndResponseListIsEmpty() {
        String sort = "sourceName";
        String order = "ASC";
        int startPage = 1;
        int batchSize = 5;
        int total = 0;

        Criteria criteria = new Criteria();
        MatchOperation matchOperation = mock(MatchOperation.class);
        GroupOperation groupOperation = mock(GroupOperation.class);
        SortOperation sortOperation = mock(SortOperation.class);
        FacetOperation facetOperation = mock(FacetOperation.class);
        ProjectionOperation projectionOperation = mock(ProjectionOperation.class);
        List<MetaDTO> metaDTOList = List.of(mock(MetaDTO.class));

        when(reportsRequestDTO.getRegion()).thenReturn(null);
        when(reportsRequestDTO.getSort()).thenReturn(sort);
        when(reportsRequestDTO.getOrder()).thenReturn(order);
        when(reportsRequestDTO.getStartPage()).thenReturn(startPage);
        when(reportsRequestDTO.getBatchSize()).thenReturn(batchSize);

        when(reportSearchResult.getResponseReportList()).thenReturn(new ArrayList<>());
        when(reportSearchResult.getTotal()).thenReturn(total);
        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), eq(REPORTS_COLLECTION), eq(ReportSearchResult.class)))
                .thenReturn(reportSearchResult);

        try (MockedStatic<ReportsQueryBuilder> reportsQueryBuilderMock = org.mockito.Mockito.mockStatic(ReportsQueryBuilder.class);
             MockedStatic<ReportUtils> reportUtilsMock = org.mockito.Mockito.mockStatic(ReportUtils.class);
             MockedStatic<QueryBuilder> queryBuilderMock = org.mockito.Mockito.mockStatic(QueryBuilder.class)) {

            reportsQueryBuilderMock.when(() -> ReportsQueryBuilder.queryBuilderForDelete(reportsRequestDTO, null))
                    .thenReturn(criteria);
            reportsQueryBuilderMock.when(() -> ReportsQueryBuilder.matchOperation(criteria))
                    .thenReturn(matchOperation);
            reportsQueryBuilderMock.when(ReportsQueryBuilder::deleteGroupOperation)
                    .thenReturn(groupOperation);
            reportsQueryBuilderMock.when(() -> ReportsQueryBuilder.buildSortOperation(sort, order))
                    .thenReturn(sortOperation);
            reportsQueryBuilderMock.when(() -> ReportsQueryBuilder.facetOperationWithGroup(sortOperation, startPage, batchSize, groupOperation))
                    .thenReturn(facetOperation);
            reportsQueryBuilderMock.when(() -> ReportsQueryBuilder.finalProjectionWithTotalCountInPipeline(RESPONSE_REPORT_LIST))
                    .thenReturn(projectionOperation);

            reportUtilsMock.when(() -> ReportUtils.getMetaDataByReport(DELETE_SOURCE_REPORT))
                    .thenReturn(metaDTOList);

            queryBuilderMock.when(() -> QueryBuilder.getTotalPages(total, batchSize))
                    .thenReturn(0);

            ReportResponseDTO result = reportService.deleteReport(reportsRequestDTO);

            assertNotNull(result);
            assertEquals(metaDTOList, result.getMeta());
            assertNotNull(result.getResponse());
            assertTrue(result.getResponse().isEmpty());
            assertEquals(startPage, result.getCurrentPage());
            assertEquals(total, result.getTotalItems());
            assertEquals(0, result.getTotalPages());
            assertEquals(DELETE_SOURCE_REPORT, result.getReportType());

            verify(countryRegionMappingUtils, never()).findDistinctCountriesByRegion(any());
            verify(reportMapper, never()).toDTOList(anyList());
        }
    }

    @Test
    void deleteReport_shouldReturnEmptyResponse_whenRegionIsEmpty() {
        String sort = "updatedDate";
        String order = "DESC";
        int startPage = 0;
        int batchSize = 20;
        int total = 0;

        Criteria criteria = new Criteria();
        MatchOperation matchOperation = mock(MatchOperation.class);
        GroupOperation groupOperation = mock(GroupOperation.class);
        SortOperation sortOperation = mock(SortOperation.class);
        FacetOperation facetOperation = mock(FacetOperation.class);
        ProjectionOperation projectionOperation = mock(ProjectionOperation.class);

        when(reportsRequestDTO.getRegion()).thenReturn("");
        when(reportsRequestDTO.getSort()).thenReturn(sort);
        when(reportsRequestDTO.getOrder()).thenReturn(order);
        when(reportsRequestDTO.getStartPage()).thenReturn(startPage);
        when(reportsRequestDTO.getBatchSize()).thenReturn(batchSize);

        when(reportSearchResult.getResponseReportList()).thenReturn(new ArrayList<>());
        when(reportSearchResult.getTotal()).thenReturn(total);
        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), eq(REPORTS_COLLECTION), eq(ReportSearchResult.class)))
                .thenReturn(reportSearchResult);

        try (MockedStatic<ReportsQueryBuilder> reportsQueryBuilderMock = org.mockito.Mockito.mockStatic(ReportsQueryBuilder.class);
             MockedStatic<ReportUtils> reportUtilsMock = org.mockito.Mockito.mockStatic(ReportUtils.class);
             MockedStatic<QueryBuilder> queryBuilderMock = org.mockito.Mockito.mockStatic(QueryBuilder.class)) {

            reportsQueryBuilderMock.when(() -> ReportsQueryBuilder.queryBuilderForDelete(reportsRequestDTO, null))
                    .thenReturn(criteria);
            reportsQueryBuilderMock.when(() -> ReportsQueryBuilder.matchOperation(criteria))
                    .thenReturn(matchOperation);
            reportsQueryBuilderMock.when(ReportsQueryBuilder::deleteGroupOperation)
                    .thenReturn(groupOperation);
            reportsQueryBuilderMock.when(() -> ReportsQueryBuilder.buildSortOperation(sort, order))
                    .thenReturn(sortOperation);
            reportsQueryBuilderMock.when(() -> ReportsQueryBuilder.facetOperationWithGroup(sortOperation, startPage, batchSize, groupOperation))
                    .thenReturn(facetOperation);
            reportsQueryBuilderMock.when(() -> ReportsQueryBuilder.finalProjectionWithTotalCountInPipeline(RESPONSE_REPORT_LIST))
                    .thenReturn(projectionOperation);

            reportUtilsMock.when(() -> ReportUtils.getMetaDataByReport(DELETE_SOURCE_REPORT))
                    .thenReturn(new ArrayList<>());

            queryBuilderMock.when(() -> QueryBuilder.getTotalPages(total, batchSize))
                    .thenReturn(0);

            ReportResponseDTO result = reportService.deleteReport(reportsRequestDTO);

            assertNotNull(result);
            assertNotNull(result.getResponse());
            assertTrue(result.getResponse().isEmpty());
            assertEquals(startPage, result.getCurrentPage());
            assertEquals(total, result.getTotalItems());
            assertEquals(0, result.getTotalPages());
            assertEquals(DELETE_SOURCE_REPORT, result.getReportType());

            verify(countryRegionMappingUtils, never()).findDistinctCountriesByRegion(any());
            verify(reportMapper, never()).toDTOList(anyList());
        }
    }
}