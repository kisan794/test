package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.rds.VendorResponseDTO;
import com.hireright.sourceintelligence.service.RDSService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@Validated
@Slf4j
public class RDSApiController implements RDSApi {

    private final RDSService rdsService;

    @Override
    public ResponseEntity<VendorResponseDTO> getVendorsList() {
        VendorResponseDTO result = rdsService.getVendorList();
        return new ResponseEntity<>(result, HttpStatus.OK);
    }
}
