package com.hireright.sourceintelligence.service.excel;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;

import static com.hireright.sourceintelligence.domain.constants.Constants.DataExtractionConstants.EMPTY_STRING;

public class ExcelCellReader {

    private ExcelCellReader(){

    }

    public static String getCellValue(Row row, int columnIndex) {
        if (row == null) {
            return EMPTY_STRING;
        }
        Cell cell = row.getCell(columnIndex);
        return getCellValueAsString(cell);
    }

    public static String getCellValueAsString(Cell cell) {
        if (cell == null) {
            return EMPTY_STRING;
        }

        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                return formatNumericCell(cell);
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                return evaluateFormulaCell(cell);
            case BLANK:
                return EMPTY_STRING;
            default:
                return EMPTY_STRING;
        }
    }

    private static String formatNumericCell(Cell cell) {
        if (DateUtil.isCellDateFormatted(cell)) {
            return cell.getDateCellValue().toString();
        }

        double numericValue = cell.getNumericCellValue();
        if (numericValue == (long) numericValue) {
            return String.valueOf((long) numericValue);
        }
        return String.valueOf(numericValue);
    }

    private static String evaluateFormulaCell(Cell cell) {
        try {
            return cell.getStringCellValue().trim();
        } catch (IllegalStateException e) {
            return cell.getCellFormula();
        }
    }

    public static boolean hasContent(Cell cell) {
        return cell != null
                && cell.getCellType() != CellType.BLANK
                && !getCellValueAsString(cell).isEmpty();
    }

    public static boolean isRowEmpty(Row row) {
        if (row == null) {
            return true;
        }

        int lastCellNum = row.getLastCellNum();
        if (lastCellNum < 0) {
            return true;
        }

        for (int cellIndex = 0; cellIndex < lastCellNum; cellIndex++) {
            Cell cell = row.getCell(cellIndex);
            if (hasContent(cell)) {
                return false;
            }
        }
        return true;
    }
}