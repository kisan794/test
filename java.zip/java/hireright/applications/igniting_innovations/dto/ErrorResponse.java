package hireright.applications.igniting_innovations.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.List;

/**
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Error response")
public class ErrorResponse {

    @Schema(description = "Error timestamp")
    @JsonProperty("timestamp")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    private OffsetDateTime timestamp;

    @Schema(description = "HTTP status code")
    @JsonProperty("statusCode")
    private Integer statusCode;

    @Schema(description = "Status")
    @JsonProperty("status")
    private String status;

    @Schema(description = "Error message")
    @JsonProperty("message")
    private String message;

    @Schema(description = "List of error details")
    @JsonProperty("errors")
    private List<ErrorDetail> errors;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "Error detail")
    public static class ErrorDetail {

        @Schema(description = "Error message")
        @JsonProperty("message")
        private String message;
    }

    public static ErrorResponse of(Integer statusCode, String status, String message, List<ErrorDetail> errors) {
        return ErrorResponse.builder()
                .timestamp(OffsetDateTime.now())
                .statusCode(statusCode)
                .status(status)
                .message(message)
                .errors(errors)
                .build();
    }

    public static ErrorResponse of(Integer statusCode, String status, String message, String errorMessage) {
        return of(statusCode, status, message, List.of(ErrorDetail.builder().message(errorMessage).build()));
    }

}