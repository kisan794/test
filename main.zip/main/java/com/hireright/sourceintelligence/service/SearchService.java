package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.dto.timezone.DropDownDTO;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;

import java.util.List;


public interface SearchService {

    SearchResponseDTO getSourceOrganizationList(SearchDTO searchDTO);

    SearchResponseDTO getSourceOrganizationListForAutocomplete(SearchDTO searchDTO);

    SearchResponseDTO getSourceOrganizationContactListByHon(SearchDTO searchDTO);

    SearchResponseDTO getSourceOrganizationAddressByHon(SearchDTO searchDTO);

    SearchResponseDTO getSourcesByFilters(SearchFilter searchFilter, String order, String sort, int startPage, int pageSize);

    SearchResponseDTO getDetailedAutocompletedSearchResult(String keyword, OrganizationType orgType, SourceOrganizationStatus status, String country); //TODO - api is not using

    SearchResponseDTO getAutocompletedSuggestionForPossibleDuplicates(String keyword, OrganizationType orgType);

    SearchFilter getFiltersForSourceOrganizations();

    List<DropDownDTO> getRegionList();

}
