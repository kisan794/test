package com.hireright.sourceintelligence.service.extraction;

import java.util.List;
import java.util.Map;

public interface DataExtractionProcessor<T> {
    Map<String, Object> processRecords(List<T> records);

    String getDataExtractionTypeType();

    default boolean supports(String dataExtractionType) {
        return getDataExtractionTypeType().equalsIgnoreCase(dataExtractionType);
    }
}

