package com.hireright.sourceintelligence.service.notification;

import com.hireright.sourceintelligence.api.dto.notification.EmailNotificationDTO;

/**
 * Interface for email notification service
 * Following Interface Segregation Principle - separate interface for email-specific operations
 * Following Single Responsibility Principle - only handles email sending
 */
public interface EmailNotificationService {
    
    /**
     * Send an email notification
     * 
     * @param emailNotification email notification details
     * @return notification ID if successful
     * @throws RuntimeException if email sending fails
     */
    String sendEmail(EmailNotificationDTO emailNotification);
    
    /**
     * Send an email notification asynchronously
     * 
     * @param emailNotification email notification details
     */
    void sendEmailAsync(EmailNotificationDTO emailNotification);
    
    /**
     * Validate email notification details
     * 
     * @param emailNotification email notification to validate
     * @return true if valid, false otherwise
     */
    boolean validateEmailNotification(EmailNotificationDTO emailNotification);
}

