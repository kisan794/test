package hireright.applications.igniting_innovations.exception;

/**
 * @author Keshav Ladha
 * @version 1.0
 */
public class ResourceNotFoundException extends RuntimeException {

    public ResourceNotFoundException(String message) {
        super(message);
    }
}
