package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.rds.*;
import com.hireright.sourceintelligence.domain.entity.Country;
import com.hireright.sourceintelligence.domain.entity.CountryRegion;
import com.hireright.sourceintelligence.domain.entity.Language;
import com.hireright.sourceintelligence.domain.mapper.CountryMapper;
import com.hireright.sourceintelligence.domain.mapper.LanguageMapper;
import com.hireright.sourceintelligence.domain.repository.CountryRegionRepository;
import com.hireright.sourceintelligence.domain.repository.CountryRepository;
import com.hireright.sourceintelligence.domain.repository.LanguageRepository;
import com.hireright.sourceintelligence.service.CountryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@RequiredArgsConstructor
@Service
public class CountryServiceImpl implements CountryService {

    private static final String BATCH_SIZE_PARAM = "&batchSize=";

    private final CountryRepository countryRepository;
    private final CountryRegionRepository countryRegionRepository;
    private final LanguageRepository languageRepository;
    private final CountryMapper countryMapper;
    private final LanguageMapper languageMapper;

    @Override
    public CountryResponseDTO getCountries(int startIndex, int batchSize) {
        log.info("Fetching countries with startIndex: {} and batchSize: {}", startIndex, batchSize);
        
        int pageNumber = startIndex - 1;
        if (pageNumber < 0) {
            pageNumber = 0;
        }
        
        Pageable pageable = PageRequest.of(pageNumber, batchSize);
        Page<Country> countryPage = countryRepository.findAll(pageable);
        
        List<CountryDTO> countryDTOs = countryMapper.entityToDTOList(countryPage.getContent());
        
        PaginationMetadata metadata = PaginationMetadata.builder()
                .totalSize(countryPage.getTotalElements())
                .startIndex(startIndex)
                .batchSize(batchSize)
                .link("/country/?startIndex=" + startIndex + BATCH_SIZE_PARAM + batchSize)
                .build();
        
        return CountryResponseDTO.builder()
                .data(countryDTOs)
                .metadata(metadata)
                .build();
    }

    @Override
    public CountryRegionResponseDTO getCountryRegions(int countryId, int startIndex, int batchSize) {
        log.info("Fetching country regions for countryId: {} with startIndex: {} and batchSize: {}", 
                countryId, startIndex, batchSize);
        
        int pageNumber = startIndex - 1;
        if (pageNumber < 0) {
            pageNumber = 0;
        }
        
        Pageable pageable = PageRequest.of(pageNumber, batchSize);
        Page<CountryRegion> regionPage = countryRegionRepository.findByCountryId(countryId, pageable);
        
        List<CountryRegionDTO> regionDTOs = countryMapper.entityToRegionDTOList(regionPage.getContent());
        
        PaginationMetadata metadata = PaginationMetadata.builder()
                .totalSize(regionPage.getTotalElements())
                .startIndex(startIndex)
                .batchSize(batchSize)
                .link("/country_region?countryId=" + countryId + BATCH_SIZE_PARAM + batchSize + "&startIndex=" + startIndex)
                .build();
        
        return CountryRegionResponseDTO.builder()
                .data(regionDTOs)
                .metadata(metadata)
                .build();
    }

    @Override
    public LanguageResponseDTO getLanguages(int startIndex, int batchSize) {
        log.info("Fetching languages with startIndex: {} and batchSize: {}", startIndex, batchSize);

        int pageNumber = startIndex - 1;
        if (pageNumber < 0) {
            pageNumber = 0;
        }

        Pageable pageable = PageRequest.of(pageNumber, batchSize);
        Page<Language> languagePage = languageRepository.findAll(pageable);

        List<LanguageDTO> languageDTOs = languageMapper.entityToDTOList(languagePage.getContent());

        PaginationMetadata metadata = PaginationMetadata.builder()
                .totalSize(languagePage.getTotalElements())
                .startIndex(startIndex)
                .batchSize(batchSize)
                .link("/language?startIndex=" + startIndex + BATCH_SIZE_PARAM + batchSize)
                .build();

        return LanguageResponseDTO.builder()
                .data(languageDTOs)
                .metadata(metadata)
                .build();
    }
}