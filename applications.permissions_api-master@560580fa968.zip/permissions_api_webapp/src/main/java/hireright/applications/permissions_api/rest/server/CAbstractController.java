package hireright.applications.permissions_api.rest.server;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-16  HRG-330191 initial version
 */

import hireright.applications.permissions_api.api.IPermissionsApi;
import hireright.applications.permissions_api.api.IPermissionsApiProvider;

public abstract class CAbstractController
{
	private final IPermissionsApiProvider m_apiProvider;

	protected CAbstractController(IPermissionsApiProvider apiProvider)
	{
		m_apiProvider = apiProvider;
	}

	protected IPermissionsApi getApi()
	{
		return m_apiProvider.getApi();
	}
}
