/*
 *
 * Copyright 2001-2018 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	T.Prikk			2018-03-09		HIVPE-25354: Vendor API end-point for sharing order properties btwn instances
 *	J.Zaporozhets	2023-12-20		HRG-147471 allowContacttoApplicant multiply calling fix
 */
package hireright.applications.vendor_api.resources;

import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import hireright.applications.vendor_api.EExchangeDirection;
import hireright.applications.vendor_api.exchange.handler.utils.CExchangeUtils;
import hireright.applications.vendor_api.facades.IdValueFacade;
import hireright.components.domain.dialects.vendor_api.BasicResponse;
import hireright.components.domain.dialects.vendor_api.NameValue;
import hireright.objects.order2.COrder;
import hireright.objects.order2.COrderProperty;
import hireright.objects.order2.loaders.COrderLoader;
import hireright.sdk.db.CMultitenantDB;
import hireright.sdk.db3.DB;
import hireright.sdk.util.CRuntimeException;

/**
 * See COrderPropertyExchangeHandler in event_reactor_handlers.
 */
@RestController
public class COrderPropertyResource extends AResource
{
	@RequestMapping(path = "/orders/{orderRef}/properties",
			method = RequestMethod.PUT,
			produces = MediaType.APPLICATION_XML_VALUE,
			consumes = MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity<BasicResponse> createOrUpdateOrderProperty(
			@PathVariable(name="orderRef") final String sOrderRef,
			@RequestBody NameValue nameValue) throws Exception
	{
		String sTenantCode = CExchangeUtils.getTenantCodeByOrderCode(sOrderRef);
		
		return CMultitenantDB.execute(sTenantCode, () -> {
			return DB.execute(new Callable<ResponseEntity<BasicResponse>>()
			{
				public ResponseEntity<BasicResponse> call() throws Exception
				{
					DB.requestTransaction();
					
					IdValueFacade references = new IdValueFacade(nameValue.getReferences().getIdValues());
					EExchangeDirection direction = EExchangeDirection.valueOf(
						references.value(EExchangeDirection.PROPERTY_NAME));
					
					COrder orderInfo = COrderLoader.find(sOrderRef);
					if (direction == EExchangeDirection.HOST_TO_VENDOR)
					{
						// local order = VENDOR
						setOrderProperty(orderInfo.getID(), nameValue.getName(), nameValue.getValue());
					}
					else if (direction == EExchangeDirection.VENDOR_TO_HOST)
					{
						throw new UnsupportedOperationException();
					}
					
					return new ResponseEntity<BasicResponse>(new BasicResponse(), HttpStatus.OK);
				}
			});
		});
	}

	/**
	 * Creates or updates the specified order property; requires DB context.
	 */
	private void setOrderProperty(Long nOrderID, String sPropertyName, String sPropertyValue)
	{
		COrderProperty updatedOrderProp = COrderProperty.loadPropertyByName(nOrderID, sPropertyName);
		if (updatedOrderProp != null)
		{
			updatedOrderProp.setValue(sPropertyValue);
			DB.session().update(updatedOrderProp);
		}
		else
		{
			try
			{
				COrderProperty.saveProperty(nOrderID, sPropertyName, sPropertyValue);
			}
			catch(CRuntimeException ex)
			{
			}
			
		}
		
	}
}
