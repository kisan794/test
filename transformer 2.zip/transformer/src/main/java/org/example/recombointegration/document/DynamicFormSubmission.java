package org.example.recombointegration.document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.index.Indexed;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * MongoDB document for storing dynamic form submissions.
 * This flexible structure can store any form data based on the form configuration.
 *
 * @author Generated
 * @version 1.0
 */
@Document(collection = "dynamic_form_submissions")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DynamicFormSubmission {

    @Id
    private String id;

    /**
     * Reference to the form template used for this submission
     */
    @Indexed
    private String formId;

    /**
     * Version of the form template used
     */
    private String formVersion;

    /**
     * Email address of the submitter (if captured)
     */
    @Indexed
    private String emailAddress;

    /**
     * Dynamic form data stored as key-value pairs
     * Key = fieldKey from form configuration
     * Value = submitted value (can be String, List, Number, etc.)
     */
    private Map<String, Object> formData;

    /**
     * Submission status
     */
    @Indexed
    @Builder.Default
    private SubmissionStatus status = SubmissionStatus.SUBMITTED;

    /**
     * Workflow tracking
     */
    private String assignedTo;
    private String reviewedBy;
    private LocalDateTime reviewedAt;
    private String reviewComments;

    /**
     * Engagement metrics
     */
    @Builder.Default
    private Integer upvoteCount = 0;

    @Builder.Default
    private List<String> upvotedBy = new ArrayList<>();

    /**
     * Comments on the submission
     */
    @Builder.Default
    private List<SubmissionComment> comments = new ArrayList<>();

    /**
     * Audit fields
     */
    @Indexed
    private LocalDateTime submissionDate;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    /**
     * Metadata
     */
    private Map<String, Object> metadata;

    /**
     * Submission status enum
     */
    public enum SubmissionStatus {
        DRAFT("Draft"),
        SUBMITTED("Submitted"),
        UNDER_REVIEW("Under Review"),
        APPROVED("Approved"),
        IMPLEMENTED("Implemented"),
        COMPLETED("Completed"),
        REJECTED("Rejected"),
        ON_HOLD("On Hold");

        private final String description;

        SubmissionStatus(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

    /**
     * Embedded comment class
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SubmissionComment {
        private String id;
        private String commenterName;
        private String commenterEmail;
        private String comment;
        private LocalDateTime createdAt;
    }
}

