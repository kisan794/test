/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-07-23	Created
 *	T.Prikk		2017-08-09	HIVPE-19903: Added domain ID
 */
package hireright.applications.vendor_api.model;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Response")
public class CExchangeResponse
{
	private String reference;

	@XmlElement(name="Reference")
	public String getReference()
	{
		return reference;
	}

	public void setReference(String reference)
	{
		this.reference = reference;
	}

	public CExchangeResponse() {}

	public CExchangeResponse(String reference)
	{
		this.reference = reference;
	}
}
