package hireright.applications.permissions_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-17  HRG-330191 initial version
 */

public class COperatorResources extends CResources<COperator>
{
	private COperatorResources()
	{
		super();
	}

	protected COperatorResources(Builder builder)
	{
		super(builder);
	}

	@Override
	public String toString()
	{
		return "COperatorResources{} " + super.toString();
	}

	public static class Builder extends CResources.Builder<COperator>
	{
		public Builder()
		{
			super();
		}

		public Builder(CResources<COperator> copy)
		{
			super(copy);
		}

		public Builder(COperatorResources copy)
		{
			super(copy);
		}

		@Override
		public COperatorResources build()
		{
			super.build();
			kind(EKind.operator);

			return new COperatorResources(this);
		}
	}
}
