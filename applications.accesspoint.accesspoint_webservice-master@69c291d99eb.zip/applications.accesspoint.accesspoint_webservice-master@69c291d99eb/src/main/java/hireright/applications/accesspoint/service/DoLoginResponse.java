/*
 * @(#)$RCSfile: DoLoginResponse.java,v $ $Revision: 1.2 $ $Date: 2014/07/28 14:56:59 $
 * $Author: aputintsev $
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/service/DoLoginResponse.java,v $
 *
 * Copyright 2006-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * Toha Bakanovsky	2009-08-06	Created
 */
package hireright.applications.accesspoint.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for doLoginResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="doLoginResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="return" type="{http://hireright.com/applications/accesspoint/service}EntryPointType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "doLoginResponse", propOrder = {
		"_return"
})
public class DoLoginResponse {

		@XmlElement(name = "return")
		protected CEntryPointBean _return;

		/**
		 * Gets the value of the return property.
		 * 
		 * @return
		 *     possible object is
		 *     {@link EntryPointType }
		 *     
		 */
		public CEntryPointBean getReturn() {
				return _return;
		}

		/**
		 * Sets the value of the return property.
		 * 
		 * @param value
		 *     allowed object is
		 *     {@link EntryPointType }
		 *     
		 */
		public void setReturn(CEntryPointBean value) {
				this._return = value;
		}

}
