/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	msuhhoruki	2017-06-16	Created
 */
package hireright.applications.vendor_api.model;

import java.util.List;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementWrapper;
import jakarta.xml.bind.annotation.XmlRootElement;

import hireright.objects.order3.model.CNameValue;

/**
 * 
 */
@XmlRootElement(name="ScreeningResponse")
public class CScreeningResponse
{
	private List<CNameValue> clientReferences;
	
	@XmlElementWrapper(name="ClientReferences")
	@XmlElement(name="IdValue")
	public List<CNameValue> getClientReferences()
	{
		return this.clientReferences;
	}
	
	public void setClientReferences(List<CNameValue> clientReferences)
	{
		this.clientReferences = clientReferences;
	}
}
