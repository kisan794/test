package com.hireright.sourceintelligence.exception;

import com.hireright.sourceintelligence.api.dto.notification.NotificationResponseDTO;
import com.hireright.sourceintelligence.api.dto.notification.NotificationStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;
import java.util.stream.Collectors;

/**
 * Global exception handler for notification-related exceptions.
 * Provides consistent error responses across the notification API.
 */
@Slf4j
@RestControllerAdvice
public class NotificationExceptionHandler {
    
    /**
     * Handles email validation exceptions
     */
    @ExceptionHandler(EmailValidationException.class)
    public ResponseEntity<NotificationResponseDTO> handleEmailValidationException(
            EmailValidationException ex) {
        
        log.warn("Email validation failed: {}", ex.getMessage());
        
        NotificationResponseDTO response = NotificationResponseDTO.builder()
                .status(NotificationStatus.FAILED)
                .message("Email validation failed")
                .errorCode(ex.getErrorCode())
                .errorDetails(ex.getMessage())
                .field(ex.getField())
                .timestamp(Instant.now().toString())
                .build();
        
        // Determine appropriate HTTP status
        HttpStatus status = determineValidationErrorStatus(ex.getMessage());
        
        return ResponseEntity.status(status).body(response);
    }
    
    /**
     * Handles circuit breaker open exceptions
     */
    @ExceptionHandler(CircuitBreakerOpenException.class)
    public ResponseEntity<NotificationResponseDTO> handleCircuitBreakerOpenException(
            CircuitBreakerOpenException ex) {
        
        log.error("Circuit breaker open: {}", ex.getMessage());
        
        NotificationResponseDTO response = NotificationResponseDTO.builder()
                .status(NotificationStatus.FAILED)
                .message("Email service temporarily unavailable")
                .errorCode(ex.getErrorCode())
                .errorDetails(ex.getMessage())
                .retryAfter(ex.getRetryAfter())
                .circuitState("OPEN")
                .failureRate(ex.getFailureRate())
                .timestamp(Instant.now().toString())
                .build();
        
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(response);
    }
    
    /**
     * Handles generic notification exceptions
     */
    @ExceptionHandler(NotificationException.class)
    public ResponseEntity<NotificationResponseDTO> handleNotificationException(
            NotificationException ex) {
        
        log.error("Notification error: {}", ex.getMessage(), ex);
        
        NotificationResponseDTO response = NotificationResponseDTO.builder()
                .status(NotificationStatus.FAILED)
                .message("Notification failed")
                .errorCode(ex.getErrorCode())
                .errorDetails(ex.getMessage())
                .field(ex.getField())
                .timestamp(Instant.now().toString())
                .build();
        
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
    }
    
    /**
     * Handles Bean Validation exceptions
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<NotificationResponseDTO> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex) {
        
        log.warn("Validation failed: {}", ex.getMessage());
        
        String errorDetails = ex.getBindingResult().getFieldErrors().stream()
                .map(error -> String.format("%s: %s", error.getField(), error.getDefaultMessage()))
                .collect(Collectors.joining(", "));
        
        FieldError firstError = ex.getBindingResult().getFieldErrors().isEmpty() 
                ? null 
                : ex.getBindingResult().getFieldErrors().get(0);
        
        NotificationResponseDTO response = NotificationResponseDTO.builder()
                .status(NotificationStatus.FAILED)
                .message("Validation failed")
                .errorCode("VALIDATION_ERROR")
                .errorDetails(errorDetails)
                .field(firstError != null ? firstError.getField() : null)
                .timestamp(Instant.now().toString())
                .build();
        
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
    }
    
    /**
     * Handles unexpected exceptions
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<NotificationResponseDTO> handleGenericException(Exception ex) {
        
        log.error("Unexpected error in notification system", ex);
        
        NotificationResponseDTO response = NotificationResponseDTO.builder()
                .status(NotificationStatus.FAILED)
                .message("An unexpected error occurred")
                .errorCode("INTERNAL_ERROR")
                .errorDetails("Please contact support if the problem persists")
                .timestamp(Instant.now().toString())
                .build();
        
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
    }
    
    /**
     * Determines appropriate HTTP status based on validation error message
     */
    private HttpStatus determineValidationErrorStatus(String errorMessage) {
        String lowerMessage = errorMessage.toLowerCase();
        
        if (lowerMessage.contains("blacklist") || lowerMessage.contains("whitelist")) {
            return HttpStatus.FORBIDDEN;
        } else if (lowerMessage.contains("size") || lowerMessage.contains("exceed")) {
            return HttpStatus.PAYLOAD_TOO_LARGE;
        } else {
            return HttpStatus.BAD_REQUEST;
        }
    }
}

