package hireright.applications.vendor_api.facades;
/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	2017-10-13	Created
 *	A.Logachyov	2018-08-23	Added documentTypeID
 *	M.Kuznetsov	2025-10-29	HRG-345322. Openjdk21-migration
 */
import hireright.components.domain.dialects.vendor_api.DocumentMetadata;

public class DocumentMetadataFacade {
    private static final String PARAM_FILE_NAME = "fileName";
    private static final String PARAM_STORAGE = "storage";
    private static final String PARAM_REFERENCE = "reference";
    private static final String PARAM_CONTENT_TYPE = "contentType";
    private static final String PARAM_DOCUMENT_TYPE_ID = "documentTypeID";

    private final DocumentMetadata m_documentMetadata;
    private final IdValueFacade m_idValues;

    public DocumentMetadataFacade() {
        this.m_documentMetadata = new DocumentMetadata();
        this.m_idValues = new IdValueFacade(this.m_documentMetadata.getIdValues());
    }

    public DocumentMetadataFacade(DocumentMetadata documentMetadata) {
        this.m_documentMetadata = documentMetadata;
        this.m_idValues = new IdValueFacade(this.m_documentMetadata.getIdValues());
    }

    public DocumentMetadata getDocumentMetadata() {
        this.m_documentMetadata.getIdValues().clear();
        this.m_documentMetadata.getIdValues().addAll(this.m_idValues.getAll());
        return this.m_documentMetadata;
    }

    public String getFileName() {
        return this.m_idValues.value(PARAM_FILE_NAME);
    }

    public String getStorage() {
        return this.m_idValues.value(PARAM_STORAGE);
    }

    public String getReference() {
        return this.m_idValues.value(PARAM_REFERENCE);
    }

    public String getContentType() {
        return this.m_idValues.value(PARAM_CONTENT_TYPE);
    }

    /*Builder methods*/

    public DocumentMetadataFacade fileName(String sFileName) {
        this.m_idValues.set(PARAM_FILE_NAME, sFileName);
        return this;
    }

    public DocumentMetadataFacade storage(String sStorage) {
        this.m_idValues.set(PARAM_STORAGE, sStorage);
        return this;
    }

    public DocumentMetadataFacade reference(String sReference) {
        this.m_idValues.set(PARAM_REFERENCE, sReference);
        return this;
    }

    public DocumentMetadataFacade contentType(String sContentType) {
        this.m_idValues.set(PARAM_CONTENT_TYPE, sContentType);
        return this;
    }

    public DocumentMetadataFacade documentTypeID(Long nDocumentTypeID) {
        this.m_idValues.set(PARAM_DOCUMENT_TYPE_ID, nDocumentTypeID != null ? String.valueOf(nDocumentTypeID) : null);
        return this;
    }

    public DocumentMetadataFacade parameter(String sName, String sValue) {
        this.m_idValues.set(sName, sValue);
        return this;
    }
}
