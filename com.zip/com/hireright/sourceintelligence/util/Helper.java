package com.hireright.sourceintelligence.util;

import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.EDUCATION_COLLECTION_PREFIX;
import static com.hireright.sourceintelligence.constants.ErrorConstants.CONFIDENCE_THRESHOLD_ERROR;
import static com.hireright.sourceintelligence.constants.ErrorConstants.UNKNOWN_ORGANIZATION;
import static com.hireright.sourceintelligence.domain.constants.Constants.SmartSearchKeys.NAME;
import static com.hireright.sourceintelligence.domain.constants.Constants.VENDORS.EQUIFAX_EDU;
import static com.hireright.sourceintelligence.domain.constants.Constants.VENDORS.NSCH;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.*;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.IN_PROGRESS;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.COUNTRY;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowInvalidRequest;

public class Helper {

    private Helper() {
        throw new IllegalStateException("Helper class");
    }
    public static String getCollectionName(String source, String suffix) {
        String prefix = "";
            String sourceType = source.trim().toUpperCase();
            if(sourceType.contains(HON_EMPLOYMENT_PREFIX) || sourceType.equals(OrganizationType.EMPLOYMENT.toString())){
                prefix = EMPLOYMENT_COLLECTION_PREFIX;
            }else if(sourceType.contains(HON_EDUCATION_PREFIX) || sourceType.equals(OrganizationType.EDUCATION.toString())){
                prefix = EDUCATION_COLLECTION_PREFIX;
            }else{
                logAndThrowInvalidRequest(UNKNOWN_ORGANIZATION, null, source);
            }
        return prefix+suffix;
    }

    public static String getIndexName(String organizationType){
        String indexName = EMPLOYMENT_COLLECTION_PREFIX;
        if(organizationType.equals(OrganizationType.EDUCATION.getType())){
            indexName = EDUCATION_COLLECTION_PREFIX;
        }
        return indexName + SOURCE_COLLECTION_SUFFIX;
    }


    public static void validateThresholdLimit(Double confidenceThreshold){
        if (confidenceThreshold != null
                && (confidenceThreshold < MIN_CONFIDENCE_THRESHOLD_ALLOWED || confidenceThreshold > 100)) {
            logAndThrowInvalidRequest(CONFIDENCE_THRESHOLD_ERROR, null, confidenceThreshold);
        }
    }


    public static Map<String, String> prepareSearchFilters(String organizationName, String city, String country,
                                                     String state) {
        Map<String, String> searchFilters = new HashMap<>();
        searchFilters.put(ORGANIZATION_NAME, organizationName);
        if (StringUtils.hasText(city) && StringUtils.hasText(country) && StringUtils.hasText(state)) {
            searchFilters.put(CITY, city);
            searchFilters.put(COUNTRY, country);
            searchFilters.put(STATE, state);
        } else if (StringUtils.hasText(country) && StringUtils.hasText(state)) {
            searchFilters.put(COUNTRY, country);
            searchFilters.put(STATE, state);
        } else if (StringUtils.hasText(country) && StringUtils.hasText(city)) {
            searchFilters.put(CITY, city);
            searchFilters.put(COUNTRY, country);
        } else if (StringUtils.hasText(country)) {
            searchFilters.put(COUNTRY, country);
        }
        return searchFilters;
    }

    public static ApprovalStatus fromAction(String action) {
        return switch (action) {
            case ACTION_SAVE, ACTION_DELETE -> PENDING_APPROVAL;
            case ACTION_SAVE_AND_USE -> SAVE_PENDING_APPROVAL;
            case ACTION_APPROVED -> APPROVED;
            case ACTION_REJECTED -> REJECTED;
            case ACTION_ON_HOLD -> ONHOLD;
            case ACTION_IN_PROGRESS -> IN_PROGRESS;
            default -> null;
        };
    }

    public static ApprovalStatus fromActionForApprovalFlow(String action) {
        return switch (action) {
            case ACTION_APPROVED -> APPROVED;
            case ACTION_REJECTED -> REJECTED;
            case ACTION_ON_HOLD -> ONHOLD;
            default -> null;
        };
    }


    public static String convertToTitleCase(String input){
        String[] words = input.toLowerCase().split("\\s+");
        StringBuilder titleCase = new StringBuilder();
        for (String word : words) {
            if (!word.isEmpty()) {
                word = word.trim();
                titleCase.append(Character.toUpperCase(word.charAt(0)))
                        .append(word.substring(1))
                        .append(" ");
            }
        }
        return titleCase.toString().trim();
    }

    public static String removeExtraSpaces(String input){
        String[] words = input.split("\\s+");
        String result = input;
        if(words.length > 1){
            StringBuilder titleCase = new StringBuilder();
            for (String word : words) {
                if (!word.isEmpty()) {
                    titleCase.append(word.trim()).append(" ");
                }
            }
            result = titleCase.toString();
        }
        return result.trim();
    }

    public static String getOrganizationType(String hon){
        String organizationType = OrganizationType.EMPLOYMENT.toString();
        if(hon.contains(HON_EDUCATION_PREFIX)){
            organizationType = OrganizationType.EDUCATION.toString();
        }
        return organizationType;
    }

    public static boolean checkIsSkipApprovalFlow(Source sourceOrganizationDTO, Source entity) {
        List<String> diff = DeepDiffUtil.findChangedFields(sourceOrganizationDTO, entity);
        return !diff.isEmpty() && diff.contains(ORGANIZATION_ALIAS);
    }

    public static boolean checkIsAutoApproval(Source sourceOrganizationDTO, Source entity) {
        List<String> diff = DeepDiffUtil.findChangedFields(sourceOrganizationDTO, entity);
        return diff.size() == 1 && diff.getFirst().equals(PAYLOAD_VERIFICATION_VALIDATION_DATE);
    }

    public static void automatedServiceFlip(List<Map<String, Object>> contactDetailsDTOS){
        int nschIndex = 0;
        int equifaxIndex = 0;
        for (int i = 0; i < contactDetailsDTOS.size(); i++) {
            Map<String, Object> contactDetailsDTO = contactDetailsDTOS.get(i);
            String name = (String) contactDetailsDTO.get(NAME);
            if(name.equalsIgnoreCase(NSCH)){
                nschIndex = i;
            }else if(name.equalsIgnoreCase(EQUIFAX_EDU)){
                equifaxIndex = i;
            }
        }
        if(equifaxIndex < nschIndex){
            Map<String,Object> nsch = contactDetailsDTOS.get(nschIndex);
            Map<String,Object> equifax = contactDetailsDTOS.get(equifaxIndex);
            contactDetailsDTOS.set(nschIndex,equifax);
            contactDetailsDTOS.set(equifaxIndex,nsch);
        }
    }
}
