package org.example.recombointegration.repository;

import org.example.recombointegration.document.FormFieldConfig;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * MongoDB repository for FormFieldConfig documents.
 * Provides database operations for form field configurations.
 *
 * @author Generated
 * @version 1.0
 */
@Repository
public interface FormFieldConfigRepository extends MongoRepository<FormFieldConfig, String> {

    /**
     * Find configuration by field key.
     */
    Optional<FormFieldConfig> findByFieldKey(String fieldKey);

    /**
     * Find all active configurations.
     */
    List<FormFieldConfig> findByActiveTrue();

    /**
     * Find configurations by section.
     */
    List<FormFieldConfig> findBySection(String section);

    /**
     * Find active configurations by section.
     */
    List<FormFieldConfig> findBySectionAndActiveTrue(String section);

    /**
     * Find all configurations ordered by display order.
     */
    List<FormFieldConfig> findAllByOrderByDisplayOrderAsc();

    /**
     * Find active configurations ordered by display order.
     */
    List<FormFieldConfig> findByActiveTrueOrderByDisplayOrderAsc();

    /**
     * Check if field key exists.
     */
    boolean existsByFieldKey(String fieldKey);
}

