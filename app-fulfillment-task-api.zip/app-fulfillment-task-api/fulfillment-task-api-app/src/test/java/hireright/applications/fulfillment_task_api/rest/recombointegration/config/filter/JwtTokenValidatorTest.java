/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.config.filter;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit tests for JwtTokenValidator
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("JwtTokenValidator Tests")
class JwtTokenValidatorTest
{

	private JwtTokenValidator validator;
	private String secretKey;
	private SecretKey key;

	@BeforeEach
	void setUp()
	{
		validator = new JwtTokenValidator();
		secretKey =
			"test-secret-key-that-is-long-enough-for-hmac-sha-256-algorithm-minimum-256-bits";
		key = Keys.hmacShaKeyFor(secretKey.getBytes(StandardCharsets.UTF_8));

		// Set secret key using reflection
		org.springframework.test.util.ReflectionTestUtils.setField(validator, "jwtSecret",
			secretKey);
	}

	@Test
	@DisplayName("Should validate valid JWT token successfully")
	void testValidateValidToken()
	{
		// Given
		String token = Jwts.builder()
			.subject("test-user")
			.issuer("test-issuer")
			.issuedAt(new Date())
			.expiration(new Date(System.currentTimeMillis() + 3600000)) // 1 hour
			.signWith(key)
			.compact();

		// When
		boolean isValid = validator.validateToken(token);

		// Then
		assertTrue(isValid);
	}

	@Test
	@DisplayName("Should validate token without expiration")
	void testValidateTokenWithoutExpiration()
	{
		// Given - token without expiration claim
		String token = Jwts.builder()
			.subject("test-user")
			.issuer("test-issuer")
			.issuedAt(new Date())
			.signWith(key)
			.compact();

		// When
		boolean isValid = validator.validateToken(token);

		// Then
		assertTrue(isValid);
	}

	@Test
	@DisplayName("Should validate token with future issued date")
	void testValidateTokenWithFutureIssuedDate()
	{
		// Given - token issued in the future (should still be valid if not expired)
		String token = Jwts.builder()
			.subject("test-user")
			.issuer("test-issuer")
			.issuedAt(new Date(System.currentTimeMillis() + 60000)) // 1 minute in future
			.expiration(new Date(System.currentTimeMillis() + 3600000)) // 1 hour
			.signWith(key)
			.compact();

		// When
		boolean isValid = validator.validateToken(token);

		// Then
		assertTrue(isValid);
	}

	@Test
	@DisplayName("Should validate token with minimum required claims")
	void testValidateTokenWithMinimumClaims()
	{
		// Given - token with only subject
		String token = Jwts.builder().subject("test-user").signWith(key).compact();

		// When
		boolean isValid = validator.validateToken(token);

		// Then
		assertTrue(isValid);
	}

	@Test
	@DisplayName("Should handle token with special characters in claims")
	void testValidateTokenWithSpecialCharactersInClaims()
	{
		// Given
		Map<String, Object> claims = new HashMap<>();
		claims.put("name", "Test User @#$%");
		claims.put("email", "test+user@example.com");

		String token = Jwts.builder()
			.subject("test-user")
			.claims(claims)
			.issuedAt(new Date())
			.expiration(new Date(System.currentTimeMillis() + 3600000))
			.signWith(key)
			.compact();

		// When
		boolean isValid = validator.validateToken(token);

		// Then
		assertTrue(isValid);
	}

	@Test
	@DisplayName("Should validate token with audience claim")
	void testValidateTokenWithAudience()
	{
		// Given
		String token = Jwts.builder()
			.subject("test-user")
			.audience()
			.add("api-service")
			.and()
			.issuedAt(new Date())
			.expiration(new Date(System.currentTimeMillis() + 3600000))
			.signWith(key)
			.compact();

		// When
		boolean isValid = validator.validateToken(token);

		// Then
		assertTrue(isValid);
	}
}
