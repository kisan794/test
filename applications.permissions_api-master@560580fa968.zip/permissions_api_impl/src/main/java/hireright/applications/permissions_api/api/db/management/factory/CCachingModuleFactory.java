package hireright.applications.permissions_api.api.db.management.factory;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-02-05  HRG-330191 initial version
 */

import hireright.objects.permissions2.CModule;
import hireright.objects.permissions2.CModuleFactory;
import hireright.sdk.util.CStringUtils;
import hireright.sdkex.as_cache.CCache;

import java.util.Arrays;
import java.util.Collection;

public class CCachingModuleFactory
{
	private static final CCache<CModule> CACHE = new CCache<>(CModule.class);

	public static final String MODE_CREATE = "CREATE";
	public static final String MODE_READ = "VIEW";
	public static final String MODE_UPDATE = "MODIFY";
	public static final String MODE_DELETE = "DELETE";

	private static final Collection<String> MODES =
		Arrays.asList(MODE_CREATE, MODE_READ, MODE_UPDATE, MODE_DELETE);

	public static CModule getModule(String sModule)
	{
		if(CStringUtils.isEmpty(sModule))
		{
			return null;
		}

		try
		{
			return CACHE.get(sModule, () -> getModuleNoCache(sModule));
		}
		catch(Exception ignored)
		{
			return getModuleNoCache(sModule);
		}
	}

	private static CModule getModuleNoCache(String sModule)
	{
		CModule module = null;
		if(CStringUtils.isNumber(sModule))
		{
			module = CModuleFactory.getModule(Integer.parseInt(sModule));
		}

		if(module == null)
		{
			module = CModuleFactory.getModule(sModule);
		}

		if(module == null)
		{
			String sLabel = sModule;

			String sMode =
				MODES.stream().filter(s -> sModule.endsWith("." + s)).findFirst().orElse(null);

			if(!CStringUtils.isEmpty(sMode))
			{
				int nIndex = sModule.lastIndexOf(sMode);
				sLabel = nIndex > 0 ? sLabel.substring(0, nIndex - 1) : sLabel;
			}

			module = CModuleFactory.getModule(sLabel);
		}

		return module;
	}
}
