package com.hireright.sourceintelligence.service.excel;

import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

@Getter
public class ExcelColumnMapping {

    private final Map<String, Integer> columnMap;
    private final int headerRowIndex;
    private final int dataStartRowIndex;
    private final int sheetIndex;

    private ExcelColumnMapping(Builder builder) {
        this.columnMap = new HashMap<>(builder.columnMap);
        this.headerRowIndex = builder.headerRowIndex;
        this.dataStartRowIndex = builder.dataStartRowIndex;
        this.sheetIndex = builder.sheetIndex;
    }

    public Integer getColumnIndex(String fieldName) {
        return columnMap.get(fieldName);
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private final Map<String, Integer> columnMap = new HashMap<>();
        private int headerRowIndex = 0;
        private int dataStartRowIndex = 1;
        private int sheetIndex = 0;

        public Builder addColumn(String fieldName, int columnIndex) {
            this.columnMap.put(fieldName, columnIndex);
            return this;
        }

        public Builder headerRowIndex(int headerRowIndex) {
            this.headerRowIndex = headerRowIndex;
            return this;
        }

        public Builder dataStartRowIndex(int dataStartRowIndex) {
            this.dataStartRowIndex = dataStartRowIndex;
            return this;
        }

        public Builder sheetIndex(int sheetIndex) {
            this.sheetIndex = sheetIndex;
            return this;
        }

        public ExcelColumnMapping build() {
            return new ExcelColumnMapping(this);
        }
    }
}