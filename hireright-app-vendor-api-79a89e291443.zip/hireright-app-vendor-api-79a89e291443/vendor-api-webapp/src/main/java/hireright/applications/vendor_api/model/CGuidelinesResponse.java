/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-08-18	Created
 */
package hireright.applications.vendor_api.model;

import java.util.List;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementWrapper;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="GuidelinesResponse")
public class CGuidelinesResponse
{
	private CCustomerDTO customerData;
	private List<CGuidelineDTO> guidelines;

	@XmlElement(name="Customer")
	public CCustomerDTO getCustomer()
	{
		return customerData;
	}

	public void setCustomer(CCustomerDTO customerData)
	{
		this.customerData = customerData;
	}

	@XmlElementWrapper(name="Guidelines")
	@XmlElement(name="Guideline")
	public List<CGuidelineDTO> getGuidelines()
	{
		return guidelines;
	}

	public void setGuidelines(List<CGuidelineDTO> guidelines)
	{
		this.guidelines = guidelines;
	}
}
