package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.rds.CountryDTO;
import com.hireright.sourceintelligence.api.dto.rds.CountryRegionDTO;
import com.hireright.sourceintelligence.domain.entity.Country;
import com.hireright.sourceintelligence.domain.entity.CountryRegion;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class CountryMapperTest {

    private final CountryMapper mapper = Mappers.getMapper(CountryMapper.class);

    @Test
    void convertBigDecimalToString_shouldReturnZeroWhenNull() {
        assertEquals("0", mapper.convertBigDecimalToString(null));
    }

    @Test
    void convertBigDecimalToString_shouldStripTrailingZeros() {
        assertEquals("123.45", mapper.convertBigDecimalToString(new BigDecimal("123.4500")));
        assertEquals("100", mapper.convertBigDecimalToString(new BigDecimal("100.000")));
    }

    @Test
    void convertIntegerToString_shouldReturnNullWhenValueIsNull() {
        assertNull(mapper.convertIntegerToString(null));
    }

    @Test
    void convertIntegerToString_shouldReturnStringWhenValueExists() {
        assertEquals("25", mapper.convertIntegerToString(25));
    }

    @Test
    void createTimestampObject_shouldReturnNullWhenTimestampIsNull() {
        assertNull(mapper.createTimestampObject(null));
    }

    @Test
    void createTimestampObject_shouldReturnNullWhenTimestampLiteralNull() {
        assertNull(mapper.createTimestampObject("null"));
    }

    @Test
    void createTimestampObject_shouldReturnMapWhenTimestampIsValid() {
        Object result = mapper.createTimestampObject("2026-03-31T10:15:30Z");

        assertNotNull(result);
        assertInstanceOf(Map.class, result);

        @SuppressWarnings("unchecked")
        Map<String, String> timestampMap = (Map<String, String>) result;
        assertEquals("2026-03-31T10:15:30Z", timestampMap.get("$timestamp"));
        assertEquals(1, timestampMap.size());
    }

    @Test
    void entityToDTO_shouldMapAllFields() {
        Country entity = new Country();
        entity.setCountryId(new BigDecimal("101.000"));
        entity.setName("India");
        entity.setCourtIntlCharge(new BigDecimal("10.500"));
        entity.setEduIntlCharge(new BigDecimal("20.000"));
        entity.setEmplIntlCharge(new BigDecimal("30.1000"));
        entity.setMvrIntlCharge(new BigDecimal("40.000"));
        entity.setRefIntlCharge(new BigDecimal("50.5500"));
        entity.setCurrency("INR");
        entity.setDateFormat("dd/MM/yyyy");
        entity.setPhoneCountryCode("+91");
        entity.setSsnEquivalent("AADHAR");
        entity.setStateEquivalent("State");
        entity.setZipEquivalent("PIN");
        entity.setCourtSearchLevel("National");
        entity.setDobRequired("Y");
        entity.setTimezone(new BigDecimal("5.500"));
        entity.setDobInquiry("Y");
        entity.setNidInquiry("N");
        entity.setNidRequired("Y");
        entity.setBirthPlaceRequired("N");
        entity.setBirthPlaceSendToVerifier("Y");
        entity.setObsolete("N");
        entity.setFinanceRegion("APAC");
        entity.setSupportRegion("APAC-SUPPORT");
        entity.setTable("COUNTRY");
        entity.setScn("12345");
        entity.setOpType("I");
        entity.setOpTs("2026-03-31T12:00:00Z");
        entity.setCurrentTs("2026-03-31T12:30:00Z");
        entity.setRowId("ROW123");
        entity.setUsername("tester");

        CountryDTO dto = mapper.entityToDTO(entity);

        assertNotNull(dto);
        assertEquals("101", dto.getCountryId());
        assertEquals("India", dto.getName());
        assertEquals("10.5", dto.getCourtIntlCharge());
        assertEquals("20", dto.getEduIntlCharge());
        assertEquals("30.1", dto.getEmplIntlCharge());
        assertEquals("40", dto.getMvrIntlCharge());
        assertEquals("50.55", dto.getRefIntlCharge());
        assertEquals("INR", dto.getCurrency());
        assertEquals("dd/MM/yyyy", dto.getDateFormat());
        assertEquals("+91", dto.getPhoneCountryCode());
        assertEquals("AADHAR", dto.getSsnEquivalent());
        assertEquals("State", dto.getStateEquivalent());
        assertEquals("PIN", dto.getZipEquivalent());
        assertEquals("National", dto.getCourtSearchLevel());
        assertEquals("Y", dto.getDobRequired());
        assertEquals("5.5", dto.getTimezone());
        assertEquals("Y", dto.getDobInquiry());
        assertEquals("N", dto.getNidInquiry());
        assertEquals("Y", dto.getNidRequired());
        assertEquals("N", dto.getBirthPlaceRequired());
        assertEquals("Y", dto.getBirthPlaceSendToVerifier());
        assertEquals("N", dto.getObsolete());
        assertEquals("APAC", dto.getFinanceRegion());
        assertEquals("APAC-SUPPORT", dto.getSupportRegion());
        assertEquals("COUNTRY", dto.getTable());
        assertEquals("12345", dto.getScn());
        assertEquals("I", dto.getOpType());
        assertEquals("ROW123", dto.getRowId());
        assertEquals("tester", dto.getUsername());

        assertInstanceOf(Map.class, dto.getOpTs());
        assertInstanceOf(Map.class, dto.getCurrentTs());

        @SuppressWarnings("unchecked")
        Map<String, String> opTs = (Map<String, String>) dto.getOpTs();
        @SuppressWarnings("unchecked")
        Map<String, String> currentTs = (Map<String, String>) dto.getCurrentTs();

        assertEquals("2026-03-31T12:00:00Z", opTs.get("$timestamp"));
        assertEquals("2026-03-31T12:30:00Z", currentTs.get("$timestamp"));
    }

    @Test
    void entityToDTO_shouldHandleNullConversions() {
        Country entity = new Country();
        entity.setCountryId(null);
        entity.setCourtIntlCharge(null);
        entity.setEduIntlCharge(null);
        entity.setEmplIntlCharge(null);
        entity.setMvrIntlCharge(null);
        entity.setRefIntlCharge(null);
        entity.setTimezone(null);
        entity.setOpTs(null);
        entity.setCurrentTs("null");

        CountryDTO dto = mapper.entityToDTO(entity);

        assertNotNull(dto);
        assertEquals("0", dto.getCountryId());
        assertEquals("0", dto.getCourtIntlCharge());
        assertEquals("0", dto.getEduIntlCharge());
        assertEquals("0", dto.getEmplIntlCharge());
        assertEquals("0", dto.getMvrIntlCharge());
        assertEquals("0", dto.getRefIntlCharge());
        assertEquals("0", dto.getTimezone());
        assertNull(dto.getOpTs());
        assertNull(dto.getCurrentTs());
    }

    @Test
    void entityToDTOList_shouldMapList() {
        Country entity1 = new Country();
        entity1.setCountryId(new BigDecimal("1"));
        entity1.setName("India");

        Country entity2 = new Country();
        entity2.setCountryId(new BigDecimal("2"));
        entity2.setName("USA");

        List<CountryDTO> result = mapper.entityToDTOList(List.of(entity1, entity2));

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("1", result.get(0).getCountryId());
        assertEquals("India", result.get(0).getName());
        assertEquals("2", result.get(1).getCountryId());
        assertEquals("USA", result.get(1).getName());
    }

    @Test
    void entityToRegionDTO_shouldMapAllFields() {
        CountryRegion entity = new CountryRegion();
        entity.setRegionId(10);
        entity.setCountryId(20);
        entity.setOldRegionId(30);
        entity.setRegionName("Karnataka");
        entity.setParentId(40);
        entity.setRegionLevel(2);
        entity.setIso31662("IN-KA");
        entity.setObsolete("N");
        entity.setTable("COUNTRY_REGION");
        entity.setScn("999");
        entity.setOpType("U");
        entity.setOpTs("2026-03-31T08:00:00Z");
        entity.setCurrentTs("2026-03-31T09:00:00Z");
        entity.setRowId("ROW-REG-1");
        entity.setUsername("regionUser");
        entity.setHrCode("HR001");
        entity.setAreaCodes(List.of("080", "081"));

        CountryRegionDTO dto = mapper.entityToRegionDTO(entity);

        assertNotNull(dto);
        assertEquals("10", dto.getId());
        assertEquals("20", dto.getCountryId());
        assertEquals("30", dto.getOldRegionId());
        assertEquals("Karnataka", dto.getRegionName());
        assertEquals("40", dto.getParentId());
        assertEquals("2", dto.getRegionLevel());
        assertEquals("IN-KA", dto.getIso31662());
        assertEquals("N", dto.getObsolete());
        assertEquals("COUNTRY_REGION", dto.getTable());
        assertEquals("999", dto.getScn());
        assertEquals("U", dto.getOpType());
        assertEquals("ROW-REG-1", dto.getRowId());
        assertEquals("regionUser", dto.getUsername());
        assertEquals("HR001", dto.getHrCode());
        assertEquals(List.of("080", "081"), dto.getAreaCodes());

        assertInstanceOf(Map.class, dto.getOpTs());
        assertInstanceOf(Map.class, dto.getCurrentTs());

        @SuppressWarnings("unchecked")
        Map<String, String> opTs = (Map<String, String>) dto.getOpTs();
        @SuppressWarnings("unchecked")
        Map<String, String> currentTs = (Map<String, String>) dto.getCurrentTs();

        assertEquals("2026-03-31T08:00:00Z", opTs.get("$timestamp"));
        assertEquals("2026-03-31T09:00:00Z", currentTs.get("$timestamp"));
    }

    @Test
    void entityToRegionDTO_shouldHandleNullIntegerAndTimestampBranches() {
        CountryRegion entity = new CountryRegion();
        entity.setRegionId(null);
        entity.setCountryId(null);
        entity.setOldRegionId(null);
        entity.setParentId(null);
        entity.setRegionLevel(null);
        entity.setOpTs(null);
        entity.setCurrentTs("null");

        CountryRegionDTO dto = mapper.entityToRegionDTO(entity);

        assertNotNull(dto);
        assertNull(dto.getId());
        assertNull(dto.getCountryId());
        assertNull(dto.getOldRegionId());
        assertNull(dto.getParentId());
        assertNull(dto.getRegionLevel());
        assertNull(dto.getOpTs());
        assertNull(dto.getCurrentTs());
    }

    @Test
    void entityToRegionDTOList_shouldMapList() {
        CountryRegion entity1 = new CountryRegion();
        entity1.setRegionId(1);
        entity1.setRegionName("Region1");

        CountryRegion entity2 = new CountryRegion();
        entity2.setRegionId(2);
        entity2.setRegionName("Region2");

        List<CountryRegionDTO> result = mapper.entityToRegionDTOList(List.of(entity1, entity2));

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("1", result.get(0).getId());
        assertEquals("Region1", result.get(0).getRegionName());
        assertEquals("2", result.get(1).getId());
        assertEquals("Region2", result.get(1).getRegionName());
    }
}