package com.hireright.sourceintelligence.exception;



import lombok.Getter;

@Getter
public enum Location {

    US("US"), CANADA("CA"), LATAM("MX"), EMEA("GB");

    private final String value;

    Location(String value) {
        this.value = value;
    }

    public static String getLocationValueForSharding(String location) {
        return Location.valueOf(location).getValue();
    }
}
