package hireright.applications.vendor_api;
/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	2017-08-22	Created
 *	M.Kuznetsov	2025-10-29	HRG-345322. Openjdk21-migration
 */

public enum EVendorReference implements IReference {
    VENDOR_ORDER_REF("vendorOrderRef"),
    VENDOR_ORDER_SERVICE_REF("vendorOrderServiceRef"),
    VENDOR_INSTANCE_REF("vendorInstanceRef"),
    VENDOR_OBJECT_REF("vendorObjectRef");

    private final String parameterName;

    EVendorReference(String sParameterName) {
        this.parameterName = sParameterName;
    }

    public String getParameterName() {
        return this.parameterName;
    }

    public String getPropertyName() {
        return this.name();
    }
}
