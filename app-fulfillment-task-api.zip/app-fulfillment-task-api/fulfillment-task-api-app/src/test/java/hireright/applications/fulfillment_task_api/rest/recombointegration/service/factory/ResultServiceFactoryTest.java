package hireright.applications.fulfillment_task_api.rest.recombointegration.service.factory;

import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ResultService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl.EducationResultServiceImpl;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl.EmploymentResultServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for ResultServiceFactory
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("ResultServiceFactory Tests")
class ResultServiceFactoryTest {

    @Mock
    private EducationResultServiceImpl educationService;

    @Mock
    private EmploymentResultServiceImpl employmentService;

    private ResultServiceFactory factory;

    @Test
    @DisplayName("Should initialize factory with education and employment services")
    void testFactoryInitializationWithBothServices() {
        // Given
        List<ResultService> services = Arrays.asList(educationService, employmentService);

        // When
        factory = new ResultServiceFactory(services);

        // Then
        assertNotNull(factory);
    }

    @Test
    @DisplayName("Should initialize factory with only education service")
    void testFactoryInitializationWithEducationOnly() {
        // Given
        List<ResultService> services = Collections.singletonList(educationService);

        // When
        factory = new ResultServiceFactory(services);

        // Then
        assertNotNull(factory);
    }

    @Test
    @DisplayName("Should initialize factory with only employment service")
    void testFactoryInitializationWithEmploymentOnly() {
        // Given
        List<ResultService> services = Collections.singletonList(employmentService);

        // When
        factory = new ResultServiceFactory(services);

        // Then
        assertNotNull(factory);
    }

    @Test
    @DisplayName("Should initialize factory with empty service list")
    void testFactoryInitializationWithEmptyList() {
        // Given
        List<ResultService> services = Collections.emptyList();

        // When
        factory = new ResultServiceFactory(services);

        // Then
        assertNotNull(factory);
    }

    @Test
    @DisplayName("Should get education service by type string")
    void testGetEducationService() {
        // Given
        List<ResultService> services = Arrays.asList(educationService, employmentService);
        factory = new ResultServiceFactory(services);

        // When
        ResultService result = factory.getService("education");

        // Then
        assertNotNull(result);
        assertEquals(educationService, result);
    }

    @Test
    @DisplayName("Should get employment service by type string")
    void testGetEmploymentService() {
        // Given
        List<ResultService> services = Arrays.asList(educationService, employmentService);
        factory = new ResultServiceFactory(services);

        // When
        ResultService result = factory.getService("employment");

        // Then
        assertNotNull(result);
        assertEquals(employmentService, result);
    }

    @Test
    @DisplayName("Should handle case-insensitive type string")
    void testGetServiceCaseInsensitive() {
        // Given
        List<ResultService> services = Arrays.asList(educationService, employmentService);
        factory = new ResultServiceFactory(services);

        // When
        ResultService result1 = factory.getService("EDUCATION");
        ResultService result2 = factory.getService("Education");
        ResultService result3 = factory.getService("eDuCaTiOn");

        // Then
        assertEquals(educationService, result1);
        assertEquals(educationService, result2);
        assertEquals(educationService, result3);
    }

    @Test
    @DisplayName("Should handle employment type with different cases")
    void testGetEmploymentServiceCaseInsensitive() {
        // Given
        List<ResultService> services = Arrays.asList(educationService, employmentService);
        factory = new ResultServiceFactory(services);

        // When
        ResultService result1 = factory.getService("EMPLOYMENT");
        ResultService result2 = factory.getService("Employment");
        ResultService result3 = factory.getService("EmPlOyMeNt");

        // Then
        assertEquals(employmentService, result1);
        assertEquals(employmentService, result2);
        assertEquals(employmentService, result3);
    }

    @Test
    @DisplayName("Should throw exception for unknown type")
    void testGetServiceWithUnknownType() {
        // Given
        List<ResultService> services = Arrays.asList(educationService, employmentService);
        factory = new ResultServiceFactory(services);

        // When & Then
        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> factory.getService("criminal")
        );

        assertTrue(exception.getMessage().contains("Unknown result type"));
        assertTrue(exception.getMessage().contains("criminal"));
    }

    @Test
    @DisplayName("Should throw exception when service not registered")
    void testGetServiceWhenNotRegistered() {
        // Given
        List<ResultService> services = Collections.singletonList(educationService);
        factory = new ResultServiceFactory(services);

        // When & Then
        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> factory.getService("employment")
        );

        assertTrue(exception.getMessage().contains("Unknown result type"));
    }

    @Test
    @DisplayName("Should throw exception for null type")
    void testGetServiceWithNullType() {
        // Given
        List<ResultService> services = Arrays.asList(educationService, employmentService);
        factory = new ResultServiceFactory(services);

        // When & Then
        assertThrows(NullPointerException.class, () -> factory.getService(null));
    }

    @Test
    @DisplayName("Should throw exception for empty type string")
    void testGetServiceWithEmptyType() {
        // Given
        List<ResultService> services = Arrays.asList(educationService, employmentService);
        factory = new ResultServiceFactory(services);

        // When & Then
        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> factory.getService("")
        );

        assertTrue(exception.getMessage().contains("Unknown result type"));
    }

    @Test
    @DisplayName("Should handle type string with whitespace")
    void testGetServiceWithWhitespace() {
        // Given
        List<ResultService> services = Arrays.asList(educationService, employmentService);
        factory = new ResultServiceFactory(services);

        // When & Then - whitespace is not trimmed, so it should fail
        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> factory.getService("  education  ")
        );

        assertTrue(exception.getMessage().contains("Unknown result type"));
    }

    @Test
    @DisplayName("Should get correct service multiple times")
    void testGetServiceMultipleTimes() {
        // Given
        List<ResultService> services = Arrays.asList(educationService, employmentService);
        factory = new ResultServiceFactory(services);

        // When
        ResultService result1 = factory.getService("education");
        ResultService result2 = factory.getService("education");
        ResultService result3 = factory.getService("employment");
        ResultService result4 = factory.getService("employment");

        // Then
        assertEquals(educationService, result1);
        assertEquals(educationService, result2);
        assertEquals(employmentService, result3);
        assertEquals(employmentService, result4);
        assertSame(result1, result2);
        assertSame(result3, result4);
    }

    @Test
    @DisplayName("Should handle services registered in different order")
    void testServicesRegisteredInDifferentOrder() {
        // Given - employment first, then education
        List<ResultService> services = Arrays.asList(employmentService, educationService);
        factory = new ResultServiceFactory(services);

        // When
        ResultService eduResult = factory.getService("education");
        ResultService empResult = factory.getService("employment");

        // Then
        assertEquals(educationService, eduResult);
        assertEquals(employmentService, empResult);
    }

    @Test
    @DisplayName("Should handle duplicate service registration")
    void testDuplicateServiceRegistration() {
        // Given - two education services
        EducationResultServiceImpl duplicateEducationService = new EducationResultServiceImpl(null, null);
        List<ResultService> services = Arrays.asList(educationService, duplicateEducationService, employmentService);

        // When
        factory = new ResultServiceFactory(services);

        // Then - Last registered service should be used
        ResultService result = factory.getService("education");
        assertEquals(duplicateEducationService, result);
    }

    @Test
    @DisplayName("Should only register EducationResultServiceImpl and EmploymentResultServiceImpl")
    void testOnlyRegistersKnownServiceTypes() {
        // Given - include a generic ResultService that's neither Education nor Employment
        ResultService genericService = new ResultService() {};
        List<ResultService> services = Arrays.asList(educationService, employmentService, genericService);

        // When
        factory = new ResultServiceFactory(services);

        // Then - Only education and employment should be registered
        assertNotNull(factory.getService("education"));
        assertNotNull(factory.getService("employment"));
    }
}

