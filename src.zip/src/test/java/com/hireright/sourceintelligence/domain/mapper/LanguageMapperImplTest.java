package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.rds.LanguageDTO;
import com.hireright.sourceintelligence.domain.entity.Language;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class LanguageMapperImplTest {

    private LanguageMapperImpl mapper;

    @BeforeEach
    void setUp() {
        mapper = new LanguageMapperImpl();
    }

    @Test
    void entityToDTO_shouldReturnNull_whenEntityIsNull() {
        assertNull(mapper.entityToDTO(null));
    }

    @Test
    void entityToDTO_shouldMapAllFields_whenEntityHasValues() {
        Language entity = new Language();
        entity.setLanguageId(BigDecimal.valueOf(101));
        entity.setName("English");
        entity.setIso6391("en");
        entity.setIso6392t("eng");
        entity.setLanguageTag("en-US");

        LanguageDTO result = mapper.entityToDTO(entity);

        assertNotNull(result);
        assertEquals("101", result.getId());
        assertEquals("English", result.getName());
        assertEquals("en", result.getIso6391());
        assertEquals("eng", result.getIso6392t());
        assertEquals("en-US", result.getLanguageTag());
    }

    @Test
    void entityToDTO_shouldMapNullFields_whenOptionalValuesAreNull() {
        Language entity = new Language();
        entity.setLanguageId(null);
        entity.setName(null);
        entity.setIso6391(null);
        entity.setIso6392t(null);
        entity.setLanguageTag(null);

        LanguageDTO result = mapper.entityToDTO(entity);

        assertNotNull(result);
        assertNull(result.getId());
        assertNull(result.getName());
        assertNull(result.getIso6391());
        assertNull(result.getIso6392t());
        assertNull(result.getLanguageTag());
    }

    @Test
    void entityToDTOList_shouldReturnNull_whenEntityListIsNull() {
        assertNull(mapper.entityToDTOList(null));
    }

    @Test
    void entityToDTOList_shouldReturnEmptyList_whenEntityListIsEmpty() {
        List<LanguageDTO> result = mapper.entityToDTOList(Collections.emptyList());

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void entityToDTOList_shouldMapAllItems_whenEntityListHasValues() {
        Language first = new Language();
        first.setLanguageId(BigDecimal.valueOf(1));
        first.setName("English");
        first.setIso6391("en");
        first.setIso6392t("eng");
        first.setLanguageTag("en-US");

        Language second = new Language();
        second.setLanguageId(BigDecimal.valueOf(2));
        second.setName("French");
        second.setIso6391("fr");
        second.setIso6392t("fra");
        second.setLanguageTag("fr-FR");

        List<LanguageDTO> result = mapper.entityToDTOList(Arrays.asList(first, second));

        assertNotNull(result);
        assertEquals(2, result.size());

        assertEquals("1", result.get(0).getId());
        assertEquals("English", result.get(0).getName());
        assertEquals("en", result.get(0).getIso6391());
        assertEquals("eng", result.get(0).getIso6392t());
        assertEquals("en-US", result.get(0).getLanguageTag());

        assertEquals("2", result.get(1).getId());
        assertEquals("French", result.get(1).getName());
        assertEquals("fr", result.get(1).getIso6391());
        assertEquals("fra", result.get(1).getIso6392t());
        assertEquals("fr-FR", result.get(1).getLanguageTag());
    }
}