package com.hireright.sourceintelligence.service;
import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.exception.InvalidRequestException;
import com.hireright.sourceintelligence.exception.ResourceNotFoundException;
import com.hireright.sourceintelligence.exception.ServiceException;
import com.hireright.sourceintelligence.service.impl.*;
import com.hireright.sourceintelligence.service.impl.helperservices.CreateSourceService;
import com.hireright.sourceintelligence.service.impl.helperservices.ReportDataUtils;
import com.hireright.sourceintelligence.service.impl.helperservices.UpdateSourceService;
import com.hireright.sourceintelligence.util.TestDataProvider;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static org.assertj.core.api.Assertions.*;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SourceServiceTest {

    @InjectMocks
    private SourceServiceImpl sourceOrganizationService;
    @InjectMocks
    private SourceServiceImpl sourceService;
    @Mock
    private SourceMapper sourceMapper;
    @Mock
    private CustomSourceRepository<Source> customSourceRepository;

    @Mock
    private MongoSourceService mongoSourceService;
    @Mock
    private ReportDataUtils reportDataUtils;



    @Mock
    private CreateSourceService createSourceService;

    @Mock
    private UpdateSourceService updateSourceService;

    @BeforeEach
    void setUp() {

    }

    @Test
    void createSourceOrganizationTest() {

        SourceOrganizationDTO sourceOrganizationDTO = TestDataProvider.getSourceOrganizationDTO();
        SourceOrganizationDTO mockResponse = TestDataProvider.getSourceOrganizationDTO();
        when(sourceOrganizationService.createSource(any(), any())).thenReturn(mockResponse);
        assertThat(sourceOrganizationService.createSource(sourceOrganizationDTO, new UIActionsDTO())).isNotNull();
    }

    @Test
    void createSourceOrganizationTest_ShouldThrowServiceException() throws Exception {
        SourceOrganizationDTO sourceOrganizationDTO = TestDataProvider.getSourceOrganizationDTO();
        Source orgEntity = TestDataProvider.getSourceOrganizationEntity();
        UIActionsDTO uiActionsDTO = new UIActionsDTO();

        lenient().when(sourceMapper.dtoToEntitySource(any())).thenReturn(orgEntity);
        lenient().when(customSourceRepository.isHonExists(any(), eq(Source.class), anyString())).thenReturn(true);
        lenient().when(createSourceService.createSource(any(), any()))
                .thenThrow(new InvalidRequestException("Source already exists"));

        assertThatExceptionOfType(InvalidRequestException.class)
                .isThrownBy(() -> sourceOrganizationService.createSource(sourceOrganizationDTO, uiActionsDTO))
                .withMessageContaining("Source already exists");
    }


    @Test
    void createSourceOrganizationTest_ShouldThrowResourceNotFoundException() throws Exception {
        SourceOrganizationDTO sourceOrganizationDTO = TestDataProvider.getSourceOrganizationDTO();
        Source orgEntity = TestDataProvider.getSourceOrganizationEntity();
        UIActionsDTO uiActionsDTO = new UIActionsDTO();

        lenient().when(sourceMapper.dtoToEntitySource(any())).thenReturn(orgEntity);
        lenient().when(customSourceRepository.isHonExists(any(), eq(Source.class), anyString())).thenReturn(true);
        lenient().when(createSourceService.createSource(any(), any()))
                .thenThrow(new InvalidRequestException("Source already exists"));

        assertThatExceptionOfType(InvalidRequestException.class)
                .isThrownBy(() -> sourceOrganizationService.createSource(sourceOrganizationDTO, uiActionsDTO))
                .withMessageContaining("Source already exists");

    }


    @Test
    void updateSourceTest() throws Exception {
        SourceOrganizationDTO sourceDTO = TestDataProvider.getSourceOrganizationDTO();
        sourceDTO.setHon(TestDataProvider.getHon());
        UIActionsDTO uiActionsDTO = new UIActionsDTO();
        uiActionsDTO.setUserAction(ACTION_SAVE);

        Source entityFromDb = TestDataProvider.getSourceOrganizationEntity();
        entityFromDb.setApprovalStatus(ApprovalStatus.PENDING_APPROVAL);
        entityFromDb.setStatus(SourceOrganizationStatus.INACTIVE);

        lenient().when(customSourceRepository.findOneByHon(anyString(), eq(Source.class), anyString()))
                .thenReturn(entityFromDb);
        lenient().when(updateSourceService.updateSource(any(), any()))
                .thenThrow(new ResourceNotFoundException("Source not found"));

        assertThatExceptionOfType(ResourceNotFoundException.class)
                .isThrownBy(() -> sourceOrganizationService.updateSource(sourceDTO, uiActionsDTO))
                .withMessageContaining("Source not found");

    }


    @Test
    void updateSourceTest_EligibleForAutApproval() throws Exception {
        SourceOrganizationDTO sourceOrganizationDTO = TestDataProvider.getSourceOrganizationDTO();
        sourceOrganizationDTO.setHon(TestDataProvider.getHon());
        SourceOrganizationDTO expectedDTO = TestDataProvider.getSourceOrganizationDTO();
        when(updateSourceService.updateSource(any(), any())).thenReturn(expectedDTO);
        SourceOrganizationDTO orgDTO = sourceOrganizationService.updateSource(sourceOrganizationDTO, new UIActionsDTO());
        assertThat(orgDTO).isNotNull();
        assertThat(orgDTO.getOrganizationName()).isEqualTo(expectedDTO.getOrganizationName());
        assertThat(orgDTO.getHon()).isEqualTo(expectedDTO.getHon());
    }


    @Test
    void updateSourceTest_ShouldThrowInvalidRequestException() throws Exception {
        SourceOrganizationDTO sourceDTO = TestDataProvider.getSourceOrganizationDTO();
        sourceDTO.setHon(TestDataProvider.getHon());
        UIActionsDTO uiActionsDTO = new UIActionsDTO();
        uiActionsDTO.setUserAction(ACTION_SAVE);

        Source entityFromDb = TestDataProvider.getSourceOrganizationEntity();
        entityFromDb.setApprovalStatus(ApprovalStatus.PENDING_APPROVAL);
        entityFromDb.setStatus(SourceOrganizationStatus.INACTIVE);

        lenient().when(customSourceRepository.findOneByHon(anyString(), eq(Source.class), anyString()))
                .thenReturn(entityFromDb);
        lenient().when(updateSourceService.updateSource(any(), any()))
                .thenThrow(new InvalidRequestException("Invalid request"));

        assertThatExceptionOfType(InvalidRequestException.class)
                .isThrownBy(() -> sourceOrganizationService.updateSource(sourceDTO, uiActionsDTO))
                .withMessageContaining("Invalid request");

    }


    @Test
    void updateSourceTest_ShouldThrowResourceNotFoundExceptionTwo() throws Exception {
        SourceOrganizationDTO sourceOrganizationDTO = TestDataProvider.getSourceOrganizationDTO();
        sourceOrganizationDTO.setHon(TestDataProvider.getHon());
        UIActionsDTO uiActionsDTO = new UIActionsDTO();

        when(updateSourceService.updateSource(any(), any()))
                .thenThrow(new ResourceNotFoundException("Source not found"));
        assertThatExceptionOfType(ResourceNotFoundException.class)
                .isThrownBy(() -> sourceOrganizationService.updateSource(sourceOrganizationDTO, uiActionsDTO))
                .withMessageContaining("Source not found");
    }



    @Test
    void updateSourceTest_ShouldThrowResourceNotFoundExceptionThree() throws Exception {
        SourceOrganizationDTO sourceOrganizationDTO = TestDataProvider.getSourceOrganizationDTO();
        sourceOrganizationDTO.setHon(TestDataProvider.getHon());
        UIActionsDTO uiActionsDTO = new UIActionsDTO();

        when(updateSourceService.updateSource(any(), any()))
                .thenThrow(new ResourceNotFoundException("Source not found"));
        assertThatExceptionOfType(ResourceNotFoundException.class)
                .isThrownBy(() -> sourceOrganizationService.updateSource(sourceOrganizationDTO, uiActionsDTO))
                .withMessageContaining("Source not found");
    }



    @Test
    void getSourceOrganizationByHonTest() {
        String hon = "OUEMP-083022-VGYQHF5";
        Source expectedSource = TestDataProvider.getSourceOrganizationEntity();
        expectedSource.setHon(hon);
        SourceOrganizationDTO expectedDTO = TestDataProvider.getSourceOrganizationDTO();
        expectedDTO.setHon(hon);
        when(mongoSourceService.findSourceByHon(hon)).thenReturn(expectedSource);
        when(sourceMapper.entitySourceToDTO(expectedSource)).thenReturn(expectedDTO);
        assertThatNoException().isThrownBy(() -> {
            SourceOrganizationDTO actualDTO = sourceService.getSourceByHon(hon);
            assert actualDTO != null;
            assert actualDTO.getHon().equals(hon);
        });
        verify(mongoSourceService, times(1)).findSourceByHon(hon);
        verify(sourceMapper, times(1)).entitySourceToDTO(any(Source.class));
    }

    @Test
    void getSourceOrganizationByHon_ServiceException_Test() {

        assertThatExceptionOfType(ResourceNotFoundException.class).isThrownBy(() -> sourceOrganizationService.getSourceByHon("OUEMP-083022-VGYQHF5"));
    }

    @Test
    void manualSelectSourceResourceNotFound_Test() {
        String hon = TestDataProvider.getHon();
        Source orgEntity = TestDataProvider.getSourceOrganizationEntity();
        orgEntity.setHon(hon);
        orgEntity.setStatus(SourceOrganizationStatus.INACTIVE);
        orgEntity.setLocation("");

        VerificationRequest verificationRequest = new VerificationRequest();
        verificationRequest.setLastVerificationDate(new Date());
        verificationRequest.setLastUsedDate("2025-11-11");

        String lastUsedDate = verificationRequest.getLastUsedDate();
        assertThatExceptionOfType(ResourceNotFoundException.class)
                .isThrownBy(() -> sourceOrganizationService.manualSelectSource(hon, null));
    }



    @Test
    void manualSelectSourceInvalidRequest_Test() {
        String hon = TestDataProvider.getHon();

        Source orgEntity = TestDataProvider.getSourceOrganizationEntity();
        orgEntity.setHon(hon);
        orgEntity.setPayload(null);
        when(mongoSourceService.findSourceByHonAndApprovalStatus(hon, ApprovalStatus.APPROVED))
                .thenReturn(orgEntity);

        assertThatExceptionOfType(InvalidRequestException.class)
                .isThrownBy(() -> sourceOrganizationService.manualSelectSource(hon, ApprovalStatus.APPROVED));

        when(customSourceRepository.findByHonIn(anyList(), any(), anyString()))
                .thenReturn(List.of(orgEntity));

        when(sourceMapper.toSourceDTOList(anyList()))
                .thenReturn(List.of(new SourceOrganizationDTO()));

        assertThatNoException().isThrownBy(() ->
                sourceOrganizationService.getSourcesByHonIds(
                        List.of("OUEMP-083022-VGYQHF5", "OUEMP-083022-VGYQHF7")));
    }



    @Test
    void getSourceOrganizationsByHonIdsTest_WhenEmpty() {
        List<String> honIds = List.of("OUEMP-083022-VGYQHF5", "OUEMP-083022-VGYQHF7");
        assertThatNoException().isThrownBy(() -> sourceOrganizationService.getSourcesByHonIds(honIds));
        Assertions.assertTrue(sourceOrganizationService.getSourcesByHonIds(honIds).isEmpty());
    }
}