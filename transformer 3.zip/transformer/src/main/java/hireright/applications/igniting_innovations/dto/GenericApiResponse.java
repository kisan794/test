package hireright.applications.igniting_innovations.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Generic API response wrapper.
 *
 * @author Generated
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Generic API response")
public class GenericApiResponse {

    @Schema(description = "Response timestamp", example = "2026-01-21T08:12:16.490+00:00")
    @JsonProperty("timestamp")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    private LocalDateTime timestamp;

    @Schema(description = "HTTP status code", example = "201")
    @JsonProperty("status")
    private Integer status;

    @Schema(description = "Response message", example = "Idea submission saved successfully")
    @JsonProperty("message")
    private String message;

    /**
     * Create a success response.
     */
    public static GenericApiResponse success(Integer status, String message) {
        return GenericApiResponse.builder()
                .timestamp(LocalDateTime.now())
                .status(status)
                .message(message)
                .build();
    }

    /**
     * Create a created response (201).
     */
    public static GenericApiResponse created(String message) {
        return success(201, message);
    }

    /**
     * Create an OK response (200).
     */
    public static GenericApiResponse ok(String message) {
        return success(200, message);
    }
}

