package com.hireright.sourceintelligence.api;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ApiConstants {

    public static final String TIMEZONE_ID_PREFIXES = "^(Africa|America|Asia|Atlantic|Australia|Europe|Indian|Pacific)/.*";

    public static final String GMT = "GMT %+03d:%02d";
    public static final String SUCCESS = "SUCCESS";
    public static final String FAILURE = "FAILURE";

    // Controller constants
    public static final String HON = "hon";
    public static final String STATUS = "status";

    public static final String EMEA = "EMEA";
    public static final String APAC = "APAC";
    public static final String[] EMEA_REGION = new String[]{"EMEA","APAC"};
    public static final String[] US_REGION = new String[]{"US","CANADA","LATAM"};


    public static final String SEARCH_TEXT = "name";
    public static final String SEARCH_TYPE = "type";
    public static final String SEARCH_KEY = "key";

    public static final String SEARCH_ORGANIZATION_TEXT = "organizationName";
    public static final String SEARCH_ORGANIZATION_TYPE = "organizationType";
    public static final String  START_INDEX = "startIndex";
    public static final String BATCH_SIZE = "batchSize";
    public static final String SOURCE_ID = "sourceId";
    public static final String SEARCH = "search";
    public static final String SORT = "sort";
    public static final String ORDER = "order";
    public static final String FROM_DATE = "fromDate";
    public static final String TO_DATE = "toDate";
    public static final String OPERATOR_NAME = "operatorName";
    public static final String OPERATOR_ROLE = "operatorRole";
    public static final String REPORT_TYPE = "reportType";
    public static final String SEARCH_ORGANIZATION_STATUS = "status";
    public static final String IS_RAM = "isRAM";
    public static final String INVALID_INDEX_VALUE = "index value should be between 1 and 999";
    public static final String INVALID_BATCH_SIZE = "batchSize should be between 1 and 999";
    public static final String TOTAL_COUNT = "X-SourceIntelligence-total-count";
    public static final  int MAX_INDEX_VALUE = 99999;
    public static final String ORDER_ITEM_ID = "orderItemId";
    public static final String SEARCH_ORGANIZATION_ALIAS = "organizationAlias";
    public static final String SEARCH_ORGANIZATION_CITY = "city";
    public static final String SEARCH_ORGANIZATION_REGION = "region";
    public static final String SEARCH_ORGANIZATION_COUNTRY = "country";
    public static final String SEARCH_KEYWORD = "searchKey";
    public static final String SEARCH_ORGANIZATION_POSTAL_CODE = "postalCode";
    public static final String SEARCH_ORGANIZATION_STATE = "state";
    public static final String ORGANIZATION_ALIAS = "organizationAlias";
    public static final String SEARCH_COUNTRY = "country";
    public static final String FLAG_PRIORITY = "flagPriority";
    public static final String VERSION = "version";
    public static final String TEMP_VERSION = "tempVersion";
    public static final String SEARCH_SOURCE = "search";
    public static final String APPROVAL_STATUS= "approvalStatus";
    public static final String CONFIDENCE_THRESHOLD= "confidenceThreshold";
    public static final String SEARCH_FILTERS= "searchFilters";
    public static final String HON_IDS = "HonIds";
    public static final String HONIDS = "honIds";
    public static final String COUNTRY_ID = "countryId";

    //Attachments
    public static final String URL = "url";
    public static final String DOCUMENT_META = "documentMeta";
    public static final String FILE = "file";
    public static final String DOCUMENT_ID = "documentId";
    public static final String DELETE_URL = "deleteURL";
    public static final String OT_KEY = "ot_key";
    public static final String ENTRY = "entry";
    public static final String API_HOST = "api_host";



    // operator related constants
    public static final String OPEN_CURLY_BRACE = "{";
    public static final String CLOSE_CURLY_BRACE = "}";
    public static final String FORWARD_SLASH = "/";

    // API Parameters Validation values
    public static final int MAX_PAGE = 99999;@NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class AuthRequestHeaders {
        public static final String AUTHORIZATION_HEADER = "Authorization";
        public static final String APPIAN_API_HEADER = "X-Appian-API-Key";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class TraceRequestHeaders {
        public static final String SOURCE_INTELLIGENCE_SERVICE_TRACE_HEADER = "X-SourceIntelligenceService-TraceId";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class ApiPath {
        public static final String SOURCE_INTELLIGENCE_SERVICE = "/sourceintelligence-service";
        public static final String SI_SERVICE = "/si";
        public static final String API_PREFIX = "/api";
        public static final String API_VERSION_V1 = "/v1";
        public static final String API_VERSION_V2 = "/v2";
        public static final String SOURCE_ORGANIZATION = "/source-organization";
        public static final String SOURCE_ORGANIZATIONS = "/source-organizations";
        public static final String SOURCES = "/sources";
        public static final String SOURCE = "/source";
        public static final String SEARCH = "/search/";
        public static final String SEARCH_SOURCE = "/search";
        public static final String CHILD_DETAILS = "/childDetails";
        public static final String V2_SEARCH = "/search";
        public static final String MATCH = "/match";
        public static final String AUTOMATCH = "/automatch";
        public static final String BYHONANDVERSION = "/byHonAndVersion";
        public static final String FILTERS = "/filters";
        public static final String INCREMENT_USED_COUNT = "/increment-used-count";
        public static final String DELETE_SOURCE = "/delete";
        public static final String LOCK_SOURCE = "/lock";
        public static final String UNLOCK_SOURCE = "/unlock";
        public static final String REGION_LIST = "/region";
        public static final String ARCHIVE = "archive";

        public static final String AUTO = "/auto";
        public static final String SUGGESTION = "/suggestion";
        public static final String DETAILS = "details";
        public static final String SOURCE_ORGANIZATION_AUTOCOMPLETE = SOURCE_ORGANIZATION + "/autocomplete";
        public static final String SOURCE_PARENT = SOURCE_ORGANIZATION + "/getParentList";



        public static final String SOURCE_ORGANIZATION_HON_CONTACTS =
                FORWARD_SLASH + OPEN_CURLY_BRACE + HON + CLOSE_CURLY_BRACE + FORWARD_SLASH;
        public static final String BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH =
                SOURCE_INTELLIGENCE_SERVICE + API_PREFIX + API_VERSION_V1;
        public static final String BASE_SI_SERVICE_V2_API_PATH =
                SI_SERVICE + API_VERSION_V2;
        public static final String HON_PATH_VAR = FORWARD_SLASH + OPEN_CURLY_BRACE + HON + CLOSE_CURLY_BRACE;
        public static final String VERSION_PATH_VAR = FORWARD_SLASH + OPEN_CURLY_BRACE + VERSION + CLOSE_CURLY_BRACE;
        public static final String SOURCE_ID_PATH_VAR = FORWARD_SLASH + OPEN_CURLY_BRACE + SOURCE_ID + CLOSE_CURLY_BRACE;
        public static final String SEARCH_SOURCE_PATH_VAR = OPEN_CURLY_BRACE + SEARCH_SOURCE + CLOSE_CURLY_BRACE;
        public static final String SOURCE_TYPE_PATH_VAR = FORWARD_SLASH + OPEN_CURLY_BRACE + SEARCH_TYPE + CLOSE_CURLY_BRACE;
        public static final String STATUS_PATH_VAR = FORWARD_SLASH + OPEN_CURLY_BRACE + STATUS + CLOSE_CURLY_BRACE;
        public static final String ARCHIVE_PATH = FORWARD_SLASH + ARCHIVE;


        public static final String API_PATH_CONTACT =
                BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + SOURCE_ORGANIZATION + "/contact";
        public static final String API_PATH_ADDRESS =
                BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + SOURCE_ORGANIZATION + "/address";
        public static final String SOURCE_ORGANIZATION_HON_ADDRESS =
                FORWARD_SLASH + OPEN_CURLY_BRACE + HON + CLOSE_CURLY_BRACE + FORWARD_SLASH;
        public static final String API_PATH_REPORTS =
                BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + SOURCE_ORGANIZATION + "/reports";


        public static final String SOURCE_ORGANIZATION_UNIQUE_LIST = SOURCE_ORGANIZATION + FORWARD_SLASH + "unique";
        public static final String PHRASE_SEARCH_PATH = SEARCH + "phrase/";
        public static final String USED_COUNT = "/usedCount/";
        public static final String VERIFY = "/verify/";
        public static final String APPROVAL_WORKFLOW = "/approval-workflow";
        public static final String UPDATE_STATUS = FORWARD_SLASH + STATUS;
        public static final String ALL_VERSIONS = FORWARD_SLASH + "allVersions";

        public static final String SEARCH_PATH_VAR = FORWARD_SLASH;
        public static final String FLAG = "/flag";
        public static final String HISTORY = "/history";
        public static final String DIFF ="/diff";
        public static final String CHANGE_LOG = "/changeLog";
        public static final String OUT_OF_BUSINESS = "/outOfBusiness";
        public static final String TIME_ZONE = "/timezones";
        public static final String VENDORS = "/vendors";
        public static final String COUNTRY = "/country";
        public static final String COUNTRY_REGION = "/country_region";

        //Reports
        public static final String REPORTS = "/{reportType}";
        public static final String CONTACT_UTILIZATION = "/contact-utilization";
        public static final String SOURCE_INFORMATION = "/source-information";
        public static final String APPROVAL_TAT = "/approval-tat";
        public static final String AUTO_MATCH = "/auto-match";
        public static final String DELETE_SOURCE_REPORT = "/delete-report";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class ResponseHeaders {
        public static final String ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";
        public static final String ACCESS_CONTROL_ALLOW_CREDENTIALS = "Access-Control-Allow-Credentials";
        public static final String ACCESS_CONTROL_ALLOW_METHODS = "Access-Control-Allow-Methods";
        public static final String X_SOURCE_INTELLIGENCE_TOTAL_COUNT = "X-SourceIntelligence-total-count";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class SearchParams {
        public static final int MIN_START_PAGE = 1;
        public static final int MAX_START_PAGE = 99999;
        public static final int MIN_PAGE_LIMIT = 10;
        public static final int MAX_PAGE_LIMIT = 99999;

        public static final String SEARCH_PHRASE = "searchPhrase";
        public static final String START_PAGE = "startPage";
        public static final String PAGE_SIZE = "pageSize";

        //Validation Messages for Search Params
        public static final String INVALID_ORDER = "order must be either asc or desc";
        public static final String INVALID_INDEX_VALUE = "index value should be between 1 and 999";
        public static final String INVALID_BATCH_SIZE = "batchSize should be between 1 and 999";
        public static final String INVALID_START_PAGE =
                "start page should be between " + MIN_START_PAGE + " and " + MAX_START_PAGE;
        public static final String INVALID_PAGE_LIMIT =
                "page limit should be between " + MIN_PAGE_LIMIT + " and " + MAX_PAGE_LIMIT;

        public static final String REGION_THRESHOLDS = "/region-thresholds";
        public static final String OP_TOOL_KEY = "ot_key";
        public static final String KEY = "key";
        public static final String ENTRY_POINT = "/entry";
        public static final String CACHED_TOKEN = "/token";
        public static final String OP_TOOL_KEY_PATH_VAR = FORWARD_SLASH + OPEN_CURLY_BRACE + OP_TOOL_KEY + CLOSE_CURLY_BRACE;
        public static final String ACCESS_POINT_URL = "/AccessPoint/AccessPointRestService/access_points/";
        public static final String HTTPS = "https://";
        public static final String REDIRECT = "/redirect";
        public static final String TOKEN = "?token=";
        public static final String LOCATION = "Location";
        public static final String ASSIGN = FORWARD_SLASH + "assign";

        public static final String UPLOAD_ATTACHMENT = FORWARD_SLASH + "uploadAttachment";
        public static final String GET_ATTACHMENT = FORWARD_SLASH + "getAttachment";
        public static final String DELETE_ATTACHMENT = FORWARD_SLASH + "deleteAttachment";
        public static final String GET_HTML_RESPONSE = FORWARD_SLASH + "getHtmlResponse" + OPEN_CURLY_BRACE +HON+ CLOSE_CURLY_BRACE;
        public static final String SCOPE = "&scope=9035";
        public static final String SUBJECT = "subject";
        public static final String USER_NAME = "userName";
        public static final String PERMISSIONS = "/permissions";
        public static final String HTTP = "http://";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class DMSApiPath {
        public static final String UPLOAD_DOCUMENT = "/documents";
        public static final String DOCUMENTS = "/documents/";
        public static final String BODY = "/body";
    }

}
