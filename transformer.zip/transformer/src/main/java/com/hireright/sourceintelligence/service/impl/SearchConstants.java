package com.hireright.sourceintelligence.service.impl;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.*;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class SearchConstants {
    // Constants
    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class SearchFields {
        public static final String ID = "_id";
        public static final String STATUS = "status";
        public static final String PARENT_HON = "HON";
        public static final String CHILD_COUNT = "childCount";
        public static final String RELATIONSHIPS = "relationships";
        public static final String RELATIONSHIP = "relationship";
        public static final String PARENT = "parent";
        public static final String EDU_PARENT = "Parent / Main Campus";
        public static final String CORPORATE_PARENT = "Corporate Parent";
        public static final String CHILD = "child";
        public static final String CHILD_OPTION_ONE = "child / affiliated / branch school";
        public static final String FRANCHISE = "franchise";
        public static final String USED_COUNT = "usedCount";
        public static final String LAST_USED_DATE = "lastUsedDateTime";
        public static final String APPROVAL_STATUS = "approvalStatus";
        public static final String ORGANIZATION_NAME = "organizationName";
        public static final String SEARCH_ORG = "searchOrg";
        public static final String ORGANIZATION_TYPE = "organizationType";
        public static final String COUNTRY = "country";
        public static final String STATE = "state";
        public static final String CITY = "city";
        public static final String ORGANIZATION_ALIAS_NAME = "organizationAlias.name";
        public static final String HON = "hon";
        public static final String LAST_APPROVED_DATE = "lastApprovedDateTime";
        public static final String LAST_MODIFIED_DATE = "last_modified_date";
        public static final String LAST_ACTION_DATE = "last_modified_date";
        public static final String ORGANIZATION_ALIAS = "organizationAlias";
        public static final String REVIEW_REQUIRED = "reviewRequired";
        public static final String POSTAL_CODE = "postalCode";
        public static final String COMMENT = "comment";
        public static final String REQUESTED_BY = "requestedBy";
        public static final String CREATED_BY = "createdBy";
        public static final String ASSIGNED_TO = "assignedTo";
        public static final String ASSIGNED_ID = "assignedId";
        public static final String PAYLOAD = "payload";
        public static final String FLAG_PRIORITY = "flagPriority";
        public static final String LAST_ACTIVE = "lastActive";
        public static final String LAST_USED = "lastUsedDate";
        public static final String LOCATION = "location";
        public static final String VALIDATED = "validated";
        public static final String PRIMARY_CONTACT = "primaryContact";
        public static final String VERSION = "version";
        public static final String REQUESTER_ID = "requesterId";
        public static final String CREATED_DATE = "created_date";
        public static final String LOG_FLAG = "logFlag";
        public static final String ACTION = "action";
        public static final String LAST_MODIFIED_BY = "lastModifiedBy";
        public static final String ADDITIONAL_INFO = "addionalInfo";
        public static final String DO_NOT_CONTACT = "doNotContact";
        public static final String PAYLOAD_RELATIONSHIPS_HON = "payload.relationships.HON";
        public static final String PAYLOAD_RELATIONSHIPS_HON_1 = "payload.relationships.hon";
        public static final String PAYLOAD_RELATIONSHIPS_RELATIONSHIP = "payload.relationships.relationship";
        public static final String VERIFICATION_VALIDATION_DATE = "verificationValidationProcess";

        public static final String PAYLOAD_VERIFICATION_VALIDATION_DATE = "payload.addionalInfo[0].verificationValidationProcess";

        public static final String MATCH_PRIORITY = "matchPriority";
        public static final String ORG_NAMES = "orgNames";
        public static final String RESULTS = "results";

        public static final String TEMP_VERSION = "tempVersion";
        public static final String ACTION_CREATE = "Create";
        public static final String IS_LOCK_ENABLED = "isLockEnabled";
        public static final String LAST_LOCKED_BY = "lastLockedBy";
        public static final String LAST_LOCKED_DATE = "lastLockedDate";
        public static final String LAST_LOCKED_ID = "lastLockedId";

        public static final String APPROVAL_START_DATE = "approval_start_date";


    }

    static final String MSG_CONTACTS_NOT_FOUND = "No contacts found for organizationType:";
    static final String MSG_ORGANIZATION_NAME_NULL = "OrganizationName cannot be empty or null";
    static final String MSG_HON_NULL = "HON cannot be null";

    public static final String DATA = "data";
    public static final String ORGANIZATION_LIST = "organizationList";

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class PayloadFields {
        public static final String PAYLOAD_CONTACTS = "payload.contacts";
        public static final String PAYLOAD_LAST_CLEAN_UP_DATE = "payload.lastCleanUpDate";
        public static final String PAYLOAD_LAST_APPROVED_DATE = "payload.lastApprovedDateTime";
        public static final String PAYLOAD_USED_COUNT = "payload.usedCount";
        public static final String PAYLOAD_CONTACT_DETAILS = "payload.contacts.contactDetails";
        public static final String PAYLOAD = "payload";
        public static final String PAYLOAD_APPROVED_FLAG = "payload.approvedFlag";
        public static final String PAYLOAD_ARCHIVE = "payload.archive";
        public static final String PAYLOAD_CREATED_DATE_TIME = "payload.createdDateTime";
        public static final String PAYLOAD_DELETE = "payload.delete";
        public static final String PAYLOAD_ADDRESS = "payload.address.line";
        public static final String PAYLOAD_ORGANIZATION_ALIASES = "payload.organizationAliases";
        public static final String PAYLOAD_DEPARTMENT_ALIASES = "payload.departmentAliases";
        public static final String PAYLOAD_DEPARTMENT_ALIASES_NAMES = "payload.departmentAliases.name";
        public static final String PAYLOAD_DEPARTMENT_NAME = "payload.departmentName";
        public static final String PAYLOAD_DOT_REGULATED = "payload.dotRegulated";
        public static final String PAYLOAD_EXPTD_TURN_AROUND_TIME_UNIT = "payload.exptdTurnAroundTimeUnit";
        public static final String PAYLOAD_HON = "payload.hon";
        public static final String PAYLOAD_NAME = "payload.name";
        public static final String PAYLOAD_TYPE = "payload.type";
        public static final String PAYLOAD_WEBSITE = "payload.website";
        public static final String PAYLOAD_ADDIONALINFO = "payload.addionalInfo";
        public static final String PAYLOAD_RELATIONSHIPS = "payload.relationships";
        public static final String PAYLOAD_RELATIONSHIPS_HAS_CHILD = "payload.relationships.hasChildren";
        public static final String PAYLOAD_CONTACTS_OP_CODE = "payload.contacts.contactDetails.communication.communicationInfo.codes";
        public static final String PAYLOAD_CONTACTS_ONLINE_PROVIDER = "payload.contacts.contactDetails.communication.name";
        public static final String PAYLOAD_CONTACTS_TYPE = "payload.contacts.contactDetails.type";
        public static final String PAYLOAD_CONTACTS_COMMUNICATION_VALUE = "payload.contacts.contactDetails.communication.communicationInfo.value";
        public static final String PAYLOAD_CONTACTS_COMMUNICATION_TYPE = "payload.contacts.contactDetails.communication.communicationInfo.type";

        public static final String COMMUNICATION_VALUE = "communication.communicationInfo.value";
        public static final String COMMUNICATION_TYPE = "communication.communicationInfo.type";
        public static final String ONLINE_PROVIDER_NAME = "communication.name";

        public static final String CONTACTS_TYPE = "type";
        public static final String STATE_CONSTANT = "All";
        public static final String CITY_CONSTANT = "All";

        public static final String PAYLOAD_ADDITIONALINFO = "payload.additionalInfo";

        public static final String PAYLOAD_NOTES = "payload.notes";
        public static final String PAYLOAD_STATUS = "payload.status";
        public static final String PAYLOAD_UN_ACCREDITED_SOURCE = "payload.unAccreditedSource";
        public static final String PAYLOAD_PRIMARY_CONTACT = "payload.contacts.contactDetails.communication.recipient";
        public static final String PAYLOAD_ADDRESS_LINE = "payload.address.line";
        public static final String PAYLOAD_LAST_USED_DATE = "payload.lastUsedDateTime";
        public static final String PAYLOAD_VERIFICATION_VALIDATION_PROCESS = "payload.addionalInfo.$[].verificationValidationProcess";
        public static final String PAYLOAD_ADDITIONAL_INFO = "payload.addionalInfo.doNotContact";
        public static final String PAYLOAD_LAST_USED_DATETIME = "payload.lastUsedDateTime";
        public static final String PAYLOAD_CONTACT_CONTACT_DETAILS = "payload.contacts.contactDetails";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class SearchProjectionFields {
        public static final String SEARCH_PAYLOAD_CONTACT_DETAILS = "payload.contactDetails";
        public static final String SEARCH_PAYLOAD_LAST_CLEAN_UP_DATE = "payload.lastCleanUpDate";
        public static final String SEARCH_PAYLOAD_ADDRESS_LINE = "payload.addressLine";
        public static final String SEARCH_PAYLOAD_USED_COUNT = "payload.usedCount";
        public static final String SEARCH_PAYLOAD_RELATIONSHIP_HON = "payload.usedCount";
        public static final String SEARCH_LAST_APPROVED_DATE = "last_approved_date";
        public static final String SEARCH_PAYLOAD_ADDITIONAL_INFO = "payload.addionalInfo";
        public static final String SEARCH_USED_COUNT = "usedCount";
        public static final String SEARCH_PAYLOAD_PRIMARY_CONTACT = "payload.primaryContact";
        public static final String SEARCH_PAYLOAD_POSTAL_CODE = "payload.postalCode";
        public static final String SEARCH_PAYLOAD_DEPARTMENT_NAME = "payload.departmentName";
        public static final String SEARCH_PAYLOAD_DEPARTMENT_ALIASES = "payload.departmentAliases";
        public static final String SEARCH_PAYLOAD_DEPARTMENT_ALIASES_NAME = "payload.departmentAliases.name";
        public static final String SEARCH_PAYLOAD_DO_NOT_CONTACT = "payload.doNotContact";
        public static final String SEARCH_PAYLOAD_LAST_USED_DATE_TIME = "payload.lastUsedDateTime";
        public static final String SEARCH_PAYLOAD_RELATIONSHIPS = "payload.relationships";
    }

    public static final String INDEX_ORGANIZATION_SEARCH = "index_organization_search";
    public static final String SEARCH_ORGANIZATION_HISTORY = "search_organization_history";
    public static final String DEPARTMENT_NAME = "departmentName";
    public static final String ADDRESS = "address";
    public static final String ADDRESS_LINE = "line";
    public static final String DEPARTMENT_ALIASES = "departmentAliases";
    public static final String AUTOMATCH = "automatch";
    public static final String SUGGESTIONS = "suggestions";

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class AggregationPipelineStages {
        public static final String FULL_TEXT_SEARCH = "$search";
        public static final String ADD_FIELDS = "$addFields";
        public static final String DOCUMENT_METADATA = "$meta";
        public static final String LIKE = "like";
        public static final String SEARCH_HIGHLIGHTS = "searchHighlights";
        public static final String TOTAL_COUNT = "$total.count";
        public static final String COUNT = "count";
        public static final String PROJECT = "$project";
        public static final String MATCH = "$match";
        public static final String REFERENCE_DOLLAR_OPERATOR = "$";
        public static final String DOC = "doc";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class AggregateOperators {
        public static final String GREATER_THAN_EQUALS = "$gte";
        public static final String LESS_THAN_EQUALS = "$lte";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class SearchScore {
        public static final String SCORE = "score";
        public static final String SEARCH_SCORE = "searchScore";
        static final int SEARCH_ORGANIZATION_NAME_SLOP = 5;
        static final int SEARCH_SCORE_BOOST_VALUE = 100;
        static final int SEARCH_FUZZY_MAX_EDITS_VALUE = 2;
        static final int SEARCH_RESULT_LIMIT = 5;
        //		static final int SEARCH_RESULT_SORT = -1; // descending
//		static final int SEARCH_BOOST_1 = 13; // value can be adjusted
//		static final int SEARCH_BOOST_2 = 8; // value can be adjusted
//		static final int SEARCH_BOOST_3 = 5; // value can be adjusted
//		static final int SEARCH_BOOST_4 = 3; // value can be adjusted
        public static final double MIN_SCORE = 20.0;
        public static final double DROP_DOWN_MIN_SCORE = 5.0;
        public static final double SEARCH_MIN_SCORE = 0.0;
        public static final double TEXT_BOX_SEARCH_MIN_SCORE = 7.0;
        public static final int DROP_DOWN_LIMIT = 200;
        public static final int SEARCH_LIMIT = 25;
        public static final int SMART_SEARCH_LIMIT = 300;
        public static final int SEARCH_SOURCE_LIMIT = 1000;
        public static final double AUTOMATCH_THRESHOLD = 99.00;
        public static final double SUGGESTIONS_THRESHOLD = 95.00;
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class FilterCategory {
        public static final String ORGANIZATION_ALIAS = "organizationAlias";
        public static final String POSTAL_CODE = "postalCode";
        public static final String START_DATE = "startDate";
        public static final String END_DATE = "endDate";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class ContactTypes {
        public static final String AUTOMATED_ONLINE_PROVIDER = "contactAutomatedServices";
        public static final String AUTOMATED_CODES = "codes";
        public static final String PHONE = "contactPhones";
        public static final String FAX = "contactFaxes";
        public static final String EMAIL = "contactEmails";

        public static final String PHONE_COUNTRY_CODE = "phoneCountryCode";
        public static final String EXTENSION = "extension";
        public static final String PHONE_NUMBER = "phoneNumber";
        public static final String AREA_CODE = "areaCode";
        public static final String ADDRESSES = "addresses";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class ParentChildTypes {

        public static final List<String> PARENT_TYPE =
                new ArrayList<>(Arrays.asList(
                        SearchFields.PARENT,
                        SearchFields.EDU_PARENT,
                        SearchFields.CORPORATE_PARENT
                ));

        public static final List<String> CHILD_TYPE = new ArrayList<>(Arrays.asList("Child / Affiliated / Branch School", "CHILD", "FRANCHISE", "Franchise"));
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class CommonText {
        public static final String[] EDU_TEXT_LIST = new String[]{"high school", "university", "school", "high"};
        public static final String[] EMP_TEXT_LIST = new String[]{"corporation", "services", "health", "solutions", "inc."};
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class ExternalConstants {
        public static final String APPLICATION_OCTET_STREAM = "application/octet-stream";
        public static final String APPLICATION_JSON = "application/json";
        public static final String ACCEPT_VALUE = "*/*";
        public static final String FILENAME = "filename=";
        public static final String ATTACHMENT = "attachment";

    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class Regex {
        public static final String PIPE = "^";
        public static final String SPACE_PLUS = "\s+";
        public static final String PLUS = "+";
        public static final String SPACE = " ";
        public static final String EMPTY_STRING = "";
        public static final String DASH = "_";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class Threshold {
        public static final String THRESHOLD_TYPE = "thresholdType";
        public static final String THRESHOLD_VALUE = "approval";
        public static final String REGION_THRESHOLD_COLLECTION = "region_threshold";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class LogFlagConstants {
        public static final String NEW_RECORD = "New Record";
        public static final String DETAILS_CHANGED = "Details Changed";
        public static final String ARCHIVED = "Archived";
        public static final String LOCKED = "Locked";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class ReportActions {
        public static final String CREATE = "Create";
        public static final String UPDATE = "Edit";
        public static final String IN_PROGRESS = "InProgress";
        public static final String APPROVED = "Approved";
        public static final String AUTO_APPROVED = "AutoApproved";
        public static final String REJECTED = "Rejected";
        public static final String ON_HOLD = "OnHold";
        public static final String DELETE = "Delete";
        public static final String ARCHIVED = "Archived";
        public static final String UNARCHIVED = "UnArchived";
        public static final String USED_COUNT = "UsedCount";
        public static final String AUTO_MATCH = "AutoMatch";
        public static final String LOCK = "LOCK";
        public static final String UNLOCK = "UNLOCK";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class SortFields {
        public static final String ORGANIZATION_NAME = "Organization_Name";
        public static final String TOTAL_COUNT = "total_count";
        public static final String LAST_MODIFIED_DATE = "Last_Modified_Date";
        public static final String SORT_LAST_MODIFIED_BY = "Sort_Last_Modified_BY";
        public static final String SORTLASTMODIFIEDBY = "sortLastModifiedBy";
        public static final String SORTASSIGNEDTO = "sortAssignedTo";
        public static final String LAST_APPROVED_DATE = "Last_Approved_Date";
        public static final String CITY = "City";
        public static final String REGION = "region";
        public static final String POSTAL_CODE = "postal_code";
        public static final String COUNTRY = "Country";
        public static final String DEPARTMENT_NAME = "Department_Name";
        public static final String LAST_USED_DATE = "Last_Used_Date";
        public static final String REQUESTED_BY = "Requested_By";
        public static final String ASSIGNED_TO = "Assigned_To";
        public static final String APPROVAL_STATUS = "Approval_Status";
        public static final String CREATED_BY = "Created_By";
        public static final String LAST_MODIFIED_BY = "Last_Modified_By";
        public static final String LASTMODIFIEDBY = "lastModifiedBy";
        public static final String ASSIGNEDTO = "assignedTo";
        public static final String APPROVALSTATUS = "approvalStatus";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class GetSortFields {
        public static final String ORGANIZATION_NAME = "getOrganizationName";
        public static final String TOTAL_COUNT = "getUsedCount";
        public static final String LAST_MODIFIED_DATE = "getLastModifiedDate";
        public static final String LAST_APPROVED_DATE = "getLastApprovedDate";
        public static final String CITY = "getCity";
        public static final String REGION = "getState";
        public static final String POSTAL_CODE = "getPostalCode";
        public static final String COUNTRY = "getCountry";
        public static final String DEPARTMENT_NAME = "getDepartmentName";
        public static final String LAST_USED_DATE = "getLastUsedDateTime";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class JaroFields {
        public static final String ORG_NAME = "org";
        public static final String ORG_ALIAS = "orgAlias";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class ErrorMessages {

        public static final String ASSIGN_SUCCESS = "Assigned successfully";
        public static final String ASSIGN_FAILURE = "Cannot assign: Source status does not allow assignment.";
        public static final String ASSIGN_FAILURE_2 = "Unable to assign, source is in use by another approver.";


        public static final String ARCHIVE_SUCCESS = "Archived successfully";
        public static final String ARCHIVE_FAILURE = "Source is already archived/source not found";

        public static final String DELETE_SUCCESS = "Deleted successfully";
        public static final String DELETE_FAILURE = "Source is already deleted/source not found";

        public static final String LOCK_SUCCESS = "Lock source successfully";
        public static final String LOCK_FAILURE = "Source is already locked";
        public static final String LOCK_FAILURE_2 = "Lock source failed, source not found";

        public static final String UNLOCK_SUCCESS = "Unlock source successfully";
        public static final String UNLOCK_FAILURE = "Source already unlocked";
        public static final String UNLOCK_FAILURE2 = "Unlock source failed, source not found";

        public static final String INTERNAL_FAILURE = "Internal server error, unable to perform the action";

    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class StatusCode {
        public static final Integer SUCCESS_CODE = 200;
        public static final Integer FAILURE_CODE = 409; //Conflict
        public static final Integer FAILURE2_CODE = 404;
        public static final Integer INTERNAL_ERROR_CODE = 500;

    }
}
