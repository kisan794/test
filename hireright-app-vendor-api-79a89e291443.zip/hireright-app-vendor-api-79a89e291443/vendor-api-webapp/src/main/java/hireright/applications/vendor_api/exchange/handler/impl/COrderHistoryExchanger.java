/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-08-14	Created
 *	T.Prikk		2017-12-12	HIVPE-27993: commits removed from createEntity(), updateEntity(), deleteEntity()
 *	T.Prikk		2018-01-30	HIVPE-32013: Override refreshEntity()
 *	T.Prikk		2018-04-11	HIVPE-21816: doTransferForCreate() adjusted for sharing reference_type='ORDER' order history entries
 */
package hireright.applications.vendor_api.exchange.handler.impl;

import java.io.Serializable;
import java.sql.SQLException;

import hireright.applications.vendor_api.exchange.handler.AEntityExchanger;
import hireright.applications.vendor_api.exchange.handler.objects.CEntityExchangeException;
import hireright.applications.vendor_api.exchange.handler.objects.COrderEntityExchangeContext;
import hireright.applications.vendor_api.exchange.handler.utils.CExchangeUtils;
import hireright.applications.vendor_api.model.COrderHistoryRequest;
import hireright.objects.order2.COrderHistory;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;

public class COrderHistoryExchanger extends AEntityExchanger<COrderEntityExchangeContext<COrderHistoryRequest>, COrderHistoryRequest, COrderHistory>
{
	private static final String REFERENCE_TYPE_ORDER_SERVICE = "ORDER_SERVICE";

	/**
	 * Order history is identified by correlation ID field
	 */
	@Override
	protected String getEntityReference(COrderHistory orderHistory)
	{
		return String.valueOf(orderHistory.getCorrelationID());
	}

	/**
	 * Transfer data in case of create
	 */
	@Override
	protected void doTransferForCreate(COrderEntityExchangeContext<COrderHistoryRequest> context, COrderHistory orderHistory) throws CEntityExchangeException
	{
		COrderHistoryRequest orderHistoryDTO = context.getTransferObject();
		doTransferForUpdate(context, orderHistory);
		
		orderHistory.setReferenceType(orderHistoryDTO.getReferenceType());
		if (REFERENCE_TYPE_ORDER_SERVICE.equals(orderHistoryDTO.getReferenceType()))
		{
			String sSrc = this.getClass().getName()+".doTransferForCreate()";
			
			try
			{
				String orderServiceReference = orderHistoryDTO.getReferenceCode();
				if (!CStringUtils.isEmpty(orderServiceReference))
				{
					Long orderServiceID = CExchangeUtils.getOrderServiceID(context.getOrderID(), orderServiceReference);
					orderHistory.setReferenceID(orderServiceID);
				}
			}
			catch (Throwable t)
			{
				CTraceLog.warning(t, sSrc, new CProperties()
						.setProperty("objectRef", orderHistoryDTO.getObjectRef())
						.setProperty("referenceType", orderHistoryDTO.getReferenceType())
						.setProperty("referenceCode", orderHistoryDTO.getReferenceCode()),
					"Failed to retrieve local order service ID for reference code: "+ orderHistoryDTO.getReferenceCode()
				);
			}
			
			
			if (orderHistory.getReferenceID() == null)
				CTraceLog.warning("Local reference id will be null for order history entry", sSrc, new CProperties()
						.setProperty("objectRef", orderHistoryDTO.getObjectRef())
						.setProperty("referenceType", orderHistoryDTO.getReferenceType())
						.setProperty("referenceCode", orderHistoryDTO.getReferenceCode())
				);
		}
	}

	/**
	 * Transfer data in case of update
	 */
	@Override
	protected void doTransferForUpdate(COrderEntityExchangeContext<COrderHistoryRequest> context, COrderHistory orderHistory) throws CEntityExchangeException
	{
		COrderHistoryRequest orderHistoryDTO = context.getTransferObject();
		orderHistory.setCommentsCode(orderHistoryDTO.getCommentsCode());
		orderHistory.setCreationDate(orderHistoryDTO.getCreationDate());
		orderHistory.setHistory(orderHistoryDTO.getHistory());
		orderHistory.setOperatorName(orderHistoryDTO.getOperatorName());
		
		if (context.getOrderID() == null)
			throw new CEntityExchangeException("Order ID not provided in context");
		
		orderHistory.setOrderID(context.getOrderID());
	}

	/**
	 * Due to chunking, cannot use standard Hibernate save to create order history.<br/>
	 * After history is created, correlation ID will be populated in data object argument.
	 * @see {@link COrderHistory#save(COrderHistory)} to see how create is performed
	 */
	@Override
	protected void createEntity(COrderHistory orderHistory) throws CEntityExchangeException
	{
		try
		{
			// do not initialize state machine in order to avoid sending the history back to its origin, ad infinitum
			COrderHistory.create(orderHistory, false);
		}
		catch (SQLException e)
		{
			throw new CEntityExchangeException("Unable to create order history", e);
		}
	}

	/**
	 * Due to chunking, cannot use standard Hibernate load to read order history.<br/>
	 * Use correlation id to load order history.
	 * @see {@link COrderHistory#loadByCorrelation(Long)} to see how read is performed
	 */
	@Override
	protected COrderHistory readEntity(Serializable correlationID) throws CEntityExchangeException
	{
		return COrderHistory.loadByCorrelation((Long) correlationID);
	}

	/**
	 * Due to chunking, cannot use standard Hibernate refresh() to reload order history.<br/>
	 * Use correlation id to load order history.<br/>
	 * @see {@link COrderHistory#loadByCorrelation(Long)} to see how read is performed.
	 */
	@Override
	protected void refreshEntity(COrderHistory instance) throws CEntityExchangeException
	{
		if (instance != null && instance.getCorrelationID() != null) {
			COrderHistory freshInstance = COrderHistory.loadByCorrelation(instance.getCorrelationID());
			instance.setCommentsCode(freshInstance.getCommentsCode());
			instance.setCreationDate(freshInstance.getCreationDate());
			instance.setHistory(freshInstance.getHistory());
			instance.setOrderID(freshInstance.getOrderID());
			instance.setOperatorName(freshInstance.getOperatorName());
			instance.setProperties(freshInstance.getProperties());
			instance.setReferenceID(freshInstance.getReferenceID());
			instance.setReferenceType(freshInstance.getReferenceType());
		}
	}

	/**
	 * Due to chunking, cannot use standard Hibernate update to modify order history.<br/>
	 * @see {@link COrderHistory#updateProperties(COrderHistory)} to see how update is performed
	 */
	@Override
	protected void updateEntity(COrderHistory orderHistory) throws CEntityExchangeException
	{
		COrderHistory.updateProperties(orderHistory);
	}

	/**
	 * Due to chunking, cannot use standard Hibernate delete to remove order history.<br/>
	 * @see {@link COrderHistory#delete(COrderHistory)} to see how delete is performed
	 */
	@Override
	protected void deleteEntity(COrderHistory orderHistory) throws CEntityExchangeException
	{
		COrderHistory.delete(orderHistory);
	}

	public COrderHistoryExchanger()
	{
		super(COrderHistory.class);
	}
}
