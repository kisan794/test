package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.timezone.DropDownDTO;
import com.hireright.sourceintelligence.domain.entity.CountryRegionMapping;
import com.hireright.sourceintelligence.domain.repository.CountryRegionMappingRepository;
import com.hireright.sourceintelligence.service.impl.helperservices.CountryRegionMappingUtils;
import org.bson.Document;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;

@ExtendWith(MockitoExtension.class)
class CountryRegionMappingUtilsTest {

    private CountryRegionMappingRepository countryRegionMappingRepository;
    private MongoTemplate mongoTemplate;

    private CountryRegionMappingUtils utils;

    @BeforeEach
    void setup() {
        countryRegionMappingRepository = mock(CountryRegionMappingRepository.class);
        mongoTemplate = mock(MongoTemplate.class, RETURNS_DEEP_STUBS);
        utils = new CountryRegionMappingUtils(countryRegionMappingRepository, mongoTemplate);
    }

    @Test
    void getRegionByCountry_shouldReturnRegion_whenMappingAndRegionPresent() {
        CountryRegionMapping mapping = mock(CountryRegionMapping.class);
        when(mapping.getRegion()).thenReturn("EMEA");
        when(countryRegionMappingRepository.findByCountry("India")).thenReturn(mapping);

        String result = utils.getRegionByCountry("India");

        assertEquals("EMEA", result);
        verify(countryRegionMappingRepository).findByCountry("India");
        verify(mapping, atLeastOnce()).getRegion();
    }


    @Test
    void getRegionByCountry_shouldReturnEmptyString_whenMappingIsNull() {
        when(countryRegionMappingRepository.findByCountry("Unknown")).thenReturn(null);

        String result = utils.getRegionByCountry("Unknown");

        assertEquals("", result);
        verify(countryRegionMappingRepository).findByCountry("Unknown");
    }

    @Test
    void getRegionByCountry_shouldReturnEmptyString_whenRegionIsNull() {
        CountryRegionMapping mapping = mock(CountryRegionMapping.class);
        when(mapping.getRegion()).thenReturn(null);
        when(countryRegionMappingRepository.findByCountry("X")).thenReturn(mapping);

        String result = utils.getRegionByCountry("X");

        assertEquals("", result);
        verify(countryRegionMappingRepository).findByCountry("X");
        verify(mapping).getRegion();
    }

    @Test
    void findDistinctCountriesByRegion_shouldCallMongoDistinctWithRegionCriteria() {
        when(mongoTemplate.findDistinct(any(Query.class), eq("country"),
                eq(CountryRegionMapping.class), eq(String.class)))
                .thenReturn(List.of("USA", "Canada"));

        List<String> result = utils.findDistinctCountriesByRegion("US");

        assertEquals(List.of("USA", "Canada"), result);

        ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);
        verify(mongoTemplate).findDistinct(queryCaptor.capture(), eq("country"),
                eq(CountryRegionMapping.class), eq(String.class));
        Document queryDoc = queryCaptor.getValue().getQueryObject();
        assertEquals("US", queryDoc.get("region"));
    }

    @Test
    void getRegion_shouldReturnUS_whenCountryIsUSA() {
        String result = utils.getRegion("USA");
        assertEquals("US", result);
        verifyNoInteractions(countryRegionMappingRepository);
    }

    @Test
    void getRegion_shouldReturnEMEA_whenCountryIsUnitedKingdom() {
        String result = utils.getRegion("United Kingdom");
        assertEquals("EMEA", result);
        verifyNoInteractions(countryRegionMappingRepository);
    }

    @Test
    void getRegion_shouldFallbackToDb_whenNotInHardcodedMap() {
        CountryRegionMapping mapping = mock(CountryRegionMapping.class);
        when(mapping.getRegion()).thenReturn("APAC");
        when(countryRegionMappingRepository.findByCountry("India")).thenReturn(mapping);

        String result = utils.getRegion("India");

        assertEquals("APAC", result);
        verify(countryRegionMappingRepository).findByCountry("India");
        verify(mapping, atLeastOnce()).getRegion();
    }


    @Test
    void getRegion_shouldReturnEmpty_whenNotInHardcodedMap_andDbReturnsEmpty() {
        when(countryRegionMappingRepository.findByCountry("NowhereLand")).thenReturn(null);

        String result = utils.getRegion("NowhereLand");

        assertEquals("", result);
        verify(countryRegionMappingRepository).findByCountry("NowhereLand");
    }

    @Test
    void getRegionList_shouldReturnDropdowns_whenRegionsPresent() {
        when(mongoTemplate.query(CountryRegionMapping.class)
                .distinct("region")
                .as(String.class)
                .all())
                .thenReturn(List.of("US", "EMEA"));

        List<DropDownDTO> result = utils.getRegionList();

        assertNotNull(result);
        assertEquals(2, result.size());

        assertEquals("US", result.get(0).getLabel());
        assertEquals("US", result.get(0).getValue());

        assertEquals("EMEA", result.get(1).getLabel());
        assertEquals("EMEA", result.get(1).getValue());
    }

    @Test
    void getRegionList_shouldReturnEmptyList_whenNoRegions() {
        when(mongoTemplate.query(CountryRegionMapping.class)
                .distinct("region")
                .as(String.class)
                .all())
                .thenReturn(Collections.emptyList());

        List<DropDownDTO> result = utils.getRegionList();

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
}
