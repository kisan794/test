package hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.PropertiesResponse;
import hireright.applications.fulfillment_task_api.model.recombointegration.education.response.EducationQualifications;
import hireright.applications.fulfillment_task_api.model.recombointegration.education.response.EducationResultData;
import hireright.applications.fulfillment_task_api.model.recombointegration.education.response.EducationResultRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.education.response.ResponseResultData;
import hireright.applications.fulfillment_task_api.rest.recombointegration.exception.ValidationException;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.Direction;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.RecipientName;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.service.LoggingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for EducationResultServiceImpl
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("EducationResultServiceImpl Tests")
class EducationResultServiceImplTest {

    @Mock
    private LoggingService loggingService;

    @Mock
    private ObjectMapper objectMapper;

    private EducationResultServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new EducationResultServiceImpl(loggingService, objectMapper);
    }

    @Test
    @DisplayName("Should process education submission successfully")
    void testProcessEducationSubmissionSuccess() throws JsonProcessingException {
        // Given
        String requestId = "COMP-EDU-001";
        EducationResultRequest request = createValidEducationResultRequest(requestId);
        String jsonPayload = "{\"id\":\"COMP-EDU-001\"}";

        when(objectMapper.writeValueAsString(request)).thenReturn(jsonPayload);

        // When
        service.processEducationSubmission(requestId, request);

        // Then
        verify(objectMapper, times(1)).writeValueAsString(request);
        verify(loggingService, times(1))
                .log(jsonPayload, requestId, RecipientName.FULFILLMENT_RESPONSE, Direction.IN);
    }

    @Test
    @DisplayName("Should throw ValidationException when request ID is null")
    void testProcessEducationSubmissionNullRequestId() {
        // Given
        EducationResultRequest request = createValidEducationResultRequest("COMP-EDU-001");

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEducationSubmission(null, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when request ID is empty")
    void testProcessEducationSubmissionEmptyRequestId() {
        // Given
        EducationResultRequest request = createValidEducationResultRequest("COMP-EDU-001");

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEducationSubmission("", request));
    }

    @Test
    @DisplayName("Should throw ValidationException when request ID in path does not match body")
    void testProcessEducationSubmissionMismatchedRequestId() {
        // Given
        String pathRequestId = "COMP-EDU-001";
        EducationResultRequest request = createValidEducationResultRequest("COMP-EDU-002");

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEducationSubmission(pathRequestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when specversion is missing")
    void testProcessEducationSubmissionMissingSpecversion() {
        // Given
        String requestId = "COMP-EDU-001";
        EducationResultRequest request = createValidEducationResultRequest(requestId);
        request.setSpecversion(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEducationSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when source is missing")
    void testProcessEducationSubmissionMissingSource() {
        // Given
        String requestId = "COMP-EDU-001";
        EducationResultRequest request = createValidEducationResultRequest(requestId);
        request.setSource(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEducationSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when type is missing")
    void testProcessEducationSubmissionMissingType() {
        // Given
        String requestId = "COMP-EDU-001";
        EducationResultRequest request = createValidEducationResultRequest(requestId);
        request.setType(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEducationSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when data is null")
    void testProcessEducationSubmissionNullData() {
        // Given
        String requestId = "COMP-EDU-001";
        EducationResultRequest request = createValidEducationResultRequest(requestId);
        request.setData(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEducationSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when decision is missing")
    void testProcessEducationSubmissionMissingDecision() {
        // Given
        String requestId = "COMP-EDU-001";
        EducationResultRequest request = createValidEducationResultRequest(requestId);
        request.getData().setDecision(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEducationSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when reviewScore is missing")
    void testProcessEducationSubmissionMissingReviewScore() {
        // Given
        String requestId = "COMP-EDU-001";
        EducationResultRequest request = createValidEducationResultRequest(requestId);
        request.getData().setReviewScore(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEducationSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when decisionDescription is missing")
    void testProcessEducationSubmissionMissingDecisionDescription() {
        // Given
        String requestId = "COMP-EDU-001";
        EducationResultRequest request = createValidEducationResultRequest(requestId);
        request.getData().setDecisionDescription(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEducationSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when resultData is missing")
    void testProcessEducationSubmissionMissingResultData() {
        // Given
        String requestId = "COMP-EDU-001";
        EducationResultRequest request = createValidEducationResultRequest(requestId);
        request.getData().setResultData(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEducationSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when audit is missing")
    void testProcessEducationSubmissionMissingAudit() {
        // Given
        String requestId = "COMP-EDU-001";
        EducationResultRequest request = createValidEducationResultRequest(requestId);
        request.getData().getProperties().setAudit(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEducationSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw ValidationException when rfmFlag is missing")
    void testProcessEducationSubmissionMissingRfmFlag() {
        // Given
        String requestId = "COMP-EDU-001";
        EducationResultRequest request = createValidEducationResultRequest(requestId);
        request.getData().getProperties().setRfmFlag(null);

        // When & Then
        assertThrows(ValidationException.class, () -> service.processEducationSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should throw RuntimeException when JSON serialization fails")
    void testProcessEducationSubmissionJsonProcessingException() throws JsonProcessingException {
        // Given
        String requestId = "COMP-EDU-001";
        EducationResultRequest request = createValidEducationResultRequest(requestId);

        when(objectMapper.writeValueAsString(request)).thenThrow(new JsonProcessingException("Serialization error") {});

        // When & Then
        assertThrows(RuntimeException.class, () -> service.processEducationSubmission(requestId, request));
    }

    @Test
    @DisplayName("Should log request with correct parameters")
    void testLoggingServiceCalledWithCorrectParameters() throws JsonProcessingException {
        // Given
        String requestId = "COMP-EDU-001";
        EducationResultRequest request = createValidEducationResultRequest(requestId);
        String jsonPayload = "{\"id\":\"COMP-EDU-001\"}";

        when(objectMapper.writeValueAsString(request)).thenReturn(jsonPayload);

        // When
        service.processEducationSubmission(requestId, request);

        // Then
        verify(loggingService, times(1))
                .log(eq(jsonPayload), eq(requestId), eq(RecipientName.FULFILLMENT_RESPONSE), eq(Direction.IN));
    }

    @Test
    @DisplayName("Should process result data with institution name and degree")
    void testProcessResultDataWithInstitutionAndDegree() throws JsonProcessingException {
        // Given
        String requestId = "COMP-EDU-001";
        EducationResultRequest request = createValidEducationResultRequest(requestId);
        request.getData().getResultData().setInstitutionName("Harvard University");
        request.getData().getResultData().getQualifications().setDegree("Bachelor of Science");

        String jsonPayload = "{\"id\":\"COMP-EDU-001\"}";
        when(objectMapper.writeValueAsString(request)).thenReturn(jsonPayload);

        // When
        service.processEducationSubmission(requestId, request);

        // Then
        verify(loggingService, times(1))
                .log(jsonPayload, requestId, RecipientName.FULFILLMENT_RESPONSE, Direction.IN);
    }

    @Test
    @DisplayName("Should handle result data with null qualifications")
    void testProcessResultDataWithNullQualifications() throws JsonProcessingException {
        // Given
        String requestId = "COMP-EDU-001";
        EducationResultRequest request = createValidEducationResultRequest(requestId);
        request.getData().getResultData().setQualifications(null);

        String jsonPayload = "{\"id\":\"COMP-EDU-001\"}";
        when(objectMapper.writeValueAsString(request)).thenReturn(jsonPayload);

        // When
        service.processEducationSubmission(requestId, request);

        // Then
        verify(loggingService, times(1))
                .log(jsonPayload, requestId, RecipientName.FULFILLMENT_RESPONSE, Direction.IN);
    }

    private EducationResultRequest createValidEducationResultRequest(String requestId) {
        EducationQualifications qualifications = EducationQualifications.builder()
                .degree("Bachelor of Science")
                .startDate("2020-01-01")
                .endDate("2024-05-31")
                .educationStatusCode("VERIFIED")
                .educationStatus("Verified")
                .grade("3.8")
                .degreeReceived(true)
                .degreeDate("2024-05-31")
                .permissionToContact(true)
                .spokeWith("Registrar")
                .build();

        EducationResultData resultData = EducationResultData.builder()
                .city("Cambridge")
                .region("MA")
                .country("USA")
                .institutionName("Harvard University")
                .qualifications(qualifications)
                .build();

        PropertiesResponse properties = PropertiesResponse.builder()
                .audit("audit-data")
                .rfmFlag(false)
                .build();

        ResponseResultData data = ResponseResultData.builder()
                .decision("APPROVED")
                .reviewScore(95.5)
                .decisionDescription("Education verified successfully")
                .properties(properties)
                .resultData(resultData)
                .build();

        return EducationResultRequest.builder()
                .specversion("1.0")
                .id(requestId)
                .source("hrg:hre:recombo")
                .type("EducationVerification.Result")
                .datacontenttype("application/json")
                .dataschema("https://example.com/schema")
                .data(data)
                .build();
    }
}

