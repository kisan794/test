package com.hireright.sourceintelligence.service.extraction;

import com.hireright.sourceintelligence.api.dto.ParchmentRecord;
import com.hireright.sourceintelligence.domain.entity.Vendors;
import com.hireright.sourceintelligence.domain.repository.VendorsRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ParchmentDataExtractionProcessorTest {

    @Mock
    private VendorsRepository vendorsRepository;

    @Mock
    private MongoTemplate mongoTemplate;

    @InjectMocks
    private ParchmentDataExtractionProcessor processor;

    private Vendors createParchmentVendor() {
        Vendors vendor = new Vendors();
        vendor.setVendor("Parchment Exchange");
        vendor.setProviderId(123);
        vendor.setWebsite("https://www.parchment.com");
        return vendor;
    }

    private List<ParchmentRecord> createSampleRecords() {
        return Arrays.asList(
                ParchmentRecord.builder()
                        .institutionName("Harvard University")
                        .country("USA")
                        .city("Cambridge")
                        .stateCountyRegion("MA")
                        .serviceProvider("Parchment Exchange")
                        .surchargeAmount("5.00")
                        .paymentMethod("Credit Card")
                        .code("HARV001")
                        .turnaroundTime("3")
                        .followUpAllowed("Yes")
                        .build(),
                ParchmentRecord.builder()
                        .institutionName("MIT")
                        .country("USA")
                        .city("Cambridge")
                        .stateCountyRegion("MA")
                        .serviceProvider("Parchment Exchange")
                        .surchargeAmount("5.00")
                        .paymentMethod("Credit Card")
                        .code("MIT001")
                        .turnaroundTime("3")
                        .followUpAllowed("Yes")
                        .build()
        );
    }

    @Test
    void testGetDataExtractionTypeType() {
        String dataExtractionType = processor.getDataExtractionTypeType();
        assertEquals("parchment", dataExtractionType);
    }

    @Test
    void testSupports_Parchment() {
        boolean supports = processor.supports("parchment");
        assertTrue(supports);
    }

    @Test
    void testSupports_OtherType() {
        boolean supports = processor.supports("clearinghouse");
        assertFalse(supports);
    }

    @Test
    void testProcessInstitutionRecords_VendorNotFound() {
        List<ParchmentRecord> sampleRecords = createSampleRecords();
        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(java.util.Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            processor.processInstitutionRecords(sampleRecords);
        });

        assertTrue(exception.getMessage().contains("Vendor 'Parchment Exchange' not found"));
        verify(vendorsRepository).findByVendor("Parchment Exchange");
        verifyNoInteractions(mongoTemplate);
    }

    @Test
    void testProcessInstitutionRecords_EmptyList() {
        Vendors parchmentVendor = createParchmentVendor();
        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(java.util.Optional.of(parchmentVendor));

        Map<String, Object> result = processor.processInstitutionRecords(Collections.emptyList());

        assertNotNull(result);
        assertEquals(0, result.get("totalRecords"));
        assertEquals(0, result.get("totalSourcesUpdated"));
        assertEquals(0, result.get("notFoundRecords"));
        assertTrue(((List<?>) result.get("notFoundRecordsData")).isEmpty());

        verify(vendorsRepository).findByVendor("Parchment Exchange");
        verifyNoMoreInteractions(mongoTemplate);
    }
}