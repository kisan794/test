package org.example.recombointegration.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.example.recombointegration.document.IdeaSubmission.ImplementationComplexity;
import org.example.recombointegration.document.IdeaSubmission.IdeaStatus;
import org.example.recombointegration.document.IdeaSubmission.TimelineType;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Response DTO for idea submission.
 *
 * @author Generated
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Response object containing idea submission details")
public class IdeaSubmissionResponse {

    @Schema(description = "Unique identifier of the idea", example = "507f1f77bcf86cd799439011")
    @JsonProperty("id")
    private String id;

    @Schema(description = "Title of the idea", example = "Automate Daily Report Generation")
    @JsonProperty("title")
    private String title;

    @Schema(description = "Name of the person who submitted the idea", example = "John Doe")
    @JsonProperty("submittedBy")
    private String submittedBy;

    @Schema(description = "Email address of the submitter", example = "john.doe@company.com")
    @JsonProperty("emailAddress")
    private String emailAddress;

    @Schema(description = "Department or function", example = "IT Operations")
    @JsonProperty("department")
    private String department;

    @Schema(description = "Date and time of submission", example = "2026-01-16T10:30:00")
    @JsonProperty("submissionDate")
    private LocalDateTime submissionDate;

    @Schema(description = "Detailed description of the idea")
    @JsonProperty("description")
    private String description;

    @Schema(description = "Main objective or goal")
    @JsonProperty("objective")
    private String objective;

    @Schema(description = "Areas impacted by this idea")
    @JsonProperty("impactAreas")
    private List<String> impactAreas;

    @Schema(description = "Types of improvement")
    @JsonProperty("improvementTypes")
    private List<String> improvementTypes;

    @Schema(description = "Other improvement type description")
    @JsonProperty("improvementTypeOther")
    private String improvementTypeOther;

    @Schema(description = "Expected benefits and impact")
    @JsonProperty("expectedBenefit")
    private String expectedBenefit;

    @Schema(description = "Impact categories")
    @JsonProperty("impactCategories")
    private List<String> impactCategories;

    @Schema(description = "Other impact category description")
    @JsonProperty("impactCategoryOther")
    private String impactCategoryOther;

    @Schema(description = "Implementation complexity level")
    @JsonProperty("implementationComplexity")
    private ImplementationComplexity implementationComplexity;

    @Schema(description = "Suggested implementation steps")
    @JsonProperty("suggestedSteps")
    private String suggestedSteps;

    @Schema(description = "Timeline type")
    @JsonProperty("timelineType")
    private TimelineType timelineType;

    @Schema(description = "Supporting documents URLs or paths")
    @JsonProperty("supportingDocuments")
    private List<String> supportingDocuments;

    @Schema(description = "Additional comments")
    @JsonProperty("additionalComments")
    private String additionalComments;

    @Schema(description = "Current status of the idea", example = "SUBMITTED")
    @JsonProperty("status")
    private IdeaStatus status;

    @Schema(description = "Number of upvotes", example = "5")
    @JsonProperty("upvoteCount")
    private Integer upvoteCount;

    @Schema(description = "Creation timestamp", example = "2026-01-16T10:30:00")
    @JsonProperty("createdAt")
    private LocalDateTime createdAt;

    @Schema(description = "Last update timestamp", example = "2026-01-16T10:30:00")
    @JsonProperty("updatedAt")
    private LocalDateTime updatedAt;

    @Schema(description = "Review timestamp", example = "2026-01-17T14:20:00")
    @JsonProperty("reviewedAt")
    private LocalDateTime reviewedAt;

    @Schema(description = "Name of the reviewer", example = "Jane Smith")
    @JsonProperty("reviewedBy")
    private String reviewedBy;

    @Schema(description = "Review comments from the reviewer")
    @JsonProperty("reviewComments")
    private String reviewComments;

    @Schema(description = "Comments on this idea")
    @JsonProperty("comments")
    private List<IdeaCommentResponse> comments;
}

