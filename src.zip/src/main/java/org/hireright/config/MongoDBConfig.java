package org.hireright.config;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import org.hireright.domain.entity.Source;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.util.concurrent.TimeUnit;

@Configuration
public class MongoDBConfig {
    private static final Logger logger = LoggerFactory.getLogger(MongoDBConfig.class);

    @Bean(name = "devMongoClient")
    public MongoClient devMongoClient() {
        int poolMin = MongoDBConstants.CONNECTION_POOL_MIN_SIZE;
        int poolMax = MongoDBConstants.CONNECTION_POOL_MAX_SIZE;
        int connectionTimeout = MongoDBConstants.CONNECTION_TIMEOUT_MS;
        int socketTimeout = MongoDBConstants.SOCKET_TIMEOUT_MS;
        int serverSelectionTimeout = MongoDBConstants.SERVER_SELECTION_TIMEOUT_MS;
        String devConnectionString = MongoDBConstants.DEV_MONGODB_URI;

        MongoClientSettings devSettings = MongoClientSettings.builder()
                .applyConnectionString(new ConnectionString(devConnectionString))
                .applyToConnectionPoolSettings(builder -> builder
                        .minSize(poolMin)
                        .maxSize(poolMax)
                        .maxWaitTime(connectionTimeout, TimeUnit.MILLISECONDS))
                .applyToSocketSettings(builder -> builder
                        .connectTimeout(connectionTimeout, TimeUnit.MILLISECONDS)
                        .readTimeout(socketTimeout, TimeUnit.MILLISECONDS))
                .applyToClusterSettings(builder -> builder
                        .serverSelectionTimeout(serverSelectionTimeout, TimeUnit.MILLISECONDS))
                .build();

        return MongoClients.create(devSettings);
    }

    @Bean(name = "testMongoClient")
    public MongoClient testMongoClient() {
        int poolMin = MongoDBConstants.CONNECTION_POOL_MIN_SIZE;
        int poolMax = MongoDBConstants.CONNECTION_POOL_MAX_SIZE;
        int connectionTimeout = MongoDBConstants.CONNECTION_TIMEOUT_MS;
        int socketTimeout = MongoDBConstants.SOCKET_TIMEOUT_MS;
        int serverSelectionTimeout = MongoDBConstants.SERVER_SELECTION_TIMEOUT_MS;
        String testConnectionString = MongoDBConstants.TEST_MONGODB_URI;

        MongoClientSettings testSettings = MongoClientSettings.builder()
                .applyConnectionString(new ConnectionString(testConnectionString))
                .applyToConnectionPoolSettings(builder -> builder
                        .minSize(poolMin)
                        .maxSize(poolMax)
                        .maxWaitTime(connectionTimeout, TimeUnit.MILLISECONDS))
                .applyToSocketSettings(builder -> builder
                        .connectTimeout(connectionTimeout, TimeUnit.MILLISECONDS)
                        .readTimeout(socketTimeout, TimeUnit.MILLISECONDS))
                .applyToClusterSettings(builder -> builder
                        .serverSelectionTimeout(serverSelectionTimeout, TimeUnit.MILLISECONDS))
                .build();

        return MongoClients.create(testSettings);
    }

    @Bean(name = "devMongoTemplate")
    public MongoTemplate devMongoTemplate() {
        return new MongoTemplate(devMongoClient(), MongoDBConstants.DEV_DATABASE);
    }

    @Bean(name = "testMongoTemplate")
    public MongoTemplate testMongoTemplate() {
        return new MongoTemplate(testMongoClient(), MongoDBConstants.TEST_DATABASE);
    }

    public int getBatchSize() {
        return MongoDBConstants.BATCH_SIZE;
    }

    public int getLogFrequency() {
        return MongoDBConstants.LOG_FREQUENCY;
    }

    public int getMaxRetries() {
        return MongoDBConstants.MAX_RETRIES;
    }

    public long getRetryDelayMs() {
        return MongoDBConstants.RETRY_DELAY_MS;
    }

}

