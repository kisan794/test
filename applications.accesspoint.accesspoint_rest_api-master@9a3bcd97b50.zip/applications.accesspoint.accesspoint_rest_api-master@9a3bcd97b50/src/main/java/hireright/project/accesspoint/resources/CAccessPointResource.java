/*
 * @(#)$RCSfilev$ $Revision: 1.4.2.2 $ $Date: 2015/03/12 13:45:44 $ $Author: atanasenko $
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/resources/src/main/java/hireright/project/accesspoint/resources/CAccessPointResource.java,v $
 *
 * Copyright 2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	J.Burlakova		2012-04-19	Created
 *	A.Putintsev		2014-09-22	Migrate to jboss7 & resteasy
 *	V.Yudichev 2018-07-16 Add entry point update before saving.
 */

package hireright.project.accesspoint.resources;

import hireright.applications.accesspoint.types.CAccessPointException;
import hireright.applications.accesspoint.types.CParameterBean;
import hireright.applications.accesspoint.types.CParametersListWrapper;
import hireright.applications.accesspoint.util.CDataBaseEntryPointFramework;
import hireright.applications.accesspoint.util.IEntryPointFramework;
import hireright.gui.extensions.entry.core.CTemporaryEntryPointDBContainer;
import hireright.objects.utilities.CEntryPoint;
import hireright.objects.utilities.CStateMachine;
import hireright.project.accesspoint.model.CreateResponse;
import hireright.project.accesspoint.model.EntryPoint;
import hireright.project.accesspoint.model.Fault;
import hireright.project.accesspoint.model.Return;
import hireright.sdk.db.CCurrentThreadConnection;
import hireright.sdk.db.CMultitenantDB;
import hireright.sdk.db3.DB;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CStringUtils;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.xml.bind.JAXBContext;
import java.io.ByteArrayInputStream;
import java.sql.Connection;
import java.util.Calendar;
import java.util.Date;

/**
 * @author Jekaterina Burlakova
 */
@Path(CHRConsts.PATH_ACCESS_POINTS_SUB)
public class CAccessPointResource extends CAbstractResource
{
	protected static final String CLASS_VERSION = "$Revision: 1.4.2.2 $ $Author: atanasenko $";

	private static final int ENTRY_OK = 0;

	private static final int ENTRIES_LIMEET_EXCEED = 1;

	private static final int FALURES_LIMEET_EXCEED = 2;

	private static final int TIME_EXPIRED = 3;

	static final String[] ERROR_MESSAGES = {
		"OK",
		"Entries limit exceed",
		"Falures limit exceed",
		"Time expired"
	};

	/**
	 * Interface for EntryPoint management
	 */
	private final IEntryPointFramework entryPointFramework = new CDataBaseEntryPointFramework();

	/**
	 * Creates EntryPoint according to specified parameters
	 *
	 * @param userID
	 * @param userClass
	 * @param entryPointType
	 * @param domainID
	 * @param designNr
	 * @param authenticationMode
	 * @param login
	 * @param entriesAllowed
	 * @param failuresAllowed
	 * @param expirationDate
	 * @param createSession
	 * @param redirectURL
	 * @param parametersList
	 * @return
	 */
	@POST
	@Produces("application/xml")
	public Response create(@Context HttpHeaders headers, final String input)
	{
		final CreateResponse response = new CreateResponse();
		final Return result = new Return();

		try
		{
			JAXBContext jaxb = JAXBContext.newInstance(EntryPoint.class);
			final EntryPoint entryPointBean = (EntryPoint) jaxb.createUnmarshaller()
				.unmarshal(new ByteArrayInputStream(input.getBytes()));

			CParameterBean regIDParamBean = entryPointBean.getParameter("orderRegID");

			String tenantCode = null;
			if(regIDParamBean != null && CStringUtils.isNotEmpty(regIDParamBean.getValue()))
			{
				tenantCode = getTenantCodeByRegID(regIDParamBean.getValue());
			}

			return CMultitenantDB.execute(tenantCode, () -> DB.execute(() -> {
				DB.requestTransaction();

				CPostprocessor.processEntryPoint(entryPointBean);

				CEntryPoint entryPoint;

				if(CEntryPoint.AUTHENTICATION_MODE_LOGIN.equals(
					entryPointBean.getAuthenticationMode())
					|| CEntryPoint.AUTHENTICATION_MODE_LOGINPASS.equals(
					entryPointBean.getAuthenticationMode()))
				{
					if(entryPointBean.getLogin() == null || entryPointBean.getLogin().isEmpty())
					{
						throw new CAccessPointException(
							"Login can't be null if authenticationMode '"
								+ entryPointBean.getAuthenticationMode() + "' is used");
					}
				}

				CParametersListWrapper parametersListWrapper =
					new CParametersListWrapper(entryPointBean.getParameters());

				entryPoint = entryPointFramework.createEntryPointAuth(entryPointBean.getUserId(),
					entryPointBean.getUserClass(), entryPointBean.getLogin(),
					entryPointBean.getEntryPointType(), entryPointBean.getDesignNr(),
					entryPointBean.getDomainId(),
					CParametersListWrapper.toParameters(parametersListWrapper));

				if(entryPoint == null)
				{
					throw new RuntimeException("Can't create EntryPoint");
				}

				if(entryPointBean.getAuthenticationMode() == null
					|| CEntryPoint.AUTHENTICATION_MODE_NONE.equals(
					entryPointBean.getAuthenticationMode()))
				{
					entryPointBean.setAuthenticationMode(CEntryPoint.AUTHENTICATION_MODE_NONE);
					entryPoint.setPassword("");
				}

				entryPoint.setAuthenticationMode(entryPointBean.getAuthenticationMode());

				if(entryPointBean.getEntriesAllowed() != null
					&& entryPointBean.getEntriesAllowed() > 0)
				{
					entryPoint.setEntriesAllowed(entryPointBean.getEntriesAllowed());
				}

				if(entryPointBean.getFailuresAllowed() != null
					&& entryPointBean.getFailuresAllowed() > 0)
				{
					entryPoint.setFailuresAllowed(entryPointBean.getFailuresAllowed());
				}

				if(entryPointBean.getExpirationTime() != null)
				{
					Calendar calendar = Calendar.getInstance();
					calendar.setTime(new Date());
					calendar.add(Calendar.MINUTE, entryPointBean.getExpirationTime());
					entryPoint.setExpirationDate(calendar.getTime());
				}

				if(entryPointBean.getCreateSession() != null)
				{
					entryPoint.setCreateSession(entryPointBean.getCreateSession() != null
						&& entryPointBean.getCreateSession().equals("Y") ?
						CEntryPoint.CREATE_SESSION_YES :
						CEntryPoint.CREATE_SESSION_NO);
				}

				CPostprocessor.updateEntryPoint(entryPoint, entryPointBean);
				entryPointFramework.saveEntryPoint(entryPoint);

				result.setKey(entryPoint.getKey());
				result.setPassword(entryPoint.getPassword());
				result.setFault(new Fault());

				CPostprocessor.processReturn(result, entryPointBean);

				response.setReturnBean(result);
				return Response.ok(response).build();
			}));
		}
		catch(Throwable e)
		{
			CTraceLog.error(e);
			result.setKey("");
			result.setFault(new Fault("env:Server", e.getMessage()));
			response.setReturnBean(result);
			return Response.status(Status.INTERNAL_SERVER_ERROR).entity(response).build();
		}
		finally
		{
			CTraceLog.info("createEntryPoint", this.getClass().getName());
		}
	}

	@GET
	@Path(CHRConsts.PATH_UUID_STD)
	public Response doLogin(@Context HttpHeaders headers,
		@PathParam(CHRConsts.PARAM_UUID) final String uuid) throws CAccessPointException
	{
		try
		{
			return withConnection(() -> CMultitenantDB.execute(() -> getTenantIDByEntryPoint(uuid),
				entryPointTenantCode -> {

					EntryPoint entryPointBean;

					CEntryPoint entryPoint = entryPointFramework.getEntryPoint(uuid);
					int result = ENTRY_OK;

					if(entryPoint == null)
					{
						throw new CAccessPointException(
							"Can't find EntryPoint for key <" + uuid + ">");
					}

					//
					// Check validity for EntryPoint
					//
					if(!entryPoint.isAllowed())
					{
						result = ENTRIES_LIMEET_EXCEED;
					}
					else if(entryPoint.hasExceededFailures())
					{
						result = FALURES_LIMEET_EXCEED;
					}
					else if(entryPoint.isExpired())
					{
						result = TIME_EXPIRED;
					}

					// We need change counters only if EP is OK, in any case state machine removes invalid EP
					if(result == ENTRY_OK)
					{
						boolean updateResult = entryPoint.decreaseEntriesCounter();

						// Adjust entries counter
						if(!updateResult)
						{
							throw new CAccessPointException(
								"Error while updating entry point counter");
						}
					}

					CStateMachine stateMachine = entryPoint.getStateMachine();
					if(stateMachine != null)
					{
						final Connection conn = CCurrentThreadConnection.getConnection();
						try
						{
							String sState = entryPoint.getStateMachine().getState();

							if(!entryPoint.isAllowed() && (
								CEntryPoint.STATE_WAIT_FOR_LOGIN.equals(sState)
									|| CEntryPoint.STATE_ACTIVE.equals(sState)))
							{
								entryPoint.getStateMachine()
									.changeState(conn, CEntryPoint.CONDITION_LIMIT_OF_ENTRIES);
							}

							if(entryPoint.hasExceededFailures() && (
								CEntryPoint.STATE_WAIT_FOR_LOGIN.equals(sState)
									|| CEntryPoint.STATE_ACTIVE.equals(sState)))
							{
								entryPoint.getStateMachine()
									.changeState(conn, CEntryPoint.CONDITION_LIMIT_OF_FAILURES);
							}
							if(entryPoint.isExpired() && (
								CEntryPoint.STATE_WAIT_FOR_LOGIN.equals(sState)
									|| CEntryPoint.STATE_ACTIVE.equals(sState)))
							{
								entryPoint.getStateMachine()
									.changeState(conn, CEntryPoint.CONDITION_EXPIRE);
							}

							entryPointFramework.commit();
						}
						catch(Exception e)
						{
							entryPointFramework.rollback();
							throw e;
						}
						finally
						{
							entryPointFramework.tearDown();
						}
					}
					if(result != ENTRY_OK)
					{
						throw new CAccessPointException(
							"EntryPoint for key '" + uuid + "' in state " + ERROR_MESSAGES[result]);
					}

					entryPointBean = new EntryPoint(entryPoint);
					return Response.ok(entryPointBean).build();
				}));
		}
		catch(Throwable ex)
		{
			CTraceLog.error(ex);
			throw new CAccessPointException(ex.getMessage() + ";\n see server log");
		}
	}

	private String getTenantCodeByRegID(String sRegID)
	{
		String tenantCode = new DB.Call<String>()
		{
			@Override
			protected String call()
			{
				return (String) DB.session()
					.createSQLQuery(
						"SELECT CON_ID_TO_CON_NAME(con_id) FROM CONTAINERS(request) WHERE reg_id=:regID")
					.setString("regID", sRegID)
					.uniqueResult();
			}
		}.executeReadOnlyIsolatedSafe();

		return CStringUtils.nvl(tenantCode).replace("HR2", "");
	}

	private Integer getTenantIDByEntryPoint(String sEntryPoint)
	{
		return new DB.Call<Integer>()
		{
			@Override
			protected Integer call()
			{
				return CTemporaryEntryPointDBContainer.getTenantContainerIdForTemporaryEntryPoint(
					sEntryPoint);
			}
		}.executeReadOnlyIsolatedSafe();
	}
}
