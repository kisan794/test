package hireright.applications.fulfillment_task_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-13  HRG-332327 initial version
 */

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.Objects;

public class CError implements Serializable {
    @JsonProperty ("text")
    private String m_sText;

    @JsonProperty ("meta")
    private CErrorMeta m_meta;

    private CError() {
    }

    private CError(Builder builder) {
        this.m_sText = builder.m_sText;
        this.m_meta = builder.m_meta;
    }

    public String getText() {
        return this.m_sText;
    }

    public CErrorMeta getMeta() {
        return this.m_meta;
    }

    public String getPath() {
        return this.m_meta != null ? this.m_meta.getPath() : null;
    }

    public String getID() {
        return this.m_meta != null ? this.m_meta.getID() : null;
    }

    public String getDetails() {
        return this.m_meta != null ? this.m_meta.getDetails() : null;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CError error = (CError) o;

        if (!Objects.equals(this.m_sText, error.m_sText)) {
            return false;
        }
        return Objects.equals(this.m_meta, error.m_meta);
    }

    @Override
    public int hashCode() {
        int result = this.m_sText != null ? this.m_sText.hashCode() : 0;
        result = 31 * result + (this.m_meta != null ? this.m_meta.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "CError{" + "m_sText='" + this.m_sText + '\'' + ", m_meta=" + this.m_meta + '}';
    }

    public static final class Builder {
        private String m_sText;
        private CErrorMeta m_meta;

        public Builder() {
        }

        public Builder(CError copy) {
            this.m_sText = copy.getText();
            this.m_meta = copy.getMeta();
        }

        public Builder text(String sText) {
            this.m_sText = sText;
            return this;
        }

        public Builder path(String sPath) {
            if (sPath != null) {
                CErrorMeta.Builder builder;
                if (this.m_meta != null) {
                    builder = new CErrorMeta.Builder(this.m_meta);
                }
                else {
                    builder = new CErrorMeta.Builder();
                }
                builder.path(sPath);
                this.m_meta = builder.build();
            }
            return this;
        }

        public Builder id(String sID) {
            if (sID != null) {
                CErrorMeta.Builder builder;
                if (this.m_meta != null) {
                    builder = new CErrorMeta.Builder(this.m_meta);
                }
                else {
                    builder = new CErrorMeta.Builder();
                }
                builder.id(sID);
                this.m_meta = builder.build();
            }
            return this;
        }

        public Builder details(String sDetails) {
            if (sDetails != null) {
                CErrorMeta.Builder builder;
                if (this.m_meta != null) {
                    builder = new CErrorMeta.Builder(this.m_meta);
                }
                else {
                    builder = new CErrorMeta.Builder();
                }
                builder.details(sDetails);
                this.m_meta = builder.build();
            }
            return this;
        }

        public Builder meta(CErrorMeta meta) {
            this.m_meta = meta;
            return this;
        }

        public CError build() {
            return new CError(this);
        }
    }
}
