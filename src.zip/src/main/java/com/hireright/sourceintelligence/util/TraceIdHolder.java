package com.hireright.sourceintelligence.util;

import lombok.experimental.UtilityClass;
import org.slf4j.MDC;

import java.util.UUID;

/**
 * Utility class for managing trace IDs using SLF4J's MDC (Mapped Diagnostic Context).
 * trace IDs are used to track requests across multiple services and components.
 * This class provides thread-safe trace ID management by leveraging MDC,
 * which maintains a per-thread context map.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@UtilityClass
public class TraceIdHolder
{

    /**
     * MDC key for storing trace ID.
     */
    public static final String TRACE_ID_KEY = "traceId";

    /**
     * HTTP header name for trace ID.
     */
    public static final String TRACE_ID_HEADER = "X-TRACE-ID";

    /**
     * Generates a new trace ID and sets it in MDC.
     *
     * @return the generated trace ID
     */
    public static String generate() {
        String traceId = UUID.randomUUID().toString();
        set(traceId);
        return traceId;
    }

    /**
     * Sets the trace ID in MDC.
     *
     * @param traceId the trace ID to set
     */
    public static void set(String traceId) {
        if (traceId != null && !traceId.isEmpty()) {
            MDC.put(TRACE_ID_KEY, traceId);
        }
    }

    /**
     * Removes the trace ID from MDC.
     */
    public static void clear() {
        MDC.remove(TRACE_ID_KEY);
    }

}