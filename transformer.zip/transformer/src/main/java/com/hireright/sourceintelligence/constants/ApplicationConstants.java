package com.hireright.sourceintelligence.constants;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ApplicationConstants {

	// OpenAPI related constants
	public static final String TITLE = "Source Intelligence Service";
	public static final String VERSION = "1.0";
	public static final String DESCRIPTION = "Microservice to provide capability for  CRUD operations on " + "SourceOrganization";
	// message related constants
	public static final String HEALTH_CHECK = "Up and running!!!";
	public static final String MESSAGE = "message";
	public static final String SOURCEINTELLIGENCE_CREATED_SUCCESSFULLY = "SourceIntelligence created successfully!!!";
	public static final String SOURCEINTELLIGENCE_UPDATED_SUCCESSFULLY = "SourceIntelligence updated successfully!!!";
	public static final String SOURCEINTELLIGENCE_DELETED_SUCCESSFULLY = "SourceIntelligence deleted successfully!!!";
	public static final String SOURCEINTELLIGENCE_FETCHED_SUCCESSFULLY = "SourceIntelligence fetched successfully!!!";
	public static final String DOCUMENT_DOESNOT_EXIST = "Document doesn't exist";
	public static final String INACTIVE_EXCEPTION = "Unable to update due to current Sourceintelligence document "
			+ "status is inactive";
	public static final String ORDER_ITEM_ID_INFO = "sourceintelligence-service : No orderItemId passed";// Genaral Constants
	public static final String HYPHEN = "-";
	public static final String CAMELCASE_YES = "Yes";
	public static final String CAMELCASE_NO = "No";
	public static final String EMPTY_SINGLE = " ";

	public static final String DATE_FORMAT_MMDDYYYY = "MM/dd/yyyy";
	public static final String SOURCE_HISTORY_COLLECTION_SUFFIX = "source_history";
	// database related constants
	public static final String SOURCE_COLLECTION_SUFFIX = "source";
	public static final String EMPLOYMENT_COLLECTION_PREFIX = "employment_";
	public static final String EDUCATION_COLLECTION_PREFIX = "education_";
	public static final String REPORTS_CONTACT_UTILIZATION_COLLECTION = "contact_utilization";
	public static final String REPORTS_COLLECTION = "reports";
	public static final String HON_EDUCATION_PREFIX = "OUEDU";
	public static final String HON_EMPLOYMENT_PREFIX = "OUEMP";
	public static final String UNASSIGNED = "UNASSIGNED";
	public static final String ORIGIN = "HRG1";
	public static final String SIDB_ORIGIN = "SIDB";
	public static final String SIDB_CURD = "CURD";
	public static final String SIDB_APPROVAL_FLOW = "APPROVAL_FLOW";

	public static final String CURRENT = "CURRENT";
	public static final String PREVIOUS = "PREVIOUS";

	public static final String QUERY_DOCUMENT_KEY = "query";
	public static final String TOTAL = "total";
	public static final String QUERY_DOCUMENT_PATH = "path";
	public static final String PHRASE = "phrase";
	public static final String INDEX = "index";
	public static final String COMPOUND = "compound";
	public static final String TOKEN_ORDER = "tokenOrder";
	public static final String SEQUENTIAL = "sequential";
	public static final String HIGHLIGHT = "highlight";
	public static final String AUTOCOMPLETE = "autocomplete";
	public static final String MUST_CLAUSE = "must";
	public static final String SHOULD_CLAUSE = "should";
	public static final String WILDCARD_CLAUSE = "wildcard";
	public static final String ALLOW_ANALYZED_FIELD ="allowAnalyzedField";
	public static final String TEXT = "text";
	public static final String SCORE = "score";
	public static final String SEARCH_SCORE = "searchScore";
	public static final String INDEX_OPERATOR = "index";
	public static final double DAYS_ALLOWED_FOR_SOURCE_RESUBMISSION = 3;
	public static final String UNAUTHORIZED_ERROR_MSG = "User is not authorised to perform search and view sources";
	public static final String ERROR_MSG_TEXT = " Error Message: ";
	public static final String VALUE = "value";
	public static final String MULTI = "multi";
	public static final String WHITESPACE_CASE_INSENSITIVE_ANALYZER = "whitespaceCaseInsensitiveAnalyzer";
	public static final String WHITESPACE_CASE_INSENSITIVE_CITY_ANALYZER = "whitespaceCaseInsensitiveCityAnalyzer";
	public static final String WHITESPACE_CASE_INSENSITIVE_STATE_ANALYZER = "whitespaceCaseInsensitiveStateAnalyzer";
	public static final String WHITESPACE_CASE_INSENSITIVE_COUNTRY_ANALYZER = "whitespaceCaseInsensitiveCountryAnalyzer";

	public static final String USERNAME = "userName";
	public static final String FIRSTNAME = "firstName";
	public static final String LASTNAME = "lastName";
	public static final String ROLES = "roles";
	public static final String OUT_OF_BUSINESS = "outOfBusiness";
	public static final String ERROR_MESSAGE_FORMAT = "Error Code: %s, Severity: %s, Message: %s";
	public static final String INTERNAL_SERVER_ERROR = "Internal server error occurred. Please contact system administrator.";

	public static final String MEDIUM = "MEDIUM";
	public static final Double MIN_CONFIDENCE_THRESHOLD_ALLOWED = 70.0;
	public static final Double MAX_CONFIDENCE_THRESHOLD = 99.0;
	public static final Double EXACT_MATCH_CONFIDENCE_THRESHOLD = 100.0;
	public static final String UNIQUE_ORG_INDEX = "uniqueOrg";
	public static final String SOURCE_AUTO_MATCH = "automatch";
	public static final String SOURCE_SUGGESTIONS = "suggestions";
	public static final String LIMIT = "limit";

	public static final String ADDRESS = "address";
	public static final String CONTACTS = "contacts";

	public static final String LIKE = "like";
	public static final String ACTION_SAVE = "Save";
	public static final String ACTION_IN_PROGRESS = "In Progress";
	public static final String ACTION_SAVE_AND_USE = "Save And Use";
	public static final String ACTION_APPROVED = "Approve";
	public static final String ACTION_ON_HOLD = "On Hold";
	public static final String ACTION_REJECTED = "Rejected";
	public static final String ACTION_DELETE = "Delete";
	public static final String ACTION_ARCHIVE = "Archive";
	public static final String APROVAL_REGION_THRESHOLD = "approval";
	public static final String FROM_SUB_REQUEST = "fromSubRequest";
	public static final String SUB_REQUEST = "subRequest";
	public static final String USER_DETAILS = "userDetails";
	public static final String ORGANIZATION_TYPE_OPTOOL = "organizationType";
	public static final String ORGANIZATION_NAME_OPTOOL = "organizationName";
	public static final String COUNTRY_OPTOOL = "country";
	public static final String STATE_OPTOOL = "state";
	public static final String CITY_OPTOOL = "city";
	public static final String OPTOOL_WEBSERVER_PORT = "optool_webserver_port";
	public static final String USER_NAME = "userName";
	public static final String USER_EMAIL = "userEmail";
	public static final String TRUST_SCORE = "trustScore";
	public static final String APPROVER_PERMISSION = "approvalManager";
	public static final String AUTO_APPOVED = "AUTO_APPROVED";
	public static final String MANUAL_PROCESS = "MANUAL_PROCESS";
	public static final String HON_FROM_VIEW_EDIT = "hon";
	public static final String OPTOOL_INSTANCE_NAME = "optool_instance_name";
	public static final String ORG_TYPE = "organizationType";
	public static final String FROM_VIEW_EDIT = "fromViewEdit";

	public static final String CREATE = "Create";
	public static final String UPDATE = "Update";
	public static final String DELETE = "Delete";

	public static final String STAGE = "stage";
	public static final String PRODUCTION = "production";


	public static final String NEW_SOURCE = "newSource";
	public static final String EXISTING_SOURCE = "existingSource";



	public static final String NO_AUTO_MATCH = "No auto match found";
	public static final String NO_AUTO_MATCH_MISSING_COUNTRY = "No auto match found, country is missing";
	public static final String NO_AUTO_MATCH_MISSING_STATE_CITY= "No auto match found, state or city is missing";
	public static final String NO_AUTO_MATCH_MISSING_CITY= "No auto match found, city is missing";
	public static final String NO_AUTO_MATCH_MISSING_REGION = "No auto match found, region not found for the given country";
	public static final String NO_AUTO_MATCH_ES = "No auto match found, criteria not matched";
	public static final String NO_AUTO_MATCH_DUPLICATE = "No auto match found, found duplicate sources";
	public static final String NO_AUTO_MATCH_JARO = "No auto match found, source not found with in the threshold limit";
	public static final String NO_AUTO_MATCH_MS = "No auto match found, source not found";
	public static final String NO_AUTO_MATCH_EXCEPTION = "No auto match found, internal server error";
}
