package hireright.applications.vendor_api.services;
/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	2017-08-16	Created
 *	M.Kuznetsov	2025-10-29	HRG-345322. Openjdk21-migration
 */

import org.springframework.web.bind.annotation.RequestMethod;

import hireright.components.domain.dialects.vendor_api.BasicResponse;

public class ScreeningReportService {
    public static final String PATH_ADD = "/screening_report";

    public enum EResponseParam {
        MESSAGE
    }

    public enum EMethod implements IMethod {
        ADD(PATH_ADD, RequestMethod.POST, String.class, BasicResponse.class);

        private final String path;
        private final RequestMethod requestMethod;
        private final Class<?> requestBodyClass;
        private final Class<?> responseBodyClass;

        EMethod(String sPath,
                RequestMethod requestMethod,
                Class<?> requestBodyClass,
                Class<?> responseBodyClass) {
            this.path = sPath;
            this.requestMethod = requestMethod;
            this.requestBodyClass = requestBodyClass;
            this.responseBodyClass = responseBodyClass;
        }

        public String getPath() {
            return this.path;
        }

        public RequestMethod getRequestMethod() {
            return this.requestMethod;
        }

        public Class<?> getRequestBodyClass() {
            return this.requestBodyClass;
        }

        public Class<?> getResponseBodyClass() {
            return this.responseBodyClass;
        }

        public boolean isValidRequest(Object request) {
            return true;
        }
    }
}
