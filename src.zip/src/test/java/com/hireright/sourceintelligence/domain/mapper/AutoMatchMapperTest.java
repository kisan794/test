package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.Alias;
import com.hireright.sourceintelligence.api.dto.optool.ContactDTO;
import com.hireright.sourceintelligence.api.dto.optool.MailAddressDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import org.json.JSONArray;
import com.mongodb.BasicDBObject;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;
import java.util.List;
import java.util.Map;

import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.CREATE;
import static org.junit.jupiter.api.Assertions.*;

class AutoMatchMapperTest {

    private AutoMatchMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = Mappers.getMapper(AutoMatchMapper.class);
    }

    @Test
    void getPayloadFieldForStrings_shouldHandleNullMissingPlainAndEncodedValues() {
        Source source = new Source();

        assertEquals("", mapper.getPayloadFieldForStrings(source, "departmentName"));

        JSONObject payload = new JSONObject();
        payload.put("website", "www.test.com");
        payload.put("departmentName", "Admissions");
        payload.put("notes", "Important note");

        source.setPayload(BasicDBObject.parse(payload.toString()));

        assertEquals("www.test.com", mapper.getPayloadFieldForStrings(source, "website"));
        assertEquals(encodeUtf16Be("Admissions"), mapper.getPayloadFieldForStrings(source, "departmentName"));
        assertEquals(encodeUtf16Be("Important note"), mapper.getPayloadFieldForStrings(source, "notes"));
        assertEquals("", mapper.getPayloadFieldForStrings(source, "missingKey"));
    }

    @Test
    void getPayloadFieldForBoolean_shouldHandleAllBranches() {
        Source source = new Source();
        assertFalse(mapper.getPayloadFieldForBoolean(source, "unAccreditedSource"));

        JSONObject payload = new JSONObject();
        payload.put("unAccreditedSource", true);
        source.setPayload(BasicDBObject.parse(payload.toString()));
        assertTrue(mapper.getPayloadFieldForBoolean(source, "unAccreditedSource"));

        JSONObject payload2 = new JSONObject();
        source.setPayload(BasicDBObject.parse(payload2.toString()));
        assertFalse(mapper.getPayloadFieldForBoolean(source, "unAccreditedSource"));
    }

    @Test
    void getLastModifiedDate_shouldReturnNullForCreateAndDateOtherwise() {
        Source source = new Source();
        Instant now = Instant.now();
        source.setLastModifiedDate(now);

        source.setAction(CREATE);
        assertNull(mapper.getLastModifiedDate(source, "ignored"));

        source.setAction("UPDATE");
        assertEquals(now, mapper.getLastModifiedDate(source, "ignored"));
    }

    @Test
    void mapInstituteAndMapCompany_shouldReturnExpectedValues() {
        Source source = new Source();

        assertNull(mapper.mapInstitute(source));
        assertNull(mapper.mapCompany(source));

        JSONObject rel = new JSONObject().put("name", "Parent Org");
        JSONArray relationships = new JSONArray().put(rel);
        JSONObject payload = new JSONObject().put("relationships", relationships);

        source.setPayload(BasicDBObject.parse(payload.toString()));

        source.setOrganizationType(OrganizationType.EDUCATION);
        assertEquals("Parent Org", mapper.mapInstitute(source));
        assertNull(mapper.mapCompany(source));

        source.setOrganizationType(OrganizationType.EMPLOYMENT);
        assertNull(mapper.mapInstitute(source));
        assertEquals("Parent Org", mapper.mapCompany(source));
        source.setPayload(BasicDBObject.parse(new JSONObject().toString()));
        assertNull(mapper.mapInstitute(source));
        assertNull(mapper.mapCompany(source));
    }

    @Test
    void getDoNotContactAndAdditionalInfo_shouldCoverAllBranches() {
        Source source = new Source();

        assertFalse(mapper.getDoNotContact(source));
        assertEquals("", mapper.getAdditionalInfo(source, "contactPersonName"));

        JSONObject info = new JSONObject()
                .put("doNotContact", "")
                .put("contactPersonName", "John Doe")
                .put("contactPersonTitle", "Manager")
                .put("sourceLanguage", "English")
                .put("contactTimeFrom", "09:00")
                .put("contactTimeTo", "17:00")
                .put("contactTimeZone", "IST")
                .put("releaseType", "Written")
                .put("someOtherField", "OtherValue");

        JSONObject payload = new JSONObject()
                .put("addionalInfo", new JSONArray().put(info));

        source.setPayload(BasicDBObject.parse(payload.toString()));

        assertFalse(mapper.getDoNotContact(source));
        assertEquals("John Doe", mapper.getAdditionalInfo(source, "contactPersonName"));
        assertEquals("Manager", mapper.getAdditionalInfo(source, "contactPersonTitle"));
        assertEquals("English", mapper.getAdditionalInfo(source, "sourceLanguage"));
        assertEquals("09:00", mapper.getAdditionalInfo(source, "contactTimeFrom"));
        assertEquals("17:00", mapper.getAdditionalInfo(source, "contactTimeTo"));
        assertEquals("IST", mapper.getAdditionalInfo(source, "contactTimeZone"));
        assertEquals("Written", mapper.getAdditionalInfo(source, "releaseType"));
        assertEquals("OtherValue", mapper.getAdditionalInfo(source, "someOtherField"));
        assertEquals("", mapper.getAdditionalInfo(source, "missingField"));

        JSONObject infoDoNotContact = new JSONObject()
                .put("doNotContact", "true")
                .put("contactPersonName", "Hidden Person")
                .put("contactPersonTitle", "Hidden Title")
                .put("sourceLanguage", "Hidden Language")
                .put("contactTimeFrom", "10:00")
                .put("contactTimeTo", "18:00")
                .put("contactTimeZone", "UTC")
                .put("releaseType", "Phone");

        JSONObject payloadDoNotContact = new JSONObject()
                .put("addionalInfo", new JSONArray().put(infoDoNotContact));

        source.setPayload(BasicDBObject.parse(payloadDoNotContact.toString()));

        assertTrue(mapper.getDoNotContact(source));
        assertEquals("", mapper.getAdditionalInfo(source, "contactPersonName"));
        assertEquals("", mapper.getAdditionalInfo(source, "contactPersonTitle"));
        assertEquals("", mapper.getAdditionalInfo(source, "sourceLanguage"));
        assertEquals("", mapper.getAdditionalInfo(source, "contactTimeFrom"));
        assertEquals("", mapper.getAdditionalInfo(source, "contactTimeTo"));
        assertEquals("", mapper.getAdditionalInfo(source, "contactTimeZone"));
        assertEquals("", mapper.getAdditionalInfo(source, "releaseType"));

        JSONObject automatedServiceContactDetail = new JSONObject()
                .put("type", "contactAutomatedServices");

        JSONObject contact = new JSONObject()
                .put("contactDetails", new JSONArray().put(automatedServiceContactDetail));

        JSONObject payloadWithAutomatedService = new JSONObject()
                .put("contacts", new JSONArray().put(contact))
                .put("addionalInfo", new JSONArray().put(infoDoNotContact));

        source.setPayload(BasicDBObject.parse(payloadWithAutomatedService.toString()));

        assertEquals("10:00", mapper.getAdditionalInfo(source, "contactTimeFrom"));
        assertEquals("18:00", mapper.getAdditionalInfo(source, "contactTimeTo"));
        assertEquals("UTC", mapper.getAdditionalInfo(source, "contactTimeZone"));
        assertEquals("Phone", mapper.getAdditionalInfo(source, "releaseType"));

        assertEquals("", mapper.getAdditionalInfo(source, "contactPersonName"));
        assertEquals("", mapper.getAdditionalInfo(source, "contactPersonTitle"));
        assertEquals("", mapper.getAdditionalInfo(source, "sourceLanguage"));
    }

    @Test
    void getAddress_shouldHandleBranches() {
        Source source = new Source();

        assertNull(mapper.getAddress(source));

        JSONObject addressObj = new JSONObject().put("line", "221B Baker Street");
        JSONObject payload = new JSONObject().put("address", new JSONArray().put(addressObj));
        source.setPayload(BasicDBObject.parse(payload.toString()));

        assertEquals("221B Baker Street", mapper.getAddress(source));

        source.setPayload(BasicDBObject.parse(new JSONObject().toString()));
        assertNull(mapper.getAddress(source));
    }

    @Test
    void isAutomatedServiceAvailable_shouldHandleAllPaths() {
        assertFalse(mapper.isAutomatedServiceAvailable(null));
        assertFalse(mapper.isAutomatedServiceAvailable(new JSONObject()));
        assertFalse(mapper.isAutomatedServiceAvailable(new JSONObject().put("contacts", new JSONArray())));
        assertFalse(mapper.isAutomatedServiceAvailable(new JSONObject().put("contacts", new JSONArray().put(JSONObject.NULL))));
        assertFalse(mapper.isAutomatedServiceAvailable(
                new JSONObject().put("contacts", new JSONArray().put(new JSONObject()))
        ));
        assertFalse(mapper.isAutomatedServiceAvailable(
                new JSONObject().put("contacts", new JSONArray().put(new JSONObject().put("contactDetails", new JSONArray())))
        ));

        JSONObject nonAutomated = new JSONObject().put("type", "contactPhones");
        JSONObject automated = new JSONObject().put("type", "contactAutomatedServices");

        JSONObject firstContact = new JSONObject().put("contactDetails", new JSONArray().put(nonAutomated).put(automated));
        JSONObject payload = new JSONObject().put("contacts", new JSONArray().put(firstContact));

        assertTrue(mapper.isAutomatedServiceAvailable(payload));
    }

    @Test
    void mapContactDetailsForAS_shouldMapAllAutomatedServiceFields() {
        Source source = new Source();

        assertTrue(mapper.mapContactDetailsForAS(source).isEmpty());

        JSONObject commInfo1 = new JSONObject().put("type", "uri").put("value", "https://provider.example.com");
        JSONObject commInfo2 = new JSONObject().put("type", "codes").put("value", "A1;A2");
        JSONObject commInfo3 = new JSONObject().put("type", "companyNames").put("value", "Inst1;Inst2");
        JSONObject commInfo4 = new JSONObject().put("type", "branch").put("value", "B1;B2");
        JSONObject commInfo5 = new JSONObject().put("type", "fromYear").put("value", "2010");
        JSONObject commInfo6 = new JSONObject().put("type", "toYear").put("value", "2020");
        JSONObject commInfo7 = new JSONObject().put("type", "surChargeAmount").put("value", "25");
        JSONObject commInfo8 = new JSONObject().put("type", "surChargeCurrency").put("value", "USD");
        JSONObject commInfo9 = new JSONObject().put("type", "paymentMethod").put("value", "Card");
        JSONObject commInfo10 = new JSONObject().put("type", "followUpAllowed").put("value", "true");
        JSONObject commInfo11 = new JSONObject().put("type", "followUpAllowedAfter").put("value", "2");
        JSONObject commInfo12 = new JSONObject().put("type", "followUpAllowedAfterTimeUnit").put("value", "days");
        JSONObject commInfo13 = new JSONObject().put("type", "turnAroundTime").put("value", "48");
        JSONObject commInfo14 = new JSONObject().put("type", "turnAroundTimeUnit").put("value", "hours");
        JSONObject commInfoIgnored = new JSONObject().put("type", "ignoredType").put("value", "ignored");
        JSONObject commInfoNoType = new JSONObject().put("value", "missingType");
        JSONObject commInfoNullType = new JSONObject().put("type", JSONObject.NULL).put("value", "missingType");

        JSONObject automatedCommunication = new JSONObject()
                .put("name", "Equifax High School")
                .put("providerID", "12")
                .put("communicationInfo", new JSONArray()
                        .put(commInfo1)
                        .put(commInfo2)
                        .put(commInfo3)
                        .put(commInfo4)
                        .put(commInfo5)
                        .put(commInfo6)
                        .put(commInfo7)
                        .put(commInfo8)
                        .put(commInfo9)
                        .put(commInfo10)
                        .put(commInfo11)
                        .put(commInfo12)
                        .put(commInfo13)
                        .put(commInfo14)
                        .put(commInfoIgnored)
                        .put(commInfoNoType)
                        .put(commInfoNullType)
                );

        JSONObject automatedCommunicationDefaultProvider = new JSONObject()
                .put("name", "NSCH")
                .put("communicationInfo", new JSONArray()
                        .put(new JSONObject().put("type", "codes").put("value", "X1;X2"))
                        .put(new JSONObject().put("type", "companyNames").put("value", "Name1;Name2"))
                );

        JSONObject automatedDetail1 = new JSONObject()
                .put("type", "contactAutomatedServices")
                .put("priority", "5")
                .put("communication", new JSONArray().put(automatedCommunication));

        JSONObject automatedDetail2 = new JSONObject()
                .put("type", "contactAutomatedServices")
                .put("priority", 8)
                .put("communication", new JSONArray().put(automatedCommunicationDefaultProvider));

        JSONObject automatedDetailNoComm = new JSONObject()
                .put("type", "contactAutomatedServices");

        JSONObject nonAutomatedDetail = new JSONObject()
                .put("type", "contactPhones")
                .put("communication", new JSONArray().put("ignored"));

        JSONObject firstContact = new JSONObject()
                .put("contactDetails", new JSONArray()
                        .put(nonAutomatedDetail)
                        .put(automatedDetail1)
                        .put(automatedDetail2)
                );

        JSONObject payload = new JSONObject().put("contacts", new JSONArray().put(firstContact));
        source.setPayload(BasicDBObject.parse(payload.toString()));

        List<Map<String, Object>> result = mapper.mapContactDetailsForAS(source);

        assertEquals(2, result.size());

        Map<String, Object> first = result.get(0);
        assertEquals("Equifax High School", first.get("name"));
        assertEquals(12, first.get("provider"));
        assertEquals(5, first.get("priority"));
        assertEquals("https://provider.example.com", first.get("providerLink"));
        assertEquals("2010,2020", first.get("EquifaxHighSchoolDateRange"));
        assertEquals("25", first.get("surchargeAmount"));
        assertEquals("USD", first.get("surchargeCurrency"));
        assertEquals("Card", first.get("paymentMethod"));
        assertEquals("true", first.get("followUpAllowed"));
        assertEquals("2", first.get("followUpAllowedAfter"));
        assertEquals("days", first.get("followUpAllowedAfterTimeUnit"));
        assertEquals("48", first.get("turnAroundTime"));
        assertEquals("hours", first.get("turnAroundTimeUnit"));
        assertArrayEquals(new String[]{"A1", "A2"}, (String[]) first.get("codes"));
        assertArrayEquals(new String[]{"B1", "B2"}, (String[]) first.get("branches"));

        Map<String, Object> second = result.get(1);
        assertEquals("NSCH", second.get("name"));
        assertNotNull(second.get("codes"));
        assertEquals(8, second.get("priority"));
    }

    @Test
    void isDoNotContact_shouldHandleTrueFalseAndMissing() {
        JSONObject payloadTrue = new JSONObject()
                .put("addionalInfo", new JSONArray()
                        .put(new JSONObject().put("doNotContact", "yes")));
        assertTrue(mapper.isDoNotContact(payloadTrue));

        JSONObject payloadFalseLiteral = new JSONObject()
                .put("addionalInfo", new JSONArray()
                        .put(new JSONObject().put("doNotContact", "false")));
        assertFalse(mapper.isDoNotContact(payloadFalseLiteral));

        JSONObject payloadEmpty = new JSONObject()
                .put("addionalInfo", new JSONArray()
                        .put(new JSONObject().put("doNotContact", "")));
        assertFalse(mapper.isDoNotContact(payloadEmpty));

        JSONObject payloadMissing = new JSONObject()
                .put("addionalInfo", new JSONArray()
                        .put(new JSONObject()));
        assertFalse(mapper.isDoNotContact(payloadMissing));
    }

    @Test
    void mapContactBaseDTO_shouldHandlePriorityTurnaroundFollowupSurchargeAndPayment() {
        ContactDTO dto = new ContactDTO();

        JSONObject json = new JSONObject()
                .put("priority", "3")
                .put("turnAroundTime", "24")
                .put("turnAroundTimeUnit", "hours")
                .put("followUpAllowed", true)
                .put("followUpAllowedAfter", "4")
                .put("followUpAllowedAfterTimeUnit", "days")
                .put("surChargeAmount", "10")
                .put("surChargeCurrency", "USD")
                .put("paymentMethod", "Wire");

        mapper.mapContactBaseDTO(json, dto);

        assertEquals(3, dto.getPriority());
        assertEquals("24", dto.getTurnAroundTime());
        assertEquals("hours", dto.getTurnAroundTimeUnit());
        assertEquals("true", dto.getIsFollowUpAllowed());
        assertEquals("4", dto.getFollowUpAllowedAfter());
        assertEquals("days", dto.getFollowUpAllowedAfterUnit());
        assertEquals("10", dto.getSurchargeAmount());
        assertEquals("USD", dto.getSurchargeCurrency());
        assertEquals("Wire", dto.getPaymentMethod());

        ContactDTO dto2 = new ContactDTO();
        JSONObject json2 = new JSONObject()
                .put("priority", 6)
                .put("followUpAllowed", "false")
                .put("followUpAllowedAfter", "7")
                .put("surChargeAmount", "15")
                .put("surChargeCurrency", "INR");
        mapper.mapContactBaseDTO(json2, dto2);

        assertEquals(6, dto2.getPriority());
        assertEquals("false", dto2.getIsFollowUpAllowed());
        assertEquals("7", dto2.getFollowUpAllowedAfter());
        assertEquals("days", dto2.getFollowUpAllowedAfterUnit());

        ContactDTO dto3 = new ContactDTO();
        mapper.mapContactBaseDTO(new JSONObject(), dto3);
        assertNull(dto3.getTurnAroundTime());
        assertNull(dto3.getPaymentMethod());
    }

    @Test
    void mapCommunication_shouldHandlePhonesFaxesMailsEmailsAndWebsites() {
        ContactDTO phoneDto = new ContactDTO();
        JSONArray phoneCommunication = new JSONArray().put(
                new JSONObject()
                        .put("name", "John")
                        .put("receipt", "Main")
                        .put("department", "Ops")
                        .put("communicationInfo", new JSONArray()
                                .put(new JSONObject().put("type", "areaCode").put("value", "080"))
                                .put(new JSONObject().put("type", "countryCode").put("value", "91"))
                                .put(new JSONObject().put("type", "phoneCountryCode").put("value", "0091"))
                                .put(new JSONObject().put("type", "phoneNumber").put("value", "123456789"))
                                .put(new JSONObject().put("type", "extension").put("value", "44"))
                                .put(new JSONObject().put("type", "ignored").put("value", "ignored"))
                        )
        );
        mapper.mapCommunication("contactPhones", phoneCommunication, phoneDto);
        assertEquals("John,Main-Ops", phoneDto.getContact());
        assertNotNull(phoneDto.getNumbers());
        assertEquals(1, phoneDto.getNumbers().size());
        assertEquals("080", phoneDto.getNumbers().get(0).getAreaCode());
        assertEquals("91", phoneDto.getNumbers().get(0).getCountryCode());
        assertEquals("0091", phoneDto.getNumbers().get(0).getPhoneCountryCode());
        assertEquals("123456789", phoneDto.getNumbers().get(0).getNumber());
        assertEquals("44", phoneDto.getNumbers().get(0).getExtension());

        ContactDTO faxDto = new ContactDTO();
        mapper.mapCommunication("contactFaxes", phoneCommunication, faxDto);
        assertNotNull(faxDto.getNumbers());
        assertEquals(1, faxDto.getNumbers().size());

        ContactDTO mailDto = new ContactDTO();
        JSONArray mailCommunication = new JSONArray().put(
                new JSONObject()
                        .put("name", "Jane")
                        .put("communicationInfo", new JSONArray()
                                .put(new JSONObject().put("type", "countryName").put("value", "India"))
                                .put(new JSONObject().put("type", "region").put("value", "KA"))
                                .put(new JSONObject().put("type", "city").put("value", "Bengaluru"))
                                .put(new JSONObject().put("type", "address").put("value", "MG Road"))
                                .put(new JSONObject().put("type", "postalCode").put("value", "560001"))
                                .put(new JSONObject().put("type", "state").put("value", "Karnataka"))
                        )
        );
        mapper.mapCommunication("contactMails", mailCommunication, mailDto);
        assertNotNull(mailDto.getAddresses());
        assertEquals(1, mailDto.getAddresses().size());
        MailAddressDTO mappedMail = mailDto.getAddresses().get(0);
        assertEquals("India", mappedMail.getCountry());
        assertEquals("Karnataka", mappedMail.getRegion());
        assertEquals(encodeUtf16Be("Bengaluru"), mappedMail.getCity());
        assertEquals("MG Road", mappedMail.getAddress());
        assertEquals("560001", mappedMail.getPostalCode());

        ContactDTO emailDto = new ContactDTO();
        JSONArray emailCommunication = new JSONArray().put(
                new JSONObject()
                        .put("communicationInfo", new JSONArray()
                                .put(new JSONObject().put("type", "address").put("value", " TEST@EXAMPLE.COM "))
                        )
        );
        mapper.mapCommunication("contactEmails", emailCommunication, emailDto);
        assertEquals(List.of("test@example.com"), emailDto.getEmails());

        ContactDTO websiteDto = new ContactDTO();
        JSONArray websiteCommunication = new JSONArray().put(
                new JSONObject()
                        .put("communicationInfo", new JSONArray()
                                .put(new JSONObject().put("type", "addresses").put("value", " HTTPS://ABC.COM "))
                        )
        );
        mapper.mapCommunication("contactWebsites", websiteCommunication, websiteDto);
        assertEquals(List.of("https://abc.com"), websiteDto.getWebsites());

        ContactDTO ignoredDto = new ContactDTO();
        JSONArray ignoredCommunication = new JSONArray().put(
                new JSONObject().put("name", "Nobody")
        );
        mapper.mapCommunication("unknownType", ignoredCommunication, ignoredDto);
        assertEquals("Nobody", ignoredDto.getContact());
        assertNull(ignoredDto.getNumbers());
        assertNull(ignoredDto.getEmails());
        assertNull(ignoredDto.getAddresses());
        assertNull(ignoredDto.getWebsites());
    }

    @Test
    void mapContactDetails_shouldHandleNullEmptyDoNotContactAndMatchingTypes() {
        Source source = new Source();

        ContactDTO empty1 = mapper.mapContactDetails(source, "contactPhones");
        assertNotNull(empty1);

        source.setPayload(BasicDBObject.parse(new JSONObject().toString()));
        ContactDTO empty2 = mapper.mapContactDetails(source, "contactPhones");
        assertNotNull(empty2);

        source.setPayload(BasicDBObject.parse(
                new JSONObject().put("contacts", new JSONArray()).toString()
        ));
        ContactDTO empty3 = mapper.mapContactDetails(source, "contactPhones");
        assertNotNull(empty3);

        source.setPayload(BasicDBObject.parse(
                new JSONObject().put("contacts", new JSONArray().put(new JSONObject())).toString()
        ));
        ContactDTO empty4 = mapper.mapContactDetails(source, "contactPhones");
        assertNotNull(empty4);

        JSONObject doNotContactPayload = new JSONObject()
                .put("addionalInfo", new JSONArray().put(new JSONObject().put("doNotContact", "true")))
                .put("contacts", new JSONArray().put(
                        new JSONObject().put("contactDetails", new JSONArray().put(
                                new JSONObject().put("type", "contactPhones")
                        ))
                ));
        source.setPayload(BasicDBObject.parse(doNotContactPayload.toString()));
        assertNull(mapper.mapContactDetails(source, "contactPhones"));

        JSONObject phoneDetail = new JSONObject()
                .put("type", "contactPhones")
                .put("priority", "1")
                .put("turnAroundTime", "12")
                .put("turnAroundTimeUnit", "hours")
                .put("followUpAllowed", "true")
                .put("followUpAllowedAfter", "2")
                .put("followUpAllowedAfterTimeUnit", "days")
                .put("surChargeAmount", "5")
                .put("surChargeCurrency", "USD")
                .put("paymentMethod", "Card")
                .put("communication", new JSONArray().put(
                        new JSONObject()
                                .put("name", "Phone Contact")
                                .put("communicationInfo", new JSONArray()
                                        .put(new JSONObject().put("type", "countryCode").put("value", "91"))
                                        .put(new JSONObject().put("type", "phoneCountryCode").put("value", "0091"))
                                        .put(new JSONObject().put("type", "phoneNumber").put("value", "999999"))
                                )
                ));

        JSONObject payload = new JSONObject()
                .put("addionalInfo", new JSONArray().put(new JSONObject().put("doNotContact", "")))
                .put("contacts", new JSONArray().put(
                        new JSONObject().put("contactDetails", new JSONArray().put(phoneDetail))
                ));

        source.setPayload(BasicDBObject.parse(payload.toString()));

        ContactDTO result = mapper.mapContactDetails(source, "contactPhones");
        assertNotNull(result);
        assertEquals(1, result.getPriority());
        assertNotNull(result.getNumbers());
        assertEquals("91", result.getNumbers().get(0).getCountryCode());
        assertEquals("999999", result.getNumbers().get(0).getNumber());
    }

    @Test
    void mapContactDetails_shouldHandleFaxCountryCodeInheritanceAndFallback() {
        Source source = new Source();

        JSONObject phoneDetail = new JSONObject()
                .put("type", "contactPhones")
                .put("communication", new JSONArray().put(
                        new JSONObject().put("communicationInfo", new JSONArray()
                                .put(new JSONObject().put("type", "countryCode").put("value", "44"))
                                .put(new JSONObject().put("type", "phoneNumber").put("value", "111111"))
                        )
                ));

        JSONObject faxDetail = new JSONObject()
                .put("type", "contactFaxes")
                .put("communication", new JSONArray().put(
                        new JSONObject().put("communicationInfo", new JSONArray()
                                .put(new JSONObject().put("type", "phoneCountryCode").put("value", "0044"))
                                .put(new JSONObject().put("type", "phoneNumber").put("value", "222222"))
                        )
                ));

        JSONObject payload = new JSONObject()
                .put("addionalInfo", new JSONArray().put(new JSONObject().put("doNotContact", "")))
                .put("contacts", new JSONArray().put(new JSONObject().put("contactDetails", new JSONArray().put(phoneDetail).put(faxDetail))));
        source.setPayload(BasicDBObject.parse(payload.toString()));

        ContactDTO faxResult = mapper.mapContactDetails(source, "contactFaxes");
        assertNotNull(faxResult);
        assertNotNull(faxResult.getNumbers());
        assertEquals("44", faxResult.getNumbers().get(0).getCountryCode());

        JSONObject faxOnlyDetail = new JSONObject()
                .put("type", "contactFaxes")
                .put("communication", new JSONArray().put(
                        new JSONObject().put("communicationInfo", new JSONArray()
                                .put(new JSONObject().put("type", "phoneCountryCode").put("value", "0091"))
                                .put(new JSONObject().put("type", "phoneNumber").put("value", "333333"))
                        )
                ));

        JSONObject payloadFaxOnly = new JSONObject()
                .put("addionalInfo", new JSONArray().put(new JSONObject().put("doNotContact", "")))
                .put("contacts", new JSONArray().put(new JSONObject().put("contactDetails", new JSONArray().put(faxOnlyDetail))));
        source.setPayload(BasicDBObject.parse(payloadFaxOnly.toString()));

        ContactDTO faxFallback = mapper.mapContactDetails(source, "contactFaxes");
        assertNotNull(faxFallback);
        assertNotNull(faxFallback.getNumbers());
        assertEquals("0091", faxFallback.getNumbers().get(0).getCountryCode());
    }

    @Test
    void mapOrganizationAlias_shouldHandleNullEmptyAndValidAliases() {
        assertTrue(mapper.mapOrganizationAlias(null).isEmpty());
        assertTrue(mapper.mapOrganizationAlias(new Alias[0]).isEmpty());

        Alias valid = new Alias();
        valid.setName("Alias One");

        Alias empty = new Alias();
        empty.setName("");

        Alias nullName = new Alias();

        List<String> result = mapper.mapOrganizationAlias(new Alias[]{valid, empty, nullName});
        assertEquals(1, result.size());
        assertEquals(encodeUtf16Be("Alias One"), result.get(0));
    }


    private String encodeUtf16Be(String value) {
        return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_16BE));
    }
}