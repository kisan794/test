/*
 * @(#)$RCSfile: CParametersListWrapper.java,v $ $Revision: 1.2 $ $Date: 2014/07/28 14:57:08 $ $Author: aputintsev $ $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/types/CParametersListWrapper.java,v $
 *
 * History:
 *     $Log: CParametersListWrapper.java,v $
 *     Revision 1.2  2014/07/28 14:57:08  aputintsev
 *     forked from production version - projects_src/applications/accesspoint
 *
 *     Revision 1.1.2.1  2009/08/13 13:24:23  asolntsev
 *     Created by St.Petersburg team
 *
 *     Revision 1.1.1.1  2009/07/31 11:24:26  banton
 *     Task 39986 1.1
 *
 *     Revision 1.5  2009/07/30 13:46:31  banton
 *     Added full multi value properties support
 *
 *     Revision 1.4  2009/07/29 09:50:13  banton
 *     Fixed WSDL. Added WSDL for 'light' Service
 *
 *     Revision 1.3  2009/07/27 14:29:43  banton
 *     Fixed user exceptions
 *
 *     Revision 1.2  2009/07/23 11:31:44  banton
 *     Added some sources decorations
 *
 */

package hireright.applications.accesspoint.types;

import hireright.sdk.util.CProperties;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import org.apache.commons.collections.MultiMap;
import org.apache.commons.collections.map.MultiValueMap;

/**
 *
 * @author banton
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(name="ParametersListType", namespace = "http://hireright.com/applications/accesspoint/types")
public class CParametersListWrapper
{
    private  List<CParameterBean> m_parameter;

    public CParametersListWrapper()
    {
    }

    public CParametersListWrapper(List<CParameterBean> m_parameter)
    {
        this.m_parameter = m_parameter;
    }

    public List<CParameterBean> getParameter()
    {
        return m_parameter;
    }

    public void setParameter(List<CParameterBean> m_parameter)
    {
        this.m_parameter = m_parameter;
    }


    public static MultiMap toParameters(CParametersListWrapper parametersListWrapper)
    {
    MultiMap result = new MultiValueMap();

        if (parametersListWrapper.getParameter()!=null)
            for (CParameterBean parameterBean : parametersListWrapper.getParameter())
                result.put(parameterBean.getName(), parameterBean.getValue());

        return result;

    }

    public static List<CParameterBean> createParameters(MultiMap properties)
    {
    List<CParameterBean> result = new ArrayList<CParameterBean>();
    Set<String> keySet = properties.keySet();

        for (Iterator<String> keyIterator = keySet.iterator();
             keyIterator.hasNext();)
            {
            String key = keyIterator.next();
            Object valueObject = properties.get(key);
            Collection<Object> collection = null;

            if (valueObject instanceof Collection)
                collection = (Collection)valueObject;
            else
                {
                collection = new ArrayList<Object>(1);
                collection.add(valueObject);
                }

            for (Object value : collection)
                {
                CParameterBean parameterBean = new CParameterBean();

                parameterBean.setName(key);
                parameterBean.setValue(value.toString());
                result.add(parameterBean);
                }

            }

        return result;
    }


}
