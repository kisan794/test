package com.hireright.sourceintelligence.api.dto.notification;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hireright.sourceintelligence.domain.enums.NotificationType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Request DTO for sending notifications
 * Follows Single Responsibility Principle - only handles notification request data
 * Supports multiple notification types via Strategy Pattern
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NotificationRequestDTO {

    @NotNull(message = "Notification type is required")
    private NotificationType notificationType;

    /**
     * Email notification details (if type is EMAIL)
     */
    @Valid
    private EmailNotificationDTO emailNotification;

    /**
     * SMS notification details (if type is SMS)
     */
    @Valid
    private SmsNotificationDTO smsNotification;

    private boolean async;

    private String requestId;
}

