package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.rds.CountryRegionResponseDTO;
import com.hireright.sourceintelligence.api.dto.rds.CountryResponseDTO;
import com.hireright.sourceintelligence.api.dto.rds.LanguageResponseDTO;
import com.hireright.sourceintelligence.api.dto.rds.VendorResponseDTO;
import com.hireright.sourceintelligence.service.CountryService;
import com.hireright.sourceintelligence.service.RDSService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RDSApiControllerTest {

    @Mock
    private RDSService rdsService;

    @Mock
    private CountryService countryService;

    @InjectMocks
    private RDSApiController rdsApiController;

    private VendorResponseDTO vendorResponseDTO;
    private CountryResponseDTO countryResponseDTO;
    private CountryRegionResponseDTO countryRegionResponseDTO;
    private LanguageResponseDTO languageResponseDTO;

    @BeforeEach
    void setUp() {
        vendorResponseDTO = new VendorResponseDTO();
        countryResponseDTO = new CountryResponseDTO();
        countryRegionResponseDTO = new CountryRegionResponseDTO();
        languageResponseDTO = new LanguageResponseDTO();
    }

    @Test
    void testGetVendorsList_ReturnsExpectedResponse() {
        when(rdsService.getVendorList()).thenReturn(vendorResponseDTO);

        ResponseEntity<VendorResponseDTO> response = rdsApiController.getVendorsList();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(vendorResponseDTO, response.getBody());
        verify(rdsService, times(1)).getVendorList();
        verifyNoInteractions(countryService);
    }

    @Test
    void testGetCountries_ReturnsExpectedResponse() {
        int startIndex = 0;
        int batchSize = 10;

        when(countryService.getCountries(startIndex, batchSize)).thenReturn(countryResponseDTO);

        ResponseEntity<CountryResponseDTO> response = rdsApiController.getCountries(startIndex, batchSize);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(countryResponseDTO, response.getBody());
        verify(countryService, times(1)).getCountries(startIndex, batchSize);
        verifyNoInteractions(rdsService);
    }

    @Test
    void testGetCountryRegions_ReturnsExpectedResponse() {
        int countryId = 101;
        int startIndex = 5;
        int batchSize = 20;

        when(countryService.getCountryRegions(countryId, startIndex, batchSize))
                .thenReturn(countryRegionResponseDTO);

        ResponseEntity<CountryRegionResponseDTO> response =
                rdsApiController.getCountryRegions(countryId, startIndex, batchSize);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(countryRegionResponseDTO, response.getBody());
        verify(countryService, times(1)).getCountryRegions(countryId, startIndex, batchSize);
        verifyNoInteractions(rdsService);
    }

    @Test
    void testGetLanguages_ReturnsExpectedResponse() {
        int startIndex = 2;
        int batchSize = 15;

        when(countryService.getLanguages(startIndex, batchSize)).thenReturn(languageResponseDTO);

        ResponseEntity<LanguageResponseDTO> response =
                rdsApiController.getLanguages(startIndex, batchSize);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(languageResponseDTO, response.getBody());
        verify(countryService, times(1)).getLanguages(startIndex, batchSize);
        verifyNoInteractions(rdsService);
    }
}