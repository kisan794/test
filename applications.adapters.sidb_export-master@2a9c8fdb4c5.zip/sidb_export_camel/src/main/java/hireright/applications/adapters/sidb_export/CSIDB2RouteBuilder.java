package hireright.applications.adapters.sidb_export;
import org.apache.camel.builder.RouteBuilder;

import hireright.applications.adapters.integration.core.api.CRequest;
import hireright.applications.adapters.integration.core.builders.CIntegrationRouteBuilder;
import hireright.applications.adapters.integration.core.impl.CXmlToJsonConverter;
import hireright.applications.adapters.integration.core.impl.CXslTransformer;
import hireright.applications.adapters.sidb_export.out.CSIDB2Consumer;
import hireright.applications.adapters.sidb_export.out.CSIDB2Enricher;
import hireright.applications.adapters.sidb_export.out.CSIDB2Exchanger;

public class CSIDB2RouteBuilder extends RouteBuilder
{
	public static final String SIDB2_ROUTE_SUFFIX = "SIDB2";
	
	@Override
	public void configure()
	{

		CIntegrationRouteBuilder
			.getInstance()
			.consumer(new CSIDB2Consumer())
			.enricher(new CSIDB2Enricher())
			.preparer(new CXslTransformer("source.xslt"))
			.exchanger(new CSIDB2Exchanger(CRequest.EPropertyType.CONTEXT))
			.build(this);
	}
}
