package com.hireright.sourceintelligence.api.v2;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hireright.sourceintelligence.api.dto.SearchResponseDTO;
import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.api.dto.UserInfo;
import com.hireright.sourceintelligence.api.v2.dto.SourceDTO;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.domain.enums.UserRoles;
import com.hireright.sourceintelligence.exception.GlobalApiExceptionHandler;
import com.hireright.sourceintelligence.exception.InvalidRequestException;
import com.hireright.sourceintelligence.exception.UnauthorizedException;
import com.hireright.sourceintelligence.service.CommonUtilService;
import com.hireright.sourceintelligence.service.SearchService;
import com.hireright.sourceintelligence.service.SourceHistoryService;
import com.hireright.sourceintelligence.service.SourceService;
import com.hireright.sourceintelligence.util.DTOConversion;
import com.hireright.sourceintelligence.util.TestDataProvider;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.SOURCE_AUTO_MATCH;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SourceApiControllerTest {

    private MockMvc mockMvc;

    @InjectMocks
    private SourceApiController sourceApiController;

    @Mock
    private SourceService sourceService;

    @Mock
    private SearchService searchService;

    @Mock
    private SourceHistoryService sourceHistoryService;



    @Mock
    private CommonUtilService commonUtilService;

    @Mock
    private HttpServletRequest httpServletRequest;

    @Mock
    private UserInfo userInfo;

    @Mock
    private DTOConversion dtoConversion;

    @BeforeEach
    public void setup() {
        JacksonTester.initFields(this, new ObjectMapper());
        // MockMvc standalone approach
        mockMvc =
                MockMvcBuilders.standaloneSetup(sourceApiController)
                        .setControllerAdvice(new GlobalApiExceptionHandler())
                        .build();

        userInfo = new UserInfo();
        userInfo.setRoles(List.of(UserRoles.RESEARCH_ANALYST.getRole()));
        userInfo.setRoles(Collections.singletonList("ROLE_CREATE_SOURCE"));
    }

    @Test
    void createSourceOrganizationTest() throws Exception {
        SourceDTO inputDTO = new SourceDTO();
        SourceOrganizationDTO sourceOrganizationDTO = new SourceOrganizationDTO();
        HttpServletRequest mockRequest = mock(HttpServletRequest.class);

        when(commonUtilService.getUserInfo(any())).thenReturn(userInfo);

        when(dtoConversion.convertV2DtoToV1Dto(any())).thenReturn(sourceOrganizationDTO);

        ResponseEntity<SourceDTO> response = sourceApiController.createSourceOrganization(inputDTO,
                mockRequest);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }
    @Test
    void updateSourceOrganizationInvalidRequestTest() throws Exception {
        SourceDTO inputDTO = new SourceDTO();
        SourceOrganizationDTO sourceOrganizationDTO = new SourceOrganizationDTO();
        HttpServletRequest mockRequest = mock(HttpServletRequest.class);

        when(commonUtilService.getUserInfo(any())).thenReturn(userInfo);

        when(dtoConversion.convertV2DtoToV1Dto(any())).thenReturn(sourceOrganizationDTO);

        assertThatExceptionOfType(InvalidRequestException.class)
                .isThrownBy(() ->sourceApiController.updateSourceOrganization("",inputDTO,
                mockRequest));

    }

    @Test
    void updateSourceOrganizationTest() throws Exception {
        SourceDTO inputDTO = new SourceDTO();
        SourceOrganizationDTO sourceOrganizationDTO = new SourceOrganizationDTO();
        sourceOrganizationDTO.setHon("OUEDU-082924-PICHKNV");
        HttpServletRequest mockRequest = mock(HttpServletRequest.class);

        when(commonUtilService.getUserInfo(any())).thenReturn(userInfo);

        when(dtoConversion.convertV2DtoToV1Dto(any())).thenReturn(sourceOrganizationDTO);

        assertThatNoException()
                .isThrownBy(() ->sourceApiController.updateSourceOrganization("OUEDU-082924-PICHKNV",inputDTO,
                        mockRequest));

    }

    @Test
    void updateSourceOrganizationRolesTest() throws Exception {
        SourceDTO inputDTO = new SourceDTO();
        SourceOrganizationDTO sourceOrganizationDTO = new SourceOrganizationDTO();
        sourceOrganizationDTO.setHon("OUEDU-082924-PICHKNV");
        HttpServletRequest mockRequest = mock(HttpServletRequest.class);
        userInfo.setRoles(List.of(UserRoles.RESEARCH_ANALYST.getRole()));
        when(commonUtilService.getUserInfo(any())).thenReturn(userInfo);

        assertThatExceptionOfType(UnauthorizedException.class)
                .isThrownBy(() ->sourceApiController.updateSourceOrganization("OUEDU-082924-PICHKNV",inputDTO,
                        mockRequest));

    }

    @Test
    void createSourceOrganizationRolesTest() throws Exception {
        SourceDTO inputDTO = new SourceDTO();
        SourceOrganizationDTO sourceOrganizationDTO = new SourceOrganizationDTO();
        sourceOrganizationDTO.setHon("OUEDU-082924-PICHKNV");
        HttpServletRequest mockRequest = mock(HttpServletRequest.class);
        userInfo.setRoles(List.of(UserRoles.RESEARCH_ANALYST.getRole()));
        when(commonUtilService.getUserInfo(any())).thenReturn(userInfo);

        assertThatExceptionOfType(UnauthorizedException.class)
                .isThrownBy(() ->sourceApiController.createSourceOrganization(inputDTO,
                        mockRequest));

    }

    @Test
    void updateSourceOrganizationStatusTest() throws Exception {
        SourceDTO inputDTO = new SourceDTO();
        inputDTO.setHon("OUEDU-082924-PICHKNV");
        inputDTO.setStatus(SourceOrganizationStatus.INACTIVE);
        HttpServletRequest mockRequest = mock(HttpServletRequest.class);

        when(commonUtilService.getUserInfo(any())).thenReturn(userInfo);

        assertThatNoException()
                .isThrownBy(() ->sourceApiController.updateSourceOrganizationStatus("OUEDU-082924-PICHKNV",inputDTO,
                        mockRequest));

    }

    @Test
    void updateSourceOrganizationStatusRolesTest() throws Exception {
        SourceDTO inputDTO = new SourceDTO();

        //SourceOrganizationDTO sourceOrganizationDTO = new SourceOrganizationDTO();
        inputDTO.setHon("OUEDU-082924-PICHKNV");
        inputDTO.setStatus(SourceOrganizationStatus.INACTIVE);
        HttpServletRequest mockRequest = mock(HttpServletRequest.class);
        userInfo.setRoles(List.of(UserRoles.RESEARCH_ANALYST.getRole()));
        when(commonUtilService.getUserInfo(any())).thenReturn(userInfo);

        assertThatExceptionOfType(UnauthorizedException.class)
                .isThrownBy(() ->sourceApiController.updateSourceOrganizationStatus("OUEDU-082924-PICHKNV",inputDTO,
                        mockRequest));

    }

//    @Test
//    void getSourceOrganizationTest() throws Exception {
//
//        SourceOrganizationDTO sourceOrganizationDTO = new SourceOrganizationDTO();
//        sourceOrganizationDTO.setHon("OUEDU-082924-PICHKNV");
//        when(sourceService.getSourceByHonAndVersion(anyString(), anyDouble())).thenReturn(sourceOrganizationDTO);
//        when(dtoConversion.convertV1DtoToV2Dto(any(SourceOrganizationDTO.class))).thenReturn(new SourceDTO());
//        assertThatNoException()
//                .isThrownBy(() ->sourceApiController.getSourceOrganization(TestDataProvider.getSourceId()));
//
//    }

//    @Test
//    void searchSourceSuggestionsInvalidRequestTest() throws Exception {
//
//        assertThatExceptionOfType(InvalidRequestException.class).isThrownBy(() ->sourceApiController.getSourcesList("","",0.0,OrganizationType.EDUCATION,"","","Country","", SourceOrganizationStatus.ACTIVE,20.0));
//    }
//
//    @Test
//    void searchSourceSuggestionsInvalidRequestOneTest() throws Exception {
//
//        assertThatExceptionOfType(InvalidRequestException.class).isThrownBy(() ->sourceApiController.getSourcesList("","",0.0,OrganizationType.EDUCATION,"","City","","State",SourceOrganizationStatus.ACTIVE,80.0));
//    }

//    @Test
//    void getSourcesListTest() throws Exception {
//        String hon = TestDataProvider.getHon();
//        when(dtoConversion.convertV1DtoToV2Dto(any())).thenReturn(new SourceDTO());
//        assertThatNoException().isThrownBy(() ->sourceApiController.getSourcesList("hon",hon,0.0,OrganizationType.EDUCATION,"","City","","State",SourceOrganizationStatus.ACTIVE,80.0));
//    }
//    @Test
//    void getSourcesListWithHonAndVersionTest() throws Exception {
//        String hon = TestDataProvider.getHon();
//        when(sourceService.getSourceByHonAndVersion(anyString(), anyDouble())).thenReturn(new SourceOrganizationDTO());
//        when(dtoConversion.convertV1DtoToV2Dto(any())).thenReturn(new SourceDTO());
//        assertThatNoException().isThrownBy(() ->sourceApiController.getSourcesList("honAndVersion",hon,0.0,OrganizationType.EDUCATION,"","City","","State",SourceOrganizationStatus.ACTIVE,80.0));
//    }

//    @Test
//    void getSourcesListWithAutoMatchTest() throws Exception {
//        String hon = TestDataProvider.getHon();
//        ApprovalStatus approvalStatus = ApprovalStatus.APPROVED;
//        SourceOrganizationDTO sourceOrganizationDTO = new SourceOrganizationDTO();
//        sourceOrganizationDTO.setHon(hon);
//        sourceOrganizationDTO.setApprovalStatus(approvalStatus);
//        SourceOrganizationDTO sourceOrganizationDTO1 = TestDataProvider.getSourceOrganizationDTO();
//        List<SourceOrganizationDTO> mockDtoList = Arrays.asList(sourceOrganizationDTO, sourceOrganizationDTO1);
//        SearchResponseDTO searchResponseDTO = new SearchResponseDTO();
//        searchResponseDTO.setSourceList(mockDtoList);
//        when(sourceService.getSearchSource(any(OrganizationType.class), anyMap(), any(SourceOrganizationStatus.class), anyDouble(), anyString())).thenReturn(searchResponseDTO);
//        assertThatNoException().isThrownBy(() ->sourceApiController.getSourcesList("autoMatch",hon,0.0,OrganizationType.EDUCATION,"","","","",SourceOrganizationStatus.ACTIVE,80.0));
//    }

//    @Test
//    void getSourcesListWithAutoMatch_InvalidRequest_Test() throws Exception {
//        String hon = TestDataProvider.getHon();
//        assertThatExceptionOfType(InvalidRequestException.class).isThrownBy(() ->sourceApiController.getSourcesList("autoMatch",hon,0.0,OrganizationType.EDUCATION,"","city","","",SourceOrganizationStatus.ACTIVE,80.0));
//    }

//    @Test
//    void getSourcesListWithSuggestionsTest() throws Exception {
//        String hon = TestDataProvider.getHon();
//        ApprovalStatus approvalStatus = ApprovalStatus.APPROVED;
//        SourceOrganizationDTO sourceOrganizationDTO = new SourceOrganizationDTO();
//        sourceOrganizationDTO.setHon(hon);
//        sourceOrganizationDTO.setApprovalStatus(approvalStatus);
//        SourceOrganizationDTO sourceOrganizationDTO1 = TestDataProvider.getSourceOrganizationDTO();
//        List<SourceOrganizationDTO> mockDtoList = Arrays.asList(sourceOrganizationDTO, sourceOrganizationDTO1);
//        SearchResponseDTO searchResponseDTO = new SearchResponseDTO();
//        searchResponseDTO.setSourceList(mockDtoList);
//        when(sourceService.getSearchSource(any(OrganizationType.class), anyMap(), any(SourceOrganizationStatus.class), anyDouble(), anyString())).thenReturn(searchResponseDTO);
//        assertThatNoException().isThrownBy(() ->sourceApiController.getSourcesList("suggestions",hon,0.0,OrganizationType.EDUCATION,"","","","",SourceOrganizationStatus.ACTIVE,80.0));
//    }

//    @Test
//    void getSourcesListWithSuggestions_InvalidRequest_Test() throws Exception {
//        String hon = TestDataProvider.getHon();
//        assertThatExceptionOfType(InvalidRequestException.class).isThrownBy(() ->sourceApiController.getSourcesList("suggestions",hon,0.0,OrganizationType.EDUCATION,"","city","","",SourceOrganizationStatus.ACTIVE,80.0));
//    }
//
//    @Test
//    void getSourcesListWithInvalidSearchTypeTest() throws Exception {
//        String hon = TestDataProvider.getHon();
//        assertThatExceptionOfType(InvalidRequestException.class).isThrownBy(() ->sourceApiController.getSourcesList("test",hon,0.0,OrganizationType.EDUCATION,"","city","","",SourceOrganizationStatus.ACTIVE,80.0));
//    }
}