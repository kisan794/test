package com.hireright.sourceintelligence.service.impl.helperservices;

import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.service.impl.MongoSearchService;
import com.hireright.sourceintelligence.service.impl.MongoSourceService;
import com.hireright.sourceintelligence.util.Helper;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.ReportActions.AUTO_REJECTED;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.ReportActions.ON_HOLD_AUTO_REJECTED;

@Slf4j
@Data
@AllArgsConstructor
@Component
public class ApprovalProcessScheduler {

    private MongoSearchService mongoSearchService;
    private MongoSourceService mongoSourceService;
    private ReportDataUtils reportDataUtils;

    //Every 1 minute
    @Scheduled(cron = "0 */5 * * * *")
    public void runInProgressSources() {
        String[] orgTypes = getOrgTypes();
        for (String orgType : orgTypes) {
            List<Source> result = mongoSearchService.findAllSourcesWithInProgress(orgType);
            if(!result.isEmpty()){
                log.info("InProgress records found: size: {}", result.size());
                for (Source source : result) {
                    updateCommonFields(source);
                    List<String> aStatus = new ArrayList<>();
                    aStatus.add(ApprovalStatus.PENDING_APPROVAL.toString());
                    aStatus.add(ApprovalStatus.SAVE_PENDING_APPROVAL.toString());
                    Source pendingSource = mongoSourceService.findSourceByHonAndApprovalStatuses(source.getHon(), aStatus);
                    if(pendingSource != null){
                        log.info("Pending source found for hon : {} with db id: {}", pendingSource.getHon(), pendingSource.getId());
                        updateRejectFields(source);
                    }
                    mongoSourceService.updateById(source, orgType);
                    reportDataUtils.reportData(source, source.getAction(), SIDB_APPROVAL_FLOW,0, AUTO_REJECTED,source.getVersion(), source.getTempVersion());
                    String collectionName = Helper.getCollectionName(source.getHon(),SOURCE_HISTORY_COLLECTION_SUFFIX);
                    mongoSourceService.insert(source, collectionName);
                }
            }
        }
    }

    //Every day @ 8am
    @Scheduled(cron = "0 0 8 * * *")
    public void runOnHoldTask() {
        log.info("Running daily cleanup at 8am");
        String[] orgTypes = getOrgTypes();
        for (String orgType : orgTypes) {
            List<Source> result = mongoSearchService.findAllSourcesWithOnHold(orgType);
            if(!result.isEmpty()){
                for (Source source : result) {
                    updateCommonFields(source);
                    List<String> aStatus = new ArrayList<>();
                    aStatus.add(ApprovalStatus.PENDING_APPROVAL.toString());
                    aStatus.add(ApprovalStatus.SAVE_PENDING_APPROVAL.toString());
                    Source pendingSource = mongoSourceService.findSourceByHonAndApprovalStatuses(source.getHon(), aStatus);
                    if(pendingSource != null){
                        updateRejectFields(source);
                    }
                    mongoSourceService.updateById(source, orgType);
                    reportDataUtils.reportData(source, source.getAction(), SIDB_APPROVAL_FLOW,0, ON_HOLD_AUTO_REJECTED,source.getVersion(), source.getTempVersion());
                    String collectionName = Helper.getCollectionName(source.getHon(),SOURCE_HISTORY_COLLECTION_SUFFIX);
                    mongoSourceService.insert(source, collectionName);
                }
            }
        }
    }
    private void updateCommonFields(Source source){
        source.setApprovalStatus(ApprovalStatus.PENDING_APPROVAL);
        source.setAssignedId(UNASSIGNED);
        source.setAssignedTo(UNASSIGNED);
    }

    private void updateRejectFields(Source source){
        source.setSystemComments("Rejected by Scheduler");
        source.setApprovalStatus(ApprovalStatus.REJECTED);
        source.setStatus(SourceOrganizationStatus.INACTIVE);
    }

    private String[] getOrgTypes(){
        return new String[]{EDUCATION_COLLECTION_PREFIX+SOURCE_COLLECTION_SUFFIX,EMPLOYMENT_COLLECTION_PREFIX+SOURCE_COLLECTION_SUFFIX};
    }
}
