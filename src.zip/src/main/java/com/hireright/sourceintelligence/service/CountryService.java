package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.rds.CountryRegionResponseDTO;
import com.hireright.sourceintelligence.api.dto.rds.CountryResponseDTO;
import com.hireright.sourceintelligence.api.dto.rds.LanguageResponseDTO;

public interface CountryService {

    CountryResponseDTO getCountries(int startIndex, int batchSize);

    CountryRegionResponseDTO getCountryRegions(int countryId, int startIndex, int batchSize);

    LanguageResponseDTO getLanguages(int startIndex, int batchSize);
}