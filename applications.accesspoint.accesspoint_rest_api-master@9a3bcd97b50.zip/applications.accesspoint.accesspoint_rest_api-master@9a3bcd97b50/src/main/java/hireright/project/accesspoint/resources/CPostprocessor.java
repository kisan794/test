package hireright.project.accesspoint.resources;
/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	2017-10-11	Created
 *	valery.yudichev	2018-07-16 Add application_id for order form entry points
 *	valery.yudichev 2018-07-16 Replace %DOMAIN_ID% with value in redirectURL
 */

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import hireright.applications.accesspoint.types.CParameterBean;
import hireright.objects.application.CApplication;
import hireright.objects.application.CApplicationDomain;
import hireright.objects.application.CApplicationManager;
import hireright.objects.application.CApplicationOrder;
import hireright.objects.application.CApplicationOrderFactory;
import hireright.objects.order2.COrder;
import hireright.objects.order2.COrderServiceManager;
import hireright.objects.order2.loaders.COrderLoader;
import hireright.objects.users.COperator;
import hireright.objects.utilities.CDomain;
import hireright.objects.utilities.CEntryPoint;
import hireright.project.accesspoint.model.EntryPoint;
import hireright.project.accesspoint.model.Return;
import hireright.sdk.db2.CSessionFactory;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.CStringUtils;

public class CPostprocessor 
{
	private static final String URL_PLACEHOLDER_KEY = "%KEY%";
	private static final String URL_PLACEHOLDER_DOMAIN_ID = "%DOMAIN_ID%";
	private static final String ENTRANCE_URL_ACTION = "entranceURLAction";
	private static final String PARAM_ORDER_REG_ID = "orderRegID";
	private static final String PARAM_ORDER_SERVICE_CODE = "orderServiceCode";
	private static final String PARAM_ORDER_SERVICE_ID = "orderServiceID";
	private static final String PARAM_OPERATOR_ID = "operatorID";
	private static final String PARAM_APPLICATION_ID = "application_id";
	private static final String DEFAULT_APPLICATION_DOMAIN = "HR-APP";
	private static final String OPTOOL_DOMAIN = "OPTOOL";
	
	//CommTool 1
	private static String IS_DOMAIN_ACTION_OPEN_COMM_TOOL = "OPEN COMM TOOL";
	//CommTool 2
	private static String IS_DOMAIN_ACTION_OPEN_COMM_TOOL_OPERATOR_FORM = "OPEN COMM TOOL OPERATOR FORM";
	//Application Review 
	private static String IS_DOMAIN_ACTION_OPTOOL_TO_ORDER_FORM = "OPTOOL REVIEW ORDER FORM";
	
	
	public static void processEntryPoint(EntryPoint entryPoint)
	{
		String sEntryPointType = entryPoint.getEntryPointType();
		
		if (IS_DOMAIN_ACTION_OPEN_COMM_TOOL.equals(sEntryPointType)
			|| IS_DOMAIN_ACTION_OPEN_COMM_TOOL_OPERATOR_FORM.equals(sEntryPointType))
		{
			processCommToolEntryPoint(entryPoint);
		}
		
		if(IS_DOMAIN_ACTION_OPTOOL_TO_ORDER_FORM.equals(sEntryPointType))
		{
			processApplicationReviewEntryPointForOperator(entryPoint);
		}
	}
	
	public static void updateEntryPoint(CEntryPoint entryPoint, EntryPoint entryPointBean)
	{
		
		if(IS_DOMAIN_ACTION_OPTOOL_TO_ORDER_FORM.equals(entryPointBean.getEntryPointType()))
		{
			String sRedirectURL = entryPoint.getRedirectURL();
			String sDomainID = DEFAULT_APPLICATION_DOMAIN;
			
			String sApplicationID = entryPointBean.getParameter(PARAM_APPLICATION_ID).getValue();
			if(CStringUtils.isNotEmpty(sApplicationID))
			{
				CApplicationDomain domain = CApplicationManager.loadApplicationDomain(Integer.valueOf(sApplicationID));
				if(domain != null && CStringUtils.isNotEmpty(domain.getDomainID()))
					sDomainID = domain.getDomainID();
			}			

			if(!(CStringUtils.isEmpty(sRedirectURL) || CStringUtils.isEmpty(sDomainID)))
			{
				entryPoint.setRedirectURL(sRedirectURL.replaceAll(URL_PLACEHOLDER_DOMAIN_ID, sDomainID));
			}
		}
	}
	
	private static void processCommToolEntryPoint(EntryPoint entryPoint)
	{
		COperator operator = getOperatorByLogin(entryPoint.getLogin());
		
		entryPoint.setUserClass(COperator.OBJECT_CLASS);
		entryPoint.setUserId(operator.getObjectID());
		
		CParameterBean regIDParamBean = entryPoint.getParameter(PARAM_ORDER_REG_ID);
		
		if (regIDParamBean == null || CStringUtils.isEmpty(regIDParamBean.getValue()))
		{
			return;
		}
		
		COrder order = COrderLoader.find(regIDParamBean.getValue());
		
		if (order == null)
		{
			return;
		}
		
		CParameterBean osCodeParamBean = entryPoint.getParameter(PARAM_ORDER_SERVICE_CODE);
	
		if (osCodeParamBean == null || CStringUtils.isEmpty(osCodeParamBean.getValue()))
		{
			return;
		}
		
		Long nOrderServiceID = COrderServiceManager.getOrderServiceID(order.getID(), osCodeParamBean.getValue());

		CParameterBean operatorParamBean = new CParameterBean();
		operatorParamBean.setName(PARAM_OPERATOR_ID);
		operatorParamBean.setValue(String.valueOf(operator.getID()));
		
		CParameterBean orderServiceIDParamBean = new CParameterBean();
		orderServiceIDParamBean.setName(PARAM_ORDER_SERVICE_ID);
		orderServiceIDParamBean.setValue(String.valueOf(nOrderServiceID));
		
		entryPoint.addParameter(operatorParamBean);
		entryPoint.addParameter(orderServiceIDParamBean);
	}
	
	private static COperator getOperatorByLogin(String sOperatorLogin)
	{		
		if (CStringUtils.isEmpty(sOperatorLogin))
		{
			return null;
		}
		
		COperator operator = COperator.get(sOperatorLogin);
		
		if (operator == null)
		{
			operator = COperator.get(1);

			if (operator == null)
			{
				throw new CRuntimeException("System operator not found");
			}
		}
		
		return operator;
	}
	
	
	private static void processApplicationReviewEntryPointForOperator(EntryPoint entryPoint)
	{

		COperator operator = getOperatorByLogin(entryPoint.getLogin());
		
		entryPoint.setUserClass(COperator.OBJECT_CLASS);
		entryPoint.setUserId(operator.getObjectID());
		
		CParameterBean regIDParamBean = entryPoint.getParameter(PARAM_ORDER_REG_ID);
		
		if (regIDParamBean == null || CStringUtils.isEmpty(regIDParamBean.getValue()))
		{
			return;
		}
		
		COrder order = COrderLoader.find(regIDParamBean.getValue());
		
		if (order == null)
		{
			return;
		}
		
		Integer nApplicationID = getApplicationID(order);
		
		if(nApplicationID == null)
		{
			return;
		}
		
		CParameterBean applicationIDParamBean = new CParameterBean();
		applicationIDParamBean.setName(PARAM_APPLICATION_ID);
		applicationIDParamBean.setValue(String.valueOf(nApplicationID));
		entryPoint.addParameter(applicationIDParamBean);	
		
		entryPoint.setDomainId(OPTOOL_DOMAIN);		
	}

	private static Integer getApplicationID(COrder order) 
	{
		CApplicationOrder applicationOrder = CApplicationOrderFactory.load(null, order.getID(), CApplication.OBJECT_CLASS);
		
		if (applicationOrder == null)
		{
			applicationOrder = CApplicationOrderFactory.load(null, order.getID(), COrder.OBJECT_CLASS);
		}
		
		return applicationOrder == null ? null : applicationOrder.getApplicationID();
	}
	
	public static void processReturn(Return result, EntryPoint entryPoint)
	{
		CParameterBean entranceURLParamBean = entryPoint.getParameter(ENTRANCE_URL_ACTION);
		
		if (CStringUtils.isEmpty(result.getKey()) || entranceURLParamBean == null || CStringUtils.isEmpty(entranceURLParamBean.getValue()))
		{
			return;
		}
		
		String sDomainID = entryPoint.getDomainId();
		
		if (CStringUtils.isEmpty(sDomainID))
		{
			return;
		}
		
		CDomain domain = CDomain.loadDomain(sDomainID);
		
		String sURL = domain.getDomainEntryPoint(entranceURLParamBean.getValue(), null).replaceAll(URL_PLACEHOLDER_KEY, result.getKey());
		result.setUrl(sURL);
	}
}
