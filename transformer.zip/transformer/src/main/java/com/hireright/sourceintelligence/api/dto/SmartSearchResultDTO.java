package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SmartSearchResultDTO {
    private String hon;
    private String organizationName;
    private String city;
    private String country;
    private String state;
    private String postalCode;
    private int usedCount;
    private String departmentName;
    private Instant lastModifiedDate;
    private Instant lastApprovedDate;
    private String lastUsedDateTime;
    private Double jaroWinklerDistance;
}
