package hireright.applications.fulfillment_task_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-13  HRG-332327 initial version
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.io.Serializable;
import java.util.Objects;

@XmlAccessorType (XmlAccessType.NONE)
@XmlRootElement (name = "meta")
public class CResourcesMeta implements Serializable {
    @JsonProperty ("count")
    private Integer m_nCount;

    @JsonProperty ("offset")
    private Long m_lOffset;

    @JsonProperty ("limit")
    private Integer m_nLimit;

    @JsonProperty ("total")
    private Long m_lTotal;

    private CResourcesMeta() {
    }

    private CResourcesMeta(Builder builder) {
        this.m_nCount = builder.m_nCount;
        this.m_lOffset = builder.m_lOffset;
        this.m_nLimit = builder.m_nLimit;
        this.m_lTotal = builder.m_lTotal;
    }

    public Integer getCount() {
        return this.m_nCount;
    }

    public Long getOffset() {
        return this.m_lOffset;
    }

    public Integer getLimit() {
        return this.m_nLimit;
    }

    public Long getTotal() {
        return this.m_lTotal;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CResourcesMeta that = (CResourcesMeta) o;

        if (!Objects.equals(this.m_nCount, that.m_nCount)) {
            return false;
        }
        if (!Objects.equals(this.m_lOffset, that.m_lOffset)) {
            return false;
        }
        if (!Objects.equals(this.m_nLimit, that.m_nLimit)) {
            return false;
        }
        return Objects.equals(this.m_lTotal, that.m_lTotal);
    }

    @Override
    public String toString() {
        return "CResourcesMeta{" + "m_nCount=" + this.m_nCount + ", m_lOffset=" + this.m_lOffset + ", m_nLimit=" + this.m_nLimit +
                ", m_lTotal=" + this.m_lTotal + '}';
    }

    @Override
    public int hashCode() {
        int result = this.m_nCount != null ? this.m_nCount.hashCode() : 0;
        result = 31 * result + (this.m_lOffset != null ? this.m_lOffset.hashCode() : 0);
        result = 31 * result + (this.m_nLimit != null ? this.m_nLimit.hashCode() : 0);
        result = 31 * result + (this.m_lTotal != null ? this.m_lTotal.hashCode() : 0);
        return result;
    }

    public static final class Builder {
        private Integer m_nCount;
        private Long m_lOffset;
        private Integer m_nLimit;
        private Long m_lTotal;

        public Builder() {
        }

        public Builder(CResourcesMeta copy) {
            if (copy == null) {
                return;
            }
            this.m_nCount = copy.getCount();
            this.m_lOffset = copy.getOffset();
            this.m_nLimit = copy.getLimit();
            this.m_lTotal = copy.getTotal();
        }

        public Builder count(Integer nCount) {
            this.m_nCount = nCount;
            return this;
        }

        public Builder offset(Long lOffset) {
            this.m_lOffset = lOffset;
            return this;
        }

        public Builder limit(Integer nLimit) {
            this.m_nLimit = nLimit;
            return this;
        }

        public Builder total(Long lTotal) {
            this.m_lTotal = lTotal;
            return this;
        }

        public CResourcesMeta build() {
            if (this.m_nCount == null) {
                this.m_nCount = 0;
            }
            if (this.m_lOffset == null) {
                this.m_lOffset = 0L;
            }
            if (this.m_lTotal == null) {
                this.m_lTotal = (long) this.m_nCount;
            }
            return new CResourcesMeta(this);
        }
    }
}
