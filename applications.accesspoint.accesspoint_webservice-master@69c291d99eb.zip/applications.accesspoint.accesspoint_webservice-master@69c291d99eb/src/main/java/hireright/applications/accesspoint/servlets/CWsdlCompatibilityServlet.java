/*
 * @(#)$RCSfile: CWsdlCompatibilityServlet.java,v $ $Revision: 1.3 $ $Date: 2015/01/23 13:52:42 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/servlets/CWsdlCompatibilityServlet.java,v $
 *
 * Copyright 2001-2014 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Putintsev		2014-12-16	Created
 *	A.Putintsev		2015-01-16	response.sendRedirect() changed to requestDispatcher.forward()
 */
package hireright.applications.accesspoint.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * This servlet is responsible for resolving requests adressing wsdl with "?wsdl"
 * notation. If there is "?wsdl" in url, than request is redirected to ".wsdl"-style URL.
 */
public class CWsdlCompatibilityServlet extends HttpServlet {
	
	protected static final String CLASS_VERSION = "$Revision: 1.3 $ $Author: cvsroot $";
	
	@Override 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException 
	{		        
        String queryString = request.getQueryString();        
        
		if ("GET".equals(request.getMethod()) && "wsdl".equalsIgnoreCase(queryString)) {
        	String location = response.encodeRedirectURL(request.getRequestURI() + ".wsdl");
        	request.getSession().getServletContext().getRequestDispatcher(location).forward(request, response);
        }
		else
		{
			getSoapRequestDispatcher(request).forward(request, response);
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		getSoapRequestDispatcher(request).forward(request, response);
	}
	
	private RequestDispatcher getSoapRequestDispatcher(HttpServletRequest request)
	{
		return request.getSession().getServletContext().getRequestDispatcher("/*.wsdl");
	}
}
