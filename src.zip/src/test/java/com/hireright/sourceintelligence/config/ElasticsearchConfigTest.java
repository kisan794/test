package com.hireright.sourceintelligence.config;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.sniff.Sniffer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;


import static com.hireright.sourceintelligence.constants.ApplicationConstants.PRODUCTION;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.STAGE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ElasticsearchConfigTest {

    private ElasticsearchConfig elasticsearchConfig;

    @BeforeEach
    void setUp() {
        elasticsearchConfig = new ElasticsearchConfig();
    }
    private void setPrivateField(Object target, String fieldName, Object value) {
        try {
            Field field = target.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(target, value);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void testElasticsearchClient_WithStageEnv() {
        setPrivateField(elasticsearchConfig, "elasticsearchUri", "http://localhost:9200,http://localhost:9201");
        setPrivateField(elasticsearchConfig, "esUserName", "user");
        setPrivateField(elasticsearchConfig, "esPassword", "pass");
        setPrivateField(elasticsearchConfig, "elasticsearchEnvType", STAGE);

        ElasticsearchClient client = elasticsearchConfig.elasticsearchClient();
        assertNotNull(client);
    }

    @Test
    void testElasticsearchClient_WithProductionEnv() {
        setPrivateField(elasticsearchConfig, "elasticsearchUri", "http://prodhost:9200");
        setPrivateField(elasticsearchConfig, "esUserName", "produser");
        setPrivateField(elasticsearchConfig, "esPassword", "prodpass");
        setPrivateField(elasticsearchConfig, "elasticsearchEnvType", PRODUCTION);

        ElasticsearchClient client = elasticsearchConfig.elasticsearchClient();
        assertNotNull(client);
    }

    @Test
    void testElasticsearchClient_WithNonProductionEnv() {
        setPrivateField(elasticsearchConfig, "elasticsearchUri", "http://devhost:9200");
        setPrivateField(elasticsearchConfig, "esUserName", "devuser");
        setPrivateField(elasticsearchConfig, "esPassword", "devpass");
        setPrivateField(elasticsearchConfig, "elasticsearchEnvType", "DEV");

        ElasticsearchClient client = elasticsearchConfig.elasticsearchClient();
        assertNotNull(client);
    }

    @Test
    void testSnifferBeanCreation() {
        RestClient mockRestClient = mock(RestClient.class);

        Sniffer sniffer = elasticsearchConfig.sniffer(mockRestClient);
        assertNotNull(sniffer);
    }

    @Test
    void testCredentialsProviderConfiguration() throws Exception {
        setPrivateField(elasticsearchConfig, "esUserName", "testUser");
        setPrivateField(elasticsearchConfig, "esPassword", "testPass");

        BasicCredentialsProvider credentialsProvider = new BasicCredentialsProvider();
        credentialsProvider.setCredentials(
                org.apache.http.auth.AuthScope.ANY,
                new UsernamePasswordCredentials("testUser", "testPass")
        );

        assertNotNull(credentialsProvider.getCredentials(org.apache.http.auth.AuthScope.ANY));
    }
}