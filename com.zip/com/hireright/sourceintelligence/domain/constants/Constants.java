package com.hireright.sourceintelligence.domain.constants;

public class Constants {

    private Constants() {

    }
    public static final String SOURCE_ORGANIZATION_COLLECTION = "source_intelligence";

    public static final String FIELD_ID = "id";
    public static final String FIELD_HON = "hon";
    public static final String FIELD_LOCATION = "location";
    public static final String FIELD_VERSION = "version";
    public static final String FIELD_STATUS = "status";
    public static final String FIELD_NAME = "organizationName";
    public static final String FIELD_APPROVAL_STATUS = "approvalStatus";
    public static final String FIELD_REQUESTED_BY = "requestedBy";
    public static final String FIELD_LAST_MODIFIED_DATE = "lastModifiedDate";
    public static final String FIELD_LAST_ACTION_DATE = "last_action_date";

    public static final String FIELD_TYPE = "organizationType";
    public static final String FIELD_ALIAS = "organizationAlias";
    public static final String FIELD_USED_COUNT = "payload.usedCount";
    public static final String FIELD_ADDESS_LINE = "payload.address.line";
    public static final String FIELD_DEPT_NAME = "payload.departmentName";
    public static final String FIELD_DEPT_ALIAS = "payload.departmentAliases";
    public static final String FIELD_CITY = "city";
    public static final String FIELD_STATE = "state";
    public static final String FIELD_COUNTRY = "country";
    public static final String FIELD_OUT_OF_BUSINESS = "outOfBusiness";
    public static final String FIELD_REVIEW_REQUIRED = "reviewRequired";
    public static final String FIELD_LAST_CLEAN_UP_DATE = "payload.lastCleanUpDate";

    public static final String COLLATION_LANG = "en_US";

    public static class SmartSearchKeys {

        public static final String HON = "hon";
        public static final String DOT_REGULATED = "dotRegulated";
        public static final String RECEIPT = "receipt";
        public static final String DEPARTMENT = "department";
        public static final String DEPARTMENT_NAME = "departmentName";
        public static final String DEPARTMENT_ALIASES = "departmentAliases";
        public static final String CONTACTS = "contacts";
        public static final String TURN_AROUND_TIME = "turnAroundTime";
        public static final String SUR_CHARGE_AMOUNT = "surChargeAmount";
        public static final String SUR_CHARGE_CURRENCY = "surChargeCurrency";
        public static final String SUR_CHARGE_PAYMENT = "paymentMethod";
        public static final String COMMUNICATION = "communication";
        public static final String COMMUNICATION_INFO = "communicationInfo";
        public static final String TURN_AROUND_TIME_UNIT = "turnAroundTimeUnit";
        public static final String FOLLOW_UP_ALLOWED = "followUpAllowed";
        public static final String FOLLOW_UP_ALLOWED_AFTER = "followUpAllowedAfter";
        public static final String FOLLOW_UP_ALLOWED_AFTER_UNITS = "followUpAllowedAfterTimeUnit";

        public static final String TYPE = "type";
        public static final String VALUE = "value";
        public static final String CONTACT_PHONES = "contactPhones";
        public static final String CONTACT_FAXES = "contactFaxes";
        public static final String CONTACT_EMAILS = "contactEmails";
        public static final String CONTACT_AUTOMATED_SERVICES = "contactAutomatedServices";
        public static final String CONTACT_MAILS = "contactMails";
        public static final String CONTACT_WEBSITES = "contactWebsites";
        public static final String TYPE_PHONES="Phones";
        public static final String TYPE_FAXES="Faxes";
        public static final String TYPE_EMAILS="Emails";
        public static final String TYPE_AUTOMATED_SERVICES="AutomatedServices";
        public static final String TYPE_MAILS="Mails";
        public static final String TYPE_WEBSITES="Websites";
        public static final String COUNTRY_CODE = "countryCode";
        public static final String PHONE_COUNTRY_CODE = "phoneCountryCode";
        public static final String AREA_CODE = "areaCode";
        public static final String PHONE_NUMBER = "phoneNumber";
        public static final String EXTENSION = "extension";
        public static final String ADDRESS = "address";
        public static final String POSTAL_CODE = "postalCode";
        public static final String COUNTRY_NAME = "countryName";
        public static final String REGION = "region";
        public static final String CITY = "city";
        public static final String URI = "uri";
        public static final String CODES = "codes";
        public static final String BRANCH = "branch";

        public static final String ADDRESSES = "addresses";
        public static final String CONTACT_DETAILS = "contactDetails";
        public static final String RELATIONSHIPS = "relationships";
        public static final String RELATIONSHIP = "relationship";
        public static final String NAME = "name";
        public static final String PROVIDER_ID = "providerID";
        public static final String PARENT_HON = "HON";
        public static final String LINE = "line";
        public static final String USED_COUNT = "usedCount";
        public static final String WEBSITE = "website";
        public static final String NOTES = "notes";
        public static final String ADDITIONAL_INFO = "addionalInfo";
        public static final String DO_NOT_CONTACT = "doNotContact";
        public static final String PRIORITY = "priority";

        public static final String LAST_APPROVED_DATETIME = "lastApprovedDateTime";
        public static final String LAST_USED_DATETIME = "lastUsedDateTime";
        public static final String LAST_CLEANUP_DATE = "lastCleanUpDate";

        public static final String ADDRESS_LINE = "address.line";

        public static final String CONTACT_PERSON_NAME = "contactPersonName";
        public static final String CONTACT_PERSON_TITLE = "contactPersonTitle";
        public static final String CONTACT_TIME_FROM = "contactTimeFrom";
        public static final String CONTACT_TIME_TO = "contactTimeTo";
        public static final String CONTACT_TIME_ZONE = "contactTimeZone";
        public static final String RELEASE_TYPE = "releaseType";
        public static final String SOURCE_LANGUAGE = "sourceLanguage";


        public static final int DEFAULT_PROVIDER = 999;
    }
    public static class RelationShipConstants {
        public static final String PARENT = "PARENT";
        public static final String CHILD = "CHILD";
        public static final String FRANCHISE = "FRANCHISE";

        public static final String EDU_PARENT = "Parent / Main Campus";
        public static final String CORPORATE_PARENT = "Corporate Parent";
        public static final String CHILD_OPTION_ONE = "child / affiliated / branch school";


    }

    public static class AutoMatchConstants {
        public static final String EQUI_FAX_HS_DATE_RANGE = "EquifaxHighSchoolDateRange";
        public static final String TURN_AROUNT_TIME_UNIT = "turnAroundTimeUnit";
        public static final String TURN_AROUNT_TIME = "turnAroundTime";
        public static final String FOLLOW_UP_ALLOWED_AFTER_TIME_UNIT = "followUpAllowedAfterTimeUnit";
        public static final String AM_FOLLOW_UP_ALLOWED_AFTER = "followUpAllowedAfter";
        public static final String AM_FOLLOW_UP_ALLOWED = "followUpAllowed";
        public static final String PAYMENT_METHOD = "paymentMethod";
        public static final String SURCHARGE_CURRENCY = "surchargeCurrency";
        public static final String SURCHARGE_AMOUNT = "surchargeAmount";
        public static final String FROM_YEAR = "fromYear";
        public static final String TO_YEAR = "toYear";

        public static final String EQUIFAX_SCHOOL_CODES = "EquifaxSchoolCodes";
        public static final String EQUIFAX_EDU_CODES = "EquifaxEduCodes";
        public static final String NSCH_CODES = "NSCHCodes";
        public static final String TALX_WORK_NUMBER_CODES = "TALXWorkNumber";

        public static final String CODES = "codes";
        public static final String PROVIDER_LINK = "providerLink";
        public static final String AS_NAME = "name";
        public static final String PROVIDER = "provider";
        public static final String AS_BRANCH = "branch";
        public static final String BRANCHES = "branches";
        public static final String COMPANY_NAMES = "companyNames";
        public static final String NSCH_INST_NAME = "NSCHInstName_";



    }

    public static class VENDORS {
        public static final String EQUI_FAX_HS = "Equifax High School";
        public static final String NSCH = "NSCH";
        public static final String EQUIFAX_EDU = "Equifax Education";
        public static final String TALX_WORK_NUMBER = "TALX (The Work Number)";

    }


    }

