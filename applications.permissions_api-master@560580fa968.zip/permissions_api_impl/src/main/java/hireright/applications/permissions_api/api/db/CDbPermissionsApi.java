package hireright.applications.permissions_api.api.db;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-17  HRG-330191 initial version
 */

import hireright.applications.permissions_api.api.IPermissionsApi;
import hireright.applications.permissions_api.api.db.management.CDbOperatorManager;
import hireright.applications.permissions_api.api.db.management.CDbOperatorPermissionsManager;
import hireright.applications.permissions_api.api.management.IOperatorManager;
import hireright.applications.permissions_api.api.management.IOperatorPermissionsManager;
import org.hibernate.Session;

public class CDbPermissionsApi implements IPermissionsApi
{
	private final Session m_session;

	public CDbPermissionsApi(Session session)
	{
		m_session = session;
	}

	@Override
	public IOperatorPermissionsManager getOperatorPermissionsManager()
	{
		return new CDbOperatorPermissionsManager(m_session);
	}

	@Override
	public IOperatorManager getOperatorManager()
	{
		return new CDbOperatorManager(m_session);
	}
}
