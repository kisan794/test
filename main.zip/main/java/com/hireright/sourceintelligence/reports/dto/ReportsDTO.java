package com.hireright.sourceintelligence.reports.dto;

import lombok.Data;


@Data
public class ReportsDTO {
    private String hon;
    private String organizationName;
    private String address;
    private String verificationValidationDate;
    private String organizationType;
    private String origin;
    private String approvalStatus; //Pending_approval, in_Progress
    private String approvedBy;
    private String approvedId;
    private int autoMatch;
    private Boolean isAutoMatch;
    private String action; //(update, archive, create, usedCount)
    private String createdBy;
    private String reason; //added to capture the reason for delete sources only
}
