package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.timezone.DropDownDTO;
import com.hireright.sourceintelligence.api.dto.timezone.TimeZoneResponseDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class TimeZoneApiControllerTest {

    private TimeZoneApiController timeZoneApiController;

    @BeforeEach
    void setUp() {
        timeZoneApiController = new TimeZoneApiController();
    }

    @Test
    void testGetTimeZones_returnsExpectedResponse() {
        ResponseEntity<TimeZoneResponseDTO> response = timeZoneApiController.getTimeZones();

        assertThat(response)
                .isNotNull()
                .extracting(ResponseEntity::getStatusCode)
                .satisfies(code -> assertThat(code.is2xxSuccessful()).isTrue());

        TimeZoneResponseDTO responseBody = response.getBody();
        assertThat(responseBody).isNotNull();

        List<DropDownDTO> timeZoneList = responseBody.getData();
        assertThat(timeZoneList)
                .isNotNull()
                .isNotEmpty()
                .allSatisfy(dto -> {
                    assertThat(dto.getValue())
                            .matches("^(Africa|America|Antarctica|Arctic|Asia|Atlantic|Australia|Europe|Indian|Pacific|Etc|SystemV)/.*");

                    assertThat(dto.getLabel())
                            .contains(dto.getValue())
                            .contains("GMT");
                });
    }

    @Test
    void testGetTimeZones_withEmptyRegionAndCity() {
        ResponseEntity<TimeZoneResponseDTO> response = timeZoneApiController.getTimeZones();

        assertThat(response).isNotNull();
        assertThat(response.getStatusCode().is2xxSuccessful()).isTrue();

        TimeZoneResponseDTO responseBody = response.getBody();
        assertThat(responseBody).isNotNull();
        assertThat(responseBody.getData()).isNotEmpty();
    }
}
