/*
 * @(#)$RCSfilev$ $Revision: 1.2 $ $Date: 2014/07/28 14:48:44 $ $Author: aputintsev $
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/resources/src/main/java/hireright/project/accesspoint/model/Return.java,v $
 *
 * Copyright 2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	J.Burlakova		2012-05-23	Created
 */
package hireright.project.accesspoint.model;

import javax.xml.bind.annotation.XmlElement;

/**
 *
 * @author Jekaterina Burlakova
 */
public class Return
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: aputintsev $";

	private String url;
	
	private String key;

	private String password;

	private Fault fault;

	public Return(){}

	@XmlElement(name = "key")
	public String getKey()
	{
		return key;
	}

	public void setKey( String key )
	{
		this.key = key;
	}

	@XmlElement(name = "url")
	public String getUrl()
	{
		return url;
	}

	public void setUrl( String url )
	{
		this.url = url;
	}
	
	@XmlElement(name = "password")
	public String getPassword()
	{
		return password;
	}

	public void setPassword( String password )
	{
		this.password = password;
	}

	@XmlElement(name = "Fault")
	public Fault getFault()
	{
		return fault;
	}

	public void setFault( Fault fault )
	{
		this.fault = fault;
	}
}
