package org.hireright.domain.entity;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FieldErrors {
    private String label;
    private String value;
}

