package com.hireright.sourceintelligence.util;

import com.hireright.sourceintelligence.constants.ApplicationConstants;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import jakarta.validation.constraints.NotNull;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * Util class to generate Hon for creation of SourceOrganization Document
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class HonGenerator {
    static final char[] chars = new char[]{'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
            'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '1', '2', '3', '4', '5', '6',
            '7', '8', '9', '0'};
    static final int CHARS_LENGTH = chars.length;
    static final int UNIQUE_STRING_LENGTH = 7;
    // Hon constants
    private static final String HON_PREFIX_EDUCATION = "OUEDU";
    private static final String HON_PREFIX_EMPLOYMENT = "OUEMP";

    /**
     * method to generate hon
     */
    public static String createHon(@NotNull OrganizationType organizationType)  {
        var newHon = new StringBuilder();

        switch (organizationType) {
            case EDUCATION:
                newHon.append(HON_PREFIX_EDUCATION);
                break;
            case EMPLOYMENT:
                newHon.append(HON_PREFIX_EMPLOYMENT);
                break;
            default:
                return null;

        }

        return newHon.append(ApplicationConstants.HYPHEN)
                .append(getCurrentDateAsMMDDYYFormat())
                .append(ApplicationConstants.HYPHEN)
                .append(getDurstenfeldShuffle())
                .toString();
    }

    public static String getCurrentDateAsMMDDYYFormat() {
        var pattern = "MMddyy";
        var sdf = new SimpleDateFormat(pattern);
        return sdf.format(new Date());
    }


    // See https://en.wikipedia.org/wiki/Fisher%E2%80%93Yates_shuffle#The_modern_algorithm
    // Note: Tested by generating 1,000,000 unique combinations.
    public static String getDurstenfeldShuffle() {
        var sr = new SecureRandom();
        var uniqueString = new StringBuilder();
        for (int i = 0; i < UNIQUE_STRING_LENGTH; i++) {
            int index = sr.nextInt(CHARS_LENGTH - i - 1);
            // Simple swap
            char a = chars[i + index];
            chars[i + index] = chars[i];
            chars[i] = a;
            uniqueString.append(a);
        }
        return uniqueString.toString();
    }

}
