package com.hireright.sourceintelligence.domain.mapper;

import static org.assertj.core.api.Assertions.assertThat;
import com.hireright.sourceintelligence.api.dto.SearchOrganizationDTO;

import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.util.TestDataProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

class SearchMapperTest {

  private SearchMapper searchMapper;

  @BeforeEach
  void setUp() {
    searchMapper = Mappers.getMapper(SearchMapper.class);
  }

  @Test
  void entityToDTOTest() {
    //given
    Source orgEntity = TestDataProvider.getSourceOrganizationEntityThree();
    orgEntity.setHon(TestDataProvider.getHon());
    //when
    SearchOrganizationDTO dto = searchMapper.entitySourceToDTO(orgEntity);
    //then
    assertThat(dto).isNotNull();
    assertThat(dto.getOrganizationName()).isEqualTo(orgEntity.getOrganizationName());
  }
}