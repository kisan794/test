/*
 * @(#)$RCSfilev$ $Revision: 1.2 $ $Date: 2014/07/28 14:48:47 $ $Author: aputintsev $
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/resources/src/main/java/hireright/project/accesspoint/resources/CHRConsts.java,v $
 *
 * Copyright 2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	J.Burlakova		2012-04-04	Created
 */
 
package hireright.project.accesspoint.resources;


/**
 *
 * @author Jekaterina Burlakova
 */
public class CHRConsts 
{
	public static final String VERSION_HR_CURRENT = "1.0";
	
	public static final String BLASH = "/";

	private static final String PATH_ACCESS_POINTS_BASE = "access_points";
	public static final String PATH_ACCESS_POINTS_SUB = BLASH + PATH_ACCESS_POINTS_BASE;
	public static final String PATH_ACCESS_POINTS_SUP = PATH_ACCESS_POINTS_BASE + BLASH;
	
	public static final String PATH_UUID_STD = "/{uuid}";
	public static final String PATH_INPUT_STD = "/{input}";	
	
	public static final String PARAM_UUID = "uuid";
	public static final String PARAM_INPUT = "input";
	
}