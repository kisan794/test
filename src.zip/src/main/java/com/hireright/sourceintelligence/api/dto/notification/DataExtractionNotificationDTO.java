package com.hireright.sourceintelligence.api.dto.notification;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * DTO for data extraction notification request
 * Specific DTO for data extraction completion notifications
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DataExtractionNotificationDTO {
    
    @NotEmpty(message = "At least one recipient email address is required")
    private List<@Email(message = "Invalid email address") String> recipients;
    
    @NotNull(message = "Data extraction type is required")
    private String dataExtractionType;
    
    private String filename;
    
    private Integer totalRecords;
    
    private Integer totalSourcesUpdated;
    
    private Integer notFoundRecords;
    
    private Long processingTimeMs;
    
    private boolean includeNotFoundRecords;
}

