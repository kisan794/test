package com.hireright.sourceintelligence.service.extraction;

import com.hireright.sourceintelligence.api.dto.ParchmentRecord;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.entity.Vendors;
import com.hireright.sourceintelligence.domain.repository.VendorsRepository;
import com.mongodb.BasicDBObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ParchmentDataExtractionProcessorTest {

    @Mock
    private VendorsRepository vendorsRepository;

    @Mock
    private MongoTemplate mongoTemplate;

    @InjectMocks
    private ParchmentDataExtractionProcessor processor;

    private Vendors parchmentVendor;
    private List<ParchmentRecord> sampleRecords;

    @BeforeEach
    void setUp() {
        parchmentVendor = new Vendors();
        parchmentVendor.setVendor("Parchment Exchange");
        parchmentVendor.setProviderId(123);
        parchmentVendor.setWebsite("https://www.parchment.com");

        sampleRecords = Arrays.asList(
                ParchmentRecord.builder()
                        .institutionName("Harvard University")
                        .country("USA")
                        .city("Cambridge")
                        .stateCountyRegion("MA")
                        .serviceProvider("Parchment Exchange")
                        .surchargeAmount("5.00")
                        .paymentMethod("Credit Card")
                        .code("HARV001")
                        .turnaroundTime("3")
                        .followUpAllowed("Yes")
                        .build(),
                ParchmentRecord.builder()
                        .institutionName("MIT")
                        .country("USA")
                        .city("Cambridge")
                        .stateCountyRegion("MA")
                        .serviceProvider("Parchment Exchange")
                        .surchargeAmount("5.00")
                        .paymentMethod("Credit Card")
                        .code("MIT001")
                        .turnaroundTime("3")
                        .followUpAllowed("Yes")
                        .build()
        );
    }

    @Test
    void testGetDataExtractionTypeType() {
        String dataExtractionType = processor.getDataExtractionTypeType();
        assertEquals("parchment", dataExtractionType);
    }

    @Test
    void testSupports_Parchment() {
        boolean supports = processor.supports("parchment");
        assertTrue(supports);
    }

    @Test
    void testSupports_OtherType() {
        boolean supports = processor.supports("clearinghouse");
        assertFalse(supports);
    }

    @Test
    void testProcessInstitutionRecords_Success() {
        List<Vendors> vendors = Collections.singletonList(parchmentVendor);
        when(vendorsRepository.findAll()).thenReturn(vendors);

        Source source1 = createMockSource("EDU123", "Harvard University");
        Source source2 = createMockSource("EDU124", "MIT");

        when(mongoTemplate.find(any(Query.class), eq(Source.class), eq("education_source")))
                .thenReturn(Collections.singletonList(source1))
                .thenReturn(Collections.singletonList(source2));

        var mockBulkOps = mock(org.springframework.data.mongodb.core.BulkOperations.class);
        when(mongoTemplate.bulkOps(any(), anyString())).thenReturn(mockBulkOps);
        when(mockBulkOps.upsert(any(Query.class), any(org.springframework.data.mongodb.core.query.Update.class)))
                .thenReturn(mockBulkOps);

        var mockBulkWriteResult = mock(com.mongodb.bulk.BulkWriteResult.class);
        when(mockBulkWriteResult.getModifiedCount()).thenReturn(2);
        when(mockBulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());
        when(mockBulkOps.execute()).thenReturn(mockBulkWriteResult);

        Map<String, Object> result = processor.processInstitutionRecords(sampleRecords);

        assertNotNull(result);
        assertEquals(2, result.get("totalRecords"));
        assertEquals(2, result.get("updatedRecords"));
        assertEquals(2, result.get("totalSourcesUpdated"));
        assertEquals(0, result.get("notFoundRecords"));
        assertTrue(((List<?>) result.get("notFoundInstitutions")).isEmpty());

        verify(vendorsRepository).findAll();
        verify(mongoTemplate, times(2)).find(any(Query.class), eq(Source.class), eq("education_source"));
        verify(mongoTemplate).bulkOps(any(), anyString());
        verify(mockBulkOps, times(2)).upsert(any(Query.class), any(org.springframework.data.mongodb.core.query.Update.class));
        verify(mockBulkOps).execute();
    }

    @Test
    void testProcessInstitutionRecords_InstitutionNotFound() {
        List<Vendors> vendors = Collections.singletonList(parchmentVendor);
        when(vendorsRepository.findAll()).thenReturn(vendors);

        Source source1 = createMockSource("EDU123", "Harvard University");

        when(mongoTemplate.find(any(Query.class), eq(Source.class), eq("education_source")))
                .thenReturn(Collections.singletonList(source1))
                .thenReturn(Collections.emptyList());

        var mockBulkOps = mock(org.springframework.data.mongodb.core.BulkOperations.class);
        when(mongoTemplate.bulkOps(any(), anyString())).thenReturn(mockBulkOps);
        when(mockBulkOps.upsert(any(Query.class), any(org.springframework.data.mongodb.core.query.Update.class)))
                .thenReturn(mockBulkOps);

        var mockBulkWriteResult = mock(com.mongodb.bulk.BulkWriteResult.class);
        when(mockBulkWriteResult.getModifiedCount()).thenReturn(1);
        when(mockBulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());
        when(mockBulkOps.execute()).thenReturn(mockBulkWriteResult);

        Map<String, Object> result = processor.processInstitutionRecords(sampleRecords);

        assertNotNull(result);
        assertEquals(2, result.get("totalRecords"));
        assertEquals(1, result.get("updatedRecords"));
        assertEquals(1, result.get("notFoundRecords"));

        List<String> notFoundInstitutions = (List<String>) result.get("notFoundInstitutions");
        assertEquals(1, notFoundInstitutions.size());
        assertTrue(notFoundInstitutions.get(0).contains("MIT"));

        verify(mongoTemplate, times(2)).find(any(Query.class), eq(Source.class), eq("education_source"));
        verify(mongoTemplate).bulkOps(any(), anyString());
        verify(mockBulkOps).upsert(any(Query.class), any(org.springframework.data.mongodb.core.query.Update.class));
        verify(mockBulkOps).execute();
    }

    @Test
    void testProcessInstitutionRecords_VendorNotFound() {
        when(vendorsRepository.findAll()).thenReturn(Collections.emptyList());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            processor.processInstitutionRecords(sampleRecords);
        });

        assertTrue(exception.getMessage().contains("Vendor 'Parchment Exchange' not found"));
        verify(vendorsRepository).findAll();
        verifyNoInteractions(mongoTemplate);
    }

    @Test
    void testProcessInstitutionRecords_EmptyList() {
        List<Vendors> vendors = Collections.singletonList(parchmentVendor);
        when(vendorsRepository.findAll()).thenReturn(vendors);

        Map<String, Object> result = processor.processInstitutionRecords(Collections.emptyList());

        assertNotNull(result);
        assertEquals(0, result.get("totalRecords"));
        assertEquals(0, result.get("updatedRecords"));
        assertEquals(0, result.get("notFoundRecords"));
        assertTrue(((List<?>) result.get("notFoundInstitutions")).isEmpty());

        verify(vendorsRepository).findAll();
        verifyNoMoreInteractions(mongoTemplate);
    }

    @Test
    void testProcessInstitutionRecords_ProcessingError() {
        List<Vendors> vendors = Collections.singletonList(parchmentVendor);
        when(vendorsRepository.findAll()).thenReturn(vendors);

        when(mongoTemplate.find(any(Query.class), eq(Source.class), eq("education_source")))
                .thenThrow(new RuntimeException("Database connection failed"));

        Map<String, Object> result = processor.processInstitutionRecords(sampleRecords);

        assertNotNull(result);
        assertEquals(2, result.get("totalRecords"));
        assertEquals(0, result.get("updatedRecords"));
        assertEquals(2, result.get("notFoundRecords"));

        List<String> notFoundInstitutions = (List<String>) result.get("notFoundInstitutions");
        assertEquals(2, notFoundInstitutions.size());
        assertTrue(notFoundInstitutions.get(0).contains("Error"));

        verify(mongoTemplate, times(2)).find(any(Query.class), eq(Source.class), eq("education_source"));
        verify(mongoTemplate, never()).bulkOps(any(), anyString());
    }

    @Test
    void testProcessInstitutionRecords_PartialSuccess() {
        List<Vendors> vendors = Collections.singletonList(parchmentVendor);
        when(vendorsRepository.findAll()).thenReturn(vendors);

        Source source1 = createMockSource("EDU123", "Harvard University");

        when(mongoTemplate.find(any(Query.class), eq(Source.class), eq("education_source")))
                .thenReturn(Collections.singletonList(source1))
                .thenThrow(new RuntimeException("Connection timeout"));

        var mockBulkOps = mock(org.springframework.data.mongodb.core.BulkOperations.class);
        when(mongoTemplate.bulkOps(any(), anyString())).thenReturn(mockBulkOps);
        when(mockBulkOps.upsert(any(Query.class), any(org.springframework.data.mongodb.core.query.Update.class)))
                .thenReturn(mockBulkOps);

        var mockBulkWriteResult = mock(com.mongodb.bulk.BulkWriteResult.class);
        when(mockBulkWriteResult.getModifiedCount()).thenReturn(1);
        when(mockBulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());
        when(mockBulkOps.execute()).thenReturn(mockBulkWriteResult);

        Map<String, Object> result = processor.processInstitutionRecords(sampleRecords);

        assertNotNull(result);
        assertEquals(2, result.get("totalRecords"));
        assertEquals(1, result.get("updatedRecords"));
        assertEquals(1, result.get("notFoundRecords"));

        List<String> notFoundInstitutions = (List<String>) result.get("notFoundInstitutions");
        assertEquals(1, notFoundInstitutions.size());
        assertTrue(notFoundInstitutions.get(0).contains("MIT"));

        verify(mongoTemplate, times(2)).find(any(Query.class), eq(Source.class), eq("education_source"));
        verify(mongoTemplate).bulkOps(any(), anyString());
        verify(mockBulkOps).execute();
    }

    @Test
    void testProcessInstitutionRecords_UpdatesPayload() {
        List<Vendors> vendors = Collections.singletonList(parchmentVendor);
        when(vendorsRepository.findAll()).thenReturn(vendors);

        Source source = createMockSource("EDU123", "Harvard University");
        when(mongoTemplate.find(any(Query.class), eq(Source.class), eq("education_source")))
                .thenReturn(Collections.singletonList(source));

        var mockBulkOps = mock(org.springframework.data.mongodb.core.BulkOperations.class);
        when(mongoTemplate.bulkOps(any(), anyString())).thenReturn(mockBulkOps);
        when(mockBulkOps.upsert(any(Query.class), any(org.springframework.data.mongodb.core.query.Update.class)))
                .thenReturn(mockBulkOps);

        var mockBulkWriteResult = mock(com.mongodb.bulk.BulkWriteResult.class);
        when(mockBulkWriteResult.getModifiedCount()).thenReturn(1);
        when(mockBulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());
        when(mockBulkOps.execute()).thenReturn(mockBulkWriteResult);

        processor.processInstitutionRecords(Collections.singletonList(sampleRecords.get(0)));

        verify(mockBulkOps).upsert(any(Query.class), argThat(update -> {
            return true;
        }));
        verify(mockBulkOps).execute();
    }

    @Test
    void testProcessInstitutionRecords_StateMapping() {
        List<Vendors> vendors = Collections.singletonList(parchmentVendor);
        when(vendorsRepository.findAll()).thenReturn(vendors);

        ParchmentRecord recordWithStateAbbr = ParchmentRecord.builder()
                .institutionName("Test University")
                .country("USA")
                .city("Boston")
                .stateCountyRegion("MA")
                .build();

        Source source = createMockSource("EDU125", "Test University");
        when(mongoTemplate.find(any(Query.class), eq(Source.class), eq("education_source")))
                .thenReturn(Collections.singletonList(source));

        Map<String, Object> result = processor.processInstitutionRecords(
                Collections.singletonList(recordWithStateAbbr)
        );

        assertEquals(1, result.get("updatedRecords"));
        verify(mongoTemplate).find(any(Query.class), eq(Source.class), eq("education_source"));
    }

    @Test
    void testProcessInstitutionRecords_BulkSaveOptimization() {
        List<ParchmentRecord> multipleRecords = Arrays.asList(
                sampleRecords.get(0),
                sampleRecords.get(1),
                ParchmentRecord.builder()
                        .institutionName("Stanford University")
                        .country("USA")
                        .city("Stanford")
                        .stateCountyRegion("CA")
                        .build()
        );

        List<Vendors> vendors = Collections.singletonList(parchmentVendor);
        when(vendorsRepository.findAll()).thenReturn(vendors);

        Source source1 = createMockSource("EDU123", "Harvard University");
        Source source2 = createMockSource("EDU124", "MIT");
        Source source3 = createMockSource("EDU125", "Stanford University");

        when(mongoTemplate.find(any(Query.class), eq(Source.class), eq("education_source")))
                .thenReturn(Collections.singletonList(source1))
                .thenReturn(Collections.singletonList(source2))
                .thenReturn(Collections.singletonList(source3));

        var mockBulkOps = mock(org.springframework.data.mongodb.core.BulkOperations.class);
        when(mongoTemplate.bulkOps(any(), anyString())).thenReturn(mockBulkOps);
        when(mockBulkOps.upsert(any(Query.class), any(org.springframework.data.mongodb.core.query.Update.class)))
                .thenReturn(mockBulkOps);

        var mockBulkWriteResult = mock(com.mongodb.bulk.BulkWriteResult.class);
        when(mockBulkWriteResult.getModifiedCount()).thenReturn(3);
        when(mockBulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());
        when(mockBulkOps.execute()).thenReturn(mockBulkWriteResult);

        Map<String, Object> result = processor.processInstitutionRecords(multipleRecords);

        assertEquals(3, result.get("totalRecords"));
        assertEquals(3, result.get("updatedRecords"));

        verify(mongoTemplate).bulkOps(any(), anyString());
        verify(mockBulkOps, times(3)).upsert(any(Query.class), any(org.springframework.data.mongodb.core.query.Update.class));
        verify(mockBulkOps, times(1)).execute();
        verify(mongoTemplate, never()).save(any(Source.class), anyString());
    }

    @Test
    void testProcessInstitutionRecords_BulkSaveFallback() {
        List<Vendors> vendors = Collections.singletonList(parchmentVendor);
        when(vendorsRepository.findAll()).thenReturn(vendors);

        Source source1 = createMockSource("EDU123", "Harvard University");
        Source source2 = createMockSource("EDU124", "MIT");

        when(mongoTemplate.find(any(Query.class), eq(Source.class), eq("education_source")))
                .thenReturn(Collections.singletonList(source1))
                .thenReturn(Collections.singletonList(source2));

        var mockBulkOps = mock(org.springframework.data.mongodb.core.BulkOperations.class);
        when(mongoTemplate.bulkOps(any(), anyString())).thenReturn(mockBulkOps);
        when(mockBulkOps.upsert(any(Query.class), any(org.springframework.data.mongodb.core.query.Update.class)))
                .thenReturn(mockBulkOps);
        when(mockBulkOps.execute()).thenThrow(new RuntimeException("Bulk operation failed"));

        Map<String, Object> result = processor.processInstitutionRecords(sampleRecords);

        assertEquals(2, result.get("totalRecords"));
        assertEquals(2, result.get("updatedRecords"));

        verify(mongoTemplate).bulkOps(any(), anyString());
        verify(mockBulkOps).execute();

        verify(mongoTemplate, times(2)).save(any(Source.class), anyString());
    }

    @Test
    void testProcessInstitutionRecords_MultipleCollections() {
        ParchmentRecord record1 = sampleRecords.get(0);
        ParchmentRecord record2 = sampleRecords.get(1);

        List<Vendors> vendors = Collections.singletonList(parchmentVendor);
        when(vendorsRepository.findAll()).thenReturn(vendors);

        Source source1 = createMockSource("EDU123", "Harvard University");
        Source source2 = createMockSource("EDU124", "MIT");

        when(mongoTemplate.find(any(Query.class), eq(Source.class), eq("education_source")))
                .thenReturn(Collections.singletonList(source1))
                .thenReturn(Collections.singletonList(source2));

        var mockBulkOps = mock(org.springframework.data.mongodb.core.BulkOperations.class);
        when(mongoTemplate.bulkOps(any(), anyString())).thenReturn(mockBulkOps);
        when(mockBulkOps.upsert(any(Query.class), any(org.springframework.data.mongodb.core.query.Update.class)))
                .thenReturn(mockBulkOps);

        var mockBulkWriteResult = mock(com.mongodb.bulk.BulkWriteResult.class);
        when(mockBulkWriteResult.getModifiedCount()).thenReturn(2);
        when(mockBulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());
        when(mockBulkOps.execute()).thenReturn(mockBulkWriteResult);

        Map<String, Object> result = processor.processInstitutionRecords(Arrays.asList(record1, record2));

        assertEquals(2, result.get("updatedRecords"));

        verify(mongoTemplate, atLeastOnce()).bulkOps(any(), anyString());
        verify(mockBulkOps, atLeastOnce()).execute();
    }

    @Test
    void testProcessInstitutionRecords_MultipleMatches() {
        List<Vendors> vendors = Collections.singletonList(parchmentVendor);
        when(vendorsRepository.findAll()).thenReturn(vendors);

        Source source1 = createMockSource("EDU123", "Harvard University");
        Source source2 = createMockSource("EDU456", "Harvard University");
        Source source3 = createMockSource("EDU789", "Harvard University");

        when(mongoTemplate.find(any(Query.class), eq(Source.class), eq("education_source")))
                .thenReturn(Arrays.asList(source1, source2, source3));

        var mockBulkOps = mock(org.springframework.data.mongodb.core.BulkOperations.class);
        when(mongoTemplate.bulkOps(any(), anyString())).thenReturn(mockBulkOps);
        when(mockBulkOps.upsert(any(Query.class), any(org.springframework.data.mongodb.core.query.Update.class)))
                .thenReturn(mockBulkOps);

        var mockBulkWriteResult = mock(com.mongodb.bulk.BulkWriteResult.class);
        when(mockBulkWriteResult.getModifiedCount()).thenReturn(3);
        when(mockBulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());
        when(mockBulkOps.execute()).thenReturn(mockBulkWriteResult);

        Map<String, Object> result = processor.processInstitutionRecords(
                Collections.singletonList(sampleRecords.get(0))
        );

        assertNotNull(result);
        assertEquals(1, result.get("totalRecords"));
        assertEquals(1, result.get("updatedRecords"));
        assertEquals(3, result.get("totalSourcesUpdated"));
        assertEquals(0, result.get("notFoundRecords"));

        verify(mockBulkOps, times(3)).upsert(any(Query.class), any(org.springframework.data.mongodb.core.query.Update.class));
        verify(mockBulkOps).execute();
    }

    @Test
    void testProcessInstitutionRecords_MatchByAlias() {
        List<Vendors> vendors = Collections.singletonList(parchmentVendor);
        when(vendorsRepository.findAll()).thenReturn(vendors);

        Source source = createMockSource("EDU123", "Massachusetts Institute of Technology");

        when(mongoTemplate.find(any(Query.class), eq(Source.class), eq("education_source")))
                .thenReturn(Collections.singletonList(source));

        var mockBulkOps = mock(org.springframework.data.mongodb.core.BulkOperations.class);
        when(mongoTemplate.bulkOps(any(), anyString())).thenReturn(mockBulkOps);
        when(mockBulkOps.upsert(any(Query.class), any(org.springframework.data.mongodb.core.query.Update.class)))
                .thenReturn(mockBulkOps);

        var mockBulkWriteResult = mock(com.mongodb.bulk.BulkWriteResult.class);
        when(mockBulkWriteResult.getModifiedCount()).thenReturn(1);
        when(mockBulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());
        when(mockBulkOps.execute()).thenReturn(mockBulkWriteResult);

        Map<String, Object> result = processor.processInstitutionRecords(
                Collections.singletonList(sampleRecords.get(1))
        );

        assertEquals(1, result.get("updatedRecords"));
        assertEquals(0, result.get("notFoundRecords"));
        verify(mongoTemplate).find(any(Query.class), eq(Source.class), eq("education_source"));
    }

    private Source createMockSource(String hon, String organizationName) {
        Source source = new Source();
        source.setHon(hon);
        source.setOrganizationName(organizationName);
        source.setPayload(new BasicDBObject());
        return source;
    }
}