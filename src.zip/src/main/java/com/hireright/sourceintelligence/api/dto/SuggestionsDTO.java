package com.hireright.sourceintelligence.api.dto;

import lombok.Data;

@Data
public class SuggestionsDTO {
    private String label;
    private String value;
    private int score;
    private String orgUnitEduHONDomID;
    private String orgUnitEduHONVal;
    private String orgUnitEduNameDomID;
    private String orgUnitEduNameVal;
    private String orgUnitEduCountryIDDomID;
    private String orgUnitEduCountryIDVal;
    private String orgUnitEduRegionIDDomID;
    private String orgUnitEduRegionIDVal;
    private String orgUnitEduRegionDomID;
    private String orgUnitEduRegionVal;
    private String orgUnitEduMunicipalityDomID;
    private String orgUnitEduMunicipalityVal;
    private String orgUnitEduPhoneDomID;
    private String orgUnitEduPhoneCountryCode;
    private String orgUnitEduPhoneAreaCode;
    private String orgUnitEduPhoneNumber;
    private String orgUnitEduPhoneExt;
}
