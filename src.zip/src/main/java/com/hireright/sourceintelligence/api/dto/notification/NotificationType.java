package com.hireright.sourceintelligence.api.dto.notification;

/**
 * Enum representing the types of notifications supported by the system.
 * This enum follows the Open/Closed Principle - new types can be added without modifying existing code.
 */
public enum NotificationType {
    /**
     * Email notification type
     */
    EMAIL,
    
    /**
     * SMS notification type
     */
    SMS,
    
    /**
     * Push notification type (for future implementation)
     */
    PUSH,
    
    /**
     * Slack notification type (for future implementation)
     */
    SLACK
}

