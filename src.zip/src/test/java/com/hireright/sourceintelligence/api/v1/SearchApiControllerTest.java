package com.hireright.sourceintelligence.api.v1;

import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.MATCH;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.PHRASE_SEARCH_PATH;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.SEARCH;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.SOURCE_ORGANIZATION;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.SOURCE_ORGANIZATION_AUTOCOMPLETE;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.SUGGESTION;
import static com.hireright.sourceintelligence.api.ApiConstants.CONFIDENCE_THRESHOLD;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.*;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.hireright.sourceintelligence.api.ApiConstants.ApiPath;
import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.dto.history.Location;
import com.hireright.sourceintelligence.api.v2.dto.SourceDTO;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SortOrder;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.domain.enums.UserRoles;
import com.hireright.sourceintelligence.exception.GlobalApiExceptionHandler;
import com.hireright.sourceintelligence.exception.InvalidRequestException;
import com.hireright.sourceintelligence.service.CommonUtilService;
import com.hireright.sourceintelligence.service.SearchService;
import com.hireright.sourceintelligence.service.SmartSearchService;
import com.hireright.sourceintelligence.util.TestDataProvider;
import static org.mockito.Mockito.lenient;

import java.lang.reflect.Field;
import java.util.*;

import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ExtendWith(MockitoExtension.class)
class SearchApiControllerTest {
    private MockMvc mockMvc;

    private static final String INCORRECT_PATH = "invalid_path";

    @Mock
    private SearchService searchOrganizationService;

    @InjectMocks
    private SearchApiController searchApiController;

    @Mock
    private UserInfo userInfo;
    @Mock
    private SmartSearchService smartSearchService;


    @Mock
    private CommonUtilService commonUtilService;


    @BeforeEach
    public void setup() {
        JacksonTester.initFields(this, new ObjectMapper());
        // MockMvc standalone approach
        mockMvc = MockMvcBuilders.standaloneSetup(searchApiController)
                .setControllerAdvice(new GlobalApiExceptionHandler())
                .build();

        userInfo = new UserInfo();
        userInfo.setRoles(List.of(UserRoles.RESEARCH_ANALYST.getRole()));
        userInfo.setRoles(Collections.singletonList("ROLE_CREATE_SOURCE"));
    }

    @Test
    void validatePhraseBlank() {
        assertThatExceptionOfType(InvalidRequestException.class)
                .isThrownBy(() -> searchApiController.validateSearchKey(""));
    }

    @Test
    void validatePhrase() {
        assertThatNoException().isThrownBy(() -> searchApiController.validateSearchKey("test test"));
    }

    @Test
    void phraseSearchNotFound() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        .get(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + PHRASE_SEARCH_PATH + INCORRECT_PATH)
                        .param("searchPhrase", "Pedro Tores School")
                        .param("organizationType", OrganizationType.EMPLOYMENT.toString())
                        .param("startPage", "1")
                        .param("pageSize", "10")
                        .accept(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isNotFound());
    }


    @Test
    void validateSearchFiltersBlank() {
        List<SearchFilter> searchFilterList = new ArrayList<>();
        assertThatExceptionOfType(InvalidRequestException.class)
                .isThrownBy(() -> searchApiController.validateSearchFilters(searchFilterList));
    }

    @Test
    void validateSearchFilters() {
        assertThatNoException().isThrownBy(() -> searchApiController.validateSearchFilters(TestDataProvider.getAllSearchFilters()));
    }

    @Test
    void autocompleteFilters() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        .get(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + SOURCE_ORGANIZATION_AUTOCOMPLETE + ApiPath.SEARCH)
                        .param("searchKey", "Pedro Tores School")
                        .param("organizationType", OrganizationType.EDUCATION.toString())
                        .param("status", SourceOrganizationStatus.ACTIVE.toString())
                        .accept(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isOk());
    }


    @Test
    void autocompleteFiltersNotFound() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        .get(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + SOURCE_ORGANIZATION_AUTOCOMPLETE + ApiPath.SEARCH + INCORRECT_PATH)
                        .param("searchPhrase", "Pedro Tores School")
                        .param("organizationType", OrganizationType.EMPLOYMENT.toString())
                        .param("startPage", "1")
                        .param("pageSize", "10")
                        .accept(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    void sourceOrganizationsByFilters() throws Exception {
        SourceOrganizationDTO dto = new SourceOrganizationDTO();
        dto.setId(new ObjectId().toHexString());
        dto.setOrganizationName("Pedro Tores School");

        SearchResponseDTO response = new SearchResponseDTO();
        response.setSourceList(List.of(dto));
        response.setTotalItems(1L);

        when(searchOrganizationService.getSourcesByFilters(any(), anyString(), anyString(), anyInt(), anyInt()))
                .thenReturn(response);

        SearchFilter searchFilter = new SearchFilter();
        searchFilter.setSearchKey("Pedro Tores School");
        searchFilter.setOrganizationType(OrganizationType.EDUCATION.getType());
        searchFilter.setStartPage(1);
        searchFilter.setPageSize(10);
        searchFilter.setOrder(SortOrder.ASC.getType());
        searchFilter.setSort("organizationName");

        String requestBody = new ObjectMapper().writeValueAsString(searchFilter);

        mockMvc.perform(MockMvcRequestBuilders
                        .post(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + SOURCE_ORGANIZATION + ApiPath.SEARCH)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(requestBody)
                        .accept(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isOk());
    }

    @Test
    void sourceOrganizationsByFilters_internal() throws Exception {
        when(searchOrganizationService.getSourcesByFilters(any(), any(), any(), anyInt(), anyInt()))
                .thenReturn(new SearchResponseDTO());

        RequestBuilder request = MockMvcRequestBuilders
                .post(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + SOURCE_ORGANIZATION + SEARCH)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{ \"organizationName\": \"Pedro Tores School\", \"organizationAlias\": \"Pedro\", \"organizationType\": \"EDUCATION\", \"status\": \"ACTIVE\", \"startPage\": 1, \"pageSize\": 10 }")
                .accept(MediaType.APPLICATION_JSON);

        mockMvc.perform(request)
                .andExpect(status().isOk());
    }


    @Test
    void sourceOrganizationsByFiltersNotFound() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        .get(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + SOURCE_ORGANIZATION + SEARCH + INCORRECT_PATH)
                        .param("searchPhrase", "Pedro Tores School")
                        .param("organizationType", OrganizationType.EMPLOYMENT.toString())
                        .param("startPage", "1")
                        .param("pageSize", "10")
                        .accept(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isNotFound());
    }


    @Test
    void autocompleteSuggestionForPossibleDuplicate_NotFound() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        .get(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + SOURCE_ORGANIZATION_AUTOCOMPLETE + SOURCE_ORGANIZATION + INCORRECT_PATH)
                        .param("searchPhrase", "Pedro Tores School")
                        .param("organizationType", OrganizationType.EMPLOYMENT.toString())
                        .param("startPage", "1")
                        .param("pageSize", "10")
                        .accept(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    void autocompleteSuggestionForPossibleDuplicate() throws Exception {

        SourceOrganizationDTO dto = new SourceOrganizationDTO();
        dto.setId(new ObjectId().toHexString());
        dto.setOrganizationName("Pedro Tores School");

        SearchResponseDTO response = new SearchResponseDTO();
        response.setSourceList(List.of(dto));
        response.setTotalItems(1L);

        when(searchOrganizationService.getAutocompletedSuggestionForPossibleDuplicates(anyString(), any()))
                .thenReturn(response);
        mockMvc.perform(MockMvcRequestBuilders
                        .get(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + SOURCE_ORGANIZATION_AUTOCOMPLETE + SUGGESTION)
                        .param("searchKey", "Pedro Tores School")
                        .param("organizationType", OrganizationType.EDUCATION.toString())
                        .param("status", SourceOrganizationStatus.ACTIVE.toString())
                        .accept(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isOk());
    }

    @Test
    void searchSourceSuggestionsInvalidRequestTest() throws Exception {

        //assertThatExceptionOfType(InvalidRequestException.class).isThrownBy(() ->searchApiController.searchSourceSuggestions(OrganizationType.EDUCATION,"","","Country","",SourceOrganizationStatus.ACTIVE,20.0));
    }

    @Test
    void searchSourceSuggestionsInvalidRequestOneTest() throws Exception {

        //assertThatExceptionOfType(InvalidRequestException.class).isThrownBy(() ->searchApiController.searchSourceSuggestions(OrganizationType.EDUCATION,"","City","","State",SourceOrganizationStatus.ACTIVE,80.0));
    }

    @Test
    void getFiltersForSourceOrganizationsTest() throws Exception {
        userInfo.setRoles(List.of(UserRoles.RESEARCH_ANALYST.getRole()));
        //lenient().when(commonUtilService.getUserInfo(any())).thenReturn(userInfo);
        assertThatNoException()
                .isThrownBy(() -> searchApiController.getFiltersForSourceOrganizations("org", "OUEDU-082924-PICHKNV"));
    }

    @Test
    void getFiltersForSourceOrganizationsUnAuthorizedTest() throws Exception {
        //lenient().when(commonUtilService.getUserInfo(any())).thenReturn(userInfo);
        lenient().when(commonUtilService.isResearchAnalyst(any())).thenReturn(true);
        assertThatNoException().isThrownBy(() -> searchApiController.getFiltersForSourceOrganizations(
                "org", "OUEDU-082924-PICHKNV"));
    }

    @Test
    void getSourceListBySmartSearchTest() {
        SmartSearchDTO smartSearchDTO = new SmartSearchDTO();
        smartSearchDTO.setOrganizationType("EDUCATION");
        smartSearchDTO.setIsDropDownSelected(false);
        smartSearchDTO.setFromSubRequest(true);
        SearchResponseDTO mockResponse = new SearchResponseDTO();
        mockResponse.setSourceList(Collections.emptyList());
        mockResponse.setTotalItems(0);
        when(smartSearchService.getSourceListBySearch(any()))
                .thenReturn(mockResponse);

        ResponseEntity<SearchResponseDTO> response = searchApiController
                .getSourceListBySmartSearch("type", smartSearchDTO);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getSourceList()).asList().isEmpty();
    }


    @Test
    void searchSourceOrgInvalidReqTest() throws Exception {
        // assertThatExceptionOfType(InvalidRequestException.class).isThrownBy(() ->searchApiController.searchOrganizations(OrganizationType.EDUCATION,"","City","Country","",SourceOrganizationStatus.ACTIVE,"USA", 20.0));
    }

    @Test
    void sourceOrganizationsByFiltersTest() throws Exception {
        // given
        SearchFilter searchFilter = new SearchFilter();
        searchFilter.setSearchKey("text");

        // Create mock response safely (no mapper call, id is non-null)
        SourceOrganizationDTO dto = new SourceOrganizationDTO();
        dto.setId(new ObjectId().toHexString());
        dto.setOrganizationName("Some Org");

        SearchResponseDTO mockResponse = new SearchResponseDTO();
        mockResponse.setSourceList(List.of(dto));
        mockResponse.setTotalItems(1L);

        when(searchOrganizationService.getSourcesByFilters(any(), any(), any(), anyInt(), anyInt()))
                .thenReturn(mockResponse);

        // then
        assertThatNoException()
                .isThrownBy(() -> searchApiController.sourceOrganizationsByFilters(searchFilter));
    }

}
