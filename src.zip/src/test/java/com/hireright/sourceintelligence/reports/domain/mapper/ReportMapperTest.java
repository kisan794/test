package com.hireright.sourceintelligence.reports.domain.mapper;

import com.hireright.sourceintelligence.reports.domain.entity.ResponseReport;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ReportMapperTest {

    private ReportMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new ReportMapperImpl();
    }

    @Test
    void mapAutoMatch_shouldReturnYes_whenAutoMatchIsOne() {
        ResponseReport responseReport = new ResponseReport();
        responseReport.setAutoMatch(1);

        String result = mapper.mapAutoMatch(responseReport);

        assertEquals("Yes", result);
    }

    @Test
    void mapAutoMatch_shouldReturnNo_whenAutoMatchIsNotOne() {
        ResponseReport responseReport = new ResponseReport();
        responseReport.setAutoMatch(0);

        String result = mapper.mapAutoMatch(responseReport);

        assertEquals("No", result);
    }
}