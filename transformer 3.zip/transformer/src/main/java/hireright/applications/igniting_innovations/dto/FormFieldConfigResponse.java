package hireright.applications.igniting_innovations.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Response DTO for form field configuration.
 *
 * @author Generated
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Response object containing form field configuration")
public class FormFieldConfigResponse {

    @Schema(description = "Unique identifier", example = "507f1f77bcf86cd799439011")
    @JsonProperty("id")
    private String id;

    @Schema(description = "Unique identifier for the field", example = "impactAreas")
    @JsonProperty("fieldKey")
    private String fieldKey;

    @Schema(description = "List of options for the field")
    @JsonProperty("options")
    private List<FieldOptionResponse> options;

    @Schema(description = "Created timestamp", example = "2026-01-16T10:30:00")
    @JsonProperty("createdAt")
    private LocalDateTime createdAt;

    @Schema(description = "Last updated timestamp", example = "2026-01-16T10:30:00")
    @JsonProperty("updatedAt")
    private LocalDateTime updatedAt;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "Field option")
    public static class FieldOptionResponse {

        @Schema(description = "Option value", example = "PROCESS")
        @JsonProperty("value")
        private String value;

        @Schema(description = "Option label", example = "Process")
        @JsonProperty("label")
        private String label;
    }
}

