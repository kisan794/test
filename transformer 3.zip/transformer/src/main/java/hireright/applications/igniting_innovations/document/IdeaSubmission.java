package hireright.applications.igniting_innovations.document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * MongoDB document representing an Idea Submission.
 * Stores all information related to submitted ideas including basic info,
 * impact areas, implementation details, and tracking status.
 *
 * @author Generated
 * @version 1.0
 */
@Document(collection = "idea_submissions")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IdeaSubmission {

    @Id
    private String id;

    // Section 1: Basic Information
    @Indexed
    private String title;

    @Indexed
    private String submittedBy;

    private String emailAddress;

    @Indexed
    private String department;

    @Indexed
    private LocalDateTime submissionDate;

    // Section 2: Idea Details
    private String description;

    private String objective;

    // Section 3: Area of Impact (stored as list)
    private List<String> impactAreas;

    // Section 4: Type of Improvement (stored as list)
    private List<String> improvementTypes;

    private String improvementTypeOther;

    // Section 5: Expected Impact
    private String expectedBenefit;

    private List<String> impactCategories;

    private String impactCategoryOther;

    // Section 6: Implementation Details
    private String implementationComplexity;

    private String suggestedSteps;

    private String timelineType;

    // Section 7: Supporting Information
    private List<String> supportingDocuments;

    private String additionalComments;

    // Status Tracking
    @Indexed
    @Builder.Default
    private String status = "SUBMITTED";

    // Engagement Metrics
    @Builder.Default
    private Integer upvoteCount = 0;

    // Audit Fields
    @Indexed
    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    private LocalDateTime reviewedAt;

    private String reviewedBy;

    private String reviewComments;

    // Embedded comments
    @Builder.Default
    private List<IdeaComment> comments = new ArrayList<>();

    /**
     * Embedded comment class
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class IdeaComment {
        private String id;
        private String commenterName;
        private String commenterEmail;
        private String comment;
        private LocalDateTime createdAt;
    }
}

