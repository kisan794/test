#!/bin/bash

# Idea Submission API - cURL Examples
BASE_URL="http://localhost:8080/api/v1/ideas"

echo "=========================================="
echo "Idea Submission API Examples"
echo "=========================================="
echo ""

# 1. Minimal Idea Submission
echo "1. Minimal Idea Submission (Required Fields Only)"
echo "POST ${BASE_URL}"
curl -X POST "${BASE_URL}" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Automate Daily Report Generation",
    "submittedBy": "John Doe",
    "description": "Currently, daily reports are generated manually which takes 2 hours. This idea proposes automating the process using scheduled scripts.",
    "objective": "Reduce manual effort and improve accuracy of daily reports"
  }' | jq .
echo ""
echo ""

# 2. Complete Idea Submission
echo "2. Complete Idea Submission (All Fields)"
echo "POST ${BASE_URL}"
curl -X POST "${BASE_URL}" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Implement Automated Inventory Tracking System",
    "submittedBy": "Sarah Johnson",
    "emailAddress": "sarah.johnson@company.com",
    "department": "Operations",
    "description": "Our current inventory tracking is manual and error-prone. We lose track of items, have stockouts, and overstocking issues. An automated system with barcode scanning would solve these problems.",
    "objective": "Reduce inventory errors by 95%, prevent stockouts, and optimize inventory levels",
    "impactAreas": ["PROCESS", "QUALITY"],
    "improvementTypes": ["INNOVATIVE", "COST_SAVING"],
    "expectedBenefit": "Reduce inventory errors from 15% to less than 1%, save $50,000 annually in lost inventory, reduce stockouts by 90%, free up 20 hours per week of manual counting",
    "impactCategories": ["TIME_EFFICIENCY", "COST_SAVINGS", "COMPLIANCE_RISK_REDUCTION"],
    "implementationComplexity": "MEDIUM",
    "suggestedSteps": "1. Evaluate barcode scanning solutions\n2. Select vendor and purchase equipment\n3. Integrate with existing ERP system\n4. Train warehouse staff\n5. Pilot in one warehouse\n6. Roll out company-wide",
    "timelineType": "LONG_TERM",
    "supportingDocuments": [
      "https://company.sharepoint.com/inventory-analysis.xlsx",
      "https://company.sharepoint.com/vendor-comparison.pdf"
    ],
    "additionalComments": "This has been discussed with the warehouse manager and IT director. Both are supportive. Estimated cost is $75,000 with ROI in 18 months."
  }' | jq .
echo ""
echo ""

# 3. Process Improvement Idea
echo "3. Process Improvement Idea"
echo "POST ${BASE_URL}"
curl -X POST "${BASE_URL}" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Streamline Employee Onboarding Process",
    "submittedBy": "Michael Chen",
    "emailAddress": "michael.chen@company.com",
    "department": "HR",
    "description": "New employee onboarding takes 3 weeks and involves 15 different manual steps across 5 departments. Many steps are redundant or could be automated.",
    "objective": "Reduce onboarding time from 3 weeks to 5 days and improve new hire satisfaction",
    "impactAreas": ["PROCESS", "PEOPLE"],
    "improvementTypes": ["INCREMENTAL", "QUALITY_ENHANCEMENT"],
    "expectedBenefit": "Reduce onboarding time by 70%, improve new hire satisfaction scores from 6.5 to 9.0, reduce HR administrative time by 15 hours per new hire",
    "impactCategories": ["TIME_EFFICIENCY", "EMPLOYEE_ENGAGEMENT"],
    "implementationComplexity": "LOW",
    "suggestedSteps": "1. Map current onboarding process\n2. Identify redundant steps\n3. Create digital onboarding checklist\n4. Automate IT account creation\n5. Create welcome kit template\n6. Train HR team on new process",
    "timelineType": "SHORT_TERM",
    "supportingDocuments": ["https://company.sharepoint.com/onboarding-survey-results.pdf"],
    "additionalComments": "Quick win with minimal cost. Can be implemented within 2 months."
  }' | jq .
echo ""
echo ""

# 4. Get All Ideas (Paginated)
echo "4. Get All Ideas (First Page)"
echo "GET ${BASE_URL}?page=0&size=10"
curl -X GET "${BASE_URL}?page=0&size=10" \
  -H "Content-Type: application/json" | jq .
echo ""
echo ""

# 5. Get Idea by ID (replace with actual ID from previous response)
echo "5. Get Idea by ID"
echo "GET ${BASE_URL}/{id}"
echo "Note: Replace {id} with actual MongoDB ObjectId from previous response"
echo "Example: curl -X GET '${BASE_URL}/65a7f8b9c1234567890abcde' | jq ."
echo ""
echo ""

# 6. Update Idea Status
echo "6. Update Idea Status to UNDER_REVIEW"
echo "PUT ${BASE_URL}/{id}/status"
echo "Note: Replace {id} with actual MongoDB ObjectId"
echo "Example:"
echo "curl -X PUT '${BASE_URL}/65a7f8b9c1234567890abcde/status' \\"
echo "  -H 'Content-Type: application/json' \\"
echo "  -d '{\"status\": \"UNDER_REVIEW\", \"reviewedBy\": \"Jane Smith\", \"reviewComments\": \"Looks promising, needs cost analysis\"}' | jq ."
echo ""
echo ""

# 7. Upvote an Idea
echo "7. Upvote an Idea"
echo "POST ${BASE_URL}/{id}/upvote"
echo "Note: Replace {id} with actual MongoDB ObjectId"
echo "Example: curl -X POST '${BASE_URL}/65a7f8b9c1234567890abcde/upvote' | jq ."
echo ""
echo ""

# 8. Add Comment to Idea
echo "8. Add Comment to Idea"
echo "POST ${BASE_URL}/{id}/comments"
echo "Note: Replace {id} with actual MongoDB ObjectId"
echo "Example:"
echo "curl -X POST '${BASE_URL}/65a7f8b9c1234567890abcde/comments' \\"
echo "  -H 'Content-Type: application/json' \\"
echo "  -d '{\"commenterName\": \"Bob Wilson\", \"commenterEmail\": \"bob@company.com\", \"comment\": \"Great idea! We should prioritize this.\"}' | jq ."
echo ""
echo ""

# 9. Search Ideas by Keyword
echo "9. Search Ideas by Keyword"
echo "GET ${BASE_URL}/search?keyword=automation&page=0&size=10"
curl -X GET "${BASE_URL}/search?keyword=automation&page=0&size=10" \
  -H "Content-Type: application/json" | jq .
echo ""
echo ""

# 10. Get Ideas by Status
echo "10. Get Ideas by Status (SUBMITTED)"
echo "GET ${BASE_URL}/status/SUBMITTED?page=0&size=10"
curl -X GET "${BASE_URL}/status/SUBMITTED?page=0&size=10" \
  -H "Content-Type: application/json" | jq .
echo ""
echo ""

# 11. Get Top Ideas by Upvotes
echo "11. Get Top Ideas by Upvotes"
echo "GET ${BASE_URL}/top?page=0&size=10"
curl -X GET "${BASE_URL}/top?page=0&size=10" \
  -H "Content-Type: application/json" | jq .
echo ""
echo ""

# 12. Get Dashboard Statistics
echo "12. Get Dashboard Statistics"
echo "GET ${BASE_URL}/dashboard/stats"
curl -X GET "${BASE_URL}/dashboard/stats" \
  -H "Content-Type: application/json" | jq .
echo ""
echo ""

echo "=========================================="
echo "All examples completed!"
echo "=========================================="
echo ""
echo "Available Idea Status Values:"
echo "  - SUBMITTED"
echo "  - UNDER_REVIEW"
echo "  - APPROVED"
echo "  - IMPLEMENTED"
echo "  - COMPLETED"
echo "  - REJECTED"
echo "  - ON_HOLD"
echo ""
echo "Available Implementation Complexity Values:"
echo "  - LOW"
echo "  - MEDIUM"
echo "  - HIGH"
echo ""
echo "Available Timeline Types:"
echo "  - SHORT_TERM"
echo "  - LONG_TERM"

