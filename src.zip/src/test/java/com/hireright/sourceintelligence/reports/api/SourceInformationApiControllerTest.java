package com.hireright.sourceintelligence.reports.api;

import com.hireright.sourceintelligence.reports.dto.ReportResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;
import com.hireright.sourceintelligence.reports.service.SourceInformationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SourceInformationApiControllerTest {

    @Mock
    private SourceInformationService sourceInformationService;

    @InjectMocks
    private SourceInformationApiController sourceInformationApiController;

    private ReportsRequestDTO requestDTO;
    private ReportResponseDTO responseDTO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        requestDTO = new ReportsRequestDTO();
        responseDTO = new ReportResponseDTO();
    }

    @Test
    void testGetSourceInformation_returnsExpectedResponse() {
        // Arrange
        when(sourceInformationService.getSourceInformation(requestDTO)).thenReturn(responseDTO);

        // Act
        ResponseEntity<ReportResponseDTO> responseEntity =
                sourceInformationApiController.getSourceInformation(requestDTO);

        // Assert
        assertNotNull(responseEntity);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(responseDTO, responseEntity.getBody());
        verify(sourceInformationService, times(1)).getSourceInformation(requestDTO);
    }
}
