package com.hireright.sourceintelligence.domain.entity;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FieldErrors {
    private String label;
    private String value;
}
