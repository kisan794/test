package hireright.applications.igniting_innovations.controller;

import hireright.applications.igniting_innovations.dto.FormFieldConfigRequest;
import hireright.applications.igniting_innovations.dto.FormFieldConfigResponse;
import hireright.applications.igniting_innovations.service.FormFieldConfigService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Controller for Form Field Configuration Management.
 * Provides endpoints for managing form field configurations stored in MongoDB.
 * These configurations are used to dynamically render form fields in the UI.
 *
 * @author Generated
 * @version 1.0
 */
@Tag(name = "Form Configuration", description = "APIs for managing form field configurations and metadata")
@Slf4j
@RestController
@RequestMapping("/api/v1/form-config")
@RequiredArgsConstructor
public class FormFieldConfigController {

    private final FormFieldConfigService formFieldConfigService;

    /**
     * Create a new form field configuration.
     */
    @Operation(
            summary = "Create form field configuration",
            description = "Create a new form field configuration with options for dropdowns, multi-selects, etc."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Configuration created successfully",
                    content = @Content(schema = @Schema(implementation = FormFieldConfigResponse.class))),
            @ApiResponse(responseCode = "400", description = "Invalid input data"),
            @ApiResponse(responseCode = "409", description = "Configuration already exists"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<FormFieldConfigResponse> createConfig(@Valid @RequestBody FormFieldConfigRequest request) {
        log.info("Received request to create form field configuration: {}", request.getFieldKey());
        FormFieldConfigResponse response = formFieldConfigService.createConfig(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * Update an existing form field configuration.
     */
    @Operation(
            summary = "Update form field configuration",
            description = "Update an existing form field configuration by field key."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Configuration updated successfully",
                    content = @Content(schema = @Schema(implementation = FormFieldConfigResponse.class))),
            @ApiResponse(responseCode = "404", description = "Configuration not found"),
            @ApiResponse(responseCode = "400", description = "Invalid input data")
    })
    @PutMapping(value = "/{fieldKey}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<FormFieldConfigResponse> updateConfig(@PathVariable String fieldKey, @Valid @RequestBody FormFieldConfigRequest request) {
        log.info("Received request to update form field configuration: {}", fieldKey);
        FormFieldConfigResponse response = formFieldConfigService.updateConfig(fieldKey, request);
        return ResponseEntity.ok(response);
    }

    /**
     * Get configuration by field key.
     */
    @Operation(
            summary = "Get configuration by field key",
            description = "Retrieve a specific form field configuration by its field key."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Configuration found",
                    content = @Content(schema = @Schema(implementation = FormFieldConfigResponse.class))),
            @ApiResponse(responseCode = "404", description = "Configuration not found")
    })
    @GetMapping("/{fieldKey}")
    public ResponseEntity<FormFieldConfigResponse> getConfigByFieldKey(@PathVariable String fieldKey) {
        log.info("Received request to get form field configuration: {}", fieldKey);
        FormFieldConfigResponse response = formFieldConfigService.getConfigByFieldKey(fieldKey);
        return ResponseEntity.ok(response);
    }

    /**
     * Get all form field configurations.
     */
    @Operation(
            summary = "Get all configurations",
            description = "Retrieve all form field configurations ordered by display order."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Configurations retrieved successfully")
    })
    @GetMapping
    public ResponseEntity<List<FormFieldConfigResponse>> getAllConfigs() {
        log.info("Received request to get all form field configurations");
        List<FormFieldConfigResponse> response = formFieldConfigService.getAllConfigs();
        return ResponseEntity.ok(response);
    }


    /**
     * Delete a configuration.
     */
    @Operation(
            summary = "Delete configuration",
            description = "Delete a form field configuration by field key."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Configuration deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Configuration not found")
    })
    @DeleteMapping("/{fieldKey}")
    public ResponseEntity<Void> deleteConfig(@PathVariable String fieldKey) {
        log.info("Received request to delete form field configuration: {}", fieldKey);
        formFieldConfigService.deleteConfig(fieldKey);
        return ResponseEntity.noContent().build();
    }
}
