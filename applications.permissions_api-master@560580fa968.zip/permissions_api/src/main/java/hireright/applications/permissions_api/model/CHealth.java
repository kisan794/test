package hireright.applications.permissions_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-16  HRG-330191 initial version
 */

import com.fasterxml.jackson.annotation.JsonProperty;

public class CHealth
{
	@JsonProperty("status")
	private EStatus m_status;

	private CHealth()
	{
	}

	public CHealth(EStatus status)
	{
		m_status = status;
	}

	public EStatus getStatus()
	{
		return m_status;
	}

	public enum EStatus
	{
		pass,
		fail
	}
}
