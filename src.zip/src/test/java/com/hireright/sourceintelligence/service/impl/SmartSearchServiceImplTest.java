package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.mapper.SourceDTOMapper;
import com.hireright.sourceintelligence.searchindex.entity.ElasticsearchSource;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import com.hireright.sourceintelligence.util.Helper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.data.mongodb.core.query.Criteria;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SmartSearchServiceImplTest {

    @InjectMocks
    private SmartSearchServiceImpl smartSearchService;

    @Mock
    private ElasticsearchService elasticsearchService;

    @Mock
    private DistanceAlgorithm distanceAlgorithm;

    @Mock
    private SourceDTOMapper sourceDTOMapper;

    @Mock
    private MongoSearchService mongoSearchService;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetSourceListBySearch_WithElasticsearchResults() {
        SmartSearchDTO dto = new SmartSearchDTO();
        dto.setName("Test Org");
        dto.setOrganizationType("EDUCATION");
        dto.setStartPage(1);

        String indexName = Helper.getIndexName("EDUCATION");
        Set<String> honIds = new HashSet<>(List.of("123", "456"));
        List<SourceDTO> expectedList = List.of(new SourceDTO(), new SourceDTO());

        when(elasticsearchService.smartSearch(any(), eq(indexName), nullable(Boolean.class))).thenReturn(honIds);
        when(mongoSearchService.getSmartSearchResponseByHonIds(anyMap(), eq(indexName), eq(honIds))).thenReturn(expectedList);

        SearchResponseDTO result = smartSearchService.getSourceListBySearch(dto);

        assertEquals(2, result.getTotalItems());
        assertEquals("SUCCESS", result.getStatus());

        verify(elasticsearchService).smartSearch(any(), eq(indexName), nullable(Boolean.class));
        verify(mongoSearchService).getSmartSearchResponseByHonIds(anyMap(), eq(indexName), eq(honIds));
    }

    @Test
    void testGetSourceListBySearch_TriggersMongoMapping() {
        SmartSearchDTO dto = new SmartSearchDTO();
        dto.setOrganizationType("EMPLOYMENT");
        dto.setStartPage(0);
        List<Source> sourceList = List.of(new Source(), new Source());

        SourceDTO sourceDTO1 = new SourceDTO();
        sourceDTO1.setOrganizationName("Org 1");

        SourceDTO sourceDTO2 = new SourceDTO();
        sourceDTO2.setOrganizationName("Org 2");

        List<SourceDTO> sourceDTOList = List.of(sourceDTO1, sourceDTO2);

        when(elasticsearchService.smartSearch(any(), any(), any())).thenReturn(Collections.emptySet());
        when(mongoSearchService.smartSearchExecution(any(Criteria.class), eq(dto))).thenReturn(sourceList);
        when(sourceDTOMapper.entityToSourceList(sourceList)).thenReturn(sourceDTOList);

        SearchResponseDTO result = smartSearchService.getSourceListBySearch(dto);

        assertNotNull(result);
        assertEquals(2, result.getTotalItems());
        assertEquals("SUCCESS", result.getStatus());
        assertEquals(2, result.getSearchList().size());

        verify(mongoSearchService).smartSearchExecution(any(Criteria.class), eq(dto));
        verify(sourceDTOMapper).entityToSourceList(sourceList);
    }


    @Test
    void testGetDropDownList() {
        String keyword = "Sample";
        String keywordLower = keyword.toLowerCase();
        OrganizationType orgType = OrganizationType.EMPLOYMENT;

        List<ElasticsearchSource> esList = List.of(new ElasticsearchSource(), new ElasticsearchSource());
        Set<String> matched = Set.of("Sample A", "Sample B");

        when(elasticsearchService.dropDownSearch(any(), any())).thenReturn(esList);
        when(distanceAlgorithm.jaroWinklerAlgorithmForDropDown(keywordLower, esList))
                .thenReturn(matched);

        List<AutocompleteSearchDTO> result =
                smartSearchService.getDropDownList(keyword, orgType, false, Map.of());

        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertEquals("organizationName", result.get(0).getCategory());
    }

    @Test
    void testGetSourceListBySearch_WithArchiveAndActiveFlags() {
        SmartSearchDTO dto = new SmartSearchDTO();
        dto.setOrganizationType("EDUCATION");
        dto.setIsArchive(true);
        dto.setStartPage(1);

        when(elasticsearchService.smartSearch(any(), any(), any())).thenReturn(Collections.emptySet());
        when(mongoSearchService.smartSearchExecution(any(Criteria.class), eq(dto))).thenReturn(Collections.emptyList());

        SearchResponseDTO result = smartSearchService.getSourceListBySearch(dto);

        assertEquals("SUCCESS", result.getStatus());
        assertEquals(0, result.getTotalItems());
    }

    @Test
    void testGetSourceListBySearch_WithWebAddressAndDepartment() {
        SmartSearchDTO dto = new SmartSearchDTO();
        dto.setName("Test Org");
        dto.setWebAddress("http://test.org");
        dto.setDepartment("HR");
        dto.setOrganizationType("EMPLOYMENT");
        dto.setStartPage(1);

        Set<String> honIds = Set.of("1");
        List<SourceDTO> list = List.of(new SourceDTO());

        when(elasticsearchService.smartSearch(any(), any(), any())).thenReturn(honIds);
        when(mongoSearchService.getSmartSearchResponseByHonIds(anyMap(), any(), any())).thenReturn(list);

        SearchResponseDTO result = smartSearchService.getSourceListBySearch(dto);

        assertEquals(1, result.getTotalItems());
        assertEquals("SUCCESS", result.getStatus());
    }

    @Test
    void testGetSourceListBySearch_WithFullAddressFields() {
        SmartSearchDTO dto = new SmartSearchDTO();
        dto.setCity("Los Angeles");
        dto.setState("CA");
        dto.setPostalCode("90001");
        dto.setCountry("US");
        dto.setOrganizationType("EDUCATION");
        dto.setStartPage(0);

        SourceDTO dto1 = new SourceDTO();
        dto1.setOrganizationName("Test Org");

        List<SourceDTO> dtoList = List.of(dto1);
        Set<String> honIds = Set.of("HON123");

        when(elasticsearchService.smartSearch(any(ElasticsearchDTO.class), anyString(), any()))
                .thenReturn(honIds);

        when(mongoSearchService.getSmartSearchResponseByHonIds(anyMap(), anyString(), eq(honIds)))
                .thenReturn(dtoList);

        SearchResponseDTO result = smartSearchService.getSourceListBySearch(dto);

        assertNotNull(result);
        assertEquals(1, result.getTotalItems());
        assertEquals("SUCCESS", result.getStatus());
        assertNotNull(result.getSearchList());
        assertEquals(1, result.getSearchList().size());
        assertEquals("Test Org", result.getSearchList().get(0).getOrganizationName());

        verify(elasticsearchService).smartSearch(any(ElasticsearchDTO.class), anyString(), any());
        verify(mongoSearchService).getSmartSearchResponseByHonIds(anyMap(), anyString(), eq(honIds));
    }



    @Test
    void testGetSourceListBySearch_WithContactFields() {
        SmartSearchDTO dto = new SmartSearchDTO();
        dto.setEmail("test@example.com");
        dto.setOnlineProvider("Certn");
        dto.setCode("CERT123");
        dto.setPhoneCountryCode("+1");
        dto.setPhoneAreaCode("310");
        dto.setPhoneNumber("5551234");
        dto.setPhoneExtension("99");

        dto.setFaxCountryCode("+1");
        dto.setFaxAreaCode("310");
        dto.setFaxNumber("5556789");
        dto.setFaxExtension("22");

        dto.setOrganizationType("EMPLOYMENT");
        dto.setStartPage(1);

        Set<String> honIds = Set.of("HON-456");
        List<SourceDTO> list = List.of(new SourceDTO());

        when(elasticsearchService.smartSearch(any(), any(), any())).thenReturn(honIds);
        when(mongoSearchService.getSmartSearchResponseByHonIds(anyMap(), any(), any())).thenReturn(list);

        SearchResponseDTO result = smartSearchService.getSourceListBySearch(dto);

        assertEquals(1, result.getTotalItems());
    }


    @Test
    void testGetDropDownList_EmptyResult() {
        when(elasticsearchService.dropDownSearch(any(), any())).thenReturn(Collections.emptyList());

        List<AutocompleteSearchDTO> result = smartSearchService.getDropDownList("keyword", OrganizationType.EMPLOYMENT, false, Map.of());

        assertTrue(result.isEmpty());
        verify(elasticsearchService).dropDownSearch(any(), any());
    }
}
