package com.hireright.sourceintelligence.domain.repository;

import com.hireright.sourceintelligence.domain.entity.Language;
import org.bson.types.ObjectId;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LanguageRepository extends MongoRepository<Language, ObjectId> {
    
    Page<Language> findAll(Pageable pageable);
}

