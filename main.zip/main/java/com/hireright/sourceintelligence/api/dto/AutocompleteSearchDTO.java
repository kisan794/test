package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.hireright.sourceintelligence.api.dto.history.SearchHistoryFilter;
import com.hireright.sourceintelligence.domain.entity.FieldValueInfo;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
//@JsonIgnoreProperties(ignoreUnknown = true)
//@JsonInclude(value = JsonInclude.Include.NON_EMPTY, content = JsonInclude.Include.NON_NULL)
public class AutocompleteSearchDTO {

  private String category;

  List<FieldValueInfo> matches;


  //private List<SearchOrganizationDTO> sources;

  private SearchHistoryFilter searchHistoryFilter;
}
