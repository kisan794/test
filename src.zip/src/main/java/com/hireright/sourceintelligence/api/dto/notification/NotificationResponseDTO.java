package com.hireright.sourceintelligence.api.dto.notification;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * Response DTO for notification operations
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NotificationResponseDTO {
    
    private String status;
    
    private String message;
    
    private String notificationId;
    
    private String requestId;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant sentAt;
    
    private Integer recipientCount;
    
    private String error;
    
    public static NotificationResponseDTO success(String notificationId, String requestId, int recipientCount) {
        return NotificationResponseDTO.builder()
                .status("SUCCESS")
                .message("Notification sent successfully")
                .notificationId(notificationId)
                .requestId(requestId)
                .sentAt(Instant.now())
                .recipientCount(recipientCount)
                .build();
    }
    
    public static NotificationResponseDTO failure(String requestId, String error) {
        return NotificationResponseDTO.builder()
                .status("FAILURE")
                .message("Failed to send notification")
                .requestId(requestId)
                .error(error)
                .sentAt(Instant.now())
                .build();
    }
}

