package hireright.applications.vendor_api.resources.listener;
/*
 * Copyright 2019 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2019-10-15  HIVPE-76880 initial version
 * S.Barinov  2019-11-22  HIVPE-105083 /ksks-in endpoint handler
 */

import hireright.lib.logging.data_exchange.logger.DataExchangeLoggerConsts;
import hireright.objects.is.CMessage;
import hireright.objects.is.CMessageManager;
import hireright.objects.is.CMessagePayload;
import hireright.sdk.db3.DB;
import hireright.sdk.debug.CDataExchangeLog;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.json.JSONObject;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class CKwikScreenListener
{
	private final CIsMessageProducer m_kwikScreenHandler;
	private final CIsMessageProducer m_nationalSearchHandler;

	public CKwikScreenListener()
	{
		m_kwikScreenHandler = new CIsMessageProducer("BASE", "KSKS-IN", "HR-KWIKSCREEN-KS/1.0",
			"KWIKSCREEN_KS_CALLBACK", "APPLICATION", "VENDOR_API");
		m_nationalSearchHandler = new CIsMessageProducer("BASE", "KSNS-IN", "HR-KWIKSCREEN-NS/1.0",
			"KWIKSCREEN_NS_CALLBACK", "APPLICATION", "VENDOR_API");
	}

	@RequestMapping(path = "/ksks-in", method = RequestMethod.POST,
		consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public String notifyKwikScreen(@RequestHeader("Content-Type") String sContentType,
		@RequestParam(name = "reference") String sReference,
		@RequestParam(name = "datasource") String sDatasource, @RequestBody String sPayload)
	{
		return m_kwikScreenHandler.handle("ks-kwikscreen-results", sDatasource, sReference,
			sContentType, sPayload);
	}

	@RequestMapping(path = "/ksns-in", method = RequestMethod.POST,
		consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public String notifyNationalSearch(@RequestHeader("Content-Type") String sContentType,
		@RequestParam(name = "reference") String sReference, @RequestBody String sPayload)
	{
		return m_nationalSearchHandler.handle("ks-ns-results", null, sReference, sContentType,
			sPayload);
	}

	private static class CIsMessageProducer
	{
		private final String m_sDomainID;
		private final String m_sAdapterID;

		private final String m_ldeProtocol;
		private final String m_ldeRecipientName;
		private final String m_ldeRecipientClass;
		private final String m_ldeRecipientID;

		private CIsMessageProducer(String sDomainID, String sAdapterID, String ldeProtocol,
			String ldeRecipientName, String ldeRecipientClass, String ldeRecipientID)
		{
			m_sDomainID = sDomainID;
			m_sAdapterID = sAdapterID;
			m_ldeProtocol = ldeProtocol;
			m_ldeRecipientName = ldeRecipientName;
			m_ldeRecipientClass = ldeRecipientClass;
			m_ldeRecipientID = ldeRecipientID;
		}

		private String handle(String sAction, String sDatasource, String sReference,
			String sContentType, String sPayload)
		{
			CProperties ldeParameters = new CProperties();
			ldeParameters.setProperty("reference", sReference);

			String sTransactionID = null;

			try
			{
				sTransactionID = new JSONObject(sPayload).optString("CompanyTransactionId");
			}
			catch(Exception ignored)
			{
			}

			if(CStringUtils.isEmpty(sTransactionID))
			{
				sTransactionID =
					DataExchangeLoggerConsts.TRANSACTION_ID_REFERENCE_GENERATOR.generateReference(
						null);

				CTraceLog.warning(
					"Transaction ID is missing in request payload so a new one is created: "
						+ sTransactionID, this.getClass().getName() + ".notify()", ldeParameters);
			}

			Element ldePayload = DocumentHelper.createElement("Response");
			ldePayload.addAttribute("contentType", "application/json");
			ldePayload.addCDATA(sPayload);

			CDataExchangeLog.addInLog(sTransactionID, m_ldeRecipientName, m_ldeRecipientClass,
				m_ldeRecipientID, m_ldeProtocol, ldeParameters.toString(), ldePayload.asXML());

			CMessage message = new CMessage();

			message.setAdapterID(m_sAdapterID);
			message.setDomainID(m_sDomainID);
			message.setSubject("KwikScreen callback: " + sReference);

			CProperties properties = message.getProperties();
			properties.setProperties(ldeParameters);
			properties.setProperty("transactionID", sTransactionID);
			properties.setProperty("action", sAction);
			properties.setProperty("datasource", sDatasource);
			message.setProperties(properties);

			CMessagePayload payload = new CMessagePayload();
			payload.setContentType(sContentType);
			payload.setPayloadClob(sPayload);
			message.addPayload(payload);

			try
			{
				new DB.Call<Boolean>()
				{
					@Override
					protected Boolean call()
					{
						return CMessageManager.create(message);
					}
				}.execute();
			}
			catch(Exception e)
			{
				CTraceLog.error(e);
				return "{\"Id\": \"" + sTransactionID + "\", \"Status\": \"Error\"}";
			}

			ldeParameters.setProperty("messageID", message.getID());

			CDataExchangeLog.addOutLog(sTransactionID, m_ldeRecipientName, m_ldeRecipientClass,
				m_ldeRecipientID, m_ldeProtocol, ldeParameters.toString(), null);

			return "{\"Id\": \"" + sTransactionID + "\", \"Status\": \"OK\"}";
		}
	}
}
