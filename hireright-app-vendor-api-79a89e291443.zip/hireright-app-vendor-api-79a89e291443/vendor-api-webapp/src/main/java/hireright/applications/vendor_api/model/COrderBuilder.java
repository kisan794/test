package hireright.applications.vendor_api.model;
/*
 *
 * Copyright 2001-2019 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	2019-01-21	Created as copy of sdk_order COrderBuilder
 *	A.Logachyov	2019-01-22	Updated buildCriminalService to use bdk_order_composer
 *	A.Logachyov	2019-05-31	Fixed unicode sanitizing
 *	A.Logachyov	2021-03-31	Added customer and user to created applicant record
 * 	V.Tsetsnev	2021-10-19	HRG-174238 Added support for Military service
 * 	A.Khmurchyk	2022-01-11	HRG-186111 Routing Issue - US request not created from UK instance due to error
 * 	Zaporozhets	2022-08-05	HRG-207384 Employment - Routing: enroll additional questions in scope of routing scenario
 *	A.Khmurchik 2023.04.28	HRG-40930: SGP - UK: Route Professional References from US to UK and vice versa
 *      H.Maibak	2025-09-12	PRC-406: Added case for crmFm rapid in buildService()
 */

import java.io.ByteArrayInputStream;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import hireright.objects.order.CMilitaryService;
import hireright.objects.order.CReferenceService;
import hireright.objects.order2.service.military.CMilitaryInquiry;
import hireright.objects.order2.service.reference_check.CPersonal;
import hireright.objects.order2.service.reference_check.CPersonalDetail;
import hireright.objects.order2.service.reference_check.CPersonalDetailId;
import hireright.objects.order3.model.military.CMilitary;
import hireright.objects.order3.model.prcr.CProfessionalReference;
import hireright.objects.order3.model.prcr.CProfessionalReferenceWrapper;
import hireright.sdk.db2.CSessionFactory;
import hireright.sdk.xml.serialization.deserializer.jakarta.CXMLDeserializer;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.lang3.EnumUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;

import hireright.frameworks.spinoff.data.LocationMultiplicity;
import hireright.objects.address.CCounty;
import hireright.objects.address.CCountyResolver;
import hireright.objects.applicant.CApplicant;
import hireright.objects.applicant.properties.CApplicantProperties;
import hireright.objects.application.CApplication;
import hireright.objects.application.CApplicationOrder;
import hireright.objects.application.CApplicationTemplateRecord;
import hireright.objects.application.CApplicationTemplateUtils;
import hireright.objects.application.CFormCodeGenerator;
import hireright.objects.application.fields.CFApplication;
import hireright.objects.objects.CCountries;
import hireright.objects.objects.CCountry;
import hireright.objects.objects.CCountryRegion;
import hireright.objects.objects.CCountryRegions;
import hireright.objects.objects.CObjectReference;
import hireright.objects.order.CAbstractService;
import hireright.objects.order.CEducationService;
import hireright.objects.order.CEmploymentService;
import hireright.objects.order.CGenericService;
import hireright.objects.order.CLicenseService;
import hireright.objects.order.CMvrService;
import hireright.objects.order.COneClickService;
import hireright.objects.order.COrder;
import hireright.objects.order.COrderDefinition;
import hireright.objects.order.COrderException;
import hireright.objects.order.COrderServiceException;
import hireright.objects.order.COrderingAddress;
import hireright.objects.order.CUnorderedService;
import hireright.objects.order.criminal.CCourtDivision;
import hireright.objects.order.criminal.CCourtFactory;
import hireright.objects.order.job_location.COrderJobLocation;
import hireright.objects.order2.COrderService;
import hireright.objects.order2.COrderServiceManager;
import hireright.objects.order2.service.education.CEducationQualification;
import hireright.objects.order2.service.employment.CReason;
import hireright.objects.order3.model.CContactInfo;
import hireright.objects.order3.model.CContactMethod;
import hireright.objects.order3.model.CDeliveryAddress;
import hireright.objects.order3.model.CDemographicDetail;
import hireright.objects.order3.model.CFlexibleDate;
import hireright.objects.order3.model.CGovernmentID;
import hireright.objects.order3.model.CNameValue;
import hireright.objects.order3.model.COrderConfiguration;
import hireright.objects.order3.model.CPayment;
import hireright.objects.order3.model.CPersonName;
import hireright.objects.order3.model.CPersonalData;
import hireright.objects.order3.model.CPhoneNumber;
import hireright.objects.order3.model.CPostalAddress;
import hireright.objects.order3.model.CPriorPersonalData;
import hireright.objects.order3.model.CQuestion;
import hireright.objects.order3.model.CScreening;
import hireright.objects.order3.model.CSearchDepth;
import hireright.objects.order3.model.education.CDatesOfAttendance;
import hireright.objects.order3.model.education.CDegree;
import hireright.objects.order3.model.education.CDegreeMajor;
import hireright.objects.order3.model.education.CDegreeMeasure;
import hireright.objects.order3.model.education.CEducation;
import hireright.objects.order3.model.education.CSchool;
import hireright.objects.order3.model.employment.CEmployerOrgName;
import hireright.objects.order3.model.employment.CEmployment;
import hireright.objects.order3.model.employment.CPositionCompensation;
import hireright.objects.order3.model.employment.CPositionHistory;
import hireright.objects.order3.model.employment.CPositionVerification;
import hireright.objects.order3.model.generic.CGeneric;
import hireright.objects.order3.model.license.CLicense;
import hireright.objects.pack.COrderTemplate;
import hireright.objects.pack.CVerificationSubject;
import hireright.objects.person.CObjectPersonName;
import hireright.objects.person.CObjectPersonNameManager;
import hireright.objects.person.CPersonNameManager;
import hireright.objects.source_intl.CCDBOrgUnit;
import hireright.objects.users.CCustomer;
import hireright.objects.users.CCustomerProperties;
import hireright.objects.users.CCustomerUser;
import hireright.objects.utilities.CAddress;
import hireright.objects.utilities.CDomain;
import hireright.order_composer.data.COrderServiceQuestion;
import hireright.order_composer.data.COrderServiceQuestionGroup;
import hireright.order_composer.data.dao.impl.COrderServiceDao;
import hireright.order_composer.data.dao.impl.COrderServiceQuestionGroupDao;
import hireright.order_composer.service.impl.CCriminalService;
import hireright.sdk.db.CSequence;
import hireright.sdk.db3.DB;
import hireright.sdk.format_util.CFPhone;
import hireright.sdk.util.CArrays;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.CStringSanitizerFactory;
import hireright.sdk.util.CStringUtils;
import hireright.sdk.util.IStringSanitizer;
import hireright.utils.consts.HrConstants;

public class COrderBuilder
{
	private static final int DEFAULT_APPLICATION_TYPE = 9;
	private static final int OA_APPLICATION_DEFAULT_PAGE = 0;
	private static final int OA_APPLICATION_STATE_MACHINE_ID = 14;

	private static final String OA_APPLICATION_STATE_ORDERED = "ORDERED";
	private static final String REGEXP_SIMPLE_YYYY_MM_DD = "\\d{4}-\\d{2}-\\d{2}";
	private static final String REF_ID_ORG_UNIT_HON = "OrgUnitHON";
	private static final String MEASURE_SYSTEM_GPA = "GPA";
	
	private static final String QUESTION_SET_TYPE = "COMMON";

	private final Map<String, String> regionMap;

	private final CCustomerUser m_user;
	private final CCustomer m_customer;
	private final CDomain m_domain;
	private final IStringSanitizer m_sanitizer;

	public COrderBuilder(CDomain domain, CCustomer customer, CCustomerUser user)
	{
		m_user = user;
		m_customer = customer;
		m_domain = domain;
		
		m_sanitizer = CStringSanitizerFactory.get();
		
		regionMap = new HashMap<>();
		regionMap.put("LEVEL1_REGION", "REGION1");
		regionMap.put("LEVEL2_REGION", "REGION2");
	}

	private String sanitize(String sValue)
	{
		return m_sanitizer.replace(sValue);
	}
	
	public CCustomerUser getCustomerUser()
	{
		return this.m_user;
	}

	public CCustomer getCustomer()
	{
		return this.m_customer;
	}

	public CDomain getDomain()
	{
		return this.m_domain;
	}

	public COrder buildOrder(COrderConfiguration request)
			throws COrderException, COrderServiceException
	{
		return buildOrder(request, false);
	}

	public COrder buildOrder(COrderConfiguration request, boolean bCreateApplicationOrder)
		throws COrderException, COrderServiceException
	{
		try
		{
			CPersonalData personalData = request.getPersonalData();
			COrderDefinition orderDefinition = COrderDefinition.loadOrderDefinition(getCustomer());
			CCustomerUser user = getCustomerUser();
			orderDefinition.create(user.getID(), null);
			
			CApplicant applicant = buildApplicant(personalData);
			
			CAddress currentAddress = buildCurrentAddress(personalData);
			applicant.createAddress(currentAddress);
			
			COrder order = new COrder(user.getID(), applicant,
					(COrderTemplate) null, // orderTemplate
					orderDefinition,
					(COrder.Initiator) null); // only used for extend
			
			if (CStringUtils.isNotEmpty(applicant.getDob()))
			{
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				df.setLenient(false);
				order.setDOB(df.parse(applicant.getDob()));
			}
			
			order.setDOBType(0);
			
			order.setDomainID(getDomain().getDomainID());
			order.setApplicantAddress(currentAddress);
			
			CPostalAddress organizationPostalAddress = request.getOrganization() != null &&
				request.getOrganization().getJobLocation() != null &&
				request.getOrganization().getJobLocation().getPostalAddress() != null ?
				request.getOrganization().getJobLocation().getPostalAddress() : null;

			if (organizationPostalAddress != null)
			{
					hireright.objects.address.CPostalAddress jobLocAddress = new hireright.objects.address.CPostalAddress();
					jobLocAddress.setCountryCode(organizationPostalAddress.getCountryCode());
					jobLocAddress.setRegion1(sanitize(organizationPostalAddress.getRegion()));
					jobLocAddress.setRegion1National(organizationPostalAddress.getRegion());
					jobLocAddress.setRegion2(sanitize(organizationPostalAddress.getCounty()));
					jobLocAddress.setRegion2National(organizationPostalAddress.getCounty());
					jobLocAddress.setMunicipality(sanitize(organizationPostalAddress.getMunicipality()));
					jobLocAddress.setMunicipalityNational(organizationPostalAddress.getMunicipality());
					jobLocAddress.setPostalCode(sanitize(organizationPostalAddress.getPostalCode()));
					jobLocAddress.setPostalCodeNational(organizationPostalAddress.getPostalCode());
					String addressLine = "";
					if (organizationPostalAddress.getDeliveryAddress() != null) {
							for(String line : organizationPostalAddress.getDeliveryAddress().getAddressLines()) {
									addressLine = addressLine + line + " ";
							}
					}
					jobLocAddress.setAddressLine(sanitize(addressLine));
					jobLocAddress.setAddressLineNational(addressLine);
					COrderJobLocation.update(order, jobLocAddress);
			}

			if (!order.create())
			{
				throw new CRuntimeException("Order create error.", request.toProperties());
			}
			
			if (bCreateApplicationOrder)
			{
				Integer nApplicationId = buildApplicationEntry(applicant);
				buildApplicationOrder(nApplicationId, order.getID());
			}
			
			CPriorPersonalData priorPersonalData = request.getPriorPersonalData();
			if (priorPersonalData != null)
			{
				setPriorPersonalData(order, priorPersonalData);
			}
			
			order.getServices(); // inits internal services list, otherwise addService throws NPE
			
			List<CScreening> screenings = request.getScreenings();
			for (CScreening screening : screenings)
			{
				CAbstractService service = buildService(order, screening);
				if (service == null)
				{
					throw new CRuntimeException("Unsupported service: " + screening.getServiceID(), request.toProperties());
				}
				
				order.addService(service);
			}
			
			for (CNameValue nameValue : CArrays.nvl(request.getClientReferences()))
			{
				order.savePropertyToDB(nameValue.getName(), nameValue.getValue());
			}

			for (CNameValue nameValue : CArrays.nvl(request.getApplicantReferences()))
			{
				order.savePropertyToDB(nameValue.getName(), nameValue.getValue());
			}

			order.createSubrequests();
			
			List<Long> orderServiceIDs = COrderServiceManager.getOrderServiceIDs(order.getID());
			if(orderServiceIDs.size() == 1)
			{
				for (CScreening screening : screenings)
				{			
					if ( screening != null)
					{
						addQuestions(screening, orderServiceIDs.get(0));
						addPersonalDetails(screening, order, orderServiceIDs.get(0));
					}
				}
			}
			
			updateServicesNamesTransliteration(order.getServicesResultsList(), applicant.getID());
			
			List<CUnorderedService> unordered = order.getUnorderedServices();
			if (unordered != null && !unordered.isEmpty())
			{
				CUnorderedService unorderedService = unordered.get(0);
				COrderServiceException ex = unorderedService.getReason();
				if (ex != null)
				{
					throw ex;
				}
				
				throw new CRuntimeException("Service not ordered: " + unorderedService.getService().getName());
			}
			
			order.submit();
			
			return order;
		}
		catch (ParseException ex)
		{
			throw new COrderException(ex.getMessage(),
					ex,
					getClass().getName() + ".buildOrder",
					-1, request.toProperties());
		}
		catch (SQLException ex)
		{
			throw new COrderException(ex.getMessage(),
					ex,
					getClass().getName() + ".buildOrder",
					COrderException.EX_PLSQL_CODE_EXECUTION_FAILED, request.toProperties());
		}
	}
	
	private void addPersonalDetails(CScreening screening, COrder order, Long orderServiceId)
	{
		if (Integer.valueOf(CReferenceService.VERIFICATION_SUBJECT_ID).equals(screening.getServiceID()))
		{
			CProfessionalReference professionalReference = deserializeProfessionalReference(screening);
			CProfessionalReference.CReference reference = professionalReference.getReference();
			
			CPersonal personal = CPersonal.load(orderServiceId);
			
			for(CProfessionalReference.CPersonalDetail pd : reference.getPersonalDetails())
			{
				CPersonalDetailId personalDetailId = new CPersonalDetailId(
						order.getOrderID(),
						personal.getPersonalID(),
						pd.getId()
				);
				
				CPersonalDetail personalDetail = new CPersonalDetail(personalDetailId, personal);
				personalDetail.setQuestion(pd.getQuestion());
				personalDetail.setAnswer(pd.getAnswer());
				
				CSessionFactory.getSessionFactory().getCurrentSession().save(personalDetail);
			}
		}
	}


	private CProfessionalReference deserializeProfessionalReference(CScreening screening)
	{
		CProfessionalReferenceWrapper professionalReferenceWrapper = screening.getRecordInstance();
		CXMLDeserializer<CProfessionalReference> deserializer = new CXMLDeserializer<>(CProfessionalReference.class);
		
		try
		{
			ByteArrayInputStream in = new ByteArrayInputStream(
					tryToDecodeBase64(CStringUtils.trim(professionalReferenceWrapper.getInquiry())).getBytes());
			return deserializer.deserialize(in);
		}
		catch (Exception ex)
		{
			throw new CRuntimeException("Failed to deserialize professional reference", ex);
		}
	}
	
	/**
	 * @param screening
	 */
	private void addQuestions(CScreening screening, Long orderServiceId) {
		
		List<CQuestion> questions = screening.getQuestions();
		if(questions != null && !questions.isEmpty())
		{
			CVerificationSubject vs = CVerificationSubject.loadVerificationSubject(screening.getServiceID());
			
			COrderServiceQuestionGroup osqg = new COrderServiceQuestionGroup(vs.getName(), orderServiceId, -1L, QUESTION_SET_TYPE);
			
			new COrderServiceQuestionGroupDao().saveOrUpdate(osqg);
			
			for (CQuestion question : questions)
			{
				COrderServiceQuestion orderServiceQuestion = new COrderServiceQuestion(Integer.parseInt(question.getSortOrder()), question.getQuestion(), question.getAnswer(), osqg);
				
				DB.session().save(orderServiceQuestion);
			}
		}
	}

	private CApplicant buildApplicant(CPersonalData personalData)
	{
		CPersonName name = personalData.getPersonName();
		CApplicant applicant = new CApplicant();
		applicant.setCustomerID(getCustomer().getCustomerID());
		applicant.setCustomerUserID(getCustomerUser().getCustomerUserID());
		applicant.setFirstName(sanitize(name.getGivenName()));
		applicant.setLastName(sanitize(name.getFamilyName()));
		applicant.setMiddleName(sanitize(name.getMiddleName()));
		applicant.setNationalFirstName(name.getNationalGivenName());
		applicant.setNationalMiddleName(name.getNationalMiddleName());
		applicant.setNationalLastName(name.getNationalFamilyName());

		hireright.objects.person.CPersonName personName = new hireright.objects.person.CPersonName(
				name.getNationalGivenName(),
				name.getNationalFamilyName(),
				name.getNationalMiddleName(),
				hireright.objects.person.CPersonName.TYPE_CURRENT);
		
		applicant.setPersonName(personName);
		
		CDemographicDetail demoDetail = personalData.getDemographicDetail();
		if (demoDetail != null)
		{
			List<CGovernmentID> govIDs = demoDetail.getGovernmentIDs();
			if (govIDs != null && !govIDs.isEmpty())
			{
				CGovernmentID govID = govIDs.get(0);
				String sGovIDCountryCode = govID.getCountryCode();
				
				if (sGovIDCountryCode !=null && sGovIDCountryCode.length() == 2)
				{
					sGovIDCountryCode = CCountries.countryCodeA2toA3(sGovIDCountryCode);
				}
				
				applicant.setCurrentGovernmentID(govID.getNumber(), sGovIDCountryCode);
			}
			
			String sDOB = demoDetail.getDateOfBirth();
			
			if (!CStringUtils.isEmpty(sDOB) && sDOB.matches(REGEXP_SIMPLE_YYYY_MM_DD))
			{
				applicant.setDob(sDOB);
			}
		}
		applicant.create();
		
		return applicant;
	}

	private Integer buildApplicationEntry(CApplicant applicant)
	{
		Integer nAppType = DEFAULT_APPLICATION_TYPE;
		
		Integer nTemplateID = getApplicationTemplateID(getCustomer(), nAppType);
		if (nTemplateID == null)
		{
			throw new CRuntimeException("Could not deterime application template id.",
				new CProperties()
					.setProperty("customerID", getCustomer().getID())
					.setProperty("applicationType", nAppType)
			);
		}
		
		Date now = new Date();
		Integer nID = CSequence.nextValue(CFApplication.SQ_TABLE_ID);
		CFApplication tApplication = new CFApplication();
		
		tApplication.setInteger(CFApplication.FIELD_ID, nID);
		tApplication.setInteger(CFApplication.FIELD_CUSTOMER_ID, getCustomer().getID());
		tApplication.setInteger(CFApplication.FIELD_CUSTOMER_USER_ID, getCustomerUser().getID());
		tApplication.setInteger(CFApplication.FIELD_APPLICANT_ID, applicant.getID());
		tApplication.setInteger(CFApplication.FIELD_TEMPLATE_ID, nTemplateID);
		tApplication.setDate(CFApplication.FIELD_INITIATED_DTTM, now);
		tApplication.setDate(CFApplication.FIELD_STATE_DTTM, now);
		tApplication.setInteger(CFApplication.FIELD_SM_STATE_MACHINE_ID, OA_APPLICATION_STATE_MACHINE_ID);
		tApplication.setString(CFApplication.FIELD_STATE, OA_APPLICATION_STATE_ORDERED);
		tApplication.setInteger(CFApplication.FIELD_ACTIVE_PAGE, OA_APPLICATION_DEFAULT_PAGE);
		
        CFormCodeGenerator formCodeGen = new CFormCodeGenerator(CApplication.DEFAULT_FORM_CODE_PREFIX);
        tApplication.setString(CFApplication.FIELD_FORM_CODE, formCodeGen.generateFormCode(nID));
		
		tApplication.insert();
		
		return nID;
	}

	public Integer getApplicationTemplateID(
			CCustomer customer,
			Integer nApplicationType)
	{
		// Copied from form_engine_core/CApplicationTemplateActions.getApplicationTemplateID()
		List<Integer> templates = CApplicationTemplateUtils.getApplicationTemplates(
				customer.getID(), nApplicationType);
		if (!templates.isEmpty() && templates.size() == 1)
		{
			return templates.get(0);
		}
		
		String sWorkFlow = CCustomerProperties.ACCOUNT_TYPE_SMALL_BUSINESS
			.equals(customer.getProperties().getAccountType())
				? "SMALL_BUSINESS"
				: "DOMESTIC";
		
		Iterator<Integer>  iter = templates.iterator();
		Integer nRetTemplateID = null;
		
		while (iter.hasNext())
		{
			Integer nTemplateID = iter.next();
			
			if (checkApplicationTemplateExists(nTemplateID, sWorkFlow))
			{
				if (nRetTemplateID != null)
				{
					throw new CRuntimeException(
						"Customer has more than one template granted with same order flow (" + sWorkFlow + "). " +
						"Must be only one template granted. Please check system configuration.");
				}
				
				nRetTemplateID = nTemplateID;
			}
		}
		
		return nRetTemplateID;
	}

	private void updateServicesNamesTransliteration(List<CAbstractService> services, Integer nApplicantID)
	{
		String sLanguage = CApplicantProperties.getPersonalInfoLocaleLanguage(nApplicantID);

		for (CAbstractService service : services)
		{
			Long lOrderServiceID = service.getOrderServiceID();
			
			if(lOrderServiceID != null)
			{
				List<CObjectPersonName> arrObjPersNames = CObjectPersonNameManager.load(
						new CObjectReference(COrderService.OBJECT_CLASS, String.valueOf(lOrderServiceID)));
				
				for(CObjectPersonName objPersName:arrObjPersNames)
				{
					hireright.objects.person.CPersonName personName = objPersName.getPersonName();
					CPersonNameManager.saveTransliterationForObject(COrderService.OBJECT_CLASS,
						String.valueOf(lOrderServiceID),
						sLanguage, personName);
				}
			}
		}
	}
	
	private boolean checkApplicationTemplateExists(
		Integer nTemplateID, String sWorkFlow)
	{
		return new CApplicationTemplateRecord(null)
			.load(nTemplateID, sWorkFlow, true);
	}

	private CApplicationOrder buildApplicationOrder(Integer nApplicationID, Long nOrderID)
	{
		CApplicationOrder applicationOrder = new CApplicationOrder(
			nApplicationID,
			nOrderID,
			CApplicationOrder.DIRECTION_ORDER_TO_APPLICATION);
		applicationOrder.create();
		return applicationOrder;
	}

	private CAddress buildCurrentAddress(CPersonalData personalData)
	{
		CPostalAddress addr = personalData.getPostalAddress();
		CContactMethod contactMethod = personalData.getContactMethod();
		if (addr == null && contactMethod == null)
		{
			return null;
		}
		
		CAddress currentAddress = new CAddress();
		if (addr != null)
		{
			populateAddress(currentAddress, addr);
		}
		
		if (contactMethod != null)
		{
			CPhoneNumber phoneNumber = contactMethod.getTelephone();
			if (phoneNumber != null && CStringUtils.isNotEmpty(phoneNumber.getNumber()))
			{
				CFPhone phone = new CFPhone(phoneNumber.getNumber());
				currentAddress.setPhone(phone);
			}
			
			CPhoneNumber cellPhoneNumber = contactMethod.getMobile();
			if (cellPhoneNumber != null && CStringUtils.isNotEmpty(cellPhoneNumber.getNumber()))
			{
				CFPhone phone = new CFPhone(cellPhoneNumber.getNumber());
				currentAddress.setCellPhone(phone);
			}
			
			currentAddress.setEMail(contactMethod.getEmail());
			currentAddress.setWWWAddress(contactMethod.getWeb());
		}
		currentAddress.create();
		
		return currentAddress;
	}

	private void populateAddress(CAddress address, CPostalAddress data)
	{
		if (data == null)
		{
			return;
		}
		
		Integer nCountryID = CCountries.findCountry(data.getCountryCode());
		address.setCountryID(nCountryID);
		address.setCounty(sanitize(data.getCounty()));
		address.setCity(sanitize(data.getMunicipality()));
		address.setNCity(data.getMunicipality());
		address.setZip(sanitize(data.getPostalCode()));

		CDeliveryAddress deliv = data.getDeliveryAddress();
		
		if (deliv != null && (!CStringUtils.isEmpty(deliv.getStreet()) || deliv.getAddressLines() != null))
		{
			String street = CStringUtils.nvl(deliv.getStreet(), String.join(", ", deliv.getAddressLines()));
			address.setStreet(sanitize(street));
			address.setNStreet(street);
		}
		
		if (CStringUtils.isNotEmpty(data.getRegion()))
		{
			String regionName = data.getRegion();
			if (CCountry.USA_COUNTRY_ID.equals(nCountryID))
			{
				CCountryRegion region = CCountryRegions.getUsaState(data.getRegion());
				if (region != null)
				{
					address.setStateID(region.getStateID());
					regionName = region.getRegionName();
				}
			}
			else
			{
				CCountryRegion region = CCountryRegions.findRegion(nCountryID, regionName);

				if (region == null && NumberUtils.isDigits(data.getRegion()))
				{
					Integer nRegionID = Integer.valueOf(data.getRegion());
					address.setRegionID(nRegionID);
				}
				else if (region != null)
				{
					address.setRegionID(region.getRegionID());
					regionName = region.getRegionName();
					address.setProvince(sanitize(regionName));
				}
				else
				{
					address.setProvince(sanitize(data.getRegion()));
					regionName = data.getRegion();
				}
			}

			address.setProvince(sanitize(regionName));
			address.setNProvince(regionName);
		}
	}

	private void setPriorPersonalData(COrder order, CPriorPersonalData data)
	{
		List<CPersonName> names = data.getPersonNames();
		for (CPersonName name : CArrays.nvl(names))
		{
			hireright.objects.person.CPersonName personName = new hireright.objects.person.CPersonName();
			personName.setFirstName(sanitize(name.getGivenName()));
			personName.setMiddleName(sanitize(name.getMiddleName()));
			personName.setLastName(sanitize(name.getFamilyName()));
			personName.setNameSource(name.getSource());
			personName.setNationalFirstName(name.getNationalGivenName());
			personName.setNationalMiddleName(name.getNationalMiddleName());
			personName.setNationalLastName(name.getNationalFamilyName());
			personName.setType(name.getType());
			personName.setValidFromTdate(name.getValidFrom());
			personName.setValidToTdate(name.getValidTo());
			personName.setProvidedBy(name.getProvidedBy());
			personName.save();
			
			CObjectPersonName objectPersonName =
					new CObjectPersonName(personName, order.getObjectClass(), order.getID().toString());
			
			objectPersonName.setPersonNameType(personName.getType());
			objectPersonName.save();
		}
	}

	private CAbstractService buildService(COrder order, CScreening screening)
	{
		CAbstractService service = null;
		
		CAddress address = new CAddress();
		CPostalAddress postalAddress = screening.getPostalAddress();
		populateAddress(address, postalAddress);
		
		COrderingAddress orderAddress = new COrderingAddress(address);
		CPersonName personName = screening.getPersonName();
		if (personName != null)
		{
			orderAddress.setNameSource(personName.getSource());
			orderAddress.setFirstNameAtAddress(personName.getGivenName());
			orderAddress.setLastNameAtAddress(personName.getFamilyName());
			orderAddress.setMiddleNameAtAddress(personName.getMiddleName());
		}
		
		if (postalAddress != null)
		{
			orderAddress.setAddressType(
					COrderingAddress.getTypeForStringType(postalAddress.getType()));
					orderAddress.setAddressSource(postalAddress.getLocationSource());
		}
		
		CVerificationSubject vs = null;
		if (screening.getServiceID() != null)
		{
			vs = CVerificationSubject.loadVerificationSubject(screening.getServiceID());
		}
		else if (CStringUtils.isNotEmpty(screening.getQualifier()))
		{
			// or use service reference?
			//CServiceReferenceFactory.getServiceReference(sRefGroup, sReference);
			
			String sServiceName = screening.getQualifier().substring("x:".length());
			if (CStringUtils.isNotEmpty(sServiceName))
			{
				vs = CVerificationSubject.loadVerificationSubject(sServiceName);
			}
			
		}
		
		if (vs != null)
		{
			switch (vs.getId().intValue())
			{
				case HrConstants.crec_crm_fl_ms_rapid_vsid:
				case HrConstants.crec_crm_fl_ms_vsid:
				case HrConstants.crec_cvl_up_lo_vsid:
				case HrConstants.crec_crm_fedrl_vsid:
				case HrConstants.crec_crm_fednl_vsid:
				case HrConstants.crec_statewide_vsid:
				case HrConstants.crec_health_statewide_vsid:
				case HrConstants.crec_nationwide_vsid:
				case HrConstants.crec_crm_felny_vsid:
				case HrConstants.crec_crm_misdm_vsid:
				case HrConstants.crec_cvl_upper_vsid:
				case HrConstants.crec_cvl_lower_vsid:
				case HrConstants.crec_cvl_fedrl_vsid:
				case HrConstants.crec_bnk_fedrl_vsid:
				{
					service = buildCriminalService(vs, order, orderAddress, screening);
					break;
				}
				case CEducationService.EDUCATION_STANDARD_SERVICE_ID:
				case CEducationService.EDUCATION_PLUS_SERVICE_ID:
				case CEducationService.EDUCATION_BASIC_SERVICE_ID:
				case CEducationService.EDUCATION_PREMIUM_SERVICE_ID:
				{
					service = buildEducationService(vs, order, orderAddress, screening);
					break;
				}
				case HrConstants.health_empl_vsid:
				case HrConstants.dot_compl3y_vsid:
				case HrConstants.dot_drug3y_vsid:
				case CEmploymentService.DOT_COMPLIANCE2_SERVICE_ID:
				case CEmploymentService.DOT_DRUG_ALCOHOL2_SERVICE_ID:
				case CEmploymentService.DOT_COMPLIANCE_FPU_SERVICE_ID:
				case CEmploymentService.DOT_DRUG_ALCOHOL_FPU_SERVICE_ID:
				case CEmploymentService.EMPLOYMENT_STANDARD_SERVICE_ID:
				case CEmploymentService.EMPLOYMENT_PLUS_SERVICE_ID:
				case CEmploymentService.EMPLOYMENT_BASIC_SERVICE_ID:
				case CEmploymentService.EMPLOYMENT_PREMIUM_SERVICE_ID:
				case CEmploymentService.EMPLOYMENT_CT:
				case CEmploymentService.DOT_PREEMPLOYMENT_SERVICE_ID:
				case CEmploymentService.DOT_PREEMPLOYMENT2_SERVICE_ID:
				case CEmploymentService.EMPLOYMENT_CURRENT_SERVICE_ID:
				case CEmploymentService.EMPLOYMENT_REGULATED_ID:
				{
					service = buildEmploymentService(vs, order, orderAddress, screening);
					break;
				}
				case HrConstants.plic_vsid:
				{
					service = buildProfessionalLicensesService(vs, order, orderAddress, screening);
					break;
				}
				case HrConstants.dmvr_vsid:
				{
					service = buildMVRService(vs, order, orderAddress, screening);
					break;
				}
				case CMilitaryService.VERIFICATION_SUBJECT_ID:
				{
					service = buildMilitaryService(vs, screening);
					break;
				}
				case CReferenceService.VERIFICATION_SUBJECT_ID:
				{
					service = buildProfessionalReferenceService(vs, order, screening);
					break;
				}
				default:
					if (vs.isGenericProduct())
					{
						service = buildGenericService(vs, order, orderAddress, screening);
					}
					else if (vs.isOneClickService())
					{
						service = buildOneClickService(vs, order, screening);
					}
					else
					{
						// at the moment: Workers Compensation Report, Fingerprinting
						throw new IllegalArgumentException("Unsupported service " + vs.getId());
					}
			}
		}
		
		if (service != null)
		{
			service.setName(vs.getName());
			service.setPackageID(null);
			service.setIsAdditionalSubreq(true);
			service.setDoRequest(true);
		}
		
		return service;
	}
	
	private CAbstractService buildGenericService(
			CVerificationSubject vs,
			COrder order,
			COrderingAddress orderAddress,
			CScreening screening)
	{
		CGeneric generic = screening.getRecordInstance();
		CGenericService genericProduct = new CGenericService();
		
		genericProduct.addProperties(vs.getProperties());
		genericProduct.setVerificationSubject(vs.getId().intValue());
		genericProduct.setProductFeatures(generic.getProductFeaturesAsProperties());
		genericProduct.setInquiry(tryToDecodeBase64(CStringUtils.trim(generic.getInquiry())));
		genericProduct.setResults(tryToDecodeBase64(CStringUtils.trim(generic.getResults())));
		
		if (orderAddress != null)
		{
			genericProduct.setLocation(orderAddress);
		}
		return genericProduct;
	}
	
	private CAbstractService buildProfessionalReferenceService(CVerificationSubject vs, COrder order, CScreening screening)
	{
		CProfessionalReference professionalReference = deserializeProfessionalReference(screening);
		
		CReferenceService referenceService = new CReferenceService();
		referenceService.addProperties(vs.getProperties());
		referenceService.setVerificationSubject(vs.getId());
		
		if (professionalReference != null)
		{
			CProfessionalReference.CReference reference = professionalReference.getReference();
			CAddress address = new CAddress();
			address.setWWWAddress(reference.getWwwAddress());
			address.setCity(reference.getCity());
			address.setCountryID(Integer.valueOf(reference.getCountryId()));
			address.setStateID(reference.getStateId());
			address.setProvince(reference.getProvince());
			address.setEMail(reference.getMail());
			address.setPhone(new CFPhone(reference.getPhone().getCode(), reference.getPhone().getNumber()));
			address.setCellPhone(new CFPhone(reference.getCellPhone()));
			address.setHomePhone(new CFPhone(reference.getHomePhone()));
			address.setZip(reference.getZip());
			referenceService.setReferenceAddress(address);
			referenceService.setProvince(reference.getProvince());
			referenceService.setState(reference.getStateId());
			referenceService.setCountryID(Integer.valueOf(reference.getCountryId()));
			referenceService.setVerificationSubject(vs.getId());
			referenceService.setFirstName(reference.getFirstName());
			referenceService.setLastName(reference.getLastName());
			referenceService.setRelationship(reference.getRelationship());
			referenceService.setUseDefaultQuestionSet(Boolean.FALSE);
		}
		
		return referenceService;
	}

	private CAbstractService buildMilitaryService(CVerificationSubject vs, CScreening screening)
	{
		CMilitary military = screening.getRecordInstance();
		CMilitaryInquiry militaryInquiry;
		CXMLDeserializer<Object> deserializer = new CXMLDeserializer<>(CMilitaryInquiry.class);

		try
		{
			militaryInquiry = (CMilitaryInquiry) deserializer.deserialize(
					new ByteArrayInputStream(tryToDecodeBase64(CStringUtils.trim(military.getInquiry())).getBytes()));
		}
		catch (Exception ex)
		{
			throw new CRuntimeException("Failed to deserialize military inquiry", ex);
		}

		CMilitaryService militaryProduct = new CMilitaryService();

		militaryProduct.addProperties(vs.getProperties());
		militaryProduct.setVerificationSubject(vs.getId().intValue());

		if (militaryInquiry != null)
		{
			militaryProduct.setBranch(CStringUtils.nvl(militaryInquiry.getPastBranch()));
			militaryProduct.setRank(CStringUtils.nvl(militaryInquiry.getPastRank()));
			militaryProduct.setSeparation(CStringUtils.nvl(militaryInquiry.getSeparation()));

			if (militaryInquiry.getDateFrom() != null)
			{
				LocalDate militaryDateFrom = militaryInquiry.getDateFrom().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				if (militaryDateFrom != null)
				{
					militaryProduct.setStartDateMonth(String.valueOf(militaryDateFrom.getMonth().getValue()));
					militaryProduct.setStartDateYear(String.valueOf(militaryDateFrom.getYear()));
				}
			}

			if (militaryInquiry.getDateTo() != null)
			{
				LocalDate militaryDateTo = militaryInquiry.getDateTo().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				if (militaryDateTo != null)
				{
					militaryProduct.setEndDateMonth(String.valueOf(militaryDateTo.getMonth().getValue()));
					militaryProduct.setEndDateYear(String.valueOf(militaryDateTo.getYear()));
				}
			}
		}

		return militaryProduct;
	}
	
	private static String tryToDecodeBase64(String sInput)
	{
		try
		{
			return new String(Base64.getDecoder().decode(sInput));
		}
		catch(Throwable ex)
		{
			return sInput;
		}
	}

	private CAbstractService buildOneClickService(
			CVerificationSubject vs,
			COrder order,
			CScreening screening)
	{
		COneClickService clickService = new COneClickService();
		clickService.addProperties(vs.getProperties());
		clickService.setVerificationSubject(vs.getId().intValue());
		
		return clickService;
	}

	private CCriminalService buildCriminalService(CVerificationSubject vs,
			COrder order, COrderingAddress address, CScreening screening)
	{
		List<COrderingAddress> addresses = new ArrayList<>();
		addresses.add(address);

		String sSearchDepth = null;
		
		CSearchDepth searchDepth = screening.getSearchDepth();
		
		if (searchDepth != null)
		{
			if (searchDepth.getYears() != null)
			{
				sSearchDepth = searchDepth.getYears().toString();
			}
		}
		else
		{
			sSearchDepth = CStringUtils.nvl(m_customer.getCriminalSearchDepth(), "7"); //Default value is 7 years
		}
		
		address.setSearchDepth(sSearchDepth);
		
			String locationMultiString = screening.getLocationMultiplicity() != null ? screening.getLocationMultiplicity() : "";
			locationMultiString = regionMap.containsKey(locationMultiString) ? regionMap.get(locationMultiString) : locationMultiString;
			LocationMultiplicity locationMultiplicity;
			if (locationMultiString.isEmpty() || !EnumUtils.isValidEnum(LocationMultiplicity.class, locationMultiString)) {
					boolean bIsCourtDistrict = CCountry.USA_COUNTRY_ID.equals(address.getCountryID()) &&
							(  HrConstants.crec_crm_fedrl_vsid == vs.getId()
									|| HrConstants.crec_bnk_fedrl_vsid == vs.getId()
									|| HrConstants.crec_cvl_fedrl_vsid == vs.getId()); //Multiplicity for court district workaround
					locationMultiplicity = bIsCourtDistrict ? LocationMultiplicity.COURT_DISTRICT : LocationMultiplicity.UNIQUE;
			} else {
					locationMultiplicity = LocationMultiplicity.valueOf(locationMultiString);
			}

		CCriminalService crim = new CCriminalService(addresses, locationMultiplicity);
		crim.setOrderServiceDao(new COrderServiceDao());
		
		crim.setSearchDepth("0".equals(searchDepth) ? "UL" : StringUtils.leftPad(sSearchDepth, 2, '0'));
		
		if (locationMultiplicity.equals(LocationMultiplicity.COURT_DISTRICT))
		{
			CCounty county = CCounty.find(address.getCounty(), address.getStateID());
			if (county != null)
			{
				CCourtDivision courtDivision = CCourtFactory.getCourtDivision(vs.getId(), address.getStateID(),county.getID());

				if (courtDivision != null)
				{
					crim.setCourtDistrict(courtDivision.getDistrict());
					crim.setCourtDivisionID(courtDivision.getID());
				}
			}
		}
		
		crim.setCountyResolver(new CCountyResolver());
		//TODO sanitize?
		crim.setNameSource(address.getNameSource());
		crim.setFirstName(address.getFirstNameAtAddress());
		crim.setLastName(address.getLastNameAtAddress());
		
		if (address.isInternational())
		{
			CApplicant applicant = order.getApplicant();
			crim.setPersonalID(applicant.getCurrentPersonalID());
		}
		
		crim.setVerificationSubject(vs.getId());
		crim.setName(screening.getQualifier());
		
		return crim;
	}


	private CAbstractService buildMVRService(CVerificationSubject vs, COrder order, COrderingAddress orderAddress, CScreening screening) {
		CMvrService mvrService = new CMvrService(vs.getId());
		mvrService.setIsApplicable(true);

		CLicense license = screening.getRecordInstance();

		if (StringUtils.isNotBlank(license.getIssuingState())) {
			mvrService.setStateIssued(license.getIssuingState());
		}
		if (StringUtils.isNotBlank(license.getIssuingProvince())) {
			mvrService.setRegionIssued(license.getIssuingProvince());
		}
		if (StringUtils.isNotBlank(license.getIssuingRegionID().toString())) {
			mvrService.setRegionIDIssued(license.getIssuingRegionID().toString());
		}
		mvrService.setCountryID(license.getIssuingCountryID());
		mvrService.setCountryIssued(license.getIssuingCountryID());
		mvrService.setLicenceNumber(license.getLicenseNumber());
		
		CPersonName nameOnLicense = license.getNameOnLicense();
		
		if (nameOnLicense != null)
		{
			mvrService.setFirstName(sanitize(nameOnLicense.getGivenName()));
			mvrService.setLastName(sanitize(nameOnLicense.getFamilyName()));
			mvrService.setMiddleName(sanitize(nameOnLicense.getMiddleName()));
		}

		return mvrService;
	}

	private CAbstractService buildProfessionalLicensesService(CVerificationSubject vs, COrder order, COrderingAddress orderAddress, CScreening screening) {
		CLicenseService licenseService = new CLicenseService(vs.getId());
		licenseService.setIsApplicable(true);

		CLicense license = screening.getRecordInstance();

		if (StringUtils.isNotEmpty(license.getExpirationDate())) {
			licenseService.setExpirationDate(DateTimeFormat.forPattern("yyyy-MM-dd").parseDateTime(license.getExpirationDate()).toDate());
		}

		licenseService.setLicenseDoesNotExpire(license.getDoesNotExpire());
		licenseService.setLicenseGoverningAgency(license.getGoverningAgency());
		licenseService.setLicenseType(license.getLicenseType());
		licenseService.setLicenseNumber(license.getLicenseNumber());
		
		CPersonName nameOnLicense = license.getNameOnLicense();
		
		if (nameOnLicense != null)
		{
			//Sanitizing made inside the service
			licenseService.setAkaFirstName(nameOnLicense.getGivenName());
			licenseService.setAkaLastName(nameOnLicense.getFamilyName());
			licenseService.setAkaMiddleName(nameOnLicense.getMiddleName());
		}
		
		CCountryRegion countryRegion = CCountryRegions.findRegion(license.getIssuingCountryID(), license.getIssuingState());


		if (license.getIssuingCountryID() == CCountry.COUNTRY_ID_USA)
		{
			if (StringUtils.isNotBlank(license.getIssuingState()))
			{
				licenseService.setStateIssued(license.getIssuingState());
			}

			licenseService.setCountryID(license.getIssuingCountryID());
		}
		else if (countryRegion != null)
		{
			licenseService.setLicenseAddress(new hireright.objects.utilities.CPostalAddress(
					countryRegion.getCountryID().toString(),
					countryRegion.getRegionID().toString(),
					countryRegion.getRegionName(), null));
		}
		else
		{
			licenseService.setLicenseAddress(new hireright.objects.utilities.CPostalAddress(
					String.valueOf(license.getIssuingCountryID()),
					null,
					license.getIssuingState(),
					null));
		}

		licenseService.setNationalLicense(license.getNational());
		licenseService.setLicenseDetails(license.getSuspensionDetails());
		licenseService.setLicenseStatus(license.getLicenseStatus());

		return licenseService;
	}

	private CEmploymentService buildEmploymentService(CVerificationSubject vs,
			COrder order, COrderingAddress address, CScreening screening)
	{
		CEmploymentService empl = new CEmploymentService(vs.getId());
		empl.setIsApplicable(true);
		
		CEmployment employment = screening.getRecordInstance();
		empl.setEmploymentType(employment.getType());

		CContactInfo contactInfo = screening.getContactInfo();

		if (contactInfo != null)
		{
			CContactMethod contactMethod = contactInfo.getContactMethod();

			if(contactMethod != null)
			{
				CPhoneNumber phoneNumber = contactMethod.getTelephone();

				if (phoneNumber != null)
				{
					address.setPhone(new CFPhone(phoneNumber.getNumber()));
				}
			}
		}
		
		CEmployerOrgName employerName = employment.getEmployerName();
		if (employerName != null)
		{
			empl.setCompanyName(employerName.getName());
		}
		
		CEmployerOrgName additionalCompanyName = employment.getEmployerName("Additional");
		if (additionalCompanyName != null)
		{
			empl.setAdditionalCompanyName(additionalCompanyName.getName());
		}
		
		CEmployerOrgName newCompanyName = employment.getEmployerName("New");
		if (newCompanyName != null)
		{
			empl.setNewCompanyName(newCompanyName.getName());
		}
		
		CPositionHistory position = employment.getPositionHistory();
		if (position != null)
		{
			empl.setJobTitle(position.getTitle());
			empl.setCurrentEmployerString(position.getCurrentEmployer());
			
			CPositionVerification verif = position.getVerification();
			if (verif != null)
			{
				empl.setContactPermissionString(verif.getPermissionToContact());
			}
			
			//boolean bDotPosition = "x:DOT".equals(position.getPositionType());
			//empl.setDotPositionString(bDotPosition ? );
			empl.setDotPositionString(position.getDotPosition());
			empl.setSelfEmployed(position.getSelfEmployed());
			
			CFlexibleDate endDate = position.getEndDate();
			if (endDate != null)
			{
				DateTime date = endDate.getDateTime();
				empl.setEndDateDay(String.valueOf(date.getDayOfMonth()));
				empl.setEndDateMonth(String.valueOf(date.getMonthOfYear()));
				empl.setEndDateYear(String.valueOf(date.getYear()));
				
				String sDateType = endDate.getDateDescription();
				//mmddyyyy = 0; mmyyyy = 1 (as default before); as in CEmploymentServiceHandler
				if (CStringUtils.isNotEmpty(sDateType))
				{
					empl.setEndDateType(Integer.valueOf(sDateType));
				}
				else
				{
					empl.setEndDateType(1);
				}
			}
			
			CFlexibleDate startDate = position.getStartDate();
			if (startDate != null)
			{
				DateTime date = startDate.getDateTime();
				empl.setStartDateDay(String.valueOf(date.getDayOfMonth()));
				empl.setStartDateMonth(String.valueOf(date.getMonthOfYear()));
				empl.setStartDateYear(String.valueOf(date.getYear()));
				
				String sDateType = startDate.getDateDescription();
				//mmddyyyy = 0; mmyyyy = 1 (as default before); as in CEmploymentServiceHandler
				if (CStringUtils.isNotEmpty(sDateType))
				{
					empl.setStartDateType(Integer.valueOf(sDateType));
				}
				else
				{
					empl.setStartDateType(1);
				}
			}
			
			CPositionCompensation compensation = position.getCompensation();
			if (compensation != null)
			{
				CPayment salary = compensation.getSalary();
				if (salary != null)
				{
					empl.setSalaryRateFreq(salary.getIntervalType());
					if (!CStringUtils.isEmpty(salary.getAmount()))
					{
						empl.setEndingSalary(salary.getAmount());
					}
					
					empl.setSalaryCurrency(salary.getCurrency());
				}
				
				CPayment other = compensation.getOtherCompensation("Other");
				
				if (other != null)
				{
					empl.setOtherCompensationFreq(other.getIntervalType());
					if (!CStringUtils.isEmpty(other.getAmount()))
					{
						empl.setOtherCompensation(other.getAmount());
					}
				}
				
				CPayment bonus = compensation.getOtherCompensation("Bonus");
				if (bonus != null)
				{
					empl.setBonusFreq(bonus.getIntervalType());
					if (!CStringUtils.isEmpty(bonus.getAmount()))
					{
						empl.setYearlyBonus(bonus.getAmount());
					}
				}
				
				CPayment comission = compensation.getOtherCompensation("Comission");
				if (comission != null)
				{
					empl.setCommissionFreq(comission.getIntervalType());
					if (comission.getAmount() != null)
					{
						empl.setYearlyCommissions(comission.getAmount().toString());
					}
				}
			}

			String sReasonForLeaving = position.getReasonForLeaving();

			if (!CStringUtils.isEmpty(sReasonForLeaving))
			{
				Integer nReasonID = CReason.findReasonID(CReason.loadAllReasons(), sReasonForLeaving);

				if (nReasonID != null)
				{
					empl.setReasonForLeavingID(nReasonID);
				}
			}
		}
		
		empl.setWentOut(employment.getEmployerOutOfBusiness());
		empl.setIsCompanyNameChanged(employment.getEmployerChangedName());
		
		CPersonName personName = screening.getPersonName();
		if (personName != null)
		{
			empl.setAkaLastName(personName.getFamilyName());
			empl.setAkaMiddleName(personName.getMiddleName());
			empl.setAkaFirstName(personName.getGivenName());
			empl.setAkaNationalFirstName(personName.getNationalGivenName());
			empl.setAkaNationalMiddleName(personName.getNationalMiddleName());
			empl.setAkaNationalLastName(personName.getNationalFamilyName());
		}
		
		empl.setComments(screening.getComments());
		empl.setOrgUnitID(CCDBOrgUnit.getOrgUnitID(screening.getReference(REF_ID_ORG_UNIT_HON)));
		empl.setEmploymentAddress(address);
		
		CApplicant applicant = order.getApplicant();
		empl.setPersonalID(applicant.getCurrentPersonalID());
		
		return empl;
	}

	private CEducationService buildEducationService(CVerificationSubject vs,
			COrder order, COrderingAddress address, CScreening screening)
	{
		CEducationService education = new CEducationService(vs.getId());
		education.setIsApplicable(true);
		
		CEducation edu = screening.getRecordInstance();
		if (edu == null)
		{
			return null;
		}
		
		CSchool school = edu.getSchool();
		if (school != null)
		{
			education.setSchoolName(school.getName());
			education.setSchoolPhone("", school.getPhone());
		}
		
		CDegree degree = edu.getDegree();
		if (degree != null)
		{
			education.setDegree(degree.getDegreeType());
			education.setDegreeEquivalent(degree.getDegreeTypeEquivalent());
			education.setGraduated(degree.getGraduated());

			readQualifications(education, degree);
			
			CFlexibleDate degreeDate = degree.getDegreeDate();
			if (degreeDate != null)
			{
				DateTime date = degreeDate.getDateTime();
				education.setDegreeDateMonth(String.valueOf(date.getMonthOfYear()));
				education.setDegreeDateYear(String.valueOf(date.getYear()));
				
				//mmddyyyy = 0; mmyyyy = 1 (as default before); as in CEducationServiceHandler
				String sDateType = degreeDate.getDateDescription();
				if (CStringUtils.isNotEmpty(sDateType))
				{
					education.setDegreeDateType(Integer.valueOf(sDateType));
				}
				else
				{
					education.setDegreeDateType(1);
				}
			}
			
			CDatesOfAttendance dates = degree.getDatesOfAttendance();
			if (dates != null)
			{
				CFlexibleDate endDate = dates.getEndDate();
				if (endDate != null)
				{
					DateTime date = endDate.getDateTime();
					education.setEndDateDay(String.valueOf(date.getDayOfMonth()));
					education.setEndDateMonth(String.valueOf(date.getMonthOfYear()));
					education.setEndDateYear(String.valueOf(date.getYear()));
					
					String sDateType = endDate.getDateDescription();
					//mmddyyyy = 0; mmyyyy = 1 (as default before); as in CEducationServiceHandler
					if (CStringUtils.isNotEmpty(sDateType))
					{
						education.setEndDateType(Integer.valueOf(sDateType));
					}
					else
					{
						education.setEndDateType(1);
					}
				}
				
				CFlexibleDate startDate = dates.getStartDate();
				if (startDate != null)
				{
					DateTime date = startDate.getDateTime();
					education.setStartDateDay(String.valueOf(date.getDayOfMonth()));
					education.setStartDateMonth(String.valueOf(date.getMonthOfYear()));
					education.setStartDateYear(String.valueOf(date.getYear()));
					
					String sDateType = startDate.getDateDescription();
					if (CStringUtils.isNotEmpty(sDateType))
					{
						education.setStartDateType(Integer.valueOf(sDateType));
					}
					else
					{
						education.setStartDateType(1);
					}

				}
			}
		}
		
		education.setGEDRegionID(screening.getReference("GEDRegionID"));
		
		CContactInfo contactInfo = screening.getContactInfo();
		if (contactInfo != null && contactInfo.getContactMethod() != null)
		{
			CPhoneNumber phoneNumber = contactInfo.getContactMethod().getTelephone();
			if (phoneNumber != null
				&& CStringUtils.isNotEmpty(phoneNumber.getNumber()))
			{
				education.setSchoolPhone(new CFPhone(phoneNumber.getNumber()));
			}
		}
		
		CPersonName personName = screening.getPersonName();
		if (personName != null)
		{
			education.setAkaFirstName(sanitize(personName.getGivenName()));
			education.setAkaMiddleName(sanitize(personName.getMiddleName()));
			education.setAkaLastName(sanitize(personName.getFamilyName()));
			
			education.setNationalAkaFirstName(personName.getGivenName());
			education.setNationalAkaMiddleName(personName.getMiddleName());
			education.setNationalAkaLastName(personName.getFamilyName());
		}
		
		education.setComments(screening.getComments());
		education.setOrgUnitHON(screening.getReference(REF_ID_ORG_UNIT_HON));
		education.setStudentID(screening.getReference("StudentID"));
		education.setSchoolAddress(address);
		
		CApplicant applicant = order.getApplicant();
		education.setPersonalID(applicant.getCurrentPersonalID());
		
		return education;
	}

	private void readQualifications(CEducationService education, CDegree degree)
	{
		List<CDegreeMajor> majors = degree.getMajors();
		if (majors == null || majors.isEmpty())
		{
			return;
		}

		List<CEducationQualification> qualifications = new ArrayList<>();

		for (int i = 0; i < majors.size(); i++)
		{
			CEducationQualification q = new CEducationQualification();
			qualifications.add(q);

			CDegreeMajor major = majors.get(i);
			List<CDegreeMeasure> measures = major.getMeasures();
			
			CDegreeMeasure measure = null;
			if (measures != null && measures.size() > 0)
			{
				measure = measures.get(0);
			}

			q.setNMajor(major.getName());

			if (measure != null && MEASURE_SYSTEM_GPA.equalsIgnoreCase(measure.getMeasureSystem()))
			{
				String sOverall = measure.getMeasureString();
				Double dOverall = measure.getMeasureNumber();
				if (dOverall != null)
				{
					sOverall = String.valueOf(dOverall);
				}

				if (sOverall != null)
				{
					q.setNGPA(sOverall);
				}
			}
		}

		// note: list guaranteed to be not empty by early return
		CEducationQualification firstQualification = qualifications.remove(0);
		education.setMajor(firstQualification.getNMajor());
		education.setOverallGPA(firstQualification.getNGPA());

		education.setQualifications(qualifications);
	}
}
