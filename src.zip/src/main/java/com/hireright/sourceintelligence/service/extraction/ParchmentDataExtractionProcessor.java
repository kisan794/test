package com.hireright.sourceintelligence.service.extraction;

import com.hireright.sourceintelligence.api.dto.Alias;
import com.hireright.sourceintelligence.api.dto.ParchmentRecord;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.entity.Vendors;
import com.hireright.sourceintelligence.domain.repository.VendorsRepository;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import com.hireright.sourceintelligence.util.Helper;
import com.hireright.sourceintelligence.util.StateMapper;
import com.mongodb.BasicDBObject;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.EDUCATION_COLLECTION_PREFIX;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.SOURCE_COLLECTION_SUFFIX;
import static com.hireright.sourceintelligence.domain.constants.Constants.*;
import static com.hireright.sourceintelligence.domain.constants.Constants.AutoMatchConstants.*;
import static com.hireright.sourceintelligence.domain.constants.Constants.DataExtractionConstants.*;
import static com.hireright.sourceintelligence.domain.constants.Constants.DataExtractionConstants.FIELD_VERSION;
import static com.hireright.sourceintelligence.domain.constants.Constants.SmartSearchKeys.*;
import static com.hireright.sourceintelligence.domain.constants.Constants.SmartSearchKeys.CODES;
import static com.hireright.sourceintelligence.domain.constants.Constants.SmartSearchKeys.FOLLOW_UP_ALLOWED;
import static com.hireright.sourceintelligence.service.excel.mapping.ParchmentColumnMapping.*;
import static com.hireright.sourceintelligence.service.excel.mapping.ParchmentColumnMapping.PAYMENT_METHOD;
import static com.hireright.sourceintelligence.service.excel.mapping.ParchmentColumnMapping.SURCHARGE_AMOUNT;

@Slf4j
@Component
@RequiredArgsConstructor
public class ParchmentDataExtractionProcessor implements DataExtractionProcessor {

    private final VendorsRepository vendorsRepository;
    private final MongoTemplate mongoTemplate;
    private final ElasticsearchService elasticsearchService;

    @Override
    public String getDataExtractionTypeType() {
        return DATA_EXTRACTION_TYPE_PARCHMENT;
    }

    @Override
    @Transactional(timeout = TRANSACTION_TIMEOUT)
    public Map<String, Object> processInstitutionRecords(List<ParchmentRecord> parchmentRecordList) {
        Vendors vendor = findParchmentVendor();
        Map<String, List<Source>> sourcesToSaveByCollection = new HashMap<>();
        List<ParchmentRecord> notFoundRecords = new ArrayList<>();

        int totalSourcesUpdated = 0;

        log.info("Starting processing of {} institution records", parchmentRecordList.size());

        Map<String, List<Source>> matches = findMatchingInstitutions(parchmentRecordList);

        for (ParchmentRecord parchmentRecord : parchmentRecordList) {
            try {
                String stateFullName = resolveStateName(parchmentRecord.getStateCountyRegion());
                String recordKey = generateRecordKey(parchmentRecord, stateFullName);
                List<Source> matchingSources = matches.getOrDefault(recordKey, Collections.emptyList());

                if (!CollectionUtils.isEmpty(matchingSources)) {
                    totalSourcesUpdated += processMatchingSources(matchingSources, parchmentRecord, vendor, sourcesToSaveByCollection);

                    if (matchingSources.size() > 1) {
                        log.debug("Multiple matches for '{}': {} sources updated",
                                parchmentRecord.getInstitutionName(), matchingSources.size());
                    }
                } else {
                    notFoundRecords.add(parchmentRecord);
                }
            } catch (Exception e) {
                notFoundRecords.add(parchmentRecord);
            }
        }
        performBulkSaveMongoDB(sourcesToSaveByCollection);
        updateElasticsearchWithRollback(sourcesToSaveByCollection);

        return buildProcessingResult(parchmentRecordList.size(), totalSourcesUpdated, notFoundRecords);
    }

    private Vendors findParchmentVendor() {
        return vendorsRepository.findByVendor(PARCHMENT_EXCHANGE)
                .orElseThrow(() -> new RuntimeException(String.format(ERROR_VENDOR_NOT_FOUND_TEMPLATE, PARCHMENT_EXCHANGE)));
    }

    private String resolveStateName(String stateInput) {
        String stateFullName = StateMapper.getFullName(stateInput);
        return stateFullName.isEmpty() && !stateInput.isEmpty() ? stateInput : stateFullName;
    }

    private int processMatchingSources(List<Source> sources, ParchmentRecord parchmentRecord,
                                       Vendors vendor, Map<String, List<Source>> sourcesToSaveByCollection) {
        int count = 0;
        for (Source source : sources) {
            boolean wasUpdated = updateParchmentExchangeContact(source, parchmentRecord, vendor);
            if (wasUpdated) {
                String collectionName = Helper.getCollectionName(source.getHon(), SOURCE_COLLECTION_SUFFIX);
                sourcesToSaveByCollection.computeIfAbsent(collectionName, k -> new ArrayList<>()).add(source);
                count++;
            }
        }
        return count;
    }

    private Map<String, Object> buildProcessingResult(int totalRecords, int totalSourcesUpdated, List<ParchmentRecord> notFoundRecords) {
        Map<String, Object> result = new HashMap<>();
        result.put(RESULT_KEY_TOTAL_RECORDS, totalRecords);
        result.put(RESULT_KEY_TOTAL_SOURCES_UPDATED, totalSourcesUpdated);
        result.put(RESULT_KEY_NOT_FOUND_RECORDS, notFoundRecords.size());

        result.put("notFoundRecordsData", convertToExcelData(notFoundRecords));
        result.put("excelMetadata", buildExcelMetadata());

        return result;
    }

    private List<Map<String, Object>> convertToExcelData(List<ParchmentRecord> records) {
        return records.stream()
                .map(this::parchmentRecordToMap)
                .collect(Collectors.toList());
    }

    private Map<String, Object> parchmentRecordToMap(ParchmentRecord record) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put(INSTITUTION_NAME, record.getInstitutionName());
        map.put(FIELD_COUNTRY, record.getCountry());
        map.put(FIELD_CITY, record.getCity());
        map.put(STATE_COUNTY_REGION, record.getStateCountyRegion());
        map.put(SERVICE_PROVIDER, record.getServiceProvider());
        map.put(SURCHARGE_AMOUNT, record.getSurchargeAmount());
        map.put(PAYMENT_METHOD, record.getPaymentMethod());
        map.put(CODE, record.getCode());
        map.put(TURNAROUND_TIME, record.getTurnaroundTime());
        map.put(FOLLOW_UP_ALLOWED, record.getFollowUpAllowed());
        return map;
    }

    private List<Map<String, String>> buildExcelMetadata() {
        List<Map<String, String>> metadata = new ArrayList<>();

        metadata.add(createMetadata("Institution Name", INSTITUTION_NAME));
        metadata.add(createMetadata("Country", FIELD_COUNTRY));
        metadata.add(createMetadata("City", FIELD_CITY));
        metadata.add(createMetadata("State/County/Region", STATE_COUNTY_REGION));
        metadata.add(createMetadata("Service Provider", SERVICE_PROVIDER));
        metadata.add(createMetadata("Surcharge Amount", SURCHARGE_AMOUNT));
        metadata.add(createMetadata("Payment Method", PAYMENT_METHOD));
        metadata.add(createMetadata("Code", CODE));
        metadata.add(createMetadata("Turnaround Time", TURNAROUND_TIME));
        metadata.add(createMetadata("Follow Up Allowed", FOLLOW_UP_ALLOWED));

        return metadata;
    }

    private Map<String, String> createMetadata(String label, String key) {
        Map<String, String> meta = new LinkedHashMap<>();
        meta.put("label", label);
        meta.put("key", key);
        return meta;
    }

    private void performBulkSaveMongoDB(Map<String, List<Source>> sourcesToSaveByCollection) {
        sourcesToSaveByCollection.forEach((collectionName, sources) -> {
            if (!sources.isEmpty()) {
                executeBulkUpdate(collectionName, sources);
            }
        });
    }

    private void updateElasticsearchWithRollback(Map<String, List<Source>> sourcesToSaveByCollection) {
        for (Map.Entry<String, List<Source>> entry : sourcesToSaveByCollection.entrySet()) {
            String collectionName = entry.getKey();
            List<Source> sources = entry.getValue();

            if (!sources.isEmpty()) {
                try {
                    String indexName = Helper.getIndexName(sources.getFirst().getOrganizationType().getType());
                    elasticsearchService.bulkUpdateAutomatedService(indexName, sources);
                } catch (Exception e) {
                    log.error("Elasticsearch update failed for {} sources in collection {}. Will rollback MongoDB transaction.",
                            sources.size(), collectionName, e);
                    throw new RuntimeException("Elasticsearch sync failed - MongoDB changes rolled back", e);
                }
            }
        }
    }

    private void executeBulkUpdate(String collectionName, List<Source> sources) {
        BulkOperations bulkOps = mongoTemplate.bulkOps(BulkOperations.BulkMode.UNORDERED, collectionName);

        sources.forEach(source -> {
            Query query = new Query(Criteria.where(MONGO_FIELD_ID).is(source.getId()));
            Update update = new Update()
                    .set(FIELD_PAYLOAD, source.getPayload());
            bulkOps.upsert(query, update);
        });

        var result = bulkOps.execute();
        log.info("Bulk save completed - collection: {}, modified: {}, upserted: {}",
                collectionName, result.getModifiedCount(), result.getUpserts().size());
    }

    private Map<String, List<Source>> findMatchingInstitutions(List<ParchmentRecord> records) {
        if (records.isEmpty()) {
            return Collections.emptyMap();
        }

        List<Criteria> recordCriteriaList = new ArrayList<>();

        for (ParchmentRecord record : records) {
            String stateFullName = resolveStateName(record.getStateCountyRegion());
            if (stateFullName == null || stateFullName.isEmpty()) {
                continue;
            }

            Criteria locationCriteria = buildLocationCriteria(record, stateFullName);
            Criteria nameCriteria = buildOrgNameCriteria(record.getInstitutionName());
            Criteria combinedCriteria = new Criteria().andOperator(locationCriteria, nameCriteria);

            recordCriteriaList.add(combinedCriteria);
        }

        if (recordCriteriaList.isEmpty()) {
            return Collections.emptyMap();
        }

        Query query = new Query(new Criteria().orOperator(recordCriteriaList.toArray(new Criteria[0])));

        query.fields()
                .include(MONGO_FIELD_ID)
                .include(FIELD_NAME)
                .include(FIELD_ALIAS)
                .include(FIELD_CITY)
                .include(FIELD_STATE)
                .include(FIELD_COUNTRY)
                .include(FIELD_HON)
                .include(FIELD_TYPE)
                .include(FIELD_PAYLOAD);

        List<Source> allSources = mongoTemplate.find(query, Source.class, EDUCATION_COLLECTION_PREFIX + SOURCE_COLLECTION_SUFFIX);

        Map<String, List<Source>> resultMap = new HashMap<>();

        for (ParchmentRecord record : records) {
            String stateFullName = resolveStateName(record.getStateCountyRegion());
            String recordKey = generateRecordKey(record, stateFullName);

            List<Source> matchingSources = allSources.stream()
                    .filter(source -> matchesRecord(source, record, stateFullName))
                    .collect(Collectors.toList());

            resultMap.put(recordKey, matchingSources);
        }

        return resultMap;
    }

    private String generateRecordKey(ParchmentRecord record, String stateFullName) {
        return String.format("%s|%s|%s|%s",
                normalize(record.getInstitutionName()),
                normalize(record.getCity()),
                normalize(stateFullName),
                normalize(record.getCountry()));
    }

    private String normalize(String value) {
        return value == null ? "" : value.trim().toLowerCase();
    }

    private boolean matchesRecord(Source source, ParchmentRecord record, String stateFullName) {
        if (!stateFullName.equals(source.getState())) {
            return false;
        }

        if (!equalsIgnoreCase(source.getCity(), record.getCity())) {
            return false;
        }

        if (!equalsIgnoreCase(source.getCountry(), record.getCountry())) {
            return false;
        }

        if (equalsIgnoreCase(source.getOrganizationName(), record.getInstitutionName())) {
            return true;
        }

        if (source.getOrganizationAlias() != null) {
            for (Alias alias : source.getOrganizationAlias()) {
                if (alias != null && equalsIgnoreCase(alias.getName(), record.getInstitutionName())) {
                    return true;
                }
            }
        }

        return false;
    }

    private boolean equalsIgnoreCase(String value1, String value2) {
        if (value1 == null && value2 == null) {
            return true;
        }
        if (value1 == null || value2 == null) {
            return false;
        }
        return value1.equalsIgnoreCase(value2);
    }

    private Criteria buildLocationCriteria(ParchmentRecord parchmentRecord, String stateFullName) {
        Criteria criteria = Criteria.where(FIELD_STATE).is(stateFullName);
        criteria.and(FIELD_CITY).regex(REGEX_ANCHOR_START + Pattern.quote(parchmentRecord.getCity()) + REGEX_ANCHOR_END, REGEX_CASE_INSENSITIVE);
        criteria.and(FIELD_COUNTRY).regex(REGEX_ANCHOR_START + Pattern.quote(parchmentRecord.getCountry()) + REGEX_ANCHOR_END, REGEX_CASE_INSENSITIVE);
        return criteria;
    }

    private Criteria buildOrgNameCriteria(String institutionName) {
        if (institutionName == null || institutionName.isEmpty()) {
            return new Criteria();
        }

        String pattern = REGEX_ANCHOR_START + Pattern.quote(institutionName) + REGEX_ANCHOR_END;
        return new Criteria().orOperator(
                Criteria.where(FIELD_NAME).regex(pattern, REGEX_CASE_INSENSITIVE),
                Criteria.where(MONGO_FIELD_ORGANIZATION_ALIAS_NAME).regex(pattern, REGEX_CASE_INSENSITIVE)
        );
    }

    private boolean updateParchmentExchangeContact(Source source, ParchmentRecord parchmentRecord, Vendors vendor) {
        BasicDBObject payload = ensurePayload(source);
        List<BasicDBObject> contacts = ensureContacts(payload);
        BasicDBObject contact = ensureContact(contacts);
        List<BasicDBObject> contactDetails = ensureContactDetails(contact);
        BasicDBObject automatedServicesContact = ensureAutomatedServicesContact(contactDetails);

        return updateParchmentExchangeCommunication(automatedServicesContact, parchmentRecord, vendor);
    }

    private List<BasicDBObject> toBasicDBObjectList(Object obj) {
        return switch (obj) {
            case null -> new ArrayList<>();
            case List<?> rawList -> {
                List<BasicDBObject> result = new ArrayList<>();
                for (Object item : rawList) {
                    switch (item) {
                        case BasicDBObject bdo -> result.add(bdo);
                        case Map map -> result.add(new BasicDBObject(map));
                        case null, default -> log.warn("Unexpected item type in list: {}. Skipping.",
                                item != null ? item.getClass().getName() : "null");
                    }
                }
                yield result;
            }
            default -> {
                log.warn("Expected List but got: {}. Returning empty list.",
                        obj.getClass().getName());
                yield new ArrayList<>();
            }
        };
    }

    private BasicDBObject ensurePayload(Source source) {
        Object payloadObj = source.getPayload();

        return switch (payloadObj) {
            case null -> {
                BasicDBObject payload = new BasicDBObject();
                source.setPayload(payload);
                yield payload;
            }
            case BasicDBObject bdo -> bdo;
            case Map map -> new BasicDBObject(map);
            default -> {
                log.warn("Unexpected payload type: {}. Attempting to parse as JSON.", payloadObj.getClass().getName());
                yield BasicDBObject.parse(payloadObj.toString());
            }
        };
    }

    private List<BasicDBObject> ensureContacts(BasicDBObject payload) {
        Object contactsObj = payload.computeIfAbsent(CONTACTS, k -> new ArrayList<BasicDBObject>());
        List<BasicDBObject> contacts = toBasicDBObjectList(contactsObj);
        payload.put(CONTACTS, contacts);
        return contacts;
    }

    private BasicDBObject ensureContact(List<BasicDBObject> contacts) {
        if (contacts.isEmpty()) {
            BasicDBObject contact = new BasicDBObject();
            contact.put(FIELD_PURPOSE, EMPTY_STRING);
            contact.put(FIELD_PURPOSE_RULE, new ArrayList<>());
            contact.put(CONTACT_DETAILS, new ArrayList<>());
            contacts.add(contact);
            return contact;
        }
        return contacts.getFirst();
    }

    private List<BasicDBObject> ensureContactDetails(BasicDBObject contact) {
        Object detailsObj = contact.computeIfAbsent(CONTACT_DETAILS, k -> new ArrayList<BasicDBObject>());
        List<BasicDBObject> details = toBasicDBObjectList(detailsObj);
        contact.put(CONTACT_DETAILS, details);
        return details;
    }

    private BasicDBObject ensureAutomatedServicesContact(List<BasicDBObject> contactDetails) {
        BasicDBObject automatedServicesContact = findContactDetailByType(contactDetails, CONTACT_AUTOMATED_SERVICES);
        if (automatedServicesContact == null) {
            incrementAllPriorities(contactDetails);
            automatedServicesContact = createAutomatedServicesContact(1);
            contactDetails.add(automatedServicesContact);
        }
        return automatedServicesContact;
    }

    private void incrementAllPriorities(List<BasicDBObject> items) {
        for (BasicDBObject item : items) {
            Object priorityObj = item.get(PRIORITY);
            if (priorityObj != null) {
                int currentPriority = toInt(priorityObj);
                item.put(PRIORITY, currentPriority + 1);
            }
        }
    }

    private BasicDBObject findContactDetailByType(List<BasicDBObject> contactDetails, String type) {
        return contactDetails.stream()
                .filter(cd -> hasType(cd, type))
                .findFirst()
                .orElse(null);
    }

    private boolean hasType(BasicDBObject cd, String type) {
        return type.equals(cd.get(TYPE));
    }

    private int toInt(Object priority) {
        if (priority instanceof Integer i) {
            return i;
        }
        return Integer.parseInt(priority.toString());
    }

    private BasicDBObject createAutomatedServicesContact(int priority) {
        BasicDBObject contact = new BasicDBObject();
        contact.put(FOLLOW_UP_ALLOWED, EMPTY_STRING);
        contact.put(TYPE, CONTACT_AUTOMATED_SERVICES);
        contact.put(PRIORITY, priority);
        contact.put(FIELD_VERSION, EMPTY_STRING);
        contact.put(TURN_AROUND_TIME, EMPTY_STRING);
        contact.put(SUR_CHARGE_AMOUNT, EMPTY_STRING);
        contact.put(NAME, EMPTY_STRING);
        contact.put(SUR_CHARGE_PAYMENT, EMPTY_STRING);
        contact.put(TURN_AROUND_TIME_UNIT, TIME_UNIT_DAYS);
        contact.put(SUR_CHARGE_CURRENCY, EMPTY_STRING);
        contact.put(COMMUNICATION, new ArrayList<>());
        contact.put(FROM_YEAR, EMPTY_STRING);
        contact.put(TO_YEAR, EMPTY_STRING);
        return contact;
    }

    private boolean updateParchmentExchangeCommunication(BasicDBObject contactDetail, ParchmentRecord parchmentRecord, Vendors vendor) {
        List<BasicDBObject> communications = ensureCommunications(contactDetail);
        BasicDBObject parchmentComm = findParchmentCommunication(communications);

        if (parchmentComm == null) {
            incrementAllPriorities(communications);
            parchmentComm = createParchmentExchangeCommunication(parchmentRecord, vendor, 1);
            communications.add(parchmentComm);
            return true;
        }
        return false;
    }

    private List<BasicDBObject> ensureCommunications(BasicDBObject contactDetail) {
        Object commsObj = contactDetail.computeIfAbsent(COMMUNICATION, k -> new ArrayList<BasicDBObject>());
        List<BasicDBObject> communications = toBasicDBObjectList(commsObj);
        contactDetail.put(COMMUNICATION, communications);
        return communications;
    }

    private BasicDBObject findParchmentCommunication(List<BasicDBObject> communications) {
        return communications.stream()
                .filter(this::isParchmentCommunication)
                .findFirst()
                .orElse(null);
    }

    private boolean isParchmentCommunication(BasicDBObject comm) {
        return PARCHMENT_EXCHANGE.equals(comm.get(NAME));
    }

    private BasicDBObject createParchmentExchangeCommunication(ParchmentRecord parchmentRecord, Vendors vendor, int priority) {
        String providerName = Optional.ofNullable(parchmentRecord.getServiceProvider())
                .filter(sp -> !sp.isEmpty())
                .orElse(PARCHMENT_EXCHANGE);

        BasicDBObject communication = new BasicDBObject();
        communication.put(NAME, providerName);
        communication.put(COMMUNICATION_INFO, createCommunicationInfoList(parchmentRecord, vendor));
        communication.put(PROVIDER_ID, String.valueOf(vendor.getProviderId()));
        communication.put(PRIORITY, priority);

        return communication;
    }

    private List<BasicDBObject> createCommunicationInfoList(ParchmentRecord parchmentRecord, Vendors vendor) {
        List<BasicDBObject> infoList = new ArrayList<>();

        infoList.add(createCommunicationInfo(COMPANY_NAMES, parchmentRecord.getInstitutionName()));
        infoList.add(createCommunicationInfo(CODES, parchmentRecord.getCode()));
        infoList.add(createCommunicationInfo(BRANCH, EMPTY_STRING));
        infoList.add(createCommunicationInfo(URI, vendor.getWebsite()));
        infoList.add(createCommunicationInfo(FIELD_SOURCE_TYPE, SOURCE_TYPE_EDUCATION));
        infoList.add(createCommunicationInfo(SURCHARGE_AMOUNT, orEmpty(parchmentRecord.getSurchargeAmount())));
        infoList.add(createCommunicationInfo(SURCHARGE_CURRENCY,
                COUNTRY_USA.equalsIgnoreCase(parchmentRecord.getCountry()) ? CURRENCY_USD : EMPTY_STRING));
        infoList.add(createCommunicationInfo(PAYMENT_METHOD, orEmpty(parchmentRecord.getPaymentMethod())));
        infoList.add(createCommunicationInfo(FOLLOW_UP_ALLOWED, orEmpty(parchmentRecord.getFollowUpAllowed())));
        infoList.add(createCommunicationInfo(FOLLOW_UP_ALLOWED_AFTER, EMPTY_STRING));
        infoList.add(createCommunicationInfo(FOLLOW_UP_ALLOWED_AFTER_UNITS, TIME_UNIT_DAYS));
        infoList.add(createCommunicationInfo(TURN_AROUND_TIME, orEmpty(parchmentRecord.getTurnaroundTime())));
        infoList.add(createCommunicationInfo(TURN_AROUND_TIME_UNIT, TIME_UNIT_DAYS));
        infoList.add(createCommunicationInfo(FROM_YEAR, EMPTY_STRING));
        infoList.add(createCommunicationInfo(TO_YEAR, EMPTY_STRING));

        return infoList;
    }

    private String orEmpty(String value) {
        return value != null ? value : EMPTY_STRING;
    }

    private BasicDBObject createCommunicationInfo(String type, String value) {
        BasicDBObject info = new BasicDBObject();
        info.put(TYPE, type);
        info.put(VALUE, orEmpty(value));
        return info;
    }

}