package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchResponseDTO;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;

import java.util.*;

public interface SourceService {

    SourceOrganizationDTO createSource(SourceOrganizationDTO sourceIntelligence, UIActionsDTO uiActionsDTO);

    SourceOrganizationDTO updateSource(SourceOrganizationDTO sourceIntelligence, UIActionsDTO uiActionsDTO);

    ResponseObject archiveSource(String hon, UIActionsDTO uiActionsDTO);

    ResponseObject assignApproveManagerToSource(ApprovalRequestDTO approvalRequestDTO);

    boolean updateFlagForPriority(String hon, Double version);

    ResponseObject deleteSource(String hon, DeleteRequestDTO deleteRequestDTO);

    ResponseObject lockSource(String hon, UIActionsDTO uiActionsDTO);

    ResponseObject unlockSource(String hon, UIActionsDTO uiActionsDTO);

    boolean updateUsedCount(String hon, boolean isAutoMatch);

    boolean updateSourceStatus(String hon, String version,String tempVersion, ApprovalStatus approvalStatus);

    SourceOrganizationDTO getSourceByHonAndApprovalStatus(String hon, ApprovalStatus approvalStatus);

    SourceOrganizationDTO getSourceByHonForOpTool(String hon);

    SourceOrganizationDTO getSourceForEditByHon(String hon, String action);

    RamResponseDTO getSourceForRAM(String hon, SourceRequestDTO sourceRequestDTO);

    SourceOrganizationDTO getSourceByHon(String hon);

    List<SourceOrganizationDTO> getSourcesByHonIds(List<String> hons);

    AutoMatchResponseDTO manualSelectSource(String hon, ApprovalStatus approvalStatus);

}
