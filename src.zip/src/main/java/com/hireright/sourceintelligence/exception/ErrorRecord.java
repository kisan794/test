package com.hireright.sourceintelligence.exception;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ErrorRecord implements Serializable {
    private static final long serialVersionUID = 1L;
    private String errorCode;
    private String message;
    private String errorType;
}

