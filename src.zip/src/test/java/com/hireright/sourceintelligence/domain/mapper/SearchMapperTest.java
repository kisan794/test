package com.hireright.sourceintelligence.domain.mapper;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.hireright.sourceintelligence.api.dto.SearchOrganizationDTO;
import com.hireright.sourceintelligence.api.dto.SearchPayload;
import com.hireright.sourceintelligence.api.dto.SmartSearchResultDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.util.TestDataProvider;
import com.mongodb.BasicDBObject;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

class SearchMapperTest {

  private SearchMapper searchMapper;

  @BeforeEach
  void setUp() {
    searchMapper = Mappers.getMapper(SearchMapper.class);
  }

  @Test
  void convertJsonToPOJO_shouldConvertSuccessfully() {
    String json = """
        {
          "website": "https://example.com",
          "notes": "sample notes",
          "additionalInfo": [
            {
              "releaseType": "Standard",
              "doNotContact": "No",
              "sourceLanguage": "English",
              "version": "1"
            }
          ],
          "addressLine": "line1",
          "departmentName": "HR",
          "doNotContact": "true",
          "usedCount": 7
        }
        """;

    SearchPayload payload = searchMapper.convertJsonToPOJO(json, SearchPayload.class);

    assertThat(payload).isNotNull();
    assertThat(payload.getWebsite()).isEqualTo("https://example.com");
    assertThat(payload.getNotes()).isEqualTo("sample notes");
    assertThat(payload.getAdditionalInfo()).isNotNull();
    assertThat(payload.getAdditionalInfo()).hasSize(1);
    assertThat(payload.getAdditionalInfo().get(0).getReleaseType()).isEqualTo("Standard");
    assertThat(payload.getAddressLine()).isEqualTo("line1");
    assertThat(payload.getDepartmentName()).isEqualTo("HR");
    assertThat(payload.getDoNotContact()).isEqualTo("true");
    assertThat(payload.getUsedCount()).isEqualTo(7);
  }

  @Test
  void convertJsonToPOJO_shouldThrowExceptionForInvalidJson() {
    String invalidJson = "{invalid-json}";

    assertThrows(RuntimeException.class,
            () -> searchMapper.convertJsonToPOJO(invalidJson, SearchPayload.class));
  }

  @Test
  void mapPayloadFields_shouldReturnWhenPayloadIsNull() {
    Source source = new Source();
    source.setHon("HON-123");
    source.setPayload(null);

    SearchOrganizationDTO dto = new SearchOrganizationDTO();

    assertDoesNotThrow(() -> searchMapper.mapPayloadFields(source, dto));

    assertThat(dto.getWebsite()).isNull();
    assertThat(dto.getNotes()).isNull();
    assertThat(dto.getAdditionalInfo()).isNull();
    assertThat(dto.getAddressLine()).isNull();
  }

  @Test
  void mapPayloadFields_shouldReturnWhenConvertedPayloadIsNull() {
    SearchMapper mapperWithNullConvertedPayload = new SearchMapper() {
      @Override
      public <T> T convertJsonToPOJO(String source, Class<T> target) {
        return null;
      }

      @Override
      public SearchOrganizationDTO entitySourceToDTO(Source entity) {
        return null;
      }

      @Override
      public List<SearchOrganizationDTO> toDTOList(List<Source> entityList) {
        return Collections.emptyList();
      }

      @Override
      public List<SmartSearchResultDTO> toSmartSourceDTOList(List<Source> entityList) {
        return Collections.emptyList();
      }
    };

    Source source = new Source();
    source.setHon("HON-456");
    source.setPayload(BasicDBObject.parse("{\"website\":\"https://example.com\"}"));

    SearchOrganizationDTO dto = new SearchOrganizationDTO();

    assertDoesNotThrow(() -> mapperWithNullConvertedPayload.mapPayloadFields(source, dto));

    assertThat(dto.getWebsite()).isNull();
    assertThat(dto.getNotes()).isNull();
    assertThat(dto.getAdditionalInfo()).isNull();
    assertThat(dto.getAddressLine()).isNull();
  }

  @Test
  void entitySourceToDTO_shouldMapEntityAndPayloadFields() {
    Source source = TestDataProvider.getSourceOrganizationEntityThree();
    source.setHon(TestDataProvider.getHon());
    source.setAssignedTo("tester");
    source.setStatus(SourceOrganizationStatus.ACTIVE);
    source.setPayload(BasicDBObject.parse("""
        {
          "website": "https://example.com",
          "notes": "search notes",
          "additionalInfo": [
            {
              "releaseType": "Standard",
              "doNotContact": "No",
              "sourceLanguage": "English",
              "version": "1"
            }
          ],
          "addressLine": "Address Line 1",
          "departmentName": "Verification",
          "doNotContact": "true",
          "usedCount": 5
        }
        """));

    SearchOrganizationDTO dto = searchMapper.entitySourceToDTO(source);

    assertThat(dto).isNotNull();
    assertThat(dto.getOrganizationName()).isEqualTo(source.getOrganizationName());
    assertThat(dto.getWebsite()).isEqualTo("https://example.com");
    assertThat(dto.getNotes()).isEqualTo("search notes");
    assertThat(dto.getAddressLine()).isEqualTo("Address Line 1");
    assertThat(dto.getDepartmentName()).isEqualTo("Verification");
    assertThat(dto.getDoNotContact()).isEqualTo("true");
    assertThat(dto.getUsedCount()).isEqualTo(5);
    assertThat(dto.getAdditionalInfo()).isNotNull();
    assertThat(dto.getAdditionalInfo()).hasSize(1);
    assertThat(dto.getAssignedTo()).isEqualTo("tester");
    assertThat(dto.getStatus()).isEqualTo(SourceOrganizationStatus.ACTIVE);
  }

  @Test
  void listMappingMethods_shouldMapLists() {
    Source source = TestDataProvider.getSourceOrganizationEntityThree();
    source.setHon(TestDataProvider.getHon());

    List<Source> sourceList = List.of(source);

    List<SearchOrganizationDTO> dtoList = searchMapper.toDTOList(sourceList);
    List<SmartSearchResultDTO> smartDtoList = searchMapper.toSmartSourceDTOList(sourceList);

    assertThat(dtoList).isNotNull();
    assertThat(dtoList).hasSize(1);
    assertThat(dtoList.get(0).getOrganizationName()).isEqualTo(source.getOrganizationName());

    assertThat(smartDtoList).isNotNull();
    assertThat(smartDtoList).hasSize(1);
  }
}
