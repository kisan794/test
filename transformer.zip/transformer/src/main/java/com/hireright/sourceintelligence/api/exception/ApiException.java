package com.hireright.sourceintelligence.api.exception;

public class ApiException {

}
