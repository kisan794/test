package com.hireright.sourceintelligence.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Document(collection = "country_region_mapping")
public class CountryRegionMapping {

    @Id
    private String id;
    private String country;
    private String region;
}
