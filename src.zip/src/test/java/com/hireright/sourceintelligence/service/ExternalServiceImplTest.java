package com.hireright.sourceintelligence.service;
import com.fasterxml.jackson.databind.JsonNode;
import com.hireright.sourceintelligence.api.dto.ExternalResponse;
import com.hireright.sourceintelligence.exception.InvalidRequestException;
import com.hireright.sourceintelligence.exception.ResourceNotFoundException;
import com.hireright.sourceintelligence.exception.ServiceException;
import com.hireright.sourceintelligence.service.impl.ExternalServiceImpl;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.*;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.retry.RetryContext;
import org.springframework.retry.support.RetrySynchronizationManager;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.ResponseExtractor;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import static org.junit.jupiter.api.Assertions.*;
import com.hireright.sourceintelligence.exception.InvalidJsonException;
import com.sun.net.httpserver.HttpServer;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;


import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.http.HttpClient;
import java.util.List;


import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ExternalServiceImplTest {

    @InjectMocks
    private ExternalServiceImpl externalService;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private HttpClient httpClient;

    @BeforeEach
    void setUp() {
        setPrivateField(externalService, "dmsUrl", "http://localhost:8080");
        setPrivateField(externalService, "hrg1ApiUrl", "http://hrg1api.com");
        setPrivateField(externalService, "hrg1PermissionApiUrl", "http://hrg1permission.com/");
        setPrivateField(externalService, "hrg1ApproversApiUrl", "http://hrg1approvers.com/");
        RetryContext mockRetryContext = mock(RetryContext.class, withSettings().lenient());
        when(mockRetryContext.getRetryCount()).thenReturn(0);
        RetrySynchronizationManager.register(mockRetryContext);
    }


    @AfterEach
    void tearDown() {
        RetrySynchronizationManager.clear();
    }

    private void setPrivateField(Object target, String fieldName, Object value) {
        try {
            java.lang.reflect.Field field = target.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(target, value);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void testGetExternalApiResponse_Success() {
        String url = "http://hrg1api.com/test";
        when(restTemplate.getForObject(url, String.class)).thenReturn("{}");
        ExternalResponse response = externalService.getExternalApiResponse(url);
        assertNotNull(response);
    }

    @Test
    void testGetExternalApiResponse_Failure() {
        String url = "http://hrg1api.com/test";
        when(restTemplate.getForObject(url, String.class)).thenThrow(new RestClientException("Error"));
        assertThrows(RestClientException.class, () -> externalService.getExternalApiResponse(url));
    }

    @Test
    void testGetHRGPermissions_Success() {
        String url = "http://hrg1permission.com/user123";
        String json = "{\"permissions\":[\"READ\",\"WRITE\"]}";
        when(restTemplate.getForObject(url, String.class)).thenReturn(json);

        JsonNode response = externalService.getHRGPermissions(url);

        assertNotNull(response);
        assertTrue(response.has("permissions"));
        assertEquals(2, response.get("permissions").size());
        assertEquals("READ", response.get("permissions").get(0).asText());
    }


    @Test
    void testGetHRGPermissions_Failure() {
        String url = "http://hrg1permission.com/user123";

        when(restTemplate.getForObject(url, String.class))
                .thenThrow(new RestClientException("Error"));

        ServiceException ex =
                assertThrows(ServiceException.class, () -> externalService.getHRGPermissions(url));

        assertTrue(ex.getCause() instanceof RestClientException);
        assertEquals("Error", ex.getCause().getMessage());

        verify(restTemplate).getForObject(url, String.class);
    }


    @Test
    void testGetApproversList_Success() {
        String url = "http://hrg1approvers.com/user123";

        String json = "{\"approvers\":[{\"id\":1,\"name\":\"A\"},{\"id\":2,\"name\":\"B\"}]}";
        when(restTemplate.getForObject(url, String.class)).thenReturn(json);

        JsonNode node = externalService.getApproversList(url);

        assertNotNull(node);
        assertTrue(node.has("approvers"));
        assertEquals(2, node.get("approvers").size());
        assertEquals("A", node.get("approvers").get(0).get("name").asText());
    }


    @Test
    void testGetApproversList_Failure() {
        String url = "http://hrg1approvers.com/user123";
        when(restTemplate.getForObject(url, String.class))
                .thenThrow(new RestClientException("Error"));

        ServiceException ex =
                assertThrows(ServiceException.class, () -> externalService.getApproversList(url));

        assertTrue(ex.getCause() instanceof RestClientException);
        assertEquals("Error", ex.getCause().getMessage());

        verify(restTemplate).getForObject(url, String.class);
    }


    @Test
    void testRetryUploadService_Success() throws IOException {
        MockMultipartFile file = new MockMultipartFile("file", "test.txt", "text/plain", "Test content".getBytes());
        String documentMeta = "{\"meta\":\"data\"}";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        ByteArrayResource fileResource = new ByteArrayResource(file.getBytes()) {
            @Override
            public String getFilename() {
                return file.getOriginalFilename();
            }
        };
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("file", fileResource);
        body.add("documentMeta", documentMeta);

        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);
        ResponseEntity<String> responseEntity = new ResponseEntity<>("Upload Success", HttpStatus.OK);

        when(restTemplate.exchange(
                eq("http://localhost:8080/documents"),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(String.class)
        )).thenReturn(responseEntity);

        String response = externalService.retryUploadService(file, documentMeta);
        assertEquals("Upload Success", response);
    }

    @Test
    void testRetryUploadService_Failure() throws IOException {
        MockMultipartFile file = new MockMultipartFile("file", "test.txt", "text/plain", "Test content".getBytes());
        String documentMeta = "{\"meta\":\"data\"}";

        when(restTemplate.exchange(
                eq("http://localhost:8080/documents"),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(String.class)
        )).thenThrow(new RestClientException("Upload failed"));

        assertThrows(RestClientException.class, () -> externalService.retryUploadService(file, documentMeta));
    }

    @Test
    void testGetAttachmentByUrl_Success() throws IOException {
        String documentId = "12345";
        byte[] fileContent = "File content".getBytes();
        ByteArrayInputStream inputStream = new ByteArrayInputStream(fileContent);
        InputStreamResource resource = new InputStreamResource(inputStream);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDisposition(ContentDisposition.builder("attachment").filename("test.txt").build());

        ResponseEntity<InputStreamResource> responseEntity = new ResponseEntity<>(resource, headers, HttpStatus.OK);
        when(restTemplate.execute(
                eq("http://localhost:8080/documents/" + documentId + "/body"),
                eq(HttpMethod.GET),
                any(),
                any())
        ).thenReturn(responseEntity);

        ResponseEntity<InputStreamResource> response = externalService.getAttachmentByUrl(documentId);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }
    @Test
    void testGetAttachmentByUrl_FileNameParsing() throws IOException {
        String documentId = "12345";
        byte[] content = "content".getBytes();
        ByteArrayInputStream inputStream = new ByteArrayInputStream(content);
        InputStreamResource resource = new InputStreamResource(inputStream);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"test.txt\"");

        ResponseEntity<InputStreamResource> responseEntity = new ResponseEntity<>(resource, headers, HttpStatus.OK);

        when(restTemplate.execute(
                eq("http://localhost:8080/documents/" + documentId + "/body"),
                eq(HttpMethod.GET),
                any(),
                any())
        ).thenReturn(responseEntity);

        ResponseEntity<InputStreamResource> response = externalService.getAttachmentByUrl(documentId);
        assertNotNull(response);
    }

    @Test
    void testGetExternalApiResponse_NullResponse() {
        String url = "http://hrg1api.com/test";
        when(restTemplate.getForObject(url, String.class)).thenReturn(null);

        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> externalService.getExternalApiResponse(url)
        );
        assertTrue(ex.getMessage().contains("content"));
    }

    @Test
    void testRetryUploadService_IOException() throws IOException {
        MultipartFile file = mock(MultipartFile.class);
        when(file.getBytes()).thenThrow(new IOException("IO Error"));
        String documentMeta = "{\"meta\":\"data\"}";

        InvalidRequestException ex = assertThrows(InvalidRequestException.class, () -> externalService.retryUploadService(file, documentMeta));
        assertTrue(ex.getMessage().contains("External service is not available please try after sometime"));
    }


    @Test
    void testGetAttachmentByUrl_Failure() throws IOException {
        String documentId = "notfound";
        when(restTemplate.execute(
                eq("http://localhost:8080/documents/" + documentId + "/body"),
                eq(HttpMethod.GET),
                any(),
                any())
        ).thenThrow(new RestClientException("Not Found"));

        assertThrows(ResourceNotFoundException.class, () -> externalService.getAttachmentByUrl(documentId));
    }

    @Test
    void testGetHtmlResponseByHon_NullInput() {
        String response = externalService.getHtmlResponseByHon(null);
        assertEquals("<html><body><h2>Rendering Html response</h2></body></html>", response);
    }

    @Test
    void testGetAttachmentByUrl_HeaderIsNull() throws IOException {
        String documentId = "nullHeader";

        doAnswer(invocation -> {
            ResponseExtractor<?> extractor = invocation.getArgument(3);

            ClientHttpResponse mockResponse = mock(ClientHttpResponse.class);
            HttpHeaders headers = new HttpHeaders(); // no content-disposition
            headers.setContentType(MediaType.APPLICATION_PDF);

            when(mockResponse.getHeaders()).thenReturn(headers);
            when(mockResponse.getBody()).thenReturn(new ByteArrayInputStream("dummy".getBytes()));
            when(mockResponse.getStatusCode()).thenReturn(HttpStatus.OK);

            return extractor.extractData(mockResponse);
        }).when(restTemplate).execute(
                eq("http://localhost:8080/documents/" + documentId + "/body"),
                eq(HttpMethod.GET),
                any(),
                any()
        );

        ResponseEntity<InputStreamResource> response = externalService.getAttachmentByUrl(documentId);

        assertNotNull(response);
        assertEquals(MediaType.APPLICATION_PDF, response.getHeaders().getContentType());
    }



    @Test
    void testGetAttachmentByUrl_HeaderEmpty() throws IOException {
        String documentId = "emptyHeader";

        doAnswer(invocation -> {
            ResponseExtractor<?> extractor = invocation.getArgument(3);

            ClientHttpResponse mockResponse = mock(ClientHttpResponse.class);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.put(HttpHeaders.CONTENT_DISPOSITION, List.of()); // explicitly empty

            when(mockResponse.getHeaders()).thenReturn(headers);
            when(mockResponse.getBody()).thenReturn(new ByteArrayInputStream("sample".getBytes()));
            when(mockResponse.getStatusCode()).thenReturn(HttpStatus.OK);

            return extractor.extractData(mockResponse);
        }).when(restTemplate).execute(
                eq("http://localhost:8080/documents/" + documentId + "/body"),
                eq(HttpMethod.GET),
                any(),
                any()
        );

        ResponseEntity<InputStreamResource> response = externalService.getAttachmentByUrl(documentId);

        assertNotNull(response);
        assertEquals(MediaType.APPLICATION_OCTET_STREAM, response.getHeaders().getContentType());
    }



    @Test
    void testGetAttachmentByUrl_DispositionWithoutFilename() throws IOException {
        String documentId = "noFilename";

        doAnswer(invocation -> {
            ResponseExtractor<?> extractor = invocation.getArgument(3);

            ClientHttpResponse mockResponse = mock(ClientHttpResponse.class);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment");

            when(mockResponse.getHeaders()).thenReturn(headers);
            when(mockResponse.getBody()).thenReturn(new ByteArrayInputStream("file content".getBytes()));
            when(mockResponse.getStatusCode()).thenReturn(HttpStatus.OK);
            return extractor.extractData(mockResponse);
        }).when(restTemplate).execute(
                eq("http://localhost:8080/documents/" + documentId + "/body"),
                eq(HttpMethod.GET),
                any(),
                any()
        );

        ResponseEntity<InputStreamResource> response = externalService.getAttachmentByUrl(documentId);

        assertNotNull(response);
        assertEquals(MediaType.APPLICATION_OCTET_STREAM, response.getHeaders().getContentType());
    }

    @Test
    void testGetHrg1PermissionApiUrl() {
        String expectedUrl = "http://hrg1permission.com/";
        String actualUrl = externalService.getHrg1PermissionApiUrl();

        assertEquals(expectedUrl, actualUrl);
    }

    @Test
    void testGetHrg1ApiUrl() {
        String expectedUrl = "http://hrg1api.com";
        String actualUrl = externalService.getHrg1ApiUrl();

        assertEquals(expectedUrl, actualUrl);
    }

    @Test
    void testGetHrg1ApproversApiUrl() {
        String expectedUrl = "http://hrg1approvers.com/";
        String actualUrl = externalService.getHrg1ApproversApiUrl();

        assertEquals(expectedUrl, actualUrl);
    }

    @Test
    void testGetRestTemplate() {
        RestTemplate template = externalService.getRestTemplate();

        assertNotNull(template);
        assertSame(restTemplate, template);
    }

    @Test
    void testGetDmsUrl() {
        assertEquals("http://localhost:8080", externalService.getDmsUrl());
    }

    @Test
    void testGetExternalApiResponse_InvalidJson_ThrowsInvalidJsonException() {
        String url = "http://hrg1api.com/bad";
        when(restTemplate.getForObject(url, String.class)).thenReturn("{invalid-json}");
        assertThrows(InvalidJsonException.class, () -> externalService.getExternalApiResponse(url));
    }

    @Test
    void testDeleteAttachment_Success() throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress(0), 0);
        int port = server.getAddress().getPort();
        setPrivateField(externalService, "dmsUrl", "http://localhost:" + port);

        String documentId = "abc123";
        server.createContext("/documents/" + documentId, exchange -> {
            assertEquals("DELETE", exchange.getRequestMethod());
            byte[] resp = "deleted".getBytes();
            exchange.sendResponseHeaders(200, resp.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(resp);
            }
        });
        server.start();

        String body = externalService.deleteAttachment(documentId);
        assertEquals("deleted", body);
        server.stop(0);
    }

    @Test
    void testDeleteAttachment_IOException() throws Exception {
        int freePort;
        try (ServerSocket s = new ServerSocket(0)) {
            freePort = s.getLocalPort();
        }
        setPrivateField(externalService, "dmsUrl", "http://localhost:" + freePort);

        assertThrows(IOException.class, () -> externalService.deleteAttachment("no-server"));
    }

    @Test
    void testGetAttachmentByUrl_NoContentType_DefaultsToOctetStream() throws IOException {
        String documentId = "noContentType";

        doAnswer(invocation -> {
            ResponseExtractor<?> extractor = invocation.getArgument(3);

            ClientHttpResponse mockResponse = mock(ClientHttpResponse.class);
            HttpHeaders headers = new HttpHeaders();
            when(mockResponse.getHeaders()).thenReturn(headers);
            when(mockResponse.getBody()).thenReturn(new ByteArrayInputStream("x".getBytes()));
            when(mockResponse.getStatusCode()).thenReturn(HttpStatus.OK);

            return extractor.extractData(mockResponse);
        }).when(restTemplate).execute(
                eq("http://localhost:8080/documents/" + documentId + "/body"),
                eq(HttpMethod.GET),
                any(),
                any()
        );

        ResponseEntity<InputStreamResource> response = externalService.getAttachmentByUrl(documentId);

        assertNotNull(response);
        assertEquals(MediaType.APPLICATION_OCTET_STREAM, response.getHeaders().getContentType());
    }

    @Test
    void testGetAttachmentByUrl_Non200_ReturnsNull() throws IOException {
        String documentId = "noContent";
        ByteArrayInputStream inputStream = new ByteArrayInputStream("ignored".getBytes());
        InputStreamResource resource = new InputStreamResource(inputStream);

        HttpHeaders headers = new HttpHeaders();
        ResponseEntity<InputStreamResource> responseEntity =
                new ResponseEntity<>(resource, headers, HttpStatus.NO_CONTENT);

        when(restTemplate.execute(
                eq("http://localhost:8080/documents/" + documentId + "/body"),
                eq(HttpMethod.GET),
                any(),
                any())
        ).thenReturn(responseEntity);

        ResponseEntity<InputStreamResource> response = externalService.getAttachmentByUrl(documentId);
        assertNull(response);
    }

    @Test
    void testGetHtmlResponseByHon() {
        String hon = "HON123";
        String response = externalService.getHtmlResponseByHon(hon);
        assertEquals("<html><body><h2>Rendering Html response</h2></body></html>", response);
    }
}
