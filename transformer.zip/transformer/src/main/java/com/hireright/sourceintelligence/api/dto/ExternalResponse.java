package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ExternalResponse {

    @JsonProperty("AuthenticationMode")
    private String authenticationMode;

    @JsonProperty("DesignNr")
    private int designNr;

    @JsonProperty("DomainId")
    private String domainId;

    @JsonProperty("ParametersList")
    private ParametersList parametersList;

    @JsonProperty("RedirectUrl")
    private String redirectUrl;

    @JsonProperty("UserClass")
    private String userClass;

    @JsonProperty("UserId")
    private String userId;
}
