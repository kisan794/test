package hireright.applications.permissions_api.rest.server;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-16  HRG-330191 initial version
 */

import hireright.applications.permissions_api.api.IPermissionsApiProvider;
import hireright.applications.permissions_api.api.management.IOperatorManager;
import hireright.applications.permissions_api.model.CCollection;
import hireright.applications.permissions_api.model.COperator;
import hireright.applications.permissions_api.model.COperatorFilter;
import hireright.applications.permissions_api.model.COperatorResource;
import hireright.applications.permissions_api.model.COperatorResources;
import hireright.applications.permissions_api.model.CSort;
import hireright.sdk.util.CStringUtils;
import hireright.spring.transaction.db.ReadOnlyTransaction;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class COperatorController extends CAbstractController implements OperatorApi
{
	public COperatorController(IPermissionsApiProvider apiProvider)
	{
		super(apiProvider);
	}

	@Override
	@ReadOnlyTransaction
	@RequestMapping(value = "/operators/{reference:.+}",
		produces = { "application/json; charset=utf-8" }, method = RequestMethod.GET)
	public ResponseEntity<COperatorResource> getOperator(String sReference)
	{
		IOperatorManager manager = getApi().getOperatorManager();

		COperator record = manager.get(sReference);

		COperatorResource.Builder response = new COperatorResource.Builder();
		response.data(record);

		return ResponseEntity.ok().body(response.build());
	}

	@Override
	@ReadOnlyTransaction
	public ResponseEntity<COperatorResources> getOperators(Long lOffset, Integer nLimit,
		String sSort, String sOrder, String sPermission)
	{
		IOperatorManager manager = getApi().getOperatorManager();

		CSort<COperator.EField> sort;
		if(!CStringUtils.isEmpty(sSort) && !CStringUtils.isEmpty(sOrder))
		{
			sort = new CSort<>(COperator.EField.fromValue(sSort), CSort.EOrder.fromValue(sOrder));
		}
		else
		{
			sort = manager.getDefaultSort();
		}

		COperatorFilter.Builder filter = new COperatorFilter.Builder();
		filter.permission(sPermission);

		CCollection<COperator> records = manager.list(lOffset, nLimit, sort, filter.build());

		COperatorResources.Builder response = new COperatorResources.Builder();

		response.data(records.getItems());
		response.offset(records.getOffset());
		response.limit(records.getLimit());
		response.total(records.getTotal());

		return ResponseEntity.ok().body(response.build());
	}
}
