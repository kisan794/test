package com.hireright.sourceintelligence.api.dto.optool;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AttachmentDTO {
    private String id;
    private String title;
    private String filename;
    private String formatFilesize;
    private String size;
}
