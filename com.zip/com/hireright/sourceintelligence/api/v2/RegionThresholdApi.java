package com.hireright.sourceintelligence.api.v2;

import com.hireright.sourceintelligence.api.v2.dto.RegionThresholdDTO;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;


import java.io.IOException;

import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.*;
import static com.hireright.sourceintelligence.api.ApiConstants.SearchParams.REGION_THRESHOLDS;

@RequestMapping(value = BASE_SI_SERVICE_V2_API_PATH)
@Tag(name = "RegionThreshold", description = "Endpoints for managing Region Thresholds")
public interface RegionThresholdApi {

    @ResponseStatus(HttpStatus.OK)
    @GetMapping(value = REGION_THRESHOLDS,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<RegionThresholdDTO> getRegions();

    @ResponseStatus(HttpStatus.OK)
    @PutMapping(value = REGION_THRESHOLDS,
            consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<RegionThresholdDTO> updateRegions(
            @Valid @RequestBody RegionThresholdDTO thresholdDTO);
}
