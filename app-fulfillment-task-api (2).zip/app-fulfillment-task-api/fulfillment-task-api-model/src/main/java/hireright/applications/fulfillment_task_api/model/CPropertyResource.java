package hireright.applications.fulfillment_task_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-25  ATS-1045 initial version
 */

public class CPropertyResource extends CResource<Void, CProperty> {
    private CPropertyResource() {
        super();
    }

    protected CPropertyResource(Builder builder) {
        super(builder);
    }

    @Override
    public String toString() {
        return "CPropertyResource{} " + super.toString();
    }

    public static class Builder extends CResource.Builder<Void, CProperty> {
        public Builder() {
            super();
        }

        public Builder(CResource<Void, CProperty> copy) {
            super(copy);
        }

        public Builder(CPropertyResource copy) {
            super(copy);
        }

        @Override
        public CPropertyResource build() {
            super.build();
            kind(EKind.PROPERTY);
            return new CPropertyResource(this);
        }
    }
}
