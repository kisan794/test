package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.AutoMatchDTO;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchResponseDTO;

public interface AutoMatchRegionService {

    AutoMatchResponseDTO autoMatch(AutoMatchDTO inputData);
}
