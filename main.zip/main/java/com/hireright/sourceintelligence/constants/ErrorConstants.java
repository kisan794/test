package com.hireright.sourceintelligence.constants;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.MEDIUM;

import lombok.Getter;


@Getter
public enum ErrorConstants {

    //400: Bad Request
    HON_MISSING_IN_REQUEST("109_40001", "LOW", "HON cannot be null or empty."),
    INACTIVE_SOURCE("109_40002", "LOW", "Cannot update. SourceOrganization %s is Inactive."),
    DATE_RANGE_MISSING("109_40003","LOW","Date range in change log filters cannot be null or empty."),
    SEARCH_TEXT_MISSING("109_40004","LOW", "Search text/phrase missing in request payload. Kindly provide search text/phrase."),
    SEARCH_NOT_SUPPORTED("109_40005","LOW", "Search not supported by the provided filter: %s."),
    INVALID_SORT("109_40006", "LOW", "Provided property %s to sort is invalid. Valid property to sort should be one of these:organizationName, location, primaryContact, validated, lastActive."),
    VALIDATION_FAILURE("109_40007", "HIGH", "Error Message: %s."),
    UNKNOWN_ORGANIZATION("109_40008","LOW","Hon Generator: Unknown Organization Type."),
    INVALID_OFFSET("109_40009","LOW","Offset index must not be less than zero!"),
    INVALID_LIMIT("109_40010","LOW","Limit must not be less than one!"),
    SOURCE_SEARCH_KEY_MISSING("109_40011", "LOW", "Source search key cannot be null or empty."),
    CONFIDENCE_THRESHOLD_ERROR("109_40012","LOW","Confidence threshold provided is %s and it should not be less than 90 and greater than 100"),
    COUNTRY_MISSING("109_40013","LOW","Country must be provided with city or state to search"),
    //403: Forbidden
    USER_UNAUTHORIZED("109_40301",MEDIUM,"User not authorised to create or update the source." ),
    LIMIT_VALIDATION_FAILURE("109_40014","LOW","List must not be greater than hundred"),
    UNKNOWN_SEARCH("109_40015","LOW","Unknown Search: Given search is not found."),
    INVALID_SOURCE_ID("109_40016","LOW","Unknown SourceId: SourceId should be hon:version!"),
    INVALID_SOURCE("109_40017","LOW","Unknown Source: Source must be either educators or employers"),
    INVALID_INPUT("109_40017","LOW","Unknown Input, provide proper input details"),
    INVALID_ACTION_REQUEST("109_40016","LOW","Invalid request or action"),
    //404: Not Found
    CONTACT_NOT_FOUND("109_40401", "LOW", "No contact found for organizationType %s."),
    ADDRESS_NOT_FOUND("109_40410", "LOW", "No address found for organizationType %s."),
    NO_DATA_FOUND("109_40402", "LOW", "No data found for page number(startIndex): %s, totalItems available: %s, total allowed pages: %s for batchSize: %s."),
    NO_SEARCH_RESULT_FOUND("109_40403", "LOW", "No search result found for search text: %s."),
    NO_SEARCH_FOUND_WITH_FILTERS("109_40404", "LOW", "No results found for the applied filters %s."),
    NO_CHILD_FOUND_WITH_FILTERS("109_40404", "LOW", "No results found for the applied filters %s."),
    SOURCE_NOT_FOUND("109_40405","LOW" ,"Source organization not found with HON: %s." ),
    SOURCE_ALREADY_IN_PROGRESS("109_40405","LOW" ,"One of the Source organization already in progress with HON: %s." ),
    SOURCE_VERSION_NOT_FOUND("109_40406","LOW" ,"Source organization not found with HON: %s and version: %s." ),

    //409: Conflict
    HON_ALREADY_EXISTS("109_40901", MEDIUM, "Hon: %s already exists. Cannot create SourceOrganization."),
    SOURCE_ALREADY_EXISTS("109_40902", MEDIUM, "Source with hon %s has similar details. Please provide the unique details."),
    SOURCE_STATUS_ALREADY_EXISTS("109_4091002", MEDIUM, "Source status is already %s."),
    SOURCE_STATUS_ERROR("109_4091003", MEDIUM, "Source should be APPROVED to perform this action, Unable to update the source status"),
    SOURCE_ACTIVATE_ERROR("109_4091003", MEDIUM, "Activation of Source feature is not in the scope"),
    PARENT_SOURCE_STATUS_ERROR("109_4091004", MEDIUM, "Child source should be deleted before deleting the source, Unable to delete the source"),
    PARENT_SOURCE_INUNDATION_ERROR("109_4091008", MEDIUM, "Parent source cannot be updated to child before discarding its child sources, Unable to update the source"),
    SOURCE_UPDATE_ERROR("109_4091005", MEDIUM, "Source should be APPROVED to perform this action, Unable to update the source"),

    //500: Internal Server Error
    PARSE_FAILED("109_50001", "HIGH", "Failed to parse source. %s"),
    FAILED_TO_MAP("109_50002" ,"HIGH", "Failed to map one object to another due to failure on parsing."),
    DATA_ACCESS_ERROR("109_50003", "HIGH", "Mongo exception, Unable to access mongo data."),
    UNEXPECTED_VALUE_FOUND("109_50004", "HIGH","Unexpected value found in search highlight field path." ),
    UNABLE_TO_INSERT_SOURCE("109_50005", "HIGH", "Mongo exception, Unable to insert %s Error Message: %s."),
    UNABLE_TO_UPDATE_SOURCE("109_50006", "HIGH", "Mongo exception, Unable to update sources with hons: %s."),
    UNABLE_TO_SAVE_SOURCE("109_50007", "HIGH", "Mongo exception, Unable to save %s Error Message: %s."),
    UNABLE_TO_CREATE_SOURCE("109_50008", "HIGH", "Exception, Unable to create %s Error Message: %s."),
    CREATE_SOURCE_ERROR("401_00001", "HIGH", "Exception, Unable to create %s Error Message: %s."),
    UPDATE_SOURCE_ERROR("401_00002", "HIGH", "Exception, Unable to update %s Error Message: %s."),
    DELETE_SOURCE_ERROR("401_00003", "HIGH", "Exception, Unable to delete %s Error Message: %s."),

    INTERNAL_SERVER_ERROR("110_60001", "HIGH","Internal server error occurred. Please contact system administrator."),

    UNABLE_TO_GET_USER_DETAILS("109_50009", "HIGH", "Failed to get user details from user account service for username: %s."),
    FAILED_TO_CREATE_HON("109_50010","HIGH" ,"Failed to create hon." ),
    FAILED_TO_GET_HON("109_50021","HIGH" ,"Hon is missing for View/Edit." ),
    FAILED_TO_FIND_PARENT_HON("109_500101","HIGH" ,"Failed to find parent hon." ),
    FAILED_TO_PARSE_DEPARTMENT_ALIASES("109_50011","HIGH" ,"Failed to parse department aliases" ),
    FAILED_TO_PUBLISH_TO_TOPIC("109_50012", "HIGH", "Unable to publish to kafka topic  %s."),
    FAILED_TO_UPLOAD_DOCUMENT("109_50013", "HIGH", "External service is not available please try after sometime"),
    FAILED_TO_DELETE_DOCUMENT("109_50014", "HIGH", "Unable to delete file"),
    FAILED_TO_DOWNLOAD_DOCUMENT("109_50014", "HIGH", "Unable to download file"),
    FAILED_TO_CONNET_EXTERNAL_API("109_50015", "HIGH", "Unable to connect external API"),
    FAILED_TO_PARSE_PERMISSIONS("109_50016", "HIGH", "Unable to parse permissions"),
    FAILED_TO_APPROVERS("109_50017", "HIGH", "Unable to parse approvers group list"),
    REGION_THRESHOLD_NOT_FOUND("109_40415","LOW" ,"Region Threshold not found with threshold type %s" ),
    REGION_NOT_FOUND("109_40415","LOW" ,"Region should not be blank" ),
    PERMISSIONS_NOT_FOUND("109_40416","LOW" ,"Permissions not found for the user: %s." ),
    ACCESS_DENIED_ERROR("403","LOW","Access denied: User %s does not have the required permissions to view SIDB portal. Please contact the administrator for assistance."),


    //Elasticsearch exceptions
    UNABLE_TO_CREATE_ES_SOURCE("109_60001", "HIGH", "Elasticsearch exception, Unable to create source %s");

    private final String code;
    private final String severity;
    private final String message;

    ErrorConstants(String code, String severity, String message) {
        this.code = code;
        this.severity = severity;
        this.message = message;

    }
}
