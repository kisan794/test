package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.v2.dto.RegionThresholdDTO;
import com.hireright.sourceintelligence.service.RegionThresholdService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequiredArgsConstructor
@Validated
@Slf4j
@CrossOrigin
public class RegionThresholdApiController implements RegionThresholdApi {

    private final RegionThresholdService regionThresholdService;

    @Override
    public ResponseEntity<RegionThresholdDTO> getRegions() {
        return ResponseEntity.ok(regionThresholdService.getRegions());
    }

    @Override
    public ResponseEntity<RegionThresholdDTO> updateRegions(RegionThresholdDTO thresholdDTO) {
        RegionThresholdDTO updatedResult = regionThresholdService.updateRegionThreshold(thresholdDTO);
        return ResponseEntity.ok(updatedResult);
    }
}
