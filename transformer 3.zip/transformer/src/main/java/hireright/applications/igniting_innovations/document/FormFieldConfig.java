package hireright.applications.igniting_innovations.document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;

/**
 * MongoDB document for storing form field configuration metadata.
 * This allows dynamic management of dropdown options, checkboxes, and other form field configurations.
 *
 * @author Generated
 * @version 1.0
 */
@Document(collection = "form_field_configs")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FormFieldConfig {

    @Id
    private String id;

    /**
     * Unique identifier for the field (e.g., "impactAreas", "improvementTypes", "implementationComplexity")
     */
    @Indexed(unique = true)
    private String fieldKey;

    /**
     * List of options for the field
     */
    private List<FieldOption> options;

    /**
     * Created timestamp
     */
    private LocalDateTime createdAt;

    /**
     * Last updated timestamp
     */
    private LocalDateTime updatedAt;

    /**
     * Field option inner class
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FieldOption {
        /**
         * Option value (stored in database)
         */
        private String value;

        /**
         * Option label (displayed to user)
         */
        private String label;
    }
}

