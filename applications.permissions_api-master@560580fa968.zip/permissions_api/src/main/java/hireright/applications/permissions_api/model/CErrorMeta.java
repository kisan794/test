package hireright.applications.permissions_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-16  HRG-330191 initial version
 */

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Objects;

public class CErrorMeta
{
	@JsonProperty("path")
	private String m_sPath;

	@JsonProperty("id")
	private String m_sID;

	@JsonProperty("details")
	private String m_sDetails;

	private CErrorMeta()
	{
	}

	private CErrorMeta(Builder builder)
	{
		m_sPath = builder.m_sPath;
		m_sID = builder.m_sID;
		m_sDetails = builder.m_sDetails;
	}

	public String getPath()
	{
		return m_sPath;
	}

	public String getID()
	{
		return m_sID;
	}

	public String getDetails()
	{
		return m_sDetails;
	}

	@Override
	public boolean equals(Object o)
	{
		if(this == o)
		{
			return true;
		}
		if(o == null || getClass() != o.getClass())
		{
			return false;
		}

		CErrorMeta that = (CErrorMeta) o;

		if(!Objects.equals(m_sPath, that.m_sPath))
		{
			return false;
		}
		if(!Objects.equals(m_sID, that.m_sID))
		{
			return false;
		}
		return Objects.equals(m_sDetails, that.m_sDetails);
	}

	@Override
	public int hashCode()
	{
		int result = m_sPath != null ? m_sPath.hashCode() : 0;
		result = 31 * result + (m_sID != null ? m_sID.hashCode() : 0);
		result = 31 * result + (m_sDetails != null ? m_sDetails.hashCode() : 0);
		return result;
	}

	@Override
	public String toString()
	{
		return "CErrorMeta{" + "m_sPath='" + m_sPath + '\'' + ", m_sID='" + m_sID + '\''
			+ ", m_sDetails='" + m_sDetails + '\'' + '}';
	}

	public static final class Builder
	{
		private String m_sPath;
		private String m_sID;
		private String m_sDetails;

		public Builder()
		{
		}

		public Builder(CErrorMeta copy)
		{
			this.m_sPath = copy.getPath();
			this.m_sID = copy.getID();
			this.m_sDetails = copy.getDetails();
		}

		public Builder path(String sPath)
		{
			this.m_sPath = sPath;
			return this;
		}

		public Builder id(String sID)
		{
			this.m_sID = sID;
			return this;
		}

		public Builder details(String sDetails)
		{
			this.m_sDetails = sDetails;
			return this;
		}

		public CErrorMeta build()
		{
			return new CErrorMeta(this);
		}
	}
}
