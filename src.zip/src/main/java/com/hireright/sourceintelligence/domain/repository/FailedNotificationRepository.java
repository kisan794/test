package com.hireright.sourceintelligence.domain.repository;

import com.hireright.sourceintelligence.domain.entity.FailedNotification;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Repository for FailedNotification entities.
 * Follows Interface Segregation Principle - defines only required operations.
 */
@Repository
public interface FailedNotificationRepository extends MongoRepository<FailedNotification, String> {
    
    /**
     * Finds all notifications that can be retried
     * (not permanent failures, within retry count, and due for retry)
     */
    @Query("{ 'permanentFailure': false, 'retryCount': { $lt: ?0 }, " +
           "'nextRetryAt': { $lt: ?1 } }")
    List<FailedNotification> findRetryableNotifications(int maxRetries, LocalDateTime now);
    
    /**
     * Finds all permanent failures for monitoring/alerting
     */
    List<FailedNotification> findByPermanentFailureTrue();
    
    /**
     * Finds failed notifications by notification ID
     */
    Optional<FailedNotification> findByNotificationId(String notificationId);
    
    /**
     * Finds failed notifications by request ID
     */
    List<FailedNotification> findByRequestId(String requestId);
    
    /**
     * Counts permanent failures
     */
    long countByPermanentFailureTrue();
    
    /**
     * Deletes old permanent failures (for cleanup)
     */
    void deleteByPermanentFailureTrueAndCreatedAtBefore(LocalDateTime before);
}

