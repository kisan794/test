package com.hireright.sourceintelligence.reports.service.impl;

import com.hireright.sourceintelligence.reports.dto.MetaDTO;
import com.hireright.sourceintelligence.reports.dto.NestedMetaDTO;

import java.util.ArrayList;
import java.util.List;

public class SourceInformationMetaUtils {

    private static final String HEADER_OPERATOR_NAME = "Operator Name";
    private static final String HEADER_IN_PROGRESS = "In Progress";
    private static final String HEADER_ON_HOLD = "On Hold";
    private static final String HEADER_REJECTED = "Rejected";
    private static final String HEADER_COMPLETED = "Completed";
    private static final String HEADER_TOTAL = "Total";

    private SourceInformationMetaUtils() {
    }

    public static List<NestedMetaDTO> getOperatorMetadata() {
        List<NestedMetaDTO> metaList = new ArrayList<>();

        metaList.add(NestedMetaDTO.builder()
                .header(HEADER_OPERATOR_NAME)
                .accessorKey("Operator_Name")
                .build());

        List<NestedMetaDTO> addedColumns = new ArrayList<>();
        addedColumns.add(NestedMetaDTO.builder().header("New").accessorKey("added.new").build());
        addedColumns.add(NestedMetaDTO.builder().header(HEADER_IN_PROGRESS).accessorKey("added.inProgress").build());
        addedColumns.add(NestedMetaDTO.builder().header(HEADER_ON_HOLD).accessorKey("added.onHold").build());
        addedColumns.add(NestedMetaDTO.builder().header(HEADER_REJECTED).accessorKey("added.cancelled").build());
        addedColumns.add(NestedMetaDTO.builder().header(HEADER_COMPLETED).accessorKey("added.completed").build());
        addedColumns.add(NestedMetaDTO.builder().header(HEADER_TOTAL).accessorKey("added.total").build());

        metaList.add(NestedMetaDTO.builder()
                .header("Added")
                .accessorKey("added")
                .columns(addedColumns)
                .build());

        List<NestedMetaDTO> changedColumns = new ArrayList<>();
        changedColumns.add(NestedMetaDTO.builder().header("New").accessorKey("changed.new").build());
        changedColumns.add(NestedMetaDTO.builder().header(HEADER_IN_PROGRESS).accessorKey("changed.inProgress").build());
        changedColumns.add(NestedMetaDTO.builder().header(HEADER_ON_HOLD).accessorKey("changed.onHold").build());
        changedColumns.add(NestedMetaDTO.builder().header(HEADER_REJECTED).accessorKey("changed.cancelled").build());
        changedColumns.add(NestedMetaDTO.builder().header(HEADER_COMPLETED).accessorKey("changed.completed").build());
        changedColumns.add(NestedMetaDTO.builder().header(HEADER_TOTAL).accessorKey("changed.total").build());

        metaList.add(NestedMetaDTO.builder()
                .header("Changed")
                .accessorKey("changed")
                .columns(changedColumns)
                .build());

        List<NestedMetaDTO> archivedColumns = new ArrayList<>();
        archivedColumns.add(NestedMetaDTO.builder().header("New").accessorKey("archived.new").build());
        archivedColumns.add(NestedMetaDTO.builder().header(HEADER_IN_PROGRESS).accessorKey("archived.inProgress").build());
        archivedColumns.add(NestedMetaDTO.builder().header(HEADER_ON_HOLD).accessorKey("archived.onHold").build());
        archivedColumns.add(NestedMetaDTO.builder().header(HEADER_REJECTED).accessorKey("archived.cancelled").build());
        archivedColumns.add(NestedMetaDTO.builder().header(HEADER_COMPLETED).accessorKey("archived.completed").build());
        archivedColumns.add(NestedMetaDTO.builder().header(HEADER_TOTAL).accessorKey("archived.total").build());

        metaList.add(NestedMetaDTO.builder()
                .header("Archived")
                .accessorKey("archived")
                .columns(archivedColumns)
                .build());

        List<NestedMetaDTO> deletedColumns = new ArrayList<>();
        deletedColumns.add(NestedMetaDTO.builder().header("New").accessorKey("deleted.new").build());
        deletedColumns.add(NestedMetaDTO.builder().header(HEADER_IN_PROGRESS).accessorKey("deleted.inProgress").build());
        deletedColumns.add(NestedMetaDTO.builder().header(HEADER_ON_HOLD).accessorKey("deleted.onHold").build());
        deletedColumns.add(NestedMetaDTO.builder().header(HEADER_REJECTED).accessorKey("deleted.cancelled").build());
        deletedColumns.add(NestedMetaDTO.builder().header(HEADER_COMPLETED).accessorKey("deleted.completed").build());
        deletedColumns.add(NestedMetaDTO.builder().header(HEADER_TOTAL).accessorKey("deleted.total").build());

        metaList.add(NestedMetaDTO.builder()
                .header("Deleted")
                .accessorKey("deleted")
                .columns(deletedColumns)
                .build());

        metaList.add(NestedMetaDTO.builder()
                .header(HEADER_TOTAL)
                .accessorKey(HEADER_TOTAL)
                .build());

        return metaList;
    }

    public static List<MetaDTO> getReviewerMetadata() {
        List<MetaDTO> metaDTOList = new ArrayList<>();
        metaDTOList.add(new MetaDTO(HEADER_OPERATOR_NAME, "Researcher_Name"));
        metaDTOList.add(new MetaDTO("New", "New"));
        metaDTOList.add(new MetaDTO(HEADER_IN_PROGRESS, "In_Progress"));
        metaDTOList.add(new MetaDTO(HEADER_ON_HOLD, "On_Hold"));
        metaDTOList.add(new MetaDTO(HEADER_REJECTED, "Cancelled"));
        metaDTOList.add(new MetaDTO(HEADER_COMPLETED, "Completed"));
        metaDTOList.add(new MetaDTO(HEADER_TOTAL, HEADER_TOTAL));
        return metaDTOList;
    }

    public static List<MetaDTO> getOperatorAndReviewerMetadata() {
        List<MetaDTO> metaDTOList = new ArrayList<>();
        metaDTOList.add(new MetaDTO(HEADER_OPERATOR_NAME, "Researcher_Name"));
        metaDTOList.add(new MetaDTO("Added new organizations as originator", "Added"));
        metaDTOList.add(new MetaDTO("Changed new organizations as originator", "Changed"));
        metaDTOList.add(new MetaDTO("Deactivated new organizations as originator", "Archived"));
        metaDTOList.add(new MetaDTO("Deleted new organizations as originator", "Deleted"));
        metaDTOList.add(new MetaDTO("Has Organizations in status 'NEW' as reviewer", "New"));
        metaDTOList.add(new MetaDTO("Has Organizations in status 'IN PROGRESS' as reviewer", "In_Progress"));
        metaDTOList.add(new MetaDTO("Has Organizations in status 'ON HOLD' as reviewer", "On_Hold"));
        metaDTOList.add(new MetaDTO("Has Organizations in status 'CANCELLED' as reviewer", "Cancelled"));
        metaDTOList.add(new MetaDTO("Has Organizations in status 'COMPLETED' as reviewer", "Completed"));
        metaDTOList.add(new MetaDTO(HEADER_TOTAL, HEADER_TOTAL));
        return metaDTOList;
    }
}