package com.hireright.sourceintelligence.service.impl.helperservices;

import com.hireright.sourceintelligence.api.dto.ApprovalRequestDTO;
import com.hireright.sourceintelligence.api.dto.AssignSourceDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.reports.dto.ReportsDTO;
import com.hireright.sourceintelligence.reports.service.ReportDataService;
import com.mongodb.BasicDBObject;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.bson.Document;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.SIDB_APPROVAL_FLOW;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.IN_PROGRESS;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.ADDITIONAL_INFO;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.VERIFICATION_VALIDATION_DATE;

@Slf4j
@RequiredArgsConstructor
@Service
public class ReportDataUtils {

    private final ReportDataService reportDataService;

    public void reportData(Source entityFromDb, String action, String origin, int autoMatch, String reason) {
        ReportsDTO reportsDTO = new ReportsDTO();
        reportsDTO.setHon(entityFromDb.getHon());
        reportsDTO.setAction(action);
        reportsDTO.setAddress(entityFromDb.getCountry() + "," + entityFromDb.getState() + "," + entityFromDb.getCity());
        reportsDTO.setOrganizationName(entityFromDb.getOrganizationName());
        reportsDTO.setOrganizationType(entityFromDb.getOrganizationType().getType());
        reportsDTO.setCreatedBy(entityFromDb.getCreatedBy());
        reportsDTO.setOrigin(origin);
        reportsDTO.setApprovalStatus(entityFromDb.getApprovalStatus().getStatus());
        //Deleted by considered as approvedBy and approvedId
        reportsDTO.setApprovedBy(entityFromDb.getAssignedTo());
        reportsDTO.setApprovedId(entityFromDb.getAssignedId());
        reportsDTO.setAutoMatch(autoMatch);
        reportsDTO.setReason(reason);
        ArrayList<Object> additionalInfo = (ArrayList<Object>) entityFromDb.getPayload().get(ADDITIONAL_INFO);
        if (!ObjectUtils.isEmpty(additionalInfo) && !ObjectUtils.isEmpty(additionalInfo.get(0))) {
            Object firstElement = additionalInfo.get(0);
            String verificationValidationDate = null;
            log.info("firstElement: {}", firstElement.getClass());
            if (firstElement instanceof BasicDBObject) {
                BasicDBObject basicDBObject = (BasicDBObject) firstElement;
                verificationValidationDate = basicDBObject.getString(VERIFICATION_VALIDATION_DATE);
            } else if (firstElement instanceof Document) {
                Document document = (Document) firstElement;
                verificationValidationDate = document.getString(VERIFICATION_VALIDATION_DATE);
            } else if (firstElement instanceof Map) {
                Map<String, Object> map = (Map<String, Object>) firstElement;
                verificationValidationDate = (String) map.get(VERIFICATION_VALIDATION_DATE);
            }
            if (verificationValidationDate != null) {
                reportsDTO.setVerificationValidationDate(verificationValidationDate);
            }
        }
        reportDataService.createData(reportsDTO);
    }

    public void createReportData(ApprovalRequestDTO approvalRequestDTO, List<String> hons) {
        for (AssignSourceDTO assignSourceDTO : approvalRequestDTO.getSourceDetails()) {
            if (hons.contains(assignSourceDTO.getHon())) {
                ReportsDTO reportsDTO = new ReportsDTO();
                reportsDTO.setHon(assignSourceDTO.getHon());
                reportsDTO.setOrganizationName(assignSourceDTO.getOrganizationName());
                reportsDTO.setApprovalStatus(IN_PROGRESS.getStatus());
                reportsDTO.setApprovedBy(approvalRequestDTO.getApproverName());
                reportsDTO.setCreatedBy(assignSourceDTO.getCreatedBy());
                reportsDTO.setOrigin(SIDB_APPROVAL_FLOW);
                reportsDTO.setAction("");
                reportDataService.createData(reportsDTO);
            }
        }
    }
}
