package com.hireright.sourceintelligence.service.notification;

import com.hireright.sourceintelligence.api.dto.notification.NotificationRequestDTO;
import com.hireright.sourceintelligence.exception.NotificationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Factory for selecting the appropriate notification service based on request type.
 * Follows Factory Pattern and Strategy Pattern.
 * Follows Open/Closed Principle - new notification types can be added without modifying this class.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class NotificationServiceFactory {
    
    private final List<NotificationService> notificationServices;
    
    /**
     * Gets the appropriate notification service for the given request
     *
     * @param request the notification request
     * @return the notification service that supports the request type
     * @throws NotificationException if no service supports the request type
     */
    public NotificationService getService(NotificationRequestDTO request) {
        log.debug("Finding notification service for type: {}", request.getNotificationType());
        
        return notificationServices.stream()
                .filter(service -> service.supports(request))
                .findFirst()
                .orElseThrow(() -> new NotificationException(
                        String.format("Unsupported notification type: %s", request.getNotificationType()),
                        "UNSUPPORTED_NOTIFICATION_TYPE"
                ));
    }
}

