/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.config.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.ErrorResponse;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * Unit tests for ApiVersionValidationFilter
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("ApiVersionValidationFilter Tests")
class ApiVersionValidationFilterTest
{

	@Mock
	private FilterChain filterChain;

	private ApiVersionValidationFilter filter;
	private ObjectMapper objectMapper;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;

	@BeforeEach
	void setUp()
	{
		objectMapper = new ObjectMapper();
		filter = new ApiVersionValidationFilter(objectMapper);

		// Set default configuration values using reflection
		org.springframework.test.util.ReflectionTestUtils.setField(filter,
			"supportedVersionsConfig", "v1,v2");
		org.springframework.test.util.ReflectionTestUtils.setField(filter, "latestVersion", "v2");

		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();
	}

	@Test
	@DisplayName("Should allow request with supported version v1")
	void testSupportedVersionV1() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/fulfillment_task_api/v1/recombo/results");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(filterChain, times(1)).doFilter(request, response);
		assertEquals(200, response.getStatus());
	}

	@Test
	@DisplayName("Should allow request with supported version v2")
	void testSupportedVersionV2() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/fulfillment_task_api/v2/recombo/results");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(filterChain, times(1)).doFilter(request, response);
		assertEquals(200, response.getStatus());
	}

	@Test
	@DisplayName("Should reject request with unsupported version v3")
	void testUnsupportedVersionV3() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/fulfillment_task_api/v3/recombo/results");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(filterChain, never()).doFilter(request, response);
		assertEquals(400, response.getStatus());
		assertEquals(MediaType.APPLICATION_JSON_VALUE, response.getContentType());

		// Verify error response
		String responseBody = response.getContentAsString();
		assertNotNull(responseBody);
		assertTrue(responseBody.contains("UNSUPPORTED_API_VERSION"));
		assertTrue(responseBody.contains("v3"));
	}

	@Test
	@DisplayName("Should reject request with unsupported version v0")
	void testUnsupportedVersionV0() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/fulfillment_task_api/v0/recombo/results");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(filterChain, never()).doFilter(request, response);
		assertEquals(400, response.getStatus());
	}

	@Test
	@DisplayName("Should skip validation for actuator endpoints")
	void testSkipValidationForActuator() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/fulfillment_task_api/actuator/health");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(filterChain, times(1)).doFilter(request, response);
		assertEquals(200, response.getStatus());
	}

	@Test
	@DisplayName("Should skip validation for health endpoints")
	void testSkipValidationForHealth() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/fulfillment_task_api/health");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(filterChain, times(1)).doFilter(request, response);
	}

	@Test
	@DisplayName("Should skip validation for swagger endpoints")
	void testSkipValidationForSwagger() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/swagger-ui/index.html");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(filterChain, times(1)).doFilter(request, response);
	}

	@Test
	@DisplayName("Should skip validation for api-docs endpoints")
	void testSkipValidationForApiDocs() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/v3/api-docs");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(filterChain, times(1)).doFilter(request, response);
	}

	@Test
	@DisplayName("Should skip validation for root path")
	void testSkipValidationForRootPath() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(filterChain, times(1)).doFilter(request, response);
	}

	@Test
	@DisplayName("Should handle path with version and nested resources")
	void testVersionWithNestedResources() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/fulfillment_task_api/v1/recombo/results/123/details");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(filterChain, times(1)).doFilter(request, response);
	}

	@Test
	@DisplayName("Should return proper error response structure for unsupported version")
	void testErrorResponseStructure() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/fulfillment_task_api/v5/recombo/results");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		assertEquals(400, response.getStatus());
		String responseBody = response.getContentAsString();

		ErrorResponse errorResponse = objectMapper.readValue(responseBody, ErrorResponse.class);
		assertNotNull(errorResponse);
		assertEquals("Error.UnsupportedVersion", errorResponse.getType());
		assertNotNull(errorResponse.getId());
		assertEquals(400, errorResponse.getData().getStatus());
		assertEquals("UNSUPPORTED_API_VERSION", errorResponse.getData().getErrorCode());
		assertTrue(errorResponse.getData().getMessage().contains("v5"));
		assertTrue(errorResponse.getData().getMessage().contains("v2"));
	}

	@Test
	@DisplayName("Should handle single supported version configuration")
	void testSingleSupportedVersion() throws ServletException, IOException
	{
		// Given
		org.springframework.test.util.ReflectionTestUtils.setField(filter,
			"supportedVersionsConfig", "v1");
		request.setRequestURI("/fulfillment_task_api/v1/recombo/results");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(filterChain, times(1)).doFilter(request, response);
	}

	@Test
	@DisplayName("Should reject when single supported version doesn't match")
	void testSingleSupportedVersionMismatch() throws ServletException, IOException
	{
		// Given
		org.springframework.test.util.ReflectionTestUtils.setField(filter,
			"supportedVersionsConfig", "v1");
		request.setRequestURI("/fulfillment_task_api/v2/recombo/results");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(filterChain, never()).doFilter(request, response);
		assertEquals(400, response.getStatus());
	}

	@Test
	@DisplayName("Should handle path without version gracefully")
	void testPathWithoutVersion() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/fulfillment_task_api/recombo/results");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(filterChain, times(1)).doFilter(request, response);
	}

	@Test
	@DisplayName("Should handle multiple version numbers in path")
	void testMultipleVersionNumbers() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/fulfillment_task_api/v10/recombo/results");
		org.springframework.test.util.ReflectionTestUtils.setField(filter,
			"supportedVersionsConfig", "v10,v11");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(filterChain, times(1)).doFilter(request, response);
	}
}
