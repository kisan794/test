/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-07-23	Created
 *	T.Prikk			2017-08-09	HIVPE-19903: added domain ID logic to add()
 *	T.Prikk			2017-08-09	HIVPE-19903: initialize comment state in add()
 *	T.Prikk			2018-04-11	HIVPE-26547: added extractProperties()
 * 	M.Kuznetsov		2025-09-12	HRG-339332: CInstanceDomain support
 */
package hireright.applications.vendor_api.resources;

import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.stream.Collectors;

import hireright.bdk.instance_parameter.CInstanceDomain;
import hireright.bdk.instance_parameter.CInstanceDomainFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import hireright.applications.vendor_api.EExchangeDirection;
import hireright.applications.vendor_api.exchange.handler.impl.COrderServiceOpCommentExchanger;
import hireright.applications.vendor_api.exchange.handler.objects.COrderServiceEntityExchangeContext;
import hireright.applications.vendor_api.exchange.handler.utils.CExchangeUtils;
import hireright.applications.vendor_api.facades.IdValueFacade;
import hireright.applications.vendor_api.model.CExchangeResponse;
import hireright.applications.vendor_api.model.COrderServiceOperatorCommentRequest;
import hireright.applications.vendor_api.services.OrderServiceOperatorCommentService;
import hireright.components.domain.dialects.vendor_api.BasicResponse;
import hireright.components.domain.dialects.vendor_api.Comment;
import hireright.objects.order3.model.CNameValue;
import hireright.sdk.db.CMultitenantDB;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;

@RestController
public class COrderServiceOperatorCommentResource extends AResource
{
	// CREATE
	@RequestMapping(path = OrderServiceOperatorCommentService.PATH_ADD,
			method = RequestMethod.POST,
			consumes = MediaType.APPLICATION_XML_VALUE,
			produces = MediaType.APPLICATION_XML_VALUE)
	public BasicResponse add(
			@PathVariable(name=OrderServiceOperatorCommentService.VAR_ORDER_REF) final String orderReference,
			@PathVariable(name=OrderServiceOperatorCommentService.VAR_ORDER_SERVICE_REF) final String orderServiceReference,
			@RequestBody final Comment comment) throws Exception
	{
		String sTenantCode = CExchangeUtils.getTenantCodeByOrderCode(orderReference);
		
		// prepare context data
		COrderServiceEntityExchangeContext<COrderServiceOperatorCommentRequest> context =
				new COrderServiceEntityExchangeContext<COrderServiceOperatorCommentRequest>();
		
		CExchangeResponse response = CMultitenantDB.execute(sTenantCode, () -> {
			Long orderServiceID = CExchangeUtils.getOrderServiceID(orderReference, orderServiceReference);
			context.setOrderServiceID(orderServiceID);
			context.setTransferObject(transformComment(comment));
			return new COrderServiceOpCommentExchanger().doCreate(context);
		});
		// perform data operation
		return transformResponse(response, OrderServiceOperatorCommentService.EResponseParam.COMMENT_ID.name());
	}

	// UPDATE
	@RequestMapping(path = OrderServiceOperatorCommentService.PATH_UPDATE,
			method = RequestMethod.PUT,
			consumes = MediaType.APPLICATION_XML_VALUE,
			produces = MediaType.APPLICATION_XML_VALUE)
	public BasicResponse update(
			@PathVariable(name=OrderServiceOperatorCommentService.VAR_ORDER_REF) final String orderReference,
			@PathVariable(name=OrderServiceOperatorCommentService.VAR_ORDER_SERVICE_REF) final String orderServiceReference,
			@PathVariable(name=OrderServiceOperatorCommentService.VAR_COMMENT_REF) final Long commentID,
			@RequestBody final Comment comment) throws Exception
	{
		String sTenantCode = CExchangeUtils.getTenantCodeByOrderCode(orderReference);

		// prepare context data
		COrderServiceEntityExchangeContext<COrderServiceOperatorCommentRequest> context =
				new COrderServiceEntityExchangeContext<COrderServiceOperatorCommentRequest>();
		
		CExchangeResponse response = CMultitenantDB.execute(sTenantCode, () -> {
			context.setEntityID(commentID);
			context.setTransferObject(transformComment(comment));
			return new COrderServiceOpCommentExchanger().doUpdate(context);
		});
		
		// perform data operation
		return transformResponse(response, OrderServiceOperatorCommentService.EResponseParam.COMMENT_ID.name());
	}

	// DELETE
	@RequestMapping(path = OrderServiceOperatorCommentService.PATH_DELETE,
			method = RequestMethod.DELETE,
			produces = MediaType.APPLICATION_XML_VALUE)
	public BasicResponse delete(
			@PathVariable(name=OrderServiceOperatorCommentService.VAR_ORDER_REF) final String orderReference,
			@PathVariable(name=OrderServiceOperatorCommentService.VAR_ORDER_SERVICE_REF) final String orderServiceReference,
			@PathVariable(name=OrderServiceOperatorCommentService.VAR_COMMENT_REF) final Long commentID) throws Exception
	{
		String sTenantCode = CExchangeUtils.getTenantCodeByOrderCode(orderReference);

		// prepare context data
		COrderServiceEntityExchangeContext<COrderServiceOperatorCommentRequest> context =
				new COrderServiceEntityExchangeContext<COrderServiceOperatorCommentRequest>();
		CExchangeResponse response = CMultitenantDB.execute(sTenantCode, () -> {
			context.setEntityID(commentID);
			return new COrderServiceOpCommentExchanger().doDelete(context);
		});
		
		// perform data operation
		return transformResponse(response, OrderServiceOperatorCommentService.EResponseParam.COMMENT_ID.name());
	}
	
	private COrderServiceOperatorCommentRequest transformComment(Comment comment)
	{
		COrderServiceOperatorCommentRequest request = new COrderServiceOperatorCommentRequest();
		request.setCommentsCode(comment.getCode());
		request.setNationalText(comment.getText());
		request.setOperatorName(comment.getAuthor());
		if (comment.getDate() != null)
		{
			GregorianCalendar calendar = comment.getDate().toGregorianCalendar();
			request.setDate(calendar.getTime());
			request.setTimestamp(new Timestamp(calendar.getTimeInMillis()));
		}
		
		IdValueFacade references = new IdValueFacade(comment.getReferences().getIdValues());
		
		request.setProperties(extractProperties(references));
		request.setObjectRef(references.value(OrderServiceOperatorCommentService.EReferenceType.ORDER_SERVICE_OPERATOR_COMMENT.name()));
		request.setRemoteInstanceDomain(CInstanceDomainFactory.search(references.value(CInstanceDomain.PROPERTY_NATIONAL_INSTANCE_ID)));
		request.setExchangeDirection(EExchangeDirection.valueOf(references.value(EExchangeDirection.PROPERTY_NAME)));
		
		return request;
	}

	private List<CNameValue> extractProperties(IdValueFacade references)
	{
		String sPropertiesAsString = CStringUtils.nvl(references
			.value(OrderServiceOperatorCommentService.EReferenceType.PROPERTIES.name()));
		
		return new CProperties(sPropertiesAsString)
			.getMap()
			.entrySet()
			.stream()
			.map(entry ->
				{
					String sName = entry.getKey();
					String sValue = CStringUtils.EMPTY_STRING;
					
					if (entry.getValue() != null)
					{
						sValue = String.valueOf(entry.getValue());
					}
					
					return new CNameValue(sName, sValue);
				}
			)
			.collect(Collectors.toList());
	}
}
