package hireright.applications.vendor_api.resources.listener;
/*
*
* Copyright 2001-2019 by HireRight, Inc. All rights reserved.
*
* This software is the confidential and proprietary information
* of HireRight, Inc. Use is subject to license terms.
*
* History:
*	alogachyov	2019-03-05	Created
*	A.Logachyov	2021-01-11	Sanitize response from Kwikscreen to prevent invalid xml
*/

import java.util.concurrent.Callable;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import hireright.objects.datasource.CDatasourceProductFactory;
import hireright.objects.is.CMessage;
import hireright.objects.is.CMessageManager;
import hireright.objects.is.CMessagePayload;
import hireright.objects.object_resource.CObjectResource;
import hireright.objects.object_resource.CObjectResourceManager;
import hireright.objects.order.COrder;
import hireright.objects.order.COrderServiceDataSource;
import hireright.objects.order2.COrderServiceManager;
import hireright.sdk.consts.Mime;
import hireright.sdk.db2.CSessionFactory;
import hireright.sdk.db3.DB;
import hireright.sdk.debug.CDataExchangeLog;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.transform.HTMLTransformer;
import hireright.sdk.util.CDataSanitizer;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.CStringUtils;

@RestController
public class CWideScreenListener
{
	private static final String ADAPTER_ID = "KS-ASN-D";

	@RequestMapping(path = "/kwikscreen/{orderServiceCode}",
			method = RequestMethod.POST,
			consumes = MediaType.APPLICATION_JSON_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public String put(@PathVariable(name="orderServiceCode") final String sOrderServiceCode,
			@RequestBody final String sPayload)
	{
		try
		{
			DB.execute(new Callable<Void>()
			{
				@Override
				public Void call() throws Exception 
				{
					DB.requestTransaction();
					Long nOrderServiceID = getOrderServiceID(sOrderServiceCode);
					
					if (nOrderServiceID == null)
					{
						throw new CRuntimeException("Request not found");
					}
					
					String sMessagePayload = null;

					String sXMLPayload = XML.toString(new JSONObject(sPayload), "root").replace(">null<", "><");
					
					CObjectResource objectResource = CObjectResourceManager.getByTypeAndName("CUSTOMER", "COMMON", 21, "KWIKSCREEN RESPONSE");
					HTMLTransformer transformer = new HTMLTransformer(new String(objectResource.getContent()));
					
					transformer.setParameter("orderServiceID", String.valueOf(nOrderServiceID));
					sMessagePayload = transformer.transform(sXMLPayload);
				
					Document doc = DocumentHelper.parseText(sMessagePayload);
					
					Element root = doc.getRootElement();
					
					Node transactionID = root.selectSingleNode("//IdValue[@name=\"TransactionID\"]");
					
					String sTransactionID = transactionID != null ? transactionID.getStringValue() : null;
					
					String sResponseAdapter = ADAPTER_ID;

					DB.requestTransaction();
					CMessage message = new CMessage();

					if (!CStringUtils.isEmpty(sTransactionID))
					{
						final String sTmpTransID = sTransactionID;
						COrderServiceDataSource orderServiceDataSource = (COrderServiceDataSource) DB.session().createCriteria(COrderServiceDataSource.class)
							.add(Restrictions.eq("orderServiceID", nOrderServiceID))
							.list()
							.stream()
							.filter(osds-> ((COrderServiceDataSource)osds).getProperties() != null)
							.filter(osds -> sTmpTransID.equals(((COrderServiceDataSource)osds).getProperties().getProperty("transactionID"))
									&& !"COMPLETED".equals(((COrderServiceDataSource)osds).getState()))
							.findFirst()
							.orElse(null);
						
						if (orderServiceDataSource != null)
						{
							CProperties osdsProperties = orderServiceDataSource.getProperties();
							
							String dsProductID = osdsProperties.getProperty("dsProductID");
							
							
							if (CStringUtils.isNumber(dsProductID))
							{
								message.setProperty("assignedActorClass", osdsProperties.getProperty("assignedActorClass"));
								message.setProperty("assignedActorID", osdsProperties.getProperty("assignedActorID"));
								message.setProperty("orderServiceDataSourceID", String.valueOf(orderServiceDataSource.getID()));
								message.setProperty("dsProductID", dsProductID);
								message.setProperty("transactionID", sTransactionID);
								
								CProperties dsProductProperties = CDatasourceProductFactory.loadPropertiesView(Long.parseLong(dsProductID));
								
								sResponseAdapter = dsProductProperties.getProperty("RESPONSE_ADAPTER", ADAPTER_ID);
								
								String sProductSpecificTransformationName = dsProductProperties.getProperty("RESPONSE_TRANSFORMATION_OBJECT_RESOURCE_NAME");
								
								if (!CStringUtils.isEmpty(sProductSpecificTransformationName))
								{
									objectResource = CObjectResourceManager.getByTypeAndName("CUSTOMER", "COMMON", 21, sProductSpecificTransformationName);
									
									if (objectResource != null)
									{
										transformer = new HTMLTransformer(new String(objectResource.getContent()));
										
										transformer.setParameter("orderServiceID", String.valueOf(nOrderServiceID));
										sMessagePayload = transformer.transform(sXMLPayload);
									}
								}
							}
						}
					}
					
					message.setAdapterID(sResponseAdapter);
					message.setDomainID("BASE");
					message.setProperty("orderServiceID", String.valueOf(nOrderServiceID));
					message.setSubject("Kwikscreen response for " + sOrderServiceCode);
					CMessagePayload payload = new CMessagePayload();
					payload.setContentType(Mime.TEXT_XML);
					payload.setPayloadClob(CDataSanitizer.removeUnallowedUnicodeCharacters(CDataSanitizer.replace(sMessagePayload)));
					message.addPayload(payload);
					
					CMessageManager.create(message);
					
					if (sTransactionID == null)
					{
						sTransactionID = CDataExchangeLog.generateTransactionID();
						CProperties props = new CProperties();
						props.setProperty("orderServiceCode", sOrderServiceCode);
						CTraceLog.error("No 'transactionID' in payload. New 'transactionID' is " + sTransactionID,
								this.getClass().getName() + ".put()", props);
					}
					
					Node backgroundReports = root.selectSingleNode("//BackgroundReports");
					
					Element rawResponseWrapped = DocumentHelper.createElement("Response");
					
					rawResponseWrapped.addAttribute("contentType", "application/json");
					
					rawResponseWrapped.addCDATA(sPayload);
					
					/*
					 * 1. Log as is
					 */
					CDataExchangeLog.addInLog(
							sTransactionID,
							"KWIKSCREEN/2.0",
							"CONTENT PROVIDER",
							null,
							"KWIKSCREEN/2.0",
							null,
							sPayload);
					/*
					 * 2. Log wrapped in XML for log viewer 'RAW' mode
					 */
					CDataExchangeLog.addInLog(
							sTransactionID,
							"KWIKSCREEN/2.0",
							"CONTENT PROVIDER",
							null,
							"KWIKSCREEN/2.0",
							new CProperties().setProperty("Label", "Raw response from Kwikscreeen").toString(),
							rawResponseWrapped.asXML());
					/*
					 * 3. Log <BackgroundReports/> for log viewer 'INTERPRETED' mode
					 */
					CDataExchangeLog.addInLog(
							sTransactionID,
							"KWIKSCREEN/2.0",
							"CONTENT PROVIDER",
							null,
							"KWIKSCREEN/2.0",
							new CProperties().setProperty("Label", "Interpreted response from Kwikscreeen").toString(),
							backgroundReports.asXML());
					
					return null;
				}
			});


			return  "{\"status\":\"OK\"}";
		}
		catch(Throwable ex)
		{
			CTraceLog.error(ex);
			return  "{\"status\":\"Error\"}";
		}
		
	}
	
	private Long getOrderServiceID(String sOrderServiceCode) throws Exception
	{
		String sRegID = CStringUtils.nvl(sOrderServiceCode).substring(0, sOrderServiceCode.length() - 7);

		Long nOrderID = COrder.findOrderByRegID(DB.connection(), sRegID);
		
		return COrderServiceManager.getOrderServiceID(nOrderID, sOrderServiceCode);
	}
}
