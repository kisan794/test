package com.hireright.sourceintelligence.reports.service.impl;

import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.reports.domain.entity.Reports;
import com.hireright.sourceintelligence.reports.domain.entity.ReportSearchResult;
import com.hireright.sourceintelligence.reports.domain.mapper.ReportMapper;
import com.hireright.sourceintelligence.reports.dto.*;
import com.hireright.sourceintelligence.reports.service.SourceInformationService;
import com.hireright.sourceintelligence.service.impl.QueryBuilder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.REPORTS_COLLECTION;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.ReportTypes.*;
import static com.hireright.sourceintelligence.reports.service.impl.ReportsQueryBuilder.limitOperation;
import static com.hireright.sourceintelligence.reports.service.impl.ReportsQueryBuilder.skipOperation;

@Slf4j
@RequiredArgsConstructor
@Service
public class SourceInformationServiceImpl implements SourceInformationService {

    private final ReportMapper reportMapper;
    private final CustomSourceRepository<Reports> customSourceRepository;

    @Override
    public ReportResponseDTO getSourceInformation(ReportsRequestDTO reportsRequestDTO) {
        String operatorRole = reportsRequestDTO.getOperatorRole();
        if (!StringUtils.isEmpty(operatorRole)) {
            if ("Originator".equalsIgnoreCase(operatorRole)) {
                return getOperatorReport(reportsRequestDTO);
            } else if ("Reviewer".equalsIgnoreCase(operatorRole)) {
                return getReviewerReport(reportsRequestDTO);
            } else if ("Originator & Reviewer".equalsIgnoreCase(operatorRole)) {
                return getOperatorAndReviewerReport(reportsRequestDTO);
            } else {
                throw new IllegalArgumentException("Invalid operator role: " + operatorRole);
            }
        } else {
            throw new IllegalArgumentException("Operator role cannot be null or empty");
        }
    }

    private ReportResponseDTO getOperatorReport(ReportsRequestDTO reportsRequestDTO) {
        Criteria criteria = ReportsQueryBuilder.queryBuilderForSourceInformationAndTat(reportsRequestDTO);
        MatchOperation matchOperation = ReportsQueryBuilder.matchOperation(criteria);
        GroupOperation groupOperation = ReportsQueryBuilder.operatorRoleGroupOperation();
        SortOperation sortOperation = ReportsQueryBuilder.buildSortOperation(reportsRequestDTO.getSort(), reportsRequestDTO.getOrder());
        FacetOperation facetOperation = ReportsQueryBuilder.facetOperation(reportsRequestDTO.getStartPage(), reportsRequestDTO.getBatchSize());
        ProjectionOperation finalProject = ReportsQueryBuilder.operatorRoleFinalProjection();

        AggregationOptions aggregationOptionsToAllowDiskUse = AggregationOptions.builder()
                .allowDiskUse(true).build();
        Aggregation aggregation = Aggregation.newAggregation(matchOperation, groupOperation, facetOperation, finalProject)
                .withOptions(aggregationOptionsToAllowDiskUse);

        var response = customSourceRepository.reportCustomAggregate(aggregation, REPORTS_COLLECTION, ReportSearchResult.class);
        log.info("Operator Report Response: {}", response);

        List<OperatorReportDTO> operatorReports = new ArrayList<>();
        if (response.getOperatorReportFlatList() != null && !response.getOperatorReportFlatList().isEmpty()) {
            operatorReports = mapFlatToNestedOperatorReport(response.getOperatorReportFlatList());
        }

        List<GenericResponseDTO> genericResponse = convertOperatorToGenericResponse(operatorReports);

        List<NestedMetaDTO> metaList = SourceInformationMetaUtils.getOperatorMetadata();

        return ReportResponseDTO.builder()
                .reportType(SOURCE_INFORMATION)
                .nestedMeta(metaList)
                .response(genericResponse)
                .currentPage(reportsRequestDTO.getStartPage())
                .totalItems(response.getTotal())
                .totalPages(QueryBuilder.getTotalPages(response.getTotal(), reportsRequestDTO.getBatchSize()))
                .build();
    }

    private List<OperatorReportDTO> mapFlatToNestedOperatorReport(List<OperatorReportFlatDTO> flatList) {
        List<OperatorReportDTO> nestedList = new ArrayList<>();

        for (OperatorReportFlatDTO flat : flatList) {
            ActionStatusCountDTO added = ActionStatusCountDTO.builder()
                    .newCount(flat.getAddedNew())
                    .inProgress(flat.getAddedInProgress())
                    .onHold(flat.getAddedOnHold())
                    .cancelled(flat.getAddedCancelled())
                    .completed(flat.getAddedCompleted())
                    .build();

            ActionStatusCountDTO changed = ActionStatusCountDTO.builder()
                    .newCount(flat.getChangedNew())
                    .inProgress(flat.getChangedInProgress())
                    .onHold(flat.getChangedOnHold())
                    .cancelled(flat.getChangedCancelled())
                    .completed(flat.getChangedCompleted())
                    .build();

            ActionStatusCountDTO archived = ActionStatusCountDTO.builder()
                    .newCount(flat.getArchivedNew())
                    .inProgress(flat.getArchivedInProgress())
                    .onHold(flat.getArchivedOnHold())
                    .cancelled(flat.getArchivedCancelled())
                    .completed(flat.getArchivedCompleted())
                    .build();

            ActionStatusCountDTO deleted = ActionStatusCountDTO.builder()
                    .newCount(flat.getDeletedNew())
                    .inProgress(flat.getDeletedInProgress())
                    .onHold(flat.getDeletedOnHold())
                    .cancelled(flat.getDeletedCancelled())
                    .completed(flat.getDeletedCompleted())
                    .build();

            OperatorReportDTO nested = OperatorReportDTO.builder()
                    .operatorName(flat.getOperatorName())
                    .added(added)
                    .changed(changed)
                    .archived(archived)
                    .deleted(deleted)
                    .build();

            nestedList.add(nested);
        }

        return nestedList;
    }

    private ReportResponseDTO getReviewerReport(ReportsRequestDTO reportsRequestDTO) {
        Criteria criteria = ReportsQueryBuilder.queryBuilderForReviewerRole(reportsRequestDTO);
        MatchOperation matchOperation = ReportsQueryBuilder.matchOperation(criteria);
        GroupOperation groupOperation = ReportsQueryBuilder.reviewerRoleGroupOperation();
        SortOperation sortOperation = ReportsQueryBuilder.buildSortOperation(reportsRequestDTO.getSort(), reportsRequestDTO.getOrder());
        FacetOperation facetOperation = ReportsQueryBuilder.facetOperationWithGroup(sortOperation, reportsRequestDTO.getStartPage(), reportsRequestDTO.getBatchSize(), groupOperation);
        ProjectionOperation finalProject = ReportsQueryBuilder.finalProjectionWithTotalCountInPipeline();

        AggregationOptions aggregationOptionsToAllowDiskUse = AggregationOptions.builder()
                .allowDiskUse(true).build();
        Aggregation aggregation = Aggregation.newAggregation(matchOperation, groupOperation, facetOperation, finalProject)
                .withOptions(aggregationOptionsToAllowDiskUse);

        var response = customSourceRepository.reportCustomAggregate(aggregation, REPORTS_COLLECTION, ReportSearchResult.class);
        log.info("Reviewer Report Response: {}", response);

        List<ReviewerReportDTO> reviewerReports = new ArrayList<>();
        if (response.getReviewerReportList() != null && !response.getReviewerReportList().isEmpty()) {
            reviewerReports = response.getReviewerReportList();
        }

        List<GenericResponseDTO> genericResponse = convertReviewerToGenericResponse(reviewerReports);

        List<MetaDTO> metaList = SourceInformationMetaUtils.getReviewerMetadata();

        return ReportResponseDTO.builder()
                .reportType(SOURCE_INFORMATION)
                .meta(metaList)
                .response(genericResponse)
                .currentPage(reportsRequestDTO.getStartPage())
                .totalItems(response.getTotal())
                .totalPages(QueryBuilder.getTotalPages(response.getTotal(), reportsRequestDTO.getBatchSize()))
                .build();
    }

    private ReportResponseDTO getOperatorAndReviewerReport(ReportsRequestDTO reportsRequestDTO) {
        Criteria actionCriteria = ReportsQueryBuilder.queryBuilderForSourceInformationAndTat(reportsRequestDTO);
        MatchOperation actionMatch = ReportsQueryBuilder.matchOperation(actionCriteria);
        GroupOperation actionGroup = ReportsQueryBuilder.operatorAndReviewerActionGroupOperation();
        SortOperation sortOperation = ReportsQueryBuilder.buildSortOperation(reportsRequestDTO.getSort(), reportsRequestDTO.getOrder());
        FacetOperation actionFacet = Aggregation.facet()
                .and(Aggregation.count().as("count")).as("total")
                .and(actionGroup, sortOperation, skipOperation(reportsRequestDTO.getStartPage(), reportsRequestDTO.getBatchSize()), limitOperation(reportsRequestDTO.getBatchSize())).as("data");
        ProjectionOperation actionProjection = Aggregation.project()
                .and(ArrayOperators.ArrayElemAt.arrayOf("total.count").elementAt(0)).as("total")
                .and("data").as("operatorReviewerReportList");

        AggregationOptions aggregationOptions = AggregationOptions.builder()
                .allowDiskUse(true).build();

        Aggregation actionAggregation = Aggregation.newAggregation(actionMatch, actionFacet, actionProjection)
                .withOptions(aggregationOptions);

        var actionResponse = customSourceRepository.reportCustomAggregate(actionAggregation, REPORTS_COLLECTION, ReportSearchResult.class);
        log.info("Action counts response: {}", actionResponse);

        Criteria statusCriteria = ReportsQueryBuilder.queryBuilderForReviewerRole(reportsRequestDTO);
        MatchOperation statusMatch = ReportsQueryBuilder.matchOperation(statusCriteria);
        GroupOperation statusGroup = ReportsQueryBuilder.operatorAndReviewerStatusGroupOperation();

        FacetOperation statusFacet = Aggregation.facet()
                .and(Aggregation.count().as("count")).as("total")
                .and(statusGroup, sortOperation, skipOperation(reportsRequestDTO.getStartPage(), reportsRequestDTO.getBatchSize()), limitOperation(reportsRequestDTO.getBatchSize())).as("data");
        ProjectionOperation statusProjection = Aggregation.project()
                .and(ArrayOperators.ArrayElemAt.arrayOf("total.count").elementAt(0)).as("total")
                .and("data").as("operatorReviewerReportList");

        Aggregation statusAggregation = Aggregation.newAggregation(statusMatch, statusFacet, statusProjection)
                .withOptions(aggregationOptions);

        var statusResponse = customSourceRepository.reportCustomAggregate(statusAggregation, REPORTS_COLLECTION, ReportSearchResult.class);
        log.info("Status counts response: {}", statusResponse);

        List<OperatorReviewerReportDTO> combinedReports = mergeActionAndStatusData(actionResponse, statusResponse);

        int startIndex = (reportsRequestDTO.getStartPage()-1) * reportsRequestDTO.getBatchSize();
        int endIndex = Math.min(startIndex + reportsRequestDTO.getBatchSize(), combinedReports.size());
        List<OperatorReviewerReportDTO> paginatedReports = combinedReports.subList(startIndex, endIndex);

        List<MetaDTO> metaList = SourceInformationMetaUtils.getOperatorAndReviewerMetadata();

        return ReportResponseDTO.builder()
                .reportType(SOURCE_INFORMATION)
                .meta(metaList)
                .response(convertToGenericResponse(paginatedReports))
                .currentPage(reportsRequestDTO.getStartPage())
                .totalItems(combinedReports.size())
                .totalPages(QueryBuilder.getTotalPages(combinedReports.size(), reportsRequestDTO.getBatchSize()))
                .build();
    }

    private List<OperatorReviewerReportDTO> mergeActionAndStatusData(ReportSearchResult actionResponse, ReportSearchResult statusResponse) {
        Map<String, OperatorReviewerReportDTO> mergedMap = new HashMap<>();

        if (actionResponse.getOperatorReviewerReportList() != null) {
            for (OperatorReviewerReportDTO actionData : actionResponse.getOperatorReviewerReportList()) {
                String researcherName = actionData.getResearcherName();
                if (researcherName != null && !researcherName.isEmpty()) {
                    OperatorReviewerReportDTO merged = OperatorReviewerReportDTO.builder()
                            .researcherName(researcherName)
                            .hon(actionData.getHon() != null ? actionData.getHon() : "")
                            .added(actionData.getAdded())
                            .changed(actionData.getChanged())
                            .archived(actionData.getArchived())
                            .deleted(actionData.getDeleted())
                            .newCount(0)
                            .inProgress(0)
                            .onHold(0)
                            .cancelled(0)
                            .completed(0)
                            .total(actionData.getAdded() + actionData.getChanged() + actionData.getArchived() + actionData.getDeleted())
                            .build();
                    mergedMap.put(researcherName, merged);
                }
            }
        }

        if (statusResponse.getOperatorReviewerReportList() != null) {
            for (OperatorReviewerReportDTO statusData : statusResponse.getOperatorReviewerReportList()) {
                String researcherName = statusData.getResearcherName();
                if (researcherName != null && !researcherName.isEmpty()) {
                    OperatorReviewerReportDTO existing = mergedMap.get(researcherName);

                    if (existing != null) {
                        existing.setNewCount(statusData.getNewCount());
                        existing.setInProgress(statusData.getInProgress());
                        existing.setOnHold(statusData.getOnHold());
                        existing.setCancelled(statusData.getCancelled());
                        existing.setCompleted(statusData.getCompleted());
                        existing.setTotal(existing.getAdded() + existing.getChanged() + existing.getArchived() + existing.getDeleted() +
                                statusData.getNewCount() + statusData.getInProgress() + statusData.getOnHold() +
                                statusData.getCancelled() + statusData.getCompleted());
                    } else {
                        int total = statusData.getNewCount() + statusData.getInProgress() + statusData.getOnHold() +
                                statusData.getCancelled() + statusData.getCompleted();
                        OperatorReviewerReportDTO merged = OperatorReviewerReportDTO.builder()
                                .researcherName(researcherName)
                                .hon(statusData.getHon() != null ? statusData.getHon() : "")
                                .added(0)
                                .changed(0)
                                .archived(0)
                                .deleted(0)
                                .newCount(statusData.getNewCount())
                                .inProgress(statusData.getInProgress())
                                .onHold(statusData.getOnHold())
                                .cancelled(statusData.getCancelled())
                                .completed(statusData.getCompleted())
                                .total(total)
                                .build();
                        mergedMap.put(researcherName, merged);
                    }
                }
            }
        }

        return new ArrayList<>(mergedMap.values());
    }

    private List<GenericResponseDTO> convertToGenericResponse(List<OperatorReviewerReportDTO> reports) {
        List<GenericResponseDTO> genericList = new ArrayList<>();
        for (OperatorReviewerReportDTO report : reports) {
            GenericResponseDTO generic = GenericResponseDTO.builder()
                    .researcherName(report.getResearcherName())
                    .added(report.getAdded())
                    .changed(report.getChanged())
                    .archived(report.getArchived())
                    .deleted(report.getDeleted())
                    .newCount(report.getNewCount())
                    .inProgress(report.getInProgress())
                    .onHold(report.getOnHold())
                    .cancelled(report.getCancelled())
                    .completed(report.getCompleted())
                    .total(report.getTotal())
                    .build();
            genericList.add(generic);
        }
        return genericList;
    }

    private List<GenericResponseDTO> convertOperatorToGenericResponse(List<OperatorReportDTO> reports) {
        List<GenericResponseDTO> genericList = new ArrayList<>();
        for (OperatorReportDTO report : reports) {
            ActionStatusCountDTO added = calculateActionTotal(report.getAdded());
            ActionStatusCountDTO changed = calculateActionTotal(report.getChanged());
            ActionStatusCountDTO archived = calculateActionTotal(report.getArchived());
            ActionStatusCountDTO deleted = calculateActionTotal(report.getDeleted());

            int overallTotal = added.getTotal() + changed.getTotal() + archived.getTotal() + deleted.getTotal();

            GenericResponseDTO generic = GenericResponseDTO.builder()
                    .operatorName(report.getOperatorName())
                    .addedNested(added)
                    .changedNested(changed)
                    .archivedNested(archived)
                    .deletedNested(deleted)
                    .total(overallTotal)
                    .build();
            genericList.add(generic);
        }
        return genericList;
    }

    private ActionStatusCountDTO calculateActionTotal(ActionStatusCountDTO action) {
        if (action == null) {
            return ActionStatusCountDTO.builder()
                    .newCount(0)
                    .inProgress(0)
                    .onHold(0)
                    .cancelled(0)
                    .completed(0)
                    .total(0)
                    .build();
        }

        int total = action.getNewCount() + action.getInProgress() + action.getOnHold() +
                    action.getCancelled() + action.getCompleted();
        action.setTotal(total);
        return action;
    }

    private List<GenericResponseDTO> convertReviewerToGenericResponse(List<ReviewerReportDTO> reports) {
        List<GenericResponseDTO> genericList = new ArrayList<>();
        for (ReviewerReportDTO report : reports) {
            int total = report.getNewCount() + report.getInProgress() + report.getOnHold() + report.getCancelled() + report.getCompleted();

            GenericResponseDTO generic = GenericResponseDTO.builder()
                    .researcherName(report.getResearcherName())
                    .newCount(report.getNewCount())
                    .inProgress(report.getInProgress())
                    .onHold(report.getOnHold())
                    .cancelled(report.getCancelled())
                    .completed(report.getCompleted())
                    .total(total)
                    .build();
            genericList.add(generic);
        }
        return genericList;
    }
}
