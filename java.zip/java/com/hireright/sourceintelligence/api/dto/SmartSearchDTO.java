package com.hireright.sourceintelligence.api.dto;

import lombok.*;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SmartSearchDTO {
    private String organizationType;
    private String name;
    private String department;
    private String webAddress;
    private String country;
    private String state;
    private String city;
    private String postalCode;
    private String address;
    private String onlineProvider;
    private String code;
    private String phoneCountryCode;
    private String phoneExtension;
    private String phoneNumber;
    private String phoneAreaCode;
    private String faxCountryCode;
    private String faxExtension;
    private String faxNumber;
    private String faxAreaCode;
    private String email;
    private Boolean isArchive;

    private Boolean fromSubRequest;
    private Boolean isDropDownSelected;

    private String order;
    private String sort;
    private int startPage;
    private int pageSize;



}
