package com.hireright.sourceintelligence.config;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.index.Index;
import org.springframework.data.mongodb.core.index.IndexOperations;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.EDUCATION_COLLECTION_PREFIX;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.SOURCE_COLLECTION_SUFFIX;
import static com.hireright.sourceintelligence.domain.constants.Constants.*;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class MongoIndexConfig {

    private final MongoTemplate mongoTemplate;

    @PostConstruct
    public void initIndexes() {
        createParchmentSourceIndexes();
    }

    private void createParchmentSourceIndexes() {
        try {
            IndexOperations indexOps = mongoTemplate.indexOps(EDUCATION_COLLECTION_PREFIX + SOURCE_COLLECTION_SUFFIX);

            Index locationNameIndex = new Index()
                    .on(FIELD_STATE, Sort.Direction.ASC)
                    .on(FIELD_CITY, Sort.Direction.ASC)
                    .on(FIELD_COUNTRY, Sort.Direction.ASC)
                    .on(FIELD_NAME, Sort.Direction.ASC)
                    .named("idx_location_name")
                    .background();

            indexOps.ensureIndex(locationNameIndex);
            log.info("Created index: idx_location_name");

        } catch (Exception e) {
            log.error("Failed to create MongoDB indexes for Parchment sources", e);
        }
    }
}