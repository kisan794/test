/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	msuhhoruki	2017-06-16	Created
 */
package hireright.applications.vendor_api;

import hireright.applications.vendor_api.model.COrderBuilder;
import hireright.applications.vendor_api.model.CScreeningRequest;
import hireright.objects.users.CCustomer;
import hireright.objects.users.CCustomerFactory;
import hireright.objects.users.CCustomerUser;
import hireright.objects.utilities.CDomain;
import hireright.objects.utilities.CDomainFactory;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.CStringUtils;

/**
 * 
 */
public class CVendorOrderBuilder
{
	private static final String DOMAIN_PROP_COMPANY = "VENDOR_API_COMPANY_CODE";
	private static final String DOMAIN_PROP_USER = "VENDOR_API_USER_LOGIN";

	public static COrderBuilder getInstance(CScreeningRequest request)
	{
		String sDomainID = request.getClientReference("DomainID");
		if (CStringUtils.isEmpty(sDomainID))
		{
			throw new CRuntimeException("DomainID missing.", request.toProperties());
		}
		
		CDomain domain = CDomainFactory.getDomain(sDomainID);
		if (domain == null)
		{
			throw new CRuntimeException("Domain not found: " + sDomainID, request.toProperties());
		}
		
		String sUserLogin = request.getClientReference("UserLogin");
		if (CStringUtils.isEmpty(sUserLogin))
		{
			sUserLogin = domain.getProperty(DOMAIN_PROP_USER);
		}
		
		String sCompanyCode = request.getClientReference("CompanyCode");
		if (CStringUtils.isEmpty(sCompanyCode))
		{
			sCompanyCode = domain.getProperty(DOMAIN_PROP_COMPANY);
		}
		if (CStringUtils.isEmpty(sCompanyCode))
		{
			throw new CRuntimeException("Company code missing.", request.toProperties());
		}
		
		CCustomer customer = CCustomerFactory.getCustomerByCode(sCompanyCode);
		if (customer == null)
		{
			throw new CRuntimeException("Customer not found: " + sCompanyCode, request.toProperties());
		}
		else if (!customer.isActive())
		{
			throw new CRuntimeException("Customer inactive: " + sCompanyCode, request.toProperties());
		}
		
		CCustomerUser user = null;
		if (CStringUtils.isNotEmpty(sUserLogin))
		{
			user = CCustomerUser.loadByLogin(customer, sUserLogin);
		}
		else
		{
			user = customer.getManagerUser();
		}
		
		if (user == null)
		{
			throw new CRuntimeException("Customer user not found.", request.toProperties());
		}
		else if (!user.isActive())
		{
			throw new CRuntimeException("Customer user inactive: " + sUserLogin, request.toProperties());
		}
		
		return new COrderBuilder(domain, customer, user);
	}
}
