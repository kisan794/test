/*
 * @(#)$RCSfile: CEntryPointFrameworkFactory.java,v $ $Revision: 1.2 $ $Date: 2014/07/28 14:57:10 $ $Author: aputintsev $ 
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/util/CEntryPointFrameworkFactory.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *     $Log: CEntryPointFrameworkFactory.java,v $
 *     Revision 1.2  2014/07/28 14:57:10  aputintsev
 *     forked from production version - projects_src/applications/accesspoint
 *
 *     Revision 1.1.2.1  2009/08/13 13:24:24  asolntsev
 *     Created by St.Petersburg team
 *
 *     Revision 1.1  2009/08/06 09:37:55  banton
 *     Added simple Finite State Machine support. Tested only for memory storage
 *
 *     Revision 1.1.1.1  2009/07/31 11:24:26  banton
 *     Task 39986 1.1
 *
 *     Revision 1.2  2009/07/30 13:46:31  banton
 *     Added full multi value properties support
 *
 *     Revision 1.1  2009/07/30 12:14:07  banton
 *     Added proxy class and memory storage for CEntryPoint
 *
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hireright.applications.accesspoint.util;

import hireright.objects.utilities.CEntryPoint;
import hireright.objects.utilities.CEntryPointFactory;
import hireright.sdk.util.CStringUtils;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Logger;
import org.apache.commons.collections.MultiMap;
import org.apache.commons.collections.map.MultiValueMap;

/**
 *
 * @author banton
 */
public class CEntryPointFrameworkFactory
{

    protected static boolean testMode=false;
    protected static boolean memoryMode=false;


    public static IEntryPointFramework createNewFramework()
    {
    IEntryPointFramework result=null;

        if (testMode)
            result = new CTestEntryPointFramework();
        else if (memoryMode)
            result = new CMemoryEntryPointFramework();
        else
            result = new CDataBaseEntryPointFramework();

        return result;
    }
    
    public static boolean isMemoryMode()
    {
        return memoryMode;
    }

    public static void setMemoryMode(boolean memoryMode)
    {
        CEntryPointFrameworkFactory.memoryMode = memoryMode;
    }

    public static boolean isTestMode()
    {
        return testMode;
    }

    public static void setTestMode(boolean testMode)
    {
        CEntryPointFrameworkFactory.testMode = testMode;
    }

    private static final Logger LOGGER = Logger.getLogger(CEntryPointFrameworkFactory.class.getName());
}
