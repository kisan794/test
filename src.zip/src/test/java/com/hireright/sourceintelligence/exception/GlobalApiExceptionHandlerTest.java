package com.hireright.sourceintelligence.exception;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingPathVariableException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.core.MethodParameter;

import jakarta.validation.ConstraintViolationException;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class GlobalApiExceptionHandlerTest {

    private GlobalApiExceptionHandler handler;
    private HttpHeaders headers;
    private HttpStatusCode status;
    private WebRequest webRequest;

    @BeforeEach
    void setUp() {
        handler = new GlobalApiExceptionHandler();
        headers = new HttpHeaders();
        status = HttpStatus.BAD_REQUEST;
        webRequest = mock(WebRequest.class);
    }
    private void dummyMethod(String arg) { /* no-op */ }

    @Test
    void handleMissingServletRequestParameter_ok() {
        MissingServletRequestParameterException ex =
                new MissingServletRequestParameterException("q", "String");
        ResponseEntity<Object> resp =
                handler.handleMissingServletRequestParameter(ex, headers, status, webRequest);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }

    @Test
    void handleMissingPathVariable_ok() throws Exception {
        MethodParameter mp = new MethodParameter(
                this.getClass().getDeclaredMethod("dummyMethod", String.class), 0);
        MissingPathVariableException ex = new MissingPathVariableException("id", mp);
        ResponseEntity<Object> resp =
                handler.handleMissingPathVariable(ex, headers, status, webRequest);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }

    @Test
    void handleHttpMediaTypeNotSupported_ok() {
        HttpMediaTypeNotSupportedException ex =
                new HttpMediaTypeNotSupportedException(MediaType.APPLICATION_XML,
                        List.of(MediaType.APPLICATION_JSON));
        ResponseEntity<Object> resp =
                handler.handleHttpMediaTypeNotSupported(ex, headers, status, webRequest);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }

    @Test
    void handleHttpMessageNotReadable_ok() {
        HttpMessageNotReadableException ex = new HttpMessageNotReadableException("bad json", new RuntimeException());
        ResponseEntity<Object> resp =
                handler.handleHttpMessageNotReadable(ex, headers, status, webRequest);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }

    @Test
    void handleHttpMessageNotWritable_ok() {
        HttpMessageNotWritableException ex = new HttpMessageNotWritableException("cannot write");
        ResponseEntity<Object> resp =
                handler.handleHttpMessageNotWritable(ex, headers, status, webRequest);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }

    @Test
    void handleNoHandlerFoundException_ok() {
        NoHandlerFoundException ex =
                new NoHandlerFoundException("GET", "/missing", new HttpHeaders());
        ResponseEntity<Object> resp =
                handler.handleNoHandlerFoundException(ex, headers, status, webRequest);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }

    @Test
    void handleMethodArgumentNotValid_ok() throws Exception {
        MethodParameter mp = new MethodParameter(
                this.getClass().getDeclaredMethod("dummyMethod", String.class), 0);

        BeanPropertyBindingResult binding = new BeanPropertyBindingResult(new Object(), "obj");
        binding.addError(new FieldError("obj", "field", "field error"));
        binding.addError(new ObjectError("obj", "global error"));

        MethodArgumentNotValidException ex = new MethodArgumentNotValidException(mp, binding);

        ResponseEntity<Object> resp =
                handler.handleMethodArgumentNotValid(ex, headers, status, webRequest);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }

    @Test
    void handleAccessDenied_forbidden() {
        AccessDeniedException ex =
                new AccessDeniedException("denied");

        ResponseEntity<Object> resp = handler.handleAccessDenied(ex);

        assertEquals(HttpStatus.FORBIDDEN, resp.getStatusCode());
        assertNotNull(resp.getBody());
    }


    @Test
    void handleMethodArgMismatch_ok() throws Exception {
        MethodParameter mp = new MethodParameter(
                this.getClass().getDeclaredMethod("dummyMethod", String.class), 0);
        MethodArgumentTypeMismatchException ex =
                new MethodArgumentTypeMismatchException("1", Integer.class, "id", mp, new IllegalArgumentException("x"));
        ResponseEntity<Object> resp = handler.handleMethodArgMismatch(ex);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }

    @Test
    void handleMissingRequestHeader_ok() throws Exception {
        MethodParameter mp = new MethodParameter(
                this.getClass().getDeclaredMethod("dummyMethod", String.class), 0);
        org.springframework.web.bind.MissingRequestHeaderException ex =
                new org.springframework.web.bind.MissingRequestHeaderException("X-Req", mp);
        ResponseEntity<Object> resp = handler.handleMissingRequestHeader(ex);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }

    @Test
    void handleConstraintViolation_ok() {
        ConstraintViolationException ex = new ConstraintViolationException(Collections.emptySet());
        ResponseEntity<Object> resp = handler.handleConstraintViolation(ex);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }

    @Test
    void handleDataIntegrityViolation_ok() {
        DataIntegrityViolationException ex = new DataIntegrityViolationException("duplicate");
        ResponseEntity<Object> resp = handler.handleDataIntegrityViolation(ex);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }

    @Test
    void handleDataAccessException_ok() {
        DataAccessException ex = new DataAccessException("db") {};
        ResponseEntity<Object> resp = handler.handleDataAccessException(ex);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }

    @Test
    void handleServiceException_ok() {
        ServiceException ex = new ServiceException("svc");
        ResponseEntity<Object> resp = handler.handleServiceException(ex);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }

//    @Test
//    void handleKafkaException_ok() {
//        KafkaException ex = new KafkaException("kafka");
//        ResponseEntity<Object> resp = handler.handleKafkaException(ex);
//        assertNotNull(resp);
//        assertNotNull(resp.getBody());
//    }

    @Test
    void unauthorizedExceptionHandler_ok() {
        UnauthorizedException ex = new UnauthorizedException("unauth");
        ResponseEntity<Object> resp = handler.unauthorizedExceptionHandler(ex);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }

    @Test
    void handleInvalidRequestException_ok() {
        InvalidRequestException ex = new InvalidRequestException("bad");
        ResponseEntity<Object> resp = handler.handleInvalidRequestException(ex);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }

    @Test
    void handleResourceNotFound_ok() {
        ResourceNotFoundException ex = new ResourceNotFoundException("missing");
        ResponseEntity<Object> resp = handler.handleResourceNotFound(ex);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }

    @Test
    void handleExperianInvalidRequestException_ok() {
        String json = "{\"errors\":[],\"success\":false}";
        ExperianInvalidRequestException ex = new ExperianInvalidRequestException(json);

        ResponseEntity<?> resp = handler.handleExperianInvalidRequestException(ex);

        assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        assertNotNull(resp.getBody());
    }


    @Test
    void handleRestClientException_ok() {
        RestClientException ex = new RestClientException("rest");
        ResponseEntity<Object> resp = handler.handleRestClientException(ex);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }

    @Test
    void handleResourceAccessException_ok() {
        ResourceAccessException ex = new ResourceAccessException("network");
        ResponseEntity<Object> resp = handler.handleResourceAccessException(ex);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }

    @Test
    void handleJsonProcessingException_ok() {
        InvalidJsonException ex = new InvalidJsonException("invalid");
        ResponseEntity<Object> resp = handler.handleJsonProcessingException(ex);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }

    @Test
    void defaultExceptionHandler_ok() {
        Exception ex = new Exception("boom");
        ResponseEntity<Object> resp = handler.defaultExceptionHandler(ex);
        assertNotNull(resp);
        assertNotNull(resp.getBody());
    }
}
