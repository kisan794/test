package hireright.applications.fulfillment_task_api.rest.recombointegration.service;

import hireright.applications.fulfillment_task_api.model.recombointegration.education.response.EducationResultRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.employment.response.EmploymentResultRequest;

public abstract class ResultService {
    public void processEducationSubmission(String requestId, EducationResultRequest resultRequest) {}

    public void processEmploymentSubmission(String requestId, EmploymentResultRequest resultRequest) {}
}
