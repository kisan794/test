package hireright.applications.igniting_innovations.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Request DTO for creating or updating form field configuration.
 *
 * @author Generated
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request object for form field configuration")
public class FormFieldConfigRequest {

    @NotBlank(message = "Field key is required")
    @Schema(description = "Unique identifier for the field")
    @JsonProperty("fieldKey")
    private String fieldKey;

    @Schema(description = "List of options for the field")
    @JsonProperty("options")
    private List<FieldOptionRequest> options;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "Field option")
    public static class FieldOptionRequest {

        @NotBlank(message = "Option value is required")
        @Schema(description = "Option value", example = "IT", required = true)
        @JsonProperty("value")
        private String value;

        @NotBlank(message = "Option label is required")
        @Schema(description = "Option label")
        @JsonProperty("label")
        private String label;
    }
}

