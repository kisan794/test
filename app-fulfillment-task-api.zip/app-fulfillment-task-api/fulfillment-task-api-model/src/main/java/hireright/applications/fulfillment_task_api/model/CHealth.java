package hireright.applications.fulfillment_task_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-13  HRG-332327 initial version
 */

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class CHealth implements Serializable {
    @JsonProperty ("status")
    private EStatus m_status;

    private CHealth() {
    }

    public CHealth(EStatus status) {
        this.m_status = status;
    }

    public EStatus getStatus() {
        return this.m_status;
    }

    public enum EStatus {
        pass,
        fail
    }
}
