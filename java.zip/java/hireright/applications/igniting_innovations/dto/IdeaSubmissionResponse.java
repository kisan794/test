package hireright.applications.igniting_innovations.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Response object containing idea submission details")
public class IdeaSubmissionResponse {

    @Schema(description = "Unique identifier of the idea")
    @JsonProperty("id")
    private String id;

    @Schema(description = "Title of the idea")
    @JsonProperty("title")
    private String title;

    @Schema(description = "Name of the person who submitted the idea")
    @JsonProperty("submittedBy")
    private String submittedBy;

    @Schema(description = "Email address of the submitter")
    @JsonProperty("emailAddress")
    private String emailAddress;

    @Schema(description = "Department or function")
    @JsonProperty("department")
    private String department;

    @Schema(description = "Date and time of submission")
    @JsonProperty("submissionDate")
    private LocalDateTime submissionDate;

    @Schema(description = "Detailed description of the idea")
    @JsonProperty("description")
    private String description;

    @Schema(description = "Main objective or goal")
    @JsonProperty("objective")
    private String objective;

    @Schema(description = "Areas impacted by this idea")
    @JsonProperty("impactAreas")
    private List<String> impactAreas;

    @Schema(description = "Types of improvement")
    @JsonProperty("improvementTypes")
    private List<String> improvementTypes;

    @Schema(description = "Other improvement type description")
    @JsonProperty("improvementTypeOther")
    private String improvementTypeOther;

    @Schema(description = "Expected benefits and impact")
    @JsonProperty("expectedBenefit")
    private String expectedBenefit;

    @Schema(description = "Impact categories")
    @JsonProperty("impactCategories")
    private List<String> impactCategories;

    @Schema(description = "Other impact category description")
    @JsonProperty("impactCategoryOther")
    private String impactCategoryOther;

    @Schema(description = "Implementation complexity level")
    @JsonProperty("implementationComplexity")
    private String implementationComplexity;

    @Schema(description = "Suggested implementation steps")
    @JsonProperty("suggestedSteps")
    private String suggestedSteps;

    @Schema(description = "Timeline type")
    @JsonProperty("timelineType")
    private String timelineType;

    @Schema(description = "Supporting documents URLs or paths")
    @JsonProperty("supportingDocuments")
    private List<String> supportingDocuments;

    @Schema(description = "Additional comments")
    @JsonProperty("additionalComments")
    private String additionalComments;

    @Schema(description = "Current status of the idea")
    @JsonProperty("status")
    private String status;
    
    @Schema(description = "Creation timestamp")
    @JsonProperty("createdAt")
    private LocalDateTime createdAt;

    @Schema(description = "Last update timestamp")
    @JsonProperty("updatedAt")
    private LocalDateTime updatedAt;
    
}