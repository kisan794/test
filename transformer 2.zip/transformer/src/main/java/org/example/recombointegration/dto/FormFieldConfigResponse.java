package org.example.recombointegration.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.example.recombointegration.document.FormFieldConfig.FieldType;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Response DTO for form field configuration.
 *
 * @author Generated
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Response object containing form field configuration")
public class FormFieldConfigResponse {

    @Schema(description = "Unique identifier", example = "507f1f77bcf86cd799439011")
    @JsonProperty("id")
    private String id;

    @Schema(description = "Unique identifier for the field", example = "impactAreas")
    @JsonProperty("fieldKey")
    private String fieldKey;

    @Schema(description = "Display name for the field", example = "Which area does this idea impact?")
    @JsonProperty("fieldLabel")
    private String fieldLabel;

    @Schema(description = "Description or help text for the field", example = "Select all areas that apply")
    @JsonProperty("fieldDescription")
    private String fieldDescription;

    @Schema(description = "Type of field", example = "MULTI_SELECT")
    @JsonProperty("fieldType")
    private FieldType fieldType;

    @Schema(description = "List of options for the field")
    @JsonProperty("options")
    private List<FieldOptionResponse> options;

    @Schema(description = "Whether this field is required", example = "false")
    @JsonProperty("required")
    private Boolean required;

    @Schema(description = "Display order in the form", example = "1")
    @JsonProperty("displayOrder")
    private Integer displayOrder;

    @Schema(description = "Whether this field is active/enabled", example = "true")
    @JsonProperty("active")
    private Boolean active;

    @Schema(description = "Section this field belongs to", example = "Area of Impact")
    @JsonProperty("section")
    private String section;

    @Schema(description = "Created timestamp", example = "2026-01-16T10:30:00")
    @JsonProperty("createdAt")
    private LocalDateTime createdAt;

    @Schema(description = "Last updated timestamp", example = "2026-01-16T10:30:00")
    @JsonProperty("updatedAt")
    private LocalDateTime updatedAt;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "Field option")
    public static class FieldOptionResponse {

        @Schema(description = "Option value", example = "PROCESS")
        @JsonProperty("value")
        private String value;

        @Schema(description = "Option label", example = "Process")
        @JsonProperty("label")
        private String label;

        @Schema(description = "Option description", example = "Streamlining workflows, automation, reducing errors")
        @JsonProperty("description")
        private String description;

        @Schema(description = "Display order", example = "1")
        @JsonProperty("order")
        private Integer order;

        @Schema(description = "Whether this option is active", example = "true")
        @JsonProperty("active")
        private Boolean active;
    }
}

