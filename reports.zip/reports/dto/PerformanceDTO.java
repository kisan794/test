package com.hireright.sourceintelligence.reports.dto;

import lombok.Data;

@Data
public class PerformanceDTO {
    private String originatorClass;
    private String originatorName;
    private String changeType;
    private String reviewerName;
    private String status;
    private int approvalDuration;
}
