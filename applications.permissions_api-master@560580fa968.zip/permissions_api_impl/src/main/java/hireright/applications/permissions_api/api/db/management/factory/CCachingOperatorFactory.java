package hireright.applications.permissions_api.api.db.management.factory;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-02-05  HRG-330191 initial version
 */

import hireright.objects.users.COperator;
import hireright.sdk.db3.DB;
import hireright.sdk.util.CStringUtils;
import hireright.sdkex.as_cache.CCache;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class CCachingOperatorFactory
{
	private static final CCache<COperator> CACHE = new CCache<>(COperator.class);

	public static COperator getOperator(String sOperator)
	{
		if(CStringUtils.isEmpty(sOperator))
		{
			return null;
		}

		try
		{
			return CACHE.get(sOperator, () -> getOperatorNoCache(sOperator));
		}
		catch(Exception ignored)
		{
			return getOperatorNoCache(sOperator);
		}
	}

	private static COperator getOperatorNoCache(String sOperator)
	{
		COperator operator = null;
		if(CStringUtils.isNumber(sOperator))
		{
			operator = COperator.get(Integer.parseInt(sOperator));
		}

		if(operator == null)
		{
			operator = COperator.get(sOperator);
		}

		return operator;
	}

	@SuppressWarnings("unchecked")
	public static Collection<COperator> getOperators(Collection<Integer> ids)
	{
		if(ids == null || ids.isEmpty())
		{
			return Collections.emptyList();
		}

		Collection<hireright.objects.users.COperator> records = new ArrayList<>(ids.size());

		ids = new ArrayList<>(ids);

		for(Integer nID : new ArrayList<>(ids))
		{
			hireright.objects.users.COperator record = null;

			try
			{
				record = CACHE.get(nID.toString(), () -> null);
			}
			catch(Exception ignored)
			{
			}

			if(record != null)
			{
				records.add(record);
				ids.remove(nID);
			}
		}

		if(!ids.isEmpty())
		{
			Criteria query = DB.session().createCriteria(hireright.objects.users.COperator.class);
			query.add(Restrictions.in("ID", ids));

			Collection<COperator> dbRecords = query.list();

			for(COperator record : dbRecords)
			{
				records.add(record);

				try
				{
					CACHE.put(record.getID().toString(), record);
					CACHE.put(record.getLogin(), record);
				}
				catch(Exception ignored)
				{
				}
			}
		}

		return records;
	}
}
