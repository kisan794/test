/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	msuhhoruki		2017-11-03	HIVPE-23610: extracted from CScreeningReportResource
 *	msuhhoruki		2017-11-30	HIVPE-27872: added tm message property to store timestamp of event/action that triggered message creation

 */
package hireright.applications.vendor_api.resources;

import java.nio.charset.Charset;
import java.util.Base64;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.http.MediaType;

import hireright.applications.vendor_api.EVendorReference;
import hireright.bdk.instance_parameter.CInstanceParameter;
import hireright.objects.content_provider.CContentProvider;
import hireright.objects.content_provider.CContentProviderFactory;
import hireright.objects.is.CEvent;
import hireright.objects.is.CMessage;
import hireright.objects.is.CMessageManager;
import hireright.objects.is.CMessagePayload;
import hireright.objects.order.COrderServiceDataSource;
import hireright.objects.order2.COrderServiceProperty;
import hireright.objects.provider.CProvider;
import hireright.objects.provider.CProviderFactory;
import hireright.objects.utilities.CDomain;
import hireright.objects.utilities.CDomainFactory;
import hireright.sdk.consts.Logical;
import hireright.sdk.db.CMultitenantDB;
import hireright.sdk.db2.CSessionFactory;
import hireright.sdk.db3.DB;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.CStringUtils;

class CMessageFactory
{
	private static final int EVENT_TYPE_START_DOC_SYNC = 755;

	public static CMessage createAndEnqueueMessage(String sSubject, String tm, String payload) 
	{
		try
		{
			return createMessage(sSubject, tm, payload);
		}
		catch(Throwable ex)
		{
			throw new CRuntimeException(ex);
		}
	}
	
	public static CMessage createMessage(String sSubject, String tm, String payload) throws Exception 
	{
		Document document = DocumentHelper.parseText(payload);
		String sTransactionID = document.selectSingleNode("//ClientReferences/IdValue[@name='INSTANCE_EXCHANGE_TRANSACTION_ID']").getText();
		
		if (sTransactionID == null)
		{
			throw new CRuntimeException("Transaction is absent");
		}
		
//			CDataExchangeLog.addInLog(sTransactionID, null, null, null, LDE_PROTOCOL_INSTANCE_EXCHANGE_1_0, null, request);
		
		String tenantCode = getTenantCodeByTransactionID(sTransactionID);

		return CMultitenantDB.execute(tenantCode, () -> {
			Session session = CSessionFactory.getSessionFactory().getCurrentSession();
			COrderServiceDataSource osds = (COrderServiceDataSource) session.createCriteria(COrderServiceDataSource.class)
					.add(Restrictions.eq("referenceID", sTransactionID))
					.uniqueResult();

			CProperties properties = new CProperties().setProperty("referenceID", sTransactionID);

			if(osds == null)
			{
				throw new CRuntimeException("OSDS not found", properties);
			}

			Long nOrderServiceID = osds.getOrderServiceID();

			String sDataAdapter = getResponseAdapter(osds);

			if(sDataAdapter == null)
			{
				properties.setProperty("providerID", osds.getProviderID());
				properties.setProperties(osds.getProperties());
				throw new CRuntimeException("Response adapter is not set", properties);
			}

			COrderServiceProperty vendorHostProp = COrderServiceProperty.getPropertyByName(nOrderServiceID.longValue(), EVendorReference.VENDOR_INSTANCE_REF.getPropertyName());
			
			if (vendorHostProp != null) 
			{
				CDomain vendorDomain = CDomainFactory.getDomain(vendorHostProp.getValue());
				
				if (vendorDomain != null && Logical.isTrue(CStringUtils.nvl(vendorDomain.getProperty("INSTANCE_EXCHANGE_DOCUMENT_SYNC"), Logical.YES_SHORT)))
				{
					initDocumentSync(nOrderServiceID);	
				}
			}
			
			CMessage result = new CMessage(sDataAdapter, "BASE", 3, sSubject);
			result.setProperty("orderServiceID", nOrderServiceID.toString());
			result.setProperty("transactionID", sTransactionID);
			result.setProperty("tm", tm);

			if(CInstanceParameter.NATIONAL_INSTANCE_US.equals(
				CInstanceParameter.getNationalInstanceId()) && !Charset.forName("US-ASCII")
				.newEncoder()
				.canEncode(payload))
			{
				result.addPayload(CMessagePayload.BODY_TYPE_BASE64,
					Base64.getEncoder().encodeToString(payload.getBytes()),
					MediaType.APPLICATION_XML_VALUE, "base64");
			}
			else
			{
				result.addPayload(CMessagePayload.BODY_TYPE_TEXT, payload, 
					MediaType.APPLICATION_XML_VALUE, "7bit");
			}

			CMessageManager.create(result);
			return result;
		});
	}

	private static String getResponseAdapter(COrderServiceDataSource osds)
	{
		CProperties properties = null;
		
		if (osds.getProviderID() != null)
		{
			CProvider provider = CProviderFactory.loadProvider(osds.getProviderID());
			properties = provider.getProperties2();
		}
		else
		{
			CProperties osdsProperties = osds.getProperties();
			if (CContentProvider.OBJECT_CLASS.equals(osdsProperties.getProperty("assignedActorClass")))
			{
				String sProviderID = osdsProperties.getProperty("assignedActorID");
				
				if (CStringUtils.isNumber(sProviderID))
				{
					properties = CContentProviderFactory.getProviderProperties(Long.parseLong(sProviderID));
				}
				else
				{
					throw new CRuntimeException("Provider is not specified");
				}
			}
		}
		
		return properties != null 
				? properties.getProperty("RESPONSE_ADAPTER")
				: null;
	}
	
	private static void initDocumentSync(Long nOrderServiceID)
	{
		CProperties properties = new CProperties();
		properties.setProperty("orderServiceID", nOrderServiceID);
		CEvent.create(EVENT_TYPE_START_DOC_SYNC, "BASE", properties);
	}

	private static String getTenantCodeByTransactionID(String sTransactionID) {
		String tenantCode = new DB.Call<String>()
		{
			@Override
			protected String call()
			{
				return (String) DB.session()
					.createSQLQuery(
						"SELECT CON_ID_TO_CON_NAME(con_id) FROM CONTAINERS(ORDER_SERVICE_DATA_SOURCE) WHERE REFERENCE_ID=:transactionID")
					.setString("transactionID", sTransactionID)
					.uniqueResult();
			}
		}.executeIsolatedSafe();
		return CStringUtils.nvl(tenantCode).replace( "HR2", "");
	}
}
