package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.Alias;
import com.hireright.sourceintelligence.api.dto.HighlightDTO;
import com.hireright.sourceintelligence.api.dto.SearchOrganizationDTO;
import com.hireright.sourceintelligence.api.dto.SmartSearchResultDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.mongodb.BasicDBObject;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SearchMapperImplTest {

    private final TestableSearchMapperImpl mapper = new TestableSearchMapperImpl();

    static class TestableSearchMapperImpl extends SearchMapperImpl {
        @Override
        public void mapPayloadFields(Source entity, SearchOrganizationDTO dto) {
            // no-op to keep generated branch testing isolated
        }

        JSONObject callDBObjectToJSONObject(com.mongodb.DBObject dbObject) {
            return dBObjectToJSONObject(dbObject);
        }

        SmartSearchResultDTO callSourceToSmartSearchResultDTO(Source source) {
            return sourceToSmartSearchResultDTO(source);
        }
    }

    @Test
    void entitySourceToDTO_shouldReturnNull_whenEntityIsNull() {
        assertNull(mapper.entitySourceToDTO(null));
    }

    @Test
    void entitySourceToDTO_shouldMapAllFields_whenAllRelevantFieldsArePresent() {
        Instant lastModifiedDate = Instant.parse("2026-04-07T10:15:30Z");
        Instant createdDate = Instant.parse("2026-04-06T10:15:30Z");

        Alias alias = new Alias();
        alias.setName("Alias 1");

        BasicDBObject payload = new BasicDBObject("key", "value");

        Source source = Source.builder()
                .hon("HON123")
                .organizationName("Org")
                .organizationAlias(new Alias[]{alias})
                .version(1.0)
                .organizationType(OrganizationType.values()[0])
                .city("Dallas")
                .state("Texas")
                .country("USA")
                .outOfBusiness(Boolean.TRUE)
                .lastModifiedDate(lastModifiedDate)
                .createdDate(createdDate)
                .postalCode("75001")
                .reviewRequired("true")
                .assignedTo("user1")
                .payload(payload)
                .build();

        SearchOrganizationDTO result = mapper.entitySourceToDTO(source);

        assertNotNull(result);
        assertEquals("HON123", result.getHon());
        assertEquals("Org", result.getOrganizationName());
        assertNotNull(result.getOrganizationAlias());
        assertEquals(1, result.getOrganizationAlias().length);
        assertNotSame(source.getOrganizationAlias(), result.getOrganizationAlias());
        assertEquals("1.0", result.getVersion());
        assertEquals(source.getOrganizationType(), result.getOrganizationType());
        assertEquals("Dallas", result.getCity());
        assertEquals("Texas", result.getState());
        assertEquals("USA", result.getCountry());
        assertEquals(Boolean.TRUE, result.getOutOfBusiness());
        assertEquals(lastModifiedDate, result.getLastModifiedDate());
        assertEquals(createdDate, result.getCreatedDate());
        assertEquals("75001", result.getPostalCode());
        assertEquals("true", result.getReviewRequired());
        assertEquals("user1", result.getAssignedTo());
        assertNotNull(result.getPayload());
    }

    @Test
    void entitySourceToDTO_shouldSkipOptionalFields_whenTheyAreNull() {
        Source source = Source.builder()
                .version(0.0)
                .build();

        SearchOrganizationDTO result = mapper.entitySourceToDTO(source);

        assertNotNull(result);
        assertEquals("0.0", result.getVersion());

        assertNull(result.getHon());
        assertNull(result.getOrganizationName());
        assertNull(result.getOrganizationAlias());
        assertNull(result.getOrganizationType());
        assertNull(result.getCity());
        assertNull(result.getState());
        assertNull(result.getCountry());
        assertNull(result.getOutOfBusiness());
        assertNull(result.getLastModifiedDate());
        assertNull(result.getCreatedDate());
        assertNull(result.getPostalCode());
        assertNull(result.getReviewRequired());
        assertNull(result.getHighlight());
        assertEquals("UNASSIGNED", result.getAssignedTo());
        assertNull(result.getPayload());
    }

    @Test
    void toDTOList_shouldReturnNull_whenInputListIsNull() {
        assertNull(mapper.toDTOList(null));
    }

    @Test
    void toDTOList_shouldMapList_whenInputListHasValues() {
        Source source = Source.builder()
                .hon("HON123")
                .version(1.0)
                .build();

        List<SearchOrganizationDTO> result = mapper.toDTOList(List.of(source));

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("HON123", result.get(0).getHon());
        assertEquals("1.0", result.get(0).getVersion());
    }

    @Test
    void toSmartSourceDTOList_shouldReturnNull_whenInputListIsNull() {
        assertNull(mapper.toSmartSourceDTOList(null));
    }

    @Test
    void toSmartSourceDTOList_shouldMapList_whenInputListHasValues() {
        Instant lastModifiedDate = Instant.parse("2026-04-07T10:15:30Z");
        Instant lastApprovedDate = Instant.parse("2026-04-07T11:15:30Z");

        Source source = Source.builder()
                .hon("HON123")
                .organizationName("Org")
                .city("Dallas")
                .country("USA")
                .state("Texas")
                .postalCode("75001")
                .lastModifiedDate(lastModifiedDate)
                .lastApprovedDate(lastApprovedDate)
                .build();

        List<SmartSearchResultDTO> result = mapper.toSmartSourceDTOList(List.of(source));

        assertNotNull(result);
        assertEquals(1, result.size());

        SmartSearchResultDTO dto = result.get(0);
        assertEquals("HON123", dto.getHon());
        assertEquals("Org", dto.getOrganizationName());
        assertEquals("Dallas", dto.getCity());
        assertEquals("USA", dto.getCountry());
        assertEquals("Texas", dto.getState());
        assertEquals("75001", dto.getPostalCode());
        assertEquals(lastModifiedDate, dto.getLastModifiedDate());
        assertEquals(lastApprovedDate, dto.getLastApprovedDate());
    }

    @Test
    void sourceToSmartSearchResultDTO_shouldReturnNull_whenSourceIsNull() {
        assertNull(mapper.callSourceToSmartSearchResultDTO(null));
    }

    @Test
    void sourceToSmartSearchResultDTO_shouldSkipOptionalFields_whenTheyAreNull() {
        Source source = Source.builder().build();

        SmartSearchResultDTO result = mapper.callSourceToSmartSearchResultDTO(source);

        assertNotNull(result);
        assertNull(result.getHon());
        assertNull(result.getOrganizationName());
        assertNull(result.getCity());
        assertNull(result.getCountry());
        assertNull(result.getState());
        assertNull(result.getPostalCode());
        assertNull(result.getLastModifiedDate());
        assertNull(result.getLastApprovedDate());
    }

    @Test
    void dBObjectToJSONObject_shouldReturnNull_whenDBObjectIsNull() {
        assertNull(mapper.callDBObjectToJSONObject(null));
    }

    @Test
    void dBObjectToJSONObject_shouldReturnEmptyJsonObject_whenDBObjectIsNotNull() {
        JSONObject result = mapper.callDBObjectToJSONObject(new BasicDBObject("key", "value"));

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
}