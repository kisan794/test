package com.hireright.sourceintelligence.domain.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.hireright.sourceintelligence.api.dto.Alias;
import com.hireright.sourceintelligence.api.dto.HighlightDTO;
import com.hireright.sourceintelligence.domain.enums.*;
import com.mongodb.DBObject;
import lombok.*;
import lombok.Builder;
import org.apache.commons.lang3.builder.*;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.util.StringUtils;

import java.time.Instant;
import java.util.List;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.UNASSIGNED;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(value = JsonInclude.Include.NON_EMPTY, content = JsonInclude.Include.NON_NULL)
public class Source {

    @Id
    //@Field("_id")
    private ObjectId id;

    private String hon;

    private String organizationName;

    private SourceOrganizationStatus status;

    private double version;

    private OrganizationType organizationType;

    private String city;

    private String country;

    private String state;

    private Alias[] organizationAlias;

    private DBObject payload;

    private ApprovalStatus approvalStatus;

    private String reviewRequired;

    private String postalCode;

    private List<HighlightDTO> highlight;

    private String location;

    private Boolean outOfBusiness;

    private String comments;
    private List<FieldErrors> generalErrors;
    private List<FieldErrors> fieldErrors;
    private String searchOrg;
    private Boolean flagPriority;
    private String logFlag;
    private String action;
    @Builder.Default
    private Boolean isLockEnabled= Boolean.FALSE;

    private String createdBy;

    private String creatorId;

    @Field("created_date")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant createdDate;

    private String lastModifiedBy;

    private String lastModifierId;

    @Field("last_modified_date")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant lastModifiedDate;

    private String requestedBy;

    private String requesterId;

    private String approvedBy;

    private String approverId;

    private String assignedTo;

    private String assignedId;

    private String lastLockedBy;
    private String lastLockedId;

    private String lastUnLockedBy;
    private String lastUnLockedId;

    @Field("last_locked_date")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant lastLockedDate;

    @Field("last_unlocked_date")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant lastUnLockedDate;

    @Field("last_approved_date")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant lastApprovedDate;
    private double tempVersion;

    @Field("approval_start_date")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant approvalStartDate;

    @Field("last_action_date")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant lastActionDate;

    private String systemComments;


    public String getAssignedTo() {
        if(StringUtils.hasText(assignedTo)) {
            return assignedTo;
        }else{
            return UNASSIGNED;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        Source that = (Source) o;

        EqualsBuilder eb = new EqualsBuilder();
        eb.append(this.hon, that.getHon());
        return eb.isEquals();
    }

    @Override
    public int hashCode() {
        HashCodeBuilder hcb = new HashCodeBuilder();
        hcb.append(hon).append(organizationName);
        return hcb.toHashCode();
    }

}
