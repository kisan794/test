/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-07-23	Created
 */
package hireright.applications.vendor_api.model;

import java.sql.Timestamp;
import java.util.Date;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import hireright.applications.vendor_api.exchange.handler.objects.CEntityExchangeDTO;

@XmlRootElement(name="FulfillmentCommentRequest")
public class COrderServiceOperatorCommentRequest extends CEntityExchangeDTO
{
	private String text;
	private String nationalText;
	private String operatorName;
	private String commentsCode;
	private Date date;
	private Timestamp timestamp;

	@XmlElement(name="Text")
	public String getText()
	{
		return this.text;
	}

	@XmlElement(name="NationalText")
	public String getNationalText()
	{
		return this.nationalText;
	}

	@XmlElement(name="OperatorName")
	public String getOperatorName()
	{
		return this.operatorName;
	}

	@XmlElement(name="CommentsCode")
	public String getCommentsCode()
	{
		return this.commentsCode;
	}

	@XmlElement(name="Date")
	@XmlJavaTypeAdapter(CDateAdapter.class)
	public Date getDate()
	{
		return this.date;
	}

	public void setText(String text)
	{
		this.text = text;
	}

	public void setNationalText(String nationalText)
	{
		this.nationalText = nationalText;
	}

	public void setOperatorName(String operatorName)
	{
		this.operatorName = operatorName;
	}

	public void setCommentsCode(String commentsCode)
	{
		this.commentsCode = commentsCode;
	}

	public void setDate(Date date)
	{
		this.date = date;
	}

	@XmlJavaTypeAdapter(CTimestampAdapter.class)
	@XmlElement(name="Timestamp")
	public Timestamp getTimestamp()
	{
		return this.timestamp;
	}

	public void setTimestamp(Timestamp timestamp)
	{
		this.timestamp = timestamp;
	}
}
