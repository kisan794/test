package com.hireright.sourceintelligence.api.dto.rds;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class VendorResponseDTO {
    @JsonProperty("EDUCATION")
    private List<VendorsDTO> education;
    @JsonProperty("EMPLOYMENT")
    private List<VendorsDTO> employment;
}
