package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.*;

import java.time.Instant;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsonorg.JSONObjectDeserializer;
import com.fasterxml.jackson.datatype.jsonorg.JSONObjectSerializer;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import lombok.*;
import org.json.JSONObject;

import jakarta.validation.constraints.NotNull;


@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(value = JsonInclude.Include.NON_EMPTY, content = JsonInclude.Include.NON_NULL)
public class SourceOrganizationDTO {

    private String hon;

    private SourceOrganizationStatus status;

    private double version;

    @NotNull
    private OrganizationType organizationType;

    @NotNull
    private String organizationName;

    private String city;

    private String country;

    private String state;

    private Alias[] organizationAlias;

    @NotNull
    @JsonSerialize(using = JSONObjectSerializer.class)
    @JsonDeserialize(using = JSONObjectDeserializer.class)
    private JSONObject payload;

    private ApprovalStatus approvalStatus;

    private String assignedTo;

    private String assignedId;

    private String logFlag;

    private String comment;

    private String rejectReason;

    private Boolean flagPriority;

    private String requestedBy;

    private String requesterId;

    private String approvedBy;

    private String approverId;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant lastModifiedDate;

    private String reviewRequired;

    private String postalCode;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private String createdDate;

    private String createdBy;

    private String creatorId;

    private String lastModifierId;

    private String lastModifiedBy;

    private Boolean outOfBusiness;

    private String location;

    private Integer usedCount;

    private Float score;

    private String comments;
    private List<FieldErrorsDTO> generalErrors;
    private List<FieldErrorsDTO> fieldErrors;

    private String region;

    private String action;

    private Boolean isLockEnabled;

    private String lastLockedBy;
    private String lastLockedId;

    private String lastUnLockedBy;
    private String lastUnLockedId;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private String lastLockedDate;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private String lastUnLockedDate;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private String lastApprovedDate;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private String lastActionDate;

    private double tempVersion;
    private String systemComments;

}
