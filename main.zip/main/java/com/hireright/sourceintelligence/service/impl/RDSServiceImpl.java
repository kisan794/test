package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.rds.VendorResponseDTO;
import com.hireright.sourceintelligence.domain.entity.Vendors;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.mapper.RDSMapper;
import com.hireright.sourceintelligence.domain.repository.VendorsRepository;
import com.hireright.sourceintelligence.service.RDSService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@RequiredArgsConstructor
@Service
public class RDSServiceImpl implements RDSService {

    private final VendorsRepository vendorsRepository;
    private final RDSMapper rdsMapper;

    @Override
    public VendorResponseDTO getVendorList() {
        VendorResponseDTO vendors = new VendorResponseDTO();
        List<Vendors> educationList = vendorsRepository.findByOrganizationTypeOrderByVendorAsc(OrganizationType.EDUCATION.getType());
        List<Vendors> empList = vendorsRepository.findByOrganizationTypeOrderByVendorAsc(OrganizationType.EMPLOYMENT.getType());
        vendors.setEducation(rdsMapper.toVendorsDTOList(educationList));
        vendors.setEmployment(rdsMapper.toVendorsDTOList(empList));
        return vendors;
    }
}
