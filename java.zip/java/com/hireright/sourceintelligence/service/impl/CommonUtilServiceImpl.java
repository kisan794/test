package com.hireright.sourceintelligence.service.impl;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.constants.ErrorConstants.PARSE_FAILED;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchScore.SEARCH_LIMIT;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowInternalServiceException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.domain.entity.FieldValueInfo;
import com.hireright.sourceintelligence.domain.enums.UserRoles;
import java.io.IOException;
import java.text.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import com.hireright.sourceintelligence.service.CommonUtilService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

@Slf4j
@Service
@RequiredArgsConstructor
public class CommonUtilServiceImpl implements CommonUtilService {

  public  <T> T convertJsonToPOJO(String source, Class<T> target) {
    ObjectMapper objectMapper = new ObjectMapper();
    T t = null;
    try {
      t = objectMapper.readValue(source, target);
    } catch (JsonProcessingException jsonProcessingException) {
      logAndThrowInternalServiceException(PARSE_FAILED,jsonProcessingException,source);
    }
    return t;
  }

  public String getDateAsString(Date date, String pattern){
    DateFormat dateFormat = new SimpleDateFormat(pattern);
    return dateFormat.format(date);
  }

  public String base64decoder(String encodedString){
    byte[] decodedBytes = Base64.getDecoder().decode(encodedString);
    return new String(decodedBytes);
  }

  @Override
  public  <T> T convertBytesToPOJO(byte[] source, Class<T> target) {
    ObjectMapper objectMapper = new ObjectMapper();
    T t = null;
    try {
      t = objectMapper.readValue(source, target);
    } catch (IOException ioException) {
      logAndThrowInternalServiceException(PARSE_FAILED,ioException,Arrays.toString(source));
    }
    return t;
  }

  @Override
  public UserInfo getUserInfo(HttpServletRequest httpServletRequest) {
    String username = base64decoder(httpServletRequest.getHeader(USERNAME));
//    String userPrimaryName = base64decoder(httpServletRequest.getHeader(FIRSTNAME))
//            + " " + base64decoder(httpServletRequest.getHeader(LASTNAME));
//    String rolesString = base64decoder(httpServletRequest.getHeader(ROLES));
    //rolesString = rolesString.replace("[","").replace("]","").replace("\"","");
    //List<String> roles = Arrays.asList(rolesString.split(","));

    return UserInfo.builder()
            .primaryUserName(username)
            .username(username)
           // .roles(roles)
            .build();
  }

  @Override
  public boolean isResearchAnalyst(List<String> roles) {
    return org.apache.commons.lang3.ObjectUtils.isNotEmpty(roles) && roles.size()==1 && roles.get(0).equalsIgnoreCase(
            UserRoles.RESEARCH_ANALYST.getRole());
  }

  @Override
  public  <V> void setIfNotNullAndEmpty(V value, Consumer<V> setter) {
    if (!ObjectUtils.isEmpty(value)) {
      setter.accept(value);
    }
  }

  @Override
  public List<AutocompleteSearchDTO> getTopFiveCategorySearches(Map<String,List<KeyMatchDTO>> mapOfCategorySearch) {
    List<AutocompleteSearchDTO> topFiveCategorySearches = new ArrayList<>();
    log.info("getTopFive: {}",mapOfCategorySearch);
    for (Map.Entry<String, List<KeyMatchDTO>> entry : mapOfCategorySearch.entrySet()) {
      AutocompleteSearchDTO autocompleteSearchDTO = new AutocompleteSearchDTO();
      autocompleteSearchDTO.setCategory(entry.getKey());
      List<KeyMatchDTO> keyMatchDTOS = entry.getValue().stream().toList();
      List<FieldValueInfo> matches = keyMatchDTOS.stream().map(keyMatchDTO-> new FieldValueInfo(keyMatchDTO.getKey(),keyMatchDTO.getOutOfBusiness(),keyMatchDTO.getDoNotContact(), keyMatchDTO.getCountry(), keyMatchDTO.getState(),keyMatchDTO.getCity(), keyMatchDTO.getHon()))
              .limit(SEARCH_LIMIT).collect(Collectors.toCollection(LinkedList::new));
      autocompleteSearchDTO.setMatches(matches);
      topFiveCategorySearches.add(autocompleteSearchDTO);
    }
    return topFiveCategorySearches;
  }

  @Override
  public Map<String,List<KeyMatchDTO>> categorizeMatchedValuesFromHighlightedObject(String category, FieldValueInfo info ,
                                                                                    Map<String,List<KeyMatchDTO>> mapOfCategorySearch, HighlightDTO highlightDTO) {
    if (mapOfCategorySearch.containsKey(category)) {
      mapOfCategorySearch.get(category).add(
              new KeyMatchDTO(info.getValue(),info.getOutOfBusiness(), info.getDoNotContact(), info.getCountry(),info.getState(),info.getCity(),info.getHon(), highlightDTO.getScore()));
    } else {
      List<KeyMatchDTO> orgNameSet = new ArrayList<>();
      orgNameSet.add(
              new KeyMatchDTO(info.getValue(),info.getOutOfBusiness(),info.getDoNotContact(), info.getCountry(),info.getState(),info.getCity(),info.getHon(), highlightDTO.getScore()));
      mapOfCategorySearch.put(category, orgNameSet);
    }
    return mapOfCategorySearch;
  }

  @Override
  public Map<String,List<KeyMatchDTO>> categorizeMatchedValues(String category, FieldValueInfo info ,
                                                                                    Map<String,List<KeyMatchDTO>> mapOfCategorySearch) {
    if (mapOfCategorySearch.containsKey(category)) {
      mapOfCategorySearch.get(category).add(
              new KeyMatchDTO(info.getValue(),info.getOutOfBusiness(), info.getDoNotContact(), info.getCountry(),info.getState(),info.getCity(),info.getHon(), 0F));
    } else {
      List<KeyMatchDTO> orgNameSet = new ArrayList<>();
      orgNameSet.add(
              new KeyMatchDTO(info.getValue(),info.getOutOfBusiness(),info.getDoNotContact(), info.getCountry(),info.getState(),info.getCity(),info.getHon(), 0F));
      mapOfCategorySearch.put(category, orgNameSet);
    }
    return mapOfCategorySearch;
  }
  @Override
  public boolean isQualityAnalystOnly(List<String> roles){
    return (!ObjectUtils.isEmpty(roles) && roles.contains(UserRoles.QUALITY_ANALYST.getRole()) && !roles.contains(UserRoles.SUPERVISOR.getRole())
            && !roles.contains(UserRoles.MANAGER.getRole()));
  }
}
