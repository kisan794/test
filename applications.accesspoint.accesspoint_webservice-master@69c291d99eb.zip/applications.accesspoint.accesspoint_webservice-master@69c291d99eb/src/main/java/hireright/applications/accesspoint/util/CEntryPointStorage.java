/*
 * @(#)$RCSfile: CEntryPointStorage.java,v $ $Revision: 1.2 $ $Date: 2014/07/28 14:57:11 $ $Author: aputintsev $ 
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/util/CEntryPointStorage.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *     $Log: CEntryPointStorage.java,v $
 *     Revision 1.2  2014/07/28 14:57:11  aputintsev
 *     forked from production version - projects_src/applications/accesspoint
 *
 *     Revision 1.1.2.1.2.1  2009/08/18 11:09:20  asolntsev
 *     Bugfixing and polishing
 *
 *     Revision 1.1.2.1  2009/08/13 13:24:24  asolntsev
 *     Created by St.Petersburg team
 *
 *     Revision 1.2  2009/08/06 09:37:55  banton
 *     Added simple Finite State Machine support. Tested only for memory storage
 *
 *     Revision 1.1.1.1  2009/07/31 11:24:26  banton
 *     Task 39986 1.1
 *
 *     Revision 1.1  2009/07/30 12:14:07  banton
 *     Added proxy class and memory storage for CEntryPoint
 *
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hireright.applications.accesspoint.util;

import hireright.objects.utilities.CEntryPoint;

import java.util.HashMap;

/**
 *
 * @author banton
 */
public class CEntryPointStorage extends HashMap<String, CEntryPoint>
{
		private static final CEntryPointStorage instance = new CEntryPointStorage();

		public static CEntryPointStorage getInstance()
		{
				return instance;
		}
}
