package com.hireright.sourceintelligence.reports.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OperatorReportDTO {
    
    @JsonProperty("operatorName")
    private String operatorName;
    
    @JsonProperty("added")
    private ActionStatusCountDTO added;
    
    @JsonProperty("changed")
    private ActionStatusCountDTO changed;
    
    @JsonProperty("archived")
    private ActionStatusCountDTO archived;
    
    @JsonProperty("deleted")
    private ActionStatusCountDTO deleted;
    
    @JsonProperty("total")
    private int total;
}

