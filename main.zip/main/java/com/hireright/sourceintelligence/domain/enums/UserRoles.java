package com.hireright.sourceintelligence.domain.enums;

public enum UserRoles {

  QUALITY_ANALYST("QualityAnalyst"),
  RESEARCH_ANALYST("ResearchAnalyst"),
  MANAGER("Manager"),
  SUPERVISOR("Supervisor");

  private String role;

  UserRoles(String role) {
    this.role = role;
  }

  public String getRole() {
    return role;
  }
}
