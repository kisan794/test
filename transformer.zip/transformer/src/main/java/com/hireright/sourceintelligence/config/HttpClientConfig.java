package com.hireright.sourceintelligence.config;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.*;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.util.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import static org.springframework.http.HttpHeaders.CONTENT_TYPE;

@Slf4j
public class HttpClientConfig {

    @Retryable(
            value = {RestClientException.class, IOException.class},  // Retry on IOException and RuntimeException
            maxAttempts = 3,                                        // Max retry attempts
            backoff = @Backoff(delay = 2000, multiplier = 2)        // Exponential backoff starting at 2 seconds
    )
    public static String restClientPost(String url, MultipartFile file, String documentMeta) throws IOException {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        ByteArrayResource fileResource = new ByteArrayResource(file.getBytes()) {
            @Override
            public String getFilename() {
                return file.getOriginalFilename();
            }
        };
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("file", fileResource);
        body.add("documentMeta", documentMeta);

        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);
        restTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);
        throw new RestClientException("Exception: -->DMS API error");

    }

    // This method will be called when retries are exhausted
    @Recover
    public String recover(RestClientException e, String url, MultipartFile file, String documentMeta) {
        log.error("Retries exhausted for url: {}, file: {}", url, file.getOriginalFilename(), e);
        return "Upload failed after retries!";
    }

    public static String delete(String url) throws IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header(CONTENT_TYPE, "application/json")
                .DELETE()
                .build();

        try (HttpClient client = HttpClient.newHttpClient()) {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            log.info("Response status code:GET: {}", response.statusCode());
            log.info("Response body:GET: {}", response.body());
            return response.body();
        } catch (IOException | InterruptedException e) {
            log.error("Error occurred while performing GET request to {}: {}", url, e.getMessage(), e);
            Thread.currentThread().interrupt();
            return null;
        }
    }

    public static String get(String url) throws IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header(CONTENT_TYPE, "application/json")
                .GET()
                .build();

        try (HttpClient client = HttpClient.newHttpClient()) {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            log.info("Response status code:GET: {}", response.statusCode());
            log.info("Response body:GET: {}", response.body());
            return response.body();
        } catch (IOException | InterruptedException e) {
            log.error("Error occurred while performing GET request to {}: {}", url, e.getMessage(), e);
            Thread.currentThread().interrupt();
            return null;
        }
    }
}
