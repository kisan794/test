/*
 * @(#)$RCSfile: CPayloadRootAnnotationMethodEndpointMapping.java,v $ $Revision: 1.2 $ $Date: 2014/11/22 08:28:36 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/service/endpoints/mapping/CPayloadRootAnnotationMethodEndpointMapping.java,v $
 *
 * Copyright 2001-2014 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Putintsev	 2014-10-30	Created
 */
package hireright.applications.accesspoint.service.endpoints.mapping;

import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.mapping.PayloadRootAnnotationMethodEndpointMapping;
import org.springframework.ws.server.endpoint.support.PayloadRootUtils;

import javax.xml.namespace.QName;
import javax.xml.transform.TransformerFactory;

/**
 * 
 */
public class CPayloadRootAnnotationMethodEndpointMapping extends
		PayloadRootAnnotationMethodEndpointMapping {
	
	@SuppressWarnings("unused")
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";

	private TransformerFactory transformerFactory;

	public TransformerFactory getTransformerFactory()
	{
		return transformerFactory;
	}

	public void setTransformerFactory(TransformerFactory transformerFactory)
	{
		this.transformerFactory = transformerFactory;
	}

	@Override
	protected QName getLookupKeyForMessage(MessageContext messageContext) throws Exception
	{
		if (transformerFactory == null)
		{
			transformerFactory = TransformerFactory.newInstance();
		}

		return PayloadRootUtils.getPayloadRootQName(messageContext.getRequest().getPayloadSource(), transformerFactory);
	}
}
