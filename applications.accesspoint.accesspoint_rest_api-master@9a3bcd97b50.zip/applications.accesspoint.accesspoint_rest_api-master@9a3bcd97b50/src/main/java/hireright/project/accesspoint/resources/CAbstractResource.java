/*
 * @(#)$RCSfilev$ $Revision: 1.3.2.2 $ $Date: 2015/03/12 13:45:52 $ $Author: atanasenko $
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/resources/src/main/java/hireright/project/accesspoint/resources/CAbstractResource.java,v $
 *
 * Copyright 2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	J.Burlakova		2012-04-04	Created
 */

package hireright.project.accesspoint.resources;

import hireright.sdk.db.CConnection;
import hireright.sdk.db.CCurrentThreadConnection;
import hireright.sdk.util.CRuntimeException;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.concurrent.Callable;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.log4j.Logger;

/**
 *
 * @author Jekaterina Burlakova
 */
public class CAbstractResource 
{
	private static final String SECURITY_KEY = "Wslk2fs2AfsR4gz3";
	private static final Logger logger = Logger.getLogger(CAbstractResource.class);
	
	public Response handleThrowable(Throwable e)
	{
		return handleThrowable(e, logger, Response.Status.INTERNAL_SERVER_ERROR);
	}

	public Response handleThrowable(Throwable e, Response.Status status)
	{
		return handleThrowable(e, logger, status);
	}

	public Response handleThrowable(Throwable e, Logger logger)
	{
		return handleThrowable(e, logger, Response.Status.INTERNAL_SERVER_ERROR);
	}
	
	protected Response handleThrowable(Throwable e, Logger logger, Response.Status status)
	{
		if (logger != null)
		{
			logger.fatal(e);
		}
		
		ResponseBuilder resp = Response.status(status);
		resp.entity(e.getMessage());
		return resp.build();
	}
	
	
	protected boolean checkAuth(String securityKey)
	{
		/*String decryptedValue = "";
		try {
			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.DECRYPT_MODE, generateKey());
	 
			byte[] stringBytes = cipher.doFinal(Base64.decode(securityKey));
			decryptedValue = new String(stringBytes, "UTF8");
		} catch (Exception e) {
			return false;
		}
		DateFormat format = new SimpleDateFormat( "MM/dd/yyyy" );
		String date = format.format( new Date() );
		try {
			Cipher cipher2 = Cipher.getInstance("AES");
			cipher2.init(Cipher.ENCRYPT_MODE, generateKey());
			byte[] resultBytes = cipher2.doFinal( date.getBytes() );
			String resultString = Base64.encodeBytes( resultBytes );
			System.err.println(resultString);
		} catch (Exception e) {
			// TODO: handle exception
		}
		if (date.equals( decryptedValue )) {
			return true;
		}*/
		if (securityKey.equals( SECURITY_KEY )) {
			return true;
		}
		
		return false;
	}

	/*private Key  generateKey() throws NoSuchAlgorithmException, InvalidKeyException, InvalidKeySpecException {
		Key key = new SecretKeySpec(SECURITY_KEY.getBytes(), "AES");
		return key;
	}*/
	
	protected Response buildOkResult(String sContent)
	{
		ResponseBuilder resp = Response.status(Response.Status.OK);
		resp.entity(sContent);
		return resp.build();
	}
	
	protected <T> T withConnection(Callable<T> callable) {
		final Connection conn = openConnection();
		try {
			T t = callable.call();
			closeConnection(conn, true);
			return t;
		} catch(Throwable t) {
			closeConnection(conn, false);
			if(t instanceof RuntimeException) {
				throw (RuntimeException) t;
			}
			throw CRuntimeException.wrap(t);
		}
	}
	
	private static Connection openConnection()
	{
		try
		{
			Connection conn = CConnection.getConnection();
			
			if (conn == null)
			{
				throw new CRuntimeException("Connection is null");
			}
			else if (!CConnection.checkConnection(conn))
			{
				CConnection.closeConnection(conn);
				throw new CRuntimeException("Server is busy. Please try again.");
			}
			
			CCurrentThreadConnection.bind( conn );
			
			return conn;
		}
		catch (Exception e)
		{
			throw new CRuntimeException(e);
		}
	}
	
	private static void closeConnection(Connection conn, boolean commit)
	{
		try
		{
			if (conn != null && !conn.isClosed())
			{
				try
				{
					if(commit) conn.commit();
					else conn.rollback();
				}
				finally
				{
					CConnection.closeConnection(conn);
				}
			}
		} 
		catch (SQLException e) 
		{
			if (logger != null)
			{
				logger.fatal(e);
			}
		}
		finally
		{
			CCurrentThreadConnection.unbind();
		}
	}
	
}
