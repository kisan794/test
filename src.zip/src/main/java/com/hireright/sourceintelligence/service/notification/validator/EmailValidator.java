package com.hireright.sourceintelligence.service.notification.validator;

import com.hireright.sourceintelligence.api.dto.notification.EmailNotificationDTO;
import com.hireright.sourceintelligence.exception.EmailValidationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Validator for email notifications.
 * Follows Single Responsibility Principle - only validates email data.
 * Implements comprehensive validation rules as per requirements.
 */
@Slf4j
@Component
public class EmailValidator {
    
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
    );
    
    @Value("${notification.email.validation.strict:true}")
    private boolean strictValidation;
    
    @Value("${notification.email.domain.whitelist:}")
    private String domainWhitelist;
    
    @Value("${notification.email.domain.blacklist:}")
    private String domainBlacklist;
    
    @Value("${notification.email.subject.maxLength:200}")
    private int maxSubjectLength;
    
    @Value("${notification.email.body.maxLength:1048576}")
    private int maxBodyLength;
    
    @Value("${notification.email.recipients.max:100}")
    private int maxRecipients;
    
    /**
     * Validates the entire email notification DTO
     *
     * @param emailDTO the email notification to validate
     * @throws EmailValidationException if validation fails
     */
    public void validate(EmailNotificationDTO emailDTO) {
        log.debug("Validating email notification");
        
        validateRecipients(emailDTO);
        validateSubject(emailDTO.getSubject());
        validateBody(emailDTO.getBody());
        validateReplyTo(emailDTO.getReplyTo());
        
        log.debug("Email notification validation successful");
    }
    
    /**
     * Validates all recipient email addresses
     */
    private void validateRecipients(EmailNotificationDTO emailDTO) {
        List<String> allRecipients = new ArrayList<>();
        
        if (emailDTO.getTo() != null) {
            allRecipients.addAll(emailDTO.getTo());
        }
        
        if (emailDTO.getCc() != null) {
            allRecipients.addAll(emailDTO.getCc());
        }
        
        if (emailDTO.getBcc() != null) {
            allRecipients.addAll(emailDTO.getBcc());
        }
        
        if (allRecipients.isEmpty()) {
            throw new EmailValidationException("At least one recipient is required", "to");
        }
        
        if (allRecipients.size() > maxRecipients) {
            throw new EmailValidationException(
                    String.format("Total recipients (%d) exceed maximum allowed (%d)", 
                            allRecipients.size(), maxRecipients),
                    "recipients"
            );
        }
        
        for (String email : allRecipients) {
            validateEmailAddress(email);
        }
    }
    
    /**
     * Validates a single email address
     */
    public void validateEmailAddress(String email) {
        if (email == null || email.trim().isEmpty()) {
            throw new EmailValidationException("Email address cannot be empty");
        }
        
        email = email.trim();
        
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            throw new EmailValidationException(
                    String.format("Invalid email format: %s", email),
                    "email"
            );
        }
        
        if (strictValidation) {
            validateDomain(email);
        }
    }
    
    /**
     * Validates email domain against whitelist/blacklist
     */
    private void validateDomain(String email) {
        String domain = extractDomain(email);
        
        // Check blacklist first
        if (!domainBlacklist.isEmpty()) {
            List<String> blacklistedDomains = Arrays.asList(domainBlacklist.split(","));
            if (blacklistedDomains.stream().anyMatch(d -> domain.equalsIgnoreCase(d.trim()))) {
                throw new EmailValidationException(
                        String.format("Domain '%s' is blacklisted", domain),
                        "email"
                );
            }
        }
        
        // Check whitelist if configured
        if (!domainWhitelist.isEmpty()) {
            List<String> whitelistedDomains = Arrays.asList(domainWhitelist.split(","));
            if (whitelistedDomains.stream().noneMatch(d -> domain.equalsIgnoreCase(d.trim()))) {
                throw new EmailValidationException(
                        String.format("Domain '%s' is not whitelisted", domain),
                        "email"
                );
            }
        }
    }
    
    /**
     * Extracts domain from email address
     */
    private String extractDomain(String email) {
        int atIndex = email.indexOf('@');
        if (atIndex > 0 && atIndex < email.length() - 1) {
            return email.substring(atIndex + 1);
        }
        return "";
    }
    
    /**
     * Validates email subject
     */
    private void validateSubject(String subject) {
        if (subject == null || subject.trim().isEmpty()) {
            throw new EmailValidationException("Subject cannot be empty", "subject");
        }
        
        if (subject.length() > maxSubjectLength) {
            throw new EmailValidationException(
                    String.format("Subject length (%d) exceeds maximum allowed (%d)", 
                            subject.length(), maxSubjectLength),
                    "subject"
            );
        }
    }
    
    /**
     * Validates email body
     */
    private void validateBody(String body) {
        if (body == null || body.trim().isEmpty()) {
            throw new EmailValidationException("Body cannot be empty", "body");
        }
        
        if (body.length() > maxBodyLength) {
            throw new EmailValidationException(
                    String.format("Body size (%d bytes) exceeds maximum allowed (%d bytes)", 
                            body.length(), maxBodyLength),
                    "body"
            );
        }
    }
    
    /**
     * Validates reply-to address if present
     */
    private void validateReplyTo(String replyTo) {
        if (replyTo != null && !replyTo.trim().isEmpty()) {
            validateEmailAddress(replyTo);
        }
    }
}

