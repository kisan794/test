package com.hireright.sourceintelligence.domain.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum ApprovalStatus {

	IN_PROGRESS("IN_PROGRESS"), PENDING_APPROVAL("PENDING_APPROVAL"),
	APPROVED("APPROVED"), REJECTED("REJECTED"),
	ONHOLD("ONHOLD"),
	SAVE_PENDING_APPROVAL("SAVE_PENDING_APPROVAL");

	private final String status;

	ApprovalStatus(String status) {
		this.status = status;
	}

	@JsonCreator
	public static ApprovalStatus fromString(String status) {
		return status == null ? null : ApprovalStatus.valueOf(status.toUpperCase());
	}

	@Override
	public String toString() {
		return status;
	}

	@JsonValue
	public String getStatus() {
		return this.status.toUpperCase();
	}
}
