<html>
<!--	$Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webapp/src/main/webapp/index.jsp,v $
			$Revision: 1.2 $ $Date: 2014/07/28 14:52:33 $ $Author: aputintsev $
	-->
<body>
<h2>Hello World!</h2>
</body>
</html>
