package hireright.applications.igniting_innovations.service;

import hireright.applications.igniting_innovations.document.IdeaSubmission;
import hireright.applications.igniting_innovations.dto.IdeaSubmissionRequest;
import hireright.applications.igniting_innovations.dto.IdeaSubmissionResponse;
import hireright.applications.igniting_innovations.repository.IdeaSubmissionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 * Service for managing idea submissions.
 * Handles business logic for creating, updating, and retrieving ideas.
 *
 * @author Generated
 * @version 1.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class IdeaSubmissionService {

    private final IdeaSubmissionRepository ideaSubmissionRepository;

    /**
     * Create a new idea submission.
     */
    public IdeaSubmissionResponse createIdea(IdeaSubmissionRequest request) {
        log.info("Creating new idea submission: {}", request.getFormData().getTitle());

        LocalDateTime now = LocalDateTime.now();

        IdeaSubmission idea = IdeaSubmission.builder()
                .title(request.getFormData().getTitle())
                .submittedBy(request.getFormData().getSubmittedBy())
                .emailAddress(request.getEmailAddress())
                .department(request.getFormData().getDepartment())
                .submissionDate(now)
                .description(request.getFormData().getDescription())
                .objective(request.getFormData().getObjective())
                .impactAreas(request.getFormData().getImpactAreas())
                .improvementTypes(request.getFormData().getImprovementTypes())
                .improvementTypeOther(request.getFormData().getImprovementTypeOther())
                .expectedBenefit(request.getFormData().getExpectedBenefit())
                .impactCategories(request.getFormData().getImpactCategories())
                .impactCategoryOther(request.getFormData().getImpactCategoryOther())
                .implementationComplexity(request.getFormData().getImplementationComplexity())
                .suggestedSteps(request.getFormData().getSuggestedSteps())
                .timelineType(request.getFormData().getTimelineType())
                .supportingDocuments(request.getFormData().getSupportingDocuments())
                .additionalComments(request.getFormData().getAdditionalComments())
                .status(request.getStatus())
                .upvoteCount(0)
                .createdAt(now)
                .updatedAt(now)
                .comments(new ArrayList<>())
                .build();

        IdeaSubmission savedIdea = ideaSubmissionRepository.save(idea);
        log.info("Idea submission created successfully with ID: {}", savedIdea.getId());

        return mapToResponse(savedIdea);
    }

    /**
     * Get idea by ID.
     */
    public IdeaSubmissionResponse getIdeaById(String id) {
        log.info("Fetching idea with ID: {}", id);
        IdeaSubmission idea = ideaSubmissionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Idea not found with ID: " + id));
        return mapToResponse(idea);
    }

    /**
     * Get all ideas with pagination.
     */
    public Page<IdeaSubmissionResponse> getAllIdeas(Pageable pageable) {
        log.info("Fetching all ideas with pagination");
        return ideaSubmissionRepository.findAll(pageable)
                .map(this::mapToResponse);
    }

    /**
     * Delete an idea.
     */
    public void deleteIdea(String id) {
        log.info("Deleting idea with ID: {}", id);
        if (!ideaSubmissionRepository.existsById(id)) {
            throw new RuntimeException("Idea not found with ID: " + id);
        }
        ideaSubmissionRepository.deleteById(id);
        log.info("Idea deleted successfully");
    }

    // Helper methods
    private IdeaSubmissionResponse mapToResponse(IdeaSubmission idea) {
        return IdeaSubmissionResponse.builder()
                .id(idea.getId())
                .title(idea.getTitle())
                .submittedBy(idea.getSubmittedBy())
                .emailAddress(idea.getEmailAddress())
                .department(idea.getDepartment())
                .submissionDate(idea.getSubmissionDate())
                .description(idea.getDescription())
                .objective(idea.getObjective())
                .impactAreas(idea.getImpactAreas())
                .improvementTypes(idea.getImprovementTypes())
                .improvementTypeOther(idea.getImprovementTypeOther())
                .expectedBenefit(idea.getExpectedBenefit())
                .impactCategories(idea.getImpactCategories())
                .impactCategoryOther(idea.getImpactCategoryOther())
                .implementationComplexity(idea.getImplementationComplexity())
                .suggestedSteps(idea.getSuggestedSteps())
                .timelineType(idea.getTimelineType())
                .supportingDocuments(idea.getSupportingDocuments())
                .additionalComments(idea.getAdditionalComments())
                .status(idea.getStatus())
                .createdAt(idea.getCreatedAt())
                .updatedAt(idea.getUpdatedAt())
                .build();
    }
    
}

