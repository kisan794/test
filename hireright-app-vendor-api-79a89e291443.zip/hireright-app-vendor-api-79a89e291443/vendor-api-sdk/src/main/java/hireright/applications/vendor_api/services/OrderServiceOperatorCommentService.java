package hireright.applications.vendor_api.services;
/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	2017-08-16	Created
 *	T.Prikk		2018-04-11	HIVPE-26547: Constant added
 *	ez			2022-08-11	HRG-133388: Probably different path for update should be created to stop conflicting with delete path.
 *	M.Kuznetsov	2025-10-29	HRG-345322. Openjdk21-migration
 */

import org.springframework.web.bind.annotation.RequestMethod;

import hireright.components.domain.dialects.vendor_api.BasicResponse;
import hireright.components.domain.dialects.vendor_api.Comment;

public class OrderServiceOperatorCommentService {
    public static final String VAR_ORDER_REF = "orderRef";
    public static final String VAR_ORDER_SERVICE_REF = "orderServiceRef";
    public static final String VAR_COMMENT_REF = "commentRef";

    public static final String PATH_ADD =
            "/orders/{" + VAR_ORDER_REF + "}/services/{" + VAR_ORDER_SERVICE_REF + "}/add/comments";
    public static final String PATH_UPDATE =
            "/orders/{" + VAR_ORDER_REF + "}/services/{" + VAR_ORDER_SERVICE_REF + "}/update/comments/{" +
                    VAR_COMMENT_REF + "}";
    public static final String PATH_DELETE =
            "/orders/{" + VAR_ORDER_REF + "}/services/{" + VAR_ORDER_SERVICE_REF + "}/delete/comments/{" +
                    VAR_COMMENT_REF + "}";

    public enum EReferenceType {
        ORDER_SERVICE,
        PROPERTIES,
        ORDER_SERVICE_OPERATOR_COMMENT
    }

    public enum EResponseParam {
        COMMENT_ID
    }

    public enum EMethod implements IMethod {
        ADD(PATH_ADD, RequestMethod.POST, Comment.class, BasicResponse.class),
        UPDATE(PATH_UPDATE, RequestMethod.PUT, Comment.class, BasicResponse.class),
        DELETE(PATH_DELETE, RequestMethod.DELETE, null, BasicResponse.class);

        private final String path;
        private final RequestMethod requestMethod;
        private final Class<?> requestBodyClass;
        private final Class<?> responseBodyClass;

        EMethod(String sPath,
                RequestMethod requestMethod,
                Class<?> requestBodyClass,
                Class<?> responseBodyClass) {
            this.path = sPath;
            this.requestMethod = requestMethod;
            this.requestBodyClass = requestBodyClass;
            this.responseBodyClass = responseBodyClass;
        }

        public String getPath() {
            return this.path;
        }

        public RequestMethod getRequestMethod() {
            return this.requestMethod;
        }

        public Class<?> getRequestBodyClass() {
            return this.requestBodyClass;
        }

        public Class<?> getResponseBodyClass() {
            return this.responseBodyClass;
        }

        public boolean isValidRequest(Object request) {
            return true;
        }
    }
}
