package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.Alias;
import com.hireright.sourceintelligence.api.dto.ContactDetailsDTO;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchSourceDTO;
import com.hireright.sourceintelligence.api.dto.optool.ContactDTO;
import com.hireright.sourceintelligence.api.dto.optool.MailAddressDTO;
import com.hireright.sourceintelligence.api.dto.optool.PhoneFaxDTO;
import com.hireright.sourceintelligence.domain.constants.Constants;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import io.jsonwebtoken.lang.Strings;
import org.json.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.*;

import static com.hireright.sourceintelligence.domain.constants.Constants.AutoMatchConstants.*;
import static com.hireright.sourceintelligence.domain.constants.Constants.AutoMatchConstants.CODES;
import static com.hireright.sourceintelligence.domain.constants.Constants.SmartSearchKeys.*;
import static com.hireright.sourceintelligence.domain.constants.Constants.SmartSearchKeys.NAME;
import static com.hireright.sourceintelligence.domain.constants.Constants.VENDORS.*;
import static com.hireright.sourceintelligence.domain.mapper.SourceMapper.mapToJSONObject;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.ReportActions.CREATE;
import static kotlin.reflect.jvm.internal.impl.builtins.StandardNames.FqNames.list;

@SuppressWarnings("ALL")
@Mapper(componentModel = "spring", imports = {JSONObject.class, JSONArray.class})
public interface AutoMatchMapper {


    // Helper Methods
    default String getPayloadFieldForStrings(Source source, String key) {
        if (source.getPayload() != null) {
            JSONObject payload = mapToJSONObject(source.getPayload());
            if(key.equals(DEPARTMENT_NAME) || (key.equals(NOTES) && payload.has(NOTES))){
                if(payload.get(key) != null){
                    return base64BEEncoder(payload.getString(key));
                }
            }else{
                return payload.has(key) ? (payload.get(key) != null ? payload.getString(key) : "") : "";
            }
        }
        return "";
    }

    default Boolean getPayloadFieldForBoolean(Source source, String key) {
        if (source.getPayload() != null) {
            JSONObject payload = mapToJSONObject(source.getPayload());
            return payload.has(key) && payload.getBoolean(key);
        }
        return false;
    }

    default Instant getLastModifiedDate(Source source, String lastModifiedDate) {
        if (source.getAction().equals(CREATE)) {
            return null;
        }
        return source.getLastModifiedDate();
    }



    default String mapInstitute(Source source) {
        if (source.getPayload() != null) {
            JSONObject payload = mapToJSONObject(source.getPayload());
            if (payload.has(RELATIONSHIPS)) {
                JSONArray relationships = payload.getJSONArray(RELATIONSHIPS);
                if (!relationships.isEmpty()) {
                    JSONObject relationship = relationships.getJSONObject(0);
                    return OrganizationType.EDUCATION.getType().equalsIgnoreCase(source.getOrganizationType().getType()) ? relationship.optString(NAME) : null;
                }
            }
        }
        return null;
    }
    default String mapCompany(Source source) {
        if (source.getPayload() != null) {
            JSONObject payload = mapToJSONObject(source.getPayload());
            if (payload.has(RELATIONSHIPS)) {
                JSONArray relationships = payload.getJSONArray(RELATIONSHIPS);
                if (!relationships.isEmpty()) {
                    JSONObject relationship = relationships.getJSONObject(0);
                    return OrganizationType.EMPLOYMENT.getType().equalsIgnoreCase(source.getOrganizationType().getType()) ? relationship.optString(NAME) : null;
                }
            }
        }
        return null;
    }

    default Boolean getDoNotContact(Source source) {
        if (source.getPayload() != null) {
            JSONObject payload = mapToJSONObject(source.getPayload());
            if (payload.has(ADDITIONAL_INFO)) {
                JSONArray additionalInfo = payload.getJSONArray(ADDITIONAL_INFO);
                if (!additionalInfo.isEmpty()) {
                    JSONObject additionalInfoJSONObject = additionalInfo.getJSONObject(0);
                    String doNotContact = additionalInfoJSONObject.optString(DO_NOT_CONTACT);
                    if(!doNotContact.equals(Strings.EMPTY)){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    default String getAdditionalInfo(Source source, String fieldName) {
        if (source.getPayload() == null) {
            return "";
        }

        JSONObject payload = mapToJSONObject(source.getPayload());
        if (!payload.has(ADDITIONAL_INFO)) {
            return "";
        }

        JSONArray additionalInfo = payload.getJSONArray(ADDITIONAL_INFO);
        if (additionalInfo.isEmpty()) {
            return "";
        }

        JSONObject info = additionalInfo.getJSONObject(0);
        String doNotContact = info.optString(DO_NOT_CONTACT);

        return switch (fieldName) {
            case CONTACT_PERSON_NAME, CONTACT_PERSON_TITLE, SOURCE_LANGUAGE ->
                    handleContactInfoField(info, fieldName, doNotContact);
            case CONTACT_TIME_FROM, CONTACT_TIME_TO, CONTACT_TIME_ZONE, RELEASE_TYPE ->
                    handleTimeOrReleaseField(payload, info, fieldName, doNotContact);
            default ->
                    getFieldValue(info, fieldName);
        };
    }

    private String handleContactInfoField(JSONObject info, String fieldName, String doNotContact) {
        if (doNotContact.equals(Strings.EMPTY)) {
            return getFieldValue(info, fieldName);
        }
        return "";
    }

    private String handleTimeOrReleaseField(JSONObject payload, JSONObject info, String fieldName, String doNotContact) {
        boolean isAutomated = isAutomatedServiceAvailable(payload);
        if (!isAutomated && !doNotContact.equals(Strings.EMPTY)) {
            return "";
        }
        return getFieldValue(info, fieldName);
    }

    private String getFieldValue(JSONObject jsonObject, String fieldName) {
        return jsonObject.has(fieldName) ? jsonObject.optString(fieldName, "") : "";
    }


    default String getAddress(Source source) {
        if (source.getPayload() != null) {
            JSONObject payload = mapToJSONObject(source.getPayload());
            if (payload.has(ADDRESS)) {
                JSONArray address = payload.getJSONArray(ADDRESS);
                JSONObject addressJSONObject = address.getJSONObject(0);
                if (addressJSONObject.has(LINE)) {
                    return addressJSONObject.getString(LINE);
                }
            }
        }
        return null;
    }

    default boolean isAutomatedServiceAvailable(JSONObject payload) {
        if (payload == null) {
            return false;
        }

        JSONArray contacts = payload.optJSONArray(CONTACTS);
        if (contacts == null || contacts.isEmpty()) {
            return false;
        }

        JSONObject firstContact = contacts.optJSONObject(0);
        if (firstContact == null) {
            return false;
        }

        JSONArray contactDetails = firstContact.optJSONArray(CONTACT_DETAILS);
        if (contactDetails == null || contactDetails.isEmpty()) {
            return false;
        }

        for (int i = 0; i < contactDetails.length(); i++) {
            JSONObject contactDetail = contactDetails.optJSONObject(i);
            if (contactDetail == null) {
                continue;
            }

            String type = contactDetail.optString(TYPE, "");
            if (CONTACT_AUTOMATED_SERVICES.equals(type)) {
                return true;
            }
        }

        return false;
    }

    default List<Map<String, Object>> mapContactDetailsForAS(Source source) {
        List<Map<String, Object>> contactDetailsDTOS = new ArrayList<>();
        if (source.getPayload() != null) {
            JSONObject payload = mapToJSONObject(source.getPayload());
            if (payload.has(CONTACTS) && payload.get(CONTACTS) != null) {
                var contacts = (JSONArray) payload.get(CONTACTS);
                if (!contacts.isEmpty()) {
                    var contactDetails = ((JSONObject) contacts.get(0)).has(CONTACT_DETAILS) ? (JSONArray) ((JSONObject) contacts.get(0)).get(CONTACT_DETAILS) : new JSONArray();
                    if (contactDetails != null && !contactDetails.isEmpty()) {
                        for (Object contactDetail : contactDetails) {
                            JSONObject contactDetailJson = (JSONObject) contactDetail;
                            if (contactDetailJson.has(TYPE) && !contactDetailJson.isNull(TYPE)) {
                                String key = (String) contactDetailJson.get(TYPE);
                                if (key.equals(CONTACT_AUTOMATED_SERVICES)) {
                                    if (contactDetailJson.has(COMMUNICATION) && contactDetailJson.get(COMMUNICATION) != null) {
                                        var communication = (JSONArray) contactDetailJson.get(COMMUNICATION);
                                        if (!communication.isEmpty()) {
                                            for (Object commObj : communication) {
                                                Map<String, Object> contactDTO = new HashMap<>();
                                                //ContactDTO contactDTO = new ContactDTO();
                                                var commObjJson = (JSONObject) commObj;
                                                if(contactDetailJson.has(PRIORITY)){
                                                    if(contactDetailJson.get(PRIORITY) instanceof String){
                                                        contactDTO.put(PRIORITY,Integer.parseInt(contactDetailJson.getString(PRIORITY)));
                                                    }else{
                                                        contactDTO.put(PRIORITY,contactDetailJson.getInt(PRIORITY));
                                                    }
                                                }
                                                String name = commObjJson.getString(AS_NAME);
                                                contactDTO.put(AS_NAME,name);
                                                contactDTO.put(PROVIDER,commObjJson.has(PROVIDER_ID) ? Integer.parseInt(commObjJson.getString(PROVIDER_ID)) : DEFAULT_PROVIDER);
                                                var communicationInfo = (JSONArray) (commObjJson.get(COMMUNICATION_INFO));
                                                if (communicationInfo.length() > 0) {
                                                    String fromYear = "";
                                                    String toYear = "";
                                                    for (Object comminfo : communicationInfo) {
                                                        var communicationInfoJSON = (JSONObject) comminfo;
                                                        if (communicationInfoJSON.has(TYPE) && !communicationInfoJSON.isNull(TYPE)) {
                                                            switch (communicationInfoJSON.getString(TYPE)) {
                                                                case URI ->
                                                                        contactDTO.put(PROVIDER_LINK,communicationInfoJSON.has(VALUE) ? communicationInfoJSON.getString(VALUE) : "");
                                                                case CODES ->{
                                                                    String codes = communicationInfoJSON.getString(VALUE);
                                                                    if(!codes.isBlank()){
                                                                        String[] codesArray = codes.split(";");
                                                                        contactDTO.put(CODES,codesArray);
                                                                        String schCodes = String.join(":", codesArray);
                                                                        if(name.equalsIgnoreCase(NSCH)){
                                                                            contactDTO.put(NSCH_CODES,schCodes);
                                                                        }else if(name.equalsIgnoreCase(EQUIFAX_EDU)){
                                                                            contactDTO.put(EQUIFAX_EDU_CODES,schCodes);
                                                                        }else if(name.equalsIgnoreCase(EQUI_FAX_HS)){
                                                                            contactDTO.put(EQUIFAX_SCHOOL_CODES,schCodes);
                                                                        }  else if(name.equalsIgnoreCase(TALX_WORK_NUMBER)){
                                                                            contactDTO.put(TALX_WORK_NUMBER_CODES,schCodes);
                                                                        }
                                                                    }
                                                                }
                                                                case COMPANY_NAMES -> {
                                                                    String instName = communicationInfoJSON.getString(VALUE);
                                                                    if (name.equalsIgnoreCase(NSCH)) {
                                                                        if(!instName.isEmpty()){
                                                                            String[] instNameArray = instName.split(";");
                                                                            for (int i = 0; i < instNameArray.length; i++) {
                                                                                contactDTO.put(NSCH_INST_NAME+(i+1),instNameArray[i]);
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                                case AS_BRANCH -> {
                                                                    String branch = communicationInfoJSON.getString(VALUE);
                                                                    if (!branch.isBlank()) {
                                                                        String[] codesArray = branch.split(";");
                                                                        contactDTO.put(BRANCHES,codesArray);
                                                                    }
                                                                }
                                                                case FROM_YEAR -> fromYear = communicationInfoJSON.getString(VALUE);
                                                                case TO_YEAR -> toYear = communicationInfoJSON.getString(VALUE);
                                                                case SUR_CHARGE_AMOUNT -> {
                                                                    String value = communicationInfoJSON.getString(VALUE);
                                                                    if (!value.isEmpty()) {
                                                                        contactDTO.put(SURCHARGE_AMOUNT, communicationInfoJSON.getString(VALUE));
                                                                    }
                                                                }
                                                                case SUR_CHARGE_CURRENCY -> {
                                                                    String value = communicationInfoJSON.getString(VALUE);
                                                                    if (!value.isEmpty()) {
                                                                        contactDTO.put(SURCHARGE_CURRENCY, communicationInfoJSON.getString(VALUE));
                                                                    }
                                                                }
                                                                case PAYMENT_METHOD -> {
                                                                    String value = communicationInfoJSON.getString(VALUE);
                                                                    if (!value.isEmpty()) {
                                                                        contactDTO.put(PAYMENT_METHOD, communicationInfoJSON.getString(VALUE));
                                                                    }
                                                                }
                                                                case AM_FOLLOW_UP_ALLOWED -> {
                                                                    String value = communicationInfoJSON.getString(VALUE);
                                                                    if (!value.isEmpty()) {
                                                                        contactDTO.put(AM_FOLLOW_UP_ALLOWED, communicationInfoJSON.getString(VALUE));
                                                                    }
                                                                }
                                                                case AM_FOLLOW_UP_ALLOWED_AFTER -> {
                                                                    String value = communicationInfoJSON.getString(VALUE);
                                                                    if (!value.isEmpty()) {
                                                                        contactDTO.put(AM_FOLLOW_UP_ALLOWED_AFTER, communicationInfoJSON.getString(VALUE));
                                                                    }
                                                                }
                                                                case FOLLOW_UP_ALLOWED_AFTER_TIME_UNIT ->{
                                                                    String value = communicationInfoJSON.getString(VALUE);
                                                                    if (!value.isEmpty()) {
                                                                        contactDTO.put(FOLLOW_UP_ALLOWED_AFTER_TIME_UNIT, communicationInfoJSON.getString(VALUE));
                                                                    }
                                                                }
                                                                case TURN_AROUNT_TIME ->{
                                                                    String value = communicationInfoJSON.getString(VALUE);
                                                                    if (!value.isEmpty()) {
                                                                        contactDTO.put(TURN_AROUNT_TIME, communicationInfoJSON.getString(VALUE));
                                                                    }
                                                                }
                                                                case TURN_AROUNT_TIME_UNIT ->{
                                                                    String value = communicationInfoJSON.getString(VALUE);
                                                                    if (!value.isEmpty()) {
                                                                        contactDTO.put(TURN_AROUNT_TIME_UNIT, communicationInfoJSON.getString(VALUE));
                                                                    }
                                                                }
                                                                default -> {
                                                                }
                                                            }
                                                        }
                                                    }
                                                    if(name.equalsIgnoreCase(EQUI_FAX_HS) && !fromYear.isEmpty() && !toYear.isEmpty()){
                                                        contactDTO.put(EQUI_FAX_HS_DATE_RANGE,fromYear+","+toYear);
                                                    }
                                                }
                                                if(!contactDTO.isEmpty()){
                                                    contactDetailsDTOS.add(contactDTO);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return contactDetailsDTOS;
    }

    default boolean isDoNotContact(JSONObject payload) {
        JSONArray additionalInfoList = payload.getJSONArray(ADDITIONAL_INFO);
        JSONObject additionalInfoJSONObject = additionalInfoList.getJSONObject(0);
        String doNotContact = additionalInfoJSONObject.has(DO_NOT_CONTACT) ? additionalInfoJSONObject.getString(DO_NOT_CONTACT) : "";
        return !doNotContact.isEmpty() && !doNotContact.equalsIgnoreCase("false");
    }

    default void mapContactBaseDTO(JSONObject contactDetailJson, ContactDTO contactDTO) {
        setPriority(contactDetailJson, contactDTO);
        setTurnAroundTime(contactDetailJson, contactDTO);
        setFollowUpDetails(contactDetailJson, contactDTO);
        setSurcharge(contactDetailJson, contactDTO);
        setPayment(contactDetailJson, contactDTO);
    }

    private void setPriority(JSONObject json, ContactDTO dto) {
        if (!hasValue(json, PRIORITY)) return;

        Object value = json.get(PRIORITY);
        if (value instanceof String strValue) {
            dto.setPriority(Integer.parseInt(strValue));
        } else if (value instanceof Number numValue) {
            dto.setPriority(numValue.intValue());
        }
    }

    private void setTurnAroundTime(JSONObject json, ContactDTO dto) {
        if (!hasValue(json, TURN_AROUND_TIME)) return;

        String turnAroundTime = json.getString(TURN_AROUND_TIME);
        dto.setTurnAroundTime(turnAroundTime);

        if (hasValue(json, TURN_AROUND_TIME_UNIT)) {
            dto.setTurnAroundTimeUnit(json.getString(TURN_AROUND_TIME_UNIT));
        }
    }

    private void setFollowUpDetails(JSONObject json, ContactDTO dto) {
        if (!json.has(FOLLOW_UP_ALLOWED) || json.isNull(FOLLOW_UP_ALLOWED)) return;

        Object followUp = json.get(FOLLOW_UP_ALLOWED);
        if (followUp instanceof Boolean boolValue) {
            dto.setIsFollowUpAllowed(Boolean.toString(boolValue));
        } else if (followUp instanceof String strValue) {
            dto.setIsFollowUpAllowed(strValue);
        }

        if (json.has(FOLLOW_UP_ALLOWED_AFTER)) {
            dto.setFollowUpAllowedAfter(json.optString(FOLLOW_UP_ALLOWED_AFTER));
            dto.setFollowUpAllowedAfterUnit(json.optString(FOLLOW_UP_ALLOWED_AFTER_UNITS, "days"));
        }
    }

    private void setSurcharge(JSONObject json, ContactDTO dto) {
        if (!hasValue(json, SUR_CHARGE_AMOUNT)) return;

        dto.setSurchargeAmount(json.optString(SUR_CHARGE_AMOUNT));
        dto.setSurchargeCurrency(json.optString(SUR_CHARGE_CURRENCY));
    }

    private void setPayment(JSONObject json, ContactDTO dto) {
        if (hasValue(json, SUR_CHARGE_PAYMENT)) {
            dto.setPaymentMethod(json.getString(SUR_CHARGE_PAYMENT));
        }
    }

    private boolean hasValue(JSONObject json, String key) {
        return json.has(key)
                && !json.isNull(key)
                && !json.optString(key).isEmpty();
    }


    default void mapCommunication(String key, JSONArray communication, ContactDTO contactDTO) {
        List<PhoneFaxDTO> phoneNumbers = new ArrayList<>();
        List<PhoneFaxDTO> faxNumbers = new ArrayList<>();
        List<String> emailList = new ArrayList<>();
        List<MailAddressDTO> mails = new ArrayList<>();
        List<String> websites = new ArrayList<>();

        for (Object communicationList : communication) {
            JSONObject commObj = (JSONObject) communicationList;
            contactDTO.setContact(buildContactName(commObj));

            if (!commObj.has(COMMUNICATION_INFO)) continue;

            JSONArray infoArray = commObj.getJSONArray(COMMUNICATION_INFO);
            if (infoArray == null || infoArray.isEmpty()) continue;

            PhoneFaxDTO phoneFaxDTO = new PhoneFaxDTO();
            MailAddressDTO mailAddress = new MailAddressDTO();

            processCommunicationInfo(key, infoArray, phoneFaxDTO, mailAddress, emailList, websites);

            addIfNotEmpty(key, phoneFaxDTO, mailAddress, phoneNumbers, faxNumbers, mails);
        }

        assignIfNotEmpty(contactDTO, phoneNumbers, faxNumbers, emailList, mails, websites);
    }

    private String buildContactName(JSONObject commObj) {
        StringBuilder contactName = new StringBuilder();
        if (commObj.has(NAME)) contactName.append(commObj.getString(NAME));
        if (commObj.has(RECEIPT)) {
            if (contactName.length() > 0) contactName.append(",");
            contactName.append(commObj.getString(RECEIPT));
        }
        if (commObj.has(DEPARTMENT) && !commObj.isNull(DEPARTMENT)) {
            if (contactName.length() > 0) contactName.append("-");
            contactName.append(commObj.getString(DEPARTMENT));
        }
        return contactName.toString();
    }


    private void processCommunicationInfo(String key, JSONArray infoArray,
                                          PhoneFaxDTO phoneFaxDTO, MailAddressDTO mailAddress,
                                          List<String> emailList, List<String> websites) {
        for (Object infoObj : infoArray) {
            if (!(infoObj instanceof JSONObject info)) continue;
            if (!info.has(TYPE)) continue;

            String type = info.optString(TYPE);
            String value = info.isNull(VALUE) ? "" : info.optString(VALUE);

            switch (key) {
                case CONTACT_PHONES, CONTACT_FAXES -> mapPhoneOrFax(type, value, phoneFaxDTO);
                case CONTACT_MAILS -> mapMail(type, value, mailAddress);
                case CONTACT_EMAILS -> mapEmail(type, value, emailList);
                case CONTACT_WEBSITES -> mapWebsite(type, value, websites);
                default -> { }
            }
        }
    }

    private void mapPhoneOrFax(String type, String value, PhoneFaxDTO dto) {
        switch (type) {
            case AREA_CODE -> dto.setAreaCode(value.trim());
            case COUNTRY_CODE -> dto.setCountryCode(value.trim());
            case PHONE_COUNTRY_CODE -> dto.setPhoneCountryCode(value.trim());
            case PHONE_NUMBER -> dto.setNumber(value.trim());
            case EXTENSION -> dto.setExtension(value.trim());
            default -> { }
        }
    }

    private void mapMail(String type, String value, MailAddressDTO mail) {
        switch (type) {
            case "countryName" -> mail.setCountry(value);
            case "region", "state" -> mail.setRegion(value);
            case "city" -> {
                mail.setCity(base64BEEncoder(value));
            }
            case "address" -> mail.setAddress(value);
            case "postalCode" -> mail.setPostalCode(value);
            default -> { }
        }
    }

    private void mapEmail(String type, String value, List<String> emailList) {
        if (ADDRESS.equals(type)) {
            emailList.add(value.trim().toLowerCase());
        }
    }

    private void mapWebsite(String type, String value, List<String> websites) {
        if (ADDRESSES.equals(type)) {
            websites.add(value.trim().toLowerCase());
        }
    }

    private void addIfNotEmpty(String key, PhoneFaxDTO phoneFaxDTO, MailAddressDTO mailAddress,
                               List<PhoneFaxDTO> phoneNumbers, List<PhoneFaxDTO> faxNumbers, List<MailAddressDTO> mails) {
        if (CONTACT_PHONES.equals(key) && !phoneFaxDTO.isEmpty()) phoneNumbers.add(phoneFaxDTO);
        if (CONTACT_FAXES.equals(key) && !phoneFaxDTO.isEmpty()) faxNumbers.add(phoneFaxDTO);
        if (CONTACT_MAILS.equals(key) && mailAddress != null && !mailAddress.isEmpty()) mails.add(mailAddress);
    }

    private void assignIfNotEmpty(ContactDTO contactDTO,
                                  List<PhoneFaxDTO> phoneNumbers, List<PhoneFaxDTO> faxNumbers,
                                  List<String> emailList, List<MailAddressDTO> mails, List<String> websites) {
        if (!phoneNumbers.isEmpty()) contactDTO.setNumbers(phoneNumbers);
        if (!faxNumbers.isEmpty()) contactDTO.setNumbers(faxNumbers);
        if (!emailList.isEmpty()) contactDTO.setEmails(emailList);
        if (!mails.isEmpty()) contactDTO.setAddresses(mails);
        if (!websites.isEmpty()) contactDTO.setWebsites(websites);
    }


    default ContactDTO mapContactDetails(Source source, String contactType) {
        ContactDTO contactDTO = new ContactDTO();
        if (source.getPayload() == null) return contactDTO;

        JSONObject payload = mapToJSONObject(source.getPayload());
        JSONArray contacts = getJSONArray(payload, CONTACTS);
        if (contacts == null || contacts.isEmpty()) return contactDTO;

        JSONArray contactDetails = getContactDetails(contacts);
        if (contactDetails == null || contactDetails.isEmpty()) return contactDTO;

        if (isDoNotContact(payload)) return null;

        mapMatchingContactDetails(contactDetails, contactType, contactDTO);
        handleFaxCountryCodeInheritance(source, contactType, contactDTO);

        return contactDTO;
    }

    private JSONArray getJSONArray(JSONObject obj, String key) {
        return (obj.has(key) && obj.get(key) instanceof JSONArray)
                ? (JSONArray) obj.get(key)
                : null;
    }

    private JSONArray getContactDetails(JSONArray contacts) {
        if (contacts.isEmpty()) return null;
        JSONObject firstContact = (JSONObject) contacts.get(0);
        return firstContact.has(CONTACT_DETAILS)
                ? (JSONArray) firstContact.get(CONTACT_DETAILS)
                : null;
    }

    private void mapMatchingContactDetails(JSONArray contactDetails, String contactType, ContactDTO contactDTO) {
        for (Object detail : contactDetails) {
            JSONObject detailJson = (JSONObject) detail;
            if (!detailJson.has(TYPE) || detailJson.isNull(TYPE)) continue;

            String key = detailJson.getString(TYPE);
            if (!key.equals(contactType)) continue;

            mapContactBaseDTO(detailJson, contactDTO);
            JSONArray communication = getJSONArray(detailJson, COMMUNICATION);
            if (communication != null && !communication.isEmpty()) {
                mapCommunication(key, communication, contactDTO);
            }
        }
    }

    private void handleFaxCountryCodeInheritance(Source source, String contactType, ContactDTO contactDTO) {
        if (!CONTACT_FAXES.equals(contactType)
                || contactDTO.getNumbers() == null
                || contactDTO.getNumbers().isEmpty()) {
            return;
        }

        ContactDTO phoneDTO = mapContactDetails(source, CONTACT_PHONES);
        if (hasNumbers(phoneDTO)) {
            String countryCode = phoneDTO.getNumbers().get(0).getCountryCode();
            applyCountryCode(contactDTO, countryCode);
        } else {
            contactDTO.getNumbers().forEach(fax ->
                    fax.setCountryCode(fax.getPhoneCountryCode()));
        }
    }

    private boolean hasNumbers(ContactDTO dto) {
        return dto != null && dto.getNumbers() != null && !dto.getNumbers().isEmpty();
    }

    private void applyCountryCode(ContactDTO dto, String countryCode) {
        if (dto.getNumbers() != null) {
            dto.getNumbers().forEach(num -> num.setCountryCode(countryCode));
        }
    }


    default List<String> mapOrganizationAlias(Alias[] aliases) {
        if (aliases != null && aliases.length > 0) {
            List<String> aliasesList = new ArrayList<>();
            for (Alias alias : aliases) {
                if(alias.getName() != null && !alias.getName().isEmpty()){
                    aliasesList.add(base64BEEncoder(alias.getName()));
                }
            }
            return aliasesList;
        }
        return new ArrayList<>();
    }

    default int mapUsedCount(Source source) {
        if (source.getPayload() != null) {
            JSONObject payload = mapToJSONObject(source.getPayload());
            if (payload.has(USED_COUNT)) {
                return (int) payload.get(USED_COUNT);
            }
        }
        return 0;
    }
    
    default String mapOrganizationName(Source source){
        return base64BEEncoder(source.getOrganizationName());
    }
    default String mapCity(Source source){
        return base64BEEncoder(source.getCity());
    }
    private String base64BEEncoder(String name){
        byte[] utf16BEBytes = name.getBytes(StandardCharsets.UTF_16BE);
        return Base64.getEncoder().encodeToString(utf16BEBytes);
    }

    @Mapping(target = "platform", constant = "sidb2")
    @Mapping(target = "type", source = "organizationType")
    @Mapping(target = "hon", source = "hon")
    @Mapping(target = "name", expression = "java(mapOrganizationName(source))")
    @Mapping(target = "aliases", expression = "java(mapOrganizationAlias(source.getOrganizationAlias()))")
    @Mapping(target = "department", expression = "java(getPayloadFieldForStrings(source, \"departmentName\"))")
    @Mapping(target = "website", expression = "java(getPayloadFieldForStrings(source, \"website\"))")
    @Mapping(target = "country", source = "country")
    @Mapping(target = "region", source = "state")
    @Mapping(target = "city", expression = "java(mapCity(source))")
    @Mapping(target = "postalCode", source = "postalCode")
    @Mapping(target = "address", expression = "java(getAddress(source))")
    @Mapping(target = "comment", expression = "java(getPayloadFieldForStrings(source, \"notes\"))")
    @Mapping(target = "status", expression = "java(String.valueOf(source.getStatus()))")
    @Mapping(target = "verificationValidationProcess", expression = "java(getAdditionalInfo(source, \"verificationValidationProcess\"))")
    //@Mapping(target = "relationshipType", expression = "java(getRelationShip(source,\"relationship\"))")
    //@Mapping(target = "parentCompany", expression = "java(mapCompany(source))")
    //@Mapping(target = "parentCountry", source = "country")
    //@Mapping(target = "parentInstitution", expression = "java(mapInstitute(source))")
    //@Mapping(target = "parentID", expression = "java(getRelationShip(source,\"HON\"))")
    @Mapping(target = "releaseType", expression = "java(getAdditionalInfo(source, \"releaseType\"))")
    @Mapping(target = "language", expression = "java(getAdditionalInfo(source, \"sourceLanguage\"))")
    @Mapping(target = "lastModifierName", source = "lastModifiedBy")
    @Mapping(target = "lastApproverName", source = "approvedBy")
    @Mapping(target = "lastModified", source = "lastModifiedDate")
    @Mapping(target = "lastApproved", source = "lastApprovedDate")
    @Mapping(target = "created", source = "createdDate")
    @Mapping(target = "isUnaccredited", expression = "java(getPayloadFieldForBoolean(source, \"unAccreditedSource\"))")
    @Mapping(target = "lastUsed", expression = "java(getPayloadFieldForStrings(source, \"lastUsedDateTime\"))")
    @Mapping(target = "contactPersonName", expression = "java(getAdditionalInfo(source, \"contactPersonName\"))")
    @Mapping(target = "contactPersonTitle", expression = "java(getAdditionalInfo(source, \"contactPersonTitle\"))")
    @Mapping(target = "contactTimeFrom", expression = "java(getAdditionalInfo(source, \"contactTimeFrom\"))")
    @Mapping(target = "contactTimeTo", expression = "java(getAdditionalInfo(source, \"contactTimeTo\"))")
    @Mapping(target = "contactTimeZone", expression = "java(getAdditionalInfo(source, \"contactTimeZone\"))")
    @Mapping(target = "doNotContact", expression = "java(getDoNotContact(source))")
    @Mapping(target = "contactAutomatedServices", expression = "java(mapContactDetailsForAS(source))")
    @Mapping(target = "contactPhones", expression = "java(mapContactDetails(source, \"contactPhones\"))")
    @Mapping(target = "contactFaxes", expression = "java(mapContactDetails(source, \"contactFaxes\"))")
    @Mapping(target = "contactEmails", expression = "java(mapContactDetails(source, \"contactEmails\"))")
    @Mapping(target = "contactWebsites", expression = "java(mapContactDetails(source, \"contactWebsites\"))")
    @Mapping(target = "contactMails", expression = "java(mapContactDetails(source, \"contactMails\"))")
    AutoMatchSourceDTO toAutoMatchDTO(Source source);

}
