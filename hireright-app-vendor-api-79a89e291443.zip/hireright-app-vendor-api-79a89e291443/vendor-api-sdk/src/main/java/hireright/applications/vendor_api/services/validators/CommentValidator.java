package hireright.applications.vendor_api.services.validators;
/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	2017-09-11	Created
 *	M.Kuznetsov	2025-10-29	HRG-345322. Openjdk21-migration
 */

import hireright.components.domain.dialects.vendor_api.Comment;

public class CommentValidator {
    public static boolean isValid(Comment comment) {
        return true;
    }
}
