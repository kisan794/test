package com.hireright.sourceintelligence.service.notification;

import com.hireright.sourceintelligence.api.dto.notification.NotificationRequestDTO;
import com.hireright.sourceintelligence.api.dto.notification.NotificationResponseDTO;

/**
 * Base interface for all notification services.
 * Follows Interface Segregation Principle - defines minimal contract.
 * Implements Strategy Pattern - different implementations for different notification types.
 */
public interface NotificationService {
    
    /**
     * Sends a notification based on the request
     *
     * @param request the notification request
     * @return response with notification status
     */
    NotificationResponseDTO sendNotification(NotificationRequestDTO request);
    
    /**
     * Checks if this service supports the given notification request
     *
     * @param request the notification request
     * @return true if this service can handle the request
     */
    boolean supports(NotificationRequestDTO request);
}

