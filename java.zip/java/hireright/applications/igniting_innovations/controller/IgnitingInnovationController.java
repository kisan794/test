package hireright.applications.igniting_innovations.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static hireright.applications.igniting_innovations.util.Constant.*;

@RestController
@RequestMapping(IGNITINGINNOVATION_SERVICE)
public class IgnitingInnovationController {

    /**
     * health check API
     *
     * @return String
     */
    @GetMapping(HEALTH)
    public String test() {
        return HEALTH_CHECK;
    }
}
