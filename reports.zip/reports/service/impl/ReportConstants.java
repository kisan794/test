package com.hireright.sourceintelligence.reports.service.impl;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ReportConstants {

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class AggregateFields {
        public static final String ID = "_id";
        public static final String STATUS = "status";
        public static final String ORGANIZATION_NAME = "organizationName";
        public static final String USED_COUNT = "usedCount";
        public static final String CREATED_DATE = "createdDate";
        public static final String VERIFICATION_VALIDATION_DATE = "verificationValidationDate";
        public static final String ADDRESS = "address";
        public static final String APPROVAL_STATUS = "approvalStatus";
        public static final String APPROVED_BY = "approvedBy";
        public static final String ORGANIZATION_TYPE = "organizationType";
        public static final String ORIGIN = "origin";
        public static final String HON = "hon";
        public static final String CREATED_BY = "createdBy";
        public static final String OPERATOR_ROLE = "operatorRole";
        public static final String AUTO_MATCH = "autoMatch";
        public static final String REASON = "reason";
        public static final String COUNT = "count";
        public static final String DATA = "data";
        public static final String TOTAL_COUNT = "$total.count";

        //Source information
        public static final String ACTION_USED_COUNT = "UsedCount";
        public static final String ADDED = "added";
        public static final String CHANGED = "changed";
        public static final String CANCELLED = "cancelled";
        public static final String ARCHIVED = "archived";
        public static final String PROGRESS = "inProgress";
        public static final String ON_HOLD = "onHold";
        public static final String COMPLETED = "completed";
        public static final String ACTION = "action";

        public static final String CREATE = "Create";
        public static final String UPDATE = "Update";
        public static final String IN_PROGRESS = "In Progress";
        public static final String DELETE = "Delete";
        public static final String ARCHIVED_ACTION = "Archived";

        // Status count fields for Operator role
        public static final String NEW_COUNT = "newCount";
        public static final String DELETED = "deleted";


        public static final String RESPONSE_REPORT_LIST= "responseReportList";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class ReportTypes {
        public static final String CONTACT_UTILIZATION = "contact-utilization";
        public static final String AUTO_MATCH = "auto-match";
        public static final String SOURCE_INFORMATION = "source-information";
        public static final String SOURCE_INFORMATION_REVIEWER = "source-information-reviewer";
        public static final String SOURCE_INFORMATION_OPERATOR_REVIEWER = "source-information-operator-reviewer";
        public static final String APPROVAL_TAT = "approval-tat";
        public static final String DELETE_SOURCE_REPORT = "source-deletion";
    }
    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    protected static class MetaData {
        protected static final String LAST_USED = "Last_Used";
        protected static final String USED_DATE = "Used_Date";
        protected static final String SOURCE_NAME = "Source_Name";
        protected static final String ORG_NAME = "Organization_Name";
        protected static final String DELETED_BY = "Deleted_By";
        protected static final String DELETED_DATE = "Deleted_Date";
        protected static final String APPROVED_BY = "Approved_By";
        protected static final String ADDRESS = "Address";
        protected static final String ORG_TYPE = "Organization_Type";
        protected static final String USED_COUNT = "Used_Count";

        protected static final String[] DELETE_META_DATA = new String[]{"Hon",SOURCE_NAME,ADDRESS,ORG_TYPE,DELETED_BY,"Reason",DELETED_DATE};
        protected static final String[] CONTACT_UTILIZATION_META_DATA = new String[]{"Hon",ORG_NAME,LAST_USED,ADDRESS,"Verification_Validation_Date",ORG_TYPE,"Origin","Approval_Status",APPROVED_BY,USED_COUNT};
        protected static final String[] AUTO_MATCH_META_DATA = new String[]{"Hon",ORG_NAME,ADDRESS,ORG_TYPE,USED_COUNT,"Is_Auto_Match"};
        protected static final String[] SOURCE_INFORMATION_META_DATA = new String[]{"Hon","Researcher_Name","Added","Changed","Archived","In_Progress","On_Hold","Cancelled","Completed"};
        protected static final String[] SOURCE_INFORMATION_REVIEWER_META_DATA = new String[]{"Researcher Name", "In Progress", "On Hold", "Cancelled", "Completed", "Total"};
        protected static final String[] SOURCE_INFORMATION_OPERATOR_REVIEWER_META_DATA = new String[]{ "Researcher Name", "Hon", "Added", "Changed", "Archived", "Deleted", "New", "In Progress", "On Hold", "Cancelled", "Completed", "Total"};
        protected static final String[] APPROVAL_TAT_META_DATA = new String[]{"Hon","Approver_Name","Status","Actual_Time","Total_Time","%_of_Actual_from_Total"};
        protected static final String[] DEFAULT_META_DATA = new String[]{};

    }
    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class Regex {
        public static final String CAMEL_CASE_REGEX = "([a-z])([A-Z])";
        public static final String SNAKE_CASE_REGEX = "$1_$2";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class MongoRegex {
        public static final String IN = "$in";
        public static final String EXPR = "$expr";
        public static final String DOLLAR = "$";
        public static final String SPLIT = "$split";
        public static final String ARRAY_ELEM_AT = "$arrayElemAt";
    }

    @NoArgsConstructor(access = AccessLevel.PUBLIC)
    public static class SortFields {
        public static final String ORGANIZATION_NAME = "Organization_Name";
        public static final String ORGANIZATION_TYPE = "Organization_Type";
        public static final String ADDRESS = "Address";
        public static final String APPROVED_BY = "Approved_By";
        public static final String CREATED_BY = "Created_By";
        public static final String REASON = "Reason";
        public static final String USED_DATE = "Used_Date";
        public static final String HON = "HON";
        public static final String VERIFICATION_DATE = "Verification_Validation_Date";
        public static final String AUTO_MATCH = "Auto_Match";
        public static final String IS_AUTO_MATCH = "Is_Auto_Match";
        public static final String APPROVAL_STATUS = "Approval_Status";
    }
}
