package com.hireright.sourceintelligence.api.v1;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.v2.dto.PermissionsDTO;
import com.hireright.sourceintelligence.config.RequestInProgressCache;
import com.hireright.sourceintelligence.service.ExternalService;
import com.hireright.sourceintelligence.service.PermissionsService;
import com.hireright.sourceintelligence.util.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.multipart.MultipartFile;

import java.time.Duration;

import jakarta.validation.constraints.NotNull;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.hireright.sourceintelligence.api.ApiConstants.SearchParams.*;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.USER_NAME;
import static com.hireright.sourceintelligence.constants.ErrorConstants.*;
import static com.hireright.sourceintelligence.constants.ErrorConstants.FAILED_TO_DOWNLOAD_DOCUMENT;
import static com.hireright.sourceintelligence.util.LoggingThrowable.*;

@RestController
@EnableRetry
@RequiredArgsConstructor
@Validated
@Slf4j
public class ExternalApiController implements ExternalApi {

    private final ExternalService externalService;
    private final PermissionsService permissionsService;
    private final HttpServletRequest request;
    private static final int LIMIT = 1000;

    @Value("${hrg1.api.url}")
    private String hrg1ApiUrl;

    @Value("${hrg1.permission.url}")
    private String hrg1PermissionApiUrl;

    @Value("${hrg1.approvers.url}")
    private String hrg1ApproversApiUrl;

    @Value("${hrg1.permission.url.US}")
    private String hrg1PermissionUSApiUrl;

    @Value("${hrg1.approvers.url.US}")
    private String hrg1ApproversUSApiUrl;

    @Value("${react.ui.url}")
    private String reactUiUrl;

    @Value("${hrg1.permissions.scope}")
    private boolean permissionsFromOptool;

    @Value("${hrg1.operators.url}")
    private String hrg1OperatorsApiUrl;

    @Value("${hrg1.operators.url.US}")
    private String hrg1OperatorsUSApiUrl;

    private final Map<String, String> jwtCache = new ConcurrentHashMap<>();

    private final Cache<String, CachedRedirect> redirectCache =
            Caffeine.newBuilder()
                    .expireAfterWrite(2, TimeUnit.MINUTES)
                    .build();

    @Override
    public ResponseEntity<String> getExternalApiResponse(String key, String entry, String apiHost) {
        log.info("Inside getExternalApiResponse method");

        UserKeyDTO userKeyDTO = new UserKeyDTO(key, apiHost);
        String gwtToken = JwtUtil.generateToken(userKeyDTO);
        CachedRedirect cached = redirectCache.getIfPresent(key);
        if (cached != null) {
            log.info("Using cached redirect for key: {}", key);
            return ResponseEntity.status(HttpStatus.FOUND)
                    .location(URI.create(cached.url()))
                    .build();
        }

        String finalRedirectUrl = reactUiUrl.split("\\?token=")[0] + TOKEN + gwtToken;
        log.info("Redirecting to {}", finalRedirectUrl);

        redirectCache.put(key, new CachedRedirect(finalRedirectUrl, System.currentTimeMillis()));
        log.info("Redirecting after caching");
        return ResponseEntity.status(HttpStatus.FOUND)
                .location(URI.create(finalRedirectUrl))
                .build();
    }

    @Override
    public ResponseEntity<UserLoginDetailsDTO> getCachedToken(String key, String apiHost) {
        log.info("Cached token key  : {} and api host : {} in getCachedToken method", key, apiHost);
        StringBuilder hrg1Url = new StringBuilder();
        hrg1Url.append(HTTP).append(apiHost).append(hrg1ApiUrl).append(key);
        log.info("HRG1 API url {} ", hrg1Url);
        ExternalResponse externalResponse = externalService.getExternalApiResponse(hrg1Url.toString());
        UserLoginDetailsDTO userLoginDetailsDTO = prepareResponse(externalResponse, apiHost);
        log.info("Before navigating to UI");
        return ResponseEntity.ok(userLoginDetailsDTO);
    }

    @Override
    public ResponseEntity<UserLoginDetailsDTO> getHRGPermissions(String subject, String userName) {
        UserLoginDetailsDTO loginDetailsDTO = new UserLoginDetailsDTO();
        UserDataDTO userDataDTO = new UserDataDTO();
        loginDetailsDTO.setKind("userDetails");
        userDataDTO.setUserEmail(subject);
        userDataDTO.setUserName(userName);
        String name = subject.split("@")[0];
        getPermission(name, userDataDTO, null);
        userDataDTO.setUserName(userName);
        userDataDTO.setUserEmail(subject);
        loginDetailsDTO.setData(List.of(userDataDTO));
        return ResponseEntity.ok(loginDetailsDTO);

    }

    @Override
    public ResponseEntity<String> uploadAttachment(@RequestParam MultipartFile file,
                                                   @RequestParam String documentMeta) {
        try {
            String response = externalService.retryUploadService(file, documentMeta);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            logAndThrowInvalidRequest(FAILED_TO_UPLOAD_DOCUMENT, e);
        }
        return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Override
    public ResponseEntity<InputStreamResource> getAttachment(@RequestParam @NotNull String documentId) {
        try {
            return externalService.getAttachmentByUrl(documentId);
        } catch (Exception e) {
            logAndThrowInvalidRequest(FAILED_TO_DOWNLOAD_DOCUMENT, e, e.getMessage());
        }
        return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Override
    public ResponseEntity<String> deleteAttachment(@RequestParam String documentId) {
        try {
            String result = externalService.deleteAttachment(documentId);
            return new ResponseEntity<>(result, HttpStatus.OK);
        } catch (Exception e) {
            if (e instanceof InterruptedException) {
                Thread.currentThread().interrupt();
            }
            logAndThrowInvalidRequest(FAILED_TO_DOWNLOAD_DOCUMENT, e, e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<ResponseObject> getOperatorsList(String apiHost) {
        log.info(" api host : {}", apiHost);
        List<ApproverDTO> operatorsList = fetchOperatorsListFromAPI(apiHost);
        ResponseObject response = new ResponseObject();
        response.setResponse(operatorsList);
        response.setStatusCode(HttpStatus.OK.value());
        response.setStatus("SUCCESS");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    private UserLoginDetailsDTO prepareResponse(ExternalResponse authenticationRequest, String apiHost) {
        UserLoginDetailsDTO loginDetailsDTO = new UserLoginDetailsDTO();

        List<Parameter> parameters = authenticationRequest.getParametersList().getParameter();

        // Initialize DTOs
        UserDataDTO userDataDTO = new UserDataDTO();
        SearchRequestDTO searchRequest = new SearchRequestDTO();

        boolean containsFromSubRequest = parameters.stream()
                .anyMatch(param -> FROM_SUB_REQUEST.equals(param.getName()));

        boolean containsFromViewEdit = parameters.stream()
                .anyMatch(param -> FROM_VIEW_EDIT.equals(param.getName()));

        boolean honFromViewEdit = parameters.stream()
                .anyMatch(param -> HON_FROM_VIEW_EDIT.equals(param.getName()));

        if(containsFromViewEdit && !honFromViewEdit){
            logAndThrowInvalidRequest(FAILED_TO_GET_HON, null, (Object) null);
        }

        loginDetailsDTO.setKind(containsFromSubRequest ? SUB_REQUEST : USER_DETAILS);

        // Populate SearchRequestDTO if "fromSubRequest" is present
        if (containsFromSubRequest && !containsFromViewEdit) {
            parameters.forEach(param -> {
                switch (param.getName()) {
                    case ORGANIZATION_TYPE_OPTOOL -> searchRequest.setOrganizationType(param.getValue());
                    case ORGANIZATION_NAME_OPTOOL -> searchRequest.setOrganizationName(param.getValue());
                    case COUNTRY_OPTOOL -> searchRequest.setCountry(param.getValue());
                    case STATE_OPTOOL -> searchRequest.setState(param.getValue());
                    case CITY_OPTOOL -> searchRequest.setCity(param.getValue());
                    default ->
                        log.debug("Unrecognized parameter in subRequest block: {}", param.getName());

                }
            });
            userDataDTO.setSearchRequest(searchRequest);
        }

        // Populate UserDataDTO
        parameters.forEach(param -> {
            switch (param.getName()) {
                case OPTOOL_WEBSERVER_PORT ->
                        userDataDTO.setOptoolWebserverPort(Integer.parseInt(param.getValue().trim()));
                case USER_NAME -> userDataDTO.setUserName(param.getValue());
                case USER_EMAIL -> userDataDTO.setUserEmail(param.getValue());
                case TRUST_SCORE -> userDataDTO.setTrustScore(param.getValue());
                case HON_FROM_VIEW_EDIT -> userDataDTO.setHon(param.getValue());
                case OPTOOL_INSTANCE_NAME -> userDataDTO.setOptoolInstanceName(param.getValue());
                case FROM_VIEW_EDIT -> userDataDTO.setFromViewEdit(param.getValue());
                case ORG_TYPE -> userDataDTO.setOrganizationType(param.getValue());
                default -> log.debug("Unrecognized parameter in userDataDTO block: {}", param.getName());
            }
        });

        String userName = userDataDTO.getUserEmail().split("@")[0];

        loginDetailsDTO.setData(List.of(getPermission(userName, userDataDTO, apiHost)));
        return loginDetailsDTO;
    }

    private UserDataDTO getPermission(String userName, UserDataDTO userDataDTO, String apiHost) {
        if(!permissionsFromOptool){
            PermissionsDTO permissionsDTO = permissionsService.getPermissionByNameAndStatus(userDataDTO.getUserName(), "active");
            if (permissionsDTO != null) {
                if(permissionsDTO.getPermissions().isEmpty()){
                    logAndThrowPermissionsDenied(ACCESS_DENIED_ERROR,null,userName);
                }
                userDataDTO.setScope(permissionsDTO.getScope());
                userDataDTO.setUserName(permissionsDTO.getUserName());
                userDataDTO.setUserEmail(permissionsDTO.getUserEmail());
                userDataDTO.setTrustScore(permissionsDTO.getTrustScore());
                userDataDTO.setPermissions(permissionsDTO.getPermissions());
                userDataDTO.setApprovalGroupList(getStaticApproverGroupList());
            }
            return userDataDTO;
        } else {
            StringBuilder hrgPermissionUrl = new StringBuilder();
            if(apiHost != null && !StringUtils.isEmpty(apiHost)){
                hrgPermissionUrl.append(HTTP).append(apiHost).append(hrg1PermissionApiUrl).append(userName).append(SCOPE);
            } else {
                hrgPermissionUrl.append(hrg1PermissionUSApiUrl).append(userName).append(SCOPE);
            }

            log.info("Permission API url {} ", hrgPermissionUrl);

            JsonNode permissionsJson =  externalService.getHRGPermissions(hrgPermissionUrl.toString());
            log.info("Permission Response {} ", permissionsJson);
            return populateUserPermissionsAndApprovalList(permissionsJson, userDataDTO, apiHost);
        }
    }

    private List<ApproverDTO> getStaticApproverGroupList() {
        List<ApproverDTO> approverList = new ArrayList<>();

        approverList.add(ApproverDTO.builder()
                .approverName("Rajiv Hazareesing")
                .approverEmail("rhazareesing@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Jennifer Rizkallah")
                .approverEmail("jennifer.rizkallah@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Dev Narayanappa")
                .approverEmail("devaraj.narayanappa@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Lakshmi Narayan")
                .approverEmail("lnarayan@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Suchithra Reddy")
                .approverEmail("suchithra.reddy@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Meena Rajappa")
                .approverEmail("meena.rajappa@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Tomasz Krzyszkowski")
                .approverEmail("tkrzyszkowski@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Anupam Jha")
                .approverEmail("anupam.jha@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Aditya Jain")
                .approverEmail("aditya.jain@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Wilson Vanganuru")
                .approverEmail("wilson.vanganuru@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Katila Ao")
                .approverEmail("katila.ao@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Sunil Shah")
                .approverEmail("sunil.shah@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Wojciech Zuk")
                .approverEmail("wojciech.zuk@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Abul Zubair")
                .approverEmail("azubair@hireright.com")
                .build());

        approverList.add(ApproverDTO.builder()
                .approverName("Rohini Narayan")
                .approverEmail("rohini.narayan@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Eddie Kim")
                .approverEmail("ekim@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Kubra Zaiba")
                .approverEmail("kubra.zaiba@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Kamil Weglewski")
                .approverEmail("kamil.weglewski@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Kristen N. Sitlhou")
                .approverEmail("kristen.sitlhou@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Udayashankar G")
                .approverEmail("udayashankar.g@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Rebecca Alvarez")
                .approverEmail("ralvarez@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Anny Tamang")
                .approverEmail("anny.tamang@hireright.com")
                .build());
        approverList.add(ApproverDTO.builder()
                .approverName("Kuovi Kin")
                .approverEmail("kuovi.kin@hireright.com")
                .build());

        return approverList;
    }


    private UserDataDTO populateUserPermissionsAndApprovalList(JsonNode rootNode, UserDataDTO userDataDTO, String apiHost) {

        Optional<JsonNode> dataNodeOpt = Optional.ofNullable(rootNode.path("data"))
                .filter(JsonNode::isArray)
                .filter(dataArray -> !dataArray.isEmpty())
                .map(dataArray -> dataArray.get(0));

        List<String> permissions = dataNodeOpt
                .map(node -> node.path("permissions"))
                .filter(JsonNode::isArray)
                .map(permissionsNode -> {
                    List<String> perms = new ArrayList<>();
                    permissionsNode.forEach(permission -> {
                        String text = permission.asText();
                        // Skip the prefix if it exists
                        String trimmed = text.startsWith("optool.webtool.si2.")
                                ? text.substring("optool.webtool.si2.".length())
                                : text;
                        perms.add(trimmed);
                    });
                    return perms;
                })
                .orElse(Collections.emptyList());

        dataNodeOpt.map(node -> node.isArray() && !node.isEmpty() ? node.get(0).path("sourceVerificationTrustLevel") : node.path("sourceVerificationTrustLevel"))
                .filter(JsonNode::isNumber)  // Ensure it's a number
                .ifPresent(trustLevel -> userDataDTO.setTrustScore(trustLevel.asText())); // Convert number to string

        if (permissions.isEmpty()) {
            logAndThrowPermissionsDenied(ACCESS_DENIED_ERROR, null, userDataDTO.getUserName());
            return userDataDTO;
        }

        userDataDTO.setPermissions(permissions);

        // Check if "optool.webtool.si2.approvalManager" exists in permissions
            if (permissions.stream().anyMatch(perm -> perm.contains(APPROVER_PERMISSION))) {
                // Call an external service to fetch approval group list
                String userName = userDataDTO.getUserEmail().split("@")[0];
                List<ApproverDTO> approvalGroupList = fetchApprovalGroupListFromAPI(userName, apiHost);
                userDataDTO.setApprovalGroupList(approvalGroupList);
           }

        /*if (permissions.stream().anyMatch(perm -> perm.contains(APPROVER_PERMISSION))) {
            List<ApproverDTO> approvalGroupList;

            if (permissionsFromOptool) {
                approvalGroupList = getStaticApproverGroupList();
            } else {
                String userName = userDataDTO.getUserEmail().split("@")[0];
                approvalGroupList = fetchApprovalGroupListFromAPI(userName, apiHost);
            }

            userDataDTO.setApprovalGroupList(approvalGroupList);
        }*/
        return userDataDTO;
    }

    private List<ApproverDTO> fetchApprovalGroupListFromAPI(String userName, String apiHost) {
        String baseUrl = buildBaseUrl(apiHost);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseUrl);

        List<ApproverDTO> approverList = new ArrayList<>();
        int offset = 0;

        while (true) {
            JsonNode rootNode = fetchPage(builder, offset);
            JsonNode dataArray = rootNode.path("data");
            JsonNode metaNode = rootNode.path("meta");

            if (isEmptyPage(dataArray, offset)) break;

            approverList.addAll(mapOperators(dataArray));

            if (isLastPage(metaNode)) break;

            offset += LIMIT;
        }

        return approverList;
    }

    private String buildBaseUrl(String apiHost) {
        if (StringUtils.hasText(apiHost)) {
            return HTTP + apiHost + hrg1ApproversApiUrl;
        }
        return hrg1ApproversUSApiUrl;
    }

    private JsonNode fetchPage(UriComponentsBuilder builder, int offset) {
        String pagedUrl = builder
                .replaceQueryParam("offset", offset)
                .replaceQueryParam("limit", LIMIT)
                .toUriString();

        log.info("Approvers List API page url: {}", pagedUrl);

        JsonNode rootNode = externalService.getApproversList(pagedUrl);

        return rootNode;
    }

    private boolean isEmptyPage(JsonNode dataArray, int offset) {
        boolean empty = !dataArray.isArray() || dataArray.isEmpty();
        if (empty) {
            log.info("No data returned from API at offset {}. Stopping.", offset);
        }
        return empty;
    }

    private List<ApproverDTO> mapOperators(JsonNode dataArray) {
        List<ApproverDTO> list = new ArrayList<>();
        for (JsonNode userNode : dataArray) {
            String username = userNode.path("username").asText();
            String email = userNode.path("email").asText();
            String formattedName = userNode.path("formattedName").asText();

            if (StringUtils.hasText(username) && StringUtils.hasText(email) && StringUtils.hasText(formattedName)) {
                list.add(ApproverDTO.builder()
                        .approverName(formattedName)
                        .userName(username)
                        .approverEmail(email)
                        .build());
            }
        }
        return list;
    }

    private boolean isLastPage(JsonNode metaNode) {
        int count = metaNode.path("count").asInt(0);
        int total = metaNode.path("total").asInt(0);
        int offset = metaNode.path("offset").asInt(0);

        if (count < LIMIT) {
            log.info("Fetched final batch of {} records (less than limit). Stopping.", count);
            return true;
        }
        if (total > 0 && (offset + count) >= total) {
            log.info("Reached total count ({}). Stopping.", total);
            return true;
        }
        return false;
    }

    private String capitalizeUsername(String username) {
        if (username == null || username.isBlank()) {
            return "";
        }
        username = username.trim();
        return username.substring(0, 1).toUpperCase() + username.substring(1);
    }



    private record CachedRedirect(String url, long timestamp) {}

    private List<ApproverDTO> fetchOperatorsListFromAPI(String apiHost) {
        String baseUrl;
        if (StringUtils.hasText(apiHost)) {
            baseUrl = HTTP + apiHost + hrg1OperatorsApiUrl;
        }else{
            baseUrl = hrg1OperatorsUSApiUrl;
        }

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(baseUrl);
        List<ApproverDTO> operatorsList = new ArrayList<>();
        int offset = 0;
        try {
            while (true) {
                String pagedUrl = uriBuilder.replaceQueryParam("offset", offset).toUriString();
                JsonNode rootNode = externalService.getApproversList(pagedUrl);
                JsonNode dataArray = rootNode.path("data");
                JsonNode metaNode = rootNode.path("meta");
                if (isEmptyPage(dataArray, offset)) break;
                operatorsList.addAll(mapOperators(dataArray));
                if (isLastPage(metaNode)) break;
                offset += LIMIT;
            }
        }catch (Exception e){
            return operatorsList;
        }
        return operatorsList;
    }

//    private List<OperatorDTO> mapOperators(JsonNode dataArray) {
//        List<OperatorDTO> list = new ArrayList<>();
//        for (JsonNode userNode : dataArray) {
//            String username = userNode.path("username").asText();
//            String email = userNode.path("email").asText();
//            String formattedName = userNode.path("formattedName").asText();
//
//            if (StringUtils.hasText(username) && StringUtils.hasText(email) && StringUtils.hasText(formattedName)) {
//                list.add(OperatorDTO.builder()
//                        .userName(username)
//                        .formattedName(formattedName)
//                        .email(email)
//                        .build());
//            }
//        }
//        return list;
//    }
}