package com.hireright.sourceintelligence.api;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ApiDescriptions {

  public static final String PHRASE_SEARCH_DESCRIPTION = """
       The phrase search API will search for Source Organizations
      within the SI Mongo database that contain the phrase within the name of the Source Organization.
      By default only ACTIVE Source Organizations are returned unless specified by status parameter.
                
      Definition of a phrase: A search term containing atleast two or more words, separated by a space character, in ordered sequence.
        
      Valid Phrases: "This is a phrase", "University of", "School of Dentistry", "XYZ Company Limited"
         
      InValid Phrases: "School", "University", "Company", "Limited"
       
              Example :
       
              Search Phrase: "University of California"
              
               Matched Organizations:
                     University of California Hastings College of Law
                      University of California, Berkeley
                      Dominican University of California - Buck Institute
                      Dominican University of California - BioMarin Pharma College
         
               Not Matched Organizations:
                      University of Southern California
                      California University of Music
         """;

  public static final String AUTOCOMPLETE_SEARCH_DESCRIPTION = """
            Provides autocompleted texts within each categories  like
            organizations, alias.
            Search is performed on organization name and alias using search key.
            Search by organization type and status area all "and" operation.
            Results are returned based on highest mongo atlas search score.
        """;

  public static final String AUTOCOMPLETE_DETAILED_SEARCH_DESCRIPTION = """
            Provides autocompleted source objects having details of city , country ,
            hon , state , used count , organization name , alias ,address etc.
            Search is performed on organization name and alias using search key.
            Search by country, organization type and status are all "and" operation.
            Results are returned based on highest mongo atlas search score for educators where as 
            for employers , the result are sorted by used count/ validation count in decreasing order.
        """;

  public static final String AUTOCOMPLETE_SUGGESTION_ON_SOURCE_CREATION_DESCRIPTION = """
            Provides autocompleted source objects having organization name , alias ,address,
            department name , department aliases so as to avoid duplicate source creation.
            Search is performed on organization name.
            Results are returned based on highest mongo atlas search score.
        """;

  public static final String SEARCH_BY_FILTER_DESCRIPTION = """
        Provides source list based on filters like organization name and organization alias.
        API will search for Source Organizations within the SI Mongo database that contain the phrase
        within the name of the Source Organization and alias when applied.
        At least one filter is required to search for source organizations
        By default only ACTIVE Source Organizations are returned unless specified in status parameter.
        The complete list of organizations can be sorted in ascending or descending order on sort properties like
        organizationName, primaryContact, validated, location, lastActive.
        """;

  public static final String LAST_VERIFIED_DATA_UPDATE_DESCRIPTION = """
      Increments used count by 1 and updates the source with date in MM/dd/yyyy format when a source is last verified.
      Used count is number of times a source is used for verification.
      """;

  public static final String SEARCH_HISTORY_BY_FILTER_DESCRIPTION = """
        Provides source list based on filters like organization name and hon.
        API will search for Source Organizations within the SI Mongo database that contain the phrase
        within the name of the Source Organization and hon when applied.
        At least one filter is required to search for source organizations.
        The list of source can be narrowed down by applying more filters like verification type which can
        EMPLOYMENT or EDUCATION , assigned to , location (countries or states) , approval statuses like NEW , REJECTED,
        APPROVED, ON_HOLD or IN_PROGRESS
        """;

  public static final String SEARCH_CHANGE_LOG_DATA_BY_FILTER_DESCRIPTION = """
        Provides source list based on filters like organization name and hon.
        API will search for Source Organizations within the SI Mongo database that contain the phrase
        within the name of the Source Organization and hon when applied.
        At least one filter is required to search for source organizations.
        The list of source is obtained by applying date range comprising start date and end date and activity type
        such as New record , Details changed or Archived.
        """;

  public static final String SOURCE_MATCHING_SEARCH_DESCRIPTION = """
        Provides source with details like city , country, hon , state , used count ,
        organization name , alias ,address etc.
        when search is performed on organization name and alias using search keyword
        and on country, organization type , status,  state ,city by their respective values.
        When all the values for the fields mentioned above are provided,they are all used in Atlas
        text search query with different analysers.
        Source organization names and aliases in the result obtained by text search are further
        applied with Jaro Winkler distance algorithm and only those result are processed further 
        whose Jaro Winkler distance values is equal or greater than the confidence threshold.
        For employers , the results are first sorted by used count/ validation count in decreasing 
        order and then by Jaro Winkler distance.
        For educators , the results are first sorted by Jaro Winkler distance in decreasing order.
        Finally , the results are further sorted by country, state and city in ascending order.
        Sources whose organization name and alias gets same Jaro Winkler distance value , then the source with matching 
        organization name is give precedence over source with matching alias.
      """;
}
