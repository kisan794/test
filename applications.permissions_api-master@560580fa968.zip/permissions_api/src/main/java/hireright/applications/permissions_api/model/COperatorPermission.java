package hireright.applications.permissions_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-17  HRG-330191 initial version
 */

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Objects;

public class COperatorPermission
{
	@JsonProperty("scope")
	private String m_sScope;

	@JsonProperty("subject")
	private String m_sSubject;

	@JsonProperty("trustLevel")
	private Integer m_nTrustLevel;

	@JsonProperty("sourceVerificationTrustLevel")
	private Integer m_nSourceVerificationTrustLevel;

	@JsonProperty("permissions")
	private Collection<String> m_permissions = new LinkedHashSet<>();

	private COperatorPermission()
	{
	}

	private COperatorPermission(Builder builder)
	{
		m_sScope = builder.m_sScope;
		m_sSubject = builder.m_sSubject;
		m_nTrustLevel = builder.m_nTrustLevel;
		m_nSourceVerificationTrustLevel = builder.m_nSourceVerificationTrustLevel;
		m_permissions.addAll(builder.m_permissions);
	}

	public String getScope()
	{
		return m_sScope;
	}

	public String getSubject()
	{
		return m_sSubject;
	}

	public Integer getTrustLevel()
	{
		return m_nTrustLevel;
	}

	public Integer getSourceVerificationTrustLevel()
	{
		return m_nSourceVerificationTrustLevel;
	}

	public Collection<String> getPermissions()
	{
		return m_permissions != null ?
			Collections.unmodifiableCollection(m_permissions) :
			Collections.emptySet();
	}

	@Override
	public String toString()
	{
		return "COperatorPermission{" + "m_sScope='" + m_sScope + '\'' + ", m_sSubject='"
			+ m_sSubject + '\'' + ", m_nTrustLevel=" + m_nTrustLevel
			+ ", m_nSourceVerificationTrustLevel=" + m_nSourceVerificationTrustLevel
			+ ", m_permissions=" + m_permissions + '}';
	}

	@Override
	public boolean equals(Object o)
	{
		if(this == o)
		{
			return true;
		}
		if(o == null || getClass() != o.getClass())
		{
			return false;
		}

		COperatorPermission that = (COperatorPermission) o;

		if(!Objects.equals(m_sScope, that.m_sScope))
		{
			return false;
		}
		if(!Objects.equals(m_sSubject, that.m_sSubject))
		{
			return false;
		}
		if(!Objects.equals(m_nTrustLevel, that.m_nTrustLevel))
		{
			return false;
		}
		if(!Objects.equals(m_nSourceVerificationTrustLevel, that.m_nSourceVerificationTrustLevel))
		{
			return false;
		}
		return Objects.equals(m_permissions, that.m_permissions);
	}

	@Override
	public int hashCode()
	{
		int result = m_sScope != null ? m_sScope.hashCode() : 0;
		result = 31 * result + (m_sSubject != null ? m_sSubject.hashCode() : 0);
		result = 31 * result + (m_nTrustLevel != null ? m_nTrustLevel.hashCode() : 0);
		result = 31 * result + (m_nSourceVerificationTrustLevel != null ?
			m_nSourceVerificationTrustLevel.hashCode() :
			0);
		result = 31 * result + (m_permissions != null ? m_permissions.hashCode() : 0);
		return result;
	}

	public enum EField
	{
		LABEL("LABEL");

		private final String m_sValue;

		EField(String sValue)
		{
			m_sValue = sValue;
		}

		public static EField fromValue(String text)
		{
			if(text == null || text.trim().isEmpty())
			{
				return null;
			}

			for(EField entry : EField.values())
			{
				if(entry.m_sValue.equalsIgnoreCase(text))
				{
					return entry;
				}
			}

			return null;
		}
	}

	public static final class Builder
	{
		private String m_sScope;
		private String m_sSubject;
		private Integer m_nTrustLevel;
		private Integer m_nSourceVerificationTrustLevel;
		private final Collection<String> m_permissions = new LinkedHashSet<>();

		public Builder()
		{
		}

		public Builder(COperatorPermission copy)
		{
			if(copy == null)
			{
				return;
			}

			this.m_sScope = copy.getScope();
			this.m_sSubject = copy.getSubject();
			this.m_nTrustLevel = copy.getTrustLevel();
			this.m_nSourceVerificationTrustLevel = copy.getSourceVerificationTrustLevel();
			this.m_permissions.addAll(copy.getPermissions());
		}

		public Builder(COperatorPermissionFilter filter)
		{
			if(filter == null)
			{
				return;
			}

			this.m_sScope = filter.getScope();
			this.m_sSubject = filter.getSubject();
		}

		public Builder scope(String sScope)
		{
			this.m_sScope = sScope;
			return this;
		}

		public Builder subject(String sSubject)
		{
			this.m_sSubject = sSubject;
			return this;
		}

		public Builder trustLevel(Integer nTrustLevel)
		{
			this.m_nTrustLevel = nTrustLevel;
			return this;
		}

		public Builder sourceVerificationTrustLevel(Integer nSourceVerificationTrustLevel)
		{
			this.m_nSourceVerificationTrustLevel = nSourceVerificationTrustLevel;
			return this;
		}

		public Builder permission(String sPermission)
		{
			if(sPermission != null && !sPermission.trim().isEmpty())
			{
				this.m_permissions.add(sPermission);
			}
			return this;
		}

		public Builder permissions(Collection<String> permissions)
		{
			this.m_permissions.clear();
			if(permissions != null)
			{
				this.m_permissions.addAll(permissions);
			}
			return this;
		}

		public COperatorPermission build()
		{
			return new COperatorPermission(this);
		}
	}
}
