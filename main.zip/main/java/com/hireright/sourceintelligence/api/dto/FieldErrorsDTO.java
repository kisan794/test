package com.hireright.sourceintelligence.api.dto;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FieldErrorsDTO {
    private String label;
    private String value;
}
