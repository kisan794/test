package com.hireright.sourceintelligence.service.impl;

import static com.hireright.sourceintelligence.api.ApiConstants.HON;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.constants.ErrorConstants.*;

import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.PayloadFields.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.ORGANIZATION_NAME;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.ORGANIZATION_TYPE;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchScore.*;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowInternalServiceException;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowInvalidRequest;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowResourceNotFound;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.dto.timezone.DropDownDTO;
import com.hireright.sourceintelligence.domain.entity.MongoSearchResult;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.domain.mapper.SourceDTOMapper;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import java.util.Collections;


import java.time.Instant;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import com.hireright.sourceintelligence.service.SearchService;
import com.hireright.sourceintelligence.service.impl.helperservices.CountryRegionMappingUtils;
import com.hireright.sourceintelligence.util.Helper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.*;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

@Slf4j
@RequiredArgsConstructor
@Service
public class SearchServiceImpl implements SearchService {

    private final SourceMapper sourceMapper;
    private final SourceDTOMapper sourceDTOMapper;
    private final CustomSourceRepository<Source> customSourceRepository;
    private final CountryRegionMappingUtils countryRegionMappingUtils;

    @Override
    public SearchResponseDTO getSourceOrganizationList(SearchDTO searchDTO) {

        if (StringUtils.isEmpty(searchDTO.getSearchText())) {
            logAndThrowInvalidRequest(SEARCH_TEXT_MISSING, null);
        }
        var criteria = QueryBuilder.buildCriteriaForLikeStartsWith(ORGANIZATION_NAME, searchDTO.getSearchText());
        var matchOperation = QueryBuilder.buildMatch(criteria);

        var facetOperation = QueryBuilder.facetOperation(searchDTO.getStartIndex(), searchDTO.getBatchSize());
        var projectionOperation = QueryBuilder.finalProjectionWithTotalCountInPipeline();

        Aggregation aggregation = QueryBuilder.aggregateWithMatch(matchOperation, facetOperation, projectionOperation);

        String collectionName = Helper.getCollectionName(searchDTO.getOrganizationType().getType(), SOURCE_COLLECTION_SUFFIX);
        var organization = customSourceRepository.customAggregate(aggregation, collectionName, MongoSearchResult.class);

        List<SourceOrganizationDTO> organizationDTOs = sourceMapper.toSourceDTOList(organization.getOrganizationList());

        return SearchResponseDTO.builder()
                .sourceList(organizationDTOs)
                .currentPage((searchDTO.getStartIndex()))
                .totalItems(organization.getTotal())
                .totalPages(QueryBuilder.getTotalPages(organization.getTotal(), searchDTO.getBatchSize()))
                .build();
    }

    @Override
    public SearchResponseDTO getSourceOrganizationListForAutocomplete(SearchDTO searchDTO) {
        if (StringUtils.isEmpty(searchDTO.getSearchText())) {
            logAndThrowInvalidRequest(SEARCH_TEXT_MISSING, null);
        }

        Query query = QueryBuilder.searchQuery(searchDTO);

        List<String> organizations = new ArrayList<>();
        try {
            String collectionName = Helper.getCollectionName(searchDTO.getOrganizationType().getType(), SOURCE_COLLECTION_SUFFIX);
            organizations = customSourceRepository.findByFieldDistinct(query, ORGANIZATION_NAME, collectionName);

        } catch (DataAccessException dataAccessException) {
            logAndThrowInternalServiceException(DATA_ACCESS_ERROR, dataAccessException);
        }
        if (CollectionUtils.isEmpty(organizations)) {
            logAndThrowResourceNotFound(NO_SEARCH_RESULT_FOUND, null, searchDTO.getSearchText());
        }
        int total = organizations.size();
        List<String> pagedOrganizations = organizations.stream()
                .skip((long) searchDTO.getStartIndex() * searchDTO.getBatchSize())
                .limit(searchDTO.getBatchSize())
                .toList();

        return SearchResponseDTO.builder()
                .organizationNames(pagedOrganizations)
                .totalItems(total)
                .totalPages(total / searchDTO.getBatchSize())
                .currentPage(searchDTO.getStartIndex())
                .build();
    }

    @Override
    public SearchResponseDTO getSourceOrganizationContactListByHon(SearchDTO searchDTO) {

        if (!StringUtils.isNotEmpty(searchDTO.getHon())) {
            logAndThrowInvalidRequest(HON_MISSING_IN_REQUEST, null);
        }
        Query query = QueryBuilder.searchQuery(searchDTO);
        query.fields().include(HON, ORGANIZATION_TYPE, ORGANIZATION_NAME, STATUS, PAYLOAD_CONTACTS);
        String collectionName = Helper.getCollectionName(searchDTO.getHon(), SOURCE_COLLECTION_SUFFIX);

        List<Source> contacts = customSourceRepository.findByQuery(query, Source.class, collectionName);
        if (CollectionUtils.isEmpty(contacts)) {
            logAndThrowResourceNotFound(CONTACT_NOT_FOUND, null, searchDTO.getHon());
        }
        return buildSearchResponseDTO(searchDTO, contacts, ORGANIZATION_NAME);
    }

    @Override
    public SearchResponseDTO getSourceOrganizationAddressByHon(SearchDTO searchDTO) {

        if (!StringUtils.isNotEmpty(searchDTO.getHon())) {
            logAndThrowInvalidRequest(HON_MISSING_IN_REQUEST, null);
        }
        Query query = QueryBuilder.searchQuery(searchDTO);
        query.fields().include(HON, ORGANIZATION_TYPE, ORGANIZATION_NAME, STATUS, PAYLOAD_ADDRESS);
        String collectionName = Helper.getCollectionName(searchDTO.getHon(), SOURCE_COLLECTION_SUFFIX);
        List<Source> address = customSourceRepository.findByQuery(query, Source.class, collectionName);
        if (CollectionUtils.isEmpty(address)) {
            logAndThrowResourceNotFound(ADDRESS_NOT_FOUND, null, searchDTO.getHon());

        }
        return buildSearchResponseDTO(searchDTO, address, ORGANIZATION_NAME);
    }


    @Override
    public SearchResponseDTO getSourcesByFilters(SearchFilter searchFilter, String order, String sort, int startPage, int pageSize) {
        String collectionName = Helper.getCollectionName(searchFilter.getOrganizationType(), SOURCE_COLLECTION_SUFFIX);
        log.info("criteria start time: {}", Instant.now());
        Criteria criteria = QueryBuilder.buildDocumentForApprovalManager(searchFilter);
        String region = searchFilter.getRegionValue();
        if (org.springframework.util.StringUtils.hasText(region)
                && !"ALL".equalsIgnoreCase(region)) {

            List<String> countries = countryRegionMappingUtils.findDistinctCountriesByRegion(region);

            if (countries != null && !countries.isEmpty()) {
                criteria.and(COUNTRY).in(countries);
            }
        }

        log.info("criteria end time: {}", Instant.now());
        MatchOperation matchOperation = QueryBuilder.buildMatch(criteria);
        ProjectionOperation projectSelectiveData = QueryBuilder.sourceByFiltersProjection();
        SortOperation sortOperation;
        LimitOperation limit = QueryBuilder.limitOperation(pageSize);
        SkipOperation skip = QueryBuilder.skipOperation(startPage, pageSize);
        AggregationOptions aggregationOptionsToAllowDiskUse = AggregationOptions.builder()
                .allowDiskUse(true).build();
        Aggregation aggregation;
        if (!StringUtils.isEmpty(order) && !StringUtils.isEmpty(sort)) {
            if(sort.equals(SearchConstants.SortFields.ORGANIZATION_NAME)){
                sort = SEARCH_ORG;
            }else if(sort.equals(SearchConstants.SortFields.LAST_MODIFIED_BY)){
                sort = SearchConstants.SortFields.SORT_LAST_MODIFIED_BY;
            }else if(sort.equals(SearchConstants.SortFields.ASSIGNED_TO)){
                sort = SearchConstants.SortFields.SORTASSIGNEDTO;
            }
            sortOperation = QueryBuilder.buildSortOperation(sort, order);
        } else {
            sortOperation = QueryBuilder.buildSortOperation(FLAG_PRIORITY, "desc");
        }
        AddFieldsOperation addFieldsOperation = QueryBuilder.addLastModifiedBy();
        Query query = Query.query(criteria);
        long searchCountResult = customSourceRepository.queryCount(query, collectionName, Source.class);
        log.info("RAM Aggregate Document Result Time: {}, count:{}", LocalDateTime.now(), searchCountResult);
        if(sort != null && (sort.equals(SearchConstants.SortFields.SORT_LAST_MODIFIED_BY) || sort.equals(SearchConstants.SortFields.SORTASSIGNEDTO))){
            aggregation = Aggregation.newAggregation(matchOperation, addFieldsOperation, sortOperation, skip, limit, projectSelectiveData ).withOptions(aggregationOptionsToAllowDiskUse);
        }else{
            aggregation = Aggregation.newAggregation(matchOperation, sortOperation, skip, limit,addFieldsOperation, projectSelectiveData ).withOptions(aggregationOptionsToAllowDiskUse);
        }
        log.info("RAM Aggregation: {}",aggregation);
        log.info("RAM Aggregate Start Time: {}", LocalDateTime.now());
        List<Source> searchResult = customSourceRepository.aggregate(aggregation, collectionName, Source.class);
        log.info("RAM Aggregate Document Result Time: {}, searchResult size:{}", LocalDateTime.now(), searchResult.size());

        if (searchResult.isEmpty()) {
            return SearchResponseDTO.builder().build();
        }
        int total = (int)searchCountResult;
        List<SourceDTO> searchList = sourceDTOMapper.entityToSourceList(searchResult);
        return SearchResponseDTO.builder().searchList(searchList)
                .currentPage(startPage)
                .totalItems(total)
                .totalPages(QueryBuilder.getTotalPages(total, pageSize))
                .build();
    }

    @Override
    public SearchFilter getFiltersForSourceOrganizations() {
        SearchFilter searchHistoryFilter = new SearchFilter();
        searchHistoryFilter.setVerificationTypes(Arrays.stream(OrganizationType.values()).toList());
        searchHistoryFilter.setStatuses(Arrays.stream(ApprovalStatus.values()).toList());
        searchHistoryFilter.setRegion(countryRegionMappingUtils.getRegionList());
        return searchHistoryFilter;
    }

    @Override
    public List<DropDownDTO> getRegionList() {
        return countryRegionMappingUtils.getRegionList();
    }

    @Override
    public SearchResponseDTO getDetailedAutocompletedSearchResult(String keyword, OrganizationType orgType, SourceOrganizationStatus status, String country) {

        List<SourceOrganizationDTO> searchOrganizationDTOList = new ArrayList<>();
        OrganizationType organizationTypeValue = null;

        List<Source> sourceOrganizations = getDetailedAutocompleteHits(keyword, orgType, status, country);

        for (Source sourceOrganization : sourceOrganizations) {
            organizationTypeValue = sourceOrganization.getOrganizationType();
            SourceOrganizationDTO sourceDTO = sourceMapper.entitySourceToDTO(sourceOrganization);
            if (!sourceDTO.getPayload().has(USED_COUNT)) {
                sourceDTO.setUsedCount(0);
            } else {
                sourceDTO.setUsedCount((Integer) sourceDTO.getPayload().get(USED_COUNT));
            }
            searchOrganizationDTOList.add(sourceDTO);
        }

        Comparator<SourceOrganizationDTO> reverseScoreComparator = (s1, s2) -> s2.getScore().compareTo(s1.getScore());

        List<SourceOrganizationDTO> sortedList;

        if (organizationTypeValue != null && organizationTypeValue.equals(OrganizationType.EDUCATION)) {
            sortedList = searchOrganizationDTOList.stream()
                    .limit(SEARCH_LIMIT).collect(Collectors.toCollection(LinkedList::new));
        } else {
            sortedList = searchOrganizationDTOList.stream().sorted(Comparator.comparing(SourceOrganizationDTO::getUsedCount).reversed()
                    .thenComparing(reverseScoreComparator)).limit(SEARCH_LIMIT).collect(Collectors.toCollection(LinkedList::new));
        }

        return SearchResponseDTO.builder()
                //.organizationNames(organization.getOrganizationList())
                .sourceList(sortedList)
                .currentPage(1)
                .totalItems(sortedList.size())
                .totalPages(QueryBuilder.getTotalPages(sortedList.size(), 10))
                .build();
    }

    @Override
    public SearchResponseDTO getAutocompletedSuggestionForPossibleDuplicates(String keyword, OrganizationType orgType) {

        Criteria criteria = QueryBuilder.buildDuplicateSearchDocument(keyword);
        MatchOperation matchOperation = QueryBuilder.buildMatch(criteria);
        ProjectionOperation projectSelectiveData = QueryBuilder.possibleDuplicateProjection();
        Aggregation aggregation = newAggregation(matchOperation, projectSelectiveData, limit(SEARCH_LIMIT));

        String collectionName = Helper.getCollectionName(orgType.getType(), SOURCE_COLLECTION_SUFFIX);
        log.info("possible duplicate query: {}", aggregation);
        List<Source> sourceOrganizations = customSourceRepository.aggregate(aggregation, collectionName, Source.class);
        if (ObjectUtils.isEmpty(sourceOrganizations)) {
            return SearchResponseDTO.builder().sourceList(new ArrayList<>()).build();
        }

        List<SourceOrganizationDTO> searchOrganizationDTOList = sourceMapper.toSourceDTOList(sourceOrganizations);

        return SearchResponseDTO.builder()
                //.organizationNames(organization.getOrganizationList())
                .sourceList(searchOrganizationDTOList)
                .currentPage(1)
                .totalItems(searchOrganizationDTOList.size())
                .totalPages(QueryBuilder.getTotalPages(searchOrganizationDTOList.size(), 10))
                .build();
    }

    private List<Source> getDetailedAutocompleteHits(String keyword, OrganizationType orgType,
                                                     SourceOrganizationStatus status, String country) {

        Criteria criteria = QueryBuilder.buildAutocompleteSearchDocument(keyword, country, status);
        MatchOperation matchOperation = QueryBuilder.buildMatch(criteria);
        ProjectionOperation projectSelectiveData = QueryBuilder.autoCompleteHitsProjection();
        Aggregation aggregation = newAggregation(matchOperation, projectSelectiveData, limit(SEARCH_LIMIT));
        String collectionName = Helper.getCollectionName(orgType.getType(), SOURCE_COLLECTION_SUFFIX);
        List<Source> sourceOrganizations = customSourceRepository.aggregate(aggregation, collectionName, Source.class);
        if (ObjectUtils.isEmpty(sourceOrganizations)) {
            logAndThrowResourceNotFound(NO_SEARCH_RESULT_FOUND, null, keyword);
        }
        return sourceOrganizations;
    }

    private SearchResponseDTO buildSearchResponseDTO(SearchDTO searchDTO,
                                                     List<Source> organizations,
                                                     String sortByName) {
        //if the size of the database query results are greater than the batch size + start index , implement paging
        //Note: startIndex is PageNumber. PageNumber starts from 0
        if (canDoPaging(organizations.size(), searchDTO)) {

            //PageRequest uses zero-based page index
            Sort sortBy = Sort.by(sortByName).descending();
            Pageable pageable = PageRequest.of(searchDTO.getStartIndex() - 1, searchDTO.getBatchSize(),
                    sortBy);
            int start = Math.min(Math.max(searchDTO.getBatchSize() * (searchDTO.getStartIndex() - 1), 0),
                    organizations.size());
            int end = Math.min(Math.max(searchDTO.getBatchSize() * searchDTO.getStartIndex(), start),
                    organizations.size());
            log.info("start:{}end:{}", start, end);
            final Page<Source> page = new PageImpl<>(organizations.subList(start, end), pageable,
                    organizations.size());
            if (page.getContent().isEmpty()) {
                int num = page.getNumber() + 1;
                logAndThrowResourceNotFound(NO_DATA_FOUND, null, num, page.getTotalElements(), page.getTotalPages(), searchDTO.getBatchSize());
            }
            List<Source> entity = page.getContent();
            List<SourceOrganizationDTO> organizationDTOS = sourceMapper.toSourceDTOList(entity);

            return SearchResponseDTO.builder()
                    .sourceList(organizationDTOS)
                    // getNumber returns value starting with 0. For UI , page number starts from 1
                    .currentPage(page.getNumber() + 1)
                    .totalItems(page.getTotalElements())
                    .totalPages(page.getTotalPages())
                    .build();
        } else { // size of results is less than the batch size requested
            List<SourceOrganizationDTO> organizationDTOS = sourceMapper.toSourceDTOList(organizations);

            return SearchResponseDTO.builder()
                    .sourceList(organizationDTOS)
                    .currentPage(1)
                    .totalItems(organizations.size())
                    .totalPages(1)
                    .build();
        }
    }

    private boolean canDoPaging(int resultCount, SearchDTO searchDTO) {
        if (resultCount == 0)
            return false;
        return resultCount > searchDTO.getStartIndex() + searchDTO.getBatchSize();
    }

}