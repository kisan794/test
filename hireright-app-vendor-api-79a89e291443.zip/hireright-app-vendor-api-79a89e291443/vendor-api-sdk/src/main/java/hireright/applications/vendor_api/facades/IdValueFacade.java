package hireright.applications.vendor_api.facades;
/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	2017-08-18	Created
 *	M.Kuznetsov	2025-10-29	HRG-345322. Openjdk21-migration
 */

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import hireright.components.domain.dialects.vendor_api.EntityIdType;
import hireright.components.domain.dialects.vendor_api.IdValueType;

public class IdValueFacade {
    private final Map<String, IdValueType> m_idValues = new HashMap<>();

    public IdValueFacade set(String sName, String sValue) {
        IdValueType idValue = this.m_idValues.get(sName);

        if (idValue == null) {
            idValue = new IdValueType();
            idValue.setName(sName);
            this.m_idValues.put(sName, idValue);
        }

        idValue.setValue(sValue);

        return this;
    }

    public IdValueFacade() {}

    public IdValueFacade(IdValueType idValue) {
        this.m_idValues.put(idValue.getName(), idValue);
    }

    public IdValueFacade(List<IdValueType> idValues) {
        for (IdValueType idValue : idValues) {
            this.m_idValues.put(idValue.getName(), idValue);
        }
    }

    public IdValueType get(String sName) {
        return this.m_idValues.get(sName);
    }

    public Set<String> getNames() {
        return this.m_idValues.keySet();
    }

    public String value(String sName) {
        return this.m_idValues.containsKey(sName) ? this.m_idValues.get(sName).getValue() : null;
    }

    public Collection<IdValueType> getAll() {
        return this.m_idValues.values();
    }

    public EntityIdType createEntityId() {
        EntityIdType result = new EntityIdType();

        result.getIdValues().addAll(getAll());

        return result;
    }
}
