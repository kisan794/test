package com.hireright.sourceintelligence.service.notification;

import com.hireright.sourceintelligence.api.dto.notification.DataExtractionNotificationDTO;
import com.hireright.sourceintelligence.api.dto.notification.NotificationResponseDTO;

/**
 * Interface for data extraction notification service
 * Following Interface Segregation Principle - focused interface for data extraction notifications
 */
public interface DataExtractionNotificationService {
    
    /**
     * Send data extraction completion notification
     * 
     * @param notification data extraction notification details
     * @return notification response
     */
    NotificationResponseDTO sendDataExtractionNotification(DataExtractionNotificationDTO notification);
}

