package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.CycleResult;
import com.hireright.sourceintelligence.domain.entity.UserCycle;
import com.hireright.sourceintelligence.domain.repository.UserCycleRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.AUTO_APPOVED;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.MANUAL_PROCESS;

@Primary
@Slf4j
@RequiredArgsConstructor
@Service
public class UserCycleEvaluator {

    private final UserCycleRepository userCycleRepository;

    public CycleResult processRequest(String userId, String region, int trustScore, int regionThreshold) {

        UserCycle cycle = userCycleRepository.findByUserIdAndRegion(userId, region)
                .orElseGet(() -> initializeCycle(userId, region, trustScore, regionThreshold));

        if (cycle.getTrustScore() != trustScore || cycle.getRegionThreshold() != regionThreshold) {
            resetCycle(cycle, trustScore, regionThreshold);
        }

        if (cycle.getAutoQuota() == 0 && cycle.getManualQuota() == 0) {
            resetCycle(cycle, trustScore, regionThreshold);
        }

        String result;
        if (cycle.getManualQuota() > 0) {
            cycle.setManualQuota(cycle.getManualQuota() - 1);
            result = MANUAL_PROCESS;
        } else {
            cycle.setAutoQuota(cycle.getAutoQuota() - 1);
            result = AUTO_APPOVED;
        }

        cycle.setLastModifiedDate(LocalDateTime.now());
        return new CycleResult(result, cycle);
    }

    private UserCycle initializeCycle(String userId, String region, int trustScore, int regionThreshold) {
        UserCycle cycle = new UserCycle();
        cycle.setUserId(userId);
        cycle.setRegion(region);
        resetCycle(cycle, trustScore, regionThreshold);
        return cycle;
    }

    private void resetCycle(UserCycle cycle, int trustScore, int regionThreshold) {
        int highest = Math.max(trustScore, regionThreshold);

        int autoScore = calculateAutoScore(highest, trustScore, regionThreshold, cycle.getCycleSize());

        cycle.setAutoQuota(autoScore);
        cycle.setManualQuota(cycle.getCycleSize() - autoScore);
        cycle.setEffectiveThreshold(highest);

        cycle.setTrustScore(trustScore);
        cycle.setRegionThreshold(regionThreshold);

        cycle.setCycleStartDate(LocalDateTime.now());
        cycle.setLastModifiedDate(LocalDateTime.now());
    }

    private int calculateAutoScore(int highest, int trustScore, int regionThreshold, int cycleSize) {
        if (trustScore == 0 && regionThreshold == 0) {
            return 0;
        }

        if (trustScore == 100 && regionThreshold == 100) {
            return cycleSize;
        }

        int rounded = roundToNearest10(highest);
        return rounded / 10;
    }

    private int roundToNearest10(int value) {
        if (value <= 0) return 0;
        if (value >= 100) return 100;
        return (int) (Math.round(value / 10.0) * 10);
    }
}