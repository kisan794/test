package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.domain.enums.UserRoles;
import com.hireright.sourceintelligence.service.impl.ContactServiceImpl;
import com.hireright.sourceintelligence.util.TestDataProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ContactServiceImplTest {

	@Mock
	private SourceService sourceService;

	@Mock
	private SearchService searchServiceMock;

	@InjectMocks
	private ContactServiceImpl contactServiceimpl;

	private UserInfo userInfo;

	@BeforeEach
	void setUp() {
		userInfo = new UserInfo();
		userInfo.setRoles(Collections.singletonList(UserRoles.RESEARCH_ANALYST.getRole()));
	}

	@Test
	void testUpdateContactWhenSourceIsActive() {
		String hon = TestDataProvider.getHon();
		ContactDTO contactDTO = TestDataProvider.getContactDTO();
		contactDTO.setHon(hon);

		SourceOrganizationDTO sourceDto = TestDataProvider.getSourceOrganizationDTO();
		sourceDto.setStatus(SourceOrganizationStatus.ACTIVE);
		sourceDto.setHon(hon);

		when(sourceService.getSourceByHon(hon)).thenReturn(sourceDto);

		contactServiceimpl.updateContact(contactDTO, userInfo);

		verify(sourceService).getSourceByHon(hon);
		verify(sourceService).updateSource(eq(sourceDto), any(UIActionsDTO.class));
	}

	@Test
	void testUpdateContactWhenSourceIsInactive_shouldThrow() {
		String hon = TestDataProvider.getHon();
		ContactDTO contactDTO = TestDataProvider.getContactDTO();
		contactDTO.setHon(hon);

		SourceOrganizationDTO sourceDto = TestDataProvider.getSourceOrganizationDTO();
		sourceDto.setStatus(SourceOrganizationStatus.INACTIVE);
		sourceDto.setHon(hon);

		when(sourceService.getSourceByHon(hon)).thenReturn(sourceDto);

		assertThrows(RuntimeException.class, () -> contactServiceimpl.updateContact(contactDTO, userInfo));

		verify(sourceService).getSourceByHon(hon);
		verify(sourceService, never()).updateSource(any(), any());
	}

	@Test
	void testGetSourceOrganizationContactListByHon() {
		String hon = TestDataProvider.getHon();
		SearchDTO searchDTO = TestDataProvider.getSearchDTO();
		searchDTO.setHon(hon);
		searchDTO.setSourceOrganizationStatus(SourceOrganizationStatus.ACTIVE);
		searchDTO.setOrganizationType(OrganizationType.EDUCATION);

		SearchResponseDTO expected = new SearchResponseDTO();
		expected.setOrganizationType(OrganizationType.EDUCATION);

		when(searchServiceMock.getSourceOrganizationContactListByHon(any(SearchDTO.class)))
				.thenReturn(expected);

		SearchResponseDTO result = contactServiceimpl.getSourceContactListByHon(searchDTO);

		assertNotNull(result);
		assertSame(expected, result);

		ArgumentCaptor<SearchDTO> captor = ArgumentCaptor.forClass(SearchDTO.class);
		verify(searchServiceMock).getSourceOrganizationContactListByHon(captor.capture());

		SearchDTO actual = captor.getValue();
		assertEquals(hon, actual.getHon());
		assertEquals(SourceOrganizationStatus.ACTIVE, actual.getSourceOrganizationStatus());
		assertEquals(OrganizationType.EDUCATION, actual.getOrganizationType());
	}

	@Test
	void testGetSourceContactListByHon_noException() {
		SearchDTO searchDTO = TestDataProvider.getSearchDTO();
		searchDTO.setHon(TestDataProvider.getHon());

		assertDoesNotThrow(() -> contactServiceimpl.getSourceContactListByHon(searchDTO));
	}
}