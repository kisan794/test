package hireright.applications.permissions_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-17  HRG-330191 initial version
 */

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Objects;

public class COperatorPermissionFilter
{
	@JsonProperty("scope")
	private String m_sScope;

	@JsonProperty("subject")
	private String m_sSubject;

	private COperatorPermissionFilter()
	{
	}

	private COperatorPermissionFilter(Builder builder)
	{
		m_sScope = builder.m_sScope;
		m_sSubject = builder.m_sSubject;
	}

	public String getScope()
	{
		return m_sScope;
	}

	public String getSubject()
	{
		return m_sSubject;
	}

	@Override
	public String toString()
	{
		return "COperatorPermissionFilter{" + "m_sScope='" + m_sScope + '\'' + ", m_sSubject='"
			+ m_sSubject + '\'' + '}';
	}

	@Override
	public boolean equals(Object o)
	{
		if(this == o)
		{
			return true;
		}
		if(o == null || getClass() != o.getClass())
		{
			return false;
		}

		COperatorPermissionFilter that = (COperatorPermissionFilter) o;

		if(!Objects.equals(m_sScope, that.m_sScope))
		{
			return false;
		}
		return Objects.equals(m_sSubject, that.m_sSubject);
	}

	@Override
	public int hashCode()
	{
		int result = m_sScope != null ? m_sScope.hashCode() : 0;
		result = 31 * result + (m_sSubject != null ? m_sSubject.hashCode() : 0);
		return result;
	}

	public static final class Builder
	{
		private String m_sScope;
		private String m_sSubject;

		public Builder()
		{
		}

		public Builder(COperatorPermissionFilter copy)
		{
			if(copy == null)
			{
				return;
			}

			this.m_sScope = copy.getScope();
			this.m_sSubject = copy.getSubject();
		}

		public Builder scope(String sScope)
		{
			this.m_sScope = sScope;
			return this;
		}

		public Builder subject(String sSubject)
		{
			this.m_sSubject = sSubject;
			return this;
		}

		public COperatorPermissionFilter build()
		{
			return new COperatorPermissionFilter(this);
		}
	}
}
