package com.hireright.sourceintelligence.domain.enums;

import com.fasterxml.jackson.annotation.JsonValue;

public enum OrganizationType {
    EDUCATION("EDUCATION"), EMPLOYMENT("EMPLOYMENT");

    private final String type;

    OrganizationType(String type) {
        this.type = type;
    }

    public static OrganizationType fromString(String type) {
        return type == null ? null : OrganizationType.valueOf(type.toUpperCase());
    }

    @Override
    public String toString() {
        return this.type;
    }

    @JsonValue
    public String getType() {
        return this.type.toUpperCase();
    }
}
