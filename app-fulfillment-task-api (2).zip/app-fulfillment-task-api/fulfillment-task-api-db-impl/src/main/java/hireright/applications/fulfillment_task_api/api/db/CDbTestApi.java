package hireright.applications.fulfillment_task_api.api.db;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-13  HRG-332327 initial version
 * M.Naumov   2025-05-19  HRG-337113 adding getOrderFormInstructionManager
 */


import hireright.applications.fulfillment_task_api.api.ITestApi;
import hireright.applications.fulfillment_task_api.api.db.management.CTestManager;
import hireright.applications.fulfillment_task_api.api.management.IServiceHealthManager;
import hireright.applications.fulfillment_task_api.api.management.ITestManager;

public class CDbTestApi implements ITestApi {

    @Override
    public ITestManager getTestManager() {
        return new CTestManager();
    }

    @Override
    public IServiceHealthManager getServiceHealthManager() {
        return null;
    }
}
