package hireright.applications.fulfillment_task_api.rest.recombointegration.controller;

import hireright.applications.fulfillment_task_api.model.recombointegration.transformer.TransformRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.transformer.TransformResponse;
import hireright.applications.fulfillment_task_api.rest.recombointegration.exception.XmlTransformationException;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.XmlTransformationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

@RestController
@Slf4j
public class TestTransformerController {


    private final XmlTransformationService xmlTransformationService;

    public TestTransformerController(XmlTransformationService xmlTransformationService) {
        this.xmlTransformationService = xmlTransformationService;
    }

    @PostMapping(value = "/transform/xml-to-json", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<TransformResponse> transformXmlToJson(@RequestBody TransformRequest request) {
        log.debug("Request: {}", request);

        try {
            log.debug("Processing XML content (length: {} characters, type: {})",
                    request.getContent().length(), request.getType());
            byte[] decodedBytes = Base64.getDecoder().decode(request.getContent());
            String xmlData = new String(decodedBytes, StandardCharsets.UTF_8);
            String jsonResult = xmlTransformationService.transformXmlToJson(
                xmlData,
                    request.getType()
            );

            log.info("XML to JSON transformation completed successfully (type: {})", request.getType());

            return ResponseEntity.ok(TransformResponse.success(jsonResult));

        } catch (XmlTransformationException e) {
            log.error("XML transformation failed: {}", e.getMessage());
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(TransformResponse.error(e.getErrorCode(), e.getMessage()));

        } catch (Exception e) {
            log.error("Unexpected error during transformation", e);
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(TransformResponse.error("INTERNAL_ERROR", "An unexpected error occurred"));
        }
    }

}