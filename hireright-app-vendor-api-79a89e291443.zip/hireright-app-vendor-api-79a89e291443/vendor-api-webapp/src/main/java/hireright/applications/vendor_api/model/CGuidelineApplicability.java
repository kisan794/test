/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-10-30	Created
 */
package hireright.applications.vendor_api.model;

public class CGuidelineApplicability
{
	private final EGuidelineApplicabilityType serviceType;
	private final EGuidelineApplicabilityType customerType;

	public EGuidelineApplicabilityType getServiceApplicability()
	{
		return serviceType;
	}

	public EGuidelineApplicabilityType getCustomerApplicability()
	{
		return customerType;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((this.customerType == null) ? 0 : this.customerType.hashCode());
		result = prime * result + ((this.serviceType == null) ? 0 : this.serviceType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CGuidelineApplicability other = (CGuidelineApplicability) obj;
		if (this.customerType != other.customerType)
			return false;
		if (this.serviceType != other.serviceType)
			return false;
		return true;
	}

	public CGuidelineApplicability(Integer nServiceID, Long nCustomerID)
	{
		this.serviceType = EGuidelineApplicabilityType.forIdentifier(nServiceID);
		this.customerType = EGuidelineApplicabilityType.forIdentifier(nCustomerID);
	}

	public CGuidelineApplicability(EGuidelineApplicabilityType serviceType, EGuidelineApplicabilityType customerType)
	{
		this.serviceType = serviceType;
		this.customerType = customerType;
	}

	public static CGuidelineApplicability customerSpecific()
	{
		return new CGuidelineApplicability(EGuidelineApplicabilityType.COMMON, EGuidelineApplicabilityType.CUSTOM);
	}

	public static CGuidelineApplicability serviceSpecific()
	{
		return new CGuidelineApplicability(EGuidelineApplicabilityType.CUSTOM, EGuidelineApplicabilityType.COMMON);
	}

	public static CGuidelineApplicability customerAndServiceSpecific()
	{
		return new CGuidelineApplicability(EGuidelineApplicabilityType.CUSTOM, EGuidelineApplicabilityType.CUSTOM);
	}
}
