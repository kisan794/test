package com.hireright.sourceintelligence.api.v2;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.v2.dto.SourceDTO;
import com.hireright.sourceintelligence.domain.enums.*;
import com.hireright.sourceintelligence.service.CommonUtilService;
import com.hireright.sourceintelligence.service.SourceService;
import com.hireright.sourceintelligence.util.DTOConversion;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.time.Instant;
import java.util.*;

import static com.hireright.sourceintelligence.api.ApiConstants.*;
import static com.hireright.sourceintelligence.constants.ErrorConstants.*;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowInvalidRequest;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowUnauthorizedException;

/**
 * Controller to trigger CRUD operations on SourceOrganization Document
 */

@RestController("V2SourceApiController")
@RequiredArgsConstructor
@Validated
@Slf4j
@CrossOrigin
public class SourceApiController implements SourceApi {



    private final SourceService sourceService;
    private final CommonUtilService commonUtilService;
    private final DTOConversion dtoConversion;

    @Override
    public ResponseEntity<SourceDTO> createSourceOrganization(@Valid @RequestBody SourceDTO sourceDTO, HttpServletRequest httpServletRequest) {
        UserInfo userInfo = commonUtilService.getUserInfo(httpServletRequest);
        List<String> roles = userInfo.getRoles();
        if(roles.size()==1 && roles.get(0).equalsIgnoreCase(UserRoles.RESEARCH_ANALYST.getRole())){
            logAndThrowUnauthorizedException(SEARCH_TEXT_MISSING,null);
        }

        SourceOrganizationDTO sourceOrganizationDTO = dtoConversion.convertV2DtoToV1Dto(sourceDTO);


        SourceOrganizationDTO response = sourceService.createSource(sourceOrganizationDTO, new UIActionsDTO());
        SourceDTO responseDTO = dtoConversion.convertV1DtoToV2Dto(response);
        return new ResponseEntity<>(responseDTO, HttpStatus.CREATED);
    }

    @Override
    public ResponseEntity<SourceDTO> updateSourceOrganization(@PathVariable(value = HON) @NotBlank final String hon,
                                                              @Valid @RequestBody SourceDTO sourceDTO, HttpServletRequest httpServletRequest) {

        UserInfo userInfo = commonUtilService.getUserInfo(httpServletRequest);
        List<String> roles = userInfo.getRoles();
        if(roles.size()==1 && roles.get(0).equalsIgnoreCase(UserRoles.RESEARCH_ANALYST.getRole())){
            logAndThrowUnauthorizedException(USER_UNAUTHORIZED,null);
        }
        SourceOrganizationDTO sourceOrganizationDTO = dtoConversion.convertV2DtoToV1Dto(sourceDTO);

        validateSourceOrganization(hon, sourceOrganizationDTO);
        SourceOrganizationDTO response = sourceService.updateSource(sourceOrganizationDTO, new UIActionsDTO());
        SourceDTO responseDTO = dtoConversion.convertV1DtoToV2Dto(response);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> updateSourceOrganizationStatus(@PathVariable(value = HON) @NotNull final String hon, @RequestBody SourceDTO sourceDTO, HttpServletRequest httpServletRequest) {
        UserInfo userInfo = commonUtilService.getUserInfo(httpServletRequest);
        List<String> roles = userInfo.getRoles();
        if(roles.size()==1 && roles.get(0).equalsIgnoreCase(UserRoles.RESEARCH_ANALYST.getRole())){
            logAndThrowUnauthorizedException(USER_UNAUTHORIZED,null);
        }
       // sourceService.updateSourceStatus(userInfo, hon, sourceDTO.getStatus());
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }



    public List<SourceDTO> getSourceByHon(String hon) {
        SourceOrganizationDTO response = sourceService.getSourceByHon(hon);
        SourceDTO responseDTO = dtoConversion.convertV1DtoToV2Dto(response);
        return List.of(responseDTO);
    }




    //Validate the input payload before updating the SourceOrganization
    private void validateSourceOrganization(String hon, SourceOrganizationDTO dto) {
        String errorMessage = null;
        if (StringUtils.isBlank(hon)) {
            errorMessage = "Path Variable hon is empty or blank.";
        }
        if (StringUtils.isBlank(dto.getHon())) {
            errorMessage = "Hon field is empty or blank in the payload.";
        }
        if (!StringUtils.equals(hon, dto.getHon())) {
            errorMessage = "Hon mismatch between path variable and payload.";
        }
        if (errorMessage != null) {
            logAndThrowInvalidRequest(VALIDATION_FAILURE,null,errorMessage);
        }
    }


}
