package com.hireright.migrationservice.repository;

import com.hireright.migrationservice.domain.Vendor;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface VendorRepository extends MongoRepository<Vendor, String> {
    
    /**
     * Find vendor by vendor name
     */
    Optional<Vendor> findByVendor(String vendor);
}

