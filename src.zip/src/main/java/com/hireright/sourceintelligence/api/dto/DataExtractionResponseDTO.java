package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DataExtractionResponseDTO {
    private String status;
    private String message;
    private String dataExtractionType;
    private String filename;
    private Integer totalRecords;
    private Integer totalSourcesUpdated;
    private Integer notFoundRecords;
    private List<Map<String, Object>> notFoundRecordsData;
    private List<Map<String, String>> excelMetadata;
    private Long processingTimeMs;
}