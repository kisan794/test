package com.hireright.sourceintelligence.service.extraction;

import com.hireright.sourceintelligence.api.dto.ParchmentRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DataExtractionProcessorFactoryTest {

    @Mock
    private DataExtractionProcessor parchmentProcessor;

    @Mock
    private DataExtractionProcessor clearinghouseProcessor;

    @Mock
    private DataExtractionProcessor nscProcessor;

    private DataExtractionProcessorFactory factory;

    @BeforeEach
    void setUp() {
        when(parchmentProcessor.getDataExtractionTypeType()).thenReturn("parchment");
        when(parchmentProcessor.supports("parchment")).thenReturn(true);
        when(parchmentProcessor.supports("PARCHMENT")).thenReturn(true);
        when(parchmentProcessor.supports(anyString())).thenAnswer(invocation -> {
            String type = invocation.getArgument(0);
            return "parchment".equalsIgnoreCase(type);
        });

        when(clearinghouseProcessor.getDataExtractionTypeType()).thenReturn("clearinghouse");
        when(clearinghouseProcessor.supports("clearinghouse")).thenReturn(true);
        when(clearinghouseProcessor.supports("CLEARINGHOUSE")).thenReturn(true);
        when(clearinghouseProcessor.supports(anyString())).thenAnswer(invocation -> {
            String type = invocation.getArgument(0);
            return "clearinghouse".equalsIgnoreCase(type);
        });

        when(nscProcessor.getDataExtractionTypeType()).thenReturn("nsc");
        when(nscProcessor.supports("nsc")).thenReturn(true);
        when(nscProcessor.supports("NSC")).thenReturn(true);
        when(nscProcessor.supports(anyString())).thenAnswer(invocation -> {
            String type = invocation.getArgument(0);
            return "nsc".equalsIgnoreCase(type);
        });
    }

    @Test
    void constructor_WithMultipleProcessors_ShouldInitializeSuccessfully() {
        List<DataExtractionProcessor> processors = Arrays.asList(parchmentProcessor, clearinghouseProcessor);

        factory = new DataExtractionProcessorFactory(processors);

        assertNotNull(factory);
    }

    @Test
    void constructor_WithSingleProcessor_ShouldInitializeSuccessfully() {
        List<DataExtractionProcessor> processors = Collections.singletonList(parchmentProcessor);

        factory = new DataExtractionProcessorFactory(processors);

        assertNotNull(factory);
    }

    @Test
    void constructor_WithEmptyList_ShouldInitializeSuccessfully() {
        List<DataExtractionProcessor> processors = Collections.emptyList();

        factory = new DataExtractionProcessorFactory(processors);

        assertNotNull(factory);
    }

    @Test
    void getProcessor_WithValidType_ShouldReturnCorrectProcessor() {
        List<DataExtractionProcessor> processors = Arrays.asList(parchmentProcessor, clearinghouseProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        DataExtractionProcessor result = factory.getProcessor("parchment");

        assertNotNull(result);
        assertSame(parchmentProcessor, result);
    }

    @Test
    void getProcessor_WithDifferentValidType_ShouldReturnCorrectProcessor() {
        List<DataExtractionProcessor> processors = Arrays.asList(parchmentProcessor, clearinghouseProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        DataExtractionProcessor result = factory.getProcessor("clearinghouse");

        assertNotNull(result);
        assertSame(clearinghouseProcessor, result);
    }

    @Test
    void getProcessor_WithCaseInsensitiveType_ShouldReturnCorrectProcessor() {
        List<DataExtractionProcessor> processors = Collections.singletonList(parchmentProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        DataExtractionProcessor result = factory.getProcessor("PARCHMENT");

        assertNotNull(result);
        assertSame(parchmentProcessor, result);
    }

    @Test
    void getProcessor_WithInvalidType_ShouldThrowException() {
        List<DataExtractionProcessor> processors = Arrays.asList(parchmentProcessor, clearinghouseProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> factory.getProcessor("nonexistent"));

        assertTrue(exception.getMessage().contains("Unsupported Data Extraction type: 'nonexistent'"));
        assertTrue(exception.getMessage().contains("Available types:"));
    }

    @Test
    void getProcessor_WithNullType_ShouldThrowException() {
        List<DataExtractionProcessor> processors = Collections.singletonList(parchmentProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> factory.getProcessor(null));

        assertEquals("Data Extraction type cannot be null or empty", exception.getMessage());
    }

    @Test
    void getProcessor_WithEmptyStringType_ShouldThrowException() {
        List<DataExtractionProcessor> processors = Collections.singletonList(parchmentProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> factory.getProcessor(""));

        assertEquals("Data Extraction type cannot be null or empty", exception.getMessage());
    }

    @ParameterizedTest
    @ValueSource(strings = {"   ", "\t", "\n", "  \t\n  "})
    void getProcessor_WithWhitespaceType_ShouldThrowException(String whitespace) {
        List<DataExtractionProcessor> processors = Collections.singletonList(parchmentProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> factory.getProcessor(whitespace));

        assertEquals("Data Extraction type cannot be null or empty", exception.getMessage());
    }

    @Test
    void getProcessor_WithEmptyProcessorsList_ShouldThrowException() {
        List<DataExtractionProcessor> processors = Collections.emptyList();
        factory = new DataExtractionProcessorFactory(processors);

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> factory.getProcessor("parchment"));

        assertTrue(exception.getMessage().contains("Unsupported Data Extraction type: 'parchment'"));
        assertTrue(exception.getMessage().contains("Available types: none"));
    }

    @Test
    void getSupportedTypes_WithMultipleProcessors_ShouldReturnAllTypes() {
        List<DataExtractionProcessor> processors = Arrays.asList(parchmentProcessor, clearinghouseProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        String supportedTypes = factory.getSupportedTypes();

        assertNotNull(supportedTypes);
        assertTrue(supportedTypes.contains("parchment"));
        assertTrue(supportedTypes.contains("clearinghouse"));
        assertTrue(supportedTypes.contains(", "));
    }

    @Test
    void getSupportedTypes_WithSingleProcessor_ShouldReturnSingleType() {
        List<DataExtractionProcessor> processors = Collections.singletonList(parchmentProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        String supportedTypes = factory.getSupportedTypes();

        assertEquals("parchment", supportedTypes);
    }

    @Test
    void getSupportedTypes_WithEmptyProcessors_ShouldReturnNone() {
        List<DataExtractionProcessor> processors = Collections.emptyList();
        factory = new DataExtractionProcessorFactory(processors);

        String supportedTypes = factory.getSupportedTypes();

        assertEquals("none", supportedTypes);
    }

    @Test
    void getSupportedTypes_WithThreeProcessors_ShouldReturnAllTypes() {
        List<DataExtractionProcessor> processors = Arrays.asList(parchmentProcessor, clearinghouseProcessor, nscProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        String supportedTypes = factory.getSupportedTypes();

        assertNotNull(supportedTypes);
        assertTrue(supportedTypes.contains("parchment"));
        assertTrue(supportedTypes.contains("clearinghouse"));
        assertTrue(supportedTypes.contains("nsc"));
    }

    @Test
    void isSupported_WithValidType_ShouldReturnTrue() {
        List<DataExtractionProcessor> processors = Arrays.asList(parchmentProcessor, clearinghouseProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        boolean result = factory.isSupported("parchment");

        assertTrue(result);
    }

    @Test
    void isSupported_WithDifferentValidType_ShouldReturnTrue() {
        List<DataExtractionProcessor> processors = Arrays.asList(parchmentProcessor, clearinghouseProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        boolean result = factory.isSupported("clearinghouse");

        assertTrue(result);
    }

    @Test
    void isSupported_WithInvalidType_ShouldReturnFalse() {
        List<DataExtractionProcessor> processors = Arrays.asList(parchmentProcessor, clearinghouseProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        boolean result = factory.isSupported("nonexistent");

        assertFalse(result);
    }

    @Test
    void isSupported_WithNullType_ShouldReturnFalse() {
        List<DataExtractionProcessor> processors = Collections.singletonList(parchmentProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        boolean result = factory.isSupported(null);

        assertFalse(result);
    }

    @Test
    void isSupported_WithEmptyStringType_ShouldReturnFalse() {
        List<DataExtractionProcessor> processors = Collections.singletonList(parchmentProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        boolean result = factory.isSupported("");

        assertFalse(result);
    }

    @ParameterizedTest
    @ValueSource(strings = {"   ", "\t", "\n", "  \t\n  "})
    void isSupported_WithWhitespaceType_ShouldReturnFalse(String whitespace) {
        List<DataExtractionProcessor> processors = Collections.singletonList(parchmentProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        boolean result = factory.isSupported(whitespace);

        assertFalse(result);
    }

    @Test
    void isSupported_WithCaseInsensitiveType_ShouldReturnTrue() {
        List<DataExtractionProcessor> processors = Collections.singletonList(parchmentProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        boolean result = factory.isSupported("PARCHMENT");

        assertTrue(result);
    }

    @Test
    void getProcessor_CalledMultipleTimes_ShouldReturnSameInstance() {
        List<DataExtractionProcessor> processors = Collections.singletonList(parchmentProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        DataExtractionProcessor result1 = factory.getProcessor("parchment");
        DataExtractionProcessor result2 = factory.getProcessor("parchment");

        assertSame(result1, result2);
    }

    @Test
    void getProcessor_WithMultipleProcessors_ShouldReturnFirstMatchingProcessor() {
        List<DataExtractionProcessor> processors = Arrays.asList(parchmentProcessor, clearinghouseProcessor, nscProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        DataExtractionProcessor result = factory.getProcessor("parchment");

        assertNotNull(result);
        assertSame(parchmentProcessor, result);
    }

    @Test
    void isSupported_WithEmptyProcessorsList_ShouldReturnFalse() {
        List<DataExtractionProcessor> processors = Collections.emptyList();
        factory = new DataExtractionProcessorFactory(processors);

        boolean result = factory.isSupported("parchment");

        assertFalse(result);
    }

    @Test
    void getProcessor_ErrorMessage_ShouldIncludeAvailableTypes() {
        List<DataExtractionProcessor> processors = Arrays.asList(parchmentProcessor, clearinghouseProcessor);
        factory = new DataExtractionProcessorFactory(processors);

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> factory.getProcessor("unknown"));

        String message = exception.getMessage();
        assertTrue(message.contains("Unsupported Data Extraction type: 'unknown'"));
        assertTrue(message.contains("parchment"));
        assertTrue(message.contains("clearinghouse"));
    }
}

