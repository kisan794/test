/*
 * @(#)$RCSfile: CBaseEntryPointFramework.java,v $ $Revision: 1.2 $ $Date: 2014/07/28 14:57:10 $ $Author: aputintsev $ 
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/util/CBaseEntryPointFramework.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *     $Log: CBaseEntryPointFramework.java,v $
 *     Revision 1.2  2014/07/28 14:57:10  aputintsev
 *     forked from production version - projects_src/applications/accesspoint
 *
 *     Revision 1.1.2.1.2.1  2009/08/18 11:09:20  asolntsev
 *     Bugfixing and polishing
 *
 *     Revision 1.1.2.1  2009/08/13 13:24:24  asolntsev
 *     Created by St.Petersburg team
 *
 *     Revision 1.2  2009/08/06 13:21:52  banton
 *     Phase 1.1 Edition
 *
 *     Revision 1.1  2009/08/06 09:37:55  banton
 *     Added simple Finite State Machine support. Tested only for memory storage
 *
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hireright.applications.accesspoint.util;

import hireright.objects.utilities.CEntryPoint;
import hireright.objects.utilities.CEntryPointFactory;
import hireright.sdk.db.sql.IField;
import hireright.sdk.util.CStringUtils;
import org.apache.commons.collections.MultiMap;

/**
 *
 * @author banton
 */
public abstract class CBaseEntryPointFramework
		implements IEntryPointFramework
{
		public CEntryPoint createEntryPointAuth(String userID, String userClass, String login, String entryPointType,
																						Integer designNumber, String domainID, MultiMap entryPointParams)
		{
		String password = generatePassword();
		// Integer nID = CSequence.nextValue(CFEntryPoint.ID_SEQUENCE);
		Long nID = System.currentTimeMillis() & 0x7FFFFFFFL;

		String sKey = CEntryPoint.md5_digest(password + String.valueOf(nID));
		CEntryPoint entryPoint= new CEntryPoint(nID, sKey);

				entryPoint.setDomainID(domainID);
				entryPoint.setDesignNr(designNumber);
				entryPoint.setUserClass(userClass);
				entryPoint.setUserID(userID);
				entryPoint.setCreateSession(CEntryPoint.CREATE_SESSION_YES);
				entryPoint.setAuthenticationMode(CEntryPoint.AUTHENTICATION_MODE_LOGINPASS);
				entryPoint.setLogin(login);
				entryPoint.setPassword(password);
				entryPoint.setEntriesAllowed(CEntryPointFactory.MAX_ENTRYPOINT_ENTRY_LIMIT);
				entryPoint.setMultiProperties(entryPointParams);
				entryPoint.setRedirectURL("???");
//        entryPoint.setState(CStateMachineController.ST_WAIT_FOR_LOGIN);

				return entryPoint;
		}

		public CEntryPoint createEntryPointNoAuth(String userID, String userClass, String entryPointType,
																							Integer designNumber, String domainID, MultiMap entryPointParams)
		{
				// TODO: create EntryPoint by means CEntryPointFactory

		// Integer nID = CSequence.nextValue(CFEntryPoint.ID_SEQUENCE);
		Long nID = System.currentTimeMillis() & 0x7FFFFFFFL;

		String sKey = CEntryPoint.md5_digest("" + String.valueOf(nID));
		CEntryPoint entryPoint= new CEntryPoint(nID, sKey);

				entryPoint.setDomainID(domainID);
				entryPoint.setCreateSession(CEntryPoint.CREATE_SESSION_YES);
				entryPoint.setAuthenticationMode(CEntryPoint.AUTHENTICATION_MODE_NONE);
				entryPoint.setUserID(null==userID ? CEntryPoint.USER_ID_COMMON : userID);
				entryPoint.setUserClass(null==userClass ? CEntryPoint.USER_CLASS_ENTRY_POINT_APPLICATION : userClass);
				entryPoint.setDesignNr(designNumber);
				entryPoint.setRedirectURL("???");
				entryPoint.setEntriesAllowed(CEntryPointFactory.SINGLE_ENTRYPOINT_ENTRY_LIMIT);
				entryPoint.setMultiProperties(entryPointParams);
//        entryPoint.setState(CStateMachineController.ST_WAIT_FOR_LOGIN);

				return entryPoint;
		}


		protected static String generatePassword()
		{
				return CStringUtils.md5_digest(String.valueOf(System.currentTimeMillis())).substring(0, 8);
		}

}
