package hireright.applications.permissions_api.rest.serialization;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-16  HRG-330191 initial version
 */

import hireright.applications.permissions_api.model.CErrorResource;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.server.ResponseStatusException;

import javax.servlet.http.HttpServletRequest;
import java.util.Iterator;
import java.util.Optional;

@RestControllerAdvice
public class CApiExceptionHandler
{
	@ExceptionHandler(ResponseStatusException.class)
	public ResponseEntity<CErrorResource> handleStatus(ResponseStatusException e,
		WebRequest request)
	{
		CErrorResource.Builder error = new CErrorResource.Builder();
		error.error(e.getMessage(), e.getReason());

		return ResponseEntity.status(e.getStatus().value()).body(error.build());
	}

	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<CErrorResource> handleBadRequest(RuntimeException e, WebRequest request)
	{
		CErrorResource.Builder error = new CErrorResource.Builder();
		error.error("Bad Request", e.getMessage());

		return new ResponseEntity<>(error.build(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<CErrorResource> handleRuntimeException(RuntimeException e,
		WebRequest request)
	{
		Throwable cause = Optional.ofNullable(e.getCause()).orElse(e);

		if(cause == e)
		{
			return handleServerException(cause, request);
		}

		if(cause instanceof ResponseStatusException)
		{
			return handleStatus((ResponseStatusException) cause, request);
		}
		else if(cause instanceof IllegalArgumentException)
		{
			return handleBadRequest((RuntimeException) cause, request);
		}
		else if(cause instanceof RuntimeException)
		{
			return handleRuntimeException((RuntimeException) cause, request);
		}

		return handleServerException(cause, request);
	}

	@ExceptionHandler(Throwable.class)
	public ResponseEntity<CErrorResource> handleServerException(Throwable e, WebRequest request)
	{
		CProperties parameters = getRequestParameters(request);

		long lLogID = CTraceLog.error(e, this.getClass().getName(), parameters);

		CErrorResource.Builder error = new CErrorResource.Builder();
		error.error("Unexpected server error: " + lLogID);

		return new ResponseEntity<>(error.build(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private CProperties getRequestParameters(WebRequest request)
	{
		CProperties parameters = new CProperties();

		try
		{
			Iterator<String> parameterNames = request.getParameterNames();
			while(parameterNames.hasNext() && !Thread.currentThread().isInterrupted())
			{
				String sParameter = parameterNames.next();
				parameters.setProperty(sParameter, request.getParameter(sParameter));
			}

			HttpServletRequest servletRequest = ((ServletWebRequest) request).getRequest();

			String sQueryString = servletRequest.getQueryString();

			parameters.setProperty("url",
				servletRequest.getRequestURL() + (!CStringUtils.isEmpty(sQueryString) ?
					"?" + sQueryString :
					""));
		}
		catch(Exception ignored)
		{
			// nothing to do
		}

		return parameters;
	}
}
