package com.hireright.sourceintelligence;

import com.hireright.sourceintelligence.constants.ApplicationConstants;
import com.hireright.sourceintelligence.exception.GlobalApiExceptionHandler;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;


@SpringBootApplication
@EnableWebMvc
@EnableRetry(proxyTargetClass=true)
@Import(GlobalApiExceptionHandler.class)
@OpenAPIDefinition(info = @Info(title = ApplicationConstants.TITLE,
        version = ApplicationConstants.VERSION,
        description = ApplicationConstants.DESCRIPTION))
@EnableScheduling
public class SourceIntelligenceServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(SourceIntelligenceServiceApplication.class, args);
    }


}


