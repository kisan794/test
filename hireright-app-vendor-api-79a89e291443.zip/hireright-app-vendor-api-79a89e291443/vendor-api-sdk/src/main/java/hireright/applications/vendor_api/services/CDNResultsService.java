package hireright.applications.vendor_api.services;
/*
 *
 * Copyright 2001-2018 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	T.Prikk		2018-10-04	HIVPE-40534: Created to support updating consent form that resides on "host" instance (CDN)
 *	M.Kuznetsov	2025-10-29	HRG-345322. Openjdk21-migration
 */
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMethod;

import hireright.components.domain.dialects.vendor_api.BasicResponse;

public class CDNResultsService {
    public static final String VAR_DOCUMENT_REF = "documentRef";

    public static final String PARAM_BADGE_NUMBER = "badgeNumber";
    public static final String PARAM_OPERATOR_NAME = "operatorName";
    public static final String PARAM_CANADA_POST_ID = "canadaPostID";

    public static final String PATH_CONSENT_DOCUMENT = "/cdn/consents/{" + VAR_DOCUMENT_REF + "}";

    public enum EMethod implements IMethod {
        UPDATE_CONSENT_DOCUMENT(PATH_CONSENT_DOCUMENT, RequestMethod.POST, MultiValueMap.class, BasicResponse.class);

        private final String path;
        private final RequestMethod requestMethod;
        private final Class<?> requestBodyClass;
        private final Class<?> responseBodyClass;

        EMethod(String sPath,
                RequestMethod requestMethod,
                Class<?> requestBodyClass,
                Class<?> responseBodyClass) {
            this.path = sPath;
            this.requestMethod = requestMethod;
            this.requestBodyClass = requestBodyClass;
            this.responseBodyClass = responseBodyClass;
        }

        public String getPath() {
            return this.path;
        }

        public RequestMethod getRequestMethod() {
            return this.requestMethod;
        }

        public Class<?> getRequestBodyClass() {
            return this.requestBodyClass;
        }

        public Class<?> getResponseBodyClass() {
            return this.responseBodyClass;
        }

        public boolean isValidRequest(Object request) {
            return true;
        }
    }
}
