package com.hireright.sourceintelligence.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Document(collection = "vendors")
public class Vendors {
    @Id
    private String id;
    private int providerId;
    private String organizationType;
    private String vendor;
    private String website;
    private boolean cevApproved;
    private boolean isBranchCodeEligible;
    private String location;
}
