package com.hireright.sourceintelligence.api.v1;

import static com.hireright.sourceintelligence.api.ApiConstants.HON;
import static com.hireright.sourceintelligence.api.ApiConstants.ResponseHeaders.X_SOURCE_INTELLIGENCE_TOTAL_COUNT;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.constants.ErrorConstants.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.*;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowInvalidRequest;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.dto.timezone.DropDownDTO;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.service.SearchService;

import java.time.Instant;
import java.util.*;

import com.hireright.sourceintelligence.service.SmartSearchService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.constraints.NotNull;

/**
 * Controller for Search operations on SourceOrganization Document
 */

@RestController
@RequiredArgsConstructor
@Validated
@Slf4j
@CrossOrigin
public class SearchApiController implements SearchApi {

    private final SearchService searchService;
    private final SmartSearchService smartSearchService;

    private static final String ORGANIZATION_TYPE_IN_SEARCH = "Organization type in search :";
    private static final String AUTO_COMPLETE_SEARCH_KEY = "autocomplete search keyword:";

    public void validateSearchKey(String searchKey) {
        if (!StringUtils.hasText(searchKey)) {
            logAndThrowInvalidRequest(SEARCH_TEXT_MISSING, null);
        }
    }

    @Override
    public ResponseEntity<List<AutocompleteSearchDTO>> autocompleteFilters(String keyword, OrganizationType organizationType, SourceOrganizationStatus status, Boolean isRAM, Map<String, String> searchFilter) {

        log.info("Drop down starts: {}", Instant.now());
        validateSearchKey(keyword);
        log.info("Input details: keyword: {},type: {},status: {},searchFilter: {}", keyword, organizationType, status, searchFilter);
        List<AutocompleteSearchDTO> result;
        if (isRAM == null || Boolean.FALSE.equals(isRAM)) {
            result = smartSearchService.getDropDownList(keyword, organizationType, Boolean.FALSE, searchFilter);
        } else {
            result = smartSearchService.getDropDownListForRAM(keyword, organizationType, isRAM, searchFilter);
        }

        log.info("Drop down ends: {}", Instant.now());
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<SearchResponseDTO> sourceOrganizationsByFilters(SearchFilter searchFilter) {

        if (searchFilter == null) {
            searchFilter = new SearchFilter();
        }
        searchFilter.setOrganizationType(searchFilter.getOrganizationType());
        if (StringUtils.hasText(searchFilter.getSearchKey())) {
            if (searchFilter.getSearchKey().contains(HON_EMPLOYMENT_PREFIX) || searchFilter.getSearchKey().contains(HON_EDUCATION_PREFIX)) {
                searchFilter.setSearchField(HON);
            } else {
                searchFilter.setSearchField(SEARCH_ORG);
            }
            searchFilter.setSearchKey(searchFilter.getSearchKey().toLowerCase());
        }
        SearchResponseDTO result = searchService.getSourcesByFilters(searchFilter, searchFilter.getOrder(), searchFilter.getSort(), searchFilter.getStartPage(), searchFilter.getPageSize());
        var responseHeaders = new HttpHeaders();
        responseHeaders.set(X_SOURCE_INTELLIGENCE_TOTAL_COUNT, Long.toString(result.getTotalItems()));
        return new ResponseEntity<>(result, responseHeaders, HttpStatus.OK);
    }

    public void validateSearchFilters(List<SearchFilter> searchFilters) {
        if (searchFilters.isEmpty()) {
            logAndThrowInvalidRequest(SEARCH_TEXT_MISSING, null);
        }
    }

    @Override
    public ResponseEntity<List<SourceOrganizationDTO>> autocompleteSourceSuggestionForPossibleDuplicates(String keyword, OrganizationType organizationType) {

        log.info("autocompleteSourceSuggestionForPossibleDuplicates: " + AUTO_COMPLETE_SEARCH_KEY + "{}" + ORGANIZATION_TYPE_IN_SEARCH + "{}", keyword, organizationType);
        validateSearchKey(keyword);
        SearchResponseDTO result = searchService.getAutocompletedSuggestionForPossibleDuplicates(keyword, organizationType);
        return new ResponseEntity<>(result.getSourceList(), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<SearchFilter> getFiltersForSourceOrganizations(String organizationName, String hon) {
        SearchFilter result = searchService.getFiltersForSourceOrganizations();
        var responseHeaders = new HttpHeaders();
        return new ResponseEntity<>(result, responseHeaders, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<SearchResponseDTO> getSourceListBySmartSearch(@NotNull String type, SmartSearchDTO smartSearchDTO) {
        //start time
        log.info("Smart search controller starts: {}, request: {}", Instant.now(), smartSearchDTO);
        if (smartSearchDTO.getOrganizationType().toUpperCase().equals(OrganizationType.EDUCATION.getType())) {
            smartSearchDTO.setOrganizationType(OrganizationType.EDUCATION.getType());
        } else {
            smartSearchDTO.setOrganizationType(OrganizationType.EMPLOYMENT.getType());
        }
        if (smartSearchDTO.getIsDropDownSelected() == null) {
            smartSearchDTO.setIsDropDownSelected(false);
        }
        SearchResponseDTO result = smartSearchService.getSourceListBySearch(smartSearchDTO);
        var responseHeaders = new HttpHeaders();
        //end time
        if(smartSearchDTO.getFromSubRequest()){
            log.info("Smart search controller ends: {}, response: {}", Instant.now(), result);
        }else{
            log.info("Smart search controller ends: {}, response size: {}", Instant.now(), result.getSearchList().size());
        }
        return new ResponseEntity<>(result, responseHeaders, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<List<DropDownDTO>> getRegionList() {
        List<DropDownDTO> result = searchService.getRegionList();
        var responseHeaders = new HttpHeaders();
        return new ResponseEntity<>(result, responseHeaders, HttpStatus.OK);
    }


}