/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-08-14	Created
 */
package hireright.applications.vendor_api.exchange.handler.objects;

public class COrderServiceEntityExchangeContext<TransferType extends CEntityExchangeDTO> extends COrderEntityExchangeContext<TransferType>
{
	private Long m_orderServiceID;

	public Long getOrderServiceID()
	{
		return m_orderServiceID;
	}

	public void setOrderServiceID(Long orderServiceID)
	{
		this.m_orderServiceID = orderServiceID;
	}
}
