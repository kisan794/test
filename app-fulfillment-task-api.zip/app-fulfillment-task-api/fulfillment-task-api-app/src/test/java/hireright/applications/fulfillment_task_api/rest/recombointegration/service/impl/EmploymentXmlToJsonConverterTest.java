package hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl;

import hireright.applications.fulfillment_task_api.rest.recombointegration.exception.XmlTransformationException;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ScreeningType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for EmploymentXmlToJsonConverter
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@DisplayName("EmploymentXmlToJsonConverter Tests")
class EmploymentXmlToJsonConverterTest {

    private EmploymentXmlToJsonConverter converter;

    @BeforeEach
    void setUp() {
        converter = new EmploymentXmlToJsonConverter();
    }

    @Test
    @DisplayName("Should return EMPLOYMENT screening type")
    void testGetType() {
        // When
        ScreeningType type = converter.getType();

        // Then
        assertEquals(ScreeningType.EMPLOYMENT, type);
    }

    @Test
    @DisplayName("Should throw exception when XML is null")
    void testConvertNullXml() {
        // When & Then
        XmlTransformationException exception = assertThrows(
                XmlTransformationException.class,
                () -> converter.convert(null)
        );

        assertEquals("XML_EMPTY", exception.getErrorCode());
        assertTrue(exception.getMessage().contains("XML content cannot be null or empty"));
    }

    @Test
    @DisplayName("Should throw exception when XML is empty")
    void testConvertEmptyXml() {
        // When & Then
        XmlTransformationException exception = assertThrows(
                XmlTransformationException.class,
                () -> converter.convert("")
        );

        assertEquals("XML_EMPTY", exception.getErrorCode());
    }

    @Test
    @DisplayName("Should throw exception when XML is whitespace only")
    void testConvertWhitespaceXml() {
        // When & Then
        XmlTransformationException exception = assertThrows(
                XmlTransformationException.class,
                () -> converter.convert("   ")
        );

        assertEquals("XML_EMPTY", exception.getErrorCode());
    }

    @Test
    @DisplayName("Should convert valid employment XML to JSON")
    void testConvertValidXml() {
        // Given
        String xml = """
                <EmploymentScreeningList>
                    <EmploymentScreening>
                        <Screening>
                            <Type>employment</Type>
                            <ProducerReferenceId>EMP-001</ProducerReferenceId>
                            <EmploymentVerificationReport>
                                <EmploymentResult>
                                    <Employer>
                                        <OrganizationName>Acme Corporation</OrganizationName>
                                        <PostalAddress>
                                            <Municipality>San Francisco</Municipality>
                                            <Region>CA</Region>
                                            <CountryCode>US</CountryCode>
                                        </PostalAddress>
                                    </Employer>
                                </EmploymentResult>
                            </EmploymentVerificationReport>
                        </Screening>
                    </EmploymentScreening>
                </EmploymentScreeningList>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.contains("NSCH"));
        assertTrue(json.contains("employment"));
    }

    @Test
    @DisplayName("Should throw exception for invalid XML")
    void testConvertInvalidXml() {
        // Given
        String invalidXml = "<invalid><unclosed>";

        // When & Then
        XmlTransformationException exception = assertThrows(
                XmlTransformationException.class,
                () -> converter.convert(invalidXml)
        );

        assertEquals("JSON_CONVERSION_FAILED", exception.getErrorCode());
    }

    @Test
    @DisplayName("Should convert XML with single employment result")
    void testConvertSingleEmploymentResult() {
        // Given
        String xml = """
                <EmploymentScreeningList>
                    <EmploymentScreening>
                        <Screening>
                            <Type>employment</Type>
                            <ProducerReferenceId>EMP-001</ProducerReferenceId>
                            <EmploymentVerificationReport>
                                <EmploymentResult>
                                    <Employer>
                                        <OrganizationName>Google</OrganizationName>
                                    </Employer>
                                </EmploymentResult>
                            </EmploymentVerificationReport>
                        </Screening>
                    </EmploymentScreening>
                </EmploymentScreeningList>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.contains("Google"));
    }

    @Test
    @DisplayName("Should convert XML with multiple employment results")
    void testConvertMultipleEmploymentResults() {
        // Given
        String xml = """
                <EmploymentScreeningList>
                    <EmploymentScreening>
                        <Screening>
                            <Type>employment</Type>
                            <ProducerReferenceId>EMP-001</ProducerReferenceId>
                            <EmploymentVerificationReport>
                                <EmploymentResult>
                                    <Employer>
                                        <OrganizationName>Google</OrganizationName>
                                    </Employer>
                                </EmploymentResult>
                                <EmploymentResult>
                                    <Employer>
                                        <OrganizationName>Microsoft</OrganizationName>
                                    </Employer>
                                </EmploymentResult>
                            </EmploymentVerificationReport>
                        </Screening>
                    </EmploymentScreening>
                </EmploymentScreeningList>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.contains("Google"));
        assertTrue(json.contains("Microsoft"));
    }

    @Test
    @DisplayName("Should handle XML without EmploymentScreeningList wrapper")
    void testConvertWithoutWrapper() {
        // Given
        String xml = """
                <EmploymentScreening>
                    <Screening>
                        <Type>employment</Type>
                        <ProducerReferenceId>EMP-001</ProducerReferenceId>
                        <EmploymentVerificationReport>
                            <EmploymentResult>
                                <Employer>
                                    <OrganizationName>Amazon</OrganizationName>
                                </Employer>
                            </EmploymentResult>
                        </EmploymentVerificationReport>
                    </Screening>
                </EmploymentScreening>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.contains("Amazon"));
    }

    @Test
    @DisplayName("Should use default type when type is missing")
    void testConvertWithMissingType() {
        // Given
        String xml = """
                <EmploymentScreeningList>
                    <EmploymentScreening>
                        <Screening>
                            <ProducerReferenceId>EMP-001</ProducerReferenceId>
                            <EmploymentVerificationReport>
                                <EmploymentResult>
                                    <Employer>
                                        <OrganizationName>Apple</OrganizationName>
                                    </Employer>
                                </EmploymentResult>
                            </EmploymentVerificationReport>
                        </Screening>
                    </EmploymentScreening>
                </EmploymentScreeningList>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.contains("employment"));
    }

    @Test
    @DisplayName("Should handle XML with special characters")
    void testConvertWithSpecialCharacters() {
        // Given
        String xml = """
                <EmploymentScreeningList>
                    <EmploymentScreening>
                        <Screening>
                            <Type>employment</Type>
                            <ProducerReferenceId>EMP-001</ProducerReferenceId>
                            <EmploymentVerificationReport>
                                <EmploymentResult>
                                    <Employer>
                                        <OrganizationName>Company &amp; Associates</OrganizationName>
                                    </Employer>
                                </EmploymentResult>
                            </EmploymentVerificationReport>
                        </Screening>
                    </EmploymentScreening>
                </EmploymentScreeningList>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.contains("Company"));
    }

    @Test
    @DisplayName("Should handle XML with missing EmploymentResult")
    void testConvertWithMissingEmploymentResult() {
        // Given
        String xml = """
                <EmploymentScreeningList>
                    <EmploymentScreening>
                        <Screening>
                            <Type>employment</Type>
                            <ProducerReferenceId>EMP-001</ProducerReferenceId>
                            <EmploymentVerificationReport>
                            </EmploymentVerificationReport>
                        </Screening>
                    </EmploymentScreening>
                </EmploymentScreeningList>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.contains("EMP-001"));
    }

    @Test
    @DisplayName("Should convert XML with complete employment data including position history")
    void testConvertCompleteEmploymentData() {
        // Given
        String xml = """
                <EmploymentScreeningList>
                    <EmploymentScreening>
                        <Screening>
                            <Type>employment</Type>
                            <ProducerReferenceId>EMP-001</ProducerReferenceId>
                            <EmploymentVerificationReport>
                                <EmploymentResult>
                                    <Employer>
                                        <OrganizationName>Acme Corporation</OrganizationName>
                                        <PostalAddress>
                                            <Municipality>San Francisco</Municipality>
                                            <Region>CA</Region>
                                            <CountryCode>US</CountryCode>
                                        </PostalAddress>
                                    </Employer>
                                    <Position>
                                        <Title>Software Engineer</Title>
                                        <StartDate>2020-01-01</StartDate>
                                        <EndDate>2024-05-31</EndDate>
                                    </Position>
                                </EmploymentResult>
                            </EmploymentVerificationReport>
                        </Screening>
                    </EmploymentScreening>
                </EmploymentScreeningList>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.contains("Acme Corporation"));
        assertTrue(json.contains("San Francisco"));
        assertTrue(json.contains("CA"));
    }

    @Test
    @DisplayName("Should convert XML with compensation information")
    void testConvertWithCompensationInfo() {
        // Given
        String xml = """
                <EmploymentScreeningList>
                    <EmploymentScreening>
                        <Screening>
                            <Type>employment</Type>
                            <ProducerReferenceId>EMP-001</ProducerReferenceId>
                            <EmploymentVerificationReport>
                                <EmploymentResult>
                                    <Employer>
                                        <OrganizationName>Tech Corp</OrganizationName>
                                    </Employer>
                                    <Position>
                                        <Title>Senior Developer</Title>
                                        <Compensation>
                                            <Amount>150000</Amount>
                                            <Currency>USD</Currency>
                                        </Compensation>
                                    </Position>
                                </EmploymentResult>
                            </EmploymentVerificationReport>
                        </Screening>
                    </EmploymentScreening>
                </EmploymentScreeningList>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.contains("Tech Corp"));
        assertTrue(json.contains("Senior Developer"));
    }

    @Test
    @DisplayName("Should handle large XML input")
    void testConvertLargeXml() {
        // Given
        StringBuilder xmlBuilder = new StringBuilder("<EmploymentScreeningList>");
        for (int i = 0; i < 10; i++) {
            xmlBuilder.append("""
                    <EmploymentScreening>
                        <Screening>
                            <Type>employment</Type>
                            <ProducerReferenceId>EMP-%d</ProducerReferenceId>
                            <EmploymentVerificationReport>
                                <EmploymentResult>
                                    <Employer>
                                        <OrganizationName>Company %d</OrganizationName>
                                    </Employer>
                                </EmploymentResult>
                            </EmploymentVerificationReport>
                        </Screening>
                    </EmploymentScreening>
                    """.formatted(i, i));
        }
        xmlBuilder.append("</EmploymentScreeningList>");

        // When
        String json = converter.convert(xmlBuilder.toString());

        // Then
        assertNotNull(json);
        assertTrue(json.length() > 0);
    }

    @Test
    @DisplayName("Should produce valid JSON output")
    void testProducesValidJson() {
        // Given
        String xml = """
                <EmploymentScreeningList>
                    <EmploymentScreening>
                        <Screening>
                            <Type>employment</Type>
                            <ProducerReferenceId>EMP-001</ProducerReferenceId>
                            <EmploymentVerificationReport>
                                <EmploymentResult>
                                    <Employer>
                                        <OrganizationName>Netflix</OrganizationName>
                                    </Employer>
                                </EmploymentResult>
                            </EmploymentVerificationReport>
                        </Screening>
                    </EmploymentScreening>
                </EmploymentScreeningList>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.startsWith("{"));
        assertTrue(json.endsWith("}"));
        assertTrue(json.contains("\"name\""));
        assertTrue(json.contains("\"type\""));
    }

    @Test
    @DisplayName("Should handle XML with employee status information")
    void testConvertWithEmployeeStatus() {
        // Given
        String xml = """
                <EmploymentScreeningList>
                    <EmploymentScreening>
                        <Screening>
                            <Type>employment</Type>
                            <ProducerReferenceId>EMP-001</ProducerReferenceId>
                            <EmploymentVerificationReport>
                                <EmploymentResult>
                                    <Employer>
                                        <OrganizationName>IBM</OrganizationName>
                                    </Employer>
                                    <Position>
                                        <Title>Consultant</Title>
                                        <EmployeeStatus>Active</EmployeeStatus>
                                        <EmployeeStatusCode>VERIFIED</EmployeeStatusCode>
                                    </Position>
                                </EmploymentResult>
                            </EmploymentVerificationReport>
                        </Screening>
                    </EmploymentScreening>
                </EmploymentScreeningList>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.contains("IBM"));
        assertTrue(json.contains("Consultant"));
    }
}

