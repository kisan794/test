/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	msuhhoruki	2017-06-15	Created
 */
package hireright.applications.vendor_api.model;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

import hireright.objects.order3.model.COrderConfiguration;
/*
@XmlType(propOrder={
		"organization",
		"clientReferences",
		"clientContact",
		"personalData",
		"screenings"})
*/
@XmlRootElement(name="ScreeningRequest")
public class CScreeningRequest extends COrderConfiguration
{
	private String context;
	
	@XmlElement(name="Context")
	public String getContext()
	{
		return this.context;
	}
	
	public void setContext(String context)
	{
		this.context = context;
	}
}
