package com.hireright.sourceintelligence.reports.service;

import com.hireright.sourceintelligence.reports.dto.ReportsDTO;

public interface ReportDataService {

    void createData(ReportsDTO reportsDTO);
}
