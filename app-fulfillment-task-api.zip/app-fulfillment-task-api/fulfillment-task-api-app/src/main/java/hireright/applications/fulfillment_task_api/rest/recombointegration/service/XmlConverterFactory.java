package hireright.applications.fulfillment_task_api.rest.recombointegration.service;

import hireright.applications.fulfillment_task_api.rest.recombointegration.exception.XmlTransformationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Factory for creating and managing XML to JSON converters.
 * Implements the Factory Pattern to provide the appropriate converter based on screening type.
 *
 * @author Keshav Ladha
 */
@Component
@Slf4j
public class XmlConverterFactory {

    private final Map<ScreeningType, XmlToJsonConverter> converters;

    @Autowired
    public XmlConverterFactory(List<XmlToJsonConverter> converterList) {
        this.converters = new EnumMap<>(ScreeningType.class);

        // Automatically register all converters based on their getType() method
        for (XmlToJsonConverter converter : converterList) {
            ScreeningType type = converter.getType();

            if (converters.containsKey(type)) {
                log.warn("Duplicate converter found for type: {}. Using: {}",
                        type, converter.getClass().getSimpleName());
            }

            converters.put(type, converter);
            log.info("Registered converter: {} for type: {}",
                    converter.getClass().getSimpleName(), type);
        }

        log.info("XmlConverterFactory initialized with {} converter types using automatic Spring DI",
                converters.size());
        log.info("Supported types: {}", getSupportedTypesString());
    }

    /**
     * Gets the appropriate converter for the specified type string.
     *
     * @param typeString the screening type as string (education, employment, etc.)
     * @return the XML to JSON converter for the specified type
     * @throws XmlTransformationException if the type is not supported
     */
    public XmlToJsonConverter getConverter(String typeString) {
        log.debug("Getting converter for type string: {}", typeString);

        try {
            ScreeningType type = ScreeningType.fromValue(typeString);
            return getConverter(type);
        } catch (IllegalArgumentException e) {
            log.error("Invalid screening type: {}", typeString);
            throw new XmlTransformationException(
                    "UNSUPPORTED_TYPE",
                    e.getMessage(),
                    e
            );
        }
    }

    /**
     * Gets the appropriate converter for the specified type enum.
     *
     * @param type the screening type enum
     * @return the XML to JSON converter for the specified type
     * @throws XmlTransformationException if the type is not supported
     */
    public XmlToJsonConverter getConverter(ScreeningType type) {
        log.debug("Getting converter for type: {}", type);

        XmlToJsonConverter converter = converters.get(type);

        if (converter == null) {
            String errorMessage = String.format(
                    "No converter registered for screening type: '%s'. Supported types are: %s",
                    type,
                    getSupportedTypesString()
            );
            log.error(errorMessage);
            throw new XmlTransformationException(
                    "UNSUPPORTED_TYPE",
                    errorMessage,
                    null
            );
        }

        log.debug("Found converter: {}", converter.getClass().getSimpleName());
        return converter;
    }

    /**
     * Gets all supported converter types as a comma-separated string.
     *
     * @return supported types as string
     */
    public String getSupportedTypesString() {
        return converters.keySet().stream()
                .map(ScreeningType::getValue)
                .collect(Collectors.joining(", "));
    }
}