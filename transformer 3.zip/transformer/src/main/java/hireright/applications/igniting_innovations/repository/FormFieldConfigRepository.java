package hireright.applications.igniting_innovations.repository;

import hireright.applications.igniting_innovations.document.FormFieldConfig;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * MongoDB repository for FormFieldConfig documents.
 * Provides database operations for form field configurations.
 *
 * @author Generated
 * @version 1.0
 */
@Repository
public interface FormFieldConfigRepository extends MongoRepository<FormFieldConfig, String> {

    /**
     * Find configuration by field key.
     */
    Optional<FormFieldConfig> findByFieldKey(String fieldKey);

    /**
     * Check if field key exists.
     */
    boolean existsByFieldKey(String fieldKey);
}

