package hireright.applications.fulfillment_task_api.rest.recombointegration.config.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.validation.ErrorResponse;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for ApiKeyFilter
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("ApiKeyFilter Tests")
class ApiKeyFilterTest {

    @Mock
    private FilterChain filterChain;

    private ApiKeyFilter filter;
    private ObjectMapper objectMapper;
    private MockHttpServletRequest request;
    private MockHttpServletResponse response;

    private static final String VALID_API_KEY = "test-api-key-12345";
    private static final String API_KEY_HEADER = "x-api-key";

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
        filter = new ApiKeyFilter(objectMapper);
        ReflectionTestUtils.setField(filter, "apiKey", VALID_API_KEY);

        request = new MockHttpServletRequest();
        response = new MockHttpServletResponse();
    }

    @Test
    @DisplayName("Should allow request with valid API key")
    void testValidApiKey() throws ServletException, IOException {
        // Given
        request.setRequestURI("/fulfillment_task_api/v1/screening");
        request.addHeader(API_KEY_HEADER, VALID_API_KEY);

        // When
        filter.doFilterInternal(request, response, filterChain);

        // Then
        verify(filterChain, times(1)).doFilter(request, response);
        assertEquals(200, response.getStatus());
    }

    @Test
    @DisplayName("Should reject request with invalid API key")
    void testInvalidApiKey() throws ServletException, IOException {
        // Given
        request.setRequestURI("/fulfillment_task_api/v1/screening");
        request.addHeader(API_KEY_HEADER, "invalid-api-key");

        // When
        filter.doFilterInternal(request, response, filterChain);

        // Then
        verify(filterChain, never()).doFilter(request, response);
        assertEquals(401, response.getStatus());
        assertEquals(MediaType.APPLICATION_JSON_VALUE, response.getContentType());

        String responseBody = response.getContentAsString();
        assertNotNull(responseBody);
        assertTrue(responseBody.contains("Error.Authentication"));
        assertTrue(responseBody.contains("Invalid or missing API key"));
    }

    @Test
    @DisplayName("Should reject request with missing API key")
    void testMissingApiKey() throws ServletException, IOException {
        // Given
        request.setRequestURI("/fulfillment_task_api/v1/screening");
        // No API key header added

        // When
        filter.doFilterInternal(request, response, filterChain);

        // Then
        verify(filterChain, never()).doFilter(request, response);
        assertEquals(401, response.getStatus());
        assertEquals(MediaType.APPLICATION_JSON_VALUE, response.getContentType());

        String responseBody = response.getContentAsString();
        assertNotNull(responseBody);
        assertTrue(responseBody.contains("Error.Authentication"));
    }

    @Test
    @DisplayName("Should skip authentication for actuator endpoints")
    void testSkipAuthenticationForActuator() throws ServletException, IOException {
        // Given
        request.setRequestURI("/fulfillment_task_api/actuator/health");
        // No API key header

        // When
        filter.doFilterInternal(request, response, filterChain);

        // Then
        verify(filterChain, times(1)).doFilter(request, response);
        assertEquals(200, response.getStatus());
    }

    @Test
    @DisplayName("Should skip authentication for health endpoints")
    void testSkipAuthenticationForHealth() throws ServletException, IOException {
        // Given
        request.setRequestURI("/fulfillment_task_api/health");
        // No API key header

        // When
        filter.doFilterInternal(request, response, filterChain);

        // Then
        verify(filterChain, times(1)).doFilter(request, response);
        assertEquals(200, response.getStatus());
    }

    @Test
    @DisplayName("Should skip authentication for root path")
    void testSkipAuthenticationForRootPath() throws ServletException, IOException {
        // Given
        request.setRequestURI("/");
        // No API key header

        // When
        filter.doFilterInternal(request, response, filterChain);

        // Then
        verify(filterChain, times(1)).doFilter(request, response);
        assertEquals(200, response.getStatus());
    }

    @Test
    @DisplayName("Should skip authentication for swagger endpoints")
    void testSkipAuthenticationForSwagger() throws ServletException, IOException {
        // Given
        request.setRequestURI("/swagger-ui/index.html");
        // No API key header

        // When
        filter.doFilterInternal(request, response, filterChain);

        // Then
        verify(filterChain, times(1)).doFilter(request, response);
        assertEquals(200, response.getStatus());
    }

    @Test
    @DisplayName("Should skip authentication for api-docs endpoints")
    void testSkipAuthenticationForApiDocs() throws ServletException, IOException {
        // Given
        request.setRequestURI("/v3/api-docs");
        // No API key header

        // When
        filter.doFilterInternal(request, response, filterChain);

        // Then
        verify(filterChain, times(1)).doFilter(request, response);
        assertEquals(200, response.getStatus());
    }

    @Test
    @DisplayName("Should skip authentication for fulfillment_task_api api-docs")
    void testSkipAuthenticationForFulfillmentApiDocs() throws ServletException, IOException {
        // Given
        request.setRequestURI("/fulfillment_task_api/api-docs");
        // No API key header

        // When
        filter.doFilterInternal(request, response, filterChain);

        // Then
        verify(filterChain, times(1)).doFilter(request, response);
        assertEquals(200, response.getStatus());
    }

    @Test
    @DisplayName("Should skip authentication for fulfillment_task_api swagger-ui")
    void testSkipAuthenticationForFulfillmentSwaggerUi() throws ServletException, IOException {
        // Given
        request.setRequestURI("/fulfillment_task_api/swagger-ui/index.html");
        // No API key header

        // When
        filter.doFilterInternal(request, response, filterChain);

        // Then
        verify(filterChain, times(1)).doFilter(request, response);
        assertEquals(200, response.getStatus());
    }

    @Test
    @DisplayName("Should return error response with correct structure")
    void testErrorResponseStructure() throws ServletException, IOException {
        // Given
        request.setRequestURI("/fulfillment_task_api/v1/screening");
        request.addHeader(API_KEY_HEADER, "wrong-key");

        // When
        filter.doFilterInternal(request, response, filterChain);

        // Then
        String responseBody = response.getContentAsString();
        ErrorResponse errorResponse = objectMapper.readValue(responseBody, ErrorResponse.class);

        assertNotNull(errorResponse);
        assertEquals("1.0", errorResponse.getSpecversion());
        assertEquals("Error.Authentication", errorResponse.getType());
        assertEquals("hrg:hre:fulfillment", errorResponse.getSource());
        assertEquals("application/json", errorResponse.getDatacontenttype());
        assertNotNull(errorResponse.getId());
        assertNotNull(errorResponse.getTime());
        assertNotNull(errorResponse.getData());
        assertEquals(401, errorResponse.getData().getStatus());
        assertEquals("Unauthorized", errorResponse.getData().getError());
        assertEquals("AUTH001", errorResponse.getData().getErrorCode());
        assertEquals("API key is missing or invalid", errorResponse.getData().getMessage());
        assertEquals("Invalid or missing API key", errorResponse.getData().getReason());
    }

    @Test
    @DisplayName("Should handle empty API key header")
    void testEmptyApiKeyHeader() throws ServletException, IOException {
        // Given
        request.setRequestURI("/fulfillment_task_api/v1/screening");
        request.addHeader(API_KEY_HEADER, "");

        // When
        filter.doFilterInternal(request, response, filterChain);

        // Then
        verify(filterChain, never()).doFilter(request, response);
        assertEquals(401, response.getStatus());
    }

    @Test
    @DisplayName("Should handle API key with whitespace")
    void testApiKeyWithWhitespace() throws ServletException, IOException {
        // Given
        request.setRequestURI("/fulfillment_task_api/v1/screening");
        request.addHeader(API_KEY_HEADER, "  " + VALID_API_KEY + "  ");

        // When
        filter.doFilterInternal(request, response, filterChain);

        // Then
        verify(filterChain, never()).doFilter(request, response);
        assertEquals(401, response.getStatus());
    }

    @Test
    @DisplayName("Should be case-sensitive for API key")
    void testApiKeyCaseSensitive() throws ServletException, IOException {
        // Given
        request.setRequestURI("/fulfillment_task_api/v1/screening");
        request.addHeader(API_KEY_HEADER, VALID_API_KEY.toUpperCase());

        // When
        filter.doFilterInternal(request, response, filterChain);

        // Then
        verify(filterChain, never()).doFilter(request, response);
        assertEquals(401, response.getStatus());
    }

    @Test
    @DisplayName("Should handle multiple API key headers")
    void testMultipleApiKeyHeaders() throws ServletException, IOException {
        // Given
        request.setRequestURI("/fulfillment_task_api/v1/screening");
        request.addHeader(API_KEY_HEADER, "wrong-key");
        request.addHeader(API_KEY_HEADER, VALID_API_KEY);

        // When
        filter.doFilterInternal(request, response, filterChain);

        // Then
        // getHeader returns the first header value
        verify(filterChain, never()).doFilter(request, response);
        assertEquals(401, response.getStatus());
    }

    @Test
    @DisplayName("Should allow request with valid API key for different paths")
    void testValidApiKeyForDifferentPaths() throws ServletException, IOException {
        // Test multiple paths
        String[] paths = {
                "/fulfillment_task_api/v1/screening",
                "/fulfillment_task_api/v1/results",
                "/fulfillment_task_api/v2/screening",
                "/api/test"
        };

        for (String path : paths) {
            // Given
            request = new MockHttpServletRequest();
            response = new MockHttpServletResponse();
            request.setRequestURI(path);
            request.addHeader(API_KEY_HEADER, VALID_API_KEY);

            // When
            filter.doFilterInternal(request, response, filterChain);

            // Then
            assertEquals(200, response.getStatus(), "Failed for path: " + path);
        }

        verify(filterChain, times(paths.length)).doFilter(any(), any());
    }
}

