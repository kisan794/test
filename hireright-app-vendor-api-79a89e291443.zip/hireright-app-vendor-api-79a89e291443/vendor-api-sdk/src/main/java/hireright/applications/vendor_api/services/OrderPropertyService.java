package hireright.applications.vendor_api.services;
/*
 *
 * Copyright 2001-2018 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2018-03-09	Created
 *	M.Kuznetsov	2025-10-29	HRG-345322. Openjdk21-migration
 */
import org.springframework.web.bind.annotation.RequestMethod;

import hireright.components.domain.dialects.vendor_api.BasicResponse;
import hireright.components.domain.dialects.vendor_api.NameValue;

public class OrderPropertyService {
    public static final String VAR_ORDER_REF = "orderRef";

    public static final String PATH_UPDATE = "/orders/{" + VAR_ORDER_REF + "}/properties";

    public enum EMethod implements IMethod {
        UPDATE(PATH_UPDATE, RequestMethod.PUT, NameValue.class, BasicResponse.class);

        private final String path;
        private final RequestMethod requestMethod;
        private final Class<?> requestBodyClass;
        private final Class<?> responseBodyClass;

        EMethod(String sPath,
                RequestMethod requestMethod,
                Class<?> requestBodyClass,
                Class<?> responseBodyClass) {
            this.path = sPath;
            this.requestMethod = requestMethod;
            this.requestBodyClass = requestBodyClass;
            this.responseBodyClass = responseBodyClass;
        }

        @Override
        public String getPath() {
            return this.path;
        }

        @Override
        public RequestMethod getRequestMethod() {
            return this.requestMethod;
        }

        @Override
        public Class<?> getRequestBodyClass() {
            return this.requestBodyClass;
        }

        @Override
        public Class<?> getResponseBodyClass() {
            return this.responseBodyClass;
        }

        @Override
        public boolean isValidRequest(Object request) {
            return true;
        }
    }
}
