/*
 * @(#)$RCSfile: CStateMachineController.java,v $ $Revision: 1.2 $ $Date: 2014/07/28 14:57:11 $ $Author: aputintsev $ 
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/util/CStateMachineController.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *     $Log: CStateMachineController.java,v $
 *     Revision 1.2  2014/07/28 14:57:11  aputintsev
 *     forked from production version - projects_src/applications/accesspoint
 *
 *     Revision 1.1.2.1.2.1  2009/08/19 07:18:08  asolntsev
 *     Bugfixing and polishing
 *
 *     Revision 1.1.2.1  2009/08/13 13:24:24  asolntsev
 *     Created by St.Petersburg team
 *
 *     Revision 1.3  2009/08/06 13:21:52  banton
 *     Phase 1.1 Edition
 *
 *     Revision 1.2  2009/08/06 09:37:55  banton
 *     Added simple Finite State Machine support. Tested only for memory storage
 *
 *     Revision 1.1.1.1  2009/07/31 11:24:26  banton
 *     Task 39986 1.1
 *
 */
package hireright.applications.accesspoint.util;

import hireright.objects.utilities.CEntryPoint;

import java.util.Timer;

/**
 *
 * @author banton
 */
public class CStateMachineController
{
		protected  boolean useMealyFSM = false;

		protected static CStateMachineController instance;

		/**
		 * FIXME	Do we really need this field? It seems it's not used.
		 */
		private Timer m_timer;

		protected Timer getTimer()
		{
			return m_timer;
		}

		//
		//  States constants
		//
		static final int ST_BEGIN          = 0;
		static final int ST_WAIT_FOR_LOGIN = 0;
		static final int ST_ACTIVE         = 1;
		static final int ST_DEACTIVAITED   = 2;
		static final int ST_CLOSED         = 3;
		static final int ST_EXPIRED        = 4;
		static final int ST_END            = 5;
		static final int ST_MAX            = 4;

		//
		//   Events constants
		//
		public static final int EV_CLOSE               = 0;
		public static final int EV_EXPIRE              = 1;
		public static final int EV_LIMIT_OF_ENTRIES    = 2;
		public static final int EV_LIMIT_OF_FAILUREES  = 3;
		public static final int EV_LOGIN_SUCCESS       = 4;
		public static final int EV_ACTIVATE            = 5;
		public static final int EV_DEACTIVATE          = 6;
		public static final int EV_TIMEOUT             = 7;
		public static final int EV_MAX                 = 7;
		public static final int INVALID_EVENT          = -1;


		/** Transition table for  */
		static Action[][] MEALY_FSM_STATE_TABLE =
				{
						//  CLOSE  EXPIRE   LOF_ENTRIES   LOF_FAILUREES   LOGIN_SUCCESS  ACTIVATE      DEACTIVATE     TIMEOUT
						{   null,    null,       null,        null,          null,           null,        null,        null},    // WAIT_FOR_LOGIN
						{   null,    null,       null,        null,          null,           null,        null,        null},    // ACTIVE
						{   null,    null,       null,        null,          null,           null,        null,        null},    // DEACTIVAITED
						{   null,    null,       null,        null,          null,           null,        null,        null},    // CLOSED
						{   null,    null,       null,        null,          null,           null,        null,        null}    // EXPIRED
				};


		/** Transition table */
		static int[][] MOOR_FSM_STATE_TABLE =
				{
						//  CLOSE  EXPIRE LOF_ENTRIES LOF_FAILUREES LOGIN_SUCCESS  ACTIVATE  DEACTIVATE   TIMEOUT
						{   -1,       -1,       -1,        -1,       ST_ACTIVE,       -1,        -1,        -1},   // WAIT_FOR_LOGIN
						{ST_CLOSED, ST_CLOSED, ST_CLOSED, ST_CLOSED,    -1,           -1,        -1,        -1},   // ACTIVE
						{   -1,       -1,       -1,        -1,          -1,           -1,        -1,        -1},   // DEACTIVAITED
						{   -1,       -1,       -1,        -1,          -1,           -1,        -1,        -1},   // CLOSED
						{   -1,       -1,       -1,        -1,          -1,           -1,        -1,        -1}    // EXPIRED
				};


		static Action[] MOOR_FSM_STATE_ACTION_TABLE =
				{
				null,                   // WAIT_FOR_LOGIN
				null,                   // ACTIVE        
				null,                   // DEACTIVAITED  
				new ClosedAction(),     // CLOSED        
				null                    // EXPIRED            
				};


		public CStateMachineController()
		{
				m_timer = new Timer("StateMachinecontroller-Timer");
		}

		/**
		 * EntryPoint
		 * @param entryPoint
		 * @param event
		 * @param entryPointFramework
		 */
		public void processEntryPoint(CEntryPoint entryPoint, int event, IEntryPointFramework entryPointFramework)
		{
		Action action = null;
		int state = -1; // entryPoint.getState();
		CEntryPointWrapper entryPointWrapper = new CEntryPointWrapper(entryPoint);

				// TODO: assert
				if ( (state < 0 || state > ST_MAX)
						|| (event < 0 || event > EV_MAX))
						return;

				if (useMealyFSM)
						{
						action = MEALY_FSM_STATE_TABLE[state][event];
						if (action!=null)
								state=action.doAction(entryPointWrapper, entryPointFramework);
						else
								state=-1;
						}
				else
						{
						state = MOOR_FSM_STATE_TABLE[state][event];
						if (state!=-1)
								action = MOOR_FSM_STATE_ACTION_TABLE[state];

						if (action!=null)
								action.doAction(entryPointWrapper, entryPointFramework);
						}

				if (state!=-1)
						{
//            entryPoint.setState(state);
						if (!entryPointWrapper.isDeleted())
								entryPointFramework.saveEntryPoint(entryPoint);
						}
		}

		public static CStateMachineController getInstance()
		{
				if (instance==null)
						instance = new CStateMachineController();
				return instance;
		}




		static class CEntryPointWrapper
		{
				boolean deleted=false;

				CEntryPoint entryPoint;

				public CEntryPointWrapper(CEntryPoint entryPoint)
				{
						this.entryPoint = entryPoint;
				}


				public boolean isDeleted()
				{
						return deleted;
				}

				public void setDeleted(boolean deleted)
				{
						this.deleted = deleted;
				}

				public CEntryPoint getEntryPoint()
				{
						return entryPoint;
				}

		}

		/**
		 * Abstract class for transition object
		 */
		static abstract class  Action
		{
				/** name of transition (for debugging) */
				String name;

				/** the state of transition to */
				int nextState;


				public Action(String name, int nextState)
				{
						this.name = name;
						this.nextState = nextState;
				}


				/**
				 * Do step action and return next state
				 * @return
				 *      next state
				 */
				abstract int doAction(CEntryPointWrapper entryPointWrapper, IEntryPointFramework entryPointFramework);
		}


}
/**
		 * Action class for state CLOSED
		 */
		class ClosedAction
				extends CStateMachineController.Action
		{

				ClosedAction()
				{
						super("A-CLOSE", CStateMachineController.ST_CLOSED);
				}

				@Override
				int doAction(CStateMachineController.CEntryPointWrapper entryPointWrapper, IEntryPointFramework entryPointFramework)
				{
						entryPointFramework.deleteEntryPoint(entryPointWrapper.getEntryPoint());
						entryPointWrapper.setDeleted(true);
						return this.nextState;
				}
		}
