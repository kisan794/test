package com.hireright.sourceintelligence.service.excel;

import com.hireright.sourceintelligence.api.dto.ParchmentRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.multipart.MultipartFile;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ExcelParserFactoryTest {

    @Mock
    private ExcelParserStrategy<ParchmentRecord> parchmentStrategy;

    @Mock
    private ExcelParserStrategy<?> anotherStrategy;

    private ExcelParserFactory excelParserFactory;

    @BeforeEach
    void setUp() {
        when(parchmentStrategy.getParserType()).thenReturn("parchment");
        when(anotherStrategy.getParserType()).thenReturn("clearinghouse");
    }

    @Test
    void constructor_WithMultipleStrategies_ShouldInitializeSuccessfully() {
        List<ExcelParserStrategy<?>> strategies = Arrays.asList(parchmentStrategy, anotherStrategy);

        excelParserFactory = new ExcelParserFactory(strategies);

        assertNotNull(excelParserFactory);
    }

    @Test
    void getParser_WithValidParserType_ShouldReturnCorrectStrategy() {
        List<ExcelParserStrategy<?>> strategies = Arrays.asList(parchmentStrategy, anotherStrategy);
        excelParserFactory = new ExcelParserFactory(strategies);

        ExcelParserStrategy<ParchmentRecord> result = excelParserFactory.getParser("parchment");

        assertNotNull(result);
        assertSame(parchmentStrategy, result);
    }

    @Test
    void getParser_WithDifferentValidParserType_ShouldReturnCorrectStrategy() {
        List<ExcelParserStrategy<?>> strategies = Arrays.asList(parchmentStrategy, anotherStrategy);
        excelParserFactory = new ExcelParserFactory(strategies);

        ExcelParserStrategy<?> result = excelParserFactory.getParser("clearinghouse");

        assertNotNull(result);
        assertSame(anotherStrategy, result);
    }

    @Test
    void getParser_WithInvalidParserType_ShouldThrowException() {
        List<ExcelParserStrategy<?>> strategies = Arrays.asList(parchmentStrategy, anotherStrategy);
        excelParserFactory = new ExcelParserFactory(strategies);

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> excelParserFactory.getParser("nonexistent"));

        assertTrue(exception.getMessage().contains("No parser strategy found for type: nonexistent"));
        assertTrue(exception.getMessage().contains("Available types:"));
    }

    @Test
    void getParser_WithNullParserType_ShouldReturnNull() {
        List<ExcelParserStrategy<?>> strategies = Arrays.asList(parchmentStrategy, anotherStrategy);
        excelParserFactory = new ExcelParserFactory(strategies);

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> excelParserFactory.getParser(null));

        assertTrue(exception.getMessage().contains("No parser strategy found for type: null"));
    }

    @Test
    void constructor_WithThreeStrategies_ShouldAllowRetrievalOfAll() {
        ExcelParserStrategy<?> thirdStrategy = new ExcelParserStrategy<ParchmentRecord>() {
            @Override
            public List<ParchmentRecord> parse(MultipartFile file) {
                return Collections.emptyList();
            }

            @Override
            public String getParserType() {
                return "nsc";
            }

            @Override
            public ExcelColumnMapping getColumnMapping() {
                return null;
            }

            @Override
            public ExcelRowMapper<ParchmentRecord> getRowMapper() {
                return null;
            }
        };

        List<ExcelParserStrategy<?>> strategies = Arrays.asList(parchmentStrategy, anotherStrategy, thirdStrategy);
        excelParserFactory = new ExcelParserFactory(strategies);

        ExcelParserStrategy<?> result1 = excelParserFactory.getParser("parchment");
        ExcelParserStrategy<?> result2 = excelParserFactory.getParser("clearinghouse");
        ExcelParserStrategy<?> result3 = excelParserFactory.getParser("nsc");

        assertNotNull(result1);
        assertNotNull(result2);
        assertNotNull(result3);
        assertSame(parchmentStrategy, result1);
        assertSame(anotherStrategy, result2);
        assertSame(thirdStrategy, result3);
    }
}

