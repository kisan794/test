package com.hireright.sourceintelligence.exception;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingPathVariableException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import java.util.ArrayList;
import java.util.List;

/**
 * Centralized exception handling across all REST API calls through @ExceptionHandler. Error
 * messages from each Exception type are wrapped in the ApiError DTO and HTTP Response with status
 * and body is built to send back to the API Caller.
 */
@Configuration
//@ComponentScan("com.hireright.common.api.exception")
@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
@Slf4j
public class GlobalApiExceptionHandler extends ResponseEntityExceptionHandler {

    // Override the Exceptions from Spring MVC and build the ApiError response


    private static ResponseEntity<Object> loggingResponseBuilder(ApiError error, Exception ex) {
        log.error(" REST Exception - ", ex);
        return responseBuilder(error);
    }

    private static ResponseEntity<Object> responseBuilder(ApiError apiError) {
        logErrorCode(apiError);
        return new ResponseEntity<>(apiError, apiError.getStatus());
    }

    //Utility Method to log the error code in the logs for alerting via Splunk
    private static void logErrorCode(@NotNull ApiError apiError) {
        var errorLogged = new StringBuilder();
        if (apiError.getErrorCode() != null) {
            errorLogged.append(apiError.getErrorCode() + " REST API EXCEPTION. ");
        }
        if (apiError.getStatus() != null) {
            errorLogged.append(" Response Status: " + apiError.getStatus().value());
        }
        if (apiError.getMessage() != null) {
            errorLogged.append(" Message: " + apiError.getMessage());
        }
        log.error(errorLogged.toString());
    }

    // Triggered when a 'required' request parameter is missing.
    @Override
    protected ResponseEntity<Object> handleMissingServletRequestParameter(MissingServletRequestParameterException ex,
                                                                          HttpHeaders headers, HttpStatusCode status,
                                                                          WebRequest request) {
        String missingParam = " Missing Parameter: " + ex.getParameterName();
        return responseBuilder(new ApiError(ErrorCode.BAD_REQUEST, missingParam));
    }

    @Override
    protected ResponseEntity<Object> handleMissingPathVariable(MissingPathVariableException ex, HttpHeaders headers,
                                                               HttpStatusCode status, WebRequest request) {
        return responseBuilder(new ApiError(ErrorCode.BAD_REQUEST, "Missing path variable: " + ex.getVariableName()));
    }

    // Triggered when the MediaType(e.g. JSON) in the body is invalid
    @Override
    protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(HttpMediaTypeNotSupportedException ex,
                                                                     HttpHeaders headers, HttpStatusCode status,
                                                                     WebRequest request) {
        String unSupportedType = "Payload Media Type  " + ex.getContentType() + "is not supported.";
        return responseBuilder(new ApiError(ErrorCode.BAD_REQUEST, unSupportedType));
    }

    // Triggered when the JSON Payload is malformed, i.e., not valid JSON
    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
                                                                  HttpHeaders headers, HttpStatusCode status,
                                                                  WebRequest request) {
        String malformedJson = "JSON in request payload is malformed.";
        return responseBuilder(new ApiError(ErrorCode.BAD_REQUEST, malformedJson));
    }

    //Triggered when JSON payload cannot be sent back in the response to the API caller
    @Override
    protected ResponseEntity<Object> handleHttpMessageNotWritable(HttpMessageNotWritableException ex,
                                                                  HttpHeaders headers, HttpStatusCode status,
                                                                  WebRequest request) {
        List<String> errorList = new ArrayList<>();
        errorList.add(ex.getMessage());
        String outputJson = "Error while writing JSON in response payload.";
        ApiError apiError = new ApiError(ErrorCode.INTERNAL, outputJson);
        apiError.addErrors(errorList);
        return responseBuilder(apiError);
    }

    // Triggered when Spring MVC could not find a mapping for the URL
    @Override
    protected ResponseEntity<Object> handleNoHandlerFoundException(NoHandlerFoundException ex, HttpHeaders headers,
                                                                   HttpStatusCode status, WebRequest request) {
        log.error("TRY Exception is:", ex);
        List<String> errorList = new ArrayList<>();
        errorList.add(ex.getMessage());
        String methodURL = "Could not find the " + ex.getHttpMethod() + " method for URL " + ex.getRequestURL();
        ApiError apiError = new ApiError(ErrorCode.NOT_FOUND, methodURL);
        apiError.addErrors(errorList);
        return responseBuilder(apiError);
    }

    //Triggered  when validation on an argument annotated with @Valid fails.
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
                                                                  HttpHeaders headers, HttpStatusCode status,
                                                                  WebRequest request) {
        ApiError apiError = new ApiError(ErrorCode.UNPROCESSABLE, ex.getMessage());
        apiError.addFieldErrors(ex.getFieldErrors());
        apiError.addGlobalErrors(ex.getBindingResult().getGlobalErrors());
        return responseBuilder(apiError);
    }

    @ExceptionHandler({AccessDeniedException.class})
    public ResponseEntity<Object> handleAccessDenied(AccessDeniedException ex) {
        //Once Okta or JWT validation is enabled in Spring Security,
        // extract the user and token and add to the error response
        return responseBuilder(new ApiError(HttpStatus.FORBIDDEN, ex.getMessage()));
    }

    // Triggered when a constraint violation error happens at the Persistence Layer

    @ExceptionHandler({MethodArgumentTypeMismatchException.class})
    public final ResponseEntity<Object> handleMethodArgMismatch(MethodArgumentTypeMismatchException ex) {
        String mismatch =
                "Type of " + ex.getName() + " in the URL does not match " + ex.getParameter().getParameterName();
        return responseBuilder(new ApiError(ErrorCode.BAD_REQUEST, mismatch));
    }

    @ExceptionHandler({MissingRequestHeaderException.class})
    public final ResponseEntity<Object> handleMissingRequestHeader(MissingRequestHeaderException ex) {
        String mismatch =
                "Request Header " + ex.getHeaderName() + " in the URL does not match " + ex.getParameter().getParameterName();
        return responseBuilder(new ApiError(ErrorCode.BAD_REQUEST, mismatch));
    }

    @ExceptionHandler({ConstraintViolationException.class})
    public final ResponseEntity<Object> handleConstraintViolation(ConstraintViolationException ex) {
        ApiError apiError = new ApiError(ErrorCode.BAD_REQUEST, "Validation Failure");
        if (CollectionUtils.isNotEmpty(ex.getConstraintViolations())) {
            apiError.addValidationErrors(ex.getConstraintViolations());
        }
        return responseBuilder(apiError);
    }

    // Handle Spring Persistence Exceptions

    @ExceptionHandler(DataIntegrityViolationException.class)
    protected ResponseEntity<Object> handleDataIntegrityViolation(DataIntegrityViolationException ex) {
        return responseBuilder(new ApiError(ErrorCode.ALREADY_EXISTS, ex));
    }

    //Default Root exception for the persistence layer. Add handlers if more specific Persistence layer exceptions
    // need to be handled
    @ExceptionHandler(DataAccessException.class)
    protected ResponseEntity<Object> handleDataAccessException(DataAccessException ex) {
        return loggingResponseBuilder(new ApiError(ErrorCode.INTERNAL, ex), ex);
    }

    //Handle custom Exceptions defined in this Microservice

    //Handle Generic Exception thrown by the microservice
    @ExceptionHandler(ServiceException.class)
    public ResponseEntity<Object> handleServiceException(ServiceException ex) {
        return responseBuilder(new ApiError(ErrorCode.INTERNAL, ex.getMessage()));
    }

    // Triggered by Kafka publish/subscribe
//    @ExceptionHandler(KafkaException.class)
//    public ResponseEntity<Object> handleKafkaException(KafkaException ex) {
//        return loggingResponseBuilder(new ApiError(ErrorCode.INTERNAL, ex.getMessage()), ex);
//    }

    //Triggered when credentials in the API call are invalid.
    @ExceptionHandler({UnauthorizedException.class})
    public ResponseEntity<Object> unauthorizedExceptionHandler(Exception ex) {

        String unAuthorized = ex.getMessage() != null ? ex.getMessage() : "The caller does not have valid " +
                "authentication credentials for the operation.";
        return responseBuilder(new ApiError(ErrorCode.UNAUTHENTICATED, unAuthorized));
    }

    @ExceptionHandler(InvalidRequestException.class)
    public ResponseEntity<Object> handleInvalidRequestException(InvalidRequestException ex) {
        String invalidRequest = ex.getMessage() != null ? ex.getMessage() : "The API request was invalid";
        return responseBuilder(new ApiError(ErrorCode.BAD_REQUEST, invalidRequest));
    }


    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<Object> handleResourceNotFound(ResourceNotFoundException ex) {
        String notFound = ex.getMessage() != null ? ex.getMessage() : "The resource requested in the API was " +
                "not found on this server";
        return responseBuilder(new ApiError(ErrorCode.NOT_FOUND, notFound));
    }

    @ExceptionHandler(ExperianInvalidRequestException.class)
    public ResponseEntity<?> handleExperianInvalidRequestException(ExperianInvalidRequestException ex) {
        final ObjectMapper objectMapper = new ObjectMapper();
        ErrorResponse errorResponse = null;
        try {
            errorResponse = objectMapper.readValue(ex.getMessage(), ErrorResponse.class);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
    }

    @ExceptionHandler(RestClientException.class)
    public ResponseEntity<Object> handleRestClientException(RestClientException ex) {
        return responseBuilder(new ApiError(ErrorCode.BAD_REQUEST, ex.getMessage()));
    }

    @ExceptionHandler(ResourceAccessException.class)
    public ResponseEntity<Object> handleResourceAccessException(ResourceAccessException ex) {
        return responseBuilder(new ApiError(ErrorCode.BAD_REQUEST, ex.getMessage()));
    }

    @ExceptionHandler(InvalidJsonException.class)
    public ResponseEntity<Object> handleJsonProcessingException(InvalidJsonException ex) {
        return responseBuilder(new ApiError(ErrorCode.BAD_REQUEST, ex.getMessage()));
    }

    // Default Handler
    @ExceptionHandler({Exception.class})
    public ResponseEntity<Object> defaultExceptionHandler(Exception ex) {
        return loggingResponseBuilder(new ApiError(ErrorCode.INTERNAL, ex.getMessage()), ex);
    }

}
