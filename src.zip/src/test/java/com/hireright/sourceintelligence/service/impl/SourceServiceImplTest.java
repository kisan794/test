package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.*;
import static com.hireright.sourceintelligence.api.ApiConstants.FAILURE;
import static com.hireright.sourceintelligence.api.ApiConstants.SUCCESS;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.*;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.CREATE;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.ErrorMessages.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.ReportActions.LOCK;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.ReportActions.UNLOCK;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.ASSIGN_MYSELF;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchResponseDTO;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchSourceDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.domain.mapper.AutoMatchMapper;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.service.impl.helperservices.ArchiveSourceService;
import com.hireright.sourceintelligence.service.impl.helperservices.CreateSourceService;
import com.hireright.sourceintelligence.service.impl.helperservices.ReportDataUtils;
import com.hireright.sourceintelligence.service.impl.helperservices.UpdateSourceService;
import com.hireright.sourceintelligence.util.Helper;
import com.mongodb.BasicDBObject;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.StatusCode.*;

@ExtendWith(MockitoExtension.class)
class SourceServiceImplTest {

    @Mock
    private CustomSourceRepository<Source> customSourceRepository;
    @Mock
    private SourceMapper sourceMapper;
    @Mock
    private ReportDataUtils reportDataUtils;
    @Mock
    private Helper helper;
    @Mock
    private AutoMatchMapper autoMatchMapper;
    @Mock
    private CreateSourceService createSourceService;
    @Mock
    private UpdateSourceService updateSourceService;
    @Mock
    private ArchiveSourceService archiveSourceService;
    @Mock
    private MongoSourceService mongoSourceService;

    @InjectMocks
    private SourceServiceImpl sourceService;

    private Source source;
    private SourceOrganizationDTO sourceOrganizationDTO;
    private UIActionsDTO uiActionsDTO;

    @BeforeEach
    void setUp() {
        source = new Source();
        source.setId(new ObjectId());
        source.setHon("HON123");
        source.setVersion(1.0);
        source.setTempVersion(2.0);
        source.setPayload(new BasicDBObject("key", "value"));
        source.setApprovalStatus(PENDING_APPROVAL);
        source.setAction(CREATE);
        source.setIsLockEnabled(false);
        source.setAssignedTo("tester");

        sourceOrganizationDTO = new SourceOrganizationDTO();
        sourceOrganizationDTO.setId(source.getId().toHexString());
        sourceOrganizationDTO.setHon("HON123");
        sourceOrganizationDTO.setOrganizationName("Test Org");

        uiActionsDTO = new UIActionsDTO();
        uiActionsDTO.setUserName("qa.user");
        uiActionsDTO.setUserEmail("qa.user@test.com");
        uiActionsDTO.setUserAction(LOCK);
    }

    @Test
    void createSource_shouldReturnCreatedSource() throws Exception {
        when(createSourceService.createSource(sourceOrganizationDTO, uiActionsDTO))
                .thenReturn(sourceOrganizationDTO);

        SourceOrganizationDTO result = sourceService.createSource(sourceOrganizationDTO, uiActionsDTO);

        assertNotNull(result);
        assertEquals("HON123", result.getHon());
        verify(createSourceService).createSource(sourceOrganizationDTO, uiActionsDTO);
    }


    @Test
    void createSource_shouldThrowWhenServiceFails() throws Exception {
        when(createSourceService.createSource(sourceOrganizationDTO, uiActionsDTO))
                .thenThrow(new Exception("create failed"));

        assertThrows(RuntimeException.class,
                () -> sourceService.createSource(sourceOrganizationDTO, uiActionsDTO));
    }

    @Test
    void updateSource_shouldReturnUpdatedSource() throws Exception {
        when(updateSourceService.updateSource(sourceOrganizationDTO, uiActionsDTO))
                .thenReturn(sourceOrganizationDTO);

        SourceOrganizationDTO result = sourceService.updateSource(sourceOrganizationDTO, uiActionsDTO);

        assertNotNull(result);
        assertEquals("HON123", result.getHon());
        verify(updateSourceService).updateSource(sourceOrganizationDTO, uiActionsDTO);
    }

    @Test
    void updateSource_shouldThrowWhenServiceFails() throws Exception {
        when(updateSourceService.updateSource(sourceOrganizationDTO, uiActionsDTO))
                .thenThrow(new Exception("update failed"));

        assertThrows(RuntimeException.class,
                () -> sourceService.updateSource(sourceOrganizationDTO, uiActionsDTO));
    }

    @Test
    void archiveSource_shouldReturnSuccessResponse() throws Exception {
        when(archiveSourceService.archiveSource("HON123", uiActionsDTO))
                .thenReturn(true);

        ResponseObject result = sourceService.archiveSource("HON123", uiActionsDTO);

        assertNotNull(result);
        assertEquals(SUCCESS, result.getStatus());
        assertEquals(ARCHIVE_SUCCESS, result.getMessage());
        assertEquals(SUCCESS_CODE, result.getStatusCode());
    }

    @Test
    void archiveSource_shouldReturnFailureResponse() throws Exception {
        when(archiveSourceService.archiveSource("HON123", uiActionsDTO))
                .thenReturn(false);

        ResponseObject result = sourceService.archiveSource("HON123", uiActionsDTO);

        assertNotNull(result);
        assertEquals(FAILURE, result.getStatus());
        assertEquals(ARCHIVE_FAILURE, result.getMessage());
        assertEquals(FAILURE_CODE, result.getStatusCode());
    }

    @Test
    void archiveSource_shouldThrowWhenServiceFails() throws Exception {
        when(archiveSourceService.archiveSource("HON123", uiActionsDTO))
                .thenThrow(new Exception("archive failed"));

        assertThrows(RuntimeException.class,
                () -> sourceService.archiveSource("HON123", uiActionsDTO));
    }

    @Test
    void manualSelectSource_shouldReturnAutoMatchResponse() {
        AutoMatchSourceDTO autoMatchSourceDTO = new AutoMatchSourceDTO();
        source.setPayload(new BasicDBObject("key", "value"));
        when(mongoSourceService.findSourceByHonAndApprovalStatus("HON123", APPROVED)).thenReturn(source);
        when(autoMatchMapper.toAutoMatchDTO(source)).thenReturn(autoMatchSourceDTO);

        AutoMatchResponseDTO result = sourceService.manualSelectSource("HON123", APPROVED);

        assertNotNull(result);
        assertNotNull(result.getSource());
        verify(mongoSourceService).findSourceByHonAndApprovalStatus("HON123", APPROVED);
        verify(autoMatchMapper).toAutoMatchDTO(source);
    }

    @Test
    void manualSelectSource_shouldThrowWhenSourceNotFound() {
        when(mongoSourceService.findSourceByHonAndApprovalStatus("HON123", APPROVED)).thenReturn(null);

        assertThrows(RuntimeException.class,
                () -> sourceService.manualSelectSource("HON123", APPROVED));
    }

    @Test
    void manualSelectSource_shouldThrowWhenPayloadMissing() {
        source.setPayload(null);
        when(mongoSourceService.findSourceByHonAndApprovalStatus("HON123", APPROVED)).thenReturn(source);

        assertThrows(RuntimeException.class,
                () -> sourceService.manualSelectSource("HON123", APPROVED));
    }

    @Test
    void getSourcesByHonIds_shouldReturnMappedDtos() {
        List<String> honIds = List.of("EMPLOYMENT");
        List<Source> sourceList = List.of(source);
        List<SourceOrganizationDTO> dtoList = List.of(sourceOrganizationDTO);

        when(customSourceRepository.findByHonIn(anyList(), eq(Source.class), anyString()))
                .thenReturn(sourceList);
        when(sourceMapper.toSourceDTOList(sourceList)).thenReturn(dtoList);

        List<SourceOrganizationDTO> result = sourceService.getSourcesByHonIds(honIds);

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(sourceMapper).toSourceDTOList(sourceList);
    }

    @Test
    void getSourcesByHonIds_shouldReturnEmptyList() {
        when(customSourceRepository.findByHonIn(anyList(), eq(Source.class), anyString()))
                .thenReturn(Collections.emptyList());

        List<SourceOrganizationDTO> result =
                sourceService.getSourcesByHonIds(List.of("EMPLOYMENT"));

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void getSourceByHon_shouldReturnDto() {
        when(mongoSourceService.findSourceByHon("HON123")).thenReturn(source);
        when(sourceMapper.entitySourceToDTO(source)).thenReturn(sourceOrganizationDTO);

        SourceOrganizationDTO result = sourceService.getSourceByHon("HON123");

        assertNotNull(result);
        assertEquals("HON123", result.getHon());
    }

    @Test
    void getSourceByHon_shouldThrowWhenSourceNotFound() {
        when(mongoSourceService.findSourceByHon("HON123")).thenReturn(null);

        assertThrows(RuntimeException.class,
                () -> sourceService.getSourceByHon("HON123"));
    }

    @Test
    void assignApproveManagerToSource_shouldAssignMyselfSuccessfully() {
        AssignSourceDTO assignSourceDTO = new AssignSourceDTO();
        assignSourceDTO.setId(source.getId().toHexString());
        assignSourceDTO.setHon("EMPLOYMENT");
        assignSourceDTO.setApprovalStatus(PENDING_APPROVAL);

        ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();
        approvalRequestDTO.setApproverName("qa.user");
        approvalRequestDTO.setApproverEmail("qa.user@test.com");
        approvalRequestDTO.setAssignType(ASSIGN_MYSELF);
        approvalRequestDTO.setOrgnaizationType("EMPLOYMENT");
        approvalRequestDTO.setSourceDetails(new ArrayList<>(List.of(assignSourceDTO)));

        when(mongoSourceService.findSourceById(any(ObjectId.class), anyString()))
                .thenReturn(source);
        when(mongoSourceService.findSourceByHonAndApprovalStatuses(eq("EMPLOYMENT"), anyList()))
                .thenReturn(null);
        when(customSourceRepository.updateFieldsByQuery(any(Query.class), any(Update.class), eq(Source.class), anyString()))
                .thenReturn(true);

        ResponseObject result = sourceService.assignApproveManagerToSource(approvalRequestDTO);

        assertNotNull(result);
        assertEquals(SUCCESS, result.getStatus());
        assertEquals(ASSIGN_SUCCESS, result.getMessage());

        verify(reportDataUtils).reportData(
                eq(source),
                eq(source.getAction()),
                eq(SIDB_APPROVAL_FLOW),
                eq(0),
                eq(MANUAL_PROCESS),
                eq(source.getVersion()),
                eq(source.getTempVersion()),
                eq(APPROVAL_FLOW)
        );
    }

    @Test
    void assignApproveManagerToSource_shouldAssignOtherSuccessfully() {
        AssignSourceDTO assignSourceDTO = new AssignSourceDTO();
        assignSourceDTO.setId(source.getId().toHexString());
        assignSourceDTO.setHon("EMPLOYMENT");
        assignSourceDTO.setApprovalStatus(PENDING_APPROVAL);

        ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();
        approvalRequestDTO.setApproverName("manager");
        approvalRequestDTO.setApproverEmail("manager@test.com");
        approvalRequestDTO.setAssignType("OTHER");
        approvalRequestDTO.setOrgnaizationType("EMPLOYMENT");
        approvalRequestDTO.setSourceDetails(new ArrayList<>(List.of(assignSourceDTO)));

        when(mongoSourceService.findSourceById(any(ObjectId.class), anyString()))
                .thenReturn(source);
        when(mongoSourceService.findSourceByHonAndApprovalStatuses(eq("EMPLOYMENT"), anyList()))
                .thenReturn(null);

        ResponseObject result = sourceService.assignApproveManagerToSource(approvalRequestDTO);

        assertNotNull(result);
        assertEquals(SUCCESS, result.getStatus());
        assertEquals(ASSIGN_SUCCESS, result.getMessage());

        verify(customSourceRepository).assignApproverToSource(
                any(Query.class),
                eq("manager"),
                eq("manager@test.com"),
                anyString()
        );
    }

    @Test
    void assignApproveManagerToSource_shouldReturnFailureWhenAlreadyAssignedInProgress() {
        AssignSourceDTO assignSourceDTO = new AssignSourceDTO();
        assignSourceDTO.setId(source.getId().toHexString());
        assignSourceDTO.setHon("EMPLOYMENT");
        assignSourceDTO.setApprovalStatus(PENDING_APPROVAL);

        ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();
        approvalRequestDTO.setAssignType(ASSIGN_MYSELF);
        approvalRequestDTO.setSourceDetails(new ArrayList<>(List.of(assignSourceDTO)));

        when(mongoSourceService.findSourceById(any(ObjectId.class), anyString()))
                .thenReturn(source);
        when(mongoSourceService.findSourceByHonAndApprovalStatuses(eq("EMPLOYMENT"), anyList()))
                .thenReturn(new Source());

        ResponseObject result = sourceService.assignApproveManagerToSource(approvalRequestDTO);

        assertNotNull(result);
        assertEquals(FAILURE, result.getStatus());
        assertEquals(ASSIGN_FAILURE_2, result.getMessage());
    }

    @Test
    void assignApproveManagerToSource_shouldReturnFailureWhenStatusInvalid() {
        source.setApprovalStatus(APPROVED);

        AssignSourceDTO assignSourceDTO = new AssignSourceDTO();
        assignSourceDTO.setId(source.getId().toHexString());
        assignSourceDTO.setHon("EMPLOYMENT");
        assignSourceDTO.setApprovalStatus(APPROVED);

        ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();
        approvalRequestDTO.setAssignType(ASSIGN_MYSELF);
        approvalRequestDTO.setSourceDetails(new ArrayList<>(List.of(assignSourceDTO)));

        when(mongoSourceService.findSourceById(any(ObjectId.class), anyString()))
                .thenReturn(source);

        ResponseObject result = sourceService.assignApproveManagerToSource(approvalRequestDTO);

        assertNotNull(result);
        assertEquals(FAILURE, result.getStatus());
        assertEquals(ASSIGN_FAILURE, result.getMessage());
    }

    @Test
    void assignApproveManagerToSource_shouldReturnFailureWhenNoHonsCollected() {
        ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();
        approvalRequestDTO.setSourceDetails(new ArrayList<>());

        ResponseObject result = sourceService.assignApproveManagerToSource(approvalRequestDTO);

        assertEquals(FAILURE, result.getStatus());
        assertEquals(ASSIGN_FAILURE, result.getMessage());
        assertEquals(FAILURE2_CODE, result.getStatusCode());
    }

    @Test
    void updateFlagForPriority_shouldToggleFromNullToTrue() {
        source.setFlagPriority(null);

        when(customSourceRepository.findByQuery(any(Query.class), eq(Source.class), anyString()))
                .thenReturn(List.of(source));
        when(customSourceRepository.updateFieldsByQuery(any(Query.class), any(Update.class), eq(Source.class), anyString()))
                .thenReturn(true);

        boolean result = sourceService.updateFlagForPriority("EMPLOYMENT", 1.0);

        assertTrue(result);
    }

    @Test
    void updateFlagForPriority_shouldToggleFromTrueToFalse() {
        source.setFlagPriority(true);

        when(customSourceRepository.findByQuery(any(Query.class), eq(Source.class), anyString()))
                .thenReturn(List.of(source));
        when(customSourceRepository.updateFieldsByQuery(any(Query.class), any(Update.class), eq(Source.class), anyString()))
                .thenReturn(true);

        boolean result = sourceService.updateFlagForPriority("EMPLOYMENT", 1.0);

        assertFalse(result);
    }

    @Test
    void updateFlagForPriority_shouldThrowWhenSourceMissing() {
        when(customSourceRepository.findByQuery(any(Query.class), eq(Source.class), anyString()))
                .thenReturn(Collections.emptyList());

        assertThrows(RuntimeException.class,
                () -> sourceService.updateFlagForPriority("EMPLOYMENT", 1.0));
    }

    @Test
    void lockSource_shouldReturnSuccess() {
        source.setIsLockEnabled(false);
        uiActionsDTO.setUserAction(LOCK);

        when(mongoSourceService.findSourceByHon("EMPLOYMENT"))
                .thenReturn(source);
        when(customSourceRepository.updateFieldsByQuery(any(Query.class), any(Update.class), eq(Source.class), anyString()))
                .thenReturn(true);

        ResponseObject result = sourceService.lockSource("EMPLOYMENT", uiActionsDTO);

        assertNotNull(result);
        assertEquals(SUCCESS, result.getStatus());
        assertEquals(LOCK_SUCCESS, result.getMessage());

        verify(mongoSourceService).insertSourceHistory(any(Source.class));
        verify(reportDataUtils).reportData(
                eq(source),
                eq(LOCK),
                eq(SIDB_ORIGIN),
                eq(0),
                isNull(),
                eq(source.getVersion()),
                eq(source.getTempVersion()),
                eq(LOCK)
        );
    }

    @Test
    void lockSource_shouldReturnFailureWhenAlreadyLocked() {
        source.setIsLockEnabled(true);
        when(mongoSourceService.findSourceByHon("HON123")).thenReturn(source);

        ResponseObject result = sourceService.lockSource("HON123", uiActionsDTO);

        assertEquals(FAILURE, result.getStatus());
        assertEquals(LOCK_FAILURE, result.getMessage());
    }

    @Test
    void lockSource_shouldReturnFailureWhenSourceMissing() {
        when(mongoSourceService.findSourceByHon("HON123")).thenReturn(null);

        ResponseObject result = sourceService.lockSource("HON123", uiActionsDTO);

        assertEquals(FAILURE, result.getStatus());
        assertEquals(LOCK_FAILURE_2, result.getMessage());
    }

    @Test
    void unlockSource_shouldReturnSuccessForCreateAction() {
        source.setIsLockEnabled(true);
        source.setAction(CREATE);
        uiActionsDTO.setUserAction(UNLOCK);

        when(mongoSourceService.findSourceByHon("EMPLOYMENT"))
                .thenReturn(source);
        when(customSourceRepository.updateFieldsByQuery(any(Query.class), any(Update.class), eq(Source.class), anyString()))
                .thenReturn(true);

        ResponseObject result = sourceService.unlockSource("EMPLOYMENT", uiActionsDTO);

        assertNotNull(result);
        assertEquals(SUCCESS, result.getStatus());
        assertEquals(UNLOCK_SUCCESS, result.getMessage());

        verify(mongoSourceService).insertSourceHistory(any(Source.class));
        verify(reportDataUtils).reportData(
                eq(source),
                eq(UNLOCK),
                eq(SIDB_ORIGIN),
                eq(0),
                isNull(),
                eq(source.getVersion()),
                eq(source.getTempVersion()),
                eq(UNLOCK)
        );
    }

    @Test
    void unlockSource_shouldReturnSuccessForNonCreateAction() {
        source.setIsLockEnabled(true);
        source.setAction("UPDATE");
        uiActionsDTO.setUserAction(UNLOCK);

        when(mongoSourceService.findSourceByHon("EMPLOYMENT"))
                .thenReturn(source);
        when(customSourceRepository.updateFieldsByQuery(any(Query.class), any(Update.class), eq(Source.class), anyString()))
                .thenReturn(true);

        ResponseObject result = sourceService.unlockSource("EMPLOYMENT", uiActionsDTO);

        assertNotNull(result);
        assertEquals(SUCCESS, result.getStatus());
        assertEquals(UNLOCK_SUCCESS, result.getMessage());
    }

    @Test
    void unlockSource_shouldReturnFailureWhenNotLocked() {
        source.setIsLockEnabled(false);
        when(mongoSourceService.findSourceByHon("HON123")).thenReturn(source);

        ResponseObject result = sourceService.unlockSource("HON123", uiActionsDTO);

        assertEquals(FAILURE, result.getStatus());
        assertEquals(UNLOCK_FAILURE, result.getMessage());
    }

    @Test
    void unlockSource_shouldReturnFailureWhenSourceMissing() {
        when(mongoSourceService.findSourceByHon("HON123")).thenReturn(null);

        ResponseObject result = sourceService.unlockSource("HON123", uiActionsDTO);

        assertEquals(FAILURE, result.getStatus());
        assertEquals(UNLOCK_FAILURE2, result.getMessage());
    }

    @Test
    void updateUsedCount_shouldReturnTrueForAutoMatch() {
        source.setPayload(new BasicDBObject("key", "value"));

        when(mongoSourceService.findSourceByHonForUsedCount("EMPLOYMENT"))
                .thenReturn(source);

        when(customSourceRepository.UpdateDateOnIncrementByHon(
                eq("EMPLOYMENT"),
                anyString(),
                eq(Source.class),
                anyString()))
                .thenReturn(source);

        boolean result = sourceService.updateUsedCount("EMPLOYMENT", true);

        assertTrue(result);

        verify(reportDataUtils).reportData(
                eq(source),
                eq("UsedCount"),
                eq(ORIGIN),
                eq(1),
                isNull(),
                eq(source.getVersion()),
                eq(source.getTempVersion()),
                eq("UsedCount")
        );
    }

    @Test
    void getSourceByHonAndApprovalStatus_shouldReturnDtoWhenStatusMatches() {
        source.setApprovalStatus(PENDING_APPROVAL);
        when(mongoSourceService.findSourceByHonAndApprovalStatus("HON123", PENDING_APPROVAL)).thenReturn(source);
        when(sourceMapper.entitySourceToDTO(source)).thenReturn(sourceOrganizationDTO);

        SourceOrganizationDTO result = sourceService.getSourceByHonAndApprovalStatus("HON123", PENDING_APPROVAL);

        assertNotNull(result);
        assertEquals("HON123", result.getHon());
    }

    @Test
    void getSourceByHonAndApprovalStatus_shouldReturnNullWhenSourceNotFoundAndApprovedRequested() {
        when(mongoSourceService.findSourceByHonAndApprovalStatus("HON123", APPROVED)).thenReturn(null);

        SourceOrganizationDTO result = sourceService.getSourceByHonAndApprovalStatus("HON123", APPROVED);

        assertNull(result);
    }

    @Test
    void getSourceByHonAndApprovalStatus_shouldReturnNullWhenStatusMismatchAndApprovedRequested() {
        source.setApprovalStatus(PENDING_APPROVAL);
        when(mongoSourceService.findSourceByHonAndApprovalStatus("HON123", APPROVED)).thenReturn(source);

        SourceOrganizationDTO result = sourceService.getSourceByHonAndApprovalStatus("HON123", APPROVED);

        assertNull(result);
    }

    @Test
    void getSourceByHonAndApprovalStatus_shouldReturnDtoFromTempFixWhenSecondLookupMatches() {
        Source firstSource = new Source();
        firstSource.setApprovalStatus(ONHOLD);

        Source secondSource = new Source();
        secondSource.setApprovalStatus(PENDING_APPROVAL);

        when(mongoSourceService.findSourceByHonAndApprovalStatus("HON123", PENDING_APPROVAL))
                .thenReturn(firstSource)
                .thenReturn(secondSource);
        when(sourceMapper.entitySourceToDTO(secondSource)).thenReturn(sourceOrganizationDTO);

        SourceOrganizationDTO result = sourceService.getSourceByHonAndApprovalStatus("HON123", PENDING_APPROVAL);

        assertNotNull(result);
    }

    @Test
    void getSourceByHonForOpTool_shouldReturnDto() {
        when(mongoSourceService.findSourceByHonOrderByLastModifiedBy("HON123")).thenReturn(source);
        when(sourceMapper.entitySourceToDTO(source)).thenReturn(sourceOrganizationDTO);

        SourceOrganizationDTO result = sourceService.getSourceByHonForOpTool("HON123");

        assertNotNull(result);
    }

    @Test
    void getSourceByHonForOpTool_shouldReturnNullWhenMissing() {
        when(mongoSourceService.findSourceByHonOrderByLastModifiedBy("HON123")).thenReturn(null);

        SourceOrganizationDTO result = sourceService.getSourceByHonForOpTool("HON123");

        assertNull(result);
    }

    @Test
    void getSourceForEditByHon_shouldReturnFallbackDtoWhenLatestSourceMissing() {
        when(mongoSourceService.findSourceByHonOrderByLastModifiedBy("HON123")).thenReturn(null);
        when(mongoSourceService.findSourceByHon("HON123")).thenReturn(source);
        when(sourceMapper.entitySourceToDTO(any(Source.class))).thenReturn(sourceOrganizationDTO);

        SourceOrganizationDTO result = sourceService.getSourceForEditByHon("HON123", "ANY");

        assertNotNull(result);
        verify(sourceMapper).entitySourceToDTO(any(Source.class));
    }

    @Test
    void getSourceForEditByHon_shouldReturnNullWhenBothSourcesMissing() {
        when(mongoSourceService.findSourceByHonOrderByLastModifiedBy("HON123")).thenReturn(null);
        when(mongoSourceService.findSourceByHon("HON123")).thenReturn(null);

        SourceOrganizationDTO result = sourceService.getSourceForEditByHon("HON123", "ANY");

        assertNull(result);
    }

    @Test
    void getSourceForEditByHon_shouldReturnLatestDtoWhenPresent() {
        when(mongoSourceService.findSourceByHonOrderByLastModifiedBy("HON123")).thenReturn(source);
        when(sourceMapper.entitySourceToDTO(source)).thenReturn(sourceOrganizationDTO);

        SourceOrganizationDTO result = sourceService.getSourceForEditByHon("HON123", "ANY");

        assertNotNull(result);
        assertEquals("HON123", result.getHon());
    }

    @Test
    void updateSourceStatus_shouldReturnTrueWhenCurrentSourceFound() {
        Source currentSource = new Source();
        currentSource.setId(new ObjectId());
        currentSource.setHon("EMPLOYMENT");
        currentSource.setVersion(1.0);
        currentSource.setTempVersion(2.0);
        currentSource.setAction("UPDATE");

        when(customSourceRepository.findByQuery(any(Query.class), eq(Source.class), anyString()))
                .thenReturn(Collections.emptyList())
                .thenReturn(List.of(currentSource));

        when(customSourceRepository.updateFieldsByQuery(any(Query.class), any(Update.class), eq(Source.class), anyString()))
                .thenReturn(true);

        boolean result = sourceService.updateSourceStatus("EMPLOYMENT", "1.0", "2.0", APPROVED);

        assertTrue(result);

        verify(reportDataUtils).reportData(
                eq(currentSource),
                eq(currentSource.getAction()),
                eq(SIDB_APPROVAL_FLOW),
                eq(0),
                eq(MANUAL_PROCESS),
                eq(currentSource.getVersion()),
                eq(currentSource.getTempVersion()),
                eq(APPROVAL_FLOW)
        );
    }


    @Test
    void getSourceForRAM_shouldFetchApprovedAndUpdateInProgressAndCurrentSource() {
        Source assignedSource = new Source();
        assignedSource.setId(new ObjectId(sourceOrganizationDTO.getId()));
        assignedSource.setAssignedTo("qa.user");
        assignedSource.setVersion(1.0);
        assignedSource.setTempVersion(2.0);
        assignedSource.setAction("Update");

        Source approvedSource = new Source();
        approvedSource.setHon("EMPLOYMENT");

        UIActionsDTO actionDto = new UIActionsDTO();
        actionDto.setUserAction(PENDING_APPROVAL.getStatus());
        actionDto.setUserName("qa.user");

        SourceRequestDTO sourceRequestDTO = new SourceRequestDTO();
        sourceRequestDTO.setUiActionsDTO(actionDto);

        SourceOrganizationDTO currentSourceDto = new SourceOrganizationDTO();
        currentSourceDto.setId(sourceOrganizationDTO.getId());
        sourceRequestDTO.setSourceOrganizationDTO(currentSourceDto);

        when(mongoSourceService.findSourceById(any(ObjectId.class), anyString()))
                .thenReturn(assignedSource)
                .thenReturn(assignedSource);
        when(mongoSourceService.findSourceByHonAndApprovalStatus("EMPLOYMENT", APPROVED))
                .thenReturn(approvedSource);
        when(sourceMapper.entitySourceToDTO(approvedSource))
                .thenReturn(new SourceOrganizationDTO());
        when(sourceMapper.entitySourceToDTO(assignedSource))
                .thenReturn(sourceOrganizationDTO);

        RamResponseDTO result = sourceService.getSourceForRAM("EMPLOYMENT", sourceRequestDTO);

        assertNotNull(result);
        assertNotNull(result.getApprovedSource());
        assertNotNull(result.getCurrentSource());

        verify(mongoSourceService).updateByIdWithCustomFields(any(Query.class), any(Update.class), anyString());
        verify(reportDataUtils).reportData(
                eq(assignedSource),
                eq("Update"),
                eq(SIDB_APPROVAL_FLOW),
                eq(0),
                eq(MANUAL_PROCESS),
                eq(assignedSource.getVersion()),
                eq(assignedSource.getTempVersion()),
                eq(APPROVAL_FLOW)
        );
    }

    @Test
    void getSourceForRAM_shouldNotFetchApprovedForApprovedAction() {
        UIActionsDTO actionDto = new UIActionsDTO();
        actionDto.setUserAction(APPROVED.getStatus());
        actionDto.setUserName("qa.user");

        SourceRequestDTO sourceRequestDTO = new SourceRequestDTO();
        sourceRequestDTO.setUiActionsDTO(actionDto);

        SourceOrganizationDTO currentSourceDto = new SourceOrganizationDTO();
        currentSourceDto.setId(source.getId().toHexString());
        sourceRequestDTO.setSourceOrganizationDTO(currentSourceDto);

        when(mongoSourceService.findSourceById(any(ObjectId.class), anyString()))
                .thenReturn(source);
        when(sourceMapper.entitySourceToDTO(source))
                .thenReturn(sourceOrganizationDTO);

        RamResponseDTO result = sourceService.getSourceForRAM("EMPLOYMENT", sourceRequestDTO);

        assertNotNull(result);
        verify(mongoSourceService, never())
                .findSourceByHonAndApprovalStatus("EMPLOYMENT", APPROVED);
    }

    @Test
    void getSourceForRAM_shouldNotUpdateInProgressWhenAssignedUserDoesNotMatch() {
        Source ramSource = new Source();
        ramSource.setId(source.getId());
        ramSource.setAssignedTo("someoneElse");

        UIActionsDTO actionDto = new UIActionsDTO();
        actionDto.setUserAction(PENDING_APPROVAL.getStatus());
        actionDto.setUserName("qa.user");

        SourceRequestDTO sourceRequestDTO = new SourceRequestDTO();
        sourceRequestDTO.setUiActionsDTO(actionDto);

        SourceOrganizationDTO currentSourceDto = new SourceOrganizationDTO();
        currentSourceDto.setId(source.getId().toHexString());
        sourceRequestDTO.setSourceOrganizationDTO(currentSourceDto);

        when(mongoSourceService.findSourceById(any(ObjectId.class), anyString()))
                .thenReturn(ramSource)
                .thenReturn(ramSource);
        when(mongoSourceService.findSourceByHonAndApprovalStatus("EMPLOYMENT", APPROVED))
                .thenReturn(null);
        when(sourceMapper.entitySourceToDTO(ramSource))
                .thenReturn(sourceOrganizationDTO);

        RamResponseDTO result = sourceService.getSourceForRAM("EMPLOYMENT", sourceRequestDTO);

        assertNotNull(result);

        verify(mongoSourceService, never())
                .updateByIdWithCustomFields(any(Query.class), any(Update.class), anyString());

        verify(reportDataUtils, never())
                .reportData(any(), anyString(), anyString(), anyInt(), any(), anyDouble(), anyDouble(), anyString());
    }
    }