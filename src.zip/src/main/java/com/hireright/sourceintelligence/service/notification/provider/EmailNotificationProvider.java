package com.hireright.sourceintelligence.service.notification.provider;

import com.hireright.sourceintelligence.api.dto.notification.AttachmentDTO;
import com.hireright.sourceintelligence.api.dto.notification.EmailNotificationDTO;
import com.hireright.sourceintelligence.exception.CircuitBreakerOpenException;
import com.hireright.sourceintelligence.exception.NotificationException;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import java.util.Base64;
import java.util.List;

/**
 * Provider for sending emails via SMTP with circuit breaker and retry logic.
 * Follows Single Responsibility Principle - only handles email sending.
 * Implements resilience patterns (retry + circuit breaker).
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class EmailNotificationProvider {
    
    private final JavaMailSender mailSender;
    private final CircuitBreakerRegistry circuitBreakerRegistry;
    
    @Value("${notification.email.from:noreply@sourceintelligence.com}")
    private String defaultFromAddress;
    
    /**
     * Sends email with circuit breaker and retry logic
     *
     * @param emailDTO the email to send
     * @throws NotificationException if sending fails
     */
    public void sendEmail(EmailNotificationDTO emailDTO) {
        CircuitBreaker circuitBreaker = circuitBreakerRegistry.circuitBreaker("emailNotification");
        
        try {
            circuitBreaker.executeRunnable(() -> sendEmailWithRetry(emailDTO));
        } catch (CallNotPermittedException e) {
            log.error("Circuit breaker is OPEN - email service unavailable");
            CircuitBreaker.Metrics metrics = circuitBreaker.getMetrics();
            
            throw new CircuitBreakerOpenException(
                    "Email service temporarily unavailable due to high failure rate",
                    60, // retry after 60 seconds
                    metrics.getFailureRate()
            );
        } catch (Exception e) {
            log.error("Failed to send email: {}", e.getMessage(), e);
            throw new NotificationException("Failed to send email", "EMAIL_SEND_FAILED", e);
        }
    }
    
    /**
     * Sends email with retry logic
     * Retries up to 3 times with exponential backoff
     */
    @Retryable(
            retryFor = {MailException.class, MessagingException.class},
            maxAttempts = 3,
            backoff = @Backoff(
                    delay = 2000,
                    multiplier = 2,
                    maxDelay = 10000
            ),
            noRetryFor = {org.springframework.mail.MailAuthenticationException.class}
    )
    protected void sendEmailWithRetry(EmailNotificationDTO emailDTO) {
        log.info("Attempting to send email to: {}", emailDTO.getTo());
        
        try {
            MimeMessage message = createMimeMessage(emailDTO);
            mailSender.send(message);
            
            log.info("Email sent successfully to: {}", emailDTO.getTo());
        } catch (MessagingException e) {
            log.error("Failed to create/send email message: {}", e.getMessage());
            throw new NotificationException("Failed to create email message", "EMAIL_CREATION_FAILED", e);
        }
    }
    
    /**
     * Creates a MimeMessage from EmailNotificationDTO
     */
    private MimeMessage createMimeMessage(EmailNotificationDTO emailDTO) throws MessagingException {
        MimeMessage message = mailSender.createMimeMessage();
        
        boolean hasAttachments = emailDTO.getAttachments() != null && !emailDTO.getAttachments().isEmpty();
        MimeMessageHelper helper = new MimeMessageHelper(message, hasAttachments, "UTF-8");
        
        // Set from address
        helper.setFrom(defaultFromAddress);
        
        // Set recipients
        helper.setTo(emailDTO.getTo().toArray(new String[0]));
        
        // Set CC if present
        if (emailDTO.getCc() != null && !emailDTO.getCc().isEmpty()) {
            helper.setCc(emailDTO.getCc().toArray(new String[0]));
        }
        
        // Set BCC if present
        if (emailDTO.getBcc() != null && !emailDTO.getBcc().isEmpty()) {
            helper.setBcc(emailDTO.getBcc().toArray(new String[0]));
        }
        
        // Set reply-to if present
        if (emailDTO.getReplyTo() != null && !emailDTO.getReplyTo().trim().isEmpty()) {
            helper.setReplyTo(emailDTO.getReplyTo());
        }
        
        // Set subject
        helper.setSubject(emailDTO.getSubject());
        
        // Set body (HTML or plain text)
        boolean isHtml = emailDTO.getHtmlContent() != null && emailDTO.getHtmlContent();
        helper.setText(emailDTO.getBody(), isHtml);
        
        // Add attachments if present
        if (hasAttachments) {
            addAttachments(helper, emailDTO.getAttachments());
        }
        
        // Set importance if present
        if (emailDTO.getImportance() != null) {
            message.setHeader("X-Priority", getPriorityHeader(emailDTO.getImportance()));
        }
        
        return message;
    }
    
    /**
     * Adds attachments to the email
     */
    private void addAttachments(MimeMessageHelper helper, List<AttachmentDTO> attachments) throws MessagingException {
        for (AttachmentDTO attachment : attachments) {
            try {
                byte[] decodedContent = Base64.getDecoder().decode(attachment.getContent());
                helper.addAttachment(
                        attachment.getFilename(),
                        () -> decodedContent,
                        attachment.getContentType()
                );
            } catch (Exception e) {
                log.error("Failed to add attachment: {}", attachment.getFilename(), e);
                throw new MessagingException("Failed to add attachment: " + attachment.getFilename(), e);
            }
        }
    }
    
    /**
     * Converts importance string to email priority header
     */
    private String getPriorityHeader(String importance) {
        return switch (importance.toUpperCase()) {
            case "HIGH" -> "1";
            case "LOW" -> "5";
            default -> "3"; // NORMAL
        };
    }
}

