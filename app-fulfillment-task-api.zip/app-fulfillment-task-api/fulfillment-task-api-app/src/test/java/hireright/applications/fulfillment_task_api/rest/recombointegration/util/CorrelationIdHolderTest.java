/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.util;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit tests for CorrelationIdHolder
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("CorrelationIdHolder Tests")
class CorrelationIdHolderTest
{

	@AfterEach
	void tearDown()
	{
		// Clean up MDC after each test
		CorrelationIdHolder.clearAll();
	}

	@Test
	@DisplayName("Should generate new correlation ID")
	void testGenerate()
	{
		// When
		String correlationId = CorrelationIdHolder.generate();

		// Then
		assertNotNull(correlationId);
		assertFalse(correlationId.isEmpty());

		// Verify it's a valid UUID format
		assertTrue(
			correlationId.matches("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"));

		// Verify it's set in MDC
		assertEquals(correlationId, CorrelationIdHolder.get());
	}

	@Test
	@DisplayName("Should generate unique correlation IDs")
	void testGenerateUnique()
	{
		// When
		String id1 = CorrelationIdHolder.generate();
		CorrelationIdHolder.clear();
		String id2 = CorrelationIdHolder.generate();

		// Then
		assertNotEquals(id1, id2);
	}

	@Test
	@DisplayName("Should set correlation ID in MDC")
	void testSet()
	{
		// Given
		String correlationId = "test-correlation-id-123";

		// When
		CorrelationIdHolder.set(correlationId);

		// Then
		assertEquals(correlationId, CorrelationIdHolder.get());
	}

	@Test
	@DisplayName("Should not set null correlation ID")
	void testSetNull()
	{
		// Given
		CorrelationIdHolder.set("initial-id");

		// When
		CorrelationIdHolder.set(null);

		// Then
		assertEquals("initial-id", CorrelationIdHolder.get());
	}

	@Test
	@DisplayName("Should not set empty correlation ID")
	void testSetEmpty()
	{
		// Given
		CorrelationIdHolder.set("initial-id");

		// When
		CorrelationIdHolder.set("");

		// Then
		assertEquals("initial-id", CorrelationIdHolder.get());
	}

	@Test
	@DisplayName("Should get correlation ID from MDC")
	void testGet()
	{
		// Given
		String correlationId = "test-id-456";
		CorrelationIdHolder.set(correlationId);

		// When
		String retrieved = CorrelationIdHolder.get();

		// Then
		assertEquals(correlationId, retrieved);
	}

	@Test
	@DisplayName("Should return null when no correlation ID is set")
	void testGetWhenNotSet()
	{
		// When
		String retrieved = CorrelationIdHolder.get();

		// Then
		assertNull(retrieved);
	}

	@Test
	@DisplayName("Should clear correlation ID from MDC")
	void testClear()
	{
		// Given
		CorrelationIdHolder.set("test-id");

		// When
		CorrelationIdHolder.clear();

		// Then
		assertNull(CorrelationIdHolder.get());
	}

	@Test
	@DisplayName("Should clear all MDC context")
	void testClearAll()
	{
		// Given
		CorrelationIdHolder.set("test-id");

		// When
		CorrelationIdHolder.clearAll();

		// Then
		assertNull(CorrelationIdHolder.get());
	}

	@Test
	@DisplayName("Should get or generate when correlation ID exists")
	void testGetOrGenerateWhenExists()
	{
		// Given
		String existingId = "existing-correlation-id";
		CorrelationIdHolder.set(existingId);

		// When
		String retrieved = CorrelationIdHolder.getOrGenerate();

		// Then
		assertEquals(existingId, retrieved);
	}

	@Test
	@DisplayName("Should get or generate when correlation ID does not exist")
	void testGetOrGenerateWhenNotExists()
	{
		// When
		String generated = CorrelationIdHolder.getOrGenerate();

		// Then
		assertNotNull(generated);
		assertFalse(generated.isEmpty());
		assertTrue(
			generated.matches("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"));
		assertEquals(generated, CorrelationIdHolder.get());
	}

	@Test
	@DisplayName("Should get or generate when correlation ID is empty")
	void testGetOrGenerateWhenEmpty()
	{
		// Given - manually set empty string in MDC (bypassing set method)
		org.slf4j.MDC.put(CorrelationIdHolder.CORRELATION_ID_KEY, "");

		// When
		String generated = CorrelationIdHolder.getOrGenerate();

		// Then
		assertNotNull(generated);
		assertFalse(generated.isEmpty());
		assertTrue(
			generated.matches("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"));
	}

	@Test
	@DisplayName("Should handle multiple set operations")
	void testMultipleSetOperations()
	{
		// When
		CorrelationIdHolder.set("id-1");
		assertEquals("id-1", CorrelationIdHolder.get());

		CorrelationIdHolder.set("id-2");
		assertEquals("id-2", CorrelationIdHolder.get());

		CorrelationIdHolder.set("id-3");
		assertEquals("id-3", CorrelationIdHolder.get());
	}

	@Test
	@DisplayName("Should verify CORRELATION_ID_HEADER constant")
	void testCorrelationIdHeaderConstant()
	{
		// Then
		assertEquals("X-Correlation-ID", CorrelationIdHolder.CORRELATION_ID_HEADER);
	}

	@Test
	@DisplayName("Should verify CORRELATION_ID_KEY constant")
	void testCorrelationIdKeyConstant()
	{
		// Then
		assertEquals("correlationId", CorrelationIdHolder.CORRELATION_ID_KEY);
	}

	@Test
	@DisplayName("Should handle very long correlation ID")
	void testVeryLongCorrelationId()
	{
		// Given
		String longId = "a".repeat(1000);

		// When
		CorrelationIdHolder.set(longId);

		// Then
		assertEquals(longId, CorrelationIdHolder.get());
	}

	@Test
	@DisplayName("Should handle special characters in correlation ID")
	void testSpecialCharactersInCorrelationId()
	{
		// Given
		String specialId = "test-id_123.456:789@#$%";

		// When
		CorrelationIdHolder.set(specialId);

		// Then
		assertEquals(specialId, CorrelationIdHolder.get());
	}

	@Test
	@DisplayName("Should handle Unicode characters in correlation ID")
	void testUnicodeCharactersInCorrelationId()
	{
		// Given
		String unicodeId = "test-id-日本語-中文-한국어";

		// When
		CorrelationIdHolder.set(unicodeId);

		// Then
		assertEquals(unicodeId, CorrelationIdHolder.get());
	}

	@Test
	@DisplayName("Should handle whitespace in correlation ID")
	void testWhitespaceInCorrelationId()
	{
		// Given
		String idWithSpaces = "test id with spaces";

		// When
		CorrelationIdHolder.set(idWithSpaces);

		// Then
		assertEquals(idWithSpaces, CorrelationIdHolder.get());
	}

	@Test
	@DisplayName("Should handle clear when nothing is set")
	void testClearWhenNothingSet()
	{
		// When & Then
		assertDoesNotThrow(() -> CorrelationIdHolder.clear());
		assertNull(CorrelationIdHolder.get());
	}

	@Test
	@DisplayName("Should handle clearAll when nothing is set")
	void testClearAllWhenNothingSet()
	{
		// When & Then
		assertDoesNotThrow(() -> CorrelationIdHolder.clearAll());
		assertNull(CorrelationIdHolder.get());
	}

	@Test
	@DisplayName("Should generate different IDs on consecutive calls")
	void testConsecutiveGenerate()
	{
		// When
		String id1 = CorrelationIdHolder.generate();
		String id2 = CorrelationIdHolder.generate();
		String id3 = CorrelationIdHolder.generate();

		// Then
		assertNotEquals(id1, id2);
		assertNotEquals(id2, id3);
		assertNotEquals(id1, id3);

		// Last generated ID should be in MDC
		assertEquals(id3, CorrelationIdHolder.get());
	}

	@Test
	@DisplayName("Should handle set with whitespace-only string")
	void testSetWithWhitespaceOnly()
	{
		// Given
		CorrelationIdHolder.set("initial-id");

		// When
		CorrelationIdHolder.set("   ");

		// Then
		// Whitespace-only is not considered empty, so it should be set
		assertEquals("   ", CorrelationIdHolder.get());
	}

	@Test
	@DisplayName("Should verify utility class cannot be instantiated")
	void testUtilityClassCannotBeInstantiated()
	{
		assertEquals(0, CorrelationIdHolder.class.getConstructors().length);
	}
}
