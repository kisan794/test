package hireright.applications.vendor_api.vendor_api_client.exceptions;
/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	2017-09-11	Created
 */

public class ValidationException extends Exception {

    public ValidationException(String sMessage) {
        super(sMessage);
    }
}
