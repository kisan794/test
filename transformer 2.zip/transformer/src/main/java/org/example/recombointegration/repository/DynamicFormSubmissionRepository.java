package org.example.recombointegration.repository;

import org.example.recombointegration.document.DynamicFormSubmission;
import org.example.recombointegration.document.DynamicFormSubmission.SubmissionStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * MongoDB repository interface for DynamicFormSubmission document.
 * Provides database operations for dynamic form submissions.
 *
 * @author Generated
 * @version 1.0
 */
@Repository
public interface DynamicFormSubmissionRepository extends MongoRepository<DynamicFormSubmission, String> {

    /**
     * Find all submissions by formId.
     */
    Page<DynamicFormSubmission> findByFormId(String formId, Pageable pageable);

    /**
     * Find all submissions by formId and status.
     */
    Page<DynamicFormSubmission> findByFormIdAndStatus(String formId, SubmissionStatus status, Pageable pageable);

    /**
     * Find all submissions by status.
     */
    Page<DynamicFormSubmission> findByStatus(SubmissionStatus status, Pageable pageable);

    /**
     * Find all submissions by email address.
     */
    Page<DynamicFormSubmission> findByEmailAddress(String emailAddress, Pageable pageable);

    /**
     * Find submissions within a date range.
     */
    Page<DynamicFormSubmission> findBySubmissionDateBetween(
            LocalDateTime startDate, 
            LocalDateTime endDate, 
            Pageable pageable);

    /**
     * Find submissions by formId within a date range.
     */
    Page<DynamicFormSubmission> findByFormIdAndSubmissionDateBetween(
            String formId,
            LocalDateTime startDate,
            LocalDateTime endDate,
            Pageable pageable);

    /**
     * Search submissions by form data (searches in the formData map).
     * This uses MongoDB's text search on the formData field.
     */
    @Query("{ 'formId': ?0, $or: [ " +
           "{ 'formData.title': { $regex: ?1, $options: 'i' } }, " +
           "{ 'formData.description': { $regex: ?1, $options: 'i' } }, " +
           "{ 'formData.submittedBy': { $regex: ?1, $options: 'i' } } " +
           "] }")
    Page<DynamicFormSubmission> searchByFormIdAndKeyword(String formId, String keyword, Pageable pageable);

    /**
     * Find top submissions by upvote count for a specific form.
     */
    Page<DynamicFormSubmission> findByFormIdOrderByUpvoteCountDesc(String formId, Pageable pageable);

    /**
     * Count submissions by formId.
     */
    long countByFormId(String formId);

    /**
     * Count submissions by formId and status.
     */
    long countByFormIdAndStatus(String formId, SubmissionStatus status);

    /**
     * Count submissions by status.
     */
    long countByStatus(SubmissionStatus status);

    /**
     * Find all submissions assigned to a specific user.
     */
    Page<DynamicFormSubmission> findByAssignedTo(String assignedTo, Pageable pageable);

    /**
     * Find submissions by formId and assigned user.
     */
    Page<DynamicFormSubmission> findByFormIdAndAssignedTo(String formId, String assignedTo, Pageable pageable);
}

