package com.hireright.sourceintelligence.service;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch._types.ShardStatistics;
import co.elastic.clients.elasticsearch._types.query_dsl.Query;
import co.elastic.clients.elasticsearch.core.CreateResponse;
import co.elastic.clients.elasticsearch.core.DeleteResponse;
import co.elastic.clients.elasticsearch.core.GetResponse;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch.core.UpdateResponse;
import co.elastic.clients.elasticsearch.core.search.Hit;
import co.elastic.clients.elasticsearch.core.search.HitsMetadata;
import co.elastic.clients.elasticsearch.indices.ElasticsearchIndicesClient;
import co.elastic.clients.transport.endpoints.BooleanResponse;
import com.hireright.sourceintelligence.api.dto.AutoMatchDTO;
import com.hireright.sourceintelligence.api.dto.ElasticsearchDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.searchindex.entity.ElasticsearchSource;
import com.hireright.sourceintelligence.service.impl.DistanceAlgorithm;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchMapper;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.io.IOException;
import java.util.*;
import java.util.function.Function;

import static com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchConstants.SearchFields.APPROVAL_STATUS;
import static com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchConstants.SearchFields.STATUS;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class ElasticsearchServiceTest {

    @InjectMocks
    private ElasticsearchService elasticsearchService;

    @Mock
    private ElasticsearchMapper elasticsearchMapper;

    @Mock
    private ElasticsearchClient elasticsearchClient;

    @Mock
    private DistanceAlgorithm distanceAlgorithm;

    @Mock
    private ElasticsearchIndicesClient indicesClient;

    @BeforeEach
    void setUp() throws IOException {
        lenient().when(elasticsearchClient.indices()).thenReturn(indicesClient);

        BooleanResponse booleanResponse = mock(BooleanResponse.class);
        lenient().when(booleanResponse.value()).thenReturn(true);
        lenient().when(indicesClient.exists(any(Function.class))).thenReturn(booleanResponse);
    }

    private Source buildSource(String hon) {
        Source source = new Source();
        source.setHon(hon);
        source.setOrganizationType(OrganizationType.EDUCATION);
        return source;
    }

    private ElasticsearchSource buildEsSource(String hon) {
        ElasticsearchSource esSource = new ElasticsearchSource();
        esSource.setHon(hon);
        return esSource;
    }

    private SearchResponse<ElasticsearchSource> buildSearchResponse(List<Hit<ElasticsearchSource>> hits, double maxScore) {
        HitsMetadata<ElasticsearchSource> hitsMetadata = new HitsMetadata.Builder<ElasticsearchSource>()
                .hits(hits)
                .maxScore(maxScore)
                .build();

        ShardStatistics shards = new ShardStatistics.Builder()
                .total(1)
                .successful(1)
                .skipped(0)
                .failed(0)
                .build();

        return new SearchResponse.Builder<ElasticsearchSource>()
                .took(1)
                .timedOut(false)
                .shards(shards)
                .hits(hitsMetadata)
                .build();
    }

    private Hit<ElasticsearchSource> buildHit(String id, double score, ElasticsearchSource source) {
        return new Hit.Builder<ElasticsearchSource>()
                .id(id)
                .index("test_index")
                .score(score)
                .source(source)
                .build();
    }

    @Test
    void testCreateSource_shouldCreateWhenMappingPresentAndIndexExists() throws IOException {
        Source source = buildSource("HON123");
        ElasticsearchSource esSource = buildEsSource("HON123");

        when(elasticsearchMapper.sourceToSearchSourceMapping(source)).thenReturn(esSource);

        CreateResponse createResponse = mock(CreateResponse.class);
        when(elasticsearchClient.create(any(Function.class))).thenReturn(createResponse);

        elasticsearchService.createSource(source);

        verify(elasticsearchClient).create(any(Function.class));
    }

    @Test
    void testCreateSource_shouldDoNothingWhenMapperReturnsNull() throws IOException {
        Source source = buildSource("HON123");
        when(elasticsearchMapper.sourceToSearchSourceMapping(source)).thenReturn(null);

        elasticsearchService.createSource(source);

        verify(elasticsearchClient, never()).create(any(Function.class));
        verify(elasticsearchClient, never()).indices();
    }

    @Test
    void testCreateSource_shouldThrowWhenIndexDoesNotExist() throws IOException {
        Source source = buildSource("HON123");
        ElasticsearchSource esSource = buildEsSource("HON123");
        when(elasticsearchMapper.sourceToSearchSourceMapping(source)).thenReturn(esSource);

        BooleanResponse booleanResponse = mock(BooleanResponse.class);
        when(booleanResponse.value()).thenReturn(false);
        when(indicesClient.exists(any(Function.class))).thenReturn(booleanResponse);

        IOException ex = assertThrows(IOException.class, () -> elasticsearchService.createSource(source));
        assertTrue(ex.getMessage().contains("Elastic Index does not exists"));

        verify(elasticsearchClient, never()).create(any(Function.class));
    }

    @Test
    void testUpdateSourceIndex_shouldUpdateWhenDocumentExists() throws IOException, IllegalAccessException {
        Source source = buildSource("HON123");
        ElasticsearchSource newSource = buildEsSource("HON123");
        newSource.setCity(Collections.singletonList("Delhi"));

        ElasticsearchSource existingSource = buildEsSource("HON123");
        existingSource.setCity(Collections.singletonList("Mumbai"));

        @SuppressWarnings("unchecked")
        GetResponse<ElasticsearchSource> getResponse = mock(GetResponse.class);
        when(getResponse.id()).thenReturn("HON123");
        when(getResponse.source()).thenReturn(existingSource);
        when(elasticsearchMapper.sourceToSearchSourceMapping(source)).thenReturn(newSource);
        when(elasticsearchClient.get(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(getResponse);

        @SuppressWarnings("unchecked")
        UpdateResponse<ElasticsearchSource> updateResponse = mock(UpdateResponse.class);
        when(elasticsearchClient.update(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(updateResponse);

        elasticsearchService.updateSourceIndex(source);

        verify(elasticsearchClient).update(any(Function.class), eq(ElasticsearchSource.class));
    }

    @Test
    void testUpdateSourceIndex_shouldAddWhenDocumentDoesNotExist() throws IOException, IllegalAccessException {
        Source source = buildSource("HON123");
        ElasticsearchSource esSource = buildEsSource("HON123");

        @SuppressWarnings("unchecked")
        GetResponse<ElasticsearchSource> getResponse = mock(GetResponse.class);
        when(getResponse.id()).thenReturn("");
        when(elasticsearchMapper.sourceToSearchSourceMapping(source)).thenReturn(esSource);
        when(elasticsearchClient.get(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(getResponse);

        CreateResponse createResponse = mock(CreateResponse.class);
        when(elasticsearchClient.create(any(Function.class))).thenReturn(createResponse);

        elasticsearchService.updateSourceIndex(source);

        verify(elasticsearchClient).create(any(Function.class));
    }

    @Test
    void testUpdateSourceIndex_shouldDoNothingWhenMapperReturnsNull() throws IOException, IllegalAccessException {
        Source source = buildSource("HON123");
        when(elasticsearchMapper.sourceToSearchSourceMapping(source)).thenReturn(null);

        elasticsearchService.updateSourceIndex(source);

        verify(elasticsearchClient, never()).get(any(Function.class), eq(ElasticsearchSource.class));
        verify(elasticsearchClient, never()).update(any(Function.class), eq(ElasticsearchSource.class));
        verify(elasticsearchClient, never()).create(any(Function.class));
    }

    @Test
    void testUpdateStatusForSourceIndex_shouldUpdateWhenDocumentExists() throws IOException {
        Source source = buildSource("HON123");
        ElasticsearchSource existingSource = buildEsSource("HON123");

        @SuppressWarnings("unchecked")
        GetResponse<ElasticsearchSource> getResponse = mock(GetResponse.class);
        when(getResponse.id()).thenReturn("HON123");
        when(getResponse.source()).thenReturn(existingSource);
        when(elasticsearchClient.get(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(getResponse);

        @SuppressWarnings("unchecked")
        UpdateResponse<ElasticsearchSource> updateResponse = mock(UpdateResponse.class);
        when(elasticsearchClient.update(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(updateResponse);

        elasticsearchService.updateStatusForSourceIndex(source, "ACTIVE", "APPROVED");

        verify(elasticsearchClient).update(any(Function.class), eq(ElasticsearchSource.class));
        verify(elasticsearchClient, never()).create(any(Function.class));
    }

    @Test
    void testUpdateStatusForSourceIndex_shouldAddWhenDocumentMissingAndIndexExists() throws IOException {
        Source source = buildSource("HON123");
        ElasticsearchSource esSource = buildEsSource("HON123");

        @SuppressWarnings("unchecked")
        GetResponse<ElasticsearchSource> getResponse = mock(GetResponse.class);
        when(getResponse.id()).thenReturn("");
        when(elasticsearchClient.get(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(getResponse);
        when(elasticsearchMapper.sourceToSearchSourceMapping(source)).thenReturn(esSource);

        CreateResponse createResponse = mock(CreateResponse.class);
        when(elasticsearchClient.create(any(Function.class))).thenReturn(createResponse);

        elasticsearchService.updateStatusForSourceIndex(source, "INACTIVE", "REJECTED");

        verify(elasticsearchClient).create(any(Function.class));
        assertEquals("INACTIVE", esSource.getStatus());
        assertEquals("REJECTED", esSource.getApprovalStatus());
    }

    @Test
    void testUpdateStatusForSourceIndex_shouldDoNothingWhenDocumentMissingAndMapperReturnsNull() throws IOException {
        Source source = buildSource("HON123");

        @SuppressWarnings("unchecked")
        GetResponse<ElasticsearchSource> getResponse = mock(GetResponse.class);
        when(getResponse.id()).thenReturn("");
        when(elasticsearchClient.get(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(getResponse);
        when(elasticsearchMapper.sourceToSearchSourceMapping(source)).thenReturn(null);

        elasticsearchService.updateStatusForSourceIndex(source, "ACTIVE", "APPROVED");

        verify(elasticsearchClient, never()).create(any(Function.class));
    }

    @Test
    void testUpdateStatusForSourceIndex_shouldDoNothingWhenDocumentMissingAndIndexNotExists() throws IOException {
        Source source = buildSource("HON123");
        ElasticsearchSource esSource = buildEsSource("HON123");

        @SuppressWarnings("unchecked")
        GetResponse<ElasticsearchSource> getResponse = mock(GetResponse.class);
        when(getResponse.id()).thenReturn("");
        when(elasticsearchClient.get(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(getResponse);
        when(elasticsearchMapper.sourceToSearchSourceMapping(source)).thenReturn(esSource);

        BooleanResponse booleanResponse = mock(BooleanResponse.class);
        when(booleanResponse.value()).thenReturn(false);
        when(indicesClient.exists(any(Function.class))).thenReturn(booleanResponse);

        elasticsearchService.updateStatusForSourceIndex(source, "ACTIVE", "APPROVED");

        verify(elasticsearchClient, never()).create(any(Function.class));
    }

    @Test
    void testIndexExists_shouldReturnTrue() throws IOException {
        assertTrue(elasticsearchService.indexExists("education_source"));
        verify(indicesClient).exists(any(Function.class));
    }

    @Test
    void testAddSource_shouldCreateDocument() throws IOException {
        ElasticsearchSource sourceDoc = buildEsSource("HON123");
        CreateResponse createResponse = mock(CreateResponse.class);
        when(elasticsearchClient.create(any(Function.class))).thenReturn(createResponse);

        elasticsearchService.addSource(sourceDoc, "education_source");

        verify(elasticsearchClient).create(any(Function.class));
    }

    @Test
    void testUpdateSourcePartial_shouldUpdateDocument() throws IOException {
        @SuppressWarnings("unchecked")
        UpdateResponse<ElasticsearchSource> updateResponse = mock(UpdateResponse.class);
        when(elasticsearchClient.update(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(updateResponse);

        Map<String, Object> updatedFields = new HashMap<>();
        updatedFields.put("city", "Delhi");

        elasticsearchService.updateSourcePartial("education_source", "HON123", updatedFields);

        verify(elasticsearchClient).update(any(Function.class), eq(ElasticsearchSource.class));
    }

    @Test
    void testDeleteSourceByHon_shouldDeleteUsingDerivedIndex() throws IOException {
        DeleteResponse deleteResponse = mock(DeleteResponse.class);
        when(elasticsearchClient.delete(any(Function.class))).thenReturn(deleteResponse);

        elasticsearchService.deleteSourceByHon("EDU123");

        verify(elasticsearchClient).delete(any(Function.class));
    }

    @Test
    void testDeleteSource_shouldDeleteDocument() throws IOException {
        DeleteResponse deleteResponse = mock(DeleteResponse.class);
        when(elasticsearchClient.delete(any(Function.class))).thenReturn(deleteResponse);

        elasticsearchService.deleteSource("HON123", "education_source");

        verify(elasticsearchClient).delete(any(Function.class));
    }

    @Test
    void testGetSourceById_shouldReturnResponse() throws IOException {
        @SuppressWarnings("unchecked")
        GetResponse<ElasticsearchSource> getResponse = mock(GetResponse.class);
        when(elasticsearchClient.get(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(getResponse);

        GetResponse<ElasticsearchSource> result = elasticsearchService.getSourceById("education_source", "HON123");

        assertNotNull(result);
        verify(elasticsearchClient).get(any(Function.class), eq(ElasticsearchSource.class));
    }

    @Test
    void testGetSourceByHon_shouldReturnSearchResponse() throws IOException {
        SearchResponse<ElasticsearchSource> response = buildSearchResponse(Collections.emptyList(), 0.0);
        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(response);

        SearchResponse<ElasticsearchSource> result = elasticsearchService.getSourceByHon("education_source", "HON123");

        assertNotNull(result);
        verify(elasticsearchClient).search(any(Function.class), eq(ElasticsearchSource.class));
    }

    @Test
    void testGetSourceByHon_shouldReturnNullOnException() throws IOException {
        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class)))
                .thenThrow(new IOException("failure"));

        SearchResponse<ElasticsearchSource> result = elasticsearchService.getSourceByHon("education_source", "HON123");

        assertNull(result);
    }

    @Test
    void testSmartSearch_shouldReturnEmptySetWhenResponseNull() {
        ElasticsearchDTO dto = new ElasticsearchDTO();
        dto.setOrganizationName("Test Org");

        ElasticsearchService spyService = spy(elasticsearchService);

        doReturn(null).when(spyService)
                .searchWithProject(any(Query.class), anyString(), anyInt(), anyDouble(), any(String[].class));

        Set<String> result = spyService.smartSearch(dto, "education_source", false);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testSmartSearch_shouldReturnEmptySetWhenHitsEmpty() throws IOException {
        ElasticsearchDTO dto = new ElasticsearchDTO();
        dto.setOrganizationName("Test Org");

        SearchResponse<ElasticsearchSource> response = buildSearchResponse(Collections.emptyList(), 0.0);
        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(response);

        Set<String> result = elasticsearchService.smartSearch(dto, "education_source", false);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testSmartSearch_shouldUseDropDownLogicWhenOrganizationNameIsNull() throws IOException {
        ElasticsearchDTO dto = new ElasticsearchDTO();
        dto.setOrganizationName(null);

        ElasticsearchSource source = buildEsSource("HON123");
        Hit<ElasticsearchSource> hit = buildHit("HON123", 200.0, source);
        SearchResponse<ElasticsearchSource> response = buildSearchResponse(List.of(hit), 200.0);

        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(response);

        Set<String> result = elasticsearchService.smartSearch(dto, "education_source", false);

        assertEquals(Set.of("HON123"), result);
    }

    @Test
    void testSmartSearch_shouldUseDropDownLogicWhenDropDownSelectedTrue() throws IOException {
        ElasticsearchDTO dto = new ElasticsearchDTO();
        dto.setOrganizationName("DropDown Org");

        ElasticsearchSource source = buildEsSource("HON777");
        Hit<ElasticsearchSource> hit = buildHit("HON777", 400.0, source);
        SearchResponse<ElasticsearchSource> response = buildSearchResponse(List.of(hit), 400.0);

        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(response);

        Set<String> result = elasticsearchService.smartSearch(dto, "education_source", true);

        assertEquals(Set.of("HON777"), result);
    }

//    @Test
//    void testSmartSearch_shouldUseExactLogicWhenFirstScoreAtLeast300() throws IOException {
//        ElasticsearchDTO dto = new ElasticsearchDTO();
//        dto.setOrganizationName("Test Org");
//
//        ElasticsearchSource source1 = buildEsSource("HON123");
//        ElasticsearchSource source2 = buildEsSource("HON124");
//
//        Hit<ElasticsearchSource> hit1 = buildHit("HON123", 350.0, source1);
//        Hit<ElasticsearchSource> hit2 = buildHit("HON124", 250.0, source2);
//
//        SearchResponse<ElasticsearchSource> response = buildSearchResponse(List.of(hit1, hit2), 350.0);
//        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(response);
//
//        Set<String> result = elasticsearchService.smartSearch(dto, "education_source", false);
//
//        assertTrue(result.contains("HON123"));
//        assertFalse(result.contains("HON124"));
//    }

    @Test
    void testSmartSearch_shouldUseJaroLogicWhenFirstScoreBelow300() throws IOException {
        ElasticsearchDTO dto = new ElasticsearchDTO();
        dto.setOrganizationName("Test Org");

        ElasticsearchSource source = buildEsSource("HON999");
        Hit<ElasticsearchSource> hit = buildHit("HON999", 150.0, source);
        SearchResponse<ElasticsearchSource> response = buildSearchResponse(List.of(hit), 150.0);

        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(response);
        when(distanceAlgorithm.smartSearchJaroWinklerAlgorithmWithText(anyString(), anyList(), anyString()))
                .thenReturn(Set.of("HON999"));

        Set<String> result = elasticsearchService.smartSearch(dto, "education_source", false);

        assertEquals(Set.of("HON999"), result);
        verify(distanceAlgorithm).smartSearchJaroWinklerAlgorithmWithText(eq("test org"), anyList(), anyString());
    }

    @Test
    void testDropDownSearch_shouldReturnResults() throws IOException {
        ElasticsearchDTO dto = new ElasticsearchDTO();

        ElasticsearchSource source = buildEsSource("HON123");
        Hit<ElasticsearchSource> hit = buildHit("HON123", 100.0, source);
        SearchResponse<ElasticsearchSource> response = buildSearchResponse(List.of(hit), 100.0);

        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(response);

        List<ElasticsearchSource> result = elasticsearchService.dropDownSearch(dto, "education_source");

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("HON123", result.get(0).getHon());
    }

    @Test
    void testDropDownSearch_shouldReturnEmptyListWhenResponseNull() throws IOException {
        ElasticsearchDTO dto = new ElasticsearchDTO();
        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class)))
                .thenThrow(new IOException("search failed"));

        List<ElasticsearchSource> result = elasticsearchService.dropDownSearch(dto, "education_source");

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testDropDownSearch_shouldReturnEmptyListWhenNoHits() throws IOException {
        ElasticsearchDTO dto = new ElasticsearchDTO();
        SearchResponse<ElasticsearchSource> response = buildSearchResponse(Collections.emptyList(), 0.0);
        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(response);

        List<ElasticsearchSource> result = elasticsearchService.dropDownSearch(dto, "education_source");

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testAutoMatchSearch_shouldDelegateToSearch() {
        AutoMatchDTO dto = new AutoMatchDTO();
        ElasticsearchSource source = buildEsSource("HON123");

        ElasticsearchService spyService = spy(elasticsearchService);
        doReturn(List.of(source)).when(spyService).search(any(Query.class), eq("education_source"), eq(15));

        List<ElasticsearchSource> result = spyService.autoMatchSearch(dto, "education_source");

        assertEquals(1, result.size());
        assertEquals("HON123", result.get(0).getHon());
    }

    @Test
    void testNonUSAutoMatchSearch_shouldDelegateToSearch() {
        AutoMatchDTO dto = new AutoMatchDTO();
        ElasticsearchSource source = buildEsSource("HON999");

        ElasticsearchService spyService = spy(elasticsearchService);
        doReturn(List.of(source)).when(spyService).search(any(Query.class), eq("education_source"), eq(25));

        List<ElasticsearchSource> result = spyService.nonUSAutoMatchSearch(dto, "education_source");

        assertEquals(1, result.size());
        assertEquals("HON999", result.get(0).getHon());
    }

    @Test
    void testSearch_shouldReturnResults() throws IOException {
        Query query = mock(Query.class);
        ElasticsearchSource source = buildEsSource("HON123");
        Hit<ElasticsearchSource> hit = buildHit("HON123", 10.0, source);
        SearchResponse<ElasticsearchSource> response = buildSearchResponse(List.of(hit), 10.0);

        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(response);

        List<ElasticsearchSource> result = elasticsearchService.search(query, "education_source", 10);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("HON123", result.get(0).getHon());
    }

    @Test
    void testSearch_shouldReturnEmptyListOnException() throws IOException {
        Query query = mock(Query.class);
        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class)))
                .thenThrow(new IOException("failure"));

        List<ElasticsearchSource> result = elasticsearchService.search(query, "education_source", 10);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testSearchWithProject_shouldReturnResponse() throws IOException {
        Query query = mock(Query.class);
        SearchResponse<ElasticsearchSource> response = buildSearchResponse(Collections.emptyList(), 0.0);

        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(response);

        SearchResponse<ElasticsearchSource> result = elasticsearchService.searchWithProject(
                query, "education_source", 5, 10.0, "hon", "organizationName"
        );

        assertNotNull(result);
    }

    @Test
    void testSearchWithProject_shouldReturnNullOnException() throws IOException {
        Query query = mock(Query.class);

        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class)))
                .thenThrow(new IOException("failure"));

        SearchResponse<ElasticsearchSource> result = elasticsearchService.searchWithProject(
                query, "education_source", 5, 10.0, "hon", "organizationName"
        );

        assertNull(result);
    }

    @Test
    void testGetUpdatedFields_shouldReturnOnlyChangedNonNullFields() throws IllegalAccessException {
        ElasticsearchSource existing = new ElasticsearchSource();
        existing.setHon("HON123");
        existing.setCity(Collections.singletonList("Mumbai"));
        existing.setStatus("OLD_STATUS");
        existing.setApprovalStatus("OLD_APPROVAL");

        ElasticsearchSource updated = new ElasticsearchSource();
        updated.setHon("HON123");
        updated.setCity(Collections.singletonList("Delhi"));
        updated.setStatus("NEW_STATUS");
        updated.setApprovalStatus(null);

        Map<String, Object> result = elasticsearchService.getUpdatedFields(updated, existing);

        assertTrue(result.containsKey("city"));
        assertTrue(result.containsKey("status"));
        assertFalse(result.containsKey("hon"));
        assertFalse(result.containsKey("approvalStatus"));
        assertEquals(Collections.singletonList("Delhi"), result.get("city"));
        assertEquals("NEW_STATUS", result.get("status"));
    }

    @Test
    void testGetUpdatedFields_shouldReturnEmptyMapWhenNothingChanged() throws IllegalAccessException {
        ElasticsearchSource existing = new ElasticsearchSource();
        existing.setHon("HON123");
        existing.setCity(Collections.singletonList("Delhi"));

        ElasticsearchSource updated = new ElasticsearchSource();
        updated.setHon("HON123");
        updated.setCity(Collections.singletonList("Delhi"));

        Map<String, Object> result = elasticsearchService.getUpdatedFields(updated, existing);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testUpdateStatusForSourceIndex_shouldPrepareExpectedUpdatedFieldsWhenExists() throws IOException {
        Source source = buildSource("HON123");
        ElasticsearchSource existingSource = buildEsSource("HON123");

        @SuppressWarnings("unchecked")
        GetResponse<ElasticsearchSource> getResponse = mock(GetResponse.class);
        when(getResponse.id()).thenReturn("HON123");
        when(getResponse.source()).thenReturn(existingSource);
        when(elasticsearchClient.get(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(getResponse);

        @SuppressWarnings("unchecked")
        UpdateResponse<ElasticsearchSource> updateResponse = mock(UpdateResponse.class);
        when(elasticsearchClient.update(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(updateResponse);

        elasticsearchService.updateStatusForSourceIndex(source, "ACTIVE", "APPROVED");

        verify(elasticsearchClient).update(any(Function.class), eq(ElasticsearchSource.class));
    }

    @Test
    void testUpdateSourceIndex_shouldIncludeActiveStatusInUpdatedFieldsPath() throws IOException, IllegalAccessException {
        Source source = buildSource("HON123");

        ElasticsearchSource newSource = buildEsSource("HON123");
        newSource.setCity(Collections.singletonList("Delhi"));

        ElasticsearchSource existingSource = buildEsSource("HON123");
        existingSource.setCity(Collections.singletonList("Mumbai"));

        @SuppressWarnings("unchecked")
        GetResponse<ElasticsearchSource> getResponse = mock(GetResponse.class);
        when(getResponse.id()).thenReturn("HON123");
        when(getResponse.source()).thenReturn(existingSource);

        when(elasticsearchMapper.sourceToSearchSourceMapping(source)).thenReturn(newSource);
        when(elasticsearchClient.get(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(getResponse);

        @SuppressWarnings("unchecked")
        UpdateResponse<ElasticsearchSource> updateResponse = mock(UpdateResponse.class);
        when(elasticsearchClient.update(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(updateResponse);

        ElasticsearchService spyService = spy(elasticsearchService);

        ArgumentCaptor<Map<String, Object>> fieldsCaptor = ArgumentCaptor.forClass(Map.class);
        doNothing().when(spyService).updateSourcePartial(eq("education_source"), eq("HON123"), fieldsCaptor.capture());

        spyService.updateSourceIndex(source);

        Map<String, Object> captured = fieldsCaptor.getValue();
        assertEquals(Collections.singletonList("Delhi"), captured.get("city"));
        assertEquals("ACTIVE", captured.get(STATUS));
    }

    @Test
    void testUpdateStatusForSourceIndex_shouldSetStatusAndApprovalBeforeCreate() throws IOException {
        Source source = buildSource("HON123");
        ElasticsearchSource esSource = buildEsSource("HON123");

        @SuppressWarnings("unchecked")
        GetResponse<ElasticsearchSource> getResponse = mock(GetResponse.class);
        when(getResponse.id()).thenReturn("");
        when(elasticsearchClient.get(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(getResponse);
        when(elasticsearchMapper.sourceToSearchSourceMapping(source)).thenReturn(esSource);

        CreateResponse createResponse = mock(CreateResponse.class);
        when(elasticsearchClient.create(any(Function.class))).thenReturn(createResponse);

        elasticsearchService.updateStatusForSourceIndex(source, "ACTIVE", "APPROVED");

        assertEquals("ACTIVE", esSource.getStatus());
        assertEquals("APPROVED", esSource.getApprovalStatus());
        verify(elasticsearchClient).create(any(Function.class));
    }

    @Test
    void testSuggestionsSearch_shouldReturnResults() throws IOException {
        ElasticsearchDTO dto = new ElasticsearchDTO();

        ElasticsearchSource source = buildEsSource("HON123");
        Hit<ElasticsearchSource> hit = buildHit("HON123", 10.0, source);
        SearchResponse<ElasticsearchSource> response = buildSearchResponse(List.of(hit), 10.0);

        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(response);

        List<ElasticsearchSource> result = elasticsearchService.suggestionsSearch(dto, "education_source");

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("HON123", result.get(0).getHon());
    }
}
