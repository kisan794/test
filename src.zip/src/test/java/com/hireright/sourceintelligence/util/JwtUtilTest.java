package com.hireright.sourceintelligence.util;
import com.hireright.sourceintelligence.api.dto.UserKeyDTO;
import com.hireright.sourceintelligence.api.dto.UserLoginDetailsDTO;
import org.junit.jupiter.api.Test;

import java.util.Base64;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;

public class JwtUtilTest {

    /*@Test
    void generateToken_shouldReturnValidJwt() {
        UserKeyDTO dto = new UserKeyDTO();
        dto.setKind("user");
        dto.setData(Collections.emptyList());
        String token = JwtUtil.generateToken(dto);
        assertNotNull(token);
        assertEquals(3, token.split("\\.").length);
        String[] parts = token.split("\\.");
        String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
        assertTrue(payload.contains("user"));
    }*/

  /*  @Test
    void generateToken_shouldThrowException_whenSerializationFails() {
        UserLoginDetailsDTO brokenDto = new UserLoginDetailsDTO() {
            @Override
            public String getKind() {
                throw new RuntimeException("Force fail");
            }
        };

        assertThrows(RuntimeException.class, () -> JwtUtil.generateToken(brokenDto));
    }*/
}
