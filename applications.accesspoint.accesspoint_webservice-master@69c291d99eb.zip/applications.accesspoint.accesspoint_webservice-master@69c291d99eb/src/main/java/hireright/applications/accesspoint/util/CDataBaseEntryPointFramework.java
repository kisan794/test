/*
 * @(#)$RCSfile: CDataBaseEntryPointFramework.java,v $ $Revision: 1.3.2.2 $ $Date: 2015/03/16 14:22:43 $ $Author: atanasenko $ 
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/util/CDataBaseEntryPointFramework.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *     $Log: CDataBaseEntryPointFramework.java,v $
 *     Revision 1.3.2.2  2015/03/16 14:22:43  atanasenko
 *     438975: Internal: Access Point issue: webapp is not closing db connections properly (part 2)
 *
 *     Revision 1.3.2.1  2015/03/16 14:22:18  atanasenko
 *     438975: Internal: Access Point issue: webapp is not closing db connections properly (part 2)
 *
 *     Revision 1.3  2014/11/22 08:28:24  cvsroot
 *     Merged with accesspoint_webservice_v4-0 Revision: 1.2.2.2 (automatically)
 *
 *     Revision 1.2.2.2  2014/11/11 15:44:21  aputintsev
 *     no message
 *
 *     Revision 1.2.2.1  2014/11/11 15:43:59  aputintsev
 *     no message
 *
 *     Revision 1.2  2014/07/28 14:57:10  aputintsev
 *     forked from production version - projects_src/applications/accesspoint
 *
 *     Revision 1.1.2.1.2.2  2009/08/18 11:09:20  asolntsev
 *     Bugfixing and polishing
 *
 *     Revision 1.1.2.1.2.1  2009/08/17 14:36:50  asolntsev
 *     created unit tests
 *
 *     Revision 1.1.2.1  2009/08/13 13:24:24  asolntsev
 *     Created by St.Petersburg team
 *
 *     Revision 1.3  2009/08/06 13:21:52  banton
 *     Phase 1.1 Edition
 *
 *     Revision 1.2  2009/08/06 10:38:24  banton
 *     Fixed deleteEntryPointByKey method for DB storage
 *
 *     Revision 1.1  2009/08/06 09:37:55  banton
 *     Added simple Finite State Machine support. Tested only for memory storage
 *
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hireright.applications.accesspoint.util;

import hireright.objects.utilities.CDomain;
import hireright.objects.utilities.CEntryPoint;
import hireright.objects.utilities.CEntryPointFactory;
import hireright.sdk.db.CConnection;
import hireright.sdk.db.CCurrentThreadConnection;
import hireright.sdk.db.CDBRuntimeException;
import hireright.sdk.util.CProperties;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.collections.MultiMap;

/**
 *
 * @author banton
 */
public class CDataBaseEntryPointFramework 
		// extends CBaseEntryPointFramework
	implements IEntryPointFramework
{
	private static final Logger LOGGER  = Logger.getLogger(CDataBaseEntryPointFramework.class.getName());
	
	private static final ThreadLocal<Connection> currentConnection = new ThreadLocal<Connection>();
	
	public void setUp()
	{
		if(CCurrentThreadConnection.getConnection() == null)
		{
			currentConnection.set(CConnection.initThreadLocalConnection());
		}
	}
	
	public void tearDown()
	{
		Connection conn = currentConnection.get();
		currentConnection.set(null);
		if(conn != null)
		{
			CConnection.closeConnection( conn );
			CCurrentThreadConnection.unbind();
		}
	}
	
	public void commit()
	{
		final Connection conn = CCurrentThreadConnection.getConnection();
		try
		{
			conn.commit();
		}
		catch ( SQLException ex )
		{
			LOGGER.log( Level.WARNING, null, ex );
			throw new CDBRuntimeException(ex);
		}
	}
	
	public void rollback()
	{
		final Connection conn = CCurrentThreadConnection.getConnection();
		CConnection.rollback( conn );
	}

	public CEntryPoint createEntryPointAuth( String userID, String userClass, String login, String entryPointType,
			Integer designNumber, String domainID, MultiMap entryPointParams )
	{
		CDomain domain = CDomain.loadDomain( domainID );
		CEntryPoint entryPoint = CEntryPointFactory.createEntryPoint( userID, userClass, login, entryPointType,
				designNumber, domain, CProperties.NO_PROPERTIES );

		entryPoint.setMultiProperties( entryPointParams );
		return entryPoint;
	}

	public CEntryPoint createEntryPointNoAuth( String userID, String userClass, String entryPointType,
			Integer designNumber, String domainID, MultiMap entryPointParams )
	{		
		CDomain domain = CDomain.loadDomain( domainID );
		CEntryPoint entryPoint = CEntryPointFactory.createEntryPoint( entryPointType, userClass,
				Integer.valueOf( userID ), designNumber, domain, CProperties.NO_PROPERTIES );

		entryPoint.setMultiProperties( entryPointParams );
		return entryPoint;
	}


		public CEntryPoint getEntryPoint(String key)
		{
				return CEntryPoint.get(key);
		}

		public void saveEntryPoint(CEntryPoint entryPoint)
		{
			entryPoint.save();
		}

		public void deleteEntryPointByKey(String key)
		{
			CEntryPoint entryPoint = CEntryPoint.get(key);
			if (entryPoint==null)
					return;

			entryPoint.delete();
		}

		public void deleteEntryPoint(CEntryPoint entryPoint)
		{
			entryPoint.delete();
		}
}
