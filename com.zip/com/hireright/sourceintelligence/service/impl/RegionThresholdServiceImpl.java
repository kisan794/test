package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.v2.dto.RegionThresholdDTO;
import com.hireright.sourceintelligence.domain.entity.RegionThreshold;
import com.hireright.sourceintelligence.domain.repository.RegionThresholdRepository;
import com.hireright.sourceintelligence.service.RegionThresholdService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.APROVAL_REGION_THRESHOLD;
import static com.hireright.sourceintelligence.constants.ErrorConstants.SOURCE_NOT_FOUND;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowResourceNotFound;


@Primary
@Slf4j
@RequiredArgsConstructor
@Transactional
@Service
public class RegionThresholdServiceImpl implements RegionThresholdService {

    private final RegionThresholdRepository regionThresholdRepository;

    @Override
    public RegionThresholdDTO getRegions() {
        RegionThresholdDTO regionThresholdDTO = new RegionThresholdDTO();
        RegionThreshold regionThreshold = regionThresholdRepository.findByThresholdType(APROVAL_REGION_THRESHOLD);
        if (regionThreshold == null) {
            logAndThrowResourceNotFound(SOURCE_NOT_FOUND, null, APROVAL_REGION_THRESHOLD);
        }
        if(regionThreshold != null) {
            return new RegionThresholdDTO(
                    regionThreshold.getEMEA(),
                    regionThreshold.getLATAM(),
                    regionThreshold.getCANADA(),
                    regionThreshold.getAPAC(),
                    regionThreshold.getAUSTRALIA(),
                    regionThreshold.getINDIA(),
                    regionThreshold.getUS());
        }
        return regionThresholdDTO;
    }

    @Override
    public RegionThresholdDTO getRegionByType(String thresholdType) {
        RegionThreshold regionThreshold = regionThresholdRepository.findByThresholdType(thresholdType);
        if (regionThreshold == null) {
            logAndThrowResourceNotFound(SOURCE_NOT_FOUND, null, thresholdType);
            return null;
        }
        return new RegionThresholdDTO(
                regionThreshold.getEMEA(),
                regionThreshold.getLATAM(),
                regionThreshold.getCANADA(),
                regionThreshold.getAPAC(),
                regionThreshold.getAUSTRALIA(),
                regionThreshold.getINDIA(),
                regionThreshold.getUS());
    }

    @Override
    public RegionThresholdDTO updateRegionThreshold(RegionThresholdDTO regionThreshold) {
        RegionThreshold existingThreshold = regionThresholdRepository.findByThresholdType(APROVAL_REGION_THRESHOLD);

        if (regionThreshold == null) {
            logAndThrowResourceNotFound(SOURCE_NOT_FOUND, null, APROVAL_REGION_THRESHOLD);
            return null;
        }

        // Update fields with new values
        existingThreshold.setEMEA(regionThreshold.getEMEA());
        existingThreshold.setLATAM(regionThreshold.getLATAM());
        existingThreshold.setCANADA(regionThreshold.getCANADA());
        existingThreshold.setAPAC(regionThreshold.getAPAC());
        existingThreshold.setAUSTRALIA(regionThreshold.getAUSTRALIA());
        existingThreshold.setINDIA(regionThreshold.getINDIA());
        existingThreshold.setUS(regionThreshold.getUS());

        // Save the updated document
        RegionThreshold savedThresholds = regionThresholdRepository.save(existingThreshold);

        return new RegionThresholdDTO(
                savedThresholds.getEMEA(),
                savedThresholds.getLATAM(),
                savedThresholds.getCANADA(),
                savedThresholds.getAPAC(),
                savedThresholds.getAUSTRALIA(),
                savedThresholds.getINDIA(),
                savedThresholds.getUS()
        );
    }
}