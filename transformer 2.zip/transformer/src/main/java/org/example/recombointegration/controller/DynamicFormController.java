package org.example.recombointegration.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.recombointegration.document.FormTemplate;
import org.example.recombointegration.service.DynamicFormService;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Controller for Dynamic Form Configuration.
 * Provides endpoints for retrieving complete form structures for UI rendering.
 * This enables the frontend to dynamically render forms without code changes.
 *
 * @author Generated
 * @version 1.0
 */
@Tag(name = "Dynamic Form Configuration", description = "APIs for retrieving dynamic form configurations for UI rendering")
@Slf4j
@RestController
@RequestMapping("/api/v1/forms")
@RequiredArgsConstructor
public class DynamicFormController {

    private final DynamicFormService dynamicFormService;

    /**
     * Get form configuration by formId.
     * This endpoint returns the complete form structure including all sections, fields,
     * validation rules, and UI settings.
     */
    @Operation(
            summary = "Get form configuration",
            description = "Retrieve complete form configuration by formId. Returns all sections, fields, validation rules, and UI settings for dynamic form rendering."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Form configuration retrieved successfully",
                    content = @Content(schema = @Schema(implementation = FormTemplate.class))),
            @ApiResponse(responseCode = "404", description = "Form configuration not found")
    })
    @GetMapping(value = "/{formId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<FormTemplate> getFormConfiguration(
            @Parameter(description = "Unique identifier of the form (e.g., 'idea-submission-form')", required = true)
            @PathVariable String formId) {
        log.info("Received request to get form configuration for formId: {}", formId);
        FormTemplate formTemplate = dynamicFormService.getFormConfiguration(formId);
        return ResponseEntity.ok(formTemplate);
    }

    /**
     * Get all active form configurations.
     * Returns a list of all active form templates available in the system.
     */
    @Operation(
            summary = "Get all active forms",
            description = "Retrieve all active form configurations available in the system."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Form configurations retrieved successfully",
                    content = @Content(schema = @Schema(implementation = FormTemplate.class)))
    })
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<FormTemplate>> getAllActiveFormConfigurations() {
        log.info("Received request to get all active form configurations");
        List<FormTemplate> formTemplates = dynamicFormService.getAllActiveFormConfigurations();
        return ResponseEntity.ok(formTemplates);
    }

    /**
     * Initialize default Idea Submission form.
     * This endpoint creates/updates the default Idea Submission form configuration.
     * Useful for initial setup or resetting to default configuration.
     */
    @Operation(
            summary = "Initialize Idea Submission form",
            description = "Create or update the default Idea Submission form configuration. This is useful for initial setup or resetting to default."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Form configuration initialized successfully",
                    content = @Content(schema = @Schema(implementation = FormTemplate.class)))
    })
    @PostMapping(value = "/initialize/idea-submission", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<FormTemplate> initializeIdeaSubmissionForm() {
        log.info("Received request to initialize Idea Submission form configuration");
        FormTemplate formTemplate = dynamicFormService.initializeIdeaSubmissionForm();
        return ResponseEntity.status(HttpStatus.CREATED).body(formTemplate);
    }

    /**
     * Create or update form configuration.
     * This endpoint allows administrators to create new or update existing form configurations.
     */
    @Operation(
            summary = "Create or update form configuration",
            description = "Create a new form configuration or update an existing one. This allows administrators to customize forms dynamically."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Form configuration saved successfully",
                    content = @Content(schema = @Schema(implementation = FormTemplate.class))),
            @ApiResponse(responseCode = "201", description = "Form configuration created successfully",
                    content = @Content(schema = @Schema(implementation = FormTemplate.class)))
    })
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<FormTemplate> saveFormConfiguration(
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Form template configuration to save",
                    required = true
            )
            @RequestBody FormTemplate formTemplate) {
        log.info("Received request to save form configuration: {}", formTemplate.getFormId());
        FormTemplate savedTemplate = dynamicFormService.saveFormConfiguration(formTemplate);
        HttpStatus status = formTemplate.getId() == null ? HttpStatus.CREATED : HttpStatus.OK;
        return ResponseEntity.status(status).body(savedTemplate);
    }

    /**
     * Health check endpoint for form configuration service.
     */
    @Operation(
            summary = "Health check",
            description = "Check if the form configuration service is running."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service is healthy")
    })
    @GetMapping("/health")
    public ResponseEntity<String> healthCheck() {
        return ResponseEntity.ok("Dynamic Form Configuration Service is running");
    }
}

