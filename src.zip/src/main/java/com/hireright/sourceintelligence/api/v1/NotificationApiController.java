package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.notification.NotificationRequestDTO;
import com.hireright.sourceintelligence.api.dto.notification.NotificationResponseDTO;
import com.hireright.sourceintelligence.api.dto.notification.NotificationStatus;
import com.hireright.sourceintelligence.service.notification.NotificationService;
import com.hireright.sourceintelligence.service.notification.NotificationServiceFactory;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;

/**
 * REST Controller for notification operations.
 * Follows Single Responsibility Principle - only handles HTTP request/response mapping.
 * Delegates business logic to service layer.
 */
@Slf4j
@RestController
@RequiredArgsConstructor
@Validated
@CrossOrigin
public class NotificationApiController implements NotificationApi {
    
    private final NotificationServiceFactory notificationServiceFactory;
    
    /**
     * Sends a notification based on the request type
     */
    @Override
    public ResponseEntity<NotificationResponseDTO> sendNotification(
            @Valid NotificationRequestDTO request) {
        
        log.info("Received notification request - type: {}, async: {}, requestId: {}", 
                request.getNotificationType(), 
                request.getAsync(), 
                request.getRequestId());
        
        try {
            // Set created timestamp if not provided
            if (request.getCreatedAt() == null) {
                request.setCreatedAt(Instant.now().toString());
            }
            
            // Get appropriate service based on notification type
            NotificationService service = notificationServiceFactory.getService(request);
            
            // Send notification
            NotificationResponseDTO response = service.sendNotification(request);
            
            // Determine HTTP status based on notification status
            HttpStatus httpStatus = determineHttpStatus(response.getStatus());
            
            log.info("Notification processed - status: {}, notificationId: {}", 
                    response.getStatus(), 
                    response.getNotificationId());
            
            return ResponseEntity.status(httpStatus).body(response);
            
        } catch (Exception e) {
            log.error("Error processing notification request", e);
            
            // Error responses are handled by GlobalExceptionHandler
            // This is a fallback in case the exception handler doesn't catch it
            NotificationResponseDTO errorResponse = NotificationResponseDTO.builder()
                    .status(NotificationStatus.FAILED)
                    .message("Failed to process notification")
                    .requestId(request.getRequestId())
                    .errorCode("PROCESSING_ERROR")
                    .errorDetails(e.getMessage())
                    .build();
            
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
    
    /**
     * Determines HTTP status code based on notification status
     */
    private HttpStatus determineHttpStatus(NotificationStatus status) {
        return switch (status) {
            case SUCCESS -> HttpStatus.OK;
            case QUEUED -> HttpStatus.ACCEPTED;
            case FAILED -> HttpStatus.INTERNAL_SERVER_ERROR;
            default -> HttpStatus.OK;
        };
    }
}

