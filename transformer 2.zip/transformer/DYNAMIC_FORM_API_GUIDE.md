# Dynamic Form Configuration API - Complete Guide

## Overview

This system provides a **fully dynamic form configuration** that allows you to:
1. **Define forms in the database** - No frontend code changes needed
2. **Fetch form structure via API** - UI renders forms dynamically
3. **Submit form data flexibly** - Backend validates against form config
4. **Change forms anytime** - Update database, UI adapts automatically

---

## Architecture

```
┌─────────────────┐
│   Frontend UI   │
└────────┬────────┘
         │
         │ 1. GET /api/v1/forms/{formId}
         │    (Fetch form configuration)
         ▼
┌─────────────────────────┐
│  Form Configuration API │
│  Returns: FormTemplate  │
└────────┬────────────────┘
         │
         │ Form structure with:
         │ - Sections
         │ - Fields (text, dropdown, checkbox, etc.)
         │ - Validation rules
         │ - Help text, placeholders
         │
         ▼
┌─────────────────┐
│  UI Renders     │
│  Form Dynamically│
└────────┬────────┘
         │
         │ 2. POST /api/v1/submissions
         │    (Submit form data as JSON)
         ▼
┌─────────────────────────┐
│ Form Submission API     │
│ - Validates data        │
│ - Stores in MongoDB     │
└─────────────────────────┘
```

---

## API Endpoints

### 1. Form Configuration APIs

#### Get Form Configuration
```http
GET /api/v1/forms/{formId}
```

**Example Request:**
```bash
curl -X GET http://localhost:8080/api/v1/forms/idea-submission-form
```

**Example Response:**
```json
{
  "id": "507f1f77bcf86cd799439011",
  "formId": "idea-submission-form",
  "formTitle": "Idea Submission Form",
  "formDescription": "Submit your innovative ideas for continuous improvement",
  "version": "1.0",
  "active": true,
  "formSettings": {
    "allowDraft": true,
    "showProgressBar": true,
    "enableAutoSave": true,
    "autoSaveInterval": 30,
    "submitButtonText": "Submit Idea",
    "draftButtonText": "Save Draft",
    "successMessage": "Your idea has been submitted successfully!",
    "enableEmailCapture": true,
    "emailFieldLabel": "Email Address",
    "emailRequired": false
  },
  "sections": [
    {
      "sectionId": "section-1",
      "sectionTitle": "Section 1: Basic Information",
      "sectionDescription": "Provide basic details about yourself and your idea",
      "displayOrder": 1,
      "collapsible": false,
      "defaultExpanded": true,
      "fields": [
        {
          "fieldId": "title",
          "fieldKey": "title",
          "label": "1. Title of Idea",
          "fieldType": "text",
          "placeholder": "Enter a concise title for your idea",
          "helpText": "Provide a concise and clear summary of your idea.",
          "required": true,
          "displayOrder": 1,
          "maxLength": 100,
          "validation": {
            "maxLength": 100,
            "minLength": 5
          }
        },
        {
          "fieldId": "submittedBy",
          "fieldKey": "submittedBy",
          "label": "2. Submitted By",
          "fieldType": "text",
          "placeholder": "Enter your name",
          "helpText": "Specify your name and department so the idea can be tracked.",
          "required": true,
          "displayOrder": 2,
          "maxLength": 100
        },
        {
          "fieldId": "impactAreas",
          "fieldKey": "impactAreas",
          "label": "6. Which area does this idea impact?",
          "fieldType": "checkbox",
          "required": true,
          "displayOrder": 1,
          "multiSelect": true,
          "options": [
            {
              "value": "PROCESS",
              "label": "Process",
              "description": "Streamlining workflows, automation, reducing errors"
            },
            {
              "value": "PEOPLE",
              "label": "People",
              "description": "Training, morale, collaboration, safety"
            },
            {
              "value": "QUALITY",
              "label": "Quality",
              "description": "Product/service quality, customer experience, compliance"
            }
          ]
        }
      ]
    }
  ]
}
```

#### Initialize Default Form
```http
POST /api/v1/forms/initialize/idea-submission
```

This creates the default Idea Submission form configuration in the database.

---

### 2. Form Submission APIs

#### Submit Form Data
```http
POST /api/v1/submissions
Content-Type: application/json
```

**Request Body:**
```json
{
  "formId": "idea-submission-form",
  "emailAddress": "user@example.com",
  "isDraft": false,
  "formData": {
    "title": "Automate Daily Report Generation",
    "submittedBy": "John Doe",
    "department": "IT Operations",
    "description": "Implement automated daily report generation to save 2 hours per day",
    "objective": "Reduce manual effort and improve accuracy of daily reports",
    "impactAreas": ["PROCESS", "QUALITY"],
    "improvementTypes": ["COST_SAVING", "INCREMENTAL"],
    "expectedBenefit": "Save 10 hours per week, reduce errors by 50%",
    "impactCategories": ["TIME_EFFICIENCY", "COST_SAVINGS"],
    "implementationComplexity": "MEDIUM",
    "suggestedSteps": "1. Analyze current process\n2. Design automation\n3. Implement and test",
    "timelineType": "SHORT_TERM",
    "additionalComments": "This will significantly improve our efficiency"
  },
  "metadata": {
    "source": "web",
    "userAgent": "Mozilla/5.0..."
  }
}
```

**Response:**
```json
{
  "id": "507f1f77bcf86cd799439012",
  "formId": "idea-submission-form",
  "formVersion": "1.0",
  "emailAddress": "user@example.com",
  "formData": {
    "title": "Automate Daily Report Generation",
    "submittedBy": "John Doe",
    ...
  },
  "status": "SUBMITTED",
  "upvoteCount": 0,
  "submissionDate": "2026-01-16T10:30:00",
  "createdAt": "2026-01-16T10:30:00",
  "updatedAt": "2026-01-16T10:30:00"
}
```

#### Save as Draft
```json
{
  "formId": "idea-submission-form",
  "emailAddress": "user@example.com",
  "isDraft": true,
  "formData": {
    "title": "Partial idea...",
    "submittedBy": "John Doe"
  }
}
```

#### Get Submission by ID
```http
GET /api/v1/submissions/{id}
```

#### Get All Submissions for a Form
```http
GET /api/v1/submissions/form/{formId}?page=0&size=10&sortBy=submissionDate&sortDirection=DESC
```

#### Get Submissions by Status
```http
GET /api/v1/submissions/form/{formId}/status/{status}?page=0&size=10
```

Status values: `DRAFT`, `SUBMITTED`, `UNDER_REVIEW`, `APPROVED`, `IMPLEMENTED`, `COMPLETED`, `REJECTED`, `ON_HOLD`

#### Search Submissions
```http
GET /api/v1/submissions/form/{formId}/search?keyword=automation&page=0&size=10
```

#### Update Submission Status
```http
PATCH /api/v1/submissions/{id}/status?status=UNDER_REVIEW&reviewedBy=Jane Smith&reviewComments=Looks promising
```

#### Add Upvote
```http
POST /api/v1/submissions/{id}/upvote?userId=user123
```

#### Add Comment
```http
POST /api/v1/submissions/{id}/comments?commenterName=Jane Smith&commenterEmail=jane@example.com&comment=Great idea!
```

#### Get Statistics
```http
GET /api/v1/submissions/form/{formId}/statistics
```

**Response:**
```json
{
  "totalSubmissions": 150,
  "submittedCount": 45,
  "underReviewCount": 30,
  "approvedCount": 25,
  "implementedCount": 20,
  "completedCount": 15,
  "rejectedCount": 10,
  "draftCount": 5
}
```

---

## Frontend Integration Guide

### Step 1: Fetch Form Configuration
```javascript
async function loadForm(formId) {
  const response = await fetch(`/api/v1/forms/${formId}`);
  const formConfig = await response.json();
  return formConfig;
}
```

### Step 2: Render Form Dynamically
```javascript
function renderForm(formConfig) {
  const formElement = document.createElement('form');
  
  formConfig.sections.forEach(section => {
    const sectionDiv = document.createElement('div');
    sectionDiv.innerHTML = `<h2>${section.sectionTitle}</h2>`;
    
    section.fields.forEach(field => {
      const fieldDiv = createField(field);
      sectionDiv.appendChild(fieldDiv);
    });
    
    formElement.appendChild(sectionDiv);
  });
  
  return formElement;
}

function createField(field) {
  const fieldDiv = document.createElement('div');
  
  switch(field.fieldType) {
    case 'text':
      fieldDiv.innerHTML = `
        <label>${field.label} ${field.required ? '*' : ''}</label>
        <input type="text" 
               name="${field.fieldKey}" 
               placeholder="${field.placeholder || ''}"
               maxlength="${field.maxLength || ''}"
               ${field.required ? 'required' : ''}>
        <small>${field.helpText || ''}</small>
      `;
      break;
      
    case 'textarea':
      fieldDiv.innerHTML = `
        <label>${field.label} ${field.required ? '*' : ''}</label>
        <textarea name="${field.fieldKey}" 
                  placeholder="${field.placeholder || ''}"
                  maxlength="${field.maxLength || ''}"
                  rows="${field.attributes?.rows || 4}"
                  ${field.required ? 'required' : ''}></textarea>
        <small>${field.helpText || ''}</small>
      `;
      break;
      
    case 'dropdown':
      let options = field.options.map(opt => 
        `<option value="${opt.value}">${opt.label}</option>`
      ).join('');
      fieldDiv.innerHTML = `
        <label>${field.label} ${field.required ? '*' : ''}</label>
        <select name="${field.fieldKey}" ${field.required ? 'required' : ''}>
          <option value="">Select...</option>
          ${options}
        </select>
        <small>${field.helpText || ''}</small>
      `;
      break;
      
    case 'checkbox':
      let checkboxes = field.options.map(opt => `
        <label>
          <input type="checkbox" name="${field.fieldKey}" value="${opt.value}">
          ${opt.label}
          ${opt.description ? `<br><small>${opt.description}</small>` : ''}
        </label>
      `).join('');
      fieldDiv.innerHTML = `
        <label>${field.label} ${field.required ? '*' : ''}</label>
        ${checkboxes}
        <small>${field.helpText || ''}</small>
      `;
      break;
  }
  
  return fieldDiv;
}
```

### Step 3: Submit Form Data
```javascript
async function submitForm(formId, formData, emailAddress, isDraft = false) {
  const response = await fetch('/api/v1/submissions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      formId: formId,
      emailAddress: emailAddress,
      isDraft: isDraft,
      formData: formData
    })
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'Submission failed');
  }
  
  return await response.json();
}

// Collect form data
function collectFormData(formElement) {
  const formData = {};
  const inputs = formElement.querySelectorAll('input, textarea, select');
  
  inputs.forEach(input => {
    if (input.type === 'checkbox') {
      if (!formData[input.name]) {
        formData[input.name] = [];
      }
      if (input.checked) {
        formData[input.name].push(input.value);
      }
    } else {
      formData[input.name] = input.value;
    }
  });
  
  return formData;
}
```

---

## Key Benefits

### ✅ **No Frontend Code Changes**
- Update form fields in database
- UI automatically adapts

### ✅ **Flexible Data Storage**
- Store any form structure
- MongoDB handles dynamic schemas

### ✅ **Built-in Validation**
- Required fields
- Length validation
- Custom validation rules

### ✅ **Complete Workflow**
- Draft support
- Status tracking
- Comments & upvotes
- Statistics

---

## Testing

### 1. Initialize Form
```bash
curl -X POST http://localhost:8080/api/v1/forms/initialize/idea-submission
```

### 2. Get Form Config
```bash
curl -X GET http://localhost:8080/api/v1/forms/idea-submission-form
```

### 3. Submit Form
```bash
curl -X POST http://localhost:8080/api/v1/submissions \
  -H "Content-Type: application/json" \
  -d '{
    "formId": "idea-submission-form",
    "emailAddress": "test@example.com",
    "isDraft": false,
    "formData": {
      "title": "Test Idea",
      "submittedBy": "Test User",
      "description": "This is a test idea",
      "objective": "Testing the system",
      "impactAreas": ["PROCESS"],
      "improvementTypes": ["INCREMENTAL"],
      "expectedBenefit": "Test benefit",
      "impactCategories": ["TIME_EFFICIENCY"],
      "implementationComplexity": "LOW",
      "timelineType": "SHORT_TERM"
    }
  }'
```

---

## Next Steps

1. **Start the application** - Form will auto-initialize
2. **Access Swagger UI** - http://localhost:8080/swagger-ui.html
3. **Test APIs** - Use Swagger or Postman
4. **Build Frontend** - Use the form config to render UI dynamically


