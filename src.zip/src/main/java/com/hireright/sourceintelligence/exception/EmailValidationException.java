package com.hireright.sourceintelligence.exception;

/**
 * Exception thrown when email validation fails.
 */
public class EmailValidationException extends NotificationException {
    
    public EmailValidationException(String message) {
        super(message, "EMAIL_VALIDATION_ERROR");
    }
    
    public EmailValidationException(String message, String field) {
        super(message, "EMAIL_VALIDATION_ERROR", field);
    }
    
    public EmailValidationException(String message, Throwable cause) {
        super(message, "EMAIL_VALIDATION_ERROR", cause);
    }
}

