package com.hireright.sourceintelligence.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * Entity representing a failed notification stored in the Dead Letter Queue.
 * This follows Single Responsibility Principle - only handles persistence of failed notifications.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "failed_notifications")
public class FailedNotification {
    
    /**
     * Unique identifier for the failed notification
     */
    @Id
    private String id;
    
    /**
     * Original notification ID
     */
    @Indexed
    private String notificationId;
    
    /**
     * Request ID for tracking
     */
    @Indexed
    private String requestId;
    
    /**
     * Type of notification (EMAIL, SMS, etc.)
     */
    private String notificationType;
    
    /**
     * Serialized email content (encrypted in production)
     */
    private String emailContent;
    
    /**
     * Serialized recipient list (encrypted in production)
     */
    private String recipientList;
    
    /**
     * Number of retry attempts
     */
    @Builder.Default
    private Integer retryCount = 0;
    
    /**
     * Maximum retry attempts allowed
     */
    @Builder.Default
    private Integer maxRetries = 5;
    
    /**
     * Timestamp when the notification first failed
     */
    @Indexed
    private LocalDateTime failedAt;
    
    /**
     * Timestamp of the last retry attempt
     */
    private LocalDateTime lastRetryAt;
    
    /**
     * Timestamp when the next retry should be attempted
     */
    @Indexed
    private LocalDateTime nextRetryAt;
    
    /**
     * Error message from the last failure
     */
    private String errorMessage;
    
    /**
     * Exception class name
     */
    private String exceptionType;
    
    /**
     * Stack trace (limited to first 2000 chars)
     */
    private String stackTrace;
    
    /**
     * Whether this is a permanent failure (max retries exceeded)
     */
    @Indexed
    @Builder.Default
    private Boolean permanentFailure = false;
    
    /**
     * Additional metadata
     */
    private Map<String, String> metadata;
    
    /**
     * Timestamp when the record was created
     */
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();
    
    /**
     * Timestamp when the record was last updated
     */
    @Builder.Default
    private LocalDateTime updatedAt = LocalDateTime.now();
    
    /**
     * Increment retry count and update timestamps
     */
    public void incrementRetryCount() {
        this.retryCount++;
        this.lastRetryAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        
        if (this.retryCount >= this.maxRetries) {
            this.permanentFailure = true;
        }
    }
    
    /**
     * Check if this notification can be retried
     */
    public boolean canRetry() {
        return !permanentFailure && 
               retryCount < maxRetries && 
               (nextRetryAt == null || LocalDateTime.now().isAfter(nextRetryAt));
    }
}

