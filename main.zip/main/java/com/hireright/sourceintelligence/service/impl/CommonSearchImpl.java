package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.domain.entity.*;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.service.CommonUtilService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.bson.Document;
import org.json.JSONObject;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.*;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.time.LocalDateTime;
import java.util.*;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.constants.ErrorConstants.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchScore.SEARCH_LIMIT;
import static com.hireright.sourceintelligence.util.LoggingThrowable.*;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.match;

@Slf4j
@Service
@RequiredArgsConstructor
public class CommonSearchImpl {
    protected final CustomSourceRepository<Source> customSourceRepository;
    private final CommonUtilService commonUtilService;

    public SearchResponseDTO getSourceOrganizationsByFilters(SearchDTO searchDTO,Map<String, Set<String>> mapFilters,List<ApprovalStatus> approvalStatuses,  String order, String sort, String collectionName){
        log.info("search start time: {}", LocalDateTime.now());
        Criteria criteria = QueryBuilder.buildDocumentByFilter(mapFilters);
        MatchOperation phraseMatch = QueryBuilder.buildMatch(criteria);
        AggregationOptions aggregationOptionsToAllowDiskUse = AggregationOptions.builder().allowDiskUse(true).build();
        ProjectionOperation projectSelectiveData = QueryBuilder.sourceByFiltersProjection();
        SortOperation sortOperation;
        Aggregation aggregation;
        MatchOperation matchOperation;
        if(approvalStatuses != null && !approvalStatuses.isEmpty()){
            matchOperation = match(Criteria.where(STATUS)
                    .is(searchDTO.getSourceOrganizationStatus() == null ?
                            SourceOrganizationStatus.ACTIVE.getStatus() :
                            searchDTO.getSourceOrganizationStatus().getStatus()).and(APPROVAL_STATUS).in(approvalStatuses));
        }else{
            matchOperation = match(Criteria.where(STATUS)
                .is(searchDTO.getSourceOrganizationStatus() == null ? SourceOrganizationStatus.ACTIVE.getStatus() : searchDTO.getSourceOrganizationStatus().getStatus()));
        }

        if(org.springframework.util.StringUtils.hasText(sort)) {
            String sortOnField = QueryBuilder.getSortPropertyMapped(sort);
            if(sortOnField == null){
                logAndThrowInvalidRequest(INVALID_SORT,null,sort);
            }
            sortOperation = new SortOperation(
                    Sort.by(QueryBuilder.getSortOrderDirection(order), sortOnField).and(Sort.by(Sort.Direction.DESC,SCORE)));

            aggregation = Aggregation.newAggregation(
                    phraseMatch,
                    matchOperation, projectSelectiveData, sortOperation,
                    QueryBuilder.facetOperation(searchDTO.getStartIndex(), searchDTO.getBatchSize()),
                    QueryBuilder.finalProjectionWithTotalCountInPipeline()).withOptions(aggregationOptionsToAllowDiskUse);
        } else {
            aggregation = Aggregation.newAggregation(
                    phraseMatch,
                    matchOperation, projectSelectiveData,
                    QueryBuilder.facetOperation(searchDTO.getStartIndex(), searchDTO.getBatchSize()),
                    QueryBuilder.finalProjectionWithTotalCountInPipeline()).withOptions(aggregationOptionsToAllowDiskUse);
        }

        var searchResult = customSourceRepository.customAggregate(aggregation, collectionName, MongoSearchResult.class);
        log.info("search results end time: {}", LocalDateTime.now());
        if (CollectionUtils.isEmpty(searchResult.getOrganizationList())) {
            logAndThrowResourceNotFound(NO_SEARCH_FOUND_WITH_FILTERS,null , mapFilters.toString());
        }
        log.info("child start time: {}", LocalDateTime.now());
        List<SourceDTO> finalSearchList = new ArrayList<>();

        return SearchResponseDTO.builder().searchList(finalSearchList)
                .currentPage((searchDTO.getStartIndex()))
                .totalItems(searchResult.getTotal())
                .totalPages(QueryBuilder.getTotalPages(searchResult.getTotal(), searchDTO.getBatchSize()))
                .build();
    }

    public List<AutocompleteSearchDTO> getAutocompletedFilters(String keyword,boolean isRAM, Map<String,String> searchFilters, String collectionName){
        if(!keyword.isEmpty()){
            searchFilters.put(ORGANIZATION_NAME,keyword);
        }
        List<Source> sourceOrganizations = getAggregationHits(keyword, isRAM, searchFilters, collectionName);
        List<AutocompleteSearchDTO> autocompleteSearchDTOS = new ArrayList<>();
        if(sourceOrganizations.isEmpty()){
            return autocompleteSearchDTOS;
        }
        long startTime = System.currentTimeMillis();
        Map<String, List<KeyMatchDTO>> mapOfCategorySearch = new HashMap<>();
        for (Source sourceOrganization : sourceOrganizations) {
            mapOfCategorySearch = getMapOfCategorySearchWithoutHighlights(searchFilters, mapOfCategorySearch,
                    sourceOrganization, keyword);
        }
        autocompleteSearchDTOS = commonUtilService
                .getTopFiveCategorySearches(mapOfCategorySearch);

        long endTime = System.currentTimeMillis();
        long duration = endTime - startTime;
        log.info("Java processing time for autocomplete search : {} ms", duration);
        return autocompleteSearchDTOS;
    }

    public List<Source> getAggregationHits(String keyword, boolean isRAM, Map<String, String> searchFilter, String collectionName) {
        try {
            MatchOperation matchOperation = QueryBuilder.buildAutocompleteSearchDocument(keyword, isRAM);
            Document projectionDoc = QueryBuilder.buildAutocompleteProjectionDocument();
            LimitOperation limitOperation = new LimitOperation(SEARCH_LIMIT);
            Aggregation aggregation = Aggregation.newAggregation(matchOperation, limitOperation, context -> projectionDoc);
            log.info("Start Date: {}", LocalDateTime.now());
            List<Source> sourceOrganizations = customSourceRepository.aggregate(aggregation, collectionName, Source.class);
            log.info("End Date: {}", LocalDateTime.now());
            return sourceOrganizations;
        }catch (Exception e){
            logAndThrowInvalidRequest(INVALID_INPUT,e);
        }
        return null;
    }

    private String getFieldValueFromAdditionalInfo(ArrayList<Object> additionalInfo, String fieldName) {
        String fieldValue = "";
        if(!ObjectUtils.isEmpty(additionalInfo) && !ObjectUtils.isEmpty(additionalInfo.get(0))){
                Document document = (Document) additionalInfo.get(0);
                JSONObject jsonObject = new JSONObject(document.toJson());
                if(jsonObject.has(fieldName)){
                    fieldValue = String.valueOf(jsonObject.get(fieldName));
                }
            }
        return fieldValue;
    }

    private Map<String, List<KeyMatchDTO>> getMapOfCategorySearchWithoutHighlights(
            Map<String, String> searchFilters,
            Map<String, List<KeyMatchDTO>> mapOfCategorySearch,
            Source sourceOrganization, String keyword) {

        FieldValueInfo info = new FieldValueInfo();
        // Extract and set the "do not contact" flag if payload exists
        if (!ObjectUtils.isEmpty(sourceOrganization.getPayload())) {
            info.setDoNotContact(getFieldValueFromAdditionalInfo(
                    (ArrayList<Object>) sourceOrganization.getPayload().get(ADDITIONAL_INFO),
                    DO_NOT_CONTACT));
        }

        // Populate base info values from sourceOrganization
        info.setCountry(sourceOrganization.getCountry());
        info.setState(sourceOrganization.getState());
        info.setCity(sourceOrganization.getCity());
        info.setHon(sourceOrganization.getHon());


            info.setOutOfBusiness(sourceOrganization.getOutOfBusiness() != null && sourceOrganization.getOutOfBusiness());
            if(sourceOrganization.getOrganizationName() != null && !sourceOrganization.getOrganizationName().isEmpty() && sourceOrganization.getOrganizationName().toLowerCase().contains(keyword.toLowerCase())){
                info.setValue(sourceOrganization.getOrganizationName().trim());
                mapOfCategorySearch = commonUtilService.categorizeMatchedValues(ORGANIZATION_NAME, info, mapOfCategorySearch);
            }
        return mapOfCategorySearch;
    }

}
