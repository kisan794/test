/*
 * @(#)$RCSfile: $ $Revision: $ $Date: $ $Author: $
 *
 * Copyright 2001-2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	M.Suhhoruki		2017-03-31	Created
 *	T.Prikk			2017-08-09	HIVPE-19903: addScreening(): added logic to create references to remote order service
 *	T.Prikk			2017-08-09	HIVPE-19903: addScreening(): added domain ID logic
 *	Someone			2017-MM-DD
 *	M.Suhhoruki		2017-08-14	Added new/old order properties for troubleshooting/tracking
 *	T.Prikk			2017-08-16	HIVPE-18686: send created order and order service refs via client references
 *	M.Suhhoruki		2017-11-03	HIVPE-23610: added reopenScreening
 *	A.Logachyov		2017-11-03	Added initDocumentSync
 *	M.Suhhoruki		2017-11-13	HIVPE-25346: storeOrderContext
 *	msuhhoruki		2017-11-30	HIVPE-27872: added timestamp to message to store event/action that triggered message creation
 *	A.Logachyov		2018-02-20	Added 5 minutes delay for document sync
 *	msuhhoruki		2018-04-09	HIVPE-29532: cancel data exchange on order cancel
 *	T.Prikk			2018-04-22	HIVPE-30297: create application/application order entries for struct. generics
 * 	V.Tsetsnev		2020-10-05	HRG-122983: added saving order service property EMPLOYMENT_SHOW_VERIFIED_WITH_DOCS_FLAG if transferred via XML
 * 	V.Tsetsnev		2020-12-07	HRG-145580: added saving order service property CREATE_ORDER_EDUCATION_GRADES if transferred via XML
 * 	V.Tsetsnev		2021-09-23 	HRG-171238: added saving regulatory order properties
 * 	V.Tsetsnev		2021-10-07	HRG-176817: added saving order property REGULATED_EMPLOYMENT_FLAG_7_YEARS if transferred via XML
 * 	V.Tsetsnev		2025-02-13	VER-25: added saving order property EDUCATION_VERIFY_HIGH_SCHOOL_AT_SOURCE
 * 	M.Kuznetsov		2025-09-12	HRG-339332: CInstanceDomain support
 */
package hireright.applications.vendor_api.resources;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

import jakarta.servlet.http.HttpServletRequest;

import hireright.bdk.instance_parameter.CInstanceDomain;
import hireright.bdk.instance_parameter.CInstanceDomainFactory;
import org.apache.commons.io.IOUtils;
import org.base64.Base64;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.joda.time.DateTime;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import hireright.applications.vendor_api.CVendorApiException;
import hireright.applications.vendor_api.CVendorOrderBuilder;
import hireright.applications.vendor_api.EHostReference;
import hireright.applications.vendor_api.facades.IdValueFacade;
import hireright.applications.vendor_api.model.COrderBuilder;
import hireright.applications.vendor_api.model.CScreeningRequest;
import hireright.applications.vendor_api.services.ScreeningReportService;
import hireright.applications.vendor_api.services.ScreeningService;
import hireright.bdk.order.COrderLookup;
import hireright.components.domain.dialects.vendor_api.BasicResponse;
import hireright.lib.compress.archivers.zip.CArchiverZip;
import hireright.lib.dom4j.CDom4jObject;
import hireright.objects.document.CDocument;
import hireright.objects.document.CDocumentFactory;
import hireright.objects.flexfields.CFlexField;
import hireright.objects.flexfields.CFlexFieldDefinition;
import hireright.objects.flexfields.CFlexFieldDefinitionList;
import hireright.objects.is.CEvent;
import hireright.objects.is.CMessage;
import hireright.objects.order.COrder;
import hireright.objects.order.COrderException;
import hireright.objects.order.COrderServiceException;
import hireright.objects.order2.COrderManager;
import hireright.objects.order2.COrderProperty;
import hireright.objects.order2.COrderService;
import hireright.objects.order2.COrderServiceManager;
import hireright.objects.order2.COrderServiceProperties;
import hireright.objects.order2.COrderServiceProperty;
import hireright.objects.pack.CPackProperty;
import hireright.objects.users.CCustomer;
import hireright.objects.users.CCustomerProperties;
import hireright.sdk.consts.Logical;
import hireright.sdk.db.pojo.CTablePojo;
import hireright.sdk.db3.DB;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;

@RestController
public class CScreeningResource extends AResource
{
	private static final int EVENT_TYPE_START_DOC_SYNC = 755;
	private static final int DOC_TYPE_CTX = 222;
	
	@RequestMapping(path = ScreeningService.PATH_ADD,
			method = RequestMethod.POST,
			consumes = MediaType.APPLICATION_XML_VALUE,
			produces = MediaType.APPLICATION_XML_VALUE)
	public BasicResponse addScreening(@RequestBody final CScreeningRequest request)
		throws Exception
	{
		return DB.execute(new Callable<BasicResponse>()
		{
			@Override
			public BasicResponse call() 
				throws Exception
			{
				DB.requestTransaction();
				COrder order = createOrder(request);
				
				List<COrderService> orderServices = COrderServiceManager.load(order.getID());
				BasicResponse response = new BasicResponse();
				if (order != null)
				{
					saveClientReferences(order.getID(), request);

					String sContext = request.getContext();
					if (!CStringUtils.isEmpty(sContext))
					{
						storeOrderContext(order, sContext);
					}
					
					initDocumentSync(order.getID());
					
					IdValueFacade references = new IdValueFacade()
						.set(ScreeningService.EResponseParam.ORDER.name(), order.getRequestRegID());
						
					if (!orderServices.isEmpty())
					{
						COrderService orderService = orderServices.iterator().next();
						references.set(ScreeningService.EResponseParam.ORDER_SERVICE.name(), orderService.getCode());

						if (Logical.isTrue(request.getClientReference(EHostReference.EMPLOYMENT_SHOW_VERIFIED_WITH_DOCS_FLAG.getPropertyName())))
						{
							COrderServiceProperty.saveProperty(orderService.getIDLong(),
									COrderServiceProperties.EMPLOYMENT_SHOW_VERIFIED_WITH_DOCS_FLAG, Logical.YES_SHORT);
						}

						if (Logical.isTrue(request.getClientReference(EHostReference.CREATE_ORDER_EDUCATION_GRADES.getPropertyName())))
						{
							COrderServiceProperty.saveProperty(orderService.getIDLong(),
									COrderServiceProperties.CREATE_ORDER_EDUCATION_GRADES, Logical.YES_SHORT);
						}
						
						if (Logical.isTrue(request.getClientReference(EHostReference.PACK_PROPERTY_MOM_PROCESS.getPropertyName())))
						{
							COrderProperty.saveProperty(orderService.getOrderID(),
									CPackProperty.PROP_PACK_PROPERTY_MOM_PROCESS, Logical.YES_SHORT);
						}
					}
					
					response.getIdValues().addAll(references.getAll());
				}
				
				return response;
			}
		});
	}
	
	private void saveClientReferences(Long nOrderID, CScreeningRequest request)
	{
		final String sHostInstanceRef = request.getClientReference(EHostReference.HOST_INSTANCE_REF.getPropertyName());
		if (sHostInstanceRef != null)
		{
			final CInstanceDomain instanceDomain = CInstanceDomainFactory.search(sHostInstanceRef);
			COrderProperty.saveProperty(nOrderID, EHostReference.HOST_INSTANCE_REF.getPropertyName(), instanceDomain.getDomainID(), true);
		}
		
		String sHostMainOrderRef = request.getClientReference(EHostReference.HOST_MAIN_ORDER_REF.getPropertyName());
		
		if (!CStringUtils.isEmpty(sHostMainOrderRef))
		{
			CFlexFieldDefinition flexFieldDefinition = CFlexFieldDefinitionList.findDefinition(null, CCustomer.OBJECT_CLASS, "COMMON", true, "HostMainOrderReference");
			
			if (flexFieldDefinition != null)
			{
				CFlexField.create(null, flexFieldDefinition, COrder.OBJECT_CLASS, String.valueOf(nOrderID), sHostMainOrderRef);
			}
		}
		
		String requestorName = request.getClientReference(EHostReference.HOST_REQUESTOR_NAME.getPropertyName());
		COrderProperty.saveProperty(nOrderID,EHostReference.HOST_REQUESTOR_NAME.getPropertyName(), requestorName, true);
		
		String sHostOrderServiceRef = request.getClientReference(EHostReference.HOST_ORDER_SERVICE_REF.getPropertyName());
		COrderProperty.saveProperty(nOrderID,EHostReference.HOST_ORDER_SERVICE_REF.getPropertyName(), sHostOrderServiceRef, true);
		
		String sHostOrderRef = request.getClientReference(EHostReference.HOST_ORDER_REF.getPropertyName());
		COrderProperty.saveProperty(nOrderID, EHostReference.HOST_ORDER_REF.getPropertyName(), sHostOrderRef, true);
		
		String sHostDelayInfoNoteRecipients = request.getClientReference(EHostReference.HOST_DELAY_INFO_NOTE_RECIPIENTS.getPropertyName());
		COrderProperty.saveProperty(nOrderID, EHostReference.HOST_DELAY_INFO_NOTE_RECIPIENTS.getPropertyName(), sHostDelayInfoNoteRecipients, true);
		
		String sHostDelayActionNoteRecipients = request.getClientReference(EHostReference.HOST_DELAY_ACTION_NOTE_RECIPIENTS.getPropertyName());
		COrderProperty.saveProperty(nOrderID, EHostReference.HOST_DELAY_ACTION_NOTE_RECIPIENTS.getPropertyName(), sHostDelayActionNoteRecipients, true);

		String regulatedEmploymentFlag7Years =
				request.getClientReference(EHostReference.REGULATED_EMPLOYMENT_FLAG_7_YEARS.getPropertyName());
		if (CStringUtils.isNotEmpty(regulatedEmploymentFlag7Years))
		{
			COrderProperty.saveProperty(nOrderID,
					COrderProperty.PROPERTY_REGULATED_EMPLOYMENT_FLAG_7_YEARS, regulatedEmploymentFlag7Years);
		}

		String sRegulation = request.getClientReference("REGULATION");
		if (CStringUtils.isNumber(sRegulation))
		{
			COrderProperty.saveProperty(nOrderID, "REGULATION", sRegulation);	
		}

		String sSpelling = request.getClientReference("VS-814 SPELLING");
		if (CStringUtils.isNumber(sSpelling))
		{
			COrderProperty.saveProperty(nOrderID, "VS-814 SPELLING", sSpelling);	
		}
		
		String alwaysFirstLaunchToManualQueue = request.getClientReference("ALWAYS_FIRST_LAUNCH_TO_MANUAL_QUEUE");
		if (CStringUtils.isNotEmpty(alwaysFirstLaunchToManualQueue))
		{
			COrderProperty.saveProperty(nOrderID, "ALWAYS_FIRST_LAUNCH_TO_MANUAL_QUEUE", alwaysFirstLaunchToManualQueue);
		}
		
		String icoverApiAlwaysRouteToManualQueue = request.getClientReference("ICOVER_API_ALWAYS_ROUTE_TO_MANUAL_QUEUE");
		if (CStringUtils.isNotEmpty(icoverApiAlwaysRouteToManualQueue))
		{
			COrderProperty.saveProperty(nOrderID, "ICOVER_API_ALWAYS_ROUTE_TO_MANUAL_QUEUE", icoverApiAlwaysRouteToManualQueue);
		}

		String sSalaryRestricted = request.getClientReference("SALARY_RESTRICTED");
		if (!CStringUtils.isEmpty(sSalaryRestricted))
		{
			COrderProperty.saveProperty(nOrderID, "SALARY_RESTRICTED", sSalaryRestricted);	
		}
		
		String sExperian = request.getClientReference(CCustomerProperties.EMPLOYMENT_EXPERIAN);
		if (!CStringUtils.isEmpty(sExperian))
		{
			COrderProperty.saveProperty(nOrderID, CCustomerProperties.EMPLOYMENT_EXPERIAN, sExperian);	
		}
		
		String sExperianDataSet = request.getClientReference(CCustomerProperties.EMPLOYMENT_EXPERIAN_DATA_SET);
		if (!CStringUtils.isEmpty(sExperianDataSet))
		{
			COrderProperty.saveProperty(nOrderID, CCustomerProperties.EMPLOYMENT_EXPERIAN_DATA_SET, sExperianDataSet);	
		}
		
		String sEquifax = request.getClientReference(CCustomerProperties.EMPLOYMENT_EQUIFAX);
		if (!CStringUtils.isEmpty(sEquifax))
		{
			COrderProperty.saveProperty(nOrderID, CCustomerProperties.EMPLOYMENT_EQUIFAX, sEquifax);	
		}
		
		String sEquifaxDataSet = request.getClientReference(CCustomerProperties.EMPLOYMENT_EQUIFAX_DATA_SET);
		if (!CStringUtils.isEmpty(sEquifaxDataSet))
		{
			COrderProperty.saveProperty(nOrderID, CCustomerProperties.EMPLOYMENT_EQUIFAX_DATA_SET, sEquifaxDataSet);	
		}
		
		String allowToContactApplicant = request.getClientReference(COrder.PROPERTY_ALLOW_CONTACT_APPLICANT);
		if (!CStringUtils.isEmpty(allowToContactApplicant))
		{
			COrderProperty.saveProperty(nOrderID, COrder.PROPERTY_ALLOW_CONTACT_APPLICANT, allowToContactApplicant);	
		}

		String regulationFCARoleType = request.getClientReference(EHostReference.REGULATION_FCA_ROLE_TYPE.getPropertyName());
		if (CStringUtils.isNotEmpty(regulationFCARoleType))
		{
			COrderProperty.saveProperty(nOrderID, COrderProperty.PROPERTY_REGULATION_FCA_ROLE_TYPE, regulationFCARoleType);
		}

		String regulationMASRoleType = request.getClientReference(EHostReference.REGULATION_MAS_ROLE_TYPE.getPropertyName());
		if (CStringUtils.isNotEmpty(regulationMASRoleType)) {
			COrderProperty.saveProperty(nOrderID, COrderProperty.PROPERTY_REGULATION_MAS_ROLE_TYPE, regulationMASRoleType);
		}

		String regulationASICRoleType = request.getClientReference(EHostReference.REGULATION_ASIC_ROLE_TYPE.getPropertyName());
		if (CStringUtils.isNotEmpty(regulationASICRoleType)) {
			COrderProperty.saveProperty(nOrderID, COrderProperty.PROPERTY_REGULATION_ASIC_ROLE_TYPE, regulationASICRoleType);
		}

		String regulationHKRoleType = request.getClientReference(EHostReference.REGULATION_HK_ROLE_TYPE.getPropertyName());
		if (CStringUtils.isNotEmpty(regulationHKRoleType)) {
			COrderProperty.saveProperty(nOrderID, COrderProperty.PROPERTY_REGULATION_HK_ROLE_TYPE, regulationHKRoleType);
		}

		String regulationMalaysiaRoleType = request.getClientReference(EHostReference.REGULATION_MALAYSIA_ROLE_TYPE.getPropertyName());
		if (CStringUtils.isNotEmpty(regulationMalaysiaRoleType)) {
			COrderProperty.saveProperty(nOrderID, COrderProperty.PROPERTY_REGULATION_MALAYSIA_ROLE_TYPE, regulationMalaysiaRoleType);
		}

		String regulationRegistrationNumber = request.getClientReference(EHostReference.REGULATION_REGISTRATION_NUMBER.getPropertyName());
		if (CStringUtils.isNotEmpty(regulationRegistrationNumber))
		{
			COrderProperty.saveProperty(nOrderID, COrderProperty.PROPERTY_REGULATION_REGISTRATION_NUMBER, regulationRegistrationNumber);
		}

		String regulationCompanyName = request.getClientReference(EHostReference.REGULATION_COMPANY_NAME.getPropertyName());
		if (CStringUtils.isNotEmpty(regulationCompanyName))
		{
			COrderProperty.saveProperty(nOrderID, COrderProperty.PROPERTY_REGULATION_COMPANY_NAME, regulationCompanyName);
		}

		String regulationDepartment = request.getClientReference(EHostReference.REGULATION_DEPARTMENT.getPropertyName());
		if (CStringUtils.isNotEmpty(regulationDepartment))
		{
			COrderProperty.saveProperty(nOrderID, COrderProperty.PROPERTY_REGULATION_DEPARTMENT, regulationDepartment);
		}

		String regulationContactInfo = request.getClientReference(EHostReference.REGULATION_CONTACT_INFO.getPropertyName());
		if (CStringUtils.isNotEmpty(regulationContactInfo))
		{
			COrderProperty.saveProperty(nOrderID, COrderProperty.PROPERTY_REGULATION_CONTACT_INFO, regulationContactInfo);
		}

		String sPropertyEducationVerifyHighSchool = request.getClientReference(COrderProperty.PROPERTY_EDUCATION_VERIFY_HIGH_SCHOOL_AT_SOURCE);
		if (CStringUtils.isNotEmpty(sPropertyEducationVerifyHighSchool))
		{
			COrderProperty.saveProperty(nOrderID, COrderProperty.PROPERTY_EDUCATION_VERIFY_HIGH_SCHOOL_AT_SOURCE,
					sPropertyEducationVerifyHighSchool);
		}
	}
	
	@RequestMapping(path = ScreeningService.PATH_CANCEL,
			method = RequestMethod.GET)
	public BasicResponse cancelScreening(
			@PathVariable(name=ScreeningService.VAR_ORDER_REF) final String sOrderRef)
		throws Exception
	{
		String message = DB.execute(new Callable<String>()
		{
			@Override
			public String call() 
				throws Exception
			{
				DB.requestTransaction();
				
				Long nOrderID = COrder.findOrderByRegID(DB.connection(), sOrderRef);
				
				COrderProperty.saveProperty(nOrderID, "CancelObjectClass", "OPERATOR");
				COrderProperty.saveProperty(nOrderID, "CancelObjectID", "1");
				// HIVPE-29532: disable order updates from this instance (needs some instance exchange sdk)
				COrderProperty.renameProperty(nOrderID,
						"INSTANCE_EXCHANGE_TRANSACTION_ID",
						"PASSIVE_INSTANCE_EXCHANGE_TRANSACTION_ID");
				
				CProperties properties = new CProperties()
						.setProperty("orderID", nOrderID)
				        .setProperty("discrepancyCode", "X")
				        // this will replace default cancellation comment
				        .setProperty("comments", "Received order cancellation request.");
				CEvent.create(522, "BASE", properties);
				
				return "";
			}
		});
		
		BasicResponse response = new BasicResponse();
		
		if (message != null)
		{
			response.getIdValues().addAll(new IdValueFacade()
					.set(ScreeningReportService.EResponseParam.MESSAGE.name(), message)
					.getAll());
		}
		
		return response;
	}

	
	@RequestMapping(path = ScreeningService.PATH_REOPEN,
			method = RequestMethod.POST,
			consumes = MediaType.APPLICATION_XML_VALUE,
			produces = MediaType.APPLICATION_XML_VALUE)
	public BasicResponse reopenScreening(final HttpServletRequest request)
		throws Exception
	{
		CMessage message = DB.execute(new Callable<CMessage>()
		{
			@Override
			public CMessage call() 
				throws Exception
			{
				DB.requestTransaction();
				
				Map<String, String> params = QueryStringParser.parse(request.getQueryString());
				String sTimestamp = params != null ? params.get("tm") : null;
				
				return CMessageFactory.createAndEnqueueMessage(
						"REOPEN", sTimestamp, IOUtils.toString(request.getInputStream()));
			}
		});
		
		BasicResponse response = new BasicResponse();
		
		if (message != null)
		{
			response.getIdValues().addAll(new IdValueFacade()
					.set(ScreeningReportService.EResponseParam.MESSAGE.name(), message.getID().toString())
					.getAll());
		}
		
		return response;
	}

	protected void initDocumentSync(Long nOrderID)
	{
		CProperties properties = new CProperties();
		properties.setProperty("orderID", nOrderID);
		CEvent.create(EVENT_TYPE_START_DOC_SYNC, "BASE", properties); //For DB and JR
		addFutureEvent(EVENT_TYPE_START_DOC_SYNC, "BASE", properties, new DateTime().plusMinutes(5).toDate()); //For OWC
	}

	private COrder createOrder(CScreeningRequest request)
		throws CVendorApiException, COrderServiceException
	{
		COrderBuilder builder = CVendorOrderBuilder.getInstance(request);
		try
		{
			COrder order = builder.buildOrder(request, true);
			
			String sOrderCode = request.getClientReference("ORDER_CODE");
			if (CStringUtils.isNotEmpty(sOrderCode))
			{
				Long nOldOrderID = COrderLookup.findByRegID(sOrderCode);
				if (nOldOrderID != null)
				{
					COrderProperty.saveProperty(nOldOrderID, "NEW_ORDER_ID", order.getID().toString());
					COrderProperty.saveProperty(order.getID(), "OLD_ORDER_ID", nOldOrderID.toString());
					COrderManager.deleteLogically(nOldOrderID);
				}
			}
			
			return order;
		}
		catch (COrderException e)
		{
			throw new CVendorApiException(e);
		}
		catch (SQLException e)
		{
			throw new CVendorApiException(e);
		}
	}
	
	// TODO: move to COrderBuilder when context is formalized
	private void storeOrderContext(COrder order, String sContext)
		throws IOException, DocumentException
	{
		byte[] data = Base64.decode(sContext);
		String sContextXml = new String(CArchiverZip.unzip(data), "US-ASCII");
		long DAY = 1000 * 60 * 60 * 24;
		
		CDocument ctx = new CDocument();
		ctx.setBodyType(CDocument.BODY_TYPE_TEXT);
		ctx.setContent(sContextXml);
		ctx.setContentCharset(CDocument.CHARSET_US_ASCII);
		ctx.setContentDescription("Fulfilment context");
		ctx.setContentEncoding(null);
		ctx.setContentFileName("context.xml");
		ctx.setContentLanguage("en");
		ctx.setContentType("text/xml");
		ctx.setDocumentTypeID(DOC_TYPE_CTX);
		ctx.setExpirationDate(new Date(System.currentTimeMillis() + DAY * 90));
		ctx.setObjectClass(order.getObjectClass());
		ctx.setObjectID(order.getID().toString());
		ctx.setTimestamp(new Date());
		
		CDocumentFactory.storeDocument(ctx);
		
		// store CTX_COMPANY_NAME order_property for TALX/HSCH PL/SQL adapters
		Document doc = DocumentHelper.parseText(sContextXml);
		CTablePojo ctxOrder = CDom4jObject.fromDocument(doc);
		CTablePojo ctxCustomer = CTablePojo.findByLabel(ctxOrder, "Customer");
		if (ctxCustomer != null)
		{
			String sCompanyName = ctxCustomer.getProperty("LEGAL_NAME");
			if (CStringUtils.isEmpty(sCompanyName))
			{
				sCompanyName = ctxCustomer.getProperty("NAME");
			}
			
			if (!CStringUtils.isEmpty(sCompanyName))
			{
				COrderProperty.saveProperty(order.getID(), "CTX_COMPANY_NAME", sCompanyName, true);
			}
		}
		
	}
}
