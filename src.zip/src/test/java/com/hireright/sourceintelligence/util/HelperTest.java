package com.hireright.sourceintelligence.util;

import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.domain.constants.Constants.SmartSearchKeys.NAME;
import static com.hireright.sourceintelligence.domain.constants.Constants.VENDORS.EQUIFAX_EDU;
import static com.hireright.sourceintelligence.domain.constants.Constants.VENDORS.NSCH;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mockStatic;

class HelperTest {

    @Test
    void constructor_shouldThrowIllegalStateException() throws Exception {
        Constructor<Helper> constructor = Helper.class.getDeclaredConstructor();
        constructor.setAccessible(true);

        Exception ex = assertThrows(Exception.class, constructor::newInstance);
        assertNotNull(ex.getCause());
        assertTrue(ex.getCause() instanceof IllegalStateException);
        assertEquals("Helper class", ex.getCause().getMessage());
    }

    @Test
    void getCollectionName_shouldReturnEmploymentPrefix_whenSourceContainsEmploymentHonPrefix() {
        String result = Helper.getCollectionName(HON_EMPLOYMENT_PREFIX + "_ABC", SOURCE_COLLECTION_SUFFIX);
        assertEquals(EMPLOYMENT_COLLECTION_PREFIX + SOURCE_COLLECTION_SUFFIX, result);
    }

    @Test
    void getCollectionName_shouldReturnEmploymentPrefix_whenSourceEqualsEmploymentType() {
        String result = Helper.getCollectionName(OrganizationType.EMPLOYMENT.toString(), SOURCE_COLLECTION_SUFFIX);
        assertEquals(EMPLOYMENT_COLLECTION_PREFIX + SOURCE_COLLECTION_SUFFIX, result);
    }

    @Test
    void getCollectionName_shouldReturnEducationPrefix_whenSourceContainsEducationHonPrefix() {
        String result = Helper.getCollectionName(HON_EDUCATION_PREFIX + "_ABC", SOURCE_COLLECTION_SUFFIX);
        assertEquals(EDUCATION_COLLECTION_PREFIX + SOURCE_COLLECTION_SUFFIX, result);
    }

    @Test
    void getCollectionName_shouldReturnEducationPrefix_whenSourceEqualsEducationType() {
        String result = Helper.getCollectionName(OrganizationType.EDUCATION.toString(), SOURCE_COLLECTION_SUFFIX);
        assertEquals(EDUCATION_COLLECTION_PREFIX + SOURCE_COLLECTION_SUFFIX, result);
    }

    @Test
    void getCollectionName_shouldThrow_whenSourceIsUnknown() {
        assertThrows(RuntimeException.class,
                () -> Helper.getCollectionName("UNKNOWN_SOURCE", SOURCE_COLLECTION_SUFFIX));
    }

    @Test
    void getIndexName_shouldReturnEmploymentIndex_whenOrganizationTypeIsNotEducation() {
        String result = Helper.getIndexName(OrganizationType.EMPLOYMENT.getType());
        assertEquals(EMPLOYMENT_COLLECTION_PREFIX + ES_SOURCE_COLLECTION_SUFFIX, result);
    }

    @Test
    void getIndexName_shouldReturnEducationIndex_whenOrganizationTypeIsEducation() {
        String result = Helper.getIndexName(OrganizationType.EDUCATION.getType());
        assertEquals(EDUCATION_COLLECTION_PREFIX + ES_SOURCE_COLLECTION_SUFFIX, result);
    }

    @Test
    void validateThresholdLimit_shouldDoNothing_whenThresholdIsNull() {
        assertDoesNotThrow(() -> Helper.validateThresholdLimit(null));
    }

    @Test
    void validateThresholdLimit_shouldDoNothing_whenThresholdIsWithinRange() {
        assertDoesNotThrow(() -> Helper.validateThresholdLimit(MIN_CONFIDENCE_THRESHOLD_ALLOWED));
        assertDoesNotThrow(() -> Helper.validateThresholdLimit(100.0));
        assertDoesNotThrow(() -> Helper.validateThresholdLimit(75.0));
    }

    @Test
    void validateThresholdLimit_shouldThrow_whenThresholdIsBelowMinimum() {
        assertThrows(RuntimeException.class,
                () -> Helper.validateThresholdLimit(MIN_CONFIDENCE_THRESHOLD_ALLOWED - 0.1));
    }

    @Test
    void validateThresholdLimit_shouldThrow_whenThresholdIsAboveHundred() {
        assertThrows(RuntimeException.class,
                () -> Helper.validateThresholdLimit(100.1));
    }

    @Test
    void prepareSearchFilters_shouldIncludeAllFields_whenOrganizationCityCountryStatePresent() {
        Map<String, String> result = Helper.prepareSearchFilters("Org", "Delhi", "India", "DL");

        assertEquals(4, result.size());
        assertEquals("Org", result.get(ORGANIZATION_NAME));
        assertEquals("Delhi", result.get(CITY));
        assertEquals("India", result.get(COUNTRY));
        assertEquals("DL", result.get(STATE));
    }

    @Test
    void prepareSearchFilters_shouldIncludeCountryAndState_whenOnlyThoseArePresent() {
        Map<String, String> result = Helper.prepareSearchFilters("Org", "", "India", "DL");

        assertEquals(3, result.size());
        assertEquals("Org", result.get(ORGANIZATION_NAME));
        assertEquals("India", result.get(COUNTRY));
        assertEquals("DL", result.get(STATE));
        assertFalse(result.containsKey(CITY));
    }

    @Test
    void prepareSearchFilters_shouldIncludeCountryAndCity_whenOnlyThoseArePresent() {
        Map<String, String> result = Helper.prepareSearchFilters("Org", "Delhi", "India", "");

        assertEquals(3, result.size());
        assertEquals("Org", result.get(ORGANIZATION_NAME));
        assertEquals("Delhi", result.get(CITY));
        assertEquals("India", result.get(COUNTRY));
        assertFalse(result.containsKey(STATE));
    }

    @Test
    void prepareSearchFilters_shouldIncludeOnlyCountry_whenOnlyCountryIsPresent() {
        Map<String, String> result = Helper.prepareSearchFilters("Org", "", "India", "");

        assertEquals(2, result.size());
        assertEquals("Org", result.get(ORGANIZATION_NAME));
        assertEquals("India", result.get(COUNTRY));
        assertFalse(result.containsKey(CITY));
        assertFalse(result.containsKey(STATE));
    }

    @Test
    void prepareSearchFilters_shouldIncludeOnlyOrganizationName_whenOtherFieldsAreMissing() {
        Map<String, String> result = Helper.prepareSearchFilters("Org", "", "", "");

        assertEquals(1, result.size());
        assertEquals("Org", result.get(ORGANIZATION_NAME));
    }

    @Test
    void fromAction_shouldReturnPendingApproval_forSave() {
        assertEquals(ApprovalStatus.PENDING_APPROVAL, Helper.fromAction(ACTION_SAVE));
    }

    @Test
    void fromAction_shouldReturnPendingApproval_forDelete() {
        assertEquals(ApprovalStatus.PENDING_APPROVAL, Helper.fromAction(ACTION_DELETE));
    }

    @Test
    void fromAction_shouldReturnSavePendingApproval_forSaveAndUse() {
        assertEquals(ApprovalStatus.SAVE_PENDING_APPROVAL, Helper.fromAction(ACTION_SAVE_AND_USE));
    }

    @Test
    void fromAction_shouldReturnApproved() {
        assertEquals(ApprovalStatus.APPROVED, Helper.fromAction(ACTION_APPROVED));
    }

    @Test
    void fromAction_shouldReturnRejected() {
        assertEquals(ApprovalStatus.REJECTED, Helper.fromAction(ACTION_REJECTED));
    }

    @Test
    void fromAction_shouldReturnOnHold() {
        assertEquals(ApprovalStatus.ONHOLD, Helper.fromAction(ACTION_ON_HOLD));
    }

    @Test
    void fromAction_shouldReturnInProgress() {
        assertEquals(ApprovalStatus.IN_PROGRESS, Helper.fromAction(ACTION_IN_PROGRESS));
    }

    @Test
    void fromAction_shouldReturnNull_forUnknownAction() {
        assertNull(Helper.fromAction("UNKNOWN"));
    }

    @Test
    void fromActionForApprovalFlow_shouldReturnApproved() {
        assertEquals(ApprovalStatus.APPROVED, Helper.fromActionForApprovalFlow(ACTION_APPROVED));
    }

    @Test
    void fromActionForApprovalFlow_shouldReturnRejected() {
        assertEquals(ApprovalStatus.REJECTED, Helper.fromActionForApprovalFlow(ACTION_REJECTED));
    }

    @Test
    void fromActionForApprovalFlow_shouldReturnOnHold() {
        assertEquals(ApprovalStatus.ONHOLD, Helper.fromActionForApprovalFlow(ACTION_ON_HOLD));
    }

    @Test
    void fromActionForApprovalFlow_shouldReturnNull_forUnknownAction() {
        assertNull(Helper.fromActionForApprovalFlow("UNKNOWN"));
    }

    @Test
    void convertToTitleCase_shouldConvertMixedCaseAndExtraSpaces() {
        String result = Helper.convertToTitleCase("  hELLo    woRLD  java ");

        assertEquals("Hello World Java", result);
    }

    @Test
    void convertToTitleCase_shouldConvertSingleWord() {
        String result = Helper.convertToTitleCase("tEsT");
        assertEquals("Test", result);
    }

    @Test
    void removeExtraSpaces_shouldTrimAndNormalize_whenMultipleWordsPresent() {
        String result = Helper.removeExtraSpaces("  hello    world   java  ");
        assertEquals("hello world java", result);
    }

    @Test
    void removeExtraSpaces_shouldTrimOnly_whenSingleWordPresent() {
        String result = Helper.removeExtraSpaces("   hello   ");
        assertEquals("hello", result);
    }

    @Test
    void getOrganizationType_shouldReturnEducation_whenHonContainsEducationPrefix() {
        String result = Helper.getOrganizationType("ABC_" + HON_EDUCATION_PREFIX + "_XYZ");
        assertEquals(OrganizationType.EDUCATION.toString(), result);
    }

    @Test
    void getOrganizationType_shouldReturnEmployment_whenHonDoesNotContainEducationPrefix() {
        String result = Helper.getOrganizationType("ABC_" + HON_EMPLOYMENT_PREFIX + "_XYZ");
        assertEquals(OrganizationType.EMPLOYMENT.toString(), result);
    }

    @Test
    void checkIsSkipApprovalFlow_shouldReturnTrue_whenDiffContainsOrganizationAlias() {
        Source source1 = new Source();
        Source source2 = new Source();

        try (MockedStatic<DeepDiffUtil> mocked = mockStatic(DeepDiffUtil.class)) {
            mocked.when(() -> DeepDiffUtil.findChangedFields(source1, source2))
                    .thenReturn(List.of(ORGANIZATION_ALIAS));

            assertTrue(Helper.checkIsSkipApprovalFlow(source1, source2));
        }
    }

    @Test
    void checkIsSkipApprovalFlow_shouldReturnFalse_whenDiffIsEmpty() {
        Source source1 = new Source();
        Source source2 = new Source();

        try (MockedStatic<DeepDiffUtil> mocked = mockStatic(DeepDiffUtil.class)) {
            mocked.when(() -> DeepDiffUtil.findChangedFields(source1, source2))
                    .thenReturn(List.of());

            assertFalse(Helper.checkIsSkipApprovalFlow(source1, source2));
        }
    }

    @Test
    void checkIsSkipApprovalFlow_shouldReturnFalse_whenDiffDoesNotContainOrganizationAlias() {
        Source source1 = new Source();
        Source source2 = new Source();

        try (MockedStatic<DeepDiffUtil> mocked = mockStatic(DeepDiffUtil.class)) {
            mocked.when(() -> DeepDiffUtil.findChangedFields(source1, source2))
                    .thenReturn(List.of("someOtherField"));

            assertFalse(Helper.checkIsSkipApprovalFlow(source1, source2));
        }
    }

    @Test
    void checkIsAutoApproval_shouldReturnTrue_whenOnlyVerificationValidationDateChanged() {
        Source source1 = new Source();
        Source source2 = new Source();

        try (MockedStatic<DeepDiffUtil> mocked = mockStatic(DeepDiffUtil.class)) {
            mocked.when(() -> DeepDiffUtil.findChangedFields(source1, source2))
                    .thenReturn(List.of(PAYLOAD_VERIFICATION_VALIDATION_DATE));

            assertTrue(Helper.checkIsAutoApproval(source1, source2));
        }
    }

    @Test
    void checkIsAutoApproval_shouldReturnFalse_whenSingleDifferentFieldChanged() {
        Source source1 = new Source();
        Source source2 = new Source();

        try (MockedStatic<DeepDiffUtil> mocked = mockStatic(DeepDiffUtil.class)) {
            mocked.when(() -> DeepDiffUtil.findChangedFields(source1, source2))
                    .thenReturn(List.of("anotherField"));

            assertFalse(Helper.checkIsAutoApproval(source1, source2));
        }
    }

    @Test
    void checkIsAutoApproval_shouldReturnFalse_whenMoreThanOneFieldChanged() {
        Source source1 = new Source();
        Source source2 = new Source();

        try (MockedStatic<DeepDiffUtil> mocked = mockStatic(DeepDiffUtil.class)) {
            mocked.when(() -> DeepDiffUtil.findChangedFields(source1, source2))
                    .thenReturn(List.of(PAYLOAD_VERIFICATION_VALIDATION_DATE, "otherField"));

            assertFalse(Helper.checkIsAutoApproval(source1, source2));
        }
    }

    @Test
    void automatedServiceFlip_shouldSwap_whenEquifaxIsBeforeNsch() {
        List<Map<String, Object>> contacts = new ArrayList<>();

        Map<String, Object> equifax = new HashMap<>();
        equifax.put(NAME, EQUIFAX_EDU);

        Map<String, Object> other = new HashMap<>();
        other.put(NAME, "OTHER_VENDOR");

        Map<String, Object> nsch = new HashMap<>();
        nsch.put(NAME, NSCH);

        contacts.add(equifax);
        contacts.add(other);
        contacts.add(nsch);

        Helper.automatedServiceFlip(contacts);

        assertEquals(NSCH, contacts.get(0).get(NAME));
        assertEquals("OTHER_VENDOR", contacts.get(1).get(NAME));
        assertEquals(EQUIFAX_EDU, contacts.get(2).get(NAME));
    }

    @Test
    void automatedServiceFlip_shouldNotSwap_whenNschIsBeforeEquifax() {
        List<Map<String, Object>> contacts = new ArrayList<>();

        Map<String, Object> nsch = new HashMap<>();
        nsch.put(NAME, NSCH);

        Map<String, Object> equifax = new HashMap<>();
        equifax.put(NAME, EQUIFAX_EDU);

        contacts.add(nsch);
        contacts.add(equifax);

        Helper.automatedServiceFlip(contacts);

        assertEquals(NSCH, contacts.get(0).get(NAME));
        assertEquals(EQUIFAX_EDU, contacts.get(1).get(NAME));
    }

    @Test
    void automatedServiceFlip_shouldNotSwap_whenOneOrBothVendorsAreMissing() {
        List<Map<String, Object>> contacts = new ArrayList<>();

        Map<String, Object> other1 = new HashMap<>();
        other1.put(NAME, "OTHER_1");

        Map<String, Object> other2 = new HashMap<>();
        other2.put(NAME, "OTHER_2");

        contacts.add(other1);
        contacts.add(other2);

        Helper.automatedServiceFlip(contacts);

        assertEquals("OTHER_1", contacts.get(0).get(NAME));
        assertEquals("OTHER_2", contacts.get(1).get(NAME));
    }
}