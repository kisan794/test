package com.hireright.sourceintelligence.service.notification.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.regex.Pattern;

/**
 * Utility for sanitizing email content to prevent injection attacks.
 * Follows Single Responsibility Principle - only handles sanitization.
 */
@Slf4j
@Component
public class EmailSanitizer {
    
    // Patterns for detecting potentially malicious content
    private static final Pattern SCRIPT_PATTERN = Pattern.compile(
            "<script[^>]*>.*?</script>", 
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL
    );
    
    private static final Pattern IFRAME_PATTERN = Pattern.compile(
            "<iframe[^>]*>.*?</iframe>", 
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL
    );
    
    private static final Pattern ON_EVENT_PATTERN = Pattern.compile(
            "on\\w+\\s*=", 
            Pattern.CASE_INSENSITIVE
    );
    
    private static final Pattern JAVASCRIPT_PROTOCOL_PATTERN = Pattern.compile(
            "javascript:", 
            Pattern.CASE_INSENSITIVE
    );
    
    /**
     * Sanitizes email subject to prevent injection attacks
     */
    public String sanitizeSubject(String subject) {
        if (subject == null) {
            return null;
        }
        
        // Remove line breaks and control characters
        String sanitized = subject.replaceAll("[\\r\\n\\t]", " ");
        
        // Remove potential injection characters
        sanitized = sanitized.replaceAll("[<>]", "");
        
        log.debug("Sanitized subject");
        return sanitized.trim();
    }
    
    /**
     * Sanitizes HTML email body to prevent XSS attacks
     */
    public String sanitizeHtmlBody(String htmlBody) {
        if (htmlBody == null) {
            return null;
        }
        
        String sanitized = htmlBody;
        
        // Remove script tags
        sanitized = SCRIPT_PATTERN.matcher(sanitized).replaceAll("");
        
        // Remove iframe tags
        sanitized = IFRAME_PATTERN.matcher(sanitized).replaceAll("");
        
        // Remove event handlers (onclick, onload, etc.)
        sanitized = ON_EVENT_PATTERN.matcher(sanitized).replaceAll("");
        
        // Remove javascript: protocol
        sanitized = JAVASCRIPT_PROTOCOL_PATTERN.matcher(sanitized).replaceAll("");
        
        log.debug("Sanitized HTML body");
        return sanitized;
    }
    
    /**
     * Sanitizes plain text email body
     */
    public String sanitizePlainTextBody(String plainText) {
        if (plainText == null) {
            return null;
        }
        
        // For plain text, just trim and return
        // No HTML/script injection possible in plain text emails
        return plainText.trim();
    }
    
    /**
     * Sanitizes email address to prevent header injection
     */
    public String sanitizeEmailAddress(String email) {
        if (email == null) {
            return null;
        }
        
        // Remove line breaks and control characters that could be used for header injection
        String sanitized = email.replaceAll("[\\r\\n\\t]", "");
        
        return sanitized.trim();
    }
}

