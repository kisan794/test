package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.rds.CountryDTO;
import com.hireright.sourceintelligence.api.dto.rds.CountryRegionDTO;
import com.hireright.sourceintelligence.domain.entity.Country;
import com.hireright.sourceintelligence.domain.entity.CountryRegion;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CountryMapperImplTest {

    private CountryMapperImpl mapper;

    @BeforeEach
    void setUp() {
        mapper = new CountryMapperImpl();
    }

    @Test
    void entityToDTO_shouldReturnNull_whenEntityIsNull() {
        assertNull(mapper.entityToDTO(null));
    }

    @Test
    void entityToDTO_shouldMapAllFields_whenEntityHasValues() {
        Country entity = new Country();
        entity.setCountryId(BigDecimal.valueOf(101));
        entity.setName("India");
        entity.setCourtIntlCharge(BigDecimal.valueOf(11));
        entity.setEduIntlCharge(BigDecimal.valueOf(12));
        entity.setEmplIntlCharge(BigDecimal.valueOf(13));
        entity.setMvrIntlCharge(BigDecimal.valueOf(14));
        entity.setRefIntlCharge(BigDecimal.valueOf(15));
        entity.setCurrency("INR");
        entity.setDateFormat("dd/MM/yyyy");
        entity.setPhoneCountryCode("+91");
        entity.setSsnEquivalent("Aadhaar");
        entity.setStateEquivalent("State");
        entity.setZipEquivalent("PIN");
        entity.setCourtSearchLevel("STATE");
        entity.setDobRequired("Y");
        entity.setTimezone(BigDecimal.valueOf(55, 1));
        entity.setDobInquiry("Y");
        entity.setNidInquiry("N");
        entity.setNidRequired("Y");
        entity.setBirthPlaceRequired("N");
        entity.setBirthPlaceSendToVerifier("Y");
        entity.setObsolete("N");
        entity.setFinanceRegion("APAC");
        entity.setSupportRegion("INDIA");
        entity.setTable("COUNTRY");
        entity.setScn("2001");
        entity.setOpType("I");
        entity.setOpTs("2026-04-07 10:15:30");
        entity.setCurrentTs("2026-04-07 11:15:30");
        entity.setRowId("ROW_1");
        entity.setUsername("tester");

        CountryDTO result = mapper.entityToDTO(entity);

        assertNotNull(result);
        assertEquals("101", result.getCountryId());
        assertEquals("India", result.getName());
        assertEquals("11", result.getCourtIntlCharge());
        assertEquals("12", result.getEduIntlCharge());
        assertEquals("13", result.getEmplIntlCharge());
        assertEquals("14", result.getMvrIntlCharge());
        assertEquals("15", result.getRefIntlCharge());
        assertEquals("INR", result.getCurrency());
        assertEquals("dd/MM/yyyy", result.getDateFormat());
        assertEquals("+91", result.getPhoneCountryCode());
        assertEquals("Aadhaar", result.getSsnEquivalent());
        assertEquals("State", result.getStateEquivalent());
        assertEquals("PIN", result.getZipEquivalent());
        assertEquals("STATE", result.getCourtSearchLevel());
        assertEquals("Y", result.getDobRequired());
        assertEquals("5.5", result.getTimezone());
        assertEquals("Y", result.getDobInquiry());
        assertEquals("N", result.getNidInquiry());
        assertEquals("Y", result.getNidRequired());
        assertEquals("N", result.getBirthPlaceRequired());
        assertEquals("Y", result.getBirthPlaceSendToVerifier());
        assertEquals("N", result.getObsolete());
        assertEquals("APAC", result.getFinanceRegion());
        assertEquals("INDIA", result.getSupportRegion());
        assertEquals("COUNTRY", result.getTable());
        assertEquals("2001", result.getScn());
        assertEquals("I", result.getOpType());
        assertNotNull(result.getOpTs());
        assertNotNull(result.getCurrentTs());
        assertEquals("ROW_1", result.getRowId());
        assertEquals("tester", result.getUsername());
    }

    @Test
    void entityToDTO_shouldMapNullConvertibleFields_whenValuesAreNull() {
        Country entity = new Country();
        entity.setCountryId(null);
        entity.setName(null);
        entity.setCourtIntlCharge(null);
        entity.setEduIntlCharge(null);
        entity.setEmplIntlCharge(null);
        entity.setMvrIntlCharge(null);
        entity.setRefIntlCharge(null);
        entity.setCurrency(null);
        entity.setDateFormat(null);
        entity.setPhoneCountryCode(null);
        entity.setSsnEquivalent(null);
        entity.setStateEquivalent(null);
        entity.setZipEquivalent(null);
        entity.setCourtSearchLevel(null);
        entity.setDobRequired(null);
        entity.setTimezone(null);
        entity.setDobInquiry(null);
        entity.setNidInquiry(null);
        entity.setNidRequired(null);
        entity.setBirthPlaceRequired(null);
        entity.setBirthPlaceSendToVerifier(null);
        entity.setObsolete(null);
        entity.setFinanceRegion(null);
        entity.setSupportRegion(null);
        entity.setTable(null);
        entity.setScn(null);
        entity.setOpType(null);
        entity.setOpTs(null);
        entity.setCurrentTs(null);
        entity.setRowId(null);
        entity.setUsername(null);

        CountryDTO result = mapper.entityToDTO(entity);

        assertNotNull(result);

        // 🔥 BigDecimal → "0"
        assertEquals("0", result.getCountryId());
        assertEquals("0", result.getCourtIntlCharge());
        assertEquals("0", result.getEduIntlCharge());
        assertEquals("0", result.getEmplIntlCharge());
        assertEquals("0", result.getMvrIntlCharge());
        assertEquals("0", result.getRefIntlCharge());
        assertEquals("0", result.getTimezone());

        // 🔥 direct string mappings → null
        assertNull(result.getName());
        assertNull(result.getCurrency());
        assertNull(result.getDateFormat());
        assertNull(result.getPhoneCountryCode());
        assertNull(result.getSsnEquivalent());
        assertNull(result.getStateEquivalent());
        assertNull(result.getZipEquivalent());
        assertNull(result.getCourtSearchLevel());
        assertNull(result.getDobRequired());
        assertNull(result.getDobInquiry());
        assertNull(result.getNidInquiry());
        assertNull(result.getNidRequired());
        assertNull(result.getBirthPlaceRequired());
        assertNull(result.getBirthPlaceSendToVerifier());
        assertNull(result.getObsolete());
        assertNull(result.getFinanceRegion());
        assertNull(result.getSupportRegion());
        assertNull(result.getTable());
        assertNull(result.getScn());
        assertNull(result.getOpType());

        // 🔥 timestamp helper → null
        assertNull(result.getOpTs());
        assertNull(result.getCurrentTs());

        assertNull(result.getRowId());
        assertNull(result.getUsername());
    }

    @Test
    void entityToDTOList_shouldReturnNull_whenEntityListIsNull() {
        assertNull(mapper.entityToDTOList(null));
    }

    @Test
    void entityToDTOList_shouldReturnEmptyList_whenEntityListIsEmpty() {
        List<CountryDTO> result = mapper.entityToDTOList(Collections.emptyList());

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void entityToDTOList_shouldMapAllItems() {
        Country first = new Country();
        first.setCountryId(BigDecimal.ONE);
        first.setName("India");

        Country second = new Country();
        second.setCountryId(BigDecimal.valueOf(2));
        second.setName("USA");

        List<CountryDTO> result = mapper.entityToDTOList(Arrays.asList(first, second));

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("1", result.get(0).getCountryId());
        assertEquals("India", result.get(0).getName());
        assertEquals("2", result.get(1).getCountryId());
        assertEquals("USA", result.get(1).getName());
    }

    @Test
    void entityToRegionDTO_shouldReturnNull_whenEntityIsNull() {
        assertNull(mapper.entityToRegionDTO(null));
    }

    @Test
    void entityToRegionDTO_shouldMapAllFields_whenEntityHasValues() {
        CountryRegion entity = new CountryRegion();
        entity.setRegionId(11);
        entity.setCountryId(101);
        entity.setOldRegionId(5);
        entity.setRegionName("Karnataka");
        entity.setParentId(1);
        entity.setRegionLevel(2);
        entity.setIso31662("IN-KA");
        entity.setObsolete("N");
        entity.setTable("COUNTRY_REGION");
        entity.setScn("3001");
        entity.setOpType("U");
        entity.setOpTs("2026-04-07 12:00:00");
        entity.setCurrentTs("2026-04-07 13:00:00");
        entity.setRowId("REG_ROW_1");
        entity.setUsername("regionTester");
        entity.setHrCode("HR001");
        entity.setAreaCodes(Arrays.asList("080", "081"));

        CountryRegionDTO result = mapper.entityToRegionDTO(entity);

        assertNotNull(result);
        assertEquals("11", result.getId());
        assertEquals("101", result.getCountryId());
        assertEquals("5", result.getOldRegionId());
        assertEquals("Karnataka", result.getRegionName());
        assertEquals("1", result.getParentId());
        assertEquals("2", result.getRegionLevel());
        assertEquals("IN-KA", result.getIso31662());
        assertEquals("N", result.getObsolete());
        assertEquals("COUNTRY_REGION", result.getTable());
        assertEquals("3001", result.getScn());
        assertEquals("U", result.getOpType());
        assertNotNull(result.getOpTs());
        assertNotNull(result.getCurrentTs());
        assertEquals("REG_ROW_1", result.getRowId());
        assertEquals("regionTester", result.getUsername());
        assertEquals("HR001", result.getHrCode());
        assertEquals(Arrays.asList("080", "081"), result.getAreaCodes());
    }

    @Test
    void entityToRegionDTO_shouldMapNullConvertibleFields_whenValuesAreNull() {
        CountryRegion entity = new CountryRegion();
        entity.setRegionId(null);
        entity.setCountryId(null);
        entity.setOldRegionId(null);
        entity.setRegionName(null);
        entity.setParentId(null);
        entity.setRegionLevel(null);
        entity.setIso31662(null);
        entity.setObsolete(null);
        entity.setTable(null);
        entity.setScn(null);
        entity.setOpType(null);
        entity.setOpTs(null);
        entity.setCurrentTs(null);
        entity.setRowId(null);
        entity.setUsername(null);
        entity.setHrCode(null);
        entity.setAreaCodes(null);

        CountryRegionDTO result = mapper.entityToRegionDTO(entity);

        assertNotNull(result);
        assertNull(result.getId());
        assertNull(result.getCountryId());
        assertNull(result.getOldRegionId());
        assertNull(result.getRegionName());
        assertNull(result.getParentId());
        assertNull(result.getRegionLevel());
        assertNull(result.getIso31662());
        assertNull(result.getObsolete());
        assertNull(result.getTable());
        assertNull(result.getScn());
        assertNull(result.getOpType());
        assertNull(result.getOpTs());
        assertNull(result.getCurrentTs());
        assertNull(result.getRowId());
        assertNull(result.getUsername());
        assertNull(result.getHrCode());
        assertNull(result.getAreaCodes());
    }

    @Test
    void entityToRegionDTOList_shouldReturnNull_whenEntityListIsNull() {
        assertNull(mapper.entityToRegionDTOList(null));
    }

    @Test
    void entityToRegionDTOList_shouldReturnEmptyList_whenEntityListIsEmpty() {
        List<CountryRegionDTO> result = mapper.entityToRegionDTOList(Collections.emptyList());

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void entityToRegionDTOList_shouldMapAllItems() {
        CountryRegion first = new CountryRegion();
        first.setRegionId(1);
        first.setRegionName("Region One");

        CountryRegion second = new CountryRegion();
        second.setRegionId(2);
        second.setRegionName("Region Two");

        List<CountryRegionDTO> result = mapper.entityToRegionDTOList(Arrays.asList(first, second));

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("1", result.get(0).getId());
        assertEquals("Region One", result.get(0).getRegionName());
        assertEquals("2", result.get(1).getId());
        assertEquals("Region Two", result.get(1).getRegionName());
    }
}