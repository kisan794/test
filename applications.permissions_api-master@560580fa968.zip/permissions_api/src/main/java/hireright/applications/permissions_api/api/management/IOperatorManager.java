package hireright.applications.permissions_api.api.management;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-02-04  HRG-330191 initial version
 */

import hireright.applications.permissions_api.model.COperator;
import hireright.applications.permissions_api.model.COperatorFilter;
import hireright.applications.permissions_api.model.CSort;

public interface IOperatorManager
	extends IRecordManager<COperator, String, CSort<COperator.EField>, COperatorFilter>
{
	@Override
	default CSort<COperator.EField> getDefaultSort()
	{
		return CSort.asc(COperator.EField.USERNAME);
	}
}
