package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.FieldErrorsDTO;
import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.api.v2.dto.SourceDTO;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class SourceV2MapperImplTest {

    private SourceV2MapperImpl mapper;

    @BeforeEach
    void setUp() {
        mapper = new SourceV2MapperImpl();
    }

    @Test
    void sourceDTOtoSourceOrganizationDTO_shouldReturnNull_whenInputIsNull() {
        assertNull(mapper.sourceDTOtoSourceOrganizationDTO(null));
    }

    @Test
    void sourceDTOtoSourceOrganizationDTO_shouldMapAllFields_whenAllFieldsPresent() {
        FieldErrorsDTO generalError = mock(FieldErrorsDTO.class);
        FieldErrorsDTO fieldError = mock(FieldErrorsDTO.class);

        List<FieldErrorsDTO> generalErrors = Collections.singletonList(generalError);
        List<FieldErrorsDTO> fieldErrors = Collections.singletonList(fieldError);

        JSONObject payload = new JSONObject();
        payload.put("key", "value");

        Instant lastModifiedDate = Instant.parse("2026-04-07T10:15:30Z");

        SourceDTO sourceDTO = SourceDTO.builder()
                .name("Test Org")
                .type(OrganizationType.values()[0])
                .hon("HON123")
                .status(SourceOrganizationStatus.ACTIVE)
                .version(5.0)
                .payload(payload)
                .approvalStatus(ApprovalStatus.APPROVED)
                .lastModifiedDate(lastModifiedDate)
                .reviewRequired("YES")
                .postalCode("560001")
                .createdDate("2026-04-01T00:00:00Z")
                .lastModifierId("lm123")
                .lastModifiedBy("tester")
                .location("Chicago")
                .comments("some comments")
                .generalErrors(generalErrors)
                .fieldErrors(fieldErrors)
                .build();

        SourceOrganizationDTO result = mapper.sourceDTOtoSourceOrganizationDTO(sourceDTO);

        assertNotNull(result);
        assertEquals("Test Org", result.getOrganizationName());
        assertEquals(OrganizationType.values()[0], result.getOrganizationType());
        assertEquals("HON123", result.getHon());
        assertEquals(SourceOrganizationStatus.ACTIVE, result.getStatus());
        assertEquals(5.0, result.getVersion());
        assertSame(payload, result.getPayload());
        assertEquals(ApprovalStatus.APPROVED, result.getApprovalStatus());
        assertEquals(lastModifiedDate, result.getLastModifiedDate());
        assertEquals("YES", result.getReviewRequired());
        assertEquals("560001", result.getPostalCode());
        assertEquals("2026-04-01T00:00:00Z", result.getCreatedDate());
        assertEquals("lm123", result.getLastModifierId());
        assertEquals("tester", result.getLastModifiedBy());
        assertEquals("Chicago", result.getLocation());
        assertEquals("some comments", result.getComments());

        assertNotNull(result.getGeneralErrors());
        assertNotNull(result.getFieldErrors());
        assertEquals(1, result.getGeneralErrors().size());
        assertEquals(1, result.getFieldErrors().size());

        assertNotSame(generalErrors, result.getGeneralErrors());
        assertNotSame(fieldErrors, result.getFieldErrors());
        assertSame(generalError, result.getGeneralErrors().get(0));
        assertSame(fieldError, result.getFieldErrors().get(0));
    }

    @Test
    void sourceDTOtoSourceOrganizationDTO_shouldSkipNullableFields_whenFieldsAreNull() {
        SourceDTO sourceDTO = SourceDTO.builder()
                .version(10.0)
                .build();

        SourceOrganizationDTO result = mapper.sourceDTOtoSourceOrganizationDTO(sourceDTO);

        assertNotNull(result);
        assertNull(result.getOrganizationName());
        assertNull(result.getOrganizationType());
        assertNull(result.getHon());
        assertNull(result.getStatus());
        assertEquals(10.0, result.getVersion());
        assertNull(result.getPayload());
        assertNull(result.getApprovalStatus());
        assertNull(result.getLastModifiedDate());
        assertNull(result.getReviewRequired());
        assertNull(result.getPostalCode());
        assertNull(result.getCreatedDate());
        assertNull(result.getLastModifierId());
        assertNull(result.getLastModifiedBy());
        assertNull(result.getLocation());
        assertNull(result.getComments());
        assertNull(result.getGeneralErrors());
        assertNull(result.getFieldErrors());
    }

    @Test
    void sourceOrganizationDTOtoSourceDTO_shouldReturnNull_whenInputIsNull() {
        assertNull(mapper.sourceOrganizationDTOtoSourceDTO(null));
    }

    @Test
    void sourceOrganizationDTOtoSourceDTO_shouldMapAllFields_whenAllFieldsPresent() {
        FieldErrorsDTO generalError = mock(FieldErrorsDTO.class);
        FieldErrorsDTO fieldError = mock(FieldErrorsDTO.class);

        List<FieldErrorsDTO> generalErrors = Collections.singletonList(generalError);
        List<FieldErrorsDTO> fieldErrors = Collections.singletonList(fieldError);

        JSONObject payload = new JSONObject();
        payload.put("key", "value");

        Instant lastModifiedDate = Instant.parse("2026-04-07T10:15:30Z");

        SourceOrganizationDTO sourceOrganizationDTO = SourceOrganizationDTO.builder()
                .organizationName("Test Org")
                .organizationType(OrganizationType.values()[0])
                .hon("HON456")
                .status(SourceOrganizationStatus.ACTIVE)
                .version(7.0)
                .approvalStatus(ApprovalStatus.APPROVED)
                .payload(payload)
                .reviewRequired("NO")
                .postalCode("110001")
                .location("New York")
                .createdDate("2026-03-01T00:00:00Z")
                .lastModifiedBy("admin")
                .lastModifierId("lm999")
                .lastModifiedDate(lastModifiedDate)
                .comments("org comments")
                .generalErrors(generalErrors)
                .fieldErrors(fieldErrors)
                .build();

        SourceDTO result = mapper.sourceOrganizationDTOtoSourceDTO(sourceOrganizationDTO);

        assertNotNull(result);
        assertEquals("Test Org", result.getName());
        assertEquals(OrganizationType.values()[0], result.getType());
        assertEquals("HON456", result.getHon());
        assertEquals(SourceOrganizationStatus.ACTIVE, result.getStatus());
        assertEquals(7.0, result.getVersion());
        assertEquals(ApprovalStatus.APPROVED, result.getApprovalStatus());
        assertSame(payload, result.getPayload());
        assertEquals("NO", result.getReviewRequired());
        assertEquals("110001", result.getPostalCode());
        assertEquals("New York", result.getLocation());
        assertEquals("2026-03-01T00:00:00Z", result.getCreatedDate());
        assertEquals("admin", result.getLastModifiedBy());
        assertEquals("lm999", result.getLastModifierId());
        assertEquals(lastModifiedDate, result.getLastModifiedDate());
        assertEquals("org comments", result.getComments());

        assertNotNull(result.getGeneralErrors());
        assertNotNull(result.getFieldErrors());
        assertEquals(1, result.getGeneralErrors().size());
        assertEquals(1, result.getFieldErrors().size());

        assertNotSame(generalErrors, result.getGeneralErrors());
        assertNotSame(fieldErrors, result.getFieldErrors());
        assertSame(generalError, result.getGeneralErrors().get(0));
        assertSame(fieldError, result.getFieldErrors().get(0));
    }

    @Test
    void sourceOrganizationDTOtoSourceDTO_shouldSkipNullableFields_whenFieldsAreNull() {
        SourceOrganizationDTO sourceOrganizationDTO = SourceOrganizationDTO.builder()
                .version(20.0)
                .build();

        SourceDTO result = mapper.sourceOrganizationDTOtoSourceDTO(sourceOrganizationDTO);

        assertNotNull(result);
        assertNull(result.getName());
        assertNull(result.getType());
        assertNull(result.getHon());
        assertNull(result.getStatus());
        assertEquals(20.0, result.getVersion());
        assertNull(result.getApprovalStatus());
        assertNull(result.getPayload());
        assertNull(result.getReviewRequired());
        assertNull(result.getPostalCode());
        assertNull(result.getLocation());
        assertNull(result.getCreatedDate());
        assertNull(result.getLastModifiedBy());
        assertNull(result.getLastModifierId());
        assertNull(result.getLastModifiedDate());
        assertNull(result.getComments());
        assertNull(result.getGeneralErrors());
        assertNull(result.getFieldErrors());
    }

    @Test
    void toSourceDTOList_shouldReturnNull_whenInputIsNull() {
        assertNull(mapper.toSourceDTOList(null));
    }

    @Test
    void toSourceDTOList_shouldMapAllItems() {
        SourceOrganizationDTO first = SourceOrganizationDTO.builder()
                .organizationName("Org1")
                .organizationType(OrganizationType.values()[0])
                .hon("HON1")
                .status(SourceOrganizationStatus.ACTIVE)
                .version(1.0)
                .build();

        SourceOrganizationDTO second = SourceOrganizationDTO.builder()
                .organizationName("Org2")
                .organizationType(OrganizationType.values()[0])
                .hon("HON2")
                .status(SourceOrganizationStatus.INACTIVE)
                .version(2.0)
                .build();

        List<SourceDTO> result = mapper.toSourceDTOList(Arrays.asList(first, second));

        assertNotNull(result);
        assertEquals(2, result.size());

        assertEquals("Org1", result.get(0).getName());
        assertEquals(OrganizationType.values()[0], result.get(0).getType());
        assertEquals("HON1", result.get(0).getHon());
        assertEquals(SourceOrganizationStatus.ACTIVE, result.get(0).getStatus());
        assertEquals(1.0, result.get(0).getVersion());

        assertEquals("Org2", result.get(1).getName());
        assertEquals(OrganizationType.values()[0], result.get(1).getType());
        assertEquals("HON2", result.get(1).getHon());
        assertEquals(SourceOrganizationStatus.INACTIVE, result.get(1).getStatus());
        assertEquals(2.0, result.get(1).getVersion());
    }

    @Test
    void toSourceDTOList_shouldReturnEmptyList_whenInputIsEmpty() {
        List<SourceDTO> result = mapper.toSourceDTOList(Collections.emptyList());

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
}