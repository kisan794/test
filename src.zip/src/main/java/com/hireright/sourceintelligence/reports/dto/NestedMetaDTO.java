package com.hireright.sourceintelligence.reports.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NestedMetaDTO {
    
    @JsonProperty("header")
    private String header;
    
    @JsonProperty("accessorKey")
    private String accessorKey;
    
    @JsonProperty("columns")
    private List<NestedMetaDTO> columns;
}

