package com.hireright.sourceintelligence.reports.service.impl;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ReportConstants {

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class AggregateFields {
        public static final String ID = "_id";
        public static final String STATUS = "status";
        public static final String ORGANIZATION_NAME = "organizationName";
        public static final String USED_COUNT = "usedCount";
        public static final String CREATED_DATE = "createdDate";
        public static final String VERIFICATION_VALIDATION_DATE = "verificationValidationDate";
        public static final String ADDRESS = "address";
        public static final String APPROVAL_STATUS = "approvalStatus";
        public static final String APPROVED_BY = "approvedBy";
        public static final String ORGANIZATION_TYPE = "organizationType";
        public static final String ORIGIN = "origin";
        public static final String APPROVED_ID = "approvedId";
        public static final String HON = "hon";
        public static final String CREATED_BY = "createdBy";
        public static final String OPERATOR_ROLE = "operatorRole";
        public static final String AUTO_MATCH = "autoMatch";
        public static final String REASON = "reason";
        public static final String TXN_TYPE = "txnType";
        public static final String COUNT = "count";
        public static final String DATA = "data";
        public static final String TOTAL_COUNT = "$total.count";
        public static final String APPROVAL_DURATION = "approvalDuration";
        public static final String TAT_DURATION = "totalApprovalDuration";
        public static final String CHANGE_TYPE = "changeType";
        public static final String RESEARCHER_NAME = "researcherName";
        public static final String APPROVED_DATE = "last_approved_date";
        public static final String ACTION_DATE = "last_action_date";
        public static final String S_CREATED_DATE = "created_date";
        public static final String VERSION = "version";
        public static final String TEMP_VERSION = "tempVersion";
        public static final String DATA_APPROVAL_STATUS = "data.approvalStatus";

        public static final String APPROVED = "APPROVED";
        public static final String REJECTED = "REJECTED";
        public static final String ARCHIVED2 = "Archived";
        //Source information
        public static final String ACTION_USED_COUNT = "UsedCount";
        public static final String ADDED = "added";
        public static final String CHANGED = "changed";
        public static final String CANCELLED = "cancelled";
        public static final String ARCHIVED = "archived";
        public static final String PROGRESS = "inProgress";
        public static final String ON_HOLD = "onHold";
        public static final String COMPLETED = "completed";
        public static final String ACTION = "action";

        public static final String CREATE = "Create";
        public static final String UPDATE = "Update";
        public static final String IN_PROGRESS = "In Progress";
        public static final String DELETE = "DELETE";
        public static final String DELETE2 = "Delete";
        public static final String ARCHIVED_ACTION = "Archived";
        public static final String RESPONSE_REPORT_LIST= "responseReportList";
        public static final String TAT_REPORT_LIST= "tatResponseReportList";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class ReportTypes {
        public static final String CONTACT_UTILIZATION = "contact-utilization";
        public static final String AUTO_MATCH = "auto-match";
        public static final String SOURCE_INFORMATION = "source-information";
        public static final String SOURCE_INFORMATION_REVIEWER = "source-information-reviewer";
        public static final String SOURCE_INFORMATION_OPERATOR_REVIEWER = "source-information-operator-reviewer";
        public static final String APPROVAL_TAT = "performance-of-source-approval-teams";
        public static final String DELETE_SOURCE_REPORT = "source-deletion";
    }
    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    protected static class MetaData {
        protected static final String LAST_USED = "Last_Used";
        protected static final String USED_DATE = "Used_Date";
        protected static final String SOURCE_NAME = "Source_Name";
        protected static final String ORG_NAME = "Organization_Name";
        protected static final String DELETED_BY = "Deleted_By";
        protected static final String DELETED_DATE = "Deleted_Date";
        protected static final String APPROVED_BY = "Approved_By";
        protected static final String ADDRESS = "Address";
        protected static final String ORG_TYPE = "Organization_Type";
        protected static final String USED_COUNT = "Used_Count";
        protected static final String REVIEWER_NAME = "Reviewer_Name";
        protected static final String ORIGINATOR_NAME = "Originator_Name";
        protected static final String RESEARCHER_NAME = "Researcher_Name";
        protected static final String CHANGE_TYPE = "Change_Type";
        protected static final String CREATED_BY = "Created_By";
        protected static final String ACTION = "Action";
        protected static final String REASON = "Reason";
        protected static final String ORIGIN = "Origin";
        protected static final String APPROVAL_STATUS = "ApprovalStatus";


        protected static final String[] DELETE_META_DATA = new String[]{"Hon",SOURCE_NAME,ADDRESS,ORG_TYPE,DELETED_BY,REASON, DELETED_DATE};
        protected static final String[] CONTACT_UTILIZATION_META_DATA = new String[]{"Hon",ORG_NAME,LAST_USED,ADDRESS,SortFields.VERIFICATION_DATE,ORG_TYPE,ORIGIN,SortFields.APPROVAL_STATUS,APPROVED_BY,USED_COUNT};
        protected static final String[] AUTO_MATCH_META_DATA = new String[]{"Hon",ORG_NAME,ADDRESS,ORG_TYPE,USED_COUNT,SortFields.IS_AUTO_MATCH};
        protected static final String[] SOURCE_INFORMATION_META_DATA = new String[]{"Hon",RESEARCHER_NAME,"Added","Changed",AggregateFields.ARCHIVED2,SortFields.IN_PROGRESS,SortFields.ON_HOLD, SortFields.CANCELLED ,SortFields.COMPLETED};
        protected static final String[] SOURCE_INFORMATION_REVIEWER_META_DATA = new String[]{RESEARCHER_NAME,"New", SortFields.IN_PROGRESS, SortFields.ON_HOLD, SortFields.CANCELLED, SortFields.COMPLETED, "Total"};
        protected static final String[] SOURCE_INFORMATION_OPERATOR_REVIEWER_META_DATA = new String[]{ RESEARCHER_NAME, "Added", "Changed", AggregateFields.ARCHIVED2, "Deleted", "New", SortFields.IN_PROGRESS, "On Hold", SortFields.CANCELLED, SortFields.COMPLETED, "Total"};
        protected static final String[] APPROVAL_TAT_META_DATA = new String[]{"Hon",ORG_NAME,ORG_TYPE, ORIGINATOR_NAME,CHANGE_TYPE,SortFields.APPROVAL_STATUS,REVIEWER_NAME,"Approval_Duration","Total_Approval_Duration"};
        protected static final String[] DEFAULT_META_DATA = new String[]{};

    }
    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class Regex {
        public static final String CAMEL_CASE_REGEX = "([a-z])([A-Z])";
        public static final String SNAKE_CASE_REGEX = "$1_$2";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class MongoRegex {
        public static final String IN = "$in";
        public static final String EXPR = "$expr";
        public static final String DOLLAR = "$";
        public static final String SPLIT = "$split";
        public static final String ARRAY_ELEM_AT = "$arrayElemAt";
        public static final String DATE_FROM_STRING = "$dateFromString";
        public static final String DATE_STRING = "dateString";
        public static final String FORMAT = "format";
        public static final String ON_ERROR = "onError";
        public static final String ON_NULL = "onNull";
        public static final String DATE_FORMAT = "%m/%d/%Y";
    }

    @NoArgsConstructor(access = AccessLevel.PUBLIC)
    public static class SortFields {
        public static final String ORGANIZATION_NAME = "Organization_Name";
        public static final String ORGANIZATION_TYPE = "Organization_Type";
        public static final String ADDRESS = "Address";
        public static final String APPROVED_BY = "Approved_By";
        public static final String CREATED_BY = "Created_By";
        public static final String REASON = "Reason";
        public static final String USED_DATE = "Used_Date";
        public static final String HON = "HON";
        public static final String HON_1 = "Hon";
        public static final String VERIFICATION_DATE = "Verification_Validation_Date";
        public static final String AUTO_MATCH = "Auto_Match";
        public static final String IS_AUTO_MATCH = "Is_Auto_Match";
        public static final String APPROVAL_STATUS = "Approval_Status";
        public static final String RESEARCHER_NAME = "Researcher_Name";
        public static final String NEW_COUNT = "New";
        public static final String IN_PROGRESS = "In_Progress";
        public static final String ON_HOLD = "On_Hold";
        public static final String CANCELLED = "Cancelled";
        public static final String COMPLETED = "Completed";
        public static final String OPERATOR_NAME = "Operator_Name";
        public static final String ADDED_NEW = "added_new";
        public static final String ADDED_IN_PROGRESS = "added_inProgress";
        public static final String ADDED_ON_HOLD = "added_onHold";
        public static final String ADDED_CANCELLED = "added_cancelled";
        public static final String ADDED_COMPLETED = "added_completed";
        public static final String CHANGED_NEW = "changed_new";
        public static final String CHANGED_IN_PROGRESS = "changed_inProgress";
        public static final String CHANGED_ON_HOLD = "changed_onHold";
        public static final String CHANGED_CANCELLED = "changed_cancelled";
        public static final String CHANGED_COMPLETED = "changed_completed";
        public static final String ARCHIVED_NEW = "archived_new";
        public static final String ARCHIVED_IN_PROGRESS = "archived_inProgress";
        public static final String ARCHIVED_ON_HOLD = "archived_onHold";
        public static final String ARCHIVED_CANCELLED = "archived_cancelled";
        public static final String ARCHIVED_COMPLETED = "archived_completed";
        public static final String DELETED_NEW = "deleted_new";
        public static final String DELETED_IN_PROGRESS = "deleted_inProgress";
        public static final String DELETED_ON_HOLD = "deleted_onHold";
        public static final String DELETED_CANCELLED = "deleted_cancelled";
        public static final String DELETED_COMPLETED = "deleted_completed";

        public static final String REVIEWER_BY = "Reviewer_Name";
        public static final String CHANGE_TYPE = "Change_Type";
        public static final String ACTION = "Action";
        public static final String USED_COUNT = "Used_Count";
        public static final String ORIGIN = "Origin";
        public static final String CREATED_DATE = "Created_Date";
    }
}
