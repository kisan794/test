package hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl;

import hireright.applications.fulfillment_task_api.rest.recombointegration.exception.XmlTransformationException;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ScreeningType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for EducationXmlToJsonConverter
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@DisplayName("EducationXmlToJsonConverter Tests")
class EducationXmlToJsonConverterTest {

    private EducationXmlToJsonConverter converter;

    @BeforeEach
    void setUp() {
        converter = new EducationXmlToJsonConverter();
    }

    @Test
    @DisplayName("Should return EDUCATION screening type")
    void testGetType() {
        // When
        ScreeningType type = converter.getType();

        // Then
        assertEquals(ScreeningType.EDUCATION, type);
    }

    @Test
    @DisplayName("Should throw exception when XML is null")
    void testConvertNullXml() {
        // When & Then
        XmlTransformationException exception = assertThrows(
                XmlTransformationException.class,
                () -> converter.convert(null)
        );

        assertEquals("XML_EMPTY", exception.getErrorCode());
        assertTrue(exception.getMessage().contains("XML content cannot be null or empty"));
    }

    @Test
    @DisplayName("Should throw exception when XML is empty")
    void testConvertEmptyXml() {
        // When & Then
        XmlTransformationException exception = assertThrows(
                XmlTransformationException.class,
                () -> converter.convert("")
        );

        assertEquals("XML_EMPTY", exception.getErrorCode());
    }

    @Test
    @DisplayName("Should throw exception when XML is whitespace only")
    void testConvertWhitespaceXml() {
        // When & Then
        XmlTransformationException exception = assertThrows(
                XmlTransformationException.class,
                () -> converter.convert("   ")
        );

        assertEquals("XML_EMPTY", exception.getErrorCode());
    }

    @Test
    @DisplayName("Should convert valid education XML to JSON")
    void testConvertValidXml() {
        // Given
        String xml = """
                <EducationScreeningList>
                    <EducationScreening>
                        <Screening>
                            <Type>education</Type>
                            <ProducerReferenceId>EDU-001</ProducerReferenceId>
                            <EducationVerificationReport>
                                <EducationResult>
                                    <Institution>
                                        <OrganizationName>Harvard University</OrganizationName>
                                        <PostalAddress>
                                            <Municipality>Cambridge</Municipality>
                                            <Region>MA</Region>
                                            <CountryCode>US</CountryCode>
                                        </PostalAddress>
                                    </Institution>
                                </EducationResult>
                            </EducationVerificationReport>
                        </Screening>
                    </EducationScreening>
                </EducationScreeningList>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.contains("NSCH"));
        assertTrue(json.contains("education"));
    }

    @Test
    @DisplayName("Should throw exception for invalid XML")
    void testConvertInvalidXml() {
        // Given
        String invalidXml = "<invalid><unclosed>";

        // When & Then
        XmlTransformationException exception = assertThrows(
                XmlTransformationException.class,
                () -> converter.convert(invalidXml)
        );

        assertEquals("JSON_CONVERSION_FAILED", exception.getErrorCode());
    }

    @Test
    @DisplayName("Should convert XML with single education result")
    void testConvertSingleEducationResult() {
        // Given
        String xml = """
                <EducationScreeningList>
                    <EducationScreening>
                        <Screening>
                            <Type>education</Type>
                            <ProducerReferenceId>EDU-001</ProducerReferenceId>
                            <EducationVerificationReport>
                                <EducationResult>
                                    <Institution>
                                        <OrganizationName>MIT</OrganizationName>
                                    </Institution>
                                </EducationResult>
                            </EducationVerificationReport>
                        </Screening>
                    </EducationScreening>
                </EducationScreeningList>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.contains("MIT"));
    }

    @Test
    @DisplayName("Should convert XML with multiple education results")
    void testConvertMultipleEducationResults() {
        // Given
        String xml = """
                <EducationScreeningList>
                    <EducationScreening>
                        <Screening>
                            <Type>education</Type>
                            <ProducerReferenceId>EDU-001</ProducerReferenceId>
                            <EducationVerificationReport>
                                <EducationResult>
                                    <Institution>
                                        <OrganizationName>Harvard</OrganizationName>
                                    </Institution>
                                </EducationResult>
                                <EducationResult>
                                    <Institution>
                                        <OrganizationName>MIT</OrganizationName>
                                    </Institution>
                                </EducationResult>
                            </EducationVerificationReport>
                        </Screening>
                    </EducationScreening>
                </EducationScreeningList>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.contains("Harvard"));
        assertTrue(json.contains("MIT"));
    }

    @Test
    @DisplayName("Should handle XML without EducationScreeningList wrapper")
    void testConvertWithoutWrapper() {
        // Given
        String xml = """
                <EducationScreening>
                    <Screening>
                        <Type>education</Type>
                        <ProducerReferenceId>EDU-001</ProducerReferenceId>
                        <EducationVerificationReport>
                            <EducationResult>
                                <Institution>
                                    <OrganizationName>Stanford</OrganizationName>
                                </Institution>
                            </EducationResult>
                        </EducationVerificationReport>
                    </Screening>
                </EducationScreening>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.contains("Stanford"));
    }

    @Test
    @DisplayName("Should use default type when type is missing")
    void testConvertWithMissingType() {
        // Given
        String xml = """
                <EducationScreeningList>
                    <EducationScreening>
                        <Screening>
                            <ProducerReferenceId>EDU-001</ProducerReferenceId>
                            <EducationVerificationReport>
                                <EducationResult>
                                    <Institution>
                                        <OrganizationName>Yale</OrganizationName>
                                    </Institution>
                                </EducationResult>
                            </EducationVerificationReport>
                        </Screening>
                    </EducationScreening>
                </EducationScreeningList>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.contains("education"));
    }

    @Test
    @DisplayName("Should handle XML with special characters")
    void testConvertWithSpecialCharacters() {
        // Given
        String xml = """
                <EducationScreeningList>
                    <EducationScreening>
                        <Screening>
                            <Type>education</Type>
                            <ProducerReferenceId>EDU-001</ProducerReferenceId>
                            <EducationVerificationReport>
                                <EducationResult>
                                    <Institution>
                                        <OrganizationName>University &amp; College</OrganizationName>
                                    </Institution>
                                </EducationResult>
                            </EducationVerificationReport>
                        </Screening>
                    </EducationScreening>
                </EducationScreeningList>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.contains("University"));
    }

    @Test
    @DisplayName("Should handle XML with missing EducationResult")
    void testConvertWithMissingEducationResult() {
        // Given
        String xml = """
                <EducationScreeningList>
                    <EducationScreening>
                        <Screening>
                            <Type>education</Type>
                            <ProducerReferenceId>EDU-001</ProducerReferenceId>
                            <EducationVerificationReport>
                            </EducationVerificationReport>
                        </Screening>
                    </EducationScreening>
                </EducationScreeningList>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.contains("EDU-001"));
    }

    @Test
    @DisplayName("Should convert XML with complete education data")
    void testConvertCompleteEducationData() {
        // Given
        String xml = """
                <EducationScreeningList>
                    <EducationScreening>
                        <Screening>
                            <Type>education</Type>
                            <ProducerReferenceId>EDU-001</ProducerReferenceId>
                            <EducationVerificationReport>
                                <EducationResult>
                                    <Institution>
                                        <OrganizationName>Harvard University</OrganizationName>
                                        <PostalAddress>
                                            <Municipality>Cambridge</Municipality>
                                            <Region>MA</Region>
                                            <CountryCode>US</CountryCode>
                                        </PostalAddress>
                                    </Institution>
                                    <Degree>
                                        <DegreeName>Bachelor of Science</DegreeName>
                                        <DegreeDate>2024-05-31</DegreeDate>
                                    </Degree>
                                </EducationResult>
                            </EducationVerificationReport>
                        </Screening>
                    </EducationScreening>
                </EducationScreeningList>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.contains("Harvard University"));
        assertTrue(json.contains("Cambridge"));
        assertTrue(json.contains("MA"));
    }

    @Test
    @DisplayName("Should handle large XML input")
    void testConvertLargeXml() {
        // Given
        StringBuilder xmlBuilder = new StringBuilder("<EducationScreeningList>");
        for (int i = 0; i < 10; i++) {
            xmlBuilder.append("""
                    <EducationScreening>
                        <Screening>
                            <Type>education</Type>
                            <ProducerReferenceId>EDU-%d</ProducerReferenceId>
                            <EducationVerificationReport>
                                <EducationResult>
                                    <Institution>
                                        <OrganizationName>University %d</OrganizationName>
                                    </Institution>
                                </EducationResult>
                            </EducationVerificationReport>
                        </Screening>
                    </EducationScreening>
                    """.formatted(i, i));
        }
        xmlBuilder.append("</EducationScreeningList>");

        // When
        String json = converter.convert(xmlBuilder.toString());

        // Then
        assertNotNull(json);
        assertTrue(json.length() > 0);
    }

    @Test
    @DisplayName("Should produce valid JSON output")
    void testProducesValidJson() {
        // Given
        String xml = """
                <EducationScreeningList>
                    <EducationScreening>
                        <Screening>
                            <Type>education</Type>
                            <ProducerReferenceId>EDU-001</ProducerReferenceId>
                            <EducationVerificationReport>
                                <EducationResult>
                                    <Institution>
                                        <OrganizationName>Princeton</OrganizationName>
                                    </Institution>
                                </EducationResult>
                            </EducationVerificationReport>
                        </Screening>
                    </EducationScreening>
                </EducationScreeningList>
                """;

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        assertTrue(json.startsWith("{"));
        assertTrue(json.endsWith("}"));
        assertTrue(json.contains("\"name\""));
        assertTrue(json.contains("\"type\""));
    }
}

