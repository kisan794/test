package com.hireright.sourceintelligence.service.excel;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class ExcelCellReaderTest {

    private Workbook workbook;
    private Sheet sheet;
    private Row row;

    @BeforeEach
    void setUp() {
        workbook = new XSSFWorkbook();
        sheet = workbook.createSheet("Test Sheet");
        row = sheet.createRow(0);
    }

    @AfterEach
    void tearDown() throws IOException {
        if (workbook != null) {
            workbook.close();
        }
    }

    @Test
    void getCellValue_WithStringCell_ShouldReturnTrimmedString() {
        Cell cell = row.createCell(0);
        cell.setCellValue("  Test Value  ");

        String result = ExcelCellReader.getCellValue(row, 0);

        assertEquals("Test Value", result);
    }

    @Test
    void getCellValue_WithNumericCell_ShouldReturnNumericString() {
        Cell cell = row.createCell(0);
        cell.setCellValue(123.0);

        String result = ExcelCellReader.getCellValue(row, 0);

        assertEquals("123", result);
    }

    @Test
    void getCellValue_WithDecimalNumericCell_ShouldReturnDecimalString() {
        Cell cell = row.createCell(0);
        cell.setCellValue(123.45);

        String result = ExcelCellReader.getCellValue(row, 0);

        assertEquals("123.45", result);
    }

    @Test
    void getCellValue_WithBooleanCell_ShouldReturnBooleanString() {
        Cell cell = row.createCell(0);
        cell.setCellValue(true);

        String result = ExcelCellReader.getCellValue(row, 0);

        assertEquals("true", result);
    }

    @Test
    void getCellValue_WithBlankCell_ShouldReturnEmptyString() {
        Cell cell = row.createCell(0);
        cell.setBlank();

        String result = ExcelCellReader.getCellValue(row, 0);

        assertEquals("", result);
    }

    @Test
    void getCellValue_WithNullCell_ShouldReturnEmptyString() {
        String result = ExcelCellReader.getCellValue(row, 5);

        assertEquals("", result);
    }

    @Test
    void getCellValue_WithNullRow_ShouldReturnEmptyString() {
        String result = ExcelCellReader.getCellValue(null, 0);

        assertEquals("", result);
    }

    @Test
    void getCellValueAsString_WithStringCell_ShouldReturnValue() {
        Cell cell = row.createCell(0);
        cell.setCellValue("Test String");

        String result = ExcelCellReader.getCellValueAsString(cell);

        assertEquals("Test String", result);
    }

    @Test
    void getCellValueAsString_WithNullCell_ShouldReturnEmptyString() {
        String result = ExcelCellReader.getCellValueAsString(null);

        assertEquals("", result);
    }

    @Test
    void getCellValueAsString_WithWhitespace_ShouldTrimValue() {
        Cell cell = row.createCell(0);
        cell.setCellValue("   Harvard University   ");

        String result = ExcelCellReader.getCellValueAsString(cell);

        assertEquals("Harvard University", result);
    }

    @Test
    void getCellValueAsString_WithFormula_ShouldReturnFormulaResult() {
        Cell cell = row.createCell(0);
        cell.setCellFormula("\"Test Formula\"");

        String result = ExcelCellReader.getCellValueAsString(cell);

        assertNotNull(result);
    }

    @Test
    void hasContent_WithStringCell_ShouldReturnTrue() {
        Cell cell = row.createCell(0);
        cell.setCellValue("Content");

        boolean result = ExcelCellReader.hasContent(cell);

        assertTrue(result);
    }

    @Test
    void hasContent_WithBlankCell_ShouldReturnFalse() {
        Cell cell = row.createCell(0);
        cell.setBlank();

        boolean result = ExcelCellReader.hasContent(cell);

        assertFalse(result);
    }

    @Test
    void hasContent_WithNullCell_ShouldReturnFalse() {
        boolean result = ExcelCellReader.hasContent(null);

        assertFalse(result);
    }

    @Test
    void hasContent_WithEmptyStringCell_ShouldReturnFalse() {
        Cell cell = row.createCell(0);
        cell.setCellValue("");

        boolean result = ExcelCellReader.hasContent(cell);

        assertFalse(result);
    }

    @Test
    void hasContent_WithWhitespaceOnlyCell_ShouldReturnFalse() {
        Cell cell = row.createCell(0);
        cell.setCellValue("   ");

        boolean result = ExcelCellReader.hasContent(cell);

        assertFalse(result);
    }

    @Test
    void hasContent_WithNumericCell_ShouldReturnTrue() {
        Cell cell = row.createCell(0);
        cell.setCellValue(123);

        boolean result = ExcelCellReader.hasContent(cell);

        assertTrue(result);
    }

    @Test
    void hasContent_WithZeroNumericCell_ShouldReturnTrue() {
        Cell cell = row.createCell(0);
        cell.setCellValue(0);

        boolean result = ExcelCellReader.hasContent(cell);

        assertTrue(result);
    }

    @Test
    void hasContent_WithBooleanCell_ShouldReturnTrue() {
        Cell cell = row.createCell(0);
        cell.setCellValue(false);

        boolean result = ExcelCellReader.hasContent(cell);

        assertTrue(result);
    }

    @Test
    void isRowEmpty_WithAllBlankCells_ShouldReturnTrue() {
        row.createCell(0).setBlank();
        row.createCell(1).setBlank();
        row.createCell(2).setBlank();

        boolean result = ExcelCellReader.isRowEmpty(row);

        assertTrue(result);
    }

    @Test
    void isRowEmpty_WithNullRow_ShouldReturnTrue() {
        boolean result = ExcelCellReader.isRowEmpty(null);

        assertTrue(result);
    }

    @Test
    void isRowEmpty_WithSomeContent_ShouldReturnFalse() {
        row.createCell(0).setBlank();
        row.createCell(1).setCellValue("Content");
        row.createCell(2).setBlank();

        boolean result = ExcelCellReader.isRowEmpty(row);

        assertFalse(result);
    }

    @Test
    void isRowEmpty_WithOnlyWhitespace_ShouldReturnTrue() {
        row.createCell(0).setCellValue("   ");
        row.createCell(1).setCellValue("");
        row.createCell(2).setBlank();

        boolean result = ExcelCellReader.isRowEmpty(row);

        assertTrue(result);
    }

    @Test
    void getCellValue_WithSpecialCharacters_ShouldReturnCorrectValue() {
        Cell cell = row.createCell(0);
        cell.setCellValue("Test@#$%^&*()");

        String result = ExcelCellReader.getCellValue(row, 0);

        assertEquals("Test@#$%^&*()", result);
    }

    @Test
    void getCellValue_WithUnicodeCharacters_ShouldReturnCorrectValue() {
        Cell cell = row.createCell(0);
        cell.setCellValue("Université François");

        String result = ExcelCellReader.getCellValue(row, 0);

        assertEquals("Université François", result);
    }

    @Test
    void getCellValueAsString_WithLargeNumber_ShouldReturnCorrectFormat() {
        Cell cell = row.createCell(0);
        cell.setCellValue(1234567890.0);

        String result = ExcelCellReader.getCellValueAsString(cell);

        assertEquals("1234567890", result);
    }

    @Test
    void getCellValueAsString_WithNegativeNumber_ShouldReturnCorrectValue() {
        Cell cell = row.createCell(0);
        cell.setCellValue(-123.45);

        String result = ExcelCellReader.getCellValueAsString(cell);

        assertEquals("-123.45", result);
    }

    @Test
    void getCellValue_WithMultipleCells_ShouldReturnCorrectValues() {
        row.createCell(0).setCellValue("First");
        row.createCell(1).setCellValue("Second");
        row.createCell(2).setCellValue("Third");

        assertEquals("First", ExcelCellReader.getCellValue(row, 0));
        assertEquals("Second", ExcelCellReader.getCellValue(row, 1));
        assertEquals("Third", ExcelCellReader.getCellValue(row, 2));
    }
}

