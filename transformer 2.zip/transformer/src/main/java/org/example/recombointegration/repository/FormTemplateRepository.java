package org.example.recombointegration.repository;

import org.example.recombointegration.document.FormTemplate;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * MongoDB repository interface for FormTemplate document.
 * Provides database operations for form templates.
 *
 * @author Generated
 * @version 1.0
 */
@Repository
public interface FormTemplateRepository extends MongoRepository<FormTemplate, String> {

    /**
     * Find form template by formId.
     */
    Optional<FormTemplate> findByFormId(String formId);

    /**
     * Find all active form templates.
     */
    List<FormTemplate> findByActiveTrue();

    /**
     * Check if form template exists by formId.
     */
    boolean existsByFormId(String formId);

    /**
     * Find form templates by version.
     */
    List<FormTemplate> findByVersion(String version);
}

