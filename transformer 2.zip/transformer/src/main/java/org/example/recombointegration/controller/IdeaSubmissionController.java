package org.example.recombointegration.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.recombointegration.dto.*;
import org.example.recombointegration.document.IdeaSubmission.IdeaStatus;
import org.example.recombointegration.service.IdeaSubmissionService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * REST Controller for Idea Submission Management.
 * Provides endpoints for creating, retrieving, updating, and managing idea submissions.
 *
 * @author Generated
 * @version 1.0
 */
@Tag(name = "Idea Submission", description = "APIs for managing idea submissions and continuous improvement initiatives")
@Slf4j
@RestController
@RequestMapping("/api/v1/ideas")
@RequiredArgsConstructor
public class IdeaSubmissionController {

    private final IdeaSubmissionService ideaSubmissionService;

    /**
     * Submit a new idea.
     */
    @Operation(
            summary = "Submit a new idea",
            description = "Create a new idea submission with all required details including impact areas, implementation complexity, and expected benefits."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Idea submitted successfully",
                    content = @Content(schema = @Schema(implementation = IdeaSubmissionResponse.class))),
            @ApiResponse(responseCode = "400", description = "Invalid input data"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<IdeaSubmissionResponse> submitIdea(
            @Valid @RequestBody IdeaSubmissionRequest request) {
        log.info("Received request to submit new idea: {}", request.getTitle());
        IdeaSubmissionResponse response = ideaSubmissionService.createIdea(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * Get idea by ID.
     */
    @Operation(
            summary = "Get idea by ID",
            description = "Retrieve detailed information about a specific idea submission by its ID."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Idea found",
                    content = @Content(schema = @Schema(implementation = IdeaSubmissionResponse.class))),
            @ApiResponse(responseCode = "404", description = "Idea not found")
    })
    @GetMapping("/{id}")
    public ResponseEntity<IdeaSubmissionResponse> getIdeaById(
            @Parameter(description = "ID of the idea to retrieve", required = true)
            @PathVariable String id) {
        log.info("Received request to get idea with ID: {}", id);
        IdeaSubmissionResponse response = ideaSubmissionService.getIdeaById(id);
        return ResponseEntity.ok(response);
    }

    /**
     * Get all ideas with pagination.
     */
    @Operation(
            summary = "Get all ideas",
            description = "Retrieve all idea submissions with pagination and sorting support."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ideas retrieved successfully")
    })
    @GetMapping
    public ResponseEntity<Page<IdeaSubmissionResponse>> getAllIdeas(
            @Parameter(description = "Page number (0-indexed)", example = "0")
            @RequestParam(defaultValue = "0") int page,
            @Parameter(description = "Page size", example = "10")
            @RequestParam(defaultValue = "10") int size,
            @Parameter(description = "Sort field", example = "submissionDate")
            @RequestParam(defaultValue = "submissionDate") String sortBy,
            @Parameter(description = "Sort direction (ASC or DESC)", example = "DESC")
            @RequestParam(defaultValue = "DESC") String sortDirection) {
        log.info("Received request to get all ideas - page: {}, size: {}", page, size);
        
        Sort sort = sortDirection.equalsIgnoreCase("ASC") 
                ? Sort.by(sortBy).ascending() 
                : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<IdeaSubmissionResponse> response = ideaSubmissionService.getAllIdeas(pageable);
        return ResponseEntity.ok(response);
    }

    /**
     * Get ideas by status.
     */
    @Operation(
            summary = "Get ideas by status",
            description = "Retrieve ideas filtered by their current status (SUBMITTED, UNDER_REVIEW, APPROVED, etc.)."
    )
    @GetMapping("/status/{status}")
    public ResponseEntity<Page<IdeaSubmissionResponse>> getIdeasByStatus(
            @Parameter(description = "Status to filter by", required = true)
            @PathVariable IdeaStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        log.info("Received request to get ideas with status: {}", status);
        Pageable pageable = PageRequest.of(page, size, Sort.by("submissionDate").descending());
        Page<IdeaSubmissionResponse> response = ideaSubmissionService.getIdeasByStatus(status, pageable);
        return ResponseEntity.ok(response);
    }

    /**
     * Get ideas by submitter.
     */
    @Operation(
            summary = "Get ideas by submitter",
            description = "Retrieve all ideas submitted by a specific person."
    )
    @GetMapping("/submitter/{submittedBy}")
    public ResponseEntity<Page<IdeaSubmissionResponse>> getIdeasBySubmitter(
            @Parameter(description = "Name of the submitter", required = true)
            @PathVariable String submittedBy,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        log.info("Received request to get ideas submitted by: {}", submittedBy);
        Pageable pageable = PageRequest.of(page, size, Sort.by("submissionDate").descending());
        Page<IdeaSubmissionResponse> response = ideaSubmissionService.getIdeasBySubmitter(submittedBy, pageable);
        return ResponseEntity.ok(response);
    }

    /**
     * Get ideas by department.
     */
    @Operation(
            summary = "Get ideas by department",
            description = "Retrieve all ideas from a specific department."
    )
    @GetMapping("/department/{department}")
    public ResponseEntity<Page<IdeaSubmissionResponse>> getIdeasByDepartment(
            @Parameter(description = "Department name", required = true)
            @PathVariable String department,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        log.info("Received request to get ideas from department: {}", department);
        Pageable pageable = PageRequest.of(page, size, Sort.by("submissionDate").descending());
        Page<IdeaSubmissionResponse> response = ideaSubmissionService.getIdeasByDepartment(department, pageable);
        return ResponseEntity.ok(response);
    }

    /**
     * Search ideas by keyword.
     */
    @Operation(
            summary = "Search ideas",
            description = "Search ideas by keyword in title or description."
    )
    @GetMapping("/search")
    public ResponseEntity<Page<IdeaSubmissionResponse>> searchIdeas(
            @Parameter(description = "Search keyword", required = true)
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        log.info("Received request to search ideas with keyword: {}", keyword);
        Pageable pageable = PageRequest.of(page, size, Sort.by("submissionDate").descending());
        Page<IdeaSubmissionResponse> response = ideaSubmissionService.searchIdeas(keyword, pageable);
        return ResponseEntity.ok(response);
    }

    /**
     * Get top ideas by upvotes.
     */
    @Operation(
            summary = "Get top ideas",
            description = "Retrieve top ideas sorted by upvote count."
    )
    @GetMapping("/top")
    public ResponseEntity<Page<IdeaSubmissionResponse>> getTopIdeas(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        log.info("Received request to get top ideas");
        Pageable pageable = PageRequest.of(page, size);
        Page<IdeaSubmissionResponse> response = ideaSubmissionService.getTopIdeas(pageable);
        return ResponseEntity.ok(response);
    }

    /**
     * Update idea status.
     */
    @Operation(
            summary = "Update idea status",
            description = "Update the status of an idea (e.g., from SUBMITTED to UNDER_REVIEW, APPROVED, etc.)."
    )
    @PutMapping("/{id}/status")
    public ResponseEntity<IdeaSubmissionResponse> updateIdeaStatus(
            @Parameter(description = "ID of the idea", required = true)
            @PathVariable String id,
            @Valid @RequestBody IdeaStatusUpdateRequest request) {
        log.info("Received request to update status for idea ID: {} to {}", id, request.getStatus());
        IdeaSubmissionResponse response = ideaSubmissionService.updateIdeaStatus(id, request);
        return ResponseEntity.ok(response);
    }

    /**
     * Upvote an idea.
     */
    @Operation(
            summary = "Upvote an idea",
            description = "Increment the upvote count for an idea."
    )
    @PostMapping("/{id}/upvote")
    public ResponseEntity<IdeaSubmissionResponse> upvoteIdea(
            @Parameter(description = "ID of the idea to upvote", required = true)
            @PathVariable String id) {
        log.info("Received request to upvote idea ID: {}", id);
        IdeaSubmissionResponse response = ideaSubmissionService.upvoteIdea(id);
        return ResponseEntity.ok(response);
    }

    /**
     * Add comment to an idea.
     */
    @Operation(
            summary = "Add comment to idea",
            description = "Add a comment or feedback to an idea submission."
    )
    @PostMapping("/{id}/comments")
    public ResponseEntity<IdeaCommentResponse> addComment(
            @Parameter(description = "ID of the idea", required = true)
            @PathVariable String id,
            @Valid @RequestBody IdeaCommentRequest request) {
        log.info("Received request to add comment to idea ID: {}", id);
        IdeaCommentResponse response = ideaSubmissionService.addComment(id, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * Get comments for an idea.
     */
    @Operation(
            summary = "Get comments for idea",
            description = "Retrieve all comments for a specific idea."
    )
    @GetMapping("/{id}/comments")
    public ResponseEntity<List<IdeaCommentResponse>> getComments(
            @Parameter(description = "ID of the idea", required = true)
            @PathVariable String id) {
        log.info("Received request to get comments for idea ID: {}", id);
        List<IdeaCommentResponse> response = ideaSubmissionService.getComments(id);
        return ResponseEntity.ok(response);
    }

    /**
     * Delete an idea.
     */
    @Operation(
            summary = "Delete an idea",
            description = "Delete an idea submission by ID."
    )
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteIdea(
            @Parameter(description = "ID of the idea to delete", required = true)
            @PathVariable String id) {
        log.info("Received request to delete idea ID: {}", id);
        ideaSubmissionService.deleteIdea(id);
        return ResponseEntity.noContent().build();
    }

    /**
     * Get dashboard statistics.
     */
    @Operation(
            summary = "Get dashboard statistics",
            description = "Retrieve aggregated statistics for the dashboard including total ideas, ideas by status, and ideas by department."
    )
    @GetMapping("/dashboard/stats")
    public ResponseEntity<Map<String, Object>> getDashboardStats() {
        log.info("Received request to get dashboard statistics");
        Map<String, Object> stats = ideaSubmissionService.getDashboardStats();
        return ResponseEntity.ok(stats);
    }
}

