package com.hireright.sourceintelligence.service.impl.helperservices;

import com.hireright.sourceintelligence.api.dto.CycleResult;
import com.hireright.sourceintelligence.service.impl.MongoSourceService;
import com.hireright.sourceintelligence.service.impl.UserCycleEvaluator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.PENDING_APPROVAL;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.SAVE_PENDING_APPROVAL;

@Slf4j
@RequiredArgsConstructor
@Transactional
@Service
public class SourceUtils {

    @Value("${approvalWorkFlow.disabled}")
    private boolean approvalWorkFlowDisabled;

    private final UserCycleEvaluator evaluator;

    private final MongoSourceService mongoSourceService;

    public CycleResult checkForAutoApproval(int userTrustScore, String region, String userName) {
        if (approvalWorkFlowDisabled) {
            return null;
        }
        int regionThreshold = mongoSourceService.getThresholdForRegion(region);
        log.info("Region Threshold: {}", regionThreshold);
        return evaluator.processRequest(userName, region, userTrustScore, regionThreshold);
    }
    public boolean isEligibleForAutoApproval(int userTrustScore, String region) {
        if (approvalWorkFlowDisabled) {
            return true;
        }
        int regionThreshold = mongoSourceService.getThresholdForRegion(region);
        log.info("Region Threshold: {}", regionThreshold);
        return (userTrustScore >= regionThreshold);
    }

    public boolean isPendingOrSavePendingApproval(String status) {
        return PENDING_APPROVAL.getStatus().equals(status) || SAVE_PENDING_APPROVAL.getStatus().equals(status);
    }
}
