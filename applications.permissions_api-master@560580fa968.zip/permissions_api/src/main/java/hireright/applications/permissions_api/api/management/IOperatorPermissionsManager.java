package hireright.applications.permissions_api.api.management;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-16  HRG-330191 initial version
 */

import hireright.applications.permissions_api.model.CSort;
import hireright.applications.permissions_api.model.COperatorPermission;
import hireright.applications.permissions_api.model.COperatorPermissionFilter;

public interface IOperatorPermissionsManager extends
	IRecordManager<COperatorPermission, String, CSort<COperatorPermission.EField>, COperatorPermissionFilter>
{
	@Override
	default COperatorPermission get(String sLabel)
	{
		throw new UnsupportedOperationException();
	}

	@Override
	default CSort<COperatorPermission.EField> getDefaultSort()
	{
		return CSort.asc(COperatorPermission.EField.LABEL);
	}
}
