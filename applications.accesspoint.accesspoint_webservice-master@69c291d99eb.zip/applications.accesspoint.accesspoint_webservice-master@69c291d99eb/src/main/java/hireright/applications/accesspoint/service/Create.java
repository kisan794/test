/*
 * @(#)$RCSfile: Create.java,v $ $Revision: 1.2 $ $Date: 2014/07/28 14:56:58 $
 * $Author: aputintsev $
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/service/Create.java,v $
 *
 * Copyright 2006-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * Toha Bakanovsky	2009-08-06	Created
 */
package hireright.applications.accesspoint.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import hireright.applications.accesspoint.types.CParametersListWrapper;


/**
 * <p>Java class for create complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="create">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="userID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="userClass" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="entryPointType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="domainID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="designNr" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="authenticationMode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="login" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="entriesAllowed" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="failuresAllowed" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="expirationDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="createSession" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="parameters" type="{http://hireright.com/applications/accesspoint/types}CParametersListWrapper" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "create", propOrder = {
		"userID",
		"userClass",
		"entryPointType",
		"domainID",
		"designNr",
		"authenticationMode",
		"login",
		"entriesAllowed",
		"failuresAllowed",
		"expirationDate",
		"createSession",
		"parameters"
})
public class Create {

		@XmlElement(required = true)
		protected String userID;
		@XmlElement(required = true)
		protected String userClass;
		@XmlElement(required = true)
		protected String entryPointType;
		@XmlElement(required = true)
		protected String domainID;
		protected int designNr;
		protected String authenticationMode;
		protected String login;
		protected Integer entriesAllowed;
		protected Integer failuresAllowed;
		@XmlSchemaType(name = "dateTime")
		protected XMLGregorianCalendar expirationDate;
		protected Boolean createSession;
		protected CParametersListWrapper parameters;

		/**
		 * Gets the value of the userID property.
		 * 
		 * @return
		 *     possible object is
		 *     {@link String }
		 *     
		 */
		public String getUserID() {
				return userID;
		}

		/**
		 * Sets the value of the userID property.
		 * 
		 * @param value
		 *     allowed object is
		 *     {@link String }
		 *     
		 */
		public void setUserID(String value) {
				this.userID = value;
		}

		/**
		 * Gets the value of the userClass property.
		 * 
		 * @return
		 *     possible object is
		 *     {@link String }
		 *     
		 */
		public String getUserClass() {
				return userClass;
		}

		/**
		 * Sets the value of the userClass property.
		 * 
		 * @param value
		 *     allowed object is
		 *     {@link String }
		 *     
		 */
		public void setUserClass(String value) {
				this.userClass = value;
		}

		/**
		 * Gets the value of the entryPointType property.
		 * 
		 * @return
		 *     possible object is
		 *     {@link String }
		 *     
		 */
		public String getEntryPointType() {
				return entryPointType;
		}

		/**
		 * Sets the value of the entryPointType property.
		 * 
		 * @param value
		 *     allowed object is
		 *     {@link String }
		 *     
		 */
		public void setEntryPointType(String value) {
				this.entryPointType = value;
		}

		/**
		 * Gets the value of the domainID property.
		 * 
		 * @return
		 *     possible object is
		 *     {@link String }
		 *     
		 */
		public String getDomainID() {
				return domainID;
		}

		/**
		 * Sets the value of the domainID property.
		 * 
		 * @param value
		 *     allowed object is
		 *     {@link String }
		 *     
		 */
		public void setDomainID(String value) {
				this.domainID = value;
		}

		/**
		 * Gets the value of the designNr property.
		 * 
		 */
		public int getDesignNr() {
				return designNr;
		}

		/**
		 * Sets the value of the designNr property.
		 * 
		 */
		public void setDesignNr(int value) {
				this.designNr = value;
		}

		/**
		 * Gets the value of the authenticationMode property.
		 * 
		 * @return
		 *     possible object is
		 *     {@link String }
		 *     
		 */
		public String getAuthenticationMode() {
				return authenticationMode;
		}

		/**
		 * Sets the value of the authenticationMode property.
		 * 
		 * @param value
		 *     allowed object is
		 *     {@link String }
		 *     
		 */
		public void setAuthenticationMode(String value) {
				this.authenticationMode = value;
		}

		/**
		 * Gets the value of the login property.
		 * 
		 * @return
		 *     possible object is
		 *     {@link String }
		 *     
		 */
		public String getLogin() {
				return login;
		}

		/**
		 * Sets the value of the login property.
		 * 
		 * @param value
		 *     allowed object is
		 *     {@link String }
		 *     
		 */
		public void setLogin(String value) {
				this.login = value;
		}

		/**
		 * Gets the value of the entriesAllowed property.
		 * 
		 * @return
		 *     possible object is
		 *     {@link Integer }
		 *     
		 */
		public Integer getEntriesAllowed() {
				return entriesAllowed;
		}

		/**
		 * Sets the value of the entriesAllowed property.
		 * 
		 * @param value
		 *     allowed object is
		 *     {@link Integer }
		 *     
		 */
		public void setEntriesAllowed(Integer value) {
				this.entriesAllowed = value;
		}

		/**
		 * Gets the value of the failuresAllowed property.
		 * 
		 * @return
		 *     possible object is
		 *     {@link Integer }
		 *     
		 */
		public Integer getFailuresAllowed() {
				return failuresAllowed;
		}

		/**
		 * Sets the value of the failuresAllowed property.
		 * 
		 * @param value
		 *     allowed object is
		 *     {@link Integer }
		 *     
		 */
		public void setFailuresAllowed(Integer value) {
				this.failuresAllowed = value;
		}

		/**
		 * Gets the value of the expirationDate property.
		 * 
		 * @return
		 *     possible object is
		 *     {@link XMLGregorianCalendar }
		 *     
		 */
		public XMLGregorianCalendar getExpirationDate() {
				return expirationDate;
		}

		/**
		 * Sets the value of the expirationDate property.
		 * 
		 * @param value
		 *     allowed object is
		 *     {@link XMLGregorianCalendar }
		 *     
		 */
		public void setExpirationDate(XMLGregorianCalendar value) {
				this.expirationDate = value;
		}

		/**
		 * Gets the value of the createSession property.
		 * 
		 * @return
		 *     possible object is
		 *     {@link Boolean }
		 *     
		 */
		public Boolean isCreateSession() {
				return createSession;
		}

		/**
		 * Sets the value of the createSession property.
		 * 
		 * @param value
		 *     allowed object is
		 *     {@link Boolean }
		 *     
		 */
		public void setCreateSession(Boolean value) {
				this.createSession = value;
		}

		/**
		 * Gets the value of the parameters property.
		 * 
		 * @return
		 *     possible object is
		 *     {@link CParametersListWrapper }
		 *     
		 */
		public CParametersListWrapper getParameters() {
				return parameters;
		}

		/**
		 * Sets the value of the parameters property.
		 * 
		 * @param value
		 *     allowed object is
		 *     {@link CParametersListWrapper }
		 *     
		 */
		public void setParameters(CParametersListWrapper value) {
				this.parameters = value;
		}

}
