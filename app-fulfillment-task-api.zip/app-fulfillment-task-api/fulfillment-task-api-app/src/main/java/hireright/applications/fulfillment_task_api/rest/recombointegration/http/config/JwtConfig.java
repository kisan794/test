/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.http.config;

import jakarta.annotation.PostConstruct;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.time.Duration;

/**
 * Spring-managed configuration for JWT authentication.
 * Contains settings for JWT token generation and validation.
 * Properties are loaded from application.properties.
 * Only active when http.client.jwt.enabled=true.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
@Getter
@Component
@ConditionalOnProperty(name = "http.client.jwt.enabled", havingValue = "true")
public class JwtConfig {

    @Value("${http.client.jwt.hrg-secret-key}")
    private String secretKey;

    @Value("${http.client.jwt.issuer:}")
    private String issuer;

    @Value("${http.client.jwt.subject:}")
    private String subject;

    @Value("${http.client.jwt.expiration-seconds:600}")
    private int expirationSeconds;

    /**
     * Validates the configuration after properties are injected.
     */
    @PostConstruct
    public void init() {
        // Validate
        if (secretKey == null || secretKey.isBlank()) {
            throw new IllegalStateException(
                    "JWT secret key must not be null or blank when JWT is enabled");
        }
        if (expirationSeconds <= 0) {
            throw new IllegalStateException("JWT expiration seconds must be positive");
        }

        log.info("JwtConfig initialized - issuer: {}, subject: {}, expirationSecond: {}", issuer,
                subject, expirationSeconds);
    }

    /**
     * Gets the JWT expiration time as a Duration.
     *
     * @return expiration time duration
     */
    public Duration getExpirationTime() {
        return Duration.ofSeconds(expirationSeconds);
    }
}

