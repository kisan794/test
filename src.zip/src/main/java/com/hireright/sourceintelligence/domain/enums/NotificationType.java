package com.hireright.sourceintelligence.domain.enums;

/**
 * Enum for notification types
 * Following Open/Closed Principle - open for extension via new enum values
 */
public enum NotificationType {
    EMAIL,
    SMS,
    PUSH,
    IN_APP
}

