package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.v2.dto.RegionThresholdDTO;

public interface RegionThresholdService {

    RegionThresholdDTO getRegions();

    RegionThresholdDTO getRegionByType(String thresholdType);

    RegionThresholdDTO updateRegionThreshold(RegionThresholdDTO regionThreshold);
}
