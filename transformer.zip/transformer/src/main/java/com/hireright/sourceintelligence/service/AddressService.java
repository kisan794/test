package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.AddressDTO;
import com.hireright.sourceintelligence.api.dto.SearchResponseDTO;
import com.hireright.sourceintelligence.api.dto.SearchDTO;
import com.hireright.sourceintelligence.api.dto.UserInfo;

public interface AddressService {
    void updateAddress(AddressDTO addressDTO, UserInfo userInfo);
    SearchResponseDTO getAddressListByHon(SearchDTO searchDTO);
}
