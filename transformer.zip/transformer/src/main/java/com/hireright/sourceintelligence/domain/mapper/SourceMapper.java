package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import org.json.*;
import org.mapstruct.*;
import org.mapstruct.NullValueCheckStrategy;

import java.util.List;

import static org.mapstruct.ReportingPolicy.IGNORE;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        unmappedTargetPolicy = IGNORE)
public interface SourceMapper {

    @Named("mapToDBObject")
    static DBObject mapToDBObject(JSONObject payload) {
        return BasicDBObject.parse(payload.toString());
    }

    @Named("mapToJSONObject")
    static JSONObject mapToJSONObject(DBObject payload) throws JSONException {
        return new JSONObject((payload.toString()));
    }

    List<SourceOrganizationDTO> toSourceDTOList(List<Source> entityList);

    @Mapping(source = "payload", target = "payload", qualifiedByName = "mapToDBObject")
    Source dtoToEntitySource(SourceOrganizationDTO dto);

    @Mapping(source = "payload", target = "payload", qualifiedByName = "mapToJSONObject")
    SourceOrganizationDTO entitySourceToDTO(Source entity);


}
