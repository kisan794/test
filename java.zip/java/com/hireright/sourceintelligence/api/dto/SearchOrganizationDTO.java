package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsonorg.JSONObjectDeserializer;
import com.fasterxml.jackson.datatype.jsonorg.JSONObjectSerializer;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import java.time.Instant;
import java.util.List;
import jakarta.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.json.JSONObject;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value = JsonInclude.Include.NON_EMPTY, content = JsonInclude.Include.NON_NULL)
public class SearchOrganizationDTO {

    @NotNull
    private String hon;

    private String organizationName;

    private Alias[] organizationAlias;

    private Alias[] departmentAliases;

    private String departmentName;

    private SourceOrganizationStatus status;

    private String version;

    private OrganizationType organizationType;

    private String city;

    private String state;

    private String country;

    private List<ContactDetails> contactDetails;

    private String addressLine;

    private String lastCleanUpDate;

    private String lastUsedDate;

    private Boolean outOfBusiness;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant lastModifiedDate;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant createdDate;

    private String lastApprovedDateTime;

    private String postalCode;

    private String reviewRequired;

    private Integer usedCount;

    @JsonIgnore
    private List<HighlightDTO> highlight;

    private Float score;

    private String primaryContact;

    private Double jaroWinklerDistance;

    private Double jaroWinklerDistanceCity;

    private boolean higherOrgNameConfidenceScore;

    private String doNotContact;

    private String website;

    private String notes;

    private String assignedTo;
    private String hasChildren;

    private ApprovalStatus approvalStatus;

    private List<AdditionalInfo> additionalInfo;

    private List<RelationshipsDTO> relationships;

    @NotNull
    @JsonSerialize(using = JSONObjectSerializer.class)
    @JsonDeserialize(using = JSONObjectDeserializer.class)
    private JSONObject payload;

    private int childCount;

}
