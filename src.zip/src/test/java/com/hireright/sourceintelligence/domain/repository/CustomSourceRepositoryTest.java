package com.hireright.sourceintelligence.domain.repository;

import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CustomSourceRepositoryTest {

  @Mock
  private MongoTemplate mongoTemplate;

  @InjectMocks
  private CustomSourceRepositoryImpl customSourceRepository;

  @Test
  void findByHonTest() {
    String hon = "12345";
    String collectionName = "testCollection";

    assertThatNoException().isThrownBy(() ->customSourceRepository.findByHon(hon, MongoTemplate.class, collectionName));

  }

//  @Test
//  void isHonExistsTest() {
//    String hon = "12345";
//    String collectionName = "testCollection";
//    when(mongoTemplate.count(any(Query.class), eq(collectionName))).thenReturn(1L);
//    assertThatNoException().isThrownBy(() ->customSourceRepository.isHonExists(hon, MongoTemplate.class, collectionName));
//
//  }

  @Test
  void isHonExistsTest() {
    String hon = "12345";
    String collectionName = "testCollection";
    Object mockEntity = new Object();

    when(mongoTemplate.findOne(any(Query.class), eq(Object.class), eq(collectionName)))
            .thenReturn(mockEntity);
    boolean result = customSourceRepository.isHonExists(hon, Object.class, collectionName);
    Assertions.assertTrue(result);
  }

  @Test
  void findByHonAndStatusTest() {
    String hon = "12345";
    String collectionName = "testCollection";

    assertThatNoException().isThrownBy(() ->customSourceRepository.findByHonAndStatus(hon,"", MongoTemplate.class, collectionName));

  }

  @Test
  void findDistinctByOrganizationNameTest() {
    String hon = "12345";
    String collectionName = "testCollection";
    Pageable pageable = Pageable.ofSize(10);
    assertThatNoException().isThrownBy(() ->customSourceRepository.findDistinctByOrganizationName(hon,pageable, MongoTemplate.class, collectionName));

  }

  @Test
  void findByFieldDistinctTest() {
    String hon = "12345";
    String collectionName = "testCollection";
    assertThatNoException().isThrownBy(() ->customSourceRepository.findByFieldDistinct(new Query(),hon, MongoTemplate.class, collectionName));

  }

  @Test
  void findByFieldDistinctNewTest() {
    String hon = "12345";
    String collectionName = "testCollection";
    assertThatNoException().isThrownBy(() ->customSourceRepository.findByFieldDistinct(new Query(),hon, collectionName));

  }

  @Test
  void findByHonInTest() {
    List<String> honIds = Arrays.asList("123","456");
    String collectionName = "testCollection";
    assertThatNoException().isThrownBy(() ->customSourceRepository.findByHonIn(honIds,MongoTemplate.class, collectionName));

  }

  @Test
  void findByStatusAndOrganizationNameAndCountryAndStateAndCityTest() {
    String collectionName = "testCollection";
    assertThatNoException().isThrownBy(() ->customSourceRepository.findByStatusAndOrganizationNameAndCountryAndStateAndCity("org name", OrganizationType.EMPLOYMENT.toString(),"Active","country","state","city",MongoTemplate.class, collectionName));

  }

  @Test
  void findByHonOrderByVersionDescTest() {
    String hon = "12345";
    String collectionName = "testCollection";
    assertThatNoException().isThrownBy(() ->customSourceRepository.findByHonOrderByVersionDesc(hon, MongoTemplate.class, collectionName));

  }

  @Test
  void findByHonAndApprovalStatusOrderByVersionDescTest() {
    String hon = "12345";
    String collectionName = "testCollection";
    assertThatNoException().isThrownBy(() ->customSourceRepository.findByHonAndApprovalStatusOrderByVersionDesc(hon, ApprovalStatus.APPROVED, MongoTemplate.class, collectionName));

  }

  @Test
  void findByRequesterIdAndLastModifiedDateBetweenTest() {
    String collectionName = "testCollection";
    assertThatNoException().isThrownBy(() ->customSourceRepository.findByRequesterIdAndLastModifiedDateBetween("", Instant.now(),Instant.now(),  MongoTemplate.class, collectionName));

  }

  @Test
  void findByHonAndApprovalStatusAndVersionLessThanOrderByVersionDescTest() {
    String collectionName = "testCollection";
    assertThatNoException().isThrownBy(() ->customSourceRepository.findByHonAndApprovalStatusAndVersionLessThanOrderByVersionDesc("", ApprovalStatus.APPROVED,2.0,  MongoTemplate.class, collectionName));

  }

  @Test
  void findByHonAndApprovalStatusAndVersionInOrderByVersionDescTest() {
    String collectionName = "testCollection";
    assertThatNoException().isThrownBy(() ->customSourceRepository.findByHonAndApprovalStatusAndVersionInOrderByVersionDesc("", ApprovalStatus.APPROVED,new Double[2],  MongoTemplate.class, collectionName));

  }

  @Test
  void findByHonAndVersionTest() {
    String collectionName = "testCollection";
    assertThatNoException().isThrownBy(() ->customSourceRepository.findByHonAndVersion("", 2.0,  MongoTemplate.class, collectionName));

  }

  @Test
  void findOneByHonAndVersionTest() {
    String collectionName = "testCollection";
    assertThatNoException().isThrownBy(() ->customSourceRepository.findOneByHonAndVersion("", 2.0,  MongoTemplate.class, collectionName));

  }

  @Test
  void UpdateDateOnIncrementByHonTest() {
    String collectionName = "testCollection";
    assertThatNoException().isThrownBy(() ->customSourceRepository.UpdateDateOnIncrementByHon("", "",  MongoTemplate.class, collectionName));

  }

  @Test
  void getSourceCountByStatusesTest() {
    String collectionName = "testCollection";
    List<ApprovalStatus> approvalStatusList = new ArrayList<>();
    approvalStatusList.add(ApprovalStatus.APPROVED);
    assertThatNoException().isThrownBy(() ->customSourceRepository.getSourceCountByStatuses(approvalStatusList,  MongoTemplate.class, collectionName));

  }

  @Test
  void findByStatusesTest() {
    String collectionName = "testCollection";
    List<ApprovalStatus> approvalStatusList = new ArrayList<>();
    approvalStatusList.add(ApprovalStatus.APPROVED);
    assertThatNoException().isThrownBy(() ->customSourceRepository.findByStatuses(approvalStatusList,10,20,  MongoTemplate.class, collectionName));

  }

  @Test
  void findByQueryTest() {
    String collectionName = "testCollection";
    assertThatNoException().isThrownBy(() ->customSourceRepository.findByQuery(new Query(),  MongoTemplate.class, collectionName));

  }

  @Test
  void findByHonOrderByLastModifiedDateDescTest() {
    String collectionName = "testCollection";
    assertThatNoException().isThrownBy(() ->customSourceRepository.findByHonOrderByLastModifiedDateDesc("",  MongoTemplate.class, collectionName));

  }

  @Test
  void createTest() {
    String collectionName = "testCollection";
    assertThatNoException().isThrownBy(() ->customSourceRepository.create(MongoTemplate.class,  MongoTemplate.class, collectionName));

  }

  @Test
  void updateTest() {
    String collectionName = "testCollection";
    assertThatNoException().isThrownBy(() ->customSourceRepository.update("","",MongoTemplate.class,  MongoTemplate.class, collectionName));

  }

  @Test
  void findByIdTest() {
    String collectionName = "testCollection";
    assertThatNoException().isThrownBy(() ->customSourceRepository.findById(new ObjectId(),  MongoTemplate.class, collectionName));

  }

  @Test
  void findByOneTest() {
    String collectionName = "testCollection";
    assertThatNoException().isThrownBy(() ->customSourceRepository.findByOne("","",  MongoTemplate.class, collectionName));

  }

  @Test
  void findByFieldTest() {
    String collectionName = "testCollection";
    assertThatNoException().isThrownBy(() ->customSourceRepository.findByField("","",  MongoTemplate.class, collectionName));

  }
}