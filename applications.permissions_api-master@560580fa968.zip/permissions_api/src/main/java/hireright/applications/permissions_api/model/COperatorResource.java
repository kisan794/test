package hireright.applications.permissions_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-17  HRG-330191 initial version
 */

public class COperatorResource extends CResource<Void, COperator>
{
	private COperatorResource()
	{
		super();
	}

	protected COperatorResource(Builder builder)
	{
		super(builder);
	}

	@Override
	public String toString()
	{
		return "COperatorResource{} " + super.toString();
	}

	public static class Builder extends CResource.Builder<Void, COperator>
	{
		public Builder()
		{
			super();
		}

		public Builder(CResource<Void, COperator> copy)
		{
			super(copy);
		}

		public Builder(COperatorResource copy)
		{
			super(copy);
		}

		@Override
		public COperatorResource build()
		{
			super.build();
			kind(EKind.operator);

			return new COperatorResource(this);
		}
	}
}
