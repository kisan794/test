/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.log.service.impl;

import hireright.applications.fulfillment_task_api.rest.recombointegration.log.LogOptions;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.Direction;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.RecipientName;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.exception.DataExchangeLoggerException;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.service.LoggingService;
import hireright.lib.logging.log_data_exchange.IDataExchangeLogger;
import hireright.lib.logging.log_data_exchange.model.CLogDataExchange;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeoutException;

import static hireright.lib.logging.log_data_exchange.model.CLogDataExchange.EDirection.OUT;
import static java.util.concurrent.CompletableFuture.supplyAsync;
import static java.util.concurrent.Executors.newVirtualThreadPerTaskExecutor;
import static java.util.concurrent.TimeUnit.MILLISECONDS;
import static org.slf4j.LoggerFactory.getLogger;

@Service
class ExternalLoggingService implements LoggingService
{
	private static final Logger LOGGER = getLogger(ExternalLoggingService.class);
	private final IDataExchangeLogger dataExchangeLogger;
	private final int timeoutMillis;

	public ExternalLoggingService(final IDataExchangeLogger dataExchangeLogger,
		@Value("${logging-api.timeout:5000}") final int timeoutMillis)
	{
		this.dataExchangeLogger = dataExchangeLogger;
		this.timeoutMillis = timeoutMillis;
	}

	@Override
	public void log(final String payload, final String transactionId,
		final RecipientName recipientName, final Direction direction)
	{
		log(buildDataExchange(CLogDataExchange.EDirection.valueOf(direction.name()), payload,
			buildLogOptions(transactionId, recipientName).build()));
	}

	private void log(final CLogDataExchange logDataExchange)
	{
		try(final ExecutorService executorService = newVirtualThreadPerTaskExecutor())
		{
			final CompletableFuture<CLogDataExchange> dataExchangeLoggerFuture =
				supplyAsync(() -> dataExchangeLogger.log(logDataExchange), executorService);

			dataExchangeLoggerFuture.get(timeoutMillis, MILLISECONDS);

		}
		catch(final TimeoutException ex)
		{
			LOGGER.error("DataExchangeLogger is not available", ex);
			throw new DataExchangeLoggerException("DataExchangeLogger is not available",
				logDataExchange.getTransactionID());
		}
		catch(final InterruptedException ex)
		{
			Thread.currentThread().interrupt();
			LOGGER.error("Thread interrupted while waiting for DataExchangeLogger", ex);
			throw new DataExchangeLoggerException("Thread interrupted while logging",
				logDataExchange.getTransactionID());
		}
		catch(final ExecutionException ex)
		{
			throw new DataExchangeLoggerException(ex.getCause().getMessage(),
				logDataExchange.getTransactionID());
		}
	}

	private LogOptions.LogOptionsBuilder buildLogOptions(final String transactionId,
		final RecipientName recipientName)
	{
		return LogOptions.LogOptionsBuilder.cdm2LogOptions()
			.transactionId(transactionId)
			.recipientName(recipientName);
	}

	private CLogDataExchange buildDataExchange(final CLogDataExchange.EDirection direction,
		final String payload, final LogOptions options)
	{
		return new CLogDataExchange.Builder().recipientName(options.recipientName().name())
			.recipientClass(options.recipientClass())
			.transactionID(options.transactionId())
			.recipientID(options.recipientId())
			.parameters(options.parameters())
			.protocol(options.protocol())
			.direction(direction)
			.payload(payload)
			.build();
	}
}
