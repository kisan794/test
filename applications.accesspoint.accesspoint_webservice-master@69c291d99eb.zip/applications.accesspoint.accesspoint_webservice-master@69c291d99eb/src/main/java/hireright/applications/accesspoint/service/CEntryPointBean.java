/*
 * @(#)$RCSfile: CEntryPointBean.java,v $ $Revision: 1.2 $ $Date: 2014/07/28 14:56:57 $ $Author: aputintsev $ $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/service/CEntryPointBean.java,v $
 *
 * History:
 *     $Log: CEntryPointBean.java,v $
 *     Revision 1.2  2014/07/28 14:56:57  aputintsev
 *     forked from production version - projects_src/applications/accesspoint
 *
 *     Revision 1.1.2.1.2.1  2009/08/18 11:09:19  asolntsev
 *     Bugfixing and polishing
 *
 *     Revision 1.1.2.1  2009/08/13 13:24:22  asolntsev
 *     Created by St.Petersburg team
 *
 *     Revision 1.1.1.1  2009/07/31 11:24:26  banton
 *     Task 39986 1.1
 *
 *     Revision 1.4  2009/07/30 14:12:19  banton
 *     Fixed errors for  multi value properties
 *
 *     Revision 1.3  2009/07/29 09:50:13  banton
 *     Fixed WSDL. Added WSDL for 'light' Service
 *
 *     Revision 1.2  2009/07/23 11:31:44  banton
 *     Added some sources decorations
 *
 */

package hireright.applications.accesspoint.service;

import java.io.Serializable;

import hireright.applications.accesspoint.types.CParametersListWrapper;
import hireright.objects.utilities.CEntryPoint;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author banton
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(name = "EntryPointType", propOrder = {
		"designNr",
		"domainID",
		"redirectURL",
		"userClass",
		"userID",
		"authenticationMode",
		"parameters"
})
public class CEntryPointBean implements Serializable
{
		// table fields
		private String  m_sRedirectURL;
		private Integer m_nDesignNr;
		private String  m_sDomainID;
		private String  m_sUserClass;
		private String  m_sUserID;
		private String  m_sAuthenticationMode;

		private  CParametersListWrapper m_parameters;

		public CEntryPointBean()
		{
		}

		public CEntryPointBean(CEntryPoint entryPoint)
		{
				m_sRedirectURL          = entryPoint.getRedirectURL().replaceAll( "%KEY%", entryPoint.getKey() );
				m_nDesignNr             = entryPoint.getDesignNr();
				m_sDomainID             = entryPoint.getDomainID();
				m_sUserClass            = entryPoint.getUserClass();
				m_sUserID               = entryPoint.getUserID();
				m_sAuthenticationMode   = entryPoint.getAuthenticationMode();

				m_parameters = new CParametersListWrapper();
				m_parameters.setParameter(CParametersListWrapper.createParameters(entryPoint.getMultiProperties()));
		}

		public Integer getDesignNr()
		{
				return m_nDesignNr;
		}

		public void setDesignNr(Integer m_nDesignNr)
		{
				this.m_nDesignNr = m_nDesignNr;
		}

		public String getAuthenticationMode()
		{
				return m_sAuthenticationMode;
		}

		public void setAuthenticationMode(String m_sAuthenticationMode)
		{
				this.m_sAuthenticationMode = m_sAuthenticationMode;
		}

		public String getDomainID()
		{
				return m_sDomainID;
		}

		public void setDomainID(String m_sDomainID)
		{
				this.m_sDomainID = m_sDomainID;
		}

		public String getRedirectURL()
		{
				return m_sRedirectURL;
		}

		public void setRedirectURL(String m_sRedirectURL)
		{
				this.m_sRedirectURL = m_sRedirectURL;
		}

		public String getUserClass()
		{
				return m_sUserClass;
		}

		public void setUserClass(String m_sUserClass)
		{
				this.m_sUserClass = m_sUserClass;
		}

		public String getUserID()
		{
				return m_sUserID;
		}

		public void setUserID(String m_sUserID)
		{
				this.m_sUserID = m_sUserID;
		}

		public CParametersListWrapper getParameters()
		{
				return m_parameters;
		}

		public void setParameters(CParametersListWrapper m_parameters)
		{
				this.m_parameters = m_parameters;
		}
}
