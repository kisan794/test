package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Response DTO for data migration operations.
 * Contains detailed information about the migration process results.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MigrationResponseDTO {
    
    /**
     * Status of the migration operation (success/error)
     */
    private String status;
    
    /**
     * Human-readable message describing the result
     */
    private String message;
    
    /**
     * Type of migration performed (e.g., "parchment", "clearinghouse")
     */
    private String migrationType;
    
    /**
     * Name of the uploaded file
     */
    private String filename;
    
    /**
     * Total number of records found in the file
     */
    private Integer totalRecords;
    
    /**
     * Number of records successfully updated
     */
    private Integer updatedRecords;
    
    /**
     * Number of records that were not found in the database
     */
    private Integer notFoundRecords;
    
    /**
     * List of institution names that were not found
     */
    private List<String> notFoundInstitutions;
    
    /**
     * Number of records that failed to process due to errors
     */
    private Integer failedRecords;
    
    /**
     * List of error messages for failed records
     */
    private List<String> errors;
    
    /**
     * Processing time in milliseconds
     */
    private Long processingTimeMs;
}

