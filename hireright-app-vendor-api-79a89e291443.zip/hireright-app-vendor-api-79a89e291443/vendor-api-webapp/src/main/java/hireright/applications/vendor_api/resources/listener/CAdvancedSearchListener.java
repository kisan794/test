package hireright.applications.vendor_api.resources.listener;
/*
*
* Copyright 2001-2019 by HireRight, Inc. All rights reserved.
*
* This software is the confidential and proprietary information
* of HireRight, Inc. Use is subject to license terms.
*
* History:
*	alogachyov	2020-05-26	Created
*/

import java.util.concurrent.Callable;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.hibernate.criterion.Restrictions;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import hireright.objects.is.CMessage;
import hireright.objects.is.CMessageManager;
import hireright.objects.is.CMessagePayload;
import hireright.objects.object_resource.CObjectResource;
import hireright.objects.object_resource.CObjectResourceManager;
import hireright.objects.order.COrder;
import hireright.objects.order.COrderServiceDataSource;
import hireright.objects.order2.COrderServiceManager;
import hireright.sdk.consts.Mime;
import hireright.sdk.db3.DB;
import hireright.sdk.debug.CDataExchangeLog;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.transform.HTMLTransformer;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.CStringUtils;

@RestController
public class CAdvancedSearchListener
{
	private static final String ADAPTER_ID = "GNF-DAT";

	@RequestMapping(path = "/advancedsearchresult",
			method = RequestMethod.POST,
			consumes = MediaType.APPLICATION_XML_VALUE,
			produces = MediaType.APPLICATION_XML_VALUE)
	public String put(@RequestBody final String sPayload)
	{
		try
		{
			DB.execute(new Callable<Void>()
			{
				@Override
				public Void call() throws Exception 
				{
					DB.requestTransaction();
										
					CObjectResource objectResource = CObjectResourceManager.getByTypeAndName("CUSTOMER", "COMMON", 21, "ADVANCEDSEARCH RESPONSE");
					HTMLTransformer transformer = new HTMLTransformer(new String(objectResource.getContent()));
					
					String sMessagePayload = transformer.transform(sPayload);
				
					Document doc = DocumentHelper.parseText(sMessagePayload);
					
					Element root = doc.getRootElement();
					
					Node sOrderServiceNode = root.selectSingleNode("//DSProductProviderResponse/Reference");
					
					String sOrderServiceCode = sOrderServiceNode != null ? sOrderServiceNode.getStringValue() : null;
					
					CMessage message = new CMessage();

					if (CStringUtils.isEmpty(sOrderServiceCode))
					{
						throw new CRuntimeException("orderServiceCode is not found");
					}
					
					Long nOrderServiceID = getOrderServiceID(sOrderServiceCode);
					
					if (nOrderServiceID == null)
					{
						throw new CRuntimeException("Subrequest is not found for code " + sOrderServiceCode);
					}
					
					COrderServiceDataSource orderServiceDataSource = (COrderServiceDataSource) DB.session().createCriteria(COrderServiceDataSource.class)
						.add(Restrictions.eq("orderServiceID", nOrderServiceID.intValue()))
						.list()
						.stream()
						.filter(osds->!"COMPLETED".equals(((COrderServiceDataSource)osds).getState()))
						.findFirst()
						.orElse(null);
					
					if (orderServiceDataSource == null)
					{
						throw new CRuntimeException("There is no pending orderServiceDataSource for orderServiceID=" + nOrderServiceID);
					}
					
					CProperties osdsProperties = orderServiceDataSource.getProperties();
					
					String sTransactionID = osdsProperties.getProperty("transactionID");
							
					if (CStringUtils.isEmpty(sTransactionID))
					{
						sTransactionID = CDataExchangeLog.generateTransactionID();
						CTraceLog.warning("No 'transactionID' in payload. New 'transactionID' is " + sTransactionID,
								this.getClass().getName() + ".put()", new CProperties()
								.setProperty("orderServiceCode", sOrderServiceCode));
					}
					
					CDataExchangeLog.addInLog(
							sTransactionID,
							"ADVANCED SEARCH",
							"CONTENT PROVIDER",
							null,
							"ADVANCEDSEARCH/1.0",
							null,
							sPayload);
					
					message.setProperty("assignedActorClass", osdsProperties.getProperty("assignedActorClass"));
					message.setProperty("assignedActorID", osdsProperties.getProperty("assignedActorID"));
					message.setProperty("orderServiceDataSourceID", String.valueOf(orderServiceDataSource.getID()));
					message.setProperty("dsProductID", osdsProperties.getProperty("dsProductID"));
					message.setProperty("transactionID", sTransactionID);
					
					message.setAdapterID(ADAPTER_ID);
					message.setDomainID("BASE");
					message.setProperty("orderServiceID", String.valueOf(nOrderServiceID));
					message.setSubject("AdvancedSearch response for " + sOrderServiceCode);
					CMessagePayload payload = new CMessagePayload();
					payload.setContentType(Mime.TEXT_XML);
					payload.setPayloadClob(sMessagePayload);
					message.addPayload(payload);
					
					CMessageManager.create(message);
					
					return null;
				}
			});


			return  "{\"status\":\"OK\"}";
		}
		catch(Throwable ex)
		{
			CTraceLog.error(ex);
			return  "{\"status\":\"Error\"}";
		}
		
	}
	
	private Long getOrderServiceID(String sOrderServiceCode) throws Exception
	{
		String sRegID = CStringUtils.nvl(sOrderServiceCode).substring(0, sOrderServiceCode.length() - 7);

		Long nOrderID = COrder.findOrderByRegID(DB.connection(), sRegID);
		
		return COrderServiceManager.getOrderServiceID(nOrderID, sOrderServiceCode);
	}
}
