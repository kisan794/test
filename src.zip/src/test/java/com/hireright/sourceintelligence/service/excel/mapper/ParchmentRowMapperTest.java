package com.hireright.sourceintelligence.service.excel.mapper;

import com.hireright.sourceintelligence.api.dto.ParchmentRecord;
import com.hireright.sourceintelligence.service.excel.ExcelColumnMapping;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class ParchmentRowMapperTest {

    private ParchmentRowMapper rowMapper;
    private Workbook workbook;
    private Sheet sheet;
    private ExcelColumnMapping columnMapping;

    @BeforeEach
    void setUp() {
        rowMapper = new ParchmentRowMapper();
        workbook = new XSSFWorkbook();
        sheet = workbook.createSheet("Test Sheet");

        columnMapping = ExcelColumnMapping.builder()
                .addColumn("institutionName", 0)
                .addColumn("country", 1)
                .addColumn("city", 2)
                .addColumn("stateCountyRegion", 3)
                .addColumn("serviceProvider", 4)
                .addColumn("surchargeAmount", 5)
                .addColumn("paymentMethod", 6)
                .addColumn("code", 7)
                .addColumn("turnaroundTime", 8)
                .addColumn("followUpAllowed", 9)
                .build();
    }

    @AfterEach
    void tearDown() throws IOException {
        if (workbook != null) {
            workbook.close();
        }
    }

    @Test
    void mapRow_WithAllFields_ShouldMapCorrectly() {
        Row row = sheet.createRow(0);
        row.createCell(0).setCellValue("Harvard University");
        row.createCell(1).setCellValue("USA");
        row.createCell(2).setCellValue("Cambridge");
        row.createCell(3).setCellValue("MA");
        row.createCell(4).setCellValue("Parchment Exchange");
        row.createCell(5).setCellValue("5.00");
        row.createCell(6).setCellValue("Credit Card");
        row.createCell(7).setCellValue("HARV001");
        row.createCell(8).setCellValue("3");
        row.createCell(9).setCellValue("Yes");

        ParchmentRecord record = rowMapper.mapRow(row, columnMapping);

        assertNotNull(record);
        assertEquals("Harvard University", record.getInstitutionName());
        assertEquals("USA", record.getCountry());
        assertEquals("Cambridge", record.getCity());
        assertEquals("MA", record.getStateCountyRegion());
        assertEquals("Parchment Exchange", record.getServiceProvider());
        assertEquals("Credit Card", record.getPaymentMethod());
        assertEquals("HARV001", record.getCode());
        assertEquals("3", record.getTurnaroundTime());
        assertEquals("Yes", record.getFollowUpAllowed());
    }

    @Test
    void mapRow_WithMissingFields_ShouldMapWithEmptyStrings() {
        Row row = sheet.createRow(0);
        row.createCell(0).setCellValue("MIT");
        row.createCell(1).setCellValue("USA");
        row.createCell(2).setCellValue("Cambridge");

        ParchmentRecord record = rowMapper.mapRow(row, columnMapping);

        assertNotNull(record);
        assertEquals("MIT", record.getInstitutionName());
        assertEquals("USA", record.getCountry());
        assertEquals("Cambridge", record.getCity());
        assertEquals("", record.getStateCountyRegion());
        assertEquals("", record.getServiceProvider());
        assertEquals("", record.getPaymentMethod());
        assertEquals("", record.getCode());
        assertEquals("", record.getTurnaroundTime());
        assertEquals("", record.getFollowUpAllowed());
    }

    @Test
    void mapRow_WithNumericValues_ShouldConvertToString() {
        Row row = sheet.createRow(0);
        row.createCell(0).setCellValue("Test University");
        row.createCell(1).setCellValue("USA");
        row.createCell(2).setCellValue("Boston");
        row.createCell(3).setCellValue("MA");
        row.createCell(4).setCellValue("Parchment Exchange");
        row.createCell(5).setCellValue(10.5);
        row.createCell(6).setCellValue("Credit Card");
        row.createCell(7).setCellValue(12345);
        row.createCell(8).setCellValue(5);
        row.createCell(9).setCellValue("Yes");

        ParchmentRecord record = rowMapper.mapRow(row, columnMapping);

        assertNotNull(record);
        assertEquals("12345", record.getCode());
        assertEquals("5", record.getTurnaroundTime());
    }

    @Test
    void mapRow_WithWhitespace_ShouldTrimValues() {
        Row row = sheet.createRow(0);
        row.createCell(0).setCellValue("  Harvard University  ");
        row.createCell(1).setCellValue(" USA ");
        row.createCell(2).setCellValue("  Cambridge  ");
        row.createCell(3).setCellValue(" MA ");

        ParchmentRecord record = rowMapper.mapRow(row, columnMapping);

        assertNotNull(record);
        assertEquals("Harvard University", record.getInstitutionName());
        assertEquals("USA", record.getCountry());
        assertEquals("Cambridge", record.getCity());
        assertEquals("MA", record.getStateCountyRegion());
    }

    @Test
    void mapRow_WithSpecialCharacters_ShouldPreserveCharacters() {
        Row row = sheet.createRow(0);
        row.createCell(0).setCellValue("O'Brien University");
        row.createCell(1).setCellValue("USA");
        row.createCell(2).setCellValue("St. Louis");
        row.createCell(3).setCellValue("MO");
        row.createCell(4).setCellValue("Parchment Exchange");
        row.createCell(5).setCellValue("$5.00");
        row.createCell(6).setCellValue("Credit/Debit Card");
        row.createCell(7).setCellValue("CODE-123");

        ParchmentRecord record = rowMapper.mapRow(row, columnMapping);

        assertNotNull(record);
        assertEquals("O'Brien University", record.getInstitutionName());
        assertEquals("St. Louis", record.getCity());
        assertEquals("Credit/Debit Card", record.getPaymentMethod());
        assertEquals("CODE-123", record.getCode());
    }

    @Test
    void mapRow_WithEmptyRow_ShouldMapAllEmptyStrings() {
        Row row = sheet.createRow(0);

        ParchmentRecord record = rowMapper.mapRow(row, columnMapping);

        assertNotNull(record);
        assertEquals("", record.getInstitutionName());
        assertEquals("", record.getCountry());
        assertEquals("", record.getCity());
        assertEquals("", record.getStateCountyRegion());
        assertEquals("", record.getServiceProvider());
        assertEquals("", record.getSurchargeAmount());
        assertEquals("", record.getPaymentMethod());
        assertEquals("", record.getCode());
        assertEquals("", record.getTurnaroundTime());
        assertEquals("", record.getFollowUpAllowed());
    }

    @Test
    void mapRow_WithNullColumnMapping_ShouldMapEmptyStrings() {
        Row row = sheet.createRow(0);
        row.createCell(0).setCellValue("Harvard University");
        row.createCell(1).setCellValue("USA");

        ExcelColumnMapping emptyMapping = ExcelColumnMapping.builder().build();

        ParchmentRecord record = rowMapper.mapRow(row, emptyMapping);

        assertNotNull(record);
        assertEquals("", record.getInstitutionName());
        assertEquals("", record.getCountry());
        assertEquals("", record.getCity());
    }

    @Test
    void mapRow_WithPartialMapping_ShouldMapOnlyMappedFields() {
        Row row = sheet.createRow(0);
        row.createCell(0).setCellValue("Stanford University");
        row.createCell(1).setCellValue("USA");
        row.createCell(2).setCellValue("Stanford");
        row.createCell(3).setCellValue("CA");

        ExcelColumnMapping partialMapping = ExcelColumnMapping.builder()
                .addColumn("institutionName", 0)
                .addColumn("country", 1)
                .build();

        ParchmentRecord record = rowMapper.mapRow(row, partialMapping);

        assertNotNull(record);
        assertEquals("Stanford University", record.getInstitutionName());
        assertEquals("USA", record.getCountry());
        assertEquals("", record.getCity());
        assertEquals("", record.getStateCountyRegion());
    }

    @Test
    void mapRow_WithUnicodeCharacters_ShouldPreserveUnicode() {
        Row row = sheet.createRow(0);
        row.createCell(0).setCellValue("Université de Montréal");
        row.createCell(1).setCellValue("Canada");
        row.createCell(2).setCellValue("Montréal");
        row.createCell(3).setCellValue("QC");

        ParchmentRecord record = rowMapper.mapRow(row, columnMapping);

        assertNotNull(record);
        assertEquals("Université de Montréal", record.getInstitutionName());
        assertEquals("Montréal", record.getCity());
    }

    @Test
    void mapRow_WithLongText_ShouldMapCorrectly() {
        Row row = sheet.createRow(0);
        String longName = "The Very Long Name of an Educational Institution for Higher Learning";
        row.createCell(0).setCellValue(longName);
        row.createCell(1).setCellValue("USA");

        ParchmentRecord record = rowMapper.mapRow(row, columnMapping);

        assertNotNull(record);
        assertEquals(longName, record.getInstitutionName());
    }

    @Test
    void mapRow_WithBooleanCell_ShouldConvertToString() {
        Row row = sheet.createRow(0);
        row.createCell(0).setCellValue("Test University");
        row.createCell(1).setCellValue("USA");
        row.createCell(9).setCellValue(true);

        ParchmentRecord record = rowMapper.mapRow(row, columnMapping);

        assertNotNull(record);
        assertEquals("true", record.getFollowUpAllowed());
    }

    @Test
    void mapRow_MultipleRows_ShouldMapIndependently() {
        Row row1 = sheet.createRow(0);
        row1.createCell(0).setCellValue("Harvard University");
        row1.createCell(1).setCellValue("USA");

        Row row2 = sheet.createRow(1);
        row2.createCell(0).setCellValue("MIT");
        row2.createCell(1).setCellValue("USA");

        ParchmentRecord record1 = rowMapper.mapRow(row1, columnMapping);
        ParchmentRecord record2 = rowMapper.mapRow(row2, columnMapping);

        assertEquals("Harvard University", record1.getInstitutionName());
        assertEquals("MIT", record2.getInstitutionName());
        assertNotSame(record1, record2);
    }

    @Test
    void mapRow_WithMixedCellTypes_ShouldHandleGracefully() {
        Row row = sheet.createRow(0);
        row.createCell(0).setCellValue("University");
        row.createCell(1).setCellValue("USA");
        row.createCell(2).setCellValue("Boston");
        row.createCell(3).setCellValue("MA");
        row.createCell(4).setCellValue("Provider");
        row.createCell(5).setCellValue(15.75);
        row.createCell(6).setCellValue("Card");
        row.createCell(7).setCellValue(999);
        row.createCell(8).setCellValue(7);
        row.createCell(9).setCellValue(false);

        ParchmentRecord record = rowMapper.mapRow(row, columnMapping);

        assertNotNull(record);
        assertEquals("University", record.getInstitutionName());
        assertEquals("999", record.getCode());
        assertEquals("7", record.getTurnaroundTime());
        assertEquals("false", record.getFollowUpAllowed());
    }
}

