package com.hireright.sourceintelligence.api.v1;

import static com.hireright.sourceintelligence.api.ApiConstants.*;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.*;
import static com.hireright.sourceintelligence.api.ApiDescriptions.*;
import com.hireright.sourceintelligence.api.ApiConstants;
import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.dto.timezone.DropDownDTO;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.exception.ApiError;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.*;
import jakarta.validation.constraints.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RequestMapping(value = BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH)
@Tag(name = "Search Source Organization", description = "Endpoints for Searching Source Organizations")
public interface SearchApi {


    //Dropdown options in smart search, ram and changelog
    @Operation(summary = "Get autocompleted strings searched by a keyword ",
      description = AUTOCOMPLETE_SEARCH_DESCRIPTION,
      responses = {
          @ApiResponse(description = "Autocompleted texts found", responseCode = "200",
              content = @Content(mediaType = "application/json",
                  array = @ArraySchema(schema = @Schema(implementation = AutocompleteSearchDTO.class)))),
          @ApiResponse(description = "Fields Not found", responseCode = "404",
              content = @Content(mediaType = "application/json",
                  schema = @Schema(implementation = ApiError.class))),
          @ApiResponse(description = "Internal error", responseCode = "500",
              content = @Content(mediaType = "application/json",
                  schema = @Schema(implementation = ApiError.class)))})
  @GetMapping(value = SOURCE_ORGANIZATION_AUTOCOMPLETE + ApiPath.SEARCH, produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.OK)
  ResponseEntity<List<AutocompleteSearchDTO>> autocompleteFilters(
      @RequestParam(value = ApiConstants.SEARCH_KEYWORD) @NotBlank String keyword,
      @RequestParam(value = ApiConstants.SEARCH_ORGANIZATION_TYPE,required = false) OrganizationType organizationType,
      @RequestParam(value = SEARCH_ORGANIZATION_STATUS,required = false) SourceOrganizationStatus status,
      @RequestParam(value = IS_RAM,required = false) Boolean isRAM,
      @RequestParam(required = false) Map<String,String> searchFilters);


    //RAM search
  @Operation(summary = "Search for organizations by filters",
      description = SEARCH_BY_FILTER_DESCRIPTION ,
      responses = {
          @ApiResponse(description = "OrganizationName  Found", responseCode = "200",
              content = @Content(mediaType = "application/json",
                  schema = @Schema(implementation = SearchListDTO.class))),
          @ApiResponse(description = "OrganizationName  Not found", responseCode = "404",
              content = @Content(mediaType = "application/json",
                  schema = @Schema(implementation = ApiError.class))),
          @ApiResponse(description = "Internal error", responseCode = "500",
              content = @Content(mediaType = "application/json",
                  schema = @Schema(implementation = ApiError.class)))})
  @PostMapping(value = SOURCE_ORGANIZATION
      + ApiPath.SEARCH, produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.OK)
  ResponseEntity<SearchResponseDTO> sourceOrganizationsByFilters(
      @RequestBody SearchFilter searchFilter);

    //Create source -  duplicate source listing
  @Operation(summary = "Get sources with autocompleted organization names by a keyword",
      description = AUTOCOMPLETE_SUGGESTION_ON_SOURCE_CREATION_DESCRIPTION,
      responses = {
          @ApiResponse(description = "Autocompleted texts found", responseCode = "200",
              content = @Content(mediaType = "application/json",
                  array = @ArraySchema(schema = @Schema(implementation = SearchResponseDTO.class)))),
          @ApiResponse(description = "Fields Not found", responseCode = "404",
              content = @Content(mediaType = "application/json",
                  schema = @Schema(implementation = ApiError.class))),
          @ApiResponse(description = "Internal error", responseCode = "500",
              content = @Content(mediaType = "application/json",
                  schema = @Schema(implementation = ApiError.class)))})
  @GetMapping(value = SOURCE_ORGANIZATION_AUTOCOMPLETE + SUGGESTION, produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.OK)
  ResponseEntity<List<SourceOrganizationDTO>> autocompleteSourceSuggestionForPossibleDuplicates(
      @RequestParam(value = ApiConstants.SEARCH_KEYWORD) @NotBlank String keyword,
      @RequestParam(value = ApiConstants.SEARCH_ORGANIZATION_TYPE) OrganizationType organizationType);

//Ram - Filters values
  @Operation(summary = "Gets filters to narrow down list of organizations",
      description = "Gets the filters based on the data obtained after searching based on organization name or hon" ,
      responses = {
          @ApiResponse(description = "OrganizationName  Found", responseCode = "200",
              content = @Content(mediaType = "application/json",
                  schema = @Schema(implementation = SearchFilter.class))),
          @ApiResponse(description = "OrganizationName  Not found", responseCode = "404",
              content = @Content(mediaType = "application/json",
                  schema = @Schema(implementation = ApiError.class))),
          @ApiResponse(description = "Internal error", responseCode = "500",
              content = @Content(mediaType = "application/json",
                  schema = @Schema(implementation = ApiError.class)))})
  @GetMapping(value = APPROVAL_WORKFLOW+ SOURCE_ORGANIZATION
      + FILTERS, produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.OK)
  ResponseEntity<SearchFilter> getFiltersForSourceOrganizations(
      @RequestParam(value = SEARCH_ORGANIZATION_TEXT, required = false) String organizationName,
      @RequestParam(value = HON, required = false) String hon);

  //Smart Search
  @Operation(summary = "Smart Search",
          description = SEARCH_BY_FILTER_DESCRIPTION ,
          responses = {
                  @ApiResponse(description = "OrganizationName  Found", responseCode = "200",
                          content = @Content(mediaType = "application/json",
                                  schema = @Schema(implementation = SmartSearchDTO.class))),
                  @ApiResponse(description = "OrganizationName  Not found", responseCode = "404",
                          content = @Content(mediaType = "application/json",
                                  schema = @Schema(implementation = ApiError.class))),
                  @ApiResponse(description = "Internal error", responseCode = "500",
                          content = @Content(mediaType = "application/json",
                                  schema = @Schema(implementation = ApiError.class)))})
  @PostMapping(value = SOURCE_ORGANIZATION
          +SOURCE_TYPE_PATH_VAR+ ApiPath.SEARCH_SOURCE, produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.OK)
  ResponseEntity<SearchResponseDTO> getSourceListBySmartSearch(@PathVariable(value = "type") @NotNull final String type, @RequestBody SmartSearchDTO smartSearchDTO);

  //Ram - Filters values
  @Operation(summary = "Gets filters to narrow down list of organizations",
          description = "Gets the filters based on the data obtained after searching based on organization name or hon" ,
          responses = {
                  @ApiResponse(description = "OrganizationName  Found", responseCode = "200",
                          content = @Content(mediaType = "application/json",
                                  schema = @Schema(implementation = SearchFilter.class))),
                  @ApiResponse(description = "OrganizationName  Not found", responseCode = "404",
                          content = @Content(mediaType = "application/json",
                                  schema = @Schema(implementation = ApiError.class))),
                  @ApiResponse(description = "Internal error", responseCode = "500",
                          content = @Content(mediaType = "application/json",
                                  schema = @Schema(implementation = ApiError.class)))})
  @GetMapping(value =  SOURCE_ORGANIZATION
          + REGION_LIST, produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.OK)
  ResponseEntity<List<DropDownDTO>> getRegionList();


}

