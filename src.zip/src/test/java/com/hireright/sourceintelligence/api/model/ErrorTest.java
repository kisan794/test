package com.hireright.sourceintelligence.api.model;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@SpringBootTest(classes = ErrorTest.class)
@AutoConfigureMockMvc
@ActiveProfiles("unittest")
@EnableWebMvc
public class ErrorTest {

	@Mock
	private Error errorMock;
	
	@Test
	public void testGettersAndSetters() {
//		
//		errorMock = new Error();
//		
//		errorMock.setErrorCode("");
//		errorMock.getErrorCode();
//		
//		errorMock.setField("");
//		errorMock.getField();
//		
//		errorMock.setMessage("");
//		errorMock.getMessage();
//		
//		assertNotNull(errorMock);
	}
}
