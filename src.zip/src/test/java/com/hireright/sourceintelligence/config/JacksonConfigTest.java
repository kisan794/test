package com.hireright.sourceintelligence.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

class JacksonConfigTest {

    @Test
    void objectMapperTest() {
        JacksonConfig jacksonConfig = new JacksonConfig();
        ObjectMapper objMapper = jacksonConfig.objectMapper();
        assertThat(objMapper).isNotNull();
    }
}