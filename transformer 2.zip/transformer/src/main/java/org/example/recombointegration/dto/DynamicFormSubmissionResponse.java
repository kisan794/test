package org.example.recombointegration.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.example.recombointegration.document.DynamicFormSubmission.SubmissionStatus;
import org.example.recombointegration.document.DynamicFormSubmission.SubmissionComment;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * DTO for dynamic form submission response.
 *
 * @author Generated
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DynamicFormSubmissionResponse {

    private String id;
    private String formId;
    private String formVersion;
    private String emailAddress;
    private Map<String, Object> formData;
    private SubmissionStatus status;
    private String assignedTo;
    private String reviewedBy;
    private LocalDateTime reviewedAt;
    private String reviewComments;
    private Integer upvoteCount;
    private List<String> upvotedBy;
    private List<SubmissionComment> comments;
    private LocalDateTime submissionDate;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Map<String, Object> metadata;
}

