package org.example.recombointegration.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Request DTO for adding a comment to an idea submission.
 *
 * @author Generated
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request object for adding a comment to an idea")
public class IdeaCommentRequest {

    @NotBlank(message = "Commenter name is required")
    @Schema(description = "Name of the person commenting", example = "Jane Smith", required = true)
    @JsonProperty("commenterName")
    private String commenterName;

    @Schema(description = "Email address of the commenter", example = "jane.smith@company.com")
    @JsonProperty("commenterEmail")
    private String commenterEmail;

    @NotBlank(message = "Comment is required")
    @Schema(description = "The comment text", example = "Great idea! This could save us a lot of time.", required = true)
    @JsonProperty("comment")
    private String comment;
}

