package org.example.recombointegration.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.Map;

/**
 * DTO for dynamic form submission request.
 * Accepts any form data as a flexible key-value map.
 *
 * @author Generated
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DynamicFormSubmissionRequest {

    /**
     * Form ID (e.g., "idea-submission-form")
     */
    @NotBlank(message = "Form ID is required")
    private String formId;

    /**
     * Email address of the submitter (optional)
     */
    private String emailAddress;

    /**
     * Dynamic form data as key-value pairs
     * Keys should match fieldKey from form configuration
     */
    @NotNull(message = "Form data is required")
    private Map<String, Object> formData;

    /**
     * Whether to save as draft (true) or submit (false)
     */
    @Builder.Default
    private Boolean isDraft = false;

    /**
     * Additional metadata (optional)
     */
    private Map<String, Object> metadata;
}

