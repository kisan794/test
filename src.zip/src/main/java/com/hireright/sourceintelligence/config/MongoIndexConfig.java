package com.hireright.sourceintelligence.config;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.index.Index;
import org.springframework.data.mongodb.core.index.IndexOperations;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class MongoIndexConfig {

    private final MongoTemplate mongoTemplate;

    @PostConstruct
    public void initIndexes() {
        createParchmentSourceIndexes();
    }

    private void createParchmentSourceIndexes() {
        try {
            IndexOperations indexOps = mongoTemplate.indexOps("education_source_parchment_test");

            Index locationNameIndex = new Index()
                    .on("state", Sort.Direction.ASC)
                    .on("city", Sort.Direction.ASC)
                    .on("country", Sort.Direction.ASC)
                    .on("organizationName", Sort.Direction.ASC)
                    .named("idx_location_name")
                    .background();

            indexOps.ensureIndex(locationNameIndex);
            log.info("Created index: idx_location_name");

        } catch (Exception e) {
            log.error("Failed to create MongoDB indexes for Parchment sources", e);
        }
    }
}