package com.hireright.sourceintelligence.config;

import com.mongodb.client.MongoClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.MongoTransactionManager;
import org.springframework.test.util.ReflectionTestUtils;

import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
public class DatabaseConfigurationTest {

    @InjectMocks
    private DatabaseConfiguration databaseConfiguration;

    @Mock
    private MongoDatabaseFactory mongoDatabaseFactory;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(databaseConfiguration, "dbConnectionString", "mongodb://localhost:8088/test");
        ReflectionTestUtils.setField(databaseConfiguration, "primaryDatabaseName", "test");
        ReflectionTestUtils.setField(databaseConfiguration, "elasticsearchEnvType", "STAGE"); 
    }

    @Test
    void transactionManagerTest() {

        MongoTransactionManager transactionManager = databaseConfiguration.transactionManager(mongoDatabaseFactory);
        assertNotNull(transactionManager, "TransactionManager should not be null");
    }

    @Test
    void getDatabaseNameTest() {
        assertThatNoException().isThrownBy(() ->databaseConfiguration.getDatabaseName());
    }

    @Test
    void mongoClientTest() {

        MongoClient actualMongoClient = databaseConfiguration.mongoClient();
        assertNotNull(actualMongoClient);

    }
}
