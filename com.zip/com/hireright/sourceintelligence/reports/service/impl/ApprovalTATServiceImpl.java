package com.hireright.sourceintelligence.reports.service.impl;

import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.reports.domain.entity.Reports;
import com.hireright.sourceintelligence.reports.domain.entity.ReportSearchResult;
import com.hireright.sourceintelligence.reports.domain.entity.ResponseReport;
import com.hireright.sourceintelligence.reports.domain.entity.TATReport;
import com.hireright.sourceintelligence.reports.domain.mapper.ReportMapper;
import com.hireright.sourceintelligence.reports.dto.GenericResponseDTO;
import com.hireright.sourceintelligence.reports.dto.MetaDTO;
import com.hireright.sourceintelligence.reports.dto.ReportResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;
import com.hireright.sourceintelligence.reports.service.ApprovalTATService;
import com.hireright.sourceintelligence.service.impl.QueryBuilder;
import com.hireright.sourceintelligence.service.impl.helperservices.CountryRegionMappingUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.REPORTS_COLLECTION;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.TAT_REPORT_LIST;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.ReportTypes.APPROVAL_TAT;
import static com.hireright.sourceintelligence.reports.service.impl.ReportUtils.getMetaDataByReport;

@Slf4j
@RequiredArgsConstructor
@Service
public class ApprovalTATServiceImpl implements ApprovalTATService {

    private final ReportMapper reportMapper;
    private final CustomSourceRepository<Reports> customSourceRepository;
    private final CountryRegionMappingUtils countryRegionMappingUtils;

    @Override
    public ReportResponseDTO getApprovalAverageTAT(ReportsRequestDTO reportsRequestDTO) {
        List<String> countryList = null;
        if(reportsRequestDTO.getRegion() != null && !reportsRequestDTO.getRegion().isEmpty()){
            countryList = countryRegionMappingUtils.findDistinctCountriesByRegion(reportsRequestDTO.getRegion());
        }
        Criteria criteria = ReportsQueryBuilder.queryBuilderForApprovalTat(reportsRequestDTO, countryList);
        MatchOperation matchOperation = ReportsQueryBuilder.matchOperation(criteria);

        Criteria criteria2 = ReportsQueryBuilder.queryBuilderForTatFilter();
        MatchOperation matchOperation2 = ReportsQueryBuilder.matchOperation(criteria2);

        ProjectionOperation projectionOperation = ReportsQueryBuilder.excludeProjection();
        GroupOperation groupOperation = ReportsQueryBuilder.approvalTATGroupOperation();
        SortOperation sortOperation = ReportsQueryBuilder.buildSortOperationForTAT(reportsRequestDTO.getSort(), reportsRequestDTO.getOrder());
        FacetOperation facetOperation = ReportsQueryBuilder.facetOperation(reportsRequestDTO.getStartPage(), reportsRequestDTO.getBatchSize());
        if(!reportsRequestDTO.getSort().isEmpty()){
            facetOperation = ReportsQueryBuilder.facetOperationWithSorting(sortOperation, reportsRequestDTO.getStartPage(), reportsRequestDTO.getBatchSize());
        }
        ProjectionOperation finalProject = ReportsQueryBuilder.finalProjectionWithTotalCountInPipeline(TAT_REPORT_LIST);

        AggregationOptions aggregationOptionsToAllowDiskUse = AggregationOptions.builder()
                .allowDiskUse(true).build();
        Aggregation aggregation;
        aggregation = Aggregation.newAggregation(matchOperation,projectionOperation, groupOperation, matchOperation2, facetOperation, finalProject).withOptions(aggregationOptionsToAllowDiskUse);
        log.info("Aggregation:{}",aggregation);

        var response = customSourceRepository.reportCustomAggregate(aggregation,REPORTS_COLLECTION, ReportSearchResult.class);
        log.info("Response: {}", response);
        List<GenericResponseDTO> responseDTOS = new ArrayList<>();
        var res = timeCalculations(response.getTatResponseReportList());
        if(!res.isEmpty()){
            responseDTOS = reportMapper.toDTOList(res);
        }
        List<MetaDTO> metaDTOList = getMetaDataByReport(APPROVAL_TAT);

        return ReportResponseDTO.builder().
                meta(metaDTOList).response(responseDTOS)
                .currentPage(reportsRequestDTO.getStartPage())
                .totalItems(res.size())
                .totalPages(QueryBuilder.getTotalPages(res.size(), reportsRequestDTO.getBatchSize()))
                .reportType(APPROVAL_TAT).build();

    }

    private List<ResponseReport> timeCalculations(List<TATReport> tatReportList){
        List<ResponseReport> responseReportList = new ArrayList<>();
       for (TATReport tatReport : tatReportList) {
           ResponseReport report = new ResponseReport();
           if(!tatReport.getData().isEmpty()){
               int dataSize = tatReport.getData().size();
               Instant startDate = null;
               Instant endDate = null;
               Instant tempDate = null;
               long totalMins = 0;
               long mins = 0;
               boolean criteriaFound = false;
               for (int i = 0; i < dataSize; i++) {
                   ResponseReport rsReport = tatReport.getData().get(i);

                   if(dataSize == 1){
                       report.setApprovalDuration("0");
                       report.setTotalApprovalDuration("0");
                   }else{
                        //Total Duration
                       if(rsReport.getApprovalStatus().equals(ApprovalStatus.PENDING_APPROVAL.getStatus()) || rsReport.getApprovalStatus().equals(ApprovalStatus.SAVE_PENDING_APPROVAL.getStatus())){
                           startDate = rsReport.getCreatedDate();
                       }else if(rsReport.getApprovalStatus().equals(ApprovalStatus.APPROVED.getStatus()) || rsReport.getApprovalStatus().equals(ApprovalStatus.REJECTED.getStatus())){
                           report = rsReport;
                           criteriaFound = true;
                           endDate = rsReport.getCreatedDate();
                           if(tempDate != null){
                               mins += Math.abs(Duration.between(tempDate, rsReport.getCreatedDate()).toMillis());
                           }
                       }else if(rsReport.getApprovalStatus().equals(ApprovalStatus.IN_PROGRESS.getStatus())){
                           tempDate = rsReport.getCreatedDate();
                       }else if(rsReport.getApprovalStatus().equals(ApprovalStatus.ONHOLD.getStatus())){
                           if(tempDate != null && rsReport.getCreatedDate() != null){
                               mins += Math.abs(Duration.between(tempDate, rsReport.getCreatedDate()).toMillis());
                           }
                           tempDate = rsReport.getCreatedDate();
                       }
                   }
               }
               if(endDate == null){
                   endDate = Instant.now();
               }
               if(startDate != null && endDate != null && startDate.isBefore(endDate)){
                   totalMins = Math.abs(Duration.between(startDate, endDate).toMillis());
               }
               report.setApprovalDuration(""+mins);
               report.setTotalApprovalDuration(""+totalMins);
               if(criteriaFound){
                   responseReportList.add(report);
               }
           }
       }
       return responseReportList;
    }

}
