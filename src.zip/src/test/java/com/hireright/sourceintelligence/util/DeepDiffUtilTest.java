package com.hireright.sourceintelligence.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.MissingNode;
import com.fasterxml.jackson.databind.node.NullNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class DeepDiffUtilTest {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Test
    void privateConstructor_shouldBeCovered() throws Exception {
        Constructor<DeepDiffUtil> constructor = DeepDiffUtil.class.getDeclaredConstructor();
        constructor.setAccessible(true);
        DeepDiffUtil instance = constructor.newInstance();
        assertNotNull(instance);
    }
    @Test
    void findChangedFields_shouldCoverNestedObjectAndArrayRecursionTogether() {
        java.util.Map<String, Object> left = java.util.Map.of(
                "outer", java.util.Map.of(
                        "items", java.util.List.of(
                                java.util.Map.of("name", "A"),
                                java.util.Map.of("name", "B")
                        )
                )
        );

        java.util.Map<String, Object> right = java.util.Map.of(
                "outer", java.util.Map.of(
                        "items", java.util.List.of(
                                java.util.Map.of("name", "A"),
                                java.util.Map.of("name", "C")
                        )
                )
        );

        List<String> changes = DeepDiffUtil.findChangedFields(left, right);

        assertEquals(List.of("outer.items[1].name"), changes);
    }
    @Test
    void diffNodes_shouldHandleLeftNullAndRightNull_asMissingNodes() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod(
                "diffNodes", JsonNode.class, JsonNode.class, String.class, List.class);
        method.setAccessible(true);

        List<String> changes = new ArrayList<>();

        method.invoke(null, null, null, "root", changes);

        assertTrue(changes.isEmpty());
    }
    @Test
    void diffNodes_shouldSkipWhenLeftEmptyArrayAndRightNull() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod(
                "diffNodes", JsonNode.class, JsonNode.class, String.class, List.class);
        method.setAccessible(true);

        ArrayNode left = MAPPER.createArrayNode();
        List<String> changes = new ArrayList<>();

        method.invoke(null, left, null, "items", changes);

        assertTrue(changes.isEmpty());
    }

    @Test
    void diffNodes_shouldSkipWhenRightEmptyArrayAndLeftNull() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod(
                "diffNodes", JsonNode.class, JsonNode.class, String.class, List.class);
        method.setAccessible(true);

        ArrayNode right = MAPPER.createArrayNode();
        List<String> changes = new ArrayList<>();

        method.invoke(null, null, right, "items", changes);

        assertTrue(changes.isEmpty());
    }

    @Test
    void diffNodes_shouldRecordChangeWhenTypesDiffer() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod(
                "diffNodes", JsonNode.class, JsonNode.class, String.class, List.class);
        method.setAccessible(true);

        JsonNode left = MAPPER.readTree("\"abc\"");
        JsonNode right = MAPPER.readTree("[1]");
        List<String> changes = new ArrayList<>();

        method.invoke(null, left, right, "field", changes);

        assertEquals(List.of("field"), changes);
    }

    @Test
    void diffNodes_shouldComparePrimitiveValues_usingAsTextBranch() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod(
                "diffNodes", JsonNode.class, JsonNode.class, String.class, List.class);
        method.setAccessible(true);

        JsonNode left = MAPPER.readTree("\"A\"");
        JsonNode right = MAPPER.readTree("\"B\"");
        List<String> changes = new ArrayList<>();

        method.invoke(null, left, right, "name", changes);

        assertEquals(List.of("name"), changes);
    }

    @Test
    void diffArrays_shouldCoverBothEarlyReturnSides() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod(
                "diffArrays", JsonNode.class, JsonNode.class, String.class, List.class);
        method.setAccessible(true);

        ArrayNode empty = MAPPER.createArrayNode();
        List<String> changes1 = new ArrayList<>();
        List<String> changes2 = new ArrayList<>();

        method.invoke(null, empty, NullNode.getInstance(), "items", changes1);
        method.invoke(null, NullNode.getInstance(), empty, "items", changes2);

        assertTrue(changes1.isEmpty());
        assertTrue(changes2.isEmpty());
    }

    @Test
    void diffArrays_shouldRecordOnlyArrayPathWhenSizesDifferAndOverlapMatches() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod(
                "diffArrays", JsonNode.class, JsonNode.class, String.class, List.class);
        method.setAccessible(true);

        JsonNode left = MAPPER.readTree("[1,2,3]");
        JsonNode right = MAPPER.readTree("[1,2]");
        List<String> changes = new ArrayList<>();

        method.invoke(null, left, right, "arr", changes);

        assertEquals(List.of("arr"), changes);
    }

    @Test
    void diffArrays_shouldTraverseOverlappingIndexes() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod(
                "diffArrays", JsonNode.class, JsonNode.class, String.class, List.class);
        method.setAccessible(true);

        JsonNode left = MAPPER.readTree("[1,9]");
        JsonNode right = MAPPER.readTree("[1,8]");
        List<String> changes = new ArrayList<>();

        method.invoke(null, left, right, "arr", changes);

        assertEquals(List.of("arr[1]"), changes);
    }

    @Test
    void diffObjects_shouldCoverBothMissingBranch() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod(
                "diffObjects", JsonNode.class, JsonNode.class, String.class, List.class);
        method.setAccessible(true);

        ObjectNode left = MAPPER.createObjectNode();
        ObjectNode right = MAPPER.createObjectNode();
        left.set("x", NullNode.getInstance());
        right.set("x", NullNode.getInstance());

        List<String> changes = new ArrayList<>();
        method.invoke(null, left, right, "", changes);

        assertTrue(changes.isEmpty());
    }

    @Test
    void diffObjects_shouldCoverOneMissingBranch() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod(
                "diffObjects", JsonNode.class, JsonNode.class, String.class, List.class);
        method.setAccessible(true);

        ObjectNode left = MAPPER.createObjectNode();
        ObjectNode right = MAPPER.createObjectNode();
        left.put("x", "value");

        List<String> changes = new ArrayList<>();
        method.invoke(null, left, right, "", changes);

        assertEquals(List.of("x"), changes);
    }

    @Test
    void diffObjects_shouldCoverShouldSkipEmptyArrayComparisonBranch() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod(
                "diffObjects", JsonNode.class, JsonNode.class, String.class, List.class);
        method.setAccessible(true);

        ObjectNode left = MAPPER.createObjectNode();
        ObjectNode right = MAPPER.createObjectNode();
        left.set("items", MAPPER.createArrayNode());

        List<String> changes = new ArrayList<>();
        method.invoke(null, left, right, "", changes);

        assertTrue(changes.isEmpty());
    }

    @Test
    void getChildNode_shouldReturnMissingWhenParentDoesNotHaveField() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod("getChildNode", JsonNode.class, String.class);
        method.setAccessible(true);

        ObjectNode parent = MAPPER.createObjectNode();

        JsonNode result = (JsonNode) method.invoke(null, parent, "absent");

        assertTrue(result.isMissingNode());
    }

    @Test
    void getChildNode_shouldReturnMissingWhenParentReturnsNullChild() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod("getChildNode", JsonNode.class, String.class);
        method.setAccessible(true);

        JsonNode parent = Mockito.mock(JsonNode.class);
        Mockito.when(parent.has("x")).thenReturn(true);
        Mockito.when(parent.get("x")).thenReturn(null);

        JsonNode result = (JsonNode) method.invoke(null, parent, "x");

        assertTrue(result.isMissingNode());
    }

    @Test
    void getChildNode_shouldReturnActualChildWhenPresent() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod("getChildNode", JsonNode.class, String.class);
        method.setAccessible(true);

        ObjectNode parent = MAPPER.createObjectNode();
        parent.put("name", "abc");

        JsonNode result = (JsonNode) method.invoke(null, parent, "name");

        assertEquals("abc", result.asText());
    }

    @Test
    void findChangedFields_shouldCoverRootTypeDifference() {
        List<String> changes = DeepDiffUtil.findChangedFields(
                java.util.Map.of("a", 1),
                java.util.List.of(1, 2)
        );

        assertEquals(List.of("$"), changes);
    }

    @Test
    void findChangedFields_shouldReturnEmpty_whenObjectsAreEqual() {
        Map<String, Object> left = Map.of(
                "name", "HR",
                "count", 1,
                "nested", Map.of("city", "Delhi")
        );
        Map<String, Object> right = Map.of(
                "name", "HR",
                "count", 1,
                "nested", Map.of("city", "Delhi")
        );

        List<String> changes = DeepDiffUtil.findChangedFields(left, right);

        assertTrue(changes.isEmpty());
    }

    @Test
    void findChangedFields_shouldReturnRoot_whenPrimitiveValuesDiffer() {
        List<String> changes = DeepDiffUtil.findChangedFields("A", "B");

        assertEquals(List.of("$"), changes);
    }

    @Test
    void findChangedFields_shouldReturnRoot_whenNodeTypesDiffer() {
        List<String> changes = DeepDiffUtil.findChangedFields("A", List.of("A"));

        assertEquals(List.of("$"), changes);
    }

    @Test
    void findChangedFields_shouldTreatBothNullAsEqual() {
        List<String> changes = DeepDiffUtil.findChangedFields(null, null);

        assertTrue(changes.isEmpty());
    }

    @Test
    void findChangedFields_shouldTreatEmptyArrayAndMissingFieldAsEqual() {
        Map<String, Object> left = Map.of("items", List.of());
        Map<String, Object> right = Map.of();

        List<String> changes = DeepDiffUtil.findChangedFields(left, right);

        assertTrue(changes.isEmpty());
    }

    @Test
    void findChangedFields_shouldSkipConfiguredRootFields() {
        Map<String, Object> left = Map.of(
                "id", "1",
                "status", "OLD",
                "name", "ABC"
        );
        Map<String, Object> right = Map.of(
                "id", "2",
                "status", "NEW",
                "name", "ABC"
        );

        List<String> changes = DeepDiffUtil.findChangedFields(left, right);

        assertTrue(changes.isEmpty());
    }

    @Test
    void findChangedFields_shouldSkipConfiguredNestedFields() {
        Map<String, Object> left = Map.of(
                "payload", Map.of(
                        "usedCount", 1,
                        "lastUsedDateTime", "2025-01-01",
                        "realField", "A"
                )
        );
        Map<String, Object> right = Map.of(
                "payload", Map.of(
                        "usedCount", 99,
                        "lastUsedDateTime", "2026-01-01",
                        "realField", "A"
                )
        );

        List<String> changes = DeepDiffUtil.findChangedFields(left, right);

        assertTrue(changes.isEmpty());
    }

    @Test
    void findChangedFields_shouldRecordChange_whenOneFieldIsMissing() {
        Map<String, Object> left = Map.of("name", "ABC");
        Map<String, Object> right = Map.of();

        List<String> changes = DeepDiffUtil.findChangedFields(left, right);

        assertEquals(List.of("name"), changes);
    }

    @Test
    void findChangedFields_shouldRecordChange_whenNestedPrimitiveDiffers() {
        Map<String, Object> left = Map.of(
                "outer", Map.of("inner", "A")
        );
        Map<String, Object> right = Map.of(
                "outer", Map.of("inner", "B")
        );

        List<String> changes = DeepDiffUtil.findChangedFields(left, right);

        assertEquals(List.of("outer.inner"), changes);
    }

    @Test
    void findChangedFields_shouldRecordChange_whenNestedNodeTypesDiffer() {
        Map<String, Object> left = Map.of(
                "outer", Map.of("inner", "A")
        );
        Map<String, Object> right = Map.of(
                "outer", Map.of("inner", List.of("A"))
        );

        List<String> changes = DeepDiffUtil.findChangedFields(left, right);

        assertEquals(List.of("outer.inner"), changes);
    }

    @Test
    void findChangedFields_shouldRecordArrayPath_whenArraySizesDiffer() {
        Map<String, Object> left = Map.of("items", List.of(1, 2));
        Map<String, Object> right = Map.of("items", List.of(1));

        List<String> changes = DeepDiffUtil.findChangedFields(left, right);

        assertEquals(List.of("items"), changes);
    }

    @Test
    void findChangedFields_shouldRecordIndexedPath_whenArrayElementDiffers() {
        Map<String, Object> left = Map.of("items", List.of("A", "B"));
        Map<String, Object> right = Map.of("items", List.of("A", "C"));

        List<String> changes = DeepDiffUtil.findChangedFields(left, right);

        assertEquals(List.of("items[1]"), changes);
    }

    @Test
    void findChangedFields_shouldHandleNullArrayElementDifference() {
        Map<String, Object> left = Map.of("items", Arrays.asList("A", null));
        Map<String, Object> right = Map.of("items", Arrays.asList("A", "B"));

        List<String> changes = DeepDiffUtil.findChangedFields(left, right);

        assertEquals(List.of("items[1]"), changes);
    }

    @Test
    void collectFieldNames_shouldReturnUnionOfBothObjects() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod("collectFieldNames", JsonNode.class, JsonNode.class);
        method.setAccessible(true);

        ObjectNode left = MAPPER.createObjectNode();
        left.put("b", 1);
        left.put("a", 2);

        ObjectNode right = MAPPER.createObjectNode();
        right.put("c", 3);

        @SuppressWarnings("unchecked")
        Set<String> result = (Set<String>) method.invoke(null, left, right);

        assertEquals(Set.of("a", "b", "c"), result);
    }

    @Test
    void buildChildPath_shouldHandleRootAndNestedPaths() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod("buildChildPath", String.class, String.class);
        method.setAccessible(true);

        assertEquals("field", method.invoke(null, "", "field"));
        assertEquals("parent.field", method.invoke(null, "parent", "field"));
    }

    @Test
    void shouldSkipField_shouldReturnTrueForRootAndNestedSkipFields() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod("shouldSkipField", String.class, String.class);
        method.setAccessible(true);

        assertTrue((Boolean) method.invoke(null, "id", "id"));
        assertTrue((Boolean) method.invoke(null, "usedCount", "payload.usedCount"));
        assertFalse((Boolean) method.invoke(null, "name", "payload.name"));
    }

    @Test
    void getChildNode_shouldReturnExistingMissingAndNullSafely() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod("getChildNode", JsonNode.class, String.class);
        method.setAccessible(true);

        ObjectNode parent = MAPPER.createObjectNode();
        parent.put("name", "value");
        parent.set("nullField", NullNode.getInstance());

        JsonNode existing = (JsonNode) method.invoke(null, parent, "name");
        JsonNode missing = (JsonNode) method.invoke(null, parent, "absent");
        JsonNode nullField = (JsonNode) method.invoke(null, parent, "nullField");

        assertEquals("value", existing.asText());
        assertTrue(missing.isMissingNode());
        assertTrue(nullField.isNull());
    }

    @Test
    void shouldSkipEmptyArrayComparison_shouldCoverTrueAndFalseBranches() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod("shouldSkipEmptyArrayComparison", JsonNode.class, JsonNode.class);
        method.setAccessible(true);

        ArrayNode emptyArray = MAPPER.createArrayNode();
        JsonNode missing = MissingNode.getInstance();
        JsonNode value = MAPPER.readTree("\"x\"");

        assertTrue((Boolean) method.invoke(null, emptyArray, missing));
        assertTrue((Boolean) method.invoke(null, missing, emptyArray));
        assertFalse((Boolean) method.invoke(null, value, missing));
    }

    @Test
    void areBothMissing_shouldCoverTrueAndFalseBranches() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod("areBothMissing", JsonNode.class, JsonNode.class);
        method.setAccessible(true);

        assertTrue((Boolean) method.invoke(null, MissingNode.getInstance(), NullNode.getInstance()));
        assertFalse((Boolean) method.invoke(null, MissingNode.getInstance(), MAPPER.readTree("\"x\"")));
    }

    @Test
    void isOneMissing_shouldCoverTrueAndFalseBranches() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod("isOneMissing", JsonNode.class, JsonNode.class);
        method.setAccessible(true);

        assertTrue((Boolean) method.invoke(null, MissingNode.getInstance(), MAPPER.readTree("\"x\"")));
        assertFalse((Boolean) method.invoke(null, MissingNode.getInstance(), NullNode.getInstance()));
        assertFalse((Boolean) method.invoke(null, MAPPER.readTree("\"x\""), MAPPER.readTree("\"y\"")));
    }

    @Test
    void compareNodes_shouldCoverTypeObjectArrayPrimitiveAndEqualBranches() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod(
                "compareNodes", JsonNode.class, JsonNode.class, String.class, List.class);
        method.setAccessible(true);

        List<String> changes = new ArrayList<>();

        // type mismatch
        method.invoke(null, MAPPER.readTree("\"x\""), MAPPER.createArrayNode(), "typeMismatch", changes);

        // object branch with primitive diff inside
        method.invoke(
                null,
                MAPPER.readTree("{\"a\":1}"),
                MAPPER.readTree("{\"a\":2}"),
                "obj",
                changes
        );

        // array branch with element diff inside
        method.invoke(
                null,
                MAPPER.readTree("[1,2]"),
                MAPPER.readTree("[1,3]"),
                "arr",
                changes
        );

        // primitive diff
        method.invoke(null, MAPPER.readTree("\"A\""), MAPPER.readTree("\"B\""), "primitive", changes);

        // primitive equal - no new change
        int sizeBeforeEqual = changes.size();
        method.invoke(null, MAPPER.readTree("\"A\""), MAPPER.readTree("\"A\""), "equalPrimitive", changes);

        assertTrue(changes.contains("typeMismatch"));
        assertTrue(changes.contains("obj.a"));
        assertTrue(changes.contains("arr[1]"));
        assertTrue(changes.contains("primitive"));
        assertEquals(sizeBeforeEqual, changes.size());
    }

    @Test
    void diffArrays_shouldCoverNullInputsEarlyReturnSizeMismatchAndIteration() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod(
                "diffArrays", JsonNode.class, JsonNode.class, String.class, List.class);
        method.setAccessible(true);

        List<String> earlyReturnChanges = new ArrayList<>();
        method.invoke(null, MAPPER.createArrayNode(), MissingNode.getInstance(), "items", earlyReturnChanges);
        assertTrue(earlyReturnChanges.isEmpty());

        List<String> sizeMismatchChanges = new ArrayList<>();
        method.invoke(null, MAPPER.readTree("[1,2]"), MAPPER.readTree("[1]"), "items", sizeMismatchChanges);
        assertTrue(sizeMismatchChanges.contains("items"));

        List<String> nullSideChanges = new ArrayList<>();
        method.invoke(null, null, MAPPER.readTree("[1]"), "items", nullSideChanges);
        assertTrue(nullSideChanges.contains("items"));

        List<String> iterationChanges = new ArrayList<>();
        method.invoke(null, MAPPER.readTree("[1,2]"), MAPPER.readTree("[1,3]"), "items", iterationChanges);
        assertTrue(iterationChanges.contains("items[1]"));
    }

    @Test
    void recordChange_shouldHandleEmptyNullAndNormalPath() throws Exception {
        Method method = DeepDiffUtil.class.getDeclaredMethod("recordChange", String.class, List.class);
        method.setAccessible(true);

        List<String> changes = new ArrayList<>();
        method.invoke(null, "", changes);
        method.invoke(null, null, changes);
        method.invoke(null, "a.b", changes);

        assertEquals(List.of("$", "$", "a.b"), changes);
    }
}