package hireright.applications.igniting_innovations.repository;

import hireright.applications.igniting_innovations.document.IdeaSubmission;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;

/**
 * MongoDB repository interface for IdeaSubmission document.
 * Provides database operations for idea submissions.
 *
 * @author Generated
 * @version 1.0
 */
@Repository
public interface IdeaSubmissionRepository extends MongoRepository<IdeaSubmission, String> {


}

