package hireright.applications.permissions_api.api.db.management;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-17  HRG-330191 initial version
 */

import hireright.applications.permissions_api.api.db.management.factory.CCachingAddressFactory;
import hireright.applications.permissions_api.api.db.management.factory.CCachingModuleFactory;
import hireright.applications.permissions_api.api.db.management.factory.CCachingOperatorFactory;
import hireright.applications.permissions_api.api.management.IOperatorManager;
import hireright.applications.permissions_api.model.CCollection;
import hireright.applications.permissions_api.model.COperator;
import hireright.applications.permissions_api.model.COperatorFilter;
import hireright.applications.permissions_api.model.CSort;
import hireright.objects.address.CAddress;
import hireright.objects.permissions2.CModule;
import hireright.objects.permissions2.COperatorPermissionFactory;
import hireright.sdk.util.CStringUtils;
import org.hibernate.Session;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class CDbOperatorManager implements IOperatorManager
{
	public static final String OPERATOR_PROP_SOURCE_APPROVAL_TRUST_LEVEL =
		"VERIF_SOURCE_APPROVAL_TRUST_LEVEL";

	private static final Integer MAX_LIMIT = 1000;
	private final Session m_session;

	public CDbOperatorManager(Session session)
	{
		m_session = session;
	}

	private hireright.objects.users.COperator resolveOperator(String sReference)
	{
		if(CStringUtils.isEmpty(sReference))
		{
			return null;
		}

		hireright.objects.users.COperator source = null;
		if(CStringUtils.isNumber(sReference))
		{
			source = hireright.objects.users.COperator.get(Integer.parseInt(sReference));
		}

		if(source == null)
		{
			source = hireright.objects.users.COperator.get(sReference);
		}
		return source;
	}

	@Override
	public COperator get(String sReference)
	{
		return translate(resolveOperator(sReference));
	}

	@Override
	public CCollection<COperator> list(Long lOffset, Integer nLimit, CSort<COperator.EField> sort,
		COperatorFilter filter)
	{
		String sPermission = filter != null ? filter.getsPermission() : null;
		CModule module = CCachingModuleFactory.getModule(sPermission);

		if(module == null)
		{
			return CCollection.Builder.empty();
		}

		List<Integer> operatorIDs = new ArrayList<>(
			new COperatorPermissionFactory(m_session).getPermissionOperators(null, null,
				module.getModuleID()));

		if(lOffset == null)
		{
			lOffset = 0L;
		}

		if(nLimit == null)
		{
			nLimit = MAX_LIMIT;
		}

		nLimit = Math.min(nLimit, MAX_LIMIT);

		int nStartIndex = lOffset.intValue();
		int nEndIndex = nStartIndex + nLimit;

		nEndIndex = Math.min(nEndIndex, operatorIDs.size());

		operatorIDs = operatorIDs.subList(nStartIndex, nEndIndex);

		Collection<hireright.objects.users.COperator> sourceRecords =
			CCachingOperatorFactory.getOperators(operatorIDs);

		CCollection.Builder<COperator> target = new CCollection.Builder<>();
		target.offset(lOffset);
		target.limit(nLimit);
		target.total((long) operatorIDs.size());

		for(hireright.objects.users.COperator sourceRecord : sourceRecords)
		{
			target.item(translate(sourceRecord));
		}

		return target.build();
	}

	private COperator translate(hireright.objects.users.COperator source)
	{
		if(source == null)
		{
			return null;
		}

		COperator.Builder target = new COperator.Builder();
		target.username(source.getLogin());
		target.formattedName(source.getFormattedName());
		target.trustScore(source.getQcPercent());

		String sSvTrustLevel = source.getProperty(OPERATOR_PROP_SOURCE_APPROVAL_TRUST_LEVEL);
		if(CStringUtils.isNumber(sSvTrustLevel))
		{
			target.sourceVerificationTrustLevel(Integer.parseInt(sSvTrustLevel));
		}

		final CAddress address = CCachingAddressFactory.getAddress(source.getAddressID());
		if(address != null)
		{
			target.email(address.getEMail());
		}

		return target.build();
	}
}
