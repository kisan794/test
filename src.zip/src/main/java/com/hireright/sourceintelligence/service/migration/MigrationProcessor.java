package com.hireright.sourceintelligence.service.migration;

import com.hireright.sourceintelligence.api.dto.InstitutionRecord;

import java.util.List;
import java.util.Map;

/**
 * Strategy interface for processing different types of migration data.
 */
public interface MigrationProcessor {
    
    /**
     * Process institution records for a specific migration type.
     * 
     * @param records List of institution records to process
     * @return Map containing processing results (totalRecords, updatedRecords, notFoundRecords, etc.)
     */
    Map<String, Object> processInstitutionRecords(List<InstitutionRecord> records);
    
    /**
     * Get the migration type this processor handles.
     * 
     * @return Migration type identifier (e.g., "parchment" etc.)
     */
    String getMigrationType();
    
    /**
     * Validate if this processor can handle the given migration type.
     * 
     * @param migrationType The migration type to validate
     * @return true if this processor can handle the type, false otherwise
     */
    default boolean supports(String migrationType) {
        return getMigrationType().equalsIgnoreCase(migrationType);
    }
}

