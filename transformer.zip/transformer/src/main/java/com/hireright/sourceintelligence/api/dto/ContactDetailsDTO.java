package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ContactDetailsDTO {
    @JsonProperty("Type")
    private String type;
    @JsonProperty("Provider")
    private String provider;
    @JsonProperty("Code")
    private String code;
    @JsonProperty("Branch")
    private String branch;
    @JsonProperty("Number")
    private String number;
    @JsonProperty("Numbers")
    private List<String> numbers;
    @JsonProperty("Emails")
    private List<String> emails;
    @JsonProperty("Email")
    private String email;
    @JsonProperty("Mail_Address")
    private String mailAddress;
    @JsonProperty("Mail_Addresses")
    private List<String> mailAddresses;
    @JsonProperty("Surcharge")
    private String surcharge;
    @JsonProperty("Payment_Method")
    private String paymentMethod;
    @JsonProperty("Turn_Around_Time")
    private String turnAroundTime;
    @JsonProperty("Follow_Up_Allowed_After")
    private String followUpAllowedAfter;
    @JsonProperty("Website")
    private String website;
    @JsonProperty("Websites")
    private List<String> websites;

    @JsonIgnore
    public boolean isEmpty() {
        return (number == null && (numbers == null || numbers.isEmpty()))
                && email == null && mailAddresses== null && surcharge == null
                && paymentMethod == null && turnAroundTime == null && followUpAllowedAfter == null
                && website == null && code == null && provider == null && branch == null;
    }
}
