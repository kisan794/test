package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.Alias;
import com.hireright.sourceintelligence.api.dto.SourceDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SourceDTOMapperImplTest {

    private SourceDTOMapperImpl mapper;

    @BeforeEach
    void setUp() {
        mapper = new SourceDTOMapperImpl();
    }

    @Test
    void toSourceDTO_shouldReturnNull_whenSourceIsNull() {
        assertNull(mapper.toSourceDTO(null));
    }

    @Test
    void toSourceDTO_shouldMapAllFields_whenApprovalStatusAndLastApprovedDatePresent() {
        SourceOrganizationStatus status = SourceOrganizationStatus.values()[0];
        OrganizationType organizationType = OrganizationType.values()[0];
        ApprovalStatus approvalStatus = ApprovalStatus.values()[0];

        Alias alias1 = new Alias();
        alias1.setName("Alias One");
        Alias alias2 = new Alias();
        alias2.setName("Alias Two");

        BasicDBObject additionalInfoObj = new BasicDBObject();
        additionalInfoObj.put("verificationValidationProcess", "Process-A");
        additionalInfoObj.put("doNotContact", "true");
        additionalInfoObj.put("releaseType", "Manual");

        BasicDBList additionalInfo = new BasicDBList();
        additionalInfo.add(additionalInfoObj);

        BasicDBObject addressObj = new BasicDBObject();
        addressObj.put("line", "123 Main Street");
        addressObj.put("postalCode", "60601");

        BasicDBList address = new BasicDBList();
        address.add(addressObj);

        BasicDBObject payload = new BasicDBObject();
        payload.put("lastUsedDateTime", "2026-04-01T00:00:00Z");
        payload.put("lastCleanUpDate", "2026-04-02T00:00:00Z");
        payload.put("departmentName", "Admissions");
        payload.put("notes", "<b>Important</b>&nbsp;note");
        payload.put("usedCount", 7);
        payload.put("address", address);
        payload.put("addionalInfo", additionalInfo);
        payload.put("contacts", new BasicDBList());

        Instant lastApprovedDate = Instant.parse("2026-04-07T10:15:30Z");
        Instant lastModifiedDate = Instant.parse("2026-04-06T10:15:30Z");

        Source source = Source.builder()
                .id(new ObjectId("507f1f77bcf86cd799439011"))
                .organizationName("<b>Test University</b>")
                .hon("<i>HON123</i>")
                .country("<span>USA</span>")
                .state("<div>Illinois</div>")
                .postalCode("<p>60601</p>")
                .city("<em>Chicago</em>")
                .createdBy("<b>creator</b>")
                .flagPriority(Boolean.TRUE)
                .action("<span>CREATE</span>")
                .lastModifiedBy("<b>modifier</b>")
                .approvedBy("<b>approver</b>")
                .lastApprovedDate(lastApprovedDate)
                .organizationType(organizationType)
                .approvalStatus(approvalStatus)
                .assignedTo("assignee")
                .assignedId("assigned-id")
                .lastModifiedDate(lastModifiedDate)
                .outOfBusiness(Boolean.FALSE)
                .version(3.0)
                .tempVersion(4.0)
                .status(status)
                .organizationAlias(new Alias[]{alias1, alias2})
                .payload(payload)
                .build();

        SourceDTO result = mapper.toSourceDTO(source);

        assertNotNull(result);
        assertEquals("Test University", result.getOrganizationName());
        assertEquals("HON123", result.getHon());
        assertEquals("USA", result.getCountry());
        assertEquals("Illinois", result.getState());
        assertEquals("60601", result.getPostalCode());
        assertEquals("Chicago", result.getCity());
        assertEquals("Illinois", result.getRegion());
        assertEquals("creator", result.getCreatedBy());
        assertEquals(Boolean.TRUE, result.getFlagPriority());
        assertEquals("CREATE", result.getAction());
        assertEquals("modifier", result.getLastModifiedBy());
        assertEquals("approver", result.getApprovedBy());
        assertEquals(lastApprovedDate.toString(), result.getLastApprovedDateTime());
        assertEquals("507f1f77bcf86cd799439011", result.getId());
        assertEquals(organizationType, result.getOrganizationType());
        assertEquals(approvalStatus.name(), result.getApprovalStatus());
        assertEquals("assignee", result.getAssignedTo());
        assertEquals("assigned-id", result.getAssignedId());
        assertEquals(lastModifiedDate, result.getLastModifiedDate());
        assertEquals(Boolean.FALSE, result.getOutOfBusiness());
        assertEquals(3.0, result.getVersion());
        assertEquals(4.0, result.getTempVersion());
        assertEquals(String.valueOf(status), result.getStatus());

        assertEquals("Process-A", result.getVerificationValidationProcess());
        assertEquals("true", result.getDoNotContact());
        assertEquals("2026-04-01T00:00:00Z", result.getLastUsedDate());
        assertEquals("2026-04-02T00:00:00Z", result.getLastCleanUpDate());
        assertEquals("Manual", result.getReleaseType());
        assertEquals("Admissions", result.getDepartmentName());
        assertEquals("Important note", result.getNotes());
        assertEquals(7, result.getUsedCount());
        assertEquals("123 Main Street, <em>Chicago</em>, <div>Illinois</div>, 60601, <span>USA</span>", result.getAddress());
        assertEquals("Alias One; Alias Two", result.getOrganizationAlias());

        assertNotNull(result.getContactDetails());
        assertTrue(result.getContactDetails().isEmpty());
    }

    @Test
    void toSourceDTO_shouldSkipApprovalStatusAndLastApprovedDate_whenTheyAreNull() {
        SourceOrganizationStatus status = SourceOrganizationStatus.values()[0];
        OrganizationType organizationType = OrganizationType.values()[0];
        Instant lastModifiedDate = Instant.parse("2026-04-06T10:15:30Z");

        Source source = Source.builder()
                .id(new ObjectId("507f1f77bcf86cd799439012"))
                .organizationName("Org")
                .hon("HON999")
                .country("USA")
                .state("Texas")
                .postalCode("75001")
                .city("Dallas")
                .createdBy("creator2")
                .flagPriority(Boolean.FALSE)
                .action("UPDATE")
                .lastModifiedBy("modifier2")
                .approvedBy("approver2")
                .lastApprovedDate(null)
                .organizationType(organizationType)
                .approvalStatus(null)
                .assignedTo("user2")
                .assignedId("assigned-2")
                .lastModifiedDate(lastModifiedDate)
                .outOfBusiness(Boolean.TRUE)
                .version(1.0)
                .tempVersion(2.0)
                .status(status)
                .organizationAlias(null)
                .payload(null)
                .build();

        SourceDTO result = mapper.toSourceDTO(source);

        assertNotNull(result);
        assertNull(result.getLastApprovedDateTime());
        assertNull(result.getApprovalStatus());

        assertEquals("Org", result.getOrganizationName());
        assertEquals("HON999", result.getHon());
        assertEquals("USA", result.getCountry());
        assertEquals("Texas", result.getState());
        assertEquals("75001", result.getPostalCode());
        assertEquals("Dallas", result.getCity());
        assertEquals("Texas", result.getRegion());
        assertEquals("creator2", result.getCreatedBy());
        assertEquals(Boolean.FALSE, result.getFlagPriority());
        assertEquals("UPDATE", result.getAction());
        assertEquals("modifier2", result.getLastModifiedBy());
        assertEquals("approver2", result.getApprovedBy());
        assertEquals("507f1f77bcf86cd799439012", result.getId());
        assertEquals(organizationType, result.getOrganizationType());
        assertEquals("user2", result.getAssignedTo());
        assertEquals("assigned-2", result.getAssignedId());
        assertEquals(lastModifiedDate, result.getLastModifiedDate());
        assertEquals(Boolean.TRUE, result.getOutOfBusiness());
        assertEquals(1.0, result.getVersion());
        assertEquals(2.0, result.getTempVersion());
        assertEquals(String.valueOf(status), result.getStatus());

        assertEquals("", result.getVerificationValidationProcess());
        assertEquals("", result.getDoNotContact());
        assertEquals("", result.getLastUsedDate());
        assertEquals("", result.getLastCleanUpDate());
        assertEquals("", result.getReleaseType());
        assertEquals("", result.getDepartmentName());
        assertEquals("", result.getNotes());
        assertEquals("75001", result.getPostalCode());
        assertEquals("Dallas, Texas, USA", result.getAddress());
        assertNull(result.getOrganizationAlias());

        assertNotNull(result.getContactDetails());
        assertTrue(result.getContactDetails().isEmpty());
    }

    @Test
    void entityToSourceList_shouldReturnNull_whenSourceListIsNull() {
        assertNull(mapper.entityToSourceList(null));
    }

    @Test
    void entityToSourceList_shouldReturnEmptyList_whenSourceListIsEmpty() {
        List<SourceDTO> result = mapper.entityToSourceList(Collections.emptyList());

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void entityToSourceList_shouldMapAllItems_whenSourceListHasValues() {
        SourceOrganizationStatus status = SourceOrganizationStatus.values()[0];
        OrganizationType organizationType = OrganizationType.values()[0];

        Source first = Source.builder()
                .id(new ObjectId("507f1f77bcf86cd799439013"))
                .organizationName("Org1")
                .hon("HON1")
                .country("USA")
                .state("CA")
                .postalCode("90001")
                .city("LA")
                .createdBy("creator1")
                .action("CREATE")
                .lastModifiedBy("modifier1")
                .approvedBy("approver1")
                .organizationType(organizationType)
                .assignedTo("user1")
                .assignedId("id1")
                .outOfBusiness(Boolean.FALSE)
                .version(1.0)
                .tempVersion(1.1)
                .status(status)
                .build();

        Source second = Source.builder()
                .id(new ObjectId("507f1f77bcf86cd799439014"))
                .organizationName("Org2")
                .hon("HON2")
                .country("India")
                .state("KA")
                .postalCode("560001")
                .city("Bangalore")
                .createdBy("creator2")
                .action("UPDATE")
                .lastModifiedBy("modifier2")
                .approvedBy("approver2")
                .organizationType(organizationType)
                .assignedTo("user2")
                .assignedId("id2")
                .outOfBusiness(Boolean.TRUE)
                .version(2.0)
                .tempVersion(2.1)
                .status(status)
                .build();

        List<SourceDTO> result = mapper.entityToSourceList(Arrays.asList(first, second));

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Org1", result.get(0).getOrganizationName());
        assertEquals("HON1", result.get(0).getHon());
        assertEquals("Org2", result.get(1).getOrganizationName());
        assertEquals("HON2", result.get(1).getHon());
    }
}