package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.Alias;
import com.hireright.sourceintelligence.api.dto.CycleResult;
import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.api.dto.UIActionsDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.entity.UserCycle;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.domain.repository.UserCycleRepository;
import com.hireright.sourceintelligence.service.impl.MongoSourceService;
import com.hireright.sourceintelligence.service.impl.SearchConstants;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import com.hireright.sourceintelligence.service.impl.helperservices.CountryRegionMappingUtils;
import com.hireright.sourceintelligence.service.impl.helperservices.CreateSourceService;
import com.hireright.sourceintelligence.service.impl.helperservices.ReportDataUtils;
import com.hireright.sourceintelligence.service.impl.helperservices.SourceUtils;
import com.hireright.sourceintelligence.util.Helper;
import com.hireright.sourceintelligence.util.HonGenerator;
import com.hireright.sourceintelligence.util.LoggingThrowable;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.USED_COUNT;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.constants.ErrorConstants.*;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.ReportActions.AUTO_APPROVED;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
class CreateSourceServiceTest {

    @InjectMocks
    private CreateSourceService createSourceService;

    @Mock
    private SourceMapper sourceMapper;
    @Mock
    private UserCycleRepository userCycleRepository;
    @Mock
    private MongoSourceService mongoSourceService;
    @Mock
    private ReportDataUtils reportDataUtils;
    @Mock
    private CountryRegionMappingUtils countryRegionMappingUtils;
    @Mock
    private ElasticsearchService elasticsearchService;
    @Mock
    private SourceUtils sourceUtils;
    private SourceOrganizationDTO sourceOrganizationDTO;
    private UIActionsDTO uiActionsDTO;
    private Source source;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(createSourceService, "shardLocation", "US");

        sourceOrganizationDTO = new SourceOrganizationDTO();
        sourceOrganizationDTO.setOrganizationType(OrganizationType.EDUCATION);
        sourceOrganizationDTO.setOrganizationName("TestOrg");
        sourceOrganizationDTO.setCountry("USA");
        sourceOrganizationDTO.setOrganizationAlias(new Alias[]{});

        uiActionsDTO = new UIActionsDTO();
        uiActionsDTO.setUserAction(ACTION_SAVE);
        uiActionsDTO.setUserName("testUser");
        uiActionsDTO.setUserEmail("test@user.com");
        uiActionsDTO.setUserTrustScore(100);

        source = new Source();
        source.setOrganizationName("TestOrg");
        source.setOrganizationType(OrganizationType.EDUCATION);
        source.setPayload(new BasicDBObject());
    }

    @Test
    void createSource_shouldCreateApprovedSource_andSaveCycle_andCreateEs() throws Exception {
        UserCycle cycle = new UserCycle();

        when(sourceMapper.dtoToEntitySource(sourceOrganizationDTO)).thenReturn(source);
        when(countryRegionMappingUtils.getRegionByCountry("USA")).thenReturn("US");
        when(sourceUtils.checkForAutoApproval(100, "US", "test@user.com"))
                .thenReturn(new CycleResult(AUTO_APPOVED, cycle));
        when(mongoSourceService.isHonExists("EDU_001")).thenReturn(false);
        when(mongoSourceService.getPossibleDuplicateSources(sourceOrganizationDTO)).thenReturn(null);
        when(mongoSourceService.insert(any(Source.class), eq("education_source"))).thenAnswer(inv -> inv.getArgument(0));
        when(sourceMapper.entitySourceToDTO(any(Source.class))).thenReturn(sourceOrganizationDTO);

        try (MockedStatic<HonGenerator> honMock = mockStatic(HonGenerator.class);
             MockedStatic<Helper> helperMock = mockStatic(Helper.class, CALLS_REAL_METHODS)) {

            honMock.when(() -> HonGenerator.createHon(OrganizationType.EDUCATION)).thenReturn("EDU_001");
            helperMock.when(() -> Helper.getCollectionName("EDUCATION", SOURCE_COLLECTION_SUFFIX))
                    .thenReturn("education_source");
            helperMock.when(() -> Helper.fromAction(ACTION_SAVE_AND_USE)).thenReturn(PENDING_APPROVAL);
            helperMock.when(() -> Helper.fromAction(ACTION_SAVE)).thenReturn(PENDING_APPROVAL);

            SourceOrganizationDTO result = createSourceService.createSource(sourceOrganizationDTO, uiActionsDTO);

            assertNotNull(result);

            ArgumentCaptor<Source> captor = ArgumentCaptor.forClass(Source.class);
            verify(mongoSourceService).insert(captor.capture(), eq("education_source"));
            Source inserted = captor.getValue();

            assertEquals("EDU_001", inserted.getHon());
            assertEquals(APPROVED, inserted.getApprovalStatus());
            assertEquals(SourceOrganizationStatus.ACTIVE, inserted.getStatus());
            assertEquals(1.0, inserted.getVersion());
            assertEquals(0.0, inserted.getTempVersion());
            assertEquals("testUser", inserted.getApprovedBy());
            assertEquals("test@user.com", inserted.getApproverId());
            assertEquals("testUser", inserted.getAssignedTo());
            assertEquals("test@user.com", inserted.getAssignedId());
            assertEquals(CREATE, inserted.getAction());
            assertEquals("testorg", inserted.getSearchOrg());
            assertEquals(SearchConstants.LogFlagConstants.NEW_RECORD, inserted.getLogFlag());
            assertEquals(Boolean.FALSE, inserted.getFlagPriority());
            assertNotNull(inserted.getCreatedDate());
            assertNotNull(inserted.getLastModifiedDate());
            assertNotNull(inserted.getLastApprovedDate());
            assertNotNull(inserted.getLastActionDate());
            assertNull(inserted.getPayload().get(USED_COUNT));

            verify(mongoSourceService).insertSourceHistory(inserted);
            verify(userCycleRepository).save(cycle);
            verify(elasticsearchService).createSource(inserted);
            verify(reportDataUtils).reportData(
                    inserted,
                    CREATE,
                    SIDB_APPROVAL_FLOW,
                    0,
                    AUTO_APPROVED,
                    1.0,
                    0.0,
                    APPROVAL_FLOW
            );
        }
    }

    @Test
    void createSource_shouldCreateManualSource_whenCycleIsManual() throws Exception {
        when(sourceMapper.dtoToEntitySource(sourceOrganizationDTO)).thenReturn(source);
        when(countryRegionMappingUtils.getRegionByCountry("USA")).thenReturn("US");
        when(sourceUtils.checkForAutoApproval(100, "US", "test@user.com"))
                .thenReturn(new CycleResult("MANUAL_REVIEW", null));
        when(mongoSourceService.isHonExists("EDU_002")).thenReturn(false);
        when(mongoSourceService.getPossibleDuplicateSources(sourceOrganizationDTO)).thenReturn(null);
        when(mongoSourceService.insert(any(Source.class), eq("education_source"))).thenAnswer(inv -> inv.getArgument(0));
        when(sourceMapper.entitySourceToDTO(any(Source.class))).thenReturn(sourceOrganizationDTO);

        try (MockedStatic<HonGenerator> honMock = mockStatic(HonGenerator.class);
             MockedStatic<Helper> helperMock = mockStatic(Helper.class, CALLS_REAL_METHODS)) {

            honMock.when(() -> HonGenerator.createHon(OrganizationType.EDUCATION)).thenReturn("EDU_002");
            helperMock.when(() -> Helper.getCollectionName("EDUCATION", SOURCE_COLLECTION_SUFFIX))
                    .thenReturn("education_source");
            helperMock.when(() -> Helper.fromAction(ACTION_SAVE)).thenReturn(PENDING_APPROVAL);

            createSourceService.createSource(sourceOrganizationDTO, uiActionsDTO);

            ArgumentCaptor<Source> captor = ArgumentCaptor.forClass(Source.class);
            verify(mongoSourceService).insert(captor.capture(), eq("education_source"));
            Source inserted = captor.getValue();

            assertEquals(PENDING_APPROVAL, inserted.getApprovalStatus());
            assertEquals(SourceOrganizationStatus.INACTIVE, inserted.getStatus());
            assertEquals(0.0, inserted.getVersion());
            assertEquals(1.0, inserted.getTempVersion());
            assertEquals(UNASSIGNED, inserted.getAssignedTo());
            assertEquals(UNASSIGNED, inserted.getAssignedId());

            verify(userCycleRepository, never()).save(any());
            verify(elasticsearchService, never()).createSource(any());
            verify(reportDataUtils).reportData(
                    inserted,
                    CREATE,
                    SIDB_APPROVAL_FLOW,
                    0,
                    MANUAL_PROCESS,
                    0.0,
                    1.0,
                    APPROVAL_FLOW
            );
        }
    }

    @Test
    void createSource_shouldCreateManualSource_whenApprovalStatusIsSavePendingApproval() throws Exception {
        uiActionsDTO.setUserAction(ACTION_SAVE_AND_USE);

        when(sourceMapper.dtoToEntitySource(sourceOrganizationDTO)).thenReturn(source);
        when(countryRegionMappingUtils.getRegionByCountry("USA")).thenReturn("US");
        when(sourceUtils.checkForAutoApproval(100, "US", "test@user.com"))
                .thenReturn(new CycleResult("MANUAL_REVIEW", null));
        when(mongoSourceService.isHonExists("EDU_003")).thenReturn(false);
        when(mongoSourceService.getPossibleDuplicateSources(sourceOrganizationDTO)).thenReturn(null);
        when(mongoSourceService.insert(any(Source.class), eq("education_source"))).thenAnswer(inv -> inv.getArgument(0));
        when(sourceMapper.entitySourceToDTO(any(Source.class))).thenReturn(sourceOrganizationDTO);

        try (MockedStatic<HonGenerator> honMock = mockStatic(HonGenerator.class);
             MockedStatic<Helper> helperMock = mockStatic(Helper.class, CALLS_REAL_METHODS)) {

            honMock.when(() -> HonGenerator.createHon(OrganizationType.EDUCATION)).thenReturn("EDU_003");
            helperMock.when(() -> Helper.getCollectionName("EDUCATION", SOURCE_COLLECTION_SUFFIX))
                    .thenReturn("education_source");
            helperMock.when(() -> Helper.fromAction(ACTION_SAVE_AND_USE)).thenReturn(SAVE_PENDING_APPROVAL);

            createSourceService.createSource(sourceOrganizationDTO, uiActionsDTO);

            ArgumentCaptor<Source> captor = ArgumentCaptor.forClass(Source.class);
            verify(mongoSourceService).insert(captor.capture(), eq("education_source"));
            Source inserted = captor.getValue();

            assertEquals(SAVE_PENDING_APPROVAL, inserted.getApprovalStatus());
            assertEquals(0.0, inserted.getVersion());
            assertEquals(1.0, inserted.getTempVersion());
            verify(reportDataUtils).reportData(
                    inserted,
                    CREATE,
                    SIDB_APPROVAL_FLOW,
                    0,
                    MANUAL_PROCESS,
                    0.0,
                    1.0,
                    APPROVAL_FLOW
            );
        }
    }

    @Test
    void createSource_shouldClearSingleEmptyAlias_andAllowAutoApproval() throws Exception {
        Alias alias = new Alias();
        alias.setName("");
        sourceOrganizationDTO.setOrganizationAlias(new Alias[]{alias});

        when(sourceMapper.dtoToEntitySource(sourceOrganizationDTO)).thenReturn(source);
        when(countryRegionMappingUtils.getRegionByCountry("USA")).thenReturn("US");
        when(sourceUtils.checkForAutoApproval(100, "US", "test@user.com"))
                .thenReturn(new CycleResult(AUTO_APPOVED, null));
        when(mongoSourceService.isHonExists("EDU_004")).thenReturn(false);
        when(mongoSourceService.getPossibleDuplicateSources(sourceOrganizationDTO)).thenReturn(null);
        when(mongoSourceService.insert(any(Source.class), eq("education_source"))).thenAnswer(inv -> inv.getArgument(0));
        when(sourceMapper.entitySourceToDTO(any(Source.class))).thenReturn(sourceOrganizationDTO);

        try (MockedStatic<HonGenerator> honMock = mockStatic(HonGenerator.class);
             MockedStatic<Helper> helperMock = mockStatic(Helper.class, CALLS_REAL_METHODS)) {

            honMock.when(() -> HonGenerator.createHon(OrganizationType.EDUCATION)).thenReturn("EDU_004");
            helperMock.when(() -> Helper.getCollectionName("EDUCATION", SOURCE_COLLECTION_SUFFIX))
                    .thenReturn("education_source");
            helperMock.when(() -> Helper.fromAction(ACTION_SAVE)).thenReturn(PENDING_APPROVAL);

            createSourceService.createSource(sourceOrganizationDTO, uiActionsDTO);

            assertEquals(0, sourceOrganizationDTO.getOrganizationAlias().length);

            ArgumentCaptor<Source> captor = ArgumentCaptor.forClass(Source.class);
            verify(mongoSourceService).insert(captor.capture(), eq("education_source"));
            assertEquals(APPROVED, captor.getValue().getApprovalStatus());
        }
    }

    @Test
    void createSource_shouldNotAutoApprove_whenAliasExists() throws Exception {
        Alias alias = new Alias();
        alias.setName("Alias 1");
        sourceOrganizationDTO.setOrganizationAlias(new Alias[]{alias});

        when(sourceMapper.dtoToEntitySource(sourceOrganizationDTO)).thenReturn(source);
        when(countryRegionMappingUtils.getRegionByCountry("USA")).thenReturn("US");
        when(sourceUtils.checkForAutoApproval(100, "US", "test@user.com"))
                .thenReturn(new CycleResult(AUTO_APPOVED, new UserCycle()));
        when(mongoSourceService.isHonExists("EDU_005")).thenReturn(false);
        when(mongoSourceService.getPossibleDuplicateSources(sourceOrganizationDTO)).thenReturn(null);
        when(mongoSourceService.insert(any(Source.class), eq("education_source"))).thenAnswer(inv -> inv.getArgument(0));
        when(sourceMapper.entitySourceToDTO(any(Source.class))).thenReturn(sourceOrganizationDTO);

        try (MockedStatic<HonGenerator> honMock = mockStatic(HonGenerator.class);
             MockedStatic<Helper> helperMock = mockStatic(Helper.class, CALLS_REAL_METHODS)) {

            honMock.when(() -> HonGenerator.createHon(OrganizationType.EDUCATION)).thenReturn("EDU_005");
            helperMock.when(() -> Helper.getCollectionName("EDUCATION", SOURCE_COLLECTION_SUFFIX))
                    .thenReturn("education_source");
            helperMock.when(() -> Helper.fromAction(ACTION_SAVE)).thenReturn(PENDING_APPROVAL);

            createSourceService.createSource(sourceOrganizationDTO, uiActionsDTO);

            ArgumentCaptor<Source> captor = ArgumentCaptor.forClass(Source.class);
            verify(mongoSourceService).insert(captor.capture(), eq("education_source"));
            Source inserted = captor.getValue();

            assertEquals(PENDING_APPROVAL, inserted.getApprovalStatus());
            assertEquals(0.0, inserted.getVersion());
            assertEquals(1.0, inserted.getTempVersion());

            verify(userCycleRepository, never()).save(any());
            verify(elasticsearchService, never()).createSource(any());
        }
    }

    @Test
    void createSource_shouldNotSaveUserCycle_whenInsertReturnsNull() throws Exception {
        when(sourceMapper.dtoToEntitySource(sourceOrganizationDTO)).thenReturn(source);
        when(countryRegionMappingUtils.getRegionByCountry("USA")).thenReturn("US");
        when(sourceUtils.checkForAutoApproval(100, "US", "test@user.com"))
                .thenReturn(new CycleResult(AUTO_APPOVED, new UserCycle()));
        when(mongoSourceService.isHonExists("EDU_006")).thenReturn(false);
        when(mongoSourceService.getPossibleDuplicateSources(sourceOrganizationDTO)).thenReturn(null);
        when(mongoSourceService.insert(any(Source.class), eq("education_source"))).thenReturn(null);
        when(sourceMapper.entitySourceToDTO(null)).thenReturn(null);

        try (MockedStatic<HonGenerator> honMock = mockStatic(HonGenerator.class);
             MockedStatic<Helper> helperMock = mockStatic(Helper.class, CALLS_REAL_METHODS)) {

            honMock.when(() -> HonGenerator.createHon(OrganizationType.EDUCATION)).thenReturn("EDU_006");
            helperMock.when(() -> Helper.getCollectionName("EDUCATION", SOURCE_COLLECTION_SUFFIX))
                    .thenReturn("education_source");
            helperMock.when(() -> Helper.fromAction(ACTION_SAVE)).thenReturn(PENDING_APPROVAL);

            SourceOrganizationDTO result = createSourceService.createSource(sourceOrganizationDTO, uiActionsDTO);

            assertNull(result);
            verify(userCycleRepository, never()).save(any());
            verify(elasticsearchService, never()).createSource(any());
            verify(mongoSourceService).insertSourceHistory(any(Source.class));
        }
    }

    @Test
    void createSource_shouldNotThrow_whenDuplicateHonMatchesGeneratedHon() throws Exception {
        SourceOrganizationDTO duplicateDTO = new SourceOrganizationDTO();
        duplicateDTO.setHon("EDU_007");

        when(sourceMapper.dtoToEntitySource(sourceOrganizationDTO)).thenReturn(source);
        when(countryRegionMappingUtils.getRegionByCountry("USA")).thenReturn("US");
        when(sourceUtils.checkForAutoApproval(100, "US", "test@user.com"))
                .thenReturn(new CycleResult("MANUAL_REVIEW", null));
        when(mongoSourceService.isHonExists("EDU_007")).thenReturn(false);
        when(mongoSourceService.getPossibleDuplicateSources(sourceOrganizationDTO)).thenReturn(duplicateDTO);
        when(mongoSourceService.insert(any(Source.class), eq("education_source"))).thenAnswer(inv -> inv.getArgument(0));
        when(sourceMapper.entitySourceToDTO(any(Source.class))).thenReturn(sourceOrganizationDTO);

        try (MockedStatic<HonGenerator> honMock = mockStatic(HonGenerator.class);
             MockedStatic<Helper> helperMock = mockStatic(Helper.class, CALLS_REAL_METHODS)) {

            honMock.when(() -> HonGenerator.createHon(OrganizationType.EDUCATION)).thenReturn("EDU_007");
            helperMock.when(() -> Helper.getCollectionName("EDUCATION", SOURCE_COLLECTION_SUFFIX))
                    .thenReturn("education_source");
            helperMock.when(() -> Helper.fromAction(ACTION_SAVE)).thenReturn(PENDING_APPROVAL);

            assertDoesNotThrow(() -> createSourceService.createSource(sourceOrganizationDTO, uiActionsDTO));
        }
    }

    @Test
    void createSource_shouldThrowWhenHonIsEmpty() {
        when(sourceMapper.dtoToEntitySource(sourceOrganizationDTO)).thenReturn(source);

        try (MockedStatic<HonGenerator> honMock = mockStatic(HonGenerator.class);
             MockedStatic<LoggingThrowable> loggingMock = mockStatic(LoggingThrowable.class)) {

            honMock.when(() -> HonGenerator.createHon(OrganizationType.EDUCATION)).thenReturn("");

            loggingMock.when(() -> LoggingThrowable.logAndThrowInternalServiceException(FAILED_TO_CREATE_HON, null))
                    .thenThrow(new RuntimeException("FAILED_TO_CREATE_HON"));

            RuntimeException exception = assertThrows(
                    RuntimeException.class,
                    () -> createSourceService.createSource(sourceOrganizationDTO, uiActionsDTO)
            );

            assertEquals("FAILED_TO_CREATE_HON", exception.getMessage());
        }
    }

    @Test
    void createSource_shouldThrowWhenHonAlreadyExists() {
        when(sourceMapper.dtoToEntitySource(sourceOrganizationDTO)).thenReturn(source);

        try (MockedStatic<HonGenerator> honMock = mockStatic(HonGenerator.class);
             MockedStatic<Helper> helperMock = mockStatic(Helper.class, CALLS_REAL_METHODS);
             MockedStatic<LoggingThrowable> loggingMock = mockStatic(LoggingThrowable.class)) {

            honMock.when(() -> HonGenerator.createHon(OrganizationType.EDUCATION)).thenReturn("EDU_008");
            helperMock.when(() -> Helper.getCollectionName("EDUCATION", SOURCE_COLLECTION_SUFFIX))
                    .thenReturn("education_source");
            when(mongoSourceService.isHonExists("EDU_008")).thenReturn(true);

            loggingMock.when(() -> LoggingThrowable.logAndThrowAlreadyExistsException(
                    HON_ALREADY_EXISTS, null, "EDU_008"
            )).thenThrow(new RuntimeException("HON_ALREADY_EXISTS"));

            RuntimeException exception = assertThrows(
                    RuntimeException.class,
                    () -> createSourceService.createSource(sourceOrganizationDTO, uiActionsDTO)
            );

            assertEquals("HON_ALREADY_EXISTS", exception.getMessage());
        }
    }

    @Test
    void createSource_shouldThrowWhenDuplicateSourceExistsWithDifferentHon() {
        SourceOrganizationDTO duplicateDTO = new SourceOrganizationDTO();
        duplicateDTO.setHon("EDU_DUP");

        when(sourceMapper.dtoToEntitySource(sourceOrganizationDTO)).thenReturn(source);
        when(mongoSourceService.isHonExists("EDU_009")).thenReturn(false);
        when(mongoSourceService.getPossibleDuplicateSources(sourceOrganizationDTO)).thenReturn(duplicateDTO);

        try (MockedStatic<HonGenerator> honMock = mockStatic(HonGenerator.class);
             MockedStatic<Helper> helperMock = mockStatic(Helper.class, CALLS_REAL_METHODS);
             MockedStatic<LoggingThrowable> loggingMock = mockStatic(LoggingThrowable.class)) {

            honMock.when(() -> HonGenerator.createHon(OrganizationType.EDUCATION)).thenReturn("EDU_009");
            helperMock.when(() -> Helper.getCollectionName("EDUCATION", SOURCE_COLLECTION_SUFFIX))
                    .thenReturn("education_source");

            loggingMock.when(() -> LoggingThrowable.logAndThrowAlreadyExistsException(
                    SOURCE_ALREADY_EXISTS, null, "EDU_DUP"
            )).thenThrow(new RuntimeException("SOURCE_ALREADY_EXISTS"));

            RuntimeException exception = assertThrows(
                    RuntimeException.class,
                    () -> createSourceService.createSource(sourceOrganizationDTO, uiActionsDTO)
            );

            assertEquals("SOURCE_ALREADY_EXISTS", exception.getMessage());
        }
    }
}