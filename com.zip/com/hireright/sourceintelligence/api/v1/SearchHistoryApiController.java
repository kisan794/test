package com.hireright.sourceintelligence.api.v1;

import static com.hireright.sourceintelligence.api.ApiConstants.ResponseHeaders.X_SOURCE_INTELLIGENCE_TOTAL_COUNT;
import static com.hireright.sourceintelligence.constants.ErrorConstants.*;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowInvalidRequest;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.dto.history.ChangeLogFilters;
import com.hireright.sourceintelligence.service.CommonUtilService;
import com.hireright.sourceintelligence.service.SearchHistoryService;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@Validated
@Slf4j
@CrossOrigin
public class SearchHistoryApiController implements SearchHistoryApi {

    private final SearchHistoryService searchHistoryService;
    private final CommonUtilService commonUtilService;

    @Override
    public ResponseEntity<SearchResponseDTO> changeLogsByFilters(ChangeLogFilters changeLogFilters) {

        SearchResponseDTO result = searchHistoryService.getChangeLogsByFilters(changeLogFilters);

        var responseHeaders = new HttpHeaders();
        responseHeaders.set(X_SOURCE_INTELLIGENCE_TOTAL_COUNT, Long.toString(result.getTotalItems()));
        return new ResponseEntity<>(result, responseHeaders, HttpStatus.OK);
    }

}
