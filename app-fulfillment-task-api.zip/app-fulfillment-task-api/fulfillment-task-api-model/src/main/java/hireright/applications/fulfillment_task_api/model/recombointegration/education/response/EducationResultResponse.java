package hireright.applications.fulfillment_task_api.model.recombointegration.education.response;

import hireright.applications.fulfillment_task_api.model.recombointegration.constant.CloudEventsConstants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.Instant;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Slf4j
public class EducationResultResponse {
    private String specversion;

    private String id;

    private String source;

    private String type;

    private String datacontenttype;

    private String time;

    private AcceptedData data;

    /**
     * Create a success response for accepted task result.
     *
     * @param requestId The task identifier
     * @param requestId The original request identifier (currently unused, reserved for future use)
     * @return TaskResultResponse configured for successful acceptance
     * @throws IllegalArgumentException if requestId is null or empty
     */
    public static EducationResultResponse accepted(String requestId) {
        if (requestId == null || requestId.trim().isEmpty()) {
            log.error("Task ID cannot be null or empty");
            throw new IllegalArgumentException("Task ID cannot be null or empty");
        }

        Instant now = Instant.now();
        String responseId = UUID.randomUUID().toString();

        log.debug("Creating task accepted response - TaskId: {}, ResponseId: {}", requestId, responseId);

        AcceptedData acceptedData = AcceptedData.builder()
                .id(requestId)
                .status(CloudEventsConstants.STATUS_COMPLETED)
                .submittedAt(now.toString())
                .message(CloudEventsConstants.MSG_RECEIVED)
                .build();

        return EducationResultResponse.builder()
                .specversion(CloudEventsConstants.CLOUDEVENTS_VERSION)
                .id(responseId)
                .source(CloudEventsConstants.SOURCE_FULFILLMENT_API)
                .type(CloudEventsConstants.TYPE_TASK_ACCEPTED)
                .datacontenttype(CloudEventsConstants.CONTENT_TYPE_JSON)
                .time(now.toString())
                .data(acceptedData)
                .build();
    }
}
