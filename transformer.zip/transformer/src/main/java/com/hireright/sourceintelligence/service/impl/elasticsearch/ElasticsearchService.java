package com.hireright.sourceintelligence.service.impl.elasticsearch;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch._types.query_dsl.Query;
import co.elastic.clients.elasticsearch.core.GetResponse;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch.core.search.Hit;
import com.hireright.sourceintelligence.api.dto.AutoMatchDTO;
import com.hireright.sourceintelligence.api.dto.ElasticsearchDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.searchindex.entity.ElasticsearchSource;
import com.hireright.sourceintelligence.service.impl.DistanceAlgorithm;
import com.hireright.sourceintelligence.util.Helper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.*;

import static com.hireright.sourceintelligence.service.impl.SearchConstants.SUGGESTIONS;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchScore.*;
import static com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchConstants.SearchFields.*;
import static com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchConstants.SearchFields.STATUS;


@Slf4j
@AllArgsConstructor
@Service
public class ElasticsearchService {

    private ElasticsearchMapper elasticsearchMapper;

    private ElasticsearchClient elasticsearchClient;

    private DistanceAlgorithm distanceAlgorithm;


    public void createSource(Source source) throws IOException {
        ElasticsearchSource searchSource = elasticsearchMapper.sourceToSearchSourceMapping(source);
        if (!ObjectUtils.isEmpty(searchSource)) {
            String indexName = Helper.getIndexName(source.getOrganizationType().getType());
            if (indexExists(indexName)) {
                addSource(searchSource, indexName);
            } else {
                throw new IOException("Elastic Index does not exists: " + indexName, null);
            }
        }
    }

    public void updateSourceIndex(Source source) throws IOException, IllegalAccessException {
        ElasticsearchSource searchSource = elasticsearchMapper.sourceToSearchSourceMapping(source);
        if (!ObjectUtils.isEmpty(searchSource)) {
            log.info("update es source: {}", searchSource);
            String indexName = Helper.getIndexName(source.getOrganizationType().getType());
            GetResponse<ElasticsearchSource> getResponse = getSourceById(indexName, searchSource.getHon());
            if (getResponse != null && !getResponse.id().isEmpty()) {
                Map<String, Object> updateFields = getUpdatedFields(searchSource, getResponse.source());
                updateFields.put(STATUS,SourceOrganizationStatus.ACTIVE.getStatus());
                updateSourcePartial(indexName, getResponse.id(), updateFields);
            } else {
                addSource(searchSource, indexName);
            }
        }
    }

    public void updateStatusForSourceIndex(Source source, String status, String approvalStatus) throws IOException {
        Map<String, Object> updatedFields = new HashMap<>();
        updatedFields.put(STATUS, status);
        updatedFields.put(APPROVAL_STATUS, approvalStatus);
        String indexName = Helper.getIndexName(source.getOrganizationType().getType());
        var searchResponse = getSourceById(indexName, source.getHon());
        if (searchResponse != null && !searchResponse.id().isEmpty()) {
            updateSourcePartial(indexName, searchResponse.id(), updatedFields);
        } else {
            ElasticsearchSource searchSource = elasticsearchMapper.sourceToSearchSourceMapping(source);
            if (!ObjectUtils.isEmpty(searchSource) && indexExists(indexName)) {
                searchSource.setStatus(status);
                searchSource.setApprovalStatus(approvalStatus);
                addSource(searchSource, indexName);
            }
        }
    }

    public boolean indexExists(String indexName) throws IOException {
        return elasticsearchClient.indices().exists(e -> e.index(indexName)).value();
    }

    public void addSource(ElasticsearchSource sourceDoc, String indexName) throws IOException {
        elasticsearchClient.create(c -> c
                .index(indexName)
                .id(sourceDoc.getHon())
                .document(sourceDoc)
        );
        log.info("Source indexed successfully.");
    }

    public void updateSourcePartial(String indexName, String docId, Map<String, Object> updatedFields) throws IOException {
        log.info("update source partial index starts");
        elasticsearchClient.update(u -> u
                        .index(indexName)
                        .id(docId)
                        .doc(updatedFields), // Only updates these fields
                ElasticsearchSource.class
        );
        log.info("updated source partial index successfully.");
        log.info("update source partial index ends");
    }


    public void deleteSourceByHon(String hon) throws IOException {
        String indexName = Helper.getIndexName(Helper.getOrganizationType(hon));
        deleteSource(hon, indexName);
    }

    public void deleteSource(String hon, String indexName) throws IOException {
        elasticsearchClient.delete(c -> c
                .index(indexName)
                .id(hon)
        );
        log.info("Source deleted successfully.");
    }


    public GetResponse<ElasticsearchSource> getSourceById(String indexName, String docId) throws IOException {
        return elasticsearchClient.get(g -> g
                        .index(indexName)
                        .id(docId),
                ElasticsearchSource.class
        );
    }
    public SearchResponse<ElasticsearchSource> getSourceByHon(String indexName, String hon) {
        try {
            return elasticsearchClient.search(s -> s
                            .index(indexName)
                            .query(q -> q
                                    .term(t -> t
                                            .field(HON)
                                            .value(hon)
                                    )
                            ),
                    ElasticsearchSource.class
            );
        } catch (IOException e) {
            log.error("get source from index failed.");
            return null;
        }
    }

    public Set<String> smartSearch(ElasticsearchDTO elasticsearchDTO, String indexName, Boolean isDropDownSelected) {
        Query boolQuery = ElasticsearchQueryBuilder.smartSearchQuery(elasticsearchDTO, isDropDownSelected);
        double minScore = calculateMinScore(elasticsearchDTO, isDropDownSelected);

        var response = searchWithProject(boolQuery, indexName, SMART_SEARCH_LIMIT, minScore, HON, ORG_NAME, ORG_ALIAS);
        if (response == null || response.hits().hits().isEmpty()) {
            return Collections.emptySet();
        }

        List<Hit<ElasticsearchSource>> hits = response.hits().hits();
        String orgName = elasticsearchDTO.getOrganizationName();

        if (orgName == null) {
            return smartSearchLogicForDropDown(hits);
        }

        if (Boolean.TRUE.equals(isDropDownSelected)) {
            return smartSearchLogicForDropDown(hits);
        }

        return handleTextBoxSearch(hits, orgName);
    }

    private double calculateMinScore(ElasticsearchDTO dto, Boolean isDropDownSelected) {
        if (Boolean.FALSE.equals(isDropDownSelected) && dto.getOrganizationName() != null) {
            return TEXT_BOX_SEARCH_MIN_SCORE;
        }
        return SEARCH_MIN_SCORE;
    }

    private Set<String> handleTextBoxSearch(List<Hit<ElasticsearchSource>> hits, String orgName) {
        if (hits.isEmpty()) {
            return Collections.emptySet();
        }

        if (hits.get(0).score() != null && hits.get(0).score() >= 300) {
            return smartSearchLogicForTextBoxExact(hits, orgName);
        } else {
            return smartSearchLogicForTextBoxWithJaro(hits, orgName.toLowerCase(), SUGGESTIONS);
        }
    }


    public List<ElasticsearchSource> dropDownSearch(ElasticsearchDTO elasticsearchDTO, String indexName) {
        Query boolQuery = ElasticsearchQueryBuilder.dropDownSearchQuery(elasticsearchDTO);
        SearchResponse<ElasticsearchSource> response = searchWithProject(boolQuery, indexName, DROP_DOWN_LIMIT,DROP_DOWN_MIN_SCORE,  HON, ORG_NAME, ORG_ALIAS);
        List<ElasticsearchSource> esResults = new ArrayList<>();
        if(response != null){
            for (Hit<ElasticsearchSource> elasticsearchSourceHit : response.hits().hits()) {
                ElasticsearchSource source = elasticsearchSourceHit.source();
                esResults.add(source);
            }
        }
        if(esResults.isEmpty()) {
            return Collections.emptyList();
        }
        return esResults;
    }

    public List<ElasticsearchSource> autoMatchSearch(AutoMatchDTO autoMatchDTO, String indexName) {
        Query boolQuery = ElasticsearchQueryBuilder.autoMatchQuery(autoMatchDTO);
        return search(boolQuery, indexName, 5);
    }

    public List<ElasticsearchSource> nonUSAutoMatchSearch(AutoMatchDTO autoMatchDTO, String indexName) {
        Query boolQuery = ElasticsearchQueryBuilder.nonUSAutoMatchQuery(autoMatchDTO);
        return search(boolQuery, indexName, 25);
    }

    public List<ElasticsearchSource> search(Query query, String indexName, int limit) {
        try {
            log.info("query: {}", query);
            SearchResponse<ElasticsearchSource> response = elasticsearchClient.search(s -> s

                            .index(indexName)
                            //.minScore(20.0)
                            .query(query).size(limit),

                    ElasticsearchSource.class
            );
            log.info("search results size: {}, response: {}", response.hits().hits().size(), response.hits().hits());

            // Return the list of matching documents
            List<ElasticsearchSource> list = new ArrayList<>();
            for (Hit<ElasticsearchSource> elasticsearchSourceHit : response.hits().hits()) {
                ElasticsearchSource source = elasticsearchSourceHit.source();
                list.add(source);
            }
            return list;
        } catch (IOException e) {
            log.error("Search failed", e);
            return Collections.emptyList();
        }
    }

    public SearchResponse<ElasticsearchSource> searchWithProject(Query query, String indexName, int limit, double score, String... projectValues) {
        try {
            log.info("drop query: {}", query);
            SearchResponse<ElasticsearchSource> response = elasticsearchClient.search(s -> s
                            .index(indexName)
                            .size(limit)
                            .source(src -> src.filter(f -> f.includes(Arrays.asList(projectValues))))
                            .minScore(score)
                            .query(query),
                    ElasticsearchSource.class
            );
            log.info("search with project results size: {}", response.hits().hits().size());
            return response;
        } catch (IOException e) {
            log.error("Search failed", e);
            return null;
        }
    }

    public Map<String, Object> getUpdatedFields(ElasticsearchSource searchSource, ElasticsearchSource existingSource) throws IllegalAccessException {
        Map<String, Object> updatedFields = new HashMap<>();
            Field[] fields = ElasticsearchSource.class.getDeclaredFields();
            for (Field field : fields) {
                field.setAccessible(true);
                Object newValue = field.get(searchSource);
                Object existingValue = field.get(existingSource);
                if (newValue != null && !newValue.equals(existingValue)) {
                    updatedFields.put(field.getName(), newValue);
                }
            }
        return updatedFields;
    }

    private Set<String> smartSearchLogicForDropDown(List<Hit<ElasticsearchSource>> esResults){
        Set<String> honIds = new HashSet<>();
        for (Hit<ElasticsearchSource> elasticsearchSourceHit : esResults) {
            assert elasticsearchSourceHit.source() != null;
            honIds.add(elasticsearchSourceHit.source().getHon());
        }
        return honIds;
    }

    private Set<String> smartSearchLogicForTextBoxWithJaro(List<Hit<ElasticsearchSource>> esResults, String name, String type){
        Set<String> honIds = new HashSet<>();
        List<ElasticsearchSource> esList = new ArrayList<>();
        for(Hit<ElasticsearchSource> elasticsearchSource: esResults){
            esList.add(elasticsearchSource.source());
        }
        honIds = distanceAlgorithm.smartSearchJaroWinklerAlgorithmWithText(name, esList, type);
        log.info("Jaro: HonIds: {}, es: {}", honIds.size(), esResults.size());
        return honIds;
    }

    private Set<String> smartSearchLogicForTextBoxExact(List<Hit<ElasticsearchSource>> esResults, String name){
        Set<String> honIds = new HashSet<>();
        for (Hit<ElasticsearchSource> esResult : esResults) {
            if (esResult != null && esResult.score() > 300) {
                ElasticsearchSource elasticsearchSourceHit = esResult.source();
                assert elasticsearchSourceHit != null;
                honIds.add(elasticsearchSourceHit.getHon());
            }
        }
        log.info("HonIds: {}, es: {}", honIds.size(), esResults.size());
        return honIds;
    }

}
