package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.rds.CountryDTO;
import com.hireright.sourceintelligence.api.dto.rds.CountryRegionDTO;
import com.hireright.sourceintelligence.api.dto.rds.CountryRegionResponseDTO;
import com.hireright.sourceintelligence.api.dto.rds.CountryResponseDTO;
import com.hireright.sourceintelligence.api.dto.rds.PaginationMetadata;
import com.hireright.sourceintelligence.domain.entity.Country;
import com.hireright.sourceintelligence.domain.entity.CountryRegion;
import com.hireright.sourceintelligence.domain.mapper.CountryMapper;
import com.hireright.sourceintelligence.domain.repository.CountryRegionRepository;
import com.hireright.sourceintelligence.domain.repository.CountryRepository;
import com.hireright.sourceintelligence.service.CountryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@RequiredArgsConstructor
@Service
public class CountryServiceImpl implements CountryService {

    private final CountryRepository countryRepository;
    private final CountryRegionRepository countryRegionRepository;
    private final CountryMapper countryMapper;

    @Override
    public CountryResponseDTO getCountries(int startIndex, int batchSize) {
        log.info("Fetching countries with startIndex: {} and batchSize: {}", startIndex, batchSize);
        
        // Convert 1-based startIndex to 0-based page number
        int pageNumber = startIndex - 1;
        if (pageNumber < 0) {
            pageNumber = 0;
        }
        
        Pageable pageable = PageRequest.of(pageNumber, batchSize);
        Page<Country> countryPage = countryRepository.findAll(pageable);
        
        List<CountryDTO> countryDTOs = countryMapper.entityToDTOList(countryPage.getContent());
        
        PaginationMetadata metadata = PaginationMetadata.builder()
                .totalSize(countryPage.getTotalElements())
                .startIndex(startIndex)
                .batchSize(batchSize)
                .link("/country/?startIndex=" + startIndex + "&batchSize=" + batchSize)
                .build();
        
        return CountryResponseDTO.builder()
                .data(countryDTOs)
                .metadata(metadata)
                .build();
    }

    @Override
    public CountryRegionResponseDTO getCountryRegions(int countryId, int startIndex, int batchSize) {
        log.info("Fetching country regions for countryId: {} with startIndex: {} and batchSize: {}", 
                countryId, startIndex, batchSize);
        
        // Convert 1-based startIndex to 0-based page number
        int pageNumber = startIndex - 1;
        if (pageNumber < 0) {
            pageNumber = 0;
        }
        
        Pageable pageable = PageRequest.of(pageNumber, batchSize);
        Page<CountryRegion> regionPage = countryRegionRepository.findByCountryId(countryId, pageable);
        
        List<CountryRegionDTO> regionDTOs = countryMapper.entityToRegionDTOList(regionPage.getContent());
        
        PaginationMetadata metadata = PaginationMetadata.builder()
                .totalSize(regionPage.getTotalElements())
                .startIndex(startIndex)
                .batchSize(batchSize)
                .link("/country_region?countryId=" + countryId + "&batchSize=" + batchSize + "&startIndex=" + startIndex)
                .build();
        
        return CountryRegionResponseDTO.builder()
                .data(regionDTOs)
                .metadata(metadata)
                .build();
    }
}

