package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.AutocompleteSearchDTO;
import com.hireright.sourceintelligence.api.dto.SearchResponseDTO;
import com.hireright.sourceintelligence.api.dto.SmartSearchDTO;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;

import java.util.List;
import java.util.Map;

public interface SmartSearchService {

    SearchResponseDTO getSourceListBySearch(SmartSearchDTO smartSearchDTO);

    List<AutocompleteSearchDTO> getDropDownList(String keyword, OrganizationType orgType, Boolean isRAM, Map<String,String> searchFilters);

    List<AutocompleteSearchDTO> getDropDownListForRAM(String keyword, OrganizationType organizationType, Boolean isRAM, Map<String, String> searchFilters);
}
