package hireright.applications.permissions_api.api.db.management;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-17  HRG-330191 initial version
 */

import hireright.applications.permissions_api.api.db.management.factory.CCachingModuleFactory;
import hireright.applications.permissions_api.api.db.management.factory.CCachingOperatorFactory;
import hireright.applications.permissions_api.api.management.IOperatorPermissionsManager;
import hireright.applications.permissions_api.model.CCollection;
import hireright.applications.permissions_api.model.COperatorPermission;
import hireright.applications.permissions_api.model.COperatorPermissionFilter;
import hireright.applications.permissions_api.model.CSort;
import hireright.objects.permissions2.CModule;
import hireright.objects.permissions2.COperatorPermissionFactory;
import hireright.objects.users.COperator;
import hireright.sdk.consts.Logical;
import hireright.sdk.util.CStringUtils;
import org.hibernate.Session;

import java.util.Collection;
import java.util.LinkedHashSet;

public class CDbOperatorPermissionsManager implements IOperatorPermissionsManager
{
	private final COperatorPermissionFactory m_factory;

	public CDbOperatorPermissionsManager(COperatorPermissionFactory factory)
	{
		m_factory = factory;
	}

	public CDbOperatorPermissionsManager(Session session)
	{
		this(new COperatorPermissionFactory(session));
	}

	@Override
	public CCollection<COperatorPermission> list(Long lOffset, Integer nLimit,
		CSort<COperatorPermission.EField> sort, COperatorPermissionFilter filter)
	{
		Collection<hireright.objects.permissions2.COperatorPermission> sourceRecords =
			new LinkedHashSet<>();

		COperator operator = CCachingOperatorFactory.getOperator(filter.getSubject());
		CModule module = CCachingModuleFactory.getModule(filter.getScope());

		COperatorPermission.Builder targetRecord = new COperatorPermission.Builder(filter);

		if(operator != null && module != null)
		{
			targetRecord.trustLevel(operator.getQcPercent());

			String sSvTrustLevel =
				operator.getProperty(CDbOperatorManager.OPERATOR_PROP_SOURCE_APPROVAL_TRUST_LEVEL);
			if(CStringUtils.isNumber(sSvTrustLevel))
			{
				targetRecord.sourceVerificationTrustLevel(Integer.parseInt(sSvTrustLevel));
			}

			targetRecord.trustLevel(operator.getQcPercent());

			sourceRecords.addAll(m_factory.getOperatorPermissions(lOffset, nLimit, operator.getID(),
				module.getModuleID()));
		}

		for(hireright.objects.permissions2.COperatorPermission sourceRecord : sourceRecords)
		{
			translate(sourceRecord, targetRecord);
		}

		CCollection.Builder<COperatorPermission> target = new CCollection.Builder<>();

		target.item(targetRecord.build());

		return target.build();
	}

	private void translate(hireright.objects.permissions2.COperatorPermission source,
		COperatorPermission.Builder targetRecord)
	{
		String sLabel = source.getModuleLabel();

		if(!Logical.isTrue(source.getViewStatus()) || CStringUtils.isEmpty(sLabel))
		{
			return;
		}

		targetRecord.permission(sLabel + "." + CCachingModuleFactory.MODE_READ);

		if(Logical.isTrue(source.getInsertStatus()))
		{
			targetRecord.permission(sLabel + "." + CCachingModuleFactory.MODE_CREATE);
		}

		if(Logical.isTrue(source.getUpdateStatus()))
		{
			targetRecord.permission(sLabel + "." + CCachingModuleFactory.MODE_UPDATE);
		}

		if(Logical.isTrue(source.getDeleteStatus()))
		{
			targetRecord.permission(sLabel + "." + CCachingModuleFactory.MODE_DELETE);
		}
	}
}
