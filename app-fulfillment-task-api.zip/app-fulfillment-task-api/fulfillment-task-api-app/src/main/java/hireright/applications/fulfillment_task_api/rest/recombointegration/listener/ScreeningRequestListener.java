package hireright.applications.fulfillment_task_api.rest.recombointegration.listener;

import hireright.applications.fulfillment_task_api.model.recombointegration.listener.ScreeningRequest;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.FulfillmentService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.util.CorrelationIdHolder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

/**
 * RabbitMQ listener for screening requests.
 * Listens to the screening queue and processes incoming messages.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
@Component
@RequiredArgsConstructor
@ConditionalOnProperty(name = "rabbitmq.enabled", havingValue = "true")
public class ScreeningRequestListener {

    private final FulfillmentService fulfillmentService;

    /**
     * Listens to screening requests queue and processes messages.
     * Extracts correlation ID from message header for tracking.
     *
     * @param request the screening request message
     */
    @RabbitListener(queues = "${rabbitmq.queue.screening-requests}")
    public void handleScreeningRequest(@Payload ScreeningRequest request) {
        try {
            // Set correlation ID from header, or from request body or generate new one
            CorrelationIdHolder.generate();

            log.info("Received screening request from queue - ID: {}, CorrelationID: {}",
                    request.getId(), CorrelationIdHolder.get());

            fulfillmentService.fulfill(request.getId());

            log.info("Successfully processed screening request - ID: {}, CorrelationID: {}",
                    request.getId(), CorrelationIdHolder.get());

        } catch (Exception e) {
            log.error("Failed to process screening request - ID: {}",
                    request.getId(), e);
            throw new UnsupportedOperationException(
                    "Failed to process screening request: " + e.getMessage(), e);
        } finally {
            // Clean up correlation ID from MDC
            CorrelationIdHolder.clear();
        }
    }
}