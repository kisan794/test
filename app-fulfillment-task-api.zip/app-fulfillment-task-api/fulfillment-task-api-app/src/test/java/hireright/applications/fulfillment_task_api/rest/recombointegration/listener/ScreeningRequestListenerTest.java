package hireright.applications.fulfillment_task_api.rest.recombointegration.listener;

import hireright.applications.fulfillment_task_api.model.recombointegration.listener.ScreeningRequest;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.FulfillmentService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.util.CorrelationIdHolder;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for ScreeningRequestListener
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("ScreeningRequestListener Tests")
class ScreeningRequestListenerTest {

    @Mock
    private FulfillmentService fulfillmentService;

    @InjectMocks
    private ScreeningRequestListener listener;

    @AfterEach
    void tearDown() {
        CorrelationIdHolder.clear();
    }

    @Test
    @DisplayName("Should successfully handle screening request")
    void testHandleScreeningRequestSuccess() {
        // Given
        ScreeningRequest request = ScreeningRequest.builder()
                .id("COMP-EDU-001")
                .build();

        doNothing().when(fulfillmentService).fulfill(anyString());

        // When
        listener.handleScreeningRequest(request);

        // Then
        verify(fulfillmentService, times(1)).fulfill("COMP-EDU-001");
        assertNull(CorrelationIdHolder.get(), "Correlation ID should be cleared after processing");
    }

    @Test
    @DisplayName("Should generate correlation ID when handling request")
    void testHandleScreeningRequestGeneratesCorrelationId() {
        // Given
        ScreeningRequest request = ScreeningRequest.builder()
                .id("COMP-EMP-001")
                .build();

        doNothing().when(fulfillmentService).fulfill(anyString());

        // When
        listener.handleScreeningRequest(request);

        // Then
        verify(fulfillmentService, times(1)).fulfill("COMP-EMP-001");
        // Correlation ID should be cleared in finally block
        assertNull(CorrelationIdHolder.get());
    }

    @Test
    @DisplayName("Should handle screening request with employment ID")
    void testHandleEmploymentScreeningRequest() {
        // Given
        ScreeningRequest request = ScreeningRequest.builder()
                .id("SINGLE-EMP-004")
                .build();

        doNothing().when(fulfillmentService).fulfill(anyString());

        // When
        listener.handleScreeningRequest(request);

        // Then
        verify(fulfillmentService, times(1)).fulfill("SINGLE-EMP-004");
    }

    @Test
    @DisplayName("Should handle screening request with education ID")
    void testHandleEducationScreeningRequest() {
        // Given
        ScreeningRequest request = ScreeningRequest.builder()
                .id("SINGLE-EDU-005")
                .build();

        doNothing().when(fulfillmentService).fulfill(anyString());

        // When
        listener.handleScreeningRequest(request);

        // Then
        verify(fulfillmentService, times(1)).fulfill("SINGLE-EDU-005");
    }

    @Test
    @DisplayName("Should throw UnsupportedOperationException when fulfillment service fails")
    void testHandleScreeningRequestFulfillmentServiceFailure() {
        // Given
        ScreeningRequest request = ScreeningRequest.builder()
                .id("COMP-EDU-001")
                .build();

        RuntimeException cause = new RuntimeException("Service unavailable");
        doThrow(cause).when(fulfillmentService).fulfill(anyString());

        // When & Then
        UnsupportedOperationException exception = assertThrows(
                UnsupportedOperationException.class,
                () -> listener.handleScreeningRequest(request)
        );

        assertTrue(exception.getMessage().contains("Failed to process screening request"));
        assertEquals(cause, exception.getCause());
        verify(fulfillmentService, times(1)).fulfill("COMP-EDU-001");
        assertNull(CorrelationIdHolder.get(), "Correlation ID should be cleared even on failure");
    }

    @Test
    @DisplayName("Should clear correlation ID in finally block on exception")
    void testHandleScreeningRequestClearsCorrelationIdOnException() {
        // Given
        ScreeningRequest request = ScreeningRequest.builder()
                .id("COMP-EDU-001")
                .build();

        doThrow(new RuntimeException("Test exception")).when(fulfillmentService).fulfill(anyString());

        // When & Then
        assertThrows(UnsupportedOperationException.class, () -> listener.handleScreeningRequest(request));

        // Verify correlation ID is cleared
        assertNull(CorrelationIdHolder.get());
    }

    @Test
    @DisplayName("Should handle null pointer exception from fulfillment service")
    void testHandleScreeningRequestNullPointerException() {
        // Given
        ScreeningRequest request = ScreeningRequest.builder()
                .id("COMP-EDU-001")
                .build();

        NullPointerException cause = new NullPointerException("Null data");
        doThrow(cause).when(fulfillmentService).fulfill(anyString());

        // When & Then
        UnsupportedOperationException exception = assertThrows(
                UnsupportedOperationException.class,
                () -> listener.handleScreeningRequest(request)
        );

        assertEquals(cause, exception.getCause());
        assertNull(CorrelationIdHolder.get());
    }

    @Test
    @DisplayName("Should handle IllegalArgumentException from fulfillment service")
    void testHandleScreeningRequestIllegalArgumentException() {
        // Given
        ScreeningRequest request = ScreeningRequest.builder()
                .id("INVALID-ID")
                .build();

        IllegalArgumentException cause = new IllegalArgumentException("Invalid request ID");
        doThrow(cause).when(fulfillmentService).fulfill(anyString());

        // When & Then
        UnsupportedOperationException exception = assertThrows(
                UnsupportedOperationException.class,
                () -> listener.handleScreeningRequest(request)
        );

        assertEquals(cause, exception.getCause());
        verify(fulfillmentService, times(1)).fulfill("INVALID-ID");
    }

    @Test
    @DisplayName("Should process multiple requests sequentially")
    void testHandleMultipleScreeningRequests() {
        // Given
        ScreeningRequest request1 = ScreeningRequest.builder().id("COMP-EDU-001").build();
        ScreeningRequest request2 = ScreeningRequest.builder().id("COMP-EMP-002").build();
        ScreeningRequest request3 = ScreeningRequest.builder().id("SINGLE-EDU-004").build();

        doNothing().when(fulfillmentService).fulfill(anyString());

        // When
        listener.handleScreeningRequest(request1);
        listener.handleScreeningRequest(request2);
        listener.handleScreeningRequest(request3);

        // Then
        verify(fulfillmentService, times(1)).fulfill("COMP-EDU-001");
        verify(fulfillmentService, times(1)).fulfill("COMP-EMP-002");
        verify(fulfillmentService, times(1)).fulfill("SINGLE-EDU-004");
        assertNull(CorrelationIdHolder.get());
    }

    @Test
    @DisplayName("Should handle request with special characters in ID")
    void testHandleScreeningRequestWithSpecialCharacters() {
        // Given
        ScreeningRequest request = ScreeningRequest.builder()
                .id("TEST-ID-123_456.789")
                .build();

        doNothing().when(fulfillmentService).fulfill(anyString());

        // When
        listener.handleScreeningRequest(request);

        // Then
        verify(fulfillmentService, times(1)).fulfill("TEST-ID-123_456.789");
    }

    @Test
    @DisplayName("Should handle request with very long ID")
    void testHandleScreeningRequestWithLongId() {
        // Given
        String longId = "COMP-EDU-" + "A".repeat(1000);
        ScreeningRequest request = ScreeningRequest.builder()
                .id(longId)
                .build();

        doNothing().when(fulfillmentService).fulfill(anyString());

        // When
        listener.handleScreeningRequest(request);

        // Then
        verify(fulfillmentService, times(1)).fulfill(longId);
    }

    @Test
    @DisplayName("Should verify fulfillment service is called exactly once per request")
    void testFulfillmentServiceCalledOnce() {
        // Given
        ScreeningRequest request = ScreeningRequest.builder()
                .id("COMP-EDU-001")
                .build();

        doNothing().when(fulfillmentService).fulfill(anyString());

        // When
        listener.handleScreeningRequest(request);

        // Then
        verify(fulfillmentService, times(1)).fulfill("COMP-EDU-001");
        verifyNoMoreInteractions(fulfillmentService);
    }
}

