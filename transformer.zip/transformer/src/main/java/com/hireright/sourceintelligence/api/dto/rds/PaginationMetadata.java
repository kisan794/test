package com.hireright.sourceintelligence.api.dto.rds;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaginationMetadata {

    @JsonProperty("TotalSize")
    private long totalSize;

    @JsonProperty("StartIndex")
    private int startIndex;

    @JsonProperty("BatchSize")
    private int batchSize;

    @JsonProperty("Link")
    private String link;
}

