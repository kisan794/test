/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.http.exception;

import lombok.Getter;

/**
 * Exception thrown when an HTTP response has a retryable status code.
 * This exception is used by Spring Retry to determine if a request should be retried.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Getter
public class RetryableHttpException extends RuntimeException {

    private final int statusCode;
    private final String responseBody;

    /**
     * Constructor with status code.
     *
     * @param statusCode the HTTP status code
     */
    public RetryableHttpException(int statusCode) {
        super("Retryable HTTP status code: " + statusCode);
        this.statusCode = statusCode;
        this.responseBody = null;
    }

    /**
     * Constructor with status code and response body.
     *
     * @param statusCode   the HTTP status code
     * @param responseBody the response body
     */
    public RetryableHttpException(int statusCode, String responseBody) {
        super("Retryable HTTP status code: " + statusCode);
        this.statusCode = statusCode;
        this.responseBody = responseBody;
    }

    /**
     * Constructor with status code and message.
     *
     * @param statusCode the HTTP status code
     * @param message    the error message
     */
    public RetryableHttpException(int statusCode, String message, String responseBody) {
        super(message);
        this.statusCode = statusCode;
        this.responseBody = responseBody;
    }
}

