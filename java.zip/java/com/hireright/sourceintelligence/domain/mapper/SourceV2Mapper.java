package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.api.v2.dto.SourceDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValueCheckStrategy;

import java.util.List;

import static org.mapstruct.ReportingPolicy.IGNORE;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        unmappedTargetPolicy = IGNORE)
public interface SourceV2Mapper {


    @Mapping(target = "organizationName", source = "name")
    @Mapping(target = "organizationType", source = "type")
    SourceOrganizationDTO sourceDTOtoSourceOrganizationDTO(SourceDTO sourceDTO);

    @Mapping(target = "name", source = "organizationName")
    @Mapping(target = "type", source = "organizationType")
    SourceDTO sourceOrganizationDTOtoSourceDTO(SourceOrganizationDTO sourceDTO);

    List<SourceDTO> toSourceDTOList(List<SourceOrganizationDTO> sourceDTO);

}
