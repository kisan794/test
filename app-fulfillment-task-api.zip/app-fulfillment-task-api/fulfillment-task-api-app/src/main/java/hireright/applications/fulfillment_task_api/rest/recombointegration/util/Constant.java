/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.util;

public final class Constant {

    public static final String EDUCATION = "EDUCATION";
    public static final String EMPLOYMENT = "EMPLOYMENT";
    public static final String SCREENING_TYPE_EMPLOYMENT = "employment";
    public static final String SCREENING_TYPE_EDUCATION = "education";
    public static final String FIELD_TYPE = "type";
    public static final
    String FIELD_NAME = "name";

    public static final String XML_PATH_ANY_DATE = "AnyDate";
    public static final String XML_PATH_SCREENING = "Screening";
    public static final String XML_PATH_NAME = "name";
    public static final String XML_PATH_TYPE = "type";
    public static final String XML_PATH_PRODUCER_REFERENCE_ID = "ProducerReferenceId";
    public static final String XML_PATH_ID_VALUE = "IdValue";


    private Constant() {
        throw new UnsupportedOperationException(
                "This is a utility class and cannot be instantiated");
    }

}