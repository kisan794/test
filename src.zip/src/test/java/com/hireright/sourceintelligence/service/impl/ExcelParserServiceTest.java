package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.InstitutionRecord;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class ExcelParserServiceTest {

    @InjectMocks
    private ExcelParserService excelParserService;

    private MockMultipartFile createExcelFile(Workbook workbook) throws IOException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        return new MockMultipartFile(
                "file",
                "test.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                outputStream.toByteArray()
        );
    }

    @Test
    void testParseExcelFile_Success() throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Sheet1");

        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Institution Name");
        headerRow.createCell(1).setCellValue("Country");
        headerRow.createCell(2).setCellValue("City");
        headerRow.createCell(3).setCellValue("State/County/Region");
        headerRow.createCell(4).setCellValue("Service Provider");
        headerRow.createCell(5).setCellValue("Surcharge Amount");
        headerRow.createCell(6).setCellValue("Payment Method");
        headerRow.createCell(7).setCellValue("Code");
        headerRow.createCell(8).setCellValue("Turnaround Time");
        headerRow.createCell(9).setCellValue("Follow Up Allowed");

        Row dataRow = sheet.createRow(1);
        dataRow.createCell(0).setCellValue("Harvard University");
        dataRow.createCell(1).setCellValue("USA");
        dataRow.createCell(2).setCellValue("Cambridge");
        dataRow.createCell(3).setCellValue("MA");
        dataRow.createCell(4).setCellValue("Parchment Exchange");
        dataRow.createCell(5).setCellValue("5.00");
        dataRow.createCell(6).setCellValue("Credit Card");
        dataRow.createCell(7).setCellValue("HARV001");
        dataRow.createCell(8).setCellValue("3");
        dataRow.createCell(9).setCellValue("Yes");

        MockMultipartFile file = createExcelFile(workbook);

        List<InstitutionRecord> records = excelParserService.parseExcelFile(file);

        assertNotNull(records);
        assertEquals(1, records.size());
        InstitutionRecord record = records.get(0);
        assertEquals("Harvard University", record.getInstitutionName());
        assertEquals("USA", record.getCountry());
        assertEquals("Cambridge", record.getCity());
        assertEquals("MA", record.getStateCountyRegion());
        assertEquals("Parchment Exchange", record.getServiceProvider());
        assertEquals("5.00", record.getSurchargeAmount());
        assertEquals("Credit Card", record.getPaymentMethod());
        assertEquals("HARV001", record.getCode());
        assertEquals("3", record.getTurnaroundTime());
        assertEquals("Yes", record.getFollowUpAllowed());

        workbook.close();
    }

    @Test
    void testParseExcelFile_MultipleRecords() throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Sheet1");

        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < 10; i++) {
            headerRow.createCell(i).setCellValue("Header " + i);
        }

        for (int i = 1; i <= 5; i++) {
            Row dataRow = sheet.createRow(i);
            dataRow.createCell(0).setCellValue("Institution " + i);
            dataRow.createCell(1).setCellValue("USA");
            dataRow.createCell(2).setCellValue("City " + i);
            dataRow.createCell(3).setCellValue("State " + i);
            dataRow.createCell(4).setCellValue("Provider");
            dataRow.createCell(5).setCellValue("5.00");
            dataRow.createCell(6).setCellValue("Credit");
            dataRow.createCell(7).setCellValue("CODE" + i);
            dataRow.createCell(8).setCellValue("3");
            dataRow.createCell(9).setCellValue("Yes");
        }

        MockMultipartFile file = createExcelFile(workbook);

        List<InstitutionRecord> records = excelParserService.parseExcelFile(file);

        assertNotNull(records);
        assertEquals(5, records.size());
        assertEquals("Institution 1", records.get(0).getInstitutionName());
        assertEquals("Institution 5", records.get(4).getInstitutionName());

        workbook.close();
    }

    @Test
    void testParseExcelFile_NumericCells() throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Sheet1");

        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < 10; i++) {
            headerRow.createCell(i).setCellValue("Header " + i);
        }

        Row dataRow = sheet.createRow(1);
        dataRow.createCell(0).setCellValue("Test University");
        dataRow.createCell(1).setCellValue("USA");
        dataRow.createCell(2).setCellValue("Boston");
        dataRow.createCell(3).setCellValue("MA");
        dataRow.createCell(4).setCellValue("Provider");
        dataRow.createCell(5).setCellValue(10.50); // Numeric value
        dataRow.createCell(6).setCellValue("Credit");
        dataRow.createCell(7).setCellValue(12345); // Numeric code
        dataRow.createCell(8).setCellValue(5); // Numeric turnaround
        dataRow.createCell(9).setCellValue("Yes");

        MockMultipartFile file = createExcelFile(workbook);

        List<InstitutionRecord> records = excelParserService.parseExcelFile(file);

        assertNotNull(records);
        assertEquals(1, records.size());
        InstitutionRecord record = records.get(0);
        assertEquals("10.5", record.getSurchargeAmount());
        assertEquals("12345", record.getCode());
        assertEquals("5", record.getTurnaroundTime());

        workbook.close();
    }

    @Test
    void testParseExcelFile_EmptyCells() throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Sheet1");

        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < 10; i++) {
            headerRow.createCell(i).setCellValue("Header " + i);
        }

        Row dataRow = sheet.createRow(1);
        dataRow.createCell(0).setCellValue("Test University");
        dataRow.createCell(1).setCellValue("USA");
        dataRow.createCell(2).setCellValue("Boston");
        dataRow.createCell(3).setCellValue("MA");
        // Leave cells 4-9 empty

        MockMultipartFile file = createExcelFile(workbook);

        List<InstitutionRecord> records = excelParserService.parseExcelFile(file);

        assertNotNull(records);
        assertEquals(1, records.size());
        InstitutionRecord record = records.get(0);
        assertEquals("Test University", record.getInstitutionName());
        assertEquals("", record.getServiceProvider());
        assertEquals("", record.getSurchargeAmount());
        assertEquals("", record.getPaymentMethod());

        workbook.close();
    }

    @Test
    void testParseExcelFile_SkipEmptyRows() throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Sheet1");

        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < 10; i++) {
            headerRow.createCell(i).setCellValue("Header " + i);
        }

        // Row 1: Valid data
        Row dataRow1 = sheet.createRow(1);
        dataRow1.createCell(0).setCellValue("University 1");
        dataRow1.createCell(1).setCellValue("USA");
        dataRow1.createCell(2).setCellValue("City");
        dataRow1.createCell(3).setCellValue("State");

        // Row 2: Empty row (should be skipped)
        sheet.createRow(2);

        // Row 3: Valid data
        Row dataRow3 = sheet.createRow(3);
        dataRow3.createCell(0).setCellValue("University 2");
        dataRow3.createCell(1).setCellValue("USA");
        dataRow3.createCell(2).setCellValue("City");
        dataRow3.createCell(3).setCellValue("State");

        MockMultipartFile file = createExcelFile(workbook);

        List<InstitutionRecord> records = excelParserService.parseExcelFile(file);

        assertNotNull(records);
        assertEquals(2, records.size());
        assertEquals("University 1", records.get(0).getInstitutionName());
        assertEquals("University 2", records.get(1).getInstitutionName());

        workbook.close();
    }

    @Test
    void testParseExcelFile_BooleanCells() throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Sheet1");

        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < 10; i++) {
            headerRow.createCell(i).setCellValue("Header " + i);
        }

        Row dataRow = sheet.createRow(1);
        dataRow.createCell(0).setCellValue("Test University");
        dataRow.createCell(1).setCellValue("USA");
        dataRow.createCell(2).setCellValue("Boston");
        dataRow.createCell(3).setCellValue("MA");
        dataRow.createCell(4).setCellValue("Provider");
        dataRow.createCell(5).setCellValue("5.00");
        dataRow.createCell(6).setCellValue("Credit");
        dataRow.createCell(7).setCellValue("CODE");
        dataRow.createCell(8).setCellValue("3");
        dataRow.createCell(9).setCellValue(true); // Boolean value

        MockMultipartFile file = createExcelFile(workbook);

        List<InstitutionRecord> records = excelParserService.parseExcelFile(file);

        assertNotNull(records);
        assertEquals(1, records.size());
        assertEquals("true", records.get(0).getFollowUpAllowed());

        workbook.close();
    }

    @Test
    void testParseExcelFile_WhitespaceHandling() throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Sheet1");

        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < 10; i++) {
            headerRow.createCell(i).setCellValue("Header " + i);
        }

        Row dataRow = sheet.createRow(1);
        dataRow.createCell(0).setCellValue("  Harvard University  "); // Leading/trailing spaces
        dataRow.createCell(1).setCellValue(" USA ");
        dataRow.createCell(2).setCellValue("Cambridge");
        dataRow.createCell(3).setCellValue("MA");

        MockMultipartFile file = createExcelFile(workbook);

        List<InstitutionRecord> records = excelParserService.parseExcelFile(file);

        assertNotNull(records);
        assertEquals(1, records.size());
        assertEquals("Harvard University", records.get(0).getInstitutionName()); // Trimmed
        assertEquals("USA", records.get(0).getCountry()); // Trimmed

        workbook.close();
    }

    @Test
    void testParseExcelFile_EmptyWorkbook() throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Sheet1");

        // Only header row, no data
        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < 10; i++) {
            headerRow.createCell(i).setCellValue("Header " + i);
        }

        MockMultipartFile file = createExcelFile(workbook);

        List<InstitutionRecord> records = excelParserService.parseExcelFile(file);

        assertNotNull(records);
        assertTrue(records.isEmpty());

        workbook.close();
    }
}