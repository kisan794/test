package com.hireright.sourceintelligence.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hireright.sourceintelligence.api.dto.UserLoginDetailsDTO;
import org.junit.jupiter.api.Test;
import org.mockito.MockedConstruction;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Base64;
import java.util.zip.GZIPInputStream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mockConstruction;
import static org.mockito.Mockito.when;

class JwtUtilTest {

    @Test
    void generateToken_shouldThrowRuntimeException_whenSerializationFails() throws Exception {
        try (MockedConstruction<ObjectMapper> mocked = mockConstruction(ObjectMapper.class,
                (mock, context) -> when(mock.writeValueAsString(any(UserLoginDetailsDTO.class)))
                        .thenThrow(new JsonProcessingException("Serialization error") {
                        }))) {

            UserLoginDetailsDTO dto = new UserLoginDetailsDTO();

            RuntimeException exception = assertThrows(RuntimeException.class,
                    () -> JwtUtil.generateToken(dto));

            assertNotNull(exception.getCause());
            assertTrue(exception.getCause() instanceof JsonProcessingException);
        }
    }

    @Test
    void compressAndEncode_shouldReturnBase64EncodedGzipContent() throws Exception {
        String json = "{\"userName\":\"qa.user\",\"email\":\"qa.user@test.com\"}";

        try (MockedConstruction<ObjectMapper> mocked = mockConstruction(ObjectMapper.class,
                (mock, context) -> when(mock.writeValueAsString(any(UserLoginDetailsDTO.class))).thenReturn(json))) {

            UserLoginDetailsDTO dto = new UserLoginDetailsDTO();

            String encoded = JwtUtil.compressAndEncode(dto);

            assertNotNull(encoded);
            assertFalse(encoded.isBlank());

            byte[] compressedBytes = Base64.getUrlDecoder().decode(encoded);
            String decompressed = unzip(compressedBytes);

            assertEquals(json, decompressed);
        }
    }

    @Test
    void compressAndEncode_shouldThrowRuntimeException_whenSerializationFails() throws Exception {
        try (MockedConstruction<ObjectMapper> mocked = mockConstruction(ObjectMapper.class,
                (mock, context) -> when(mock.writeValueAsString(any(UserLoginDetailsDTO.class)))
                        .thenThrow(new JsonProcessingException("Compression error") {
                        }))) {

            UserLoginDetailsDTO dto = new UserLoginDetailsDTO();

            RuntimeException exception = assertThrows(RuntimeException.class,
                    () -> JwtUtil.compressAndEncode(dto));

            assertNotNull(exception.getCause());
            assertTrue(exception.getCause() instanceof JsonProcessingException);
        }
    }

    private String unzip(byte[] compressedBytes) throws Exception {
        try (GZIPInputStream gzipInputStream = new GZIPInputStream(new ByteArrayInputStream(compressedBytes));
             ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {

            byte[] buffer = new byte[256];
            int length;
            while ((length = gzipInputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, length);
            }
            return outputStream.toString();
        }
    }
}