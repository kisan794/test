/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk		2017-08-14	Created
 * 	M.Kuznetsov		2025-09-12	HRG-339332: CInstanceDomain support
 */
package hireright.applications.vendor_api.exchange.handler.objects;

import java.util.List;

import hireright.applications.vendor_api.EExchangeDirection;
import hireright.bdk.instance_parameter.CInstanceDomain;
import hireright.objects.order3.model.CNameValue;

/**
 * Common superclass for entity exchange DTOs
 */
public class CEntityExchangeDTO
{
	private EExchangeDirection m_exchangeDir;
	private String m_objectReference;
	private CInstanceDomain m_remoteInstanceDomain;
	private List<CNameValue> properties;

	public String getObjectRef()
	{
		return m_objectReference;
	}

	public void setObjectRef(String reference)
	{
		this.m_objectReference = reference;
	}

	public CInstanceDomain getRemoteInstanceDomain()
	{
		return m_remoteInstanceDomain;
	}

	public void setRemoteInstanceDomain(CInstanceDomain remoteInstanceDomain)
	{
		this.m_remoteInstanceDomain = remoteInstanceDomain;
	}

	public List<CNameValue> getProperties()
	{
		return this.properties;
	}

	public void setProperties(List<CNameValue> properties)
	{
		this.properties = properties;
	}

	public EExchangeDirection getExchangeDirection()
	{
		return m_exchangeDir;
	}

	public void setExchangeDirection(EExchangeDirection exchangeDirection)
	{
		this.m_exchangeDir = exchangeDirection;
	}
}
