package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.AutoMatchDTO;
import com.hireright.sourceintelligence.searchindex.entity.ElasticsearchSource;
import com.hireright.sourceintelligence.service.impl.DistanceAlgorithm;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class
DistanceAlgorithmTest {

    private DistanceAlgorithm distanceAlgorithm;

    @BeforeEach
    void setUp() {
        distanceAlgorithm = new DistanceAlgorithm();
        ReflectionTestUtils.setField(distanceAlgorithm, "algorithmThresholdForApplication", "80.0");
    }

    @Test
    void testJaroWinklerAlgorithmWithOrgNameMatch() {
        AutoMatchDTO autoMatchDTO = getTestAutoMatchDTO("Test University");
        ElasticsearchSource source = getTestElasticsearchSource("Test University", List.of("TU"));
        List<ElasticsearchSource> searchList = List.of(source);

        Map<String, String> result = distanceAlgorithm.jaroWinklerAlgorithm(autoMatchDTO.getSourceName(), searchList);

        assertThat(result).containsKey("org");
    }

    @Test
    void testJaroWinklerAlgorithmWithAliasMatch() {
        AutoMatchDTO autoMatchDTO = getTestAutoMatchDTO("TU");
        ElasticsearchSource source = getTestElasticsearchSource("Other Name", List.of("TU"));
        List<ElasticsearchSource> searchList = List.of(source);

        Map<String, String> result = distanceAlgorithm.jaroWinklerAlgorithm(autoMatchDTO.getSourceName(), searchList);

        assertThat(result).containsKey("orgAlias");
    }

    @Test
    void testSmartSearchJaroWinklerAlgorithmWithTextMatch() {
        ReflectionTestUtils.setField(distanceAlgorithm, "suggestionThreshold", "85.0");

        ElasticsearchSource source = getTestElasticsearchSource("Smart Institute", List.of("SI"), "HON999");
        List<ElasticsearchSource> searchList = List.of(source);

        Set<String> result = distanceAlgorithm.smartSearchJaroWinklerAlgorithmWithText("Smart Institute", searchList, "suggestions");

        assertThat(result).contains("HON999");
    }


    @Test
    void testJaroWinklerAlgorithmWithBothNameAndAliasMatch() {
        DistanceAlgorithm distanceAlgorithm = new DistanceAlgorithm();
        ReflectionTestUtils.setField(distanceAlgorithm, "algorithmThresholdForApplication", "80");

        ElasticsearchSource source = new ElasticsearchSource();
        source.setOrganizationName("Global University");
        source.setOrganizationAlias(List.of("GU", "Global U"));
        List<ElasticsearchSource> searchList = List.of(source);

        Map<String, String> result = distanceAlgorithm.jaroWinklerAlgorithm("Global U", searchList);

        assertThat(result)
                .containsExactlyInAnyOrderEntriesOf(
                        Map.of(
                                "orgAlias", "Global U"
                        )
                );
    }




    @Test
    void testJaroWinklerAlgorithmAliasMoreSimilarThanName() {
        ElasticsearchSource source = getTestElasticsearchSource("Unmatched Name", List.of("ExactMatch"));
        List<ElasticsearchSource> searchList = List.of(source);

        Map<String, String> result = distanceAlgorithm.jaroWinklerAlgorithm("ExactMatch", searchList);

        assertThat(result).containsKey("orgAlias");
    }

    @Test
    void testJaroWinklerAlgorithmWithEmptyList() {
        Map<String, String> result = distanceAlgorithm.jaroWinklerAlgorithm("Anything", new ArrayList<>());

        assertThat(result).isEmpty();
    }



    @Test
    void testJaroWinklerAlgorithm_EqualOrgAndAliasDistance() {
        String name = "EqualName";
        ElasticsearchSource source = new ElasticsearchSource();
        source.setOrganizationName("EqualName");
        source.setOrganizationAlias(List.of("EqualName"));
        source.setHon("HON321");

        List<ElasticsearchSource> list = List.of(source);

        Map<String, String> result = distanceAlgorithm.jaroWinklerAlgorithm(name, list);

        assertThat(result).containsKey("org").containsKey("orgAlias");
    }

    @Test
    void testSmartSearchJaroWinklerAlgorithmWithText_multipleValuesTriggersSortLambda() {
        ReflectionTestUtils.setField(distanceAlgorithm, "suggestionThreshold", "85.0");

        List<ElasticsearchSource> list = new ArrayList<>();
        ElasticsearchSource s1 = getTestElasticsearchSource("Smart Institute A", List.of("Smart A"), "HON001");
        ElasticsearchSource s2 = getTestElasticsearchSource("Smart Institute B", List.of("Smart B"), "HON002");

        list.add(s1);
        list.add(s2);

        Set<String> result = distanceAlgorithm.smartSearchJaroWinklerAlgorithmWithText("Smart Institute", list, "suggestions");

        assertThat(result).contains("HON001", "HON002");
    }

    @Test
    void testJaroWinklerAlgorithmForDropDown() {
        List<ElasticsearchSource> list = List.of(
                getTestElasticsearchSource("Alpha College", List.of("AC"), "HON001"),
                getTestElasticsearchSource("Beta School", List.of("BS"), "HON002")
        );

        Set<String> result = distanceAlgorithm.jaroWinklerAlgorithmForDropDown("Alpha", list);

        assertThat(result).contains("Alpha College");
    }

    private AutoMatchDTO getTestAutoMatchDTO(String name) {
        AutoMatchDTO dto = new AutoMatchDTO();
        dto.setSourceName(name);
        dto.setCity("City");
        dto.setCountry("USA");
        dto.setState("State");
        dto.setSourceType("EDUCATION");
        return dto;
    }

    private ElasticsearchSource getTestElasticsearchSource(String name, List<String> aliases) {
        ElasticsearchSource source = new ElasticsearchSource();
        source.setOrganizationName(name);
        source.setOrganizationAlias(aliases);
        source.setHon("HON123");
        return source;
    }

    private ElasticsearchSource getTestElasticsearchSource(String name, List<String> aliases, String hon) {
        ElasticsearchSource source = new ElasticsearchSource();
        source.setOrganizationName(name);
        source.setOrganizationAlias(aliases);
        source.setHon(hon);
        return source;
    }
}