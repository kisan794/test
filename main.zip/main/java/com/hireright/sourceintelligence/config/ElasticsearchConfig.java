package com.hireright.sourceintelligence.config;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.json.jackson.JacksonJsonpMapper;
import co.elastic.clients.transport.ElasticsearchTransport;
import co.elastic.clients.transport.rest_client.RestClientTransport;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.nio.reactor.IOReactorConfig;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.sniff.ElasticsearchNodesSniffer;
import org.elasticsearch.client.sniff.Sniffer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.net.URI;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.PRODUCTION;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.STAGE;

@Configuration
public class ElasticsearchConfig {

    @Value("${spring.elasticsearch.uris}")
    private String elasticsearchUri;

    @Value("${spring.elasticsearch.username}")
    private String esUserName;

    @Value("${spring.elasticsearch.password}")
    private String esPassword;

    @Value("${elasticsearchEnvType}")
    private String elasticsearchEnvType;


    @Bean
    public ElasticsearchClient elasticsearchClient() {

        final BasicCredentialsProvider credentialsProvider = new BasicCredentialsProvider();
        credentialsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(esUserName, esPassword));

        RestClient restClient;
        if (elasticsearchEnvType.equals(STAGE) || elasticsearchEnvType.equals(PRODUCTION)) {
            String[] elasticsearchHosts = elasticsearchUri.split(",");

            HttpHost[] httpHosts = new HttpHost[elasticsearchHosts.length];
            for (int i = 0; i < elasticsearchHosts.length; i++) {
                URI uri = URI.create(elasticsearchHosts[i]);
                httpHosts[i] = new HttpHost(uri.getHost(), uri.getPort(), uri.getScheme());
            }

            RestClientBuilder builder = RestClient.builder(httpHosts);

            restClient = builder.setHttpClientConfigCallback(httpClientBuilder -> {
                return httpClientBuilder
                        .setDefaultCredentialsProvider(credentialsProvider)
                        .setKeepAliveStrategy((response, context) -> 120_000) // 2 min keep-alive
                        .setDefaultIOReactorConfig(IOReactorConfig.custom()
                                .setSoKeepAlive(true) // Enable TCP Keep-Alive
                                .build());
            }).build();

        } else {
            URI uri = URI.create(elasticsearchUri);
            restClient = RestClient.builder(new HttpHost(uri.getHost(), uri.getPort(), uri.getScheme()))
                    .setHttpClientConfigCallback(httpClientBuilder -> httpClientBuilder
                            .setDefaultCredentialsProvider(credentialsProvider))
                    .build();
        }
        ElasticsearchTransport transport = new RestClientTransport(restClient, new JacksonJsonpMapper());
        return new ElasticsearchClient(transport);
    }

    @Bean
    public Sniffer sniffer(RestClient restClient) {
        ElasticsearchNodesSniffer nodesSniffer = new ElasticsearchNodesSniffer(
                restClient);
        return Sniffer.builder(restClient)
                .setNodesSniffer(nodesSniffer)
                .build();
    }
}
