/*
 * @(#)$RCSfilev$ $Revision: 1.2 $ $Date: 2014/07/28 14:48:43 $ $Author: aputintsev $
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/resources/src/main/java/hireright/project/accesspoint/model/CreateResponse.java,v $
 *
 * Copyright 2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	J.Burlakova		2012-05-23	Created
 */

package hireright.project.accesspoint.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Jekaterina Burlakova
 */
@XmlRootElement(name = "createResponse")
public class CreateResponse
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: aputintsev $";

	private Return returnBean;

	public CreateResponse(){}

	@XmlElement(name = "return")
	public Return getReturnBean()
	{
		return returnBean;
	}

	public void setReturnBean( Return returnBean )
	{
		this.returnBean = returnBean;
	}

	
}
