package com.hireright.migrationservice.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Contact {
    private String purpose;
    private List<PurposeRule> purposeRule;
    private List<ContactDetail> contactDetails;
}

