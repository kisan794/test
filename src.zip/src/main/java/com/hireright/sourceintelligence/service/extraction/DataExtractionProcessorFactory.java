package com.hireright.sourceintelligence.service.extraction;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Slf4j
@Component
@RequiredArgsConstructor
public class DataExtractionProcessorFactory {

    private final List<DataExtractionProcessor<?>> processors;

    @SuppressWarnings("unchecked")
    public <T> DataExtractionProcessor<T> getProcessor(String dataExtractionType) {
        if (dataExtractionType == null || dataExtractionType.trim().isEmpty()) {
            throw new IllegalArgumentException("Data Extraction type cannot be null or empty");
        }

        Optional<DataExtractionProcessor<?>> processor = processors.stream()
                .filter(p -> p.supports(dataExtractionType))
                .findFirst();

        if (processor.isEmpty()) {
            throw new IllegalArgumentException(
                    String.format("Unsupported Data Extraction type: '%s'. Available types: %s",
                            dataExtractionType,
                            getSupportedTypes())
            );
        }

        return (DataExtractionProcessor<T>) processor.get();
    }

    public String getSupportedTypes() {
        return processors.stream()
                .map(DataExtractionProcessor::getDataExtractionTypeType)
                .reduce((a, b) -> a + ", " + b)
                .orElse("none");
    }

    public boolean isSupported(String dataExtractionType) {
        if (dataExtractionType == null || dataExtractionType.trim().isEmpty()) {
            return false;
        }

        return processors.stream()
                .anyMatch(p -> p.supports(dataExtractionType));
    }
}

