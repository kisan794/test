

import com.hireright.sourceintelligence.api.dto.InstitutionRecord;
import com.hireright.sourceintelligence.service.migration.MigrationProcessorFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Service for handling data migration operations.
 * Delegates to specific migration processors based on migration type using the Strategy Pattern.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class MigrationService {

    private final MigrationProcessorFactory processorFactory;

    /**
     * Process institution records using the appropriate migration processor.
     *
     * @param records List of institution records to process
     * @param migrationType The type of migration (e.g., "parchment", "clearinghouse")
     * @return Map containing processing results
     */
    public Map<String, Object> processInstitutionRecords(List<InstitutionRecord> records, String migrationType) {
        log.info("Processing {} records for migration type: {}", records.size(), migrationType);

        // Get the appropriate processor for this migration type
        var processor = processorFactory.getProcessor(migrationType);

        // Delegate to the processor
        Map<String, Object> result = processor.processInstitutionRecords(records);
        result.put("migrationType", migrationType);

        return result;
    }

    /**
     * Get all supported migration types.
     *
     * @return Comma-separated string of supported migration types
     */
    public String getSupportedMigrationTypes() {
        return processorFactory.getSupportedTypes();
    }

    /**
     * Check if a migration type is supported.
     *
     * @param migrationType The migration type to check
     * @return true if supported, false otherwise
     */
    public boolean isMigrationTypeSupported(String migrationType) {
        return processorFactory.isSupported(migrationType);
    }
}

