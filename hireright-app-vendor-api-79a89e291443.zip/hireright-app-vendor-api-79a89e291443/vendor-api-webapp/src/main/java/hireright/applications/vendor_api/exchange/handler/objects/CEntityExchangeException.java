/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-08-14	Created
 */
package hireright.applications.vendor_api.exchange.handler.objects;

@SuppressWarnings("serial")
public class CEntityExchangeException extends Exception
{
	public CEntityExchangeException(String msg)
	{
		super(msg);
	}

	public CEntityExchangeException(String msg, Throwable t)
	{
		super(msg, t);
	}
}
