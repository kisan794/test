/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.employment.Request;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Helper class to read employment verification mock JSON responses
 *
 * @author Keshav Ladha
 * @version 1.0
 */
public class ReadEmploymentMockResponse
{

	private static final ObjectMapper mapper = new ObjectMapper();

	private ReadEmploymentMockResponse()
	{
		// Private constructor to prevent instantiation
	}

	/**
	 * Reads all employment verification mock responses from JSON files
	 *
	 * @return Map of employment data requests keyed by ID
	 * @throws IOException if file reading fails
	 */
	public static Map<String, Request> readAllEmploymentMockResponses()
	{
		Map<String, Request> responseMap = new HashMap<>();

		String[] files = {
			"/mock/EMP-001.json",
			"/mock/EMP-002.json",
			"/mock/EMP-003.json",
			"/mock/EMP-004.json",
			"/mock/EMP-005.json"
		};

		String[] keys = {
			"COMP-EMP-001",
			"COMP-EMP-002",
			"COMP-EMP-003",
			"SINGLE-EMP-004",
			"SINGLE-EMP-005"
		};

		for(int i = 0; i < files.length; i++)
		{
			try(InputStream is = ReadEmploymentMockResponse.class.getResourceAsStream(files[i]))
			{
				if(is == null)
				{
					throw new IOException("File not found: " + files[i]);
				}
				// Convert JSON into EmploymentDataRequest object
				Request request = mapper.readValue(is, Request.class);
				responseMap.put(keys[i], request);
			}
			catch(IOException e)
			{
				throw new RuntimeException(e);
			}
		}
		return responseMap;
	}
}

