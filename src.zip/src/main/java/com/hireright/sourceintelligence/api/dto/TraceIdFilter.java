package com.hireright.sourceintelligence.api.dto;

import com.hireright.sourceintelligence.util.TraceIdHolder;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * Servlet filter that manages trace IDs for HTTP requests.
 * This filter:
 * 1. Extracts trace ID from incoming request header (X-TRACE-ID)
 * 2. Generates a new trace ID if not present
 * 3. Sets the trace ID in MDC for logging
 * 4. Adds the trace ID to the response header
 * 5. Cleans up MDC after request processing
 * The filter runs with highest priority (Order 1) to ensure trace ID
 * is available for all subsequent filters and request processing.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
@Component
@Order(1)
public class TraceIdFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        try {
            // Extract trace ID from request header or generate new one
            String traceId = httpRequest.getHeader(TraceIdHolder.TRACE_ID_HEADER);

            if (traceId == null || traceId.isEmpty()) {
                traceId = TraceIdHolder.generate();
            } else {
                TraceIdHolder.set(traceId);
            }

            // Add trace ID to response header
            httpResponse.setHeader(TraceIdHolder.TRACE_ID_HEADER, traceId);

            // Continue with the filter chain
            chain.doFilter(request, response);

        } finally {
            // Clean up MDC after request processing
            TraceIdHolder.clear();
        }
    }

    @Override
    public void init(FilterConfig filterConfig) {
        log.info("traceIdFilter initialized");
    }

    @Override
    public void destroy() {
        log.info("traceIdFilter destroyed");
    }
}