package org.example.recombointegration.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.example.recombointegration.document.IdeaSubmission.ImplementationComplexity;
import org.example.recombointegration.document.IdeaSubmission.TimelineType;

import java.util.List;

/**
 * Request DTO for creating or updating an idea submission.
 *
 * @author Generated
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request object for submitting a new idea")
public class IdeaSubmissionRequest {

    // Section 1: Basic Information
    @NotBlank(message = "Title is required")
    @Size(max = 100, message = "Title must not exceed 100 characters")
    @Schema(description = "Title of the idea", example = "Automate Daily Report Generation", required = true)
    @JsonProperty("title")
    private String title;

    @NotBlank(message = "Submitted by is required")
    @Schema(description = "Name of the person submitting the idea", example = "John Doe", required = true)
    @JsonProperty("submittedBy")
    private String submittedBy;

    @Schema(description = "Email address of the submitter", example = "john.doe@company.com")
    @JsonProperty("emailAddress")
    private String emailAddress;

    @Schema(description = "Department or function of the submitter", example = "IT Operations")
    @JsonProperty("department")
    private String department;

    // Section 2: Idea Details
    @NotBlank(message = "Description is required")
    @Schema(description = "Detailed description of the idea and problem it solves", 
            example = "Currently, daily reports are generated manually which takes 2 hours. This idea proposes automating the process using scheduled scripts.",
            required = true)
    @JsonProperty("description")
    private String description;

    @NotBlank(message = "Objective is required")
    @Schema(description = "Main goal or objective of the idea", 
            example = "Reduce manual effort and improve accuracy of daily reports",
            required = true)
    @JsonProperty("objective")
    private String objective;

    // Section 3: Area of Impact
    @Schema(description = "Areas impacted by this idea", 
            example = "[\"PROCESS\", \"QUALITY\"]",
            allowableValues = {"PROCESS", "PEOPLE", "QUALITY"})
    @JsonProperty("impactAreas")
    private List<String> impactAreas;

    // Section 4: Type of Improvement
    @Schema(description = "Types of improvement this idea provides", 
            example = "[\"INCREMENTAL\", \"COST_SAVING\"]",
            allowableValues = {"INCREMENTAL", "INNOVATIVE", "COST_SAVING", "QUALITY_ENHANCEMENT", "OTHER"})
    @JsonProperty("improvementTypes")
    private List<String> improvementTypes;

    @Schema(description = "Other improvement type if 'OTHER' is selected", example = "Process automation")
    @JsonProperty("improvementTypeOther")
    private String improvementTypeOther;

    // Section 5: Expected Impact
    @Schema(description = "Expected benefits and quantified impact", 
            example = "Reduce processing time by 90%, eliminate manual errors, free up 10 hours per week")
    @JsonProperty("expectedBenefit")
    private String expectedBenefit;

    @Schema(description = "Categories of impact", 
            example = "[\"TIME_EFFICIENCY\", \"COST_SAVINGS\"]",
            allowableValues = {"TIME_EFFICIENCY", "COST_SAVINGS", "EMPLOYEE_ENGAGEMENT", "CUSTOMER_SATISFACTION", "COMPLIANCE_RISK_REDUCTION", "OTHER"})
    @JsonProperty("impactCategories")
    private List<String> impactCategories;

    @Schema(description = "Other impact category if 'OTHER' is selected", example = "Data accuracy")
    @JsonProperty("impactCategoryOther")
    private String impactCategoryOther;

    // Section 6: Implementation Details
    @Schema(description = "Implementation complexity level", 
            example = "MEDIUM",
            allowableValues = {"LOW", "MEDIUM", "HIGH"})
    @JsonProperty("implementationComplexity")
    private ImplementationComplexity implementationComplexity;

    @Schema(description = "Suggested steps or roadmap for implementation", 
            example = "1. Analyze current report format\n2. Develop automation script\n3. Test with sample data\n4. Deploy to production")
    @JsonProperty("suggestedSteps")
    private String suggestedSteps;

    @Schema(description = "Timeline type for implementation", 
            example = "SHORT_TERM",
            allowableValues = {"SHORT_TERM", "LONG_TERM"})
    @JsonProperty("timelineType")
    private TimelineType timelineType;

    // Section 7: Supporting Information
    @Schema(description = "URLs or file paths to supporting documents", 
            example = "[\"https://example.com/doc1.pdf\", \"https://example.com/flowchart.png\"]")
    @JsonProperty("supportingDocuments")
    private List<String> supportingDocuments;

    @Schema(description = "Additional comments or notes", 
            example = "This idea has been discussed with the team lead and has initial approval")
    @JsonProperty("additionalComments")
    private String additionalComments;
}

