/*
 * @(#)$RCSfile: CAccessPointFaultInfo.java,v $ $Revision: 1.2 $ $Date: 2014/07/28 14:57:07 $ $Author: aputintsev $ 
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/types/CAccessPointFaultInfo.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *     $Log: CAccessPointFaultInfo.java,v $
 *     Revision 1.2  2014/07/28 14:57:07  aputintsev
 *     forked from production version - projects_src/applications/accesspoint
 *
 *     Revision 1.1.2.1  2009/08/13 13:24:23  asolntsev
 *     Created by St.Petersburg team
 *
 *     Revision 1.1.1.1  2009/07/31 11:24:26  banton
 *     Task 39986 1.1
 *
 *     Revision 1.1  2009/07/27 14:29:43  banton
 *     Fixed user exceptions
 *
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hireright.applications.accesspoint.types;

import javax.xml.bind.annotation.XmlType;


/**
 *
 * @author banton
 */
@XmlType(
    name = "CAccessPointFaultInfo",
    namespace = "http://hireright.com/applications/accesspoint/types",
    propOrder= {"message"} )
public class CAccessPointFaultInfo
{
    private String message;

    public CAccessPointFaultInfo()
    {
    }

    public CAccessPointFaultInfo(String message)
    {
        this.message = message;
    }

    public String getMessage()
    {
        return message;
    }

    public void setMessage(String message)
    {
        this.message = message;
    }
}


