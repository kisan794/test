package com.hireright.sourceintelligence.exception;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ErrorResponse implements Serializable {
    private static final long serialVersionUID = 1L;
    private List<ErrorRecord> errors;
    private boolean success;
}
