package com.hireright.migrationservice.service;

import com.hireright.migrationservice.domain.*;
import com.hireright.migrationservice.dto.InstitutionRecord;
import com.hireright.migrationservice.repository.SourceRepository;
import com.hireright.migrationservice.repository.VendorRepository;
import com.hireright.migrationservice.util.StateMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class MigrationService {
    
    private final SourceRepository sourceRepository;
    private final VendorRepository vendorRepository;
    
    private static final String PARCHMENT_EXCHANGE = "Parchment Exchange";
    private static final String CONTACT_TYPE_AUTOMATED_SERVICES = "contactAutomatedServices";
    private static final String SOURCE_TYPE_EDUCATION = "Education";
    private static final String CURRENCY_USD = "USD";
    private static final String TIME_UNIT_DAYS = "days";
    
    /**
     * Process institution records and update MongoDB
     */
    @Transactional
    public Map<String, Object> processInstitutionRecords(List<InstitutionRecord> records) {
        int totalRecords = records.size();
        int updatedRecords = 0;
        int notFoundRecords = 0;
        List<String> notFoundInstitutions = new ArrayList<>();
        
        // Get Parchment Exchange vendor information
        Vendor vendor = vendorRepository.findByVendor(PARCHMENT_EXCHANGE)
            .orElseThrow(() -> new RuntimeException("Vendor 'Parchment Exchange' not found in database"));
        
        log.info("Found vendor: {} with providerId: {}", vendor.getVendor(), vendor.getProviderId());
        
        for (InstitutionRecord record : records) {
            try {
                boolean updated = processInstitutionRecord(record, vendor);
                if (updated) {
                    updatedRecords++;
                } else {
                    notFoundRecords++;
                    notFoundInstitutions.add(record.getInstitutionName());
                }
            } catch (Exception e) {
                log.error("Error processing record: {}", record.getInstitutionName(), e);
                notFoundRecords++;
                notFoundInstitutions.add(record.getInstitutionName() + " (Error: " + e.getMessage() + ")");
            }
        }
        
        Map<String, Object> result = new HashMap<>();
        result.put("totalRecords", totalRecords);
        result.put("updatedRecords", updatedRecords);
        result.put("notFoundRecords", notFoundRecords);
        result.put("notFoundInstitutions", notFoundInstitutions);
        
        log.info("Processing complete. Total: {}, Updated: {}, Not Found: {}", 
            totalRecords, updatedRecords, notFoundRecords);
        
        return result;
    }
    
    /**
     * Process a single institution record
     */
    private boolean processInstitutionRecord(InstitutionRecord record, Vendor vendor) {
        // Convert state abbreviation to full name if needed
        String stateFullName = StateMapper.getFullName(record.getStateCountyRegion());
        if (stateFullName.isEmpty() && !record.getStateCountyRegion().isEmpty()) {
            // If not a valid abbreviation, use as-is (might already be full name or region)
            stateFullName = record.getStateCountyRegion();
        }
        
        log.debug("Searching for institution: {}, City: {}, Country: {}, State: {}", 
            record.getInstitutionName(), record.getCity(), record.getCountry(), stateFullName);
        
        // Find matching source in database
        Optional<Source> sourceOpt = sourceRepository.findByOrganizationNameAndCityAndCountryAndState(
            record.getInstitutionName(),
            record.getCity(),
            record.getCountry(),
            stateFullName
        );
        
        if (sourceOpt.isEmpty()) {
            log.warn("Institution not found: {}", record.getInstitutionName());
            return false;
        }
        
        Source source = sourceOpt.get();
        log.info("Found matching institution: {} (HON: {})", source.getOrganizationName(), source.getHon());
        
        // Update or add Parchment Exchange contact
        updateParchmentExchangeContact(source, record, vendor);
        
        // Save updated source
        sourceRepository.save(source);
        log.info("Updated institution: {}", source.getOrganizationName());
        
        return true;
    }
    
    /**
     * Update or add Parchment Exchange contact to source
     */
    private void updateParchmentExchangeContact(Source source, InstitutionRecord record, Vendor vendor) {
        Payload payload = source.getPayload();
        if (payload == null) {
            payload = new Payload();
            source.setPayload(payload);
        }
        
        List<Contact> contacts = payload.getContacts();
        if (contacts == null) {
            contacts = new ArrayList<>();
            payload.setContacts(contacts);
        }
        
        // Find or create the main contact entry
        Contact contact = contacts.isEmpty() ? null : contacts.get(0);
        if (contact == null) {
            contact = Contact.builder()
                .purpose("")
                .purposeRule(new ArrayList<>())
                .contactDetails(new ArrayList<>())
                .build();
            contacts.add(contact);
        }
        
        List<ContactDetail> contactDetails = contact.getContactDetails();
        if (contactDetails == null) {
            contactDetails = new ArrayList<>();
            contact.setContactDetails(contactDetails);
        }
        
        // Check if contactAutomatedServices already exists
        ContactDetail automatedServicesContact = findContactDetailByType(contactDetails, CONTACT_TYPE_AUTOMATED_SERVICES);
        
        if (automatedServicesContact == null) {
            // Create new contactAutomatedServices
            automatedServicesContact = createAutomatedServicesContact();
            contactDetails.add(automatedServicesContact);
            log.debug("Created new contactAutomatedServices");
        }
        
        // Update or add Parchment Exchange communication
        updateParchmentExchangeCommunication(automatedServicesContact, record, vendor);
    }
    
    /**
     * Find contact detail by type
     */
    private ContactDetail findContactDetailByType(List<ContactDetail> contactDetails, String type) {
        return contactDetails.stream()
            .filter(cd -> type.equals(cd.getType()))
            .findFirst()
            .orElse(null);
    }
    
    /**
     * Create new automated services contact detail
     */
    private ContactDetail createAutomatedServicesContact() {
        return ContactDetail.builder()
            .followUpAllowed("")
            .type(CONTACT_TYPE_AUTOMATED_SERVICES)
            .priority(1)
            .version("")
            .turnAroundTime("")
            .surChargeAmount("")
            .name("")
            .paymentMethod("")
            .turnAroundTimeUnit(TIME_UNIT_DAYS)
            .surChargeCurrency("")
            .communication(new ArrayList<>())
            .fromYear("")
            .toYear("")
            .build();
    }
    
    /**
     * Update or add Parchment Exchange communication
     */
    private void updateParchmentExchangeCommunication(ContactDetail contactDetail, InstitutionRecord record, Vendor vendor) {
        List<Communication> communications = contactDetail.getCommunication();
        if (communications == null) {
            communications = new ArrayList<>();
            contactDetail.setCommunication(communications);
        }
        
        // Check if Parchment Exchange already exists
        Communication parchmentComm = communications.stream()
            .filter(c -> PARCHMENT_EXCHANGE.equals(c.getName()))
            .findFirst()
            .orElse(null);
        
        if (parchmentComm == null) {
            // Calculate priority (max priority + 1)
            int maxPriority = communications.stream()
                .map(Communication::getPriority)
                .filter(Objects::nonNull)
                .max(Integer::compareTo)
                .orElse(0);
            
            int newPriority = maxPriority + 1;
            
            // Create new Parchment Exchange communication
            parchmentComm = createParchmentExchangeCommunication(record, vendor, newPriority);
            communications.add(parchmentComm);
            log.debug("Added Parchment Exchange communication with priority: {}", newPriority);
        } else {
            // Update existing communication
            updateCommunicationInfo(parchmentComm.getCommunicationInfo(), record, vendor);
            log.debug("Updated existing Parchment Exchange communication");
        }
    }

    /**
     * Create new Parchment Exchange communication
     */
    private Communication createParchmentExchangeCommunication(InstitutionRecord record, Vendor vendor, int priority) {
        List<CommunicationInfo> communicationInfoList = createCommunicationInfoList(record, vendor);

        return Communication.builder()
            .name(PARCHMENT_EXCHANGE)
            .communicationInfo(communicationInfoList)
            .providerID(String.valueOf(vendor.getProviderId()))
            .priority(priority)
            .build();
    }

    /**
     * Create communication info list
     */
    private List<CommunicationInfo> createCommunicationInfoList(InstitutionRecord record, Vendor vendor) {
        List<CommunicationInfo> infoList = new ArrayList<>();

        // Add all required fields
        infoList.add(createCommunicationInfo("companyNames", record.getInstitutionName()));
        infoList.add(createCommunicationInfo("codes", record.getCode()));
        infoList.add(createCommunicationInfo("branch", ""));
        infoList.add(createCommunicationInfo("uri", vendor.getWebsite()));
        infoList.add(createCommunicationInfo("sourceType", SOURCE_TYPE_EDUCATION));

        // Surcharge amount and currency
        String surchargeAmount = record.getSurchargeAmount() != null ? record.getSurchargeAmount() : "";
        String currency = "USA".equalsIgnoreCase(record.getCountry()) ? CURRENCY_USD : "";
        infoList.add(createCommunicationInfo("surChargeAmount", surchargeAmount));
        infoList.add(createCommunicationInfo("surChargeCurrency", currency));

        // Payment method
        String paymentMethod = record.getPaymentMethod() != null ? record.getPaymentMethod() : "";
        infoList.add(createCommunicationInfo("paymentMethod", paymentMethod));

        // Follow-up allowed
        String followUpAllowed = record.getFollowUpAllowed() != null ? record.getFollowUpAllowed() : "";
        infoList.add(createCommunicationInfo("followUpAllowed", followUpAllowed));
        infoList.add(createCommunicationInfo("followUpAllowedAfter", ""));
        infoList.add(createCommunicationInfo("followUpAllowedAfterTimeUnit", TIME_UNIT_DAYS));

        // Turnaround time
        String turnaroundTime = record.getTurnaroundTime() != null ? record.getTurnaroundTime() : "";
        infoList.add(createCommunicationInfo("turnAroundTime", turnaroundTime));
        infoList.add(createCommunicationInfo("turnAroundTimeUnit", TIME_UNIT_DAYS));

        // Year range
        infoList.add(createCommunicationInfo("fromYear", ""));
        infoList.add(createCommunicationInfo("toYear", ""));

        return infoList;
    }

    /**
     * Create communication info object
     */
    private CommunicationInfo createCommunicationInfo(String type, String value) {
        return CommunicationInfo.builder()
            .type(type)
            .value(value != null ? value : "")
            .build();
    }

    /**
     * Update existing communication info
     */
    private void updateCommunicationInfo(List<CommunicationInfo> communicationInfoList, InstitutionRecord record, Vendor vendor) {
        if (communicationInfoList == null) {
            return;
        }

        // Update specific fields
        updateInfoValue(communicationInfoList, "companyNames", record.getInstitutionName());
        updateInfoValue(communicationInfoList, "codes", record.getCode());
        updateInfoValue(communicationInfoList, "uri", vendor.getWebsite());

        String surchargeAmount = record.getSurchargeAmount() != null ? record.getSurchargeAmount() : "";
        String currency = "USA".equalsIgnoreCase(record.getCountry()) ? CURRENCY_USD : "";
        updateInfoValue(communicationInfoList, "surChargeAmount", surchargeAmount);
        updateInfoValue(communicationInfoList, "surChargeCurrency", currency);

        String paymentMethod = record.getPaymentMethod() != null ? record.getPaymentMethod() : "";
        updateInfoValue(communicationInfoList, "paymentMethod", paymentMethod);

        String followUpAllowed = record.getFollowUpAllowed() != null ? record.getFollowUpAllowed() : "";
        updateInfoValue(communicationInfoList, "followUpAllowed", followUpAllowed);

        String turnaroundTime = record.getTurnaroundTime() != null ? record.getTurnaroundTime() : "";
        updateInfoValue(communicationInfoList, "turnAroundTime", turnaroundTime);
    }

    /**
     * Update a specific communication info value by type
     */
    private void updateInfoValue(List<CommunicationInfo> communicationInfoList, String type, String value) {
        communicationInfoList.stream()
            .filter(info -> type.equals(info.getType()))
            .findFirst()
            .ifPresent(info -> info.setValue(value != null ? value : ""));
    }
}
