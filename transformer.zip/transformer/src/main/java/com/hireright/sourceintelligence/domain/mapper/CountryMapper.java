package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.rds.CountryDTO;
import com.hireright.sourceintelligence.api.dto.rds.CountryRegionDTO;
import com.hireright.sourceintelligence.domain.entity.Country;
import com.hireright.sourceintelligence.domain.entity.CountryRegion;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mapstruct.ReportingPolicy.IGNORE;

@Mapper(componentModel = "spring", unmappedTargetPolicy = IGNORE)
public interface CountryMapper {

    @Mapping(target = "countryId", expression = "java(convertBigDecimalToString(entity.getCountryId()))")
    @Mapping(target = "name", expression = "java(entity.getName())")
    @Mapping(target = "courtIntlCharge", expression = "java(convertBigDecimalToString(entity.getCourtIntlCharge()))")
    @Mapping(target = "eduIntlCharge", expression = "java(convertBigDecimalToString(entity.getEduIntlCharge()))")
    @Mapping(target = "emplIntlCharge", expression = "java(convertBigDecimalToString(entity.getEmplIntlCharge()))")
    @Mapping(target = "mvrIntlCharge", expression = "java(convertBigDecimalToString(entity.getMvrIntlCharge()))")
    @Mapping(target = "refIntlCharge", expression = "java(convertBigDecimalToString(entity.getRefIntlCharge()))")
    @Mapping(target = "currency", expression = "java(entity.getCurrency())")
    @Mapping(target = "dateFormat", expression = "java(entity.getDateFormat())")
    @Mapping(target = "phoneCountryCode", expression = "java(entity.getPhoneCountryCode())")
    @Mapping(target = "ssnEquivalent", expression = "java(entity.getSsnEquivalent())")
    @Mapping(target = "stateEquivalent", expression = "java(entity.getStateEquivalent())")
    @Mapping(target = "zipEquivalent", expression = "java(entity.getZipEquivalent())")
    @Mapping(target = "courtSearchLevel", expression = "java(entity.getCourtSearchLevel())")
    @Mapping(target = "dobRequired", expression = "java(entity.getDobRequired())")
    @Mapping(target = "timezone", expression = "java(convertBigDecimalToString(entity.getTimezone()))")
    @Mapping(target = "dobInquiry", expression = "java(entity.getDobInquiry())")
    @Mapping(target = "nidInquiry", expression = "java(entity.getNidInquiry())")
    @Mapping(target = "nidRequired", expression = "java(entity.getNidRequired())")
    @Mapping(target = "birthPlaceRequired", expression = "java(entity.getBirthPlaceRequired())")
    @Mapping(target = "birthPlaceSendToVerifier", expression = "java(entity.getBirthPlaceSendToVerifier())")
    @Mapping(target = "obsolete", expression = "java(entity.getObsolete())")
    @Mapping(target = "financeRegion", expression = "java(entity.getFinanceRegion())")
    @Mapping(target = "supportRegion", expression = "java(entity.getSupportRegion())")
    @Mapping(target = "table", expression = "java(entity.getTable())")
    @Mapping(target = "scn", expression = "java(entity.getScn())")
    @Mapping(target = "opType", expression = "java(entity.getOpType())")
    @Mapping(target = "opTs", expression = "java(createTimestampObject(entity.getOpTs()))")
    @Mapping(target = "currentTs", expression = "java(createTimestampObject(entity.getCurrentTs()))")
    @Mapping(target = "rowId", expression = "java(entity.getRowId())")
    @Mapping(target = "username", expression = "java(entity.getUsername())")
    CountryDTO entityToDTO(Country entity);

    List<CountryDTO> entityToDTOList(List<Country> entityList);

    @Mapping(target = "id", expression = "java(convertIntegerToString(entity.getRegionId()))")
    @Mapping(target = "countryId", expression = "java(convertIntegerToString(entity.getCountryId()))")
    @Mapping(target = "oldRegionId", expression = "java(convertIntegerToString(entity.getOldRegionId()))")
    @Mapping(target = "regionName", expression = "java(entity.getRegionName())")
    @Mapping(target = "parentId", expression = "java(convertIntegerToString(entity.getParentId()))")
    @Mapping(target = "regionLevel", expression = "java(convertIntegerToString(entity.getRegionLevel()))")
    @Mapping(target = "iso31662", expression = "java(entity.getIso31662())")
    @Mapping(target = "obsolete", expression = "java(entity.getObsolete())")
    @Mapping(target = "table", expression = "java(entity.getTable())")
    @Mapping(target = "scn", expression = "java(entity.getScn())")
    @Mapping(target = "opType", expression = "java(entity.getOpType())")
    @Mapping(target = "opTs", expression = "java(createTimestampObject(entity.getOpTs()))")
    @Mapping(target = "currentTs", expression = "java(createTimestampObject(entity.getCurrentTs()))")
    @Mapping(target = "rowId", expression = "java(entity.getRowId())")
    @Mapping(target = "username", expression = "java(entity.getUsername())")
    @Mapping(target = "hrCode", expression = "java(entity.getHrCode())")
    @Mapping(target = "areaCodes", expression = "java(entity.getAreaCodes())")
    CountryRegionDTO entityToRegionDTO(CountryRegion entity);

    List<CountryRegionDTO> entityToRegionDTOList(List<CountryRegion> entityList);

    default String convertBigDecimalToString(BigDecimal value) {
        if (value == null) {
            return "0";
        }
        return value.stripTrailingZeros().toPlainString();
    }

    default String convertIntegerToString(Integer value) {
        if (value == null) {
            return null;
        }
        return String.valueOf(value);
    }

    default Object createTimestampObject(String timestamp) {
        if (timestamp == null || timestamp.equals("null")) {
            return null;
        }
        Map<String, String> timestampMap = new HashMap<>();
        timestampMap.put("$timestamp", timestamp);
        return timestampMap;
    }
}

