package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.notification.DataExtractionNotificationDTO;
import com.hireright.sourceintelligence.api.dto.notification.NotificationRequestDTO;
import com.hireright.sourceintelligence.api.dto.notification.NotificationResponseDTO;
import com.hireright.sourceintelligence.service.notification.DataExtractionNotificationService;
import com.hireright.sourceintelligence.service.notification.NotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Controller for notification operations
 * Following Single Responsibility Principle - only handles HTTP request/response mapping
 * Following Dependency Inversion Principle - depends on service abstractions
 */
@Slf4j
@RestController
@RequiredArgsConstructor
@Validated
@CrossOrigin
public class NotificationApiController implements NotificationApi {
    
    private final List<NotificationService> notificationServices;
    private final DataExtractionNotificationService dataExtractionNotificationService;
    
    @Override
    public ResponseEntity<NotificationResponseDTO> sendNotification(NotificationRequestDTO request) {
        log.info("Received notification request - Type: {}, RequestID: {}", 
                request.getNotificationType(), request.getRequestId());
        
        // Strategy Pattern - select the appropriate notification service
        NotificationService notificationService = notificationServices.stream()
                .filter(service -> service.supports(request))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException(
                        "No notification service found for type: " + request.getNotificationType()));
        
        NotificationResponseDTO response = notificationService.sendNotification(request);
        
        log.info("Notification request processed - Status: {}, NotificationID: {}", 
                response.getStatus(), response.getNotificationId());
        
        return ResponseEntity.ok(response);
    }
    
    @Override
    public ResponseEntity<NotificationResponseDTO> sendDataExtractionNotification(
            DataExtractionNotificationDTO notification) {
        log.info("Received data extraction notification request - Type: {}, Recipients: {}", 
                notification.getDataExtractionType(), notification.getRecipients());
        
        NotificationResponseDTO response = dataExtractionNotificationService
                .sendDataExtractionNotification(notification);
        
        log.info("Data extraction notification processed - Status: {}", response.getStatus());
        
        return ResponseEntity.ok(response);
    }
}

