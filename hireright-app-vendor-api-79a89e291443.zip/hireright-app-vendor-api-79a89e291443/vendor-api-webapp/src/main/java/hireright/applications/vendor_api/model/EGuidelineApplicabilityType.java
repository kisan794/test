/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-08-18	Created
 */
package hireright.applications.vendor_api.model;

public enum EGuidelineApplicabilityType
{
	COMMON("Common"),
	CUSTOM("Custom");

	private String stringValue;

	public String stringValue()
	{
		return stringValue;
	}

	public static EGuidelineApplicabilityType forIdentifier(Long id)
	{
		if (id == null)
			return null;
		if (id == 0L)
			return COMMON;
		return CUSTOM;
	}

	public static EGuidelineApplicabilityType forIdentifier(Integer id)
	{
		return id == null ? null : forIdentifier(id.longValue());
	}

	public static EGuidelineApplicabilityType ofStringValue(String stringValue)
	{
		for (EGuidelineApplicabilityType qualifier : values())
		{
			if (qualifier.stringValue.equals(stringValue))
				return qualifier;
		}
		
		return null;
	}

	EGuidelineApplicabilityType(String value)
	{
		this.stringValue = value;
	}
}
