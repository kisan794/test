package com.hireright.sourceintelligence.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Document(collection = "language")
public class Language {

    @Id
    @Field("_id")
    private ObjectId id;

    @Field("languageEn")
    private String languageEn;

    @Field("languageTrans")
    private String languageTrans;

    @Field("languageCode")
    private String languageCode;

    @Field("country")
    private List<String> country;

    @Field("region")
    private List<String> region;

    @Field("location")
    private String location;
}

