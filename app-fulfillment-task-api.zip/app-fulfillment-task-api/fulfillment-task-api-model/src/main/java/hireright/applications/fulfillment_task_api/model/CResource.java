package hireright.applications.fulfillment_task_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-13  HRG-332327 initial version
 * M.Naumov   2025-05-16  HRG-337113 adding orderFormInstructions
 */

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import hireright.applications.fulfillment_task_api.model.serialization.CLocalDateTimeDeserializer;
import hireright.applications.fulfillment_task_api.model.serialization.CLocalDateTimeSerializer;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Objects;

public class CResource<META, DATA> implements Serializable {
    @JsonProperty ("kind")
    private EKind m_kind;

    @JsonProperty ("meta")
    private META m_meta;

    @JsonProperty ("transactionId")
    private String m_sTransactionID;

    @JsonProperty ("timestamp")
    @JsonDeserialize (using = CLocalDateTimeDeserializer.class)
    @JsonSerialize (using = CLocalDateTimeSerializer.class)
    private LocalDateTime m_timestamp;

    @JsonProperty ("data")
    private DATA m_data;

    @JsonProperty ("links")
    private Collection<String> m_links = new HashSet<>();

    @JsonProperty ("errors")
    private Collection<CError> m_errors = new HashSet<>();

    protected CResource() {
    }

    protected CResource(Builder<META, DATA> builder) {
        this.m_kind = builder.m_kind;
        this.m_meta = builder.m_meta;
        this.m_sTransactionID = builder.m_sTransactionID;
        this.m_timestamp = builder.m_timestamp;
        this.m_data = builder.m_data;
        this.m_links.addAll(builder.m_links);
        this.m_errors.addAll(builder.m_errors);
    }

    public EKind getKind() {
        return this.m_kind;
    }

    public META getMeta() {
        return this.m_meta;
    }

    public String getTransactionID() {
        return this.m_sTransactionID;
    }

    public LocalDateTime getTimestamp() {
        return this.m_timestamp;
    }

    public DATA getData() {
        return this.m_data;
    }

    public Collection<String> getLinks() {
        return this.m_links != null ? new HashSet<>(this.m_links) : Collections.emptySet();
    }

    public Collection<CError> getErrors() {
        return this.m_errors != null ? new HashSet<>(this.m_errors) : Collections.emptySet();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CResource<?, ?> cResource = (CResource<?, ?>) o;

        if (this.m_kind != cResource.m_kind) {
            return false;
        }
        if (!Objects.equals(this.m_meta, cResource.m_meta)) {
            return false;
        }
        if (!Objects.equals(this.m_sTransactionID, cResource.m_sTransactionID)) {
            return false;
        }
        if (!Objects.equals(this.m_timestamp, cResource.m_timestamp)) {
            return false;
        }
        if (!Objects.equals(this.m_data, cResource.m_data)) {
            return false;
        }
        if (!Objects.equals(this.m_links, cResource.m_links)) {
            return false;
        }
        return Objects.equals(this.m_errors, cResource.m_errors);
    }

    @Override
    public int hashCode() {
        int result = this.m_kind != null ? this.m_kind.hashCode() : 0;
        result = 31 * result + (this.m_meta != null ? this.m_meta.hashCode() : 0);
        result = 31 * result + (this.m_sTransactionID != null ? this.m_sTransactionID.hashCode() : 0);
        result = 31 * result + (this.m_timestamp != null ? this.m_timestamp.hashCode() : 0);
        result = 31 * result + (this.m_data != null ? this.m_data.hashCode() : 0);
        result = 31 * result + (this.m_links != null ? this.m_links.hashCode() : 0);
        result = 31 * result + (this.m_errors != null ? this.m_errors.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "CResource{" + "m_kind=" + this.m_kind + ", m_meta=" + this.m_meta + ", m_sTransactionID='" +
                this.m_sTransactionID +
                '\'' + ", m_timestamp=" + this.m_timestamp + ", m_data=" + this.m_data + ", m_links=" + this.m_links + ", m_errors=" +
                this.m_errors + '}';
    }

    public enum EKind {
        STATUS("status"),
        ERROR("error"),
        FLEX_FIELD_LIST_ITEM("flexFieldListItem"),
        FLEX_FIELD_LIST_ITEM_LIST("flexFieldListItemList"),
        CUSTOMER_ACCOUNT("account"),
        CUSTOMER_ACCOUNT_LIST("accountList"),
        CUSTOMER_ACCOUNT_REFERENCE("accountReference"),
        CUSTOMER_ACCOUNT_REFERENCE_LIST("accountReferenceList"),
        INTEGRATION_PROFILE_REFERENCE("integrationProfileReference"),
        INTEGRATION_PROFILE_REFERENCE_LIST("integrationProfileReferenceList"),
        INTEGRATION_PROFILE("integrationProfile"),
        INTEGRATION_PROFILE_LIST("integrationProfileList"),
        USER_PERMISSION("userPermission"),
        USER_PERMISSION_LIST("userPermissionList"),
        PROPERTY("property"),
        PROPERTY_LIST("propertyList"),
        DOMAIN_REFERENCE("domainReference"),
        DOMAIN_REFERENCE_LIST("domainReferenceList"),
        USER_GROUP("userGroup"),
        USER_GROUP_LIST("userGroupList"),
        USER_GROUP_REFERENCE("userGroupReference"),
        USER_GROUP_REFERENCE_LIST("userGroupReferenceList"),
        SERVICE_DELIVERY_REPORTING("serviceDeliveryReporting"),
        SERVICE_DELIVERY_SERVICE_GUIDELINES("serviceDeliveryServiceGuidelines"),
        SERVICE_DELIVERY_INTEGRATIONS("serviceDeliveryIntegrations"),
        SERVICE_DELIVERY_ASRC("serviceDeliveryAsrc"),
        ACCOUNT_ACCESS_POLICY("accountAccessPolicy"),
        USER("user"),
        USER_LIST("userList"),
        USER_REFERENCE("userReference"),
        USER_REFERENCE_LIST("userReferenceList"),
        SERVICE_PACKAGE("servicePackage"),
        SERVICE_PACKAGE_LIST("servicePackageList"),
        CUSTOMER_SERVICE_PACKAGE("customerServicePackage"),
        CUSTOMER_SERVICE_PACKAGE_LIST("customerServicePackageList"),
        ROLLOUT_FEATURE_REFERENCE("rolloutFeatureReference"),
        ROLLOUT_FEATURE_REFERENCE_LIST("rolloutFeatureReferenceList"),
        ORDER_FORM_INSTRUCTIONS("orderFormInstructions"),
        ORDER_FORM_INSTRUCTIONS_LIST("orderFormInstructionsList"),
        ;

        private final String m_sValue;

        EKind(String sValue) {
            this.m_sValue = sValue;
        }

        @JsonValue
        @Override
        public String toString() {
            return this.m_sValue;
        }

        @JsonCreator
        public static EKind fromValue(String text) {
            if (text == null || text.trim().isEmpty()) {
                return null;
            }

            for (EKind entry : EKind.values()) {
                if (entry.m_sValue.equalsIgnoreCase(text)) {
                    return entry;
                }
            }
            return null;
        }
    }

    public static class Builder<META, DATA> {
        private EKind m_kind;
        protected META m_meta;
        private String m_sTransactionID;
        private LocalDateTime m_timestamp = LocalDateTime.now();
        protected DATA m_data;
        private final Collection<String> m_links = new HashSet<>();
        private final Collection<CError> m_errors = new HashSet<>();

        public Builder() {
        }

        public Builder(CResource<META, DATA> copy) {
            if (copy == null) {
                return;
            }

            this.m_kind = copy.getKind();
            this.m_meta = copy.getMeta();
            this.m_sTransactionID = copy.getTransactionID();
            this.m_timestamp = copy.getTimestamp();
            this.m_data = copy.getData();
            this.m_links.addAll(copy.getLinks());
            this.m_errors.addAll(copy.getErrors());
        }

        public Builder(DATA data) {
            this.m_data = data;
        }

        public Builder<META, DATA> kind(EKind kind) {
            this.m_kind = kind;
            return this;
        }

        public Builder<META, DATA> meta(META meta) {
            this.m_meta = meta;
            return this;
        }

        public Builder<META, DATA> transactionID(String sTransactionID) {
            this.m_sTransactionID = sTransactionID;
            return this;
        }

        public Builder<META, DATA> timestamp(LocalDateTime timestamp) {
            this.m_timestamp = timestamp;
            return this;
        }

        public Builder<META, DATA> data(DATA data) {
            this.m_data = data;
            return this;
        }

        public Builder<META, DATA> link(String sLink) {
            if (sLink != null) {
                this.m_links.add(sLink);
            }
            return this;
        }

        public Builder<META, DATA> links(Collection<String> links) {
            this.m_links.clear();
            if (links != null) {
                this.m_links.addAll(links);
            }
            return this;
        }

        public Builder<META, DATA> error(String sText) {
            return error(sText, null, null, null);
        }

        public Builder<META, DATA> error(String sText, String sDetails) {
            return error(sText, null, null, sDetails);
        }

        public Builder<META, DATA> error(String sText, String sPath, String sDetails) {
            return error(sText, sPath, null, sDetails);
        }

        public Builder<META, DATA> error(String sText, String sPath, String sID, String sDetails) {
            if (sText != null || sDetails != null) {
                this.m_errors.add(new CError.Builder().text(sText).path(sPath).id(sID).details(sDetails).build());
            }
            return this;
        }

        public Builder<META, DATA> error(CError error) {
            if (error != null) {
                this.m_errors.add(error);
            }
            return this;
        }

        public Builder<META, DATA> errors(Collection<CError> errors) {
            this.m_errors.clear();
            if (errors != null) {
                this.m_errors.addAll(errors);
            }
            return this;
        }

        public CResource<META, DATA> build() {
            if (this.m_timestamp == null) {
                this.m_timestamp = LocalDateTime.now();
            }
            return new CResource<>(this);
        }
    }
}
