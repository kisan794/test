package hireright.applications.permissions_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-16  HRG-330191 initial version
 */

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import hireright.applications.permissions_api.model.serialization.CLocalDateTimeDeserializer;
import hireright.applications.permissions_api.model.serialization.CLocalDateTimeSerializer;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Objects;

public class CResource<META, DATA>
{
	@JsonProperty("kind")
	private EKind m_kind;

	@JsonProperty("meta")
	private META m_meta;

	@JsonProperty("transactionId")
	private String m_sTransactionID;

	@JsonProperty("timestamp")
	@JsonDeserialize(using = CLocalDateTimeDeserializer.class)
	@JsonSerialize(using = CLocalDateTimeSerializer.class)
	private LocalDateTime m_timestamp;

	@JsonProperty("data")
	private DATA m_data;

	@JsonProperty("links")
	private Collection<String> m_links = new HashSet<>();

	@JsonProperty("errors")
	private Collection<CError> m_errors = new HashSet<>();

	protected CResource()
	{
	}

	protected CResource(Builder<META, DATA> builder)
	{
		m_kind = builder.m_kind;
		m_meta = builder.m_meta;
		m_sTransactionID = builder.m_sTransactionID;
		m_timestamp = builder.m_timestamp;
		m_data = builder.m_data;
		m_links.addAll(builder.m_links);
		m_errors.addAll(builder.m_errors);
	}

	public EKind getKind()
	{
		return m_kind;
	}

	public META getMeta()
	{
		return m_meta;
	}

	public String getTransactionID()
	{
		return m_sTransactionID;
	}

	public LocalDateTime getTimestamp()
	{
		return m_timestamp;
	}

	public DATA getData()
	{
		return m_data;
	}

	public Collection<String> getLinks()
	{
		return m_links != null ? new HashSet<>(m_links) : Collections.emptySet();
	}

	public Collection<CError> getErrors()
	{
		return m_errors != null ? new HashSet<>(m_errors) : Collections.emptySet();
	}

	@Override
	public boolean equals(Object o)
	{
		if(this == o)
		{
			return true;
		}
		if(o == null || getClass() != o.getClass())
		{
			return false;
		}

		CResource<?, ?> cResource = (CResource<?, ?>) o;

		if(m_kind != cResource.m_kind)
		{
			return false;
		}
		if(!Objects.equals(m_meta, cResource.m_meta))
		{
			return false;
		}
		if(!Objects.equals(m_sTransactionID, cResource.m_sTransactionID))
		{
			return false;
		}
		if(!Objects.equals(m_timestamp, cResource.m_timestamp))
		{
			return false;
		}
		if(!Objects.equals(m_data, cResource.m_data))
		{
			return false;
		}
		if(!Objects.equals(m_links, cResource.m_links))
		{
			return false;
		}
		return Objects.equals(m_errors, cResource.m_errors);
	}

	@Override
	public int hashCode()
	{
		int result = m_kind != null ? m_kind.hashCode() : 0;
		result = 31 * result + (m_meta != null ? m_meta.hashCode() : 0);
		result = 31 * result + (m_sTransactionID != null ? m_sTransactionID.hashCode() : 0);
		result = 31 * result + (m_timestamp != null ? m_timestamp.hashCode() : 0);
		result = 31 * result + (m_data != null ? m_data.hashCode() : 0);
		result = 31 * result + (m_links != null ? m_links.hashCode() : 0);
		result = 31 * result + (m_errors != null ? m_errors.hashCode() : 0);
		return result;
	}

	@Override
	public String toString()
	{
		return "CResource{" + "m_kind=" + m_kind + ", m_meta=" + m_meta + ", m_sTransactionID='"
			+ m_sTransactionID + '\'' + ", m_timestamp=" + m_timestamp + ", m_data=" + m_data
			+ ", m_links=" + m_links + ", m_errors=" + m_errors + '}';
	}

	public enum EKind
	{
		status("status"),
		error("error"),
		operatorPermissions("permissions:OperatorPermissions"),
		operator("operators:Operator"),
		operators("operators:Operators"),
		;

		private final String m_sValue;

		EKind(String sValue)
		{
			m_sValue = sValue;
		}

		@JsonValue
		public String toString()
		{
			return m_sValue;
		}

		@JsonCreator
		public static EKind fromValue(String text)
		{
			if(text == null || text.trim().isEmpty())
			{
				return null;
			}

			for(EKind entry : EKind.values())
			{
				if(entry.m_sValue.equalsIgnoreCase(text))
				{
					return entry;
				}
			}
			return null;
		}
	}

	public static class Builder<META, DATA>
	{
		private EKind m_kind;
		protected META m_meta;
		private String m_sTransactionID;
		private LocalDateTime m_timestamp = LocalDateTime.now();
		protected DATA m_data;
		private final Collection<String> m_links = new HashSet<>();
		private final Collection<CError> m_errors = new HashSet<>();

		public Builder()
		{
		}

		public Builder(CResource<META, DATA> copy)
		{
			if(copy == null)
			{
				return;
			}
			this.m_kind = copy.getKind();
			this.m_meta = copy.getMeta();
			this.m_sTransactionID = copy.getTransactionID();
			this.m_timestamp = copy.getTimestamp();
			this.m_data = copy.getData();
			this.m_links.addAll(copy.getLinks());
			this.m_errors.addAll(copy.getErrors());
		}

		public Builder<META, DATA> kind(EKind kind)
		{
			this.m_kind = kind;
			return this;
		}

		public Builder<META, DATA> meta(META meta)
		{
			this.m_meta = meta;
			return this;
		}

		public Builder<META, DATA> transactionID(String sTransactionID)
		{
			this.m_sTransactionID = sTransactionID;
			return this;
		}

		public Builder<META, DATA> timestamp(LocalDateTime timestamp)
		{
			if(timestamp != null)
			{
				this.m_timestamp = timestamp;
			}
			else
			{
				this.m_timestamp = null;
			}
			return this;
		}

		public Builder<META, DATA> data(DATA data)
		{
			this.m_data = data;
			return this;
		}

		public Builder<META, DATA> link(String sLink)
		{
			if(sLink != null)
			{
				this.m_links.add(sLink);
			}
			return this;
		}

		public Builder<META, DATA> links(Collection<String> links)
		{
			this.m_links.clear();
			if(links != null)
			{
				this.m_links.addAll(links);
			}
			return this;
		}

		public Builder<META, DATA> error(String sText)
		{
			return error(sText, null, null, null);
		}

		public Builder<META, DATA> error(String sText, String sDetails)
		{
			return error(sText, null, null, sDetails);
		}

		public Builder<META, DATA> error(String sText, String sPath, String sDetails)
		{
			return error(sText, sPath, null, sDetails);
		}

		public Builder<META, DATA> error(String sText, String sPath, String sID, String sDetails)
		{
			if(sText != null || sDetails != null)
			{
				this.m_errors.add(
					new CError.Builder().text(sText).path(sPath).id(sID).details(sDetails).build());
			}
			return this;
		}

		public Builder<META, DATA> error(CError error)
		{
			if(error != null)
			{
				this.m_errors.add(error);
			}
			return this;
		}

		public Builder<META, DATA> errors(Collection<CError> errors)
		{
			this.m_errors.clear();
			if(errors != null)
			{
				this.m_errors.addAll(errors);
			}
			return this;
		}

		public CResource<META, DATA> build()
		{
			if(m_timestamp == null)
			{
				m_timestamp = LocalDateTime.now();
			}
			return new CResource<>(this);
		}
	}
}
