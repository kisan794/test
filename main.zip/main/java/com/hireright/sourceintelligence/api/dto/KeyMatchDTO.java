package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value = JsonInclude.Include.NON_EMPTY, content = JsonInclude.Include.NON_NULL)
public class KeyMatchDTO {

  @NotNull
  private String key;

  private Boolean outOfBusiness;

  private String doNotContact;

  private String country;
  private String state;
  private String city;
  private String hon;

  @NotNull
  private Float score;

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || this.getClass() != o.getClass()) {
      return false;
    }
    KeyMatchDTO that = (KeyMatchDTO) o;

    EqualsBuilder eb = new EqualsBuilder();
    eb.append(this.getKey().toLowerCase(), that.getKey().toLowerCase());
    return eb.isEquals();
  }

  @Override
  public int hashCode() {
    HashCodeBuilder hcb = new HashCodeBuilder();
    hcb.append(key.toLowerCase());
    return hcb.toHashCode();
  }
}
