package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.searchindex.entity.ElasticsearchSource;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.text.similarity.JaroWinklerDistance;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.hireright.sourceintelligence.service.impl.SearchConstants.JaroFields.ORG_ALIAS;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.JaroFields.ORG_NAME;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SUGGESTIONS;

@Slf4j
@Component
public class DistanceAlgorithm {

    @Value("${jaroWinklerAlgo.distance.threshold}")
    private String algorithmThresholdForApplication;

    @Value("${suggestionThreshold}")
    private String suggestionThreshold;

    public Map<String, String> jaroWinklerAlgorithm(String sourceName, List<ElasticsearchSource> searchList) {
        sourceName = sourceName.trim().toLowerCase();
        double preferredConfidenceThreshold = Double.parseDouble(algorithmThresholdForApplication) / 100;
        log.info("threshold: {}", preferredConfidenceThreshold);
        double orgMaxRange = 0;
        double orgAliasMaxRange = 0;
        String finalOrgName = "";
        String finalOrgAlias = "";
        int matchCount = 0;
        JaroWinklerDistance jaroWinklerDistance = new JaroWinklerDistance();
        for (ElasticsearchSource searchSource : searchList) {
            if (orgMaxRange == 1 && orgAliasMaxRange == 1) break;
            double distanceForOrgName = 1 - jaroWinklerDistance.apply(sourceName, searchSource.getOrganizationName().trim().toLowerCase());
            log.info("org dist: {} ", distanceForOrgName);
            if (orgMaxRange <= distanceForOrgName && distanceForOrgName >= preferredConfidenceThreshold) {
                orgMaxRange = distanceForOrgName;
                finalOrgName = searchSource.getOrganizationName();
                matchCount++;
            }
            if (searchSource.getOrganizationAlias() != null && !searchSource.getOrganizationAlias().isEmpty()) {
                for (String alias : searchSource.getOrganizationAlias()) {
                    if (orgAliasMaxRange == 1) break;
                    double distanceForOrgAlias = 1 - jaroWinklerDistance.apply(sourceName, alias.trim().toLowerCase());
                    log.info("orgAlias dist for automatch: {} ", distanceForOrgAlias);
                    if (orgAliasMaxRange <= distanceForOrgAlias && distanceForOrgAlias >= preferredConfidenceThreshold) {
                        orgAliasMaxRange = distanceForOrgAlias;
                        finalOrgAlias = alias;
                        matchCount++;
                    }
                }
            }
        }
        log.info("Match count: {}", matchCount);
        Map<String, String> searchSourceMap = new HashMap<>();
        if (matchCount == searchList.size()) {
            finalResponseForAutomatchWithMatchZero(searchSourceMap, finalOrgName, finalOrgAlias);
        }else{
            finalResponseForAutomatch(searchSourceMap,finalOrgName, finalOrgAlias, orgMaxRange, orgAliasMaxRange);
        }
        return searchSourceMap;
    }

    private void finalResponseForAutomatchWithMatchZero(Map<String,String> searchSourceMap, String finalOrgName, String finalOrgAlias){
        if (!finalOrgName.isEmpty()) {
            searchSourceMap.put(ORG_NAME, finalOrgName);
            searchSourceMap.put(ORG_ALIAS, finalOrgName);
        } else if (!finalOrgAlias.isEmpty()) {
            searchSourceMap.put(ORG_NAME, finalOrgAlias);
            searchSourceMap.put(ORG_ALIAS, finalOrgAlias);
        }
    }

    private void finalResponseForAutomatch(Map<String,String> searchSourceMap, String finalOrgName, String finalOrgAlias, double orgMaxRange, double orgAliasMaxRange){
            if (orgMaxRange == orgAliasMaxRange) {
                if (!finalOrgName.isEmpty()) searchSourceMap.put(ORG_NAME, finalOrgName);
                if (!finalOrgAlias.isEmpty()) searchSourceMap.put(ORG_ALIAS, finalOrgAlias);
            } else if (orgMaxRange > orgAliasMaxRange) {
                if (!finalOrgName.isEmpty()) searchSourceMap.put(ORG_NAME, finalOrgName);
            } else {
                if (!finalOrgAlias.isEmpty()) searchSourceMap.put(ORG_ALIAS, finalOrgAlias);
            }
    }


    public Set<String> smartSearchJaroWinklerAlgorithmWithText(String name, List<ElasticsearchSource> searchList, String type) {
        Map<String, Double> mapList = new LinkedHashMap<>();
        JaroWinklerDistance jaroWinklerDistance = new JaroWinklerDistance();
        double threshold = 1.0;
        if(type.equals(SUGGESTIONS)){
            threshold = Double.parseDouble(suggestionThreshold)/100;
        }
        for (ElasticsearchSource searchSource : searchList) {
            double finalDistanceForSource;
            double distanceForOrgName = 1 - jaroWinklerDistance.apply(name.trim().toLowerCase(), searchSource.getOrganizationName().trim().toLowerCase());
            if (distanceForOrgName >= threshold) {
                finalDistanceForSource = distanceForOrgName;
                mapList.put(searchSource.getHon(), finalDistanceForSource);
            }
            if (searchSource.getOrganizationAlias() != null && !searchSource.getOrganizationAlias().isEmpty()) {
                orgAliasLogicWithText(name, searchSource, threshold, jaroWinklerDistance, mapList);
            }
        }
        Map<String, Double> sortedDesc = mapList.entrySet()
                .stream()
                .sorted(Map.Entry.<String, Double>comparingByValue().reversed()) // descending
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue,
                        (e1, e2) -> e1,
                        LinkedHashMap::new
                ));
        return sortedDesc.keySet();
    }

    public Set<String> jaroWinklerAlgorithmForDropDown(String name, List<ElasticsearchSource> searchList) {
        log.info("Jaro Drop down option starts: {}", Instant.now());
        Map<String, Map<String, Double>> mapList = new LinkedHashMap<>();
        Set<String> values = new HashSet<>();

        JaroWinklerDistance jaroWinklerDistance = new JaroWinklerDistance();
        for (ElasticsearchSource searchSource : searchList) {
            String orgName = searchSource.getOrganizationName().trim().toLowerCase();
            Double distanceForOrgName = 1 - jaroWinklerDistance.apply(name, orgName);
            if (!values.contains(orgName)) {
                values.add(orgName);
                Map<String, Double> val = new LinkedHashMap<>();
                val.put(searchSource.getOrganizationName().trim(), distanceForOrgName);
                mapList.put(searchSource.getHon(), val);
            }
        }
        for (ElasticsearchSource searchSource : searchList) {
            if (searchSource.getOrganizationAlias() != null && !searchSource.getOrganizationAlias().isEmpty()) {
                for (String alias : searchSource.getOrganizationAlias()) {
                    Double distanceForOrgAlias = 1 - jaroWinklerDistance.apply(name, alias.toLowerCase());
                    if (mapList.containsKey(searchSource.getHon())) {
                        Map<String, Double> val = mapList.get(searchSource.getHon());
                        Double dist = val.get(searchSource.getOrganizationName());
                        if (dist < distanceForOrgAlias) {
                            val.put(searchSource.getOrganizationName(), distanceForOrgAlias);
                            mapList.put(searchSource.getHon(), val);
                        }
                    }
                }
            }
        }
        return mapList.entrySet().stream()
                .flatMap(e -> e.getValue().entrySet().stream()
                        .map(inner -> Map.entry(inner.getKey(), inner.getValue()))
                )
                .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                .limit(25)
                .map(Map.Entry::getKey)
                .collect(Collectors.toCollection(LinkedHashSet::new));
    }


    private void orgAliasLogicWithText(String name, ElasticsearchSource searchSource, double threshold, JaroWinklerDistance jaroWinklerDistance, Map<String, Double> mapList){
        for (String alias : searchSource.getOrganizationAlias()) {
            double finalDistanceForAlias;
            double distanceForOrgAlias = 1 - jaroWinklerDistance.apply(name.trim().toLowerCase(), alias.trim().toLowerCase());
            if (distanceForOrgAlias >= threshold) {
                finalDistanceForAlias = distanceForOrgAlias;
                if (!mapList.containsKey(searchSource.getHon())) {
                    mapList.put(searchSource.getHon(), finalDistanceForAlias);
                } else {
                    if (finalDistanceForAlias > mapList.get(searchSource.getHon())) {
                        mapList.put(searchSource.getHon(), finalDistanceForAlias);
                    }
                }
            }
        }
    }

    public Set<String> jaroWinklerAlgorithmForDropDownRAM(String name, List<String> searchList) {
        log.info("Jaro Drop down option for RAM starts: {}", Instant.now());
        Set<String> values = new HashSet<>();
        Map<String, Double> mapList = new LinkedHashMap<>();
        JaroWinklerDistance jaroWinklerDistance = new JaroWinklerDistance();
        for (String organizationName : searchList) {
            String orgName = organizationName.trim().toLowerCase();
            Double distanceForOrgName = 1 - jaroWinklerDistance.apply(name, orgName);
            if (!values.contains(orgName)) {
                values.add(orgName);
                mapList.put(organizationName.trim(), distanceForOrgName);
            }
        }
        return mapList.entrySet()
                .stream()
                .sorted(Map.Entry.<String, Double>comparingByValue().reversed()) // descending
                .map(Map.Entry::getKey)
                .collect(Collectors.toCollection(LinkedHashSet::new));
    }
}
