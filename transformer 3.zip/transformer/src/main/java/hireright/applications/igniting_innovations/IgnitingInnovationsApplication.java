package hireright.applications.igniting_innovations;

import hireright.applications.igniting_innovations.util.Constant;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main Spring Boot Application for Igniting Innovations.
 * Provides idea submission and management services for continuous improvement initiatives.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@SpringBootApplication
@OpenAPIDefinition(info = @Info(title = Constant.TITLE,
        version = Constant.VERSION,
        description = Constant.DESCRIPTION))
public class IgnitingInnovationsApplication {

    private static final Logger logger = LoggerFactory.getLogger(IgnitingInnovationsApplication.class);

    /**
     * Main method to start the Spring Boot application.
     *
     * m args command line arguments
     */
    public static void main(String[] args) {
        logger.info("Starting Igniting Innovations Application...");

        try {
            SpringApplication.run(IgnitingInnovationsApplication.class, args);
            logger.info("Igniting Innovations Application started successfully");
        } catch (Exception e) {
            logger.error("Failed to start Igniting Innovations Application", e);
            System.exit(1);
        }
    }
}