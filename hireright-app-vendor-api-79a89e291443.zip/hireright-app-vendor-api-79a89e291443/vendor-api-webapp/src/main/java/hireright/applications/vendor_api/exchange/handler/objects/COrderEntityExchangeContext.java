/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-08-14	Created
 */
package hireright.applications.vendor_api.exchange.handler.objects;

/**
 * 
 */
public class COrderEntityExchangeContext<TransferType extends CEntityExchangeDTO> extends AEntityExchangeContext<TransferType>
{
	private Long m_orderID;

	public Long getOrderID()
	{
		return m_orderID;
	}

	public void setOrderID(Long orderID)
	{
		this.m_orderID = orderID;
	}
}
