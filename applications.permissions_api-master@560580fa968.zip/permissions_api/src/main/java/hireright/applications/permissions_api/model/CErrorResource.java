package hireright.applications.permissions_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-16  HRG-330191 initial version
 */

public class CErrorResource extends CResource<Void, Void>
{
	private CErrorResource()
	{
		super();
	}

	protected CErrorResource(Builder builder)
	{
		super(builder);
	}

	@Override
	public String toString()
	{
		return "CError{} " + super.toString();
	}

	public static class Builder extends CResource.Builder<Void, Void>
	{
		public Builder()
		{
			super();
		}

		public Builder(CResource<Void, Void> copy)
		{
			super(copy);
		}

		public Builder(CErrorResource copy)
		{
			super(copy);
		}

		@Override
		public CErrorResource build()
		{
			super.build();
			kind(EKind.error);
			return new CErrorResource(this);
		}
	}
}
