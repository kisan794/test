/*
 * @(#)$RCSfile: CAccessPoint.java,v $ $Revision: 1.4 $ $Date: 2009/08/13
 * 13:24:22 $ $Author: cvsroot $ $Source:
 * /usr/local/cvsroot/projects_src/applications
 * /accesspoint/webservice/src/main/java
 * /hireright/applications/accesspoint/service/CAccessPoint.java,v $
 *  
 * History:
 * 	A.Bakanovskiy	2009-07-23	Added some sources decorations
 * 	A.Bakanovskiy	2009-07-27	Fixed user exceptions
 * 	A.Bakanovskiy	2009-07-29	Fixed WSDL. Added WSDL for 'light'
 * 	A.Bakanovskiy	2009-07-30	Fixed connection workaround, fixed statemachine using
 * 								Added full multi value properties
 * 	A.Bakanovskiy	2009-07-31	Task 39986 1.1
 * 	A.Bakanovskiy	2009-08-06	Added simple Finite State Machine support. Tested only for memory storage
 * 								Fixed deleteEntryPointByKey method for DB storage
 * 								Phase 1.1 Edition
 *  A.Solntsev		2009-08-13	Created by St.Petersburg team
 * 	A.Solntsev		2009-08-18	Bugfixing and polishing
 *  A.Solntsev		2009-08-19	Bugfixing and polishing
 *  A.Putintsev		2014-07-28	forked from production version - projects_src/applications/accesspoint
 *  A.Putintsev		2014-09-22	migration to jboss7 & Spring WS
 *  A.Putintsev		2015-01-16	success parameter in doLogin() is removed
 */

package hireright.applications.accesspoint.service;

import hireright.applications.accesspoint.types.*;
import hireright.applications.accesspoint.util.CEntryPointFrameworkFactory;
import hireright.applications.accesspoint.util.IEntryPointFramework;
import hireright.objects.utilities.CEntryPoint;
import hireright.objects.utilities.CStateMachine;
import hireright.sdk.db.CCurrentThreadConnection;

import java.sql.Connection;
import java.util.logging.Logger;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.collections.MultiMap;
import org.springframework.stereotype.Service;

/**
 *
 * @author banton
 */
@Service
public class CAccessPoint implements IAccessPoint
{
	private static final Logger LOGGER = Logger.getLogger( CAccessPoint.class.getName() );
	
	static final int ENTRY_OK = 0;

	static final int ENTRIES_LIMEET_EXCEED = 1;

	static final int FALURES_LIMEET_EXCEED = 2;

	static final int TIME_EXPIRED = 3;

	static final String[] ERROR_MESSAGES =
	{
			"OK", "Entries limit exceed", "Falures limit exceed", "Time expired"
	};

	/**
	 * Interface for EntryPoint management
	 */
	private final IEntryPointFramework entryPointFramework;

	public CAccessPoint()
	{
		entryPointFramework = CEntryPointFrameworkFactory.createNewFramework();
	}

	/**
	 * Web service operation
	 */	
	public CreateResult create( String userID, String userClass,
			String entryPointType, String domainID,
			int designNr, String authenticationMode,
			String login, Integer entriesAllowed,
			Integer failuresAllowed,
			XMLGregorianCalendar expirationDate,
			Boolean createSession,
			CParametersListWrapper parametersListWrapper ) throws CAccessPointException
	{
		LOGGER.entering( CAccessPoint.class.getName(), "createEntryPoint" );
		try
		{
			MultiMap properties = CParametersListWrapper.toParameters( parametersListWrapper );
			CEntryPoint entryPoint = null;
			boolean useAuth = false;
	
			if ( CEntryPoint.AUTHENTICATION_MODE_LOGIN.equals( authenticationMode )
					|| CEntryPoint.AUTHENTICATION_MODE_LOGINPASS.equals( authenticationMode ) )
			{
				useAuth = true;
				if ( login == null || login.length() < 1 )
					throw new CAccessPointException( "Login can't be null if authenticationMode '" + authenticationMode
							+ "' is used" );
			}
			else if ( CEntryPoint.AUTHENTICATION_MODE_PASS.equals( authenticationMode ) )
				useAuth = true;

			entryPointFramework.setUp();

			try
			{
				if ( useAuth )
					entryPoint = entryPointFramework.createEntryPointAuth( userID, userClass, login, entryPointType, designNr,
							domainID, properties );
				else
					entryPoint = entryPointFramework.createEntryPointNoAuth( userID, userClass, entryPointType, designNr, domainID,
							properties );
	
				if ( entryPoint == null )
					throw new RuntimeException( "Can't create EntryPoint" );
	
				if ( authenticationMode == null )
					authenticationMode = CEntryPoint.AUTHENTICATION_MODE_NONE;
				entryPoint.setAuthenticationMode( authenticationMode );
	
				if ( entriesAllowed != null && entriesAllowed > 0 )
					entryPoint.setEntriesAllowed( entriesAllowed );
	
				if ( failuresAllowed != null && failuresAllowed > 0 )
					entryPoint.setFailuresAllowed( failuresAllowed );
	
				if ( expirationDate != null )
					entryPoint.setExpirationDate( expirationDate.toGregorianCalendar().getTime() );
	
				if ( createSession != null )
					entryPoint.setCreateSession( createSession ? CEntryPoint.CREATE_SESSION_YES : CEntryPoint.CREATE_SESSION_NO );
	
				entryPointFramework.saveEntryPoint( entryPoint );
	
				entryPointFramework.commit();
				
				final CreateResult result = new CreateResult();
				result.setKey( entryPoint.getKey() );
				result.setPassword( entryPoint.getPassword() );
				return result;
			}
			finally
			{
				entryPointFramework.rollback();
				entryPointFramework.tearDown();
			}
		}
		finally
		{
			LOGGER.exiting( CAccessPoint.class.getName(), "createEntryPoint" );
		}
	}

	public CEntryPointBean doLogin( String key )
			throws CAccessPointException
	{
		LOGGER.entering( CAccessPoint.class.getName(), "doLogin", new Object[]
		{
				key
		} );
		
		entryPointFramework.setUp();
		
		try
		{
			CEntryPoint entryPoint = entryPointFramework.getEntryPoint( key );
			int result = ENTRY_OK;
			// int event=-1;

			if ( entryPoint == null )
				throw new CAccessPointException( "Can't find EntryPoint for key '" + key + "'" );

			if ( CEntryPointFrameworkFactory.isTestMode() )
				return new CEntryPointBean( entryPoint );

			//
			// Check validity for EntryPoint
			//
			if ( !entryPoint.isAllowed() )
				result = ENTRIES_LIMEET_EXCEED;
			else if ( entryPoint.hasExceededFailures() )
				result = FALURES_LIMEET_EXCEED;
			else if ( entryPoint.isExpired() )
				result = TIME_EXPIRED;

			// We need change counters only if EP is OK, in any case state machine removes invalid EP
			if ( result == ENTRY_OK )
			{
				boolean updateResult = entryPoint.decreaseEntriesCounter();

				// Adjust entries counter
				if ( !updateResult )
					throw new CAccessPointException( "Error while updating entry point counter" );
			}

			CStateMachine stateMachine = entryPoint.getStateMachine();
			if ( stateMachine != null )
			{
				final Connection conn = CCurrentThreadConnection.getConnection();
				try
				{
					String sState = entryPoint.getStateMachine().getState();
					if ( !entryPoint.isAllowed()
							&& (CEntryPoint.STATE_WAIT_FOR_LOGIN.equals( sState ) || CEntryPoint.STATE_ACTIVE.equals( sState )) )
						entryPoint.getStateMachine().changeState( conn, CEntryPoint.CONDITION_LIMIT_OF_ENTRIES );

					if ( entryPoint.hasExceededFailures()
							&& (CEntryPoint.STATE_WAIT_FOR_LOGIN.equals( sState ) || CEntryPoint.STATE_ACTIVE.equals( sState )) )
						entryPoint.getStateMachine().changeState( conn, CEntryPoint.CONDITION_LIMIT_OF_FAILURES );

					if ( entryPoint.isExpired()
							&& (CEntryPoint.STATE_WAIT_FOR_LOGIN.equals( sState ) || CEntryPoint.STATE_ACTIVE.equals( sState )) )
						entryPoint.getStateMachine().changeState( conn, CEntryPoint.CONDITION_EXPIRE );
					
					entryPointFramework.commit();
				}
				catch (RuntimeException e)
				{
					entryPointFramework.rollback();
					throw e;
				}
				catch (Error e)
				{
					entryPointFramework.rollback();
					throw e;
				}
				finally
				{
					entryPointFramework.tearDown();
				}
			}

			//        if (!entryPoint.isAllowed())
			//            event = CStateMachineController.EV_LIMIT_OF_ENTRIES;
			//        else if (entryPoint.hasExceededFailures())
			//            event = CStateMachineController.EV_LIMIT_OF_FAILUREES;
			//        // �������������� ����������� ����������� ������� ������� � ���� ����� ������ ����
			//        else if (entryPoint.isExpired())
			//            event = CStateMachineController.EV_EXPIRE;
			//
			//        // Perform state machine action
			//        if (event!=CStateMachineController.INVALID_EVENT)
			//            CStateMachineController.getInstance().processEntryPoint(entryPoint, event, entryPointFramework);

			if ( result != ENTRY_OK )
				throw new CAccessPointException( "EntryPoint for key '" + key + "' in state " + ERROR_MESSAGES[result] );

			return new CEntryPointBean( entryPoint );
		}
		finally
		{
			LOGGER.exiting( CAccessPoint.class.getName(), "doLogin" );
		}
	}
}
