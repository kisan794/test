package hireright.applications.permissions_api.api.management;

/*
 * Copyright 2023 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2023-05-19  HRG-261594 initial version
 */

import hireright.applications.permissions_api.model.CCollection;

public interface IRecordManager<RECORD, KEY, SORT, FILTER>
{
	RECORD get(KEY key);

	CCollection<RECORD> list(Long lOffset, Integer nLimit, SORT sort, FILTER filter);

	default CCollection<RECORD> list(Long lOffset, Integer nLimit, FILTER filter)
	{
		return list(lOffset, nLimit, getDefaultSort(), filter);
	}

	SORT getDefaultSort();
}
