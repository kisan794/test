package hireright.applications.vendor_api.resources;
/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	2017-08-17	Created
 */

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

import hireright.applications.vendor_api.facades.ErrorResponseFacade;
import hireright.applications.vendor_api.facades.IdValueFacade;
import hireright.applications.vendor_api.model.CExchangeResponse;
import hireright.components.domain.dialects.vendor_api.BasicResponse;
import hireright.objects.is.CEventCreationException;
import hireright.sdk.db.CCurrentThreadConnection;
import hireright.sdk.db.sql.CCallableStatement;
import hireright.sdk.db3.DB;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CProperties;

public class AResource 
{
	@ExceptionHandler({Exception.class})
	public ResponseEntity<BasicResponse> handleErrror(Exception ex)
	{
		Long nErrorID = CTraceLog.error(ex);
		ErrorResponseFacade errorResponseFacade = new ErrorResponseFacade(nErrorID.toString(), ex.getMessage());
		
		return new ResponseEntity<BasicResponse>(errorResponseFacade.getBasicResponse(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@Deprecated
	protected BasicResponse transformResponse(CExchangeResponse originalResponse, String sResponseParamName)
	{
		BasicResponse response = new BasicResponse();
		response.getIdValues().addAll(new IdValueFacade()
				.set(sResponseParamName, originalResponse.getReference())
				.getAll());
		
		return response;
	}
	
	/*
	 * Used only for document sync.
	 */
	@Deprecated
	protected BigDecimal addFutureEvent(Integer nEventTypeID, String sDomainID, CProperties properties, Date dttmTriggeringDate)
	{
		String sStatement =
				"DECLARE \n" +
				"	nEventID NUMBER;\n" +
				"BEGIN \n" +
				"	is_events.add_futureEvent(nEventID, :nEventTypeID, :sDomainID, :sProperties, sysdate + 1/12);\n" +
				"	is_events_storage.set_stateDTTM(nEventID, :dttmTriggeringDate);\n"
				+ ":nEventID := nEventID;\n" +
				"END;";

		CCallableStatement stmt = new CCallableStatement(sStatement);
		try
		{
			stmt.setInteger("nEventTypeID", nEventTypeID);
			stmt.setString("sDomainID", sDomainID);
			stmt.setString("sProperties", properties.toString());
			stmt.setTimestamp("dttmTriggeringDate", dttmTriggeringDate);

			stmt.registerOutParameter("nEventID", Types.NUMERIC);

			stmt.execute(DB.connection());

			BigDecimal nEventID = (BigDecimal) stmt.getObject("nEventID");
			
			return nEventID;
		}
		catch (SQLException e)
		{
			CProperties params = new CProperties()
				.setProperty("nEventTypeID", nEventTypeID)
				.setProperty("sDomainID", sDomainID)
				.setProperties("eventProperties", properties)
				.setProperty("date", dttmTriggeringDate);
			throw new CEventCreationException(e, params);
		}
		finally
		{
			stmt.close();
		}
	}
}
