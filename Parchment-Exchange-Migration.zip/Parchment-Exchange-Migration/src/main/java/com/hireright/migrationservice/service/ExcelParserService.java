package com.hireright.migrationservice.service;

import com.hireright.migrationservice.dto.InstitutionRecord;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class ExcelParserService {
    
    /**
     * Parse Excel file and extract institution records
     * Expected columns:
     * 0: Institution Name
     * 1: Country
     * 2: City
     * 3: State / County / Region
     * 4: Service / Provider (Automated services/Online Providers)
     * 5: Surcharge Amount
     * 6: Payment Method
     * 7: Code
     * 8: Turnaround Time
     * 9: Follow-up Allowed
     */
    public List<InstitutionRecord> parseExcelFile(MultipartFile file) throws IOException {
        List<InstitutionRecord> records = new ArrayList<>();
        
        try (InputStream inputStream = file.getInputStream();
             Workbook workbook = new XSSFWorkbook(inputStream)) {
            
            Sheet sheet = workbook.getSheetAt(0);
            
            // Skip header row (row 0)
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) {
                    continue;
                }
                
                // Skip empty rows
                if (isRowEmpty(row)) {
                    continue;
                }
                
                InstitutionRecord record = InstitutionRecord.builder()
                    .institutionName(getCellValueAsString(row.getCell(0)))
                    .country(getCellValueAsString(row.getCell(1)))
                    .city(getCellValueAsString(row.getCell(2)))
                    .stateCountyRegion(getCellValueAsString(row.getCell(3)))
                    .serviceProvider(getCellValueAsString(row.getCell(4)))
                    .surchargeAmount(getCellValueAsString(row.getCell(5)))
                    .paymentMethod(getCellValueAsString(row.getCell(6)))
                    .code(getCellValueAsString(row.getCell(7)))
                    .turnaroundTime(getCellValueAsString(row.getCell(8)))
                    .followUpAllowed(getCellValueAsString(row.getCell(9)))
                    .build();
                
                records.add(record);
                log.debug("Parsed record: {}", record);
            }
        }
        
        log.info("Parsed {} records from Excel file", records.size());
        return records;
    }
    
    /**
     * Get cell value as string, handling different cell types
     */
    private String getCellValueAsString(Cell cell) {
        if (cell == null) {
            return "";
        }
        
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString();
                } else {
                    // Convert numeric to string without decimal point for whole numbers
                    double numericValue = cell.getNumericCellValue();
                    if (numericValue == (long) numericValue) {
                        return String.valueOf((long) numericValue);
                    } else {
                        return String.valueOf(numericValue);
                    }
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                return cell.getCellFormula();
            case BLANK:
                return "";
            default:
                return "";
        }
    }
    
    /**
     * Check if a row is empty
     */
    private boolean isRowEmpty(Row row) {
        if (row == null) {
            return true;
        }
        
        for (int cellNum = 0; cellNum < row.getLastCellNum(); cellNum++) {
            Cell cell = row.getCell(cellNum);
            if (cell != null && cell.getCellType() != CellType.BLANK && 
                !getCellValueAsString(cell).isEmpty()) {
                return false;
            }
        }
        return true;
    }
}

