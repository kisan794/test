package com.hireright.sourceintelligence.api.dto.notification;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for email attachments
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AttachmentDTO {
    
    @NotNull(message = "Attachment filename is required")
    private String filename;
    
    @NotNull(message = "Attachment content is required")
    private byte[] content;
    
    private String contentType;
}

