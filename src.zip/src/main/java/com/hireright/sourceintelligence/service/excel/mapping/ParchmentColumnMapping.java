package com.hireright.sourceintelligence.service.excel.mapping;

import com.hireright.sourceintelligence.service.excel.ExcelColumnMapping;

public class ParchmentColumnMapping {

    private ParchmentColumnMapping() {

    }

    public static final String INSTITUTION_NAME = "institutionName";
    public static final String COUNTRY = "country";
    public static final String CITY = "city";
    public static final String STATE_COUNTY_REGION = "stateCountyRegion";
    public static final String SERVICE_PROVIDER = "serviceProvider";
    public static final String SURCHARGE_AMOUNT = "surchargeAmount";
    public static final String PAYMENT_METHOD = "paymentMethod";
    public static final String CODE = "code";
    public static final String TURNAROUND_TIME = "turnaroundTime";
    public static final String FOLLOW_UP_ALLOWED = "followUpAllowed";

    private static final int COL_INSTITUTION_NAME = 0;
    private static final int COL_COUNTRY = 1;
    private static final int COL_CITY = 2;
    private static final int COL_STATE_COUNTY_REGION = 3;
    private static final int COL_SERVICE_PROVIDER = 4;
    private static final int COL_SURCHARGE_AMOUNT = 5;
    private static final int COL_PAYMENT_METHOD = 6;
    private static final int COL_CODE = 7;
    private static final int COL_TURNAROUND_TIME = 8;
    private static final int COL_FOLLOW_UP_ALLOWED = 9;

    public static ExcelColumnMapping create() {
        return ExcelColumnMapping.builder()
                .addColumn(INSTITUTION_NAME, COL_INSTITUTION_NAME)
                .addColumn(COUNTRY, COL_COUNTRY)
                .addColumn(CITY, COL_CITY)
                .addColumn(STATE_COUNTY_REGION, COL_STATE_COUNTY_REGION)
                .addColumn(SERVICE_PROVIDER, COL_SERVICE_PROVIDER)
                .addColumn(SURCHARGE_AMOUNT, COL_SURCHARGE_AMOUNT)
                .addColumn(PAYMENT_METHOD, COL_PAYMENT_METHOD)
                .addColumn(CODE, COL_CODE)
                .addColumn(TURNAROUND_TIME, COL_TURNAROUND_TIME)
                .addColumn(FOLLOW_UP_ALLOWED, COL_FOLLOW_UP_ALLOWED)
                .headerRowIndex(0)
                .dataStartRowIndex(1)
                .sheetIndex(0)
                .build();
    }
}