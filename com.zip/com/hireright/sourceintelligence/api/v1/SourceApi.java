package com.hireright.sourceintelligence.api.v1;

import static com.hireright.sourceintelligence.api.ApiConstants.*;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.*;
import static com.hireright.sourceintelligence.api.ApiConstants.SearchParams.*;
import static com.hireright.sourceintelligence.api.ApiConstants.VERSION;
import static com.hireright.sourceintelligence.api.ApiDescriptions.LAST_VERIFIED_DATA_UPDATE_DESCRIPTION;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchResponseDTO;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.exception.ApiError;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;


import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RequestMapping(value = BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH)
@Tag(name = "SourceOrganization", description = "Endpoints for managing Source Organizations")
public interface SourceApi {

    @Operation(summary = "Create a SourceOrganization", tags = {"SourceOrganization"},
            responses = {
                    @ApiResponse(description = "Created", responseCode = "201",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = SourceOrganizationDTO.class))),
                    @ApiResponse(description = "Source Organization Not found", responseCode = "404",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Internal error", responseCode = "500",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))})
    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping(value = SOURCE_ORGANIZATION, consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<SourceOrganizationDTO> createSourceOrganization(
            @Valid @RequestBody SourceRequestDTO sourceRequest, HttpServletRequest httpServletRequest);

    @Operation(summary = "Update an existing SourceOrganization", tags = {"SourceOrganization"},
            responses = {
                    @ApiResponse(description = "OK", responseCode = "200",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = SourceOrganizationDTO.class))),
                    @ApiResponse(description = "Invalid JSON Payload", responseCode = "401",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Source Organization Not found", responseCode = "404",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Internal error", responseCode = "500",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))})
    @ResponseStatus(HttpStatus.OK)
    @PutMapping(value = SOURCE_ORGANIZATION + HON_PATH_VAR,
            consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<SourceOrganizationDTO> updateSourceOrganization(
            @PathVariable(value = HON) @NotBlank final String hon,
            @Valid @RequestBody SourceRequestDTO sourceRequest, HttpServletRequest httpServletRequest);


    @Operation(summary = "Archive SourceOrganization", tags = {"SourceOrganization"},
            responses = {
                    @ApiResponse(description = "OK", responseCode = "200",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = SourceRequestDTO.class))),
                    @ApiResponse(description = "Invalid JSON Payload", responseCode = "401",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Source Organization Not found", responseCode = "404",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Internal error", responseCode = "500",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))})
    @ResponseStatus(HttpStatus.OK)
    @PutMapping(value = SOURCE_ORGANIZATION +ARCHIVE_PATH + HON_PATH_VAR,
            consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<ResponseObject> archiveSource(
            @PathVariable(value = HON) @NotNull final String hon,
            @Valid @RequestBody SourceRequestDTO sourceRequestDTO, HttpServletRequest httpServletRequest);


    @Operation(summary = "Find a SourceOrganization using hon", tags = {"SourceOrganization"},
            responses = {
                    @ApiResponse(description = "Source Organization Found", responseCode = "200",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = SourceOrganizationDTO.class))),
                    @ApiResponse(description = "Source Organization Not found", responseCode = "404",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Internal error", responseCode = "500",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))})
    @ResponseStatus(HttpStatus.OK)
    @GetMapping(value = SOURCE_ORGANIZATION + HON_PATH_VAR,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<SourceOrganizationDTO> getSourceOrganization(
            @PathVariable(value = HON) @NotNull final String hon,
            @RequestParam(value="mode") String mode,
            @RequestParam(value = "approvalStatus", required = false) ApprovalStatus approvalStatus,
            @RequestParam(value = "action", required = false) String action,
            @RequestParam(value = "isRam", required = false)  Boolean isRam,
            @RequestParam(value = "version", required = false) Double version,
            @RequestParam(value = "tempVersion", required = false) Double tempVersion);

    @Operation(summary = "Updates source organization with data when last verified",
            description = LAST_VERIFIED_DATA_UPDATE_DESCRIPTION,
            tags = {"SourceOrganization"},
            responses = {
                    @ApiResponse(description = "OK", responseCode = "200"),
                    @ApiResponse(description = "Invalid JSON Payload", responseCode = "401",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Source Organization Not found", responseCode = "404",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Internal error", responseCode = "500",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))})
    @ResponseStatus(HttpStatus.OK)
    @PutMapping(value = SOURCE_ORGANIZATION + HON_PATH_VAR + VERIFY,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<AutoMatchResponseDTO> updateVerificationData(
            @PathVariable(value = HON) @NotBlank final String hon,
            @Valid @RequestBody VerificationRequest verificationRequest);

    @Operation(summary = "Get sourceOrganizations by hon ids", tags = {"SourceOrganization"},
            responses = {
                    @ApiResponse(description = "Source Organizations Found", responseCode = "200",
                            content = @Content(mediaType = "application/json",
                                    array = @ArraySchema(schema = @Schema(implementation = SourceOrganizationDTO.class)))),
                    @ApiResponse(description = "Source Organizations Not found", responseCode = "404",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Internal error", responseCode = "500",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))})
    @ResponseStatus(HttpStatus.OK)
    @PostMapping(value = SOURCE_ORGANIZATIONS,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<List<SourceOrganizationDTO>> getSourceOrganizationsByHonIds(
            @RequestBody List<String> honIds);

        @Operation(summary = "Assign Approve manager to Source", tags = {"SourceOrganization"},
            responses = {
                    @ApiResponse(description = "OK", responseCode = "200",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = SourceOrganizationDTO.class))),
                    @ApiResponse(description = "Invalid JSON Payload", responseCode = "401",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Source Organization Not found", responseCode = "404",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Internal error", responseCode = "500",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))})
    @ResponseStatus(HttpStatus.OK)
    @PutMapping(value = SOURCE_ORGANIZATION + ASSIGN,
            consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<ResponseObject> assignApproveManagerToSource(@RequestBody ApprovalRequestDTO approvalRequestDTO);

    @Operation(summary = "prioritize a source organization",
            description = "updates priority flag",
            tags = {"SourceOrganization"},
            responses = {
                    @ApiResponse(description = "OK", responseCode = "200"),
                    @ApiResponse(description = "Invalid JSON Payload", responseCode = "401",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Source Organization Not found", responseCode = "404",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Internal error", responseCode = "500",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))})
    @ResponseStatus(HttpStatus.OK)
    @PutMapping(value = SOURCE_ORGANIZATION + HON_PATH_VAR + FORWARD_SLASH + VERSION + VERSION_PATH_VAR + FLAG)
    ResponseEntity<ResponseObject> updateFlagForPriority(@PathVariable(value = HON) @NotBlank final String hon,
                                                         @PathVariable(value = VERSION) @NotNull final Double version);


    @Operation(summary = "Find a SourceOrganization using hon", tags = {"SourceOrganization"},
            responses = {
                    @ApiResponse(description = "Source Organization Found", responseCode = "200",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = SourceOrganizationDTO.class))),
                    @ApiResponse(description = "Source Organization Not found", responseCode = "404",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Internal error", responseCode = "500",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))})
    @ResponseStatus(HttpStatus.OK)
    @PutMapping(value = SOURCE_ORGANIZATION +INCREMENT_USED_COUNT,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Boolean> updateUsedCount(
            @RequestBody UsedCountIncrementDTO usedCountIncrementDTO);


    @Operation(summary = "Delete a Source using hon", tags = {"SourceOrganization"},
            responses = {
                    @ApiResponse(description = "Source get Deleted", responseCode = "200",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = SourceOrganizationDTO.class))),
                    @ApiResponse(description = "Source Organization Not found", responseCode = "404",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Internal error", responseCode = "500",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))})
    @ResponseStatus(HttpStatus.OK)
    @DeleteMapping(value = SOURCE_ORGANIZATION +DELETE_SOURCE+HON_PATH_VAR,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<ResponseObject> deleteSource(
            @PathVariable String hon, @RequestBody DeleteRequestDTO deleteRequestDTO);


    @Operation(summary = "Lock source", tags = {"SourceOrganization"},
            responses = {
                    @ApiResponse(description = "Source Organization Found", responseCode = "200",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = SourceOrganizationDTO.class))),
                    @ApiResponse(description = "Source Organization Not found", responseCode = "404",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Internal error", responseCode = "500",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))})
    @ResponseStatus(HttpStatus.OK)
    @PutMapping(value = SOURCE_ORGANIZATION +LOCK_SOURCE+HON_PATH_VAR,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<ResponseObject> lockSource(
            @PathVariable String hon, @RequestBody UIActionsDTO sourceRequestDTO);


    @Operation(summary = "Unlock source using hon", tags = {"SourceOrganization"},
            responses = {
                    @ApiResponse(description = "Source Organization Found", responseCode = "200",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = SourceOrganizationDTO.class))),
                    @ApiResponse(description = "Source Organization Not found", responseCode = "404",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Internal error", responseCode = "500",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))})
    @ResponseStatus(HttpStatus.OK)
    @PutMapping(value = SOURCE_ORGANIZATION + UNLOCK_SOURCE + HON_PATH_VAR,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<ResponseObject> unlockSource(
            @PathVariable String hon, @RequestBody UIActionsDTO sourceRequestDTO);


    @Operation(summary = "update the status of the source (In_Progress)",
            description = "updates source status",
            tags = {"SourceOrganization"},
            responses = {
                    @ApiResponse(description = "OK", responseCode = "200"),
                    @ApiResponse(description = "Invalid JSON Payload", responseCode = "401",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Source Organization Not found", responseCode = "404",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Internal error", responseCode = "500",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))})
    @ResponseStatus(HttpStatus.OK)
    @PutMapping(value = SOURCE_ORGANIZATION + HON_PATH_VAR + UPDATE_STATUS + STATUS_PATH_VAR)
    ResponseEntity<ResponseObject> updateSourceStatus(@PathVariable(value = HON) @NotBlank final String hon,
                                                      @PathVariable(value = STATUS) @NotBlank final ApprovalStatus approvalStatus,
                                                      @RequestParam(value = VERSION) @NotNull final String version,
                                                      @RequestParam(value = TEMP_VERSION) @NotNull final String tempVersion);



}
