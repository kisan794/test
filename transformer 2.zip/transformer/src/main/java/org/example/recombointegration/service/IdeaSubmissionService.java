package org.example.recombointegration.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.recombointegration.dto.*;
import org.example.recombointegration.document.IdeaSubmission;
import org.example.recombointegration.document.IdeaSubmission.IdeaStatus;
import org.example.recombointegration.repository.IdeaSubmissionRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Service for managing idea submissions.
 * Handles business logic for creating, updating, and retrieving ideas.
 *
 * @author Generated
 * @version 1.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class IdeaSubmissionService {

    private final IdeaSubmissionRepository ideaSubmissionRepository;

    /**
     * Create a new idea submission.
     */
    public IdeaSubmissionResponse createIdea(IdeaSubmissionRequest request) {
        log.info("Creating new idea submission: {}", request.getTitle());

        LocalDateTime now = LocalDateTime.now();

        IdeaSubmission idea = IdeaSubmission.builder()
                .title(request.getTitle())
                .submittedBy(request.getSubmittedBy())
                .emailAddress(request.getEmailAddress())
                .department(request.getDepartment())
                .submissionDate(now)
                .description(request.getDescription())
                .objective(request.getObjective())
                .impactAreas(request.getImpactAreas())
                .improvementTypes(request.getImprovementTypes())
                .improvementTypeOther(request.getImprovementTypeOther())
                .expectedBenefit(request.getExpectedBenefit())
                .impactCategories(request.getImpactCategories())
                .impactCategoryOther(request.getImpactCategoryOther())
                .implementationComplexity(request.getImplementationComplexity())
                .suggestedSteps(request.getSuggestedSteps())
                .timelineType(request.getTimelineType())
                .supportingDocuments(request.getSupportingDocuments())
                .additionalComments(request.getAdditionalComments())
                .status(IdeaStatus.SUBMITTED)
                .upvoteCount(0)
                .createdAt(now)
                .updatedAt(now)
                .comments(new ArrayList<>())
                .build();

        IdeaSubmission savedIdea = ideaSubmissionRepository.save(idea);
        log.info("Idea submission created successfully with ID: {}", savedIdea.getId());

        return mapToResponse(savedIdea);
    }

    /**
     * Get idea by ID.
     */
    public IdeaSubmissionResponse getIdeaById(String id) {
        log.info("Fetching idea with ID: {}", id);
        IdeaSubmission idea = ideaSubmissionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Idea not found with ID: " + id));
        return mapToResponse(idea);
    }

    /**
     * Get all ideas with pagination.
     */
    public Page<IdeaSubmissionResponse> getAllIdeas(Pageable pageable) {
        log.info("Fetching all ideas with pagination");
        return ideaSubmissionRepository.findAll(pageable)
                .map(this::mapToResponse);
    }

    /**
     * Get ideas by status.
     */
    public Page<IdeaSubmissionResponse> getIdeasByStatus(IdeaStatus status, Pageable pageable) {
        log.info("Fetching ideas with status: {}", status);
        return ideaSubmissionRepository.findByStatus(status, pageable)
                .map(this::mapToResponse);
    }

    /**
     * Get ideas by submitter.
     */
    public Page<IdeaSubmissionResponse> getIdeasBySubmitter(String submittedBy, Pageable pageable) {
        log.info("Fetching ideas submitted by: {}", submittedBy);
        return ideaSubmissionRepository.findBySubmittedBy(submittedBy, pageable)
                .map(this::mapToResponse);
    }

    /**
     * Get ideas by department.
     */
    public Page<IdeaSubmissionResponse> getIdeasByDepartment(String department, Pageable pageable) {
        log.info("Fetching ideas from department: {}", department);
        return ideaSubmissionRepository.findByDepartment(department, pageable)
                .map(this::mapToResponse);
    }

    /**
     * Search ideas by keyword.
     */
    public Page<IdeaSubmissionResponse> searchIdeas(String keyword, Pageable pageable) {
        log.info("Searching ideas with keyword: {}", keyword);
        return ideaSubmissionRepository.searchByKeyword(keyword, pageable)
                .map(this::mapToResponse);
    }

    /**
     * Get top ideas by upvotes.
     */
    public Page<IdeaSubmissionResponse> getTopIdeas(Pageable pageable) {
        log.info("Fetching top ideas by upvotes");
        return ideaSubmissionRepository.findAllByOrderByUpvoteCountDesc(pageable)
                .map(this::mapToResponse);
    }

    /**
     * Update idea status.
     */
    public IdeaSubmissionResponse updateIdeaStatus(String id, IdeaStatusUpdateRequest request) {
        log.info("Updating status for idea ID: {} to {}", id, request.getStatus());

        IdeaSubmission idea = ideaSubmissionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Idea not found with ID: " + id));

        idea.setStatus(request.getStatus());
        idea.setReviewedBy(request.getReviewedBy());
        idea.setReviewComments(request.getReviewComments());
        idea.setReviewedAt(LocalDateTime.now());
        idea.setUpdatedAt(LocalDateTime.now());

        IdeaSubmission updatedIdea = ideaSubmissionRepository.save(idea);
        log.info("Idea status updated successfully");

        return mapToResponse(updatedIdea);
    }

    /**
     * Upvote an idea.
     */
    public IdeaSubmissionResponse upvoteIdea(String id) {
        log.info("Upvoting idea ID: {}", id);

        IdeaSubmission idea = ideaSubmissionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Idea not found with ID: " + id));

        idea.setUpvoteCount(idea.getUpvoteCount() + 1);
        IdeaSubmission updatedIdea = ideaSubmissionRepository.save(idea);

        log.info("Idea upvoted successfully. New count: {}", updatedIdea.getUpvoteCount());
        return mapToResponse(updatedIdea);
    }

    /**
     * Add comment to an idea.
     */
    public IdeaCommentResponse addComment(String ideaId, IdeaCommentRequest request) {
        log.info("Adding comment to idea ID: {}", ideaId);

        IdeaSubmission idea = ideaSubmissionRepository.findById(ideaId)
                .orElseThrow(() -> new RuntimeException("Idea not found with ID: " + ideaId));

        IdeaSubmission.IdeaComment comment = IdeaSubmission.IdeaComment.builder()
                .id(UUID.randomUUID().toString())
                .commenterName(request.getCommenterName())
                .commenterEmail(request.getCommenterEmail())
                .comment(request.getComment())
                .createdAt(LocalDateTime.now())
                .build();

        idea.getComments().add(comment);
        idea.setUpdatedAt(LocalDateTime.now());

        IdeaSubmission updatedIdea = ideaSubmissionRepository.save(idea);
        log.info("Comment added successfully");

        return mapCommentToResponse(comment);
    }

    /**
     * Get comments for an idea.
     */
    public List<IdeaCommentResponse> getComments(String ideaId) {
        log.info("Fetching comments for idea ID: {}", ideaId);
        IdeaSubmission idea = ideaSubmissionRepository.findById(ideaId)
                .orElseThrow(() -> new RuntimeException("Idea not found with ID: " + ideaId));

        return idea.getComments().stream()
                .map(this::mapCommentToResponse)
                .collect(Collectors.toList());
    }

    /**
     * Delete an idea.
     */
    public void deleteIdea(String id) {
        log.info("Deleting idea with ID: {}", id);
        if (!ideaSubmissionRepository.existsById(id)) {
            throw new RuntimeException("Idea not found with ID: " + id);
        }
        ideaSubmissionRepository.deleteById(id);
        log.info("Idea deleted successfully");
    }

    /**
     * Get dashboard statistics.
     */
    public Map<String, Object> getDashboardStats() {
        log.info("Fetching dashboard statistics");

        Map<String, Object> stats = new HashMap<>();

        // Total ideas
        stats.put("totalIdeas", ideaSubmissionRepository.count());

        // Ideas by status
        Map<String, Long> statusMap = new HashMap<>();
        for (IdeaStatus status : IdeaStatus.values()) {
            long count = ideaSubmissionRepository.findByStatus(status, Pageable.unpaged()).getTotalElements();
            statusMap.put(status.name(), count);
        }
        stats.put("ideasByStatus", statusMap);

        // Ideas by department - simplified version
        List<IdeaSubmission> allIdeas = ideaSubmissionRepository.findAll();
        Map<String, Long> deptMap = allIdeas.stream()
                .collect(Collectors.groupingBy(
                        idea -> idea.getDepartment() != null ? idea.getDepartment() : "Unknown",
                        Collectors.counting()
                ));
        stats.put("ideasByDepartment", deptMap);

        return stats;
    }

    // Helper methods
    private IdeaSubmissionResponse mapToResponse(IdeaSubmission idea) {
        return IdeaSubmissionResponse.builder()
                .id(idea.getId())
                .title(idea.getTitle())
                .submittedBy(idea.getSubmittedBy())
                .emailAddress(idea.getEmailAddress())
                .department(idea.getDepartment())
                .submissionDate(idea.getSubmissionDate())
                .description(idea.getDescription())
                .objective(idea.getObjective())
                .impactAreas(idea.getImpactAreas())
                .improvementTypes(idea.getImprovementTypes())
                .improvementTypeOther(idea.getImprovementTypeOther())
                .expectedBenefit(idea.getExpectedBenefit())
                .impactCategories(idea.getImpactCategories())
                .impactCategoryOther(idea.getImpactCategoryOther())
                .implementationComplexity(idea.getImplementationComplexity())
                .suggestedSteps(idea.getSuggestedSteps())
                .timelineType(idea.getTimelineType())
                .supportingDocuments(idea.getSupportingDocuments())
                .additionalComments(idea.getAdditionalComments())
                .status(idea.getStatus())
                .upvoteCount(idea.getUpvoteCount())
                .createdAt(idea.getCreatedAt())
                .updatedAt(idea.getUpdatedAt())
                .reviewedAt(idea.getReviewedAt())
                .reviewedBy(idea.getReviewedBy())
                .reviewComments(idea.getReviewComments())
                .comments(idea.getComments() != null ? idea.getComments().stream()
                        .map(this::mapCommentToResponse)
                        .collect(Collectors.toList()) : new ArrayList<>())
                .build();
    }

    private IdeaCommentResponse mapCommentToResponse(IdeaSubmission.IdeaComment comment) {
        return IdeaCommentResponse.builder()
                .id(comment.getId())
                .commenterName(comment.getCommenterName())
                .commenterEmail(comment.getCommenterEmail())
                .comment(comment.getComment())
                .createdAt(comment.getCreatedAt())
                .build();
    }
}

