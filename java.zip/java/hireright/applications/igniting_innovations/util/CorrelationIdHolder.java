package hireright.applications.igniting_innovations.util;

import org.slf4j.MDC;

import java.util.UUID;

/**
 * Utility class for managing correlation IDs using SLF4J's MDC (Mapped Diagnostic Context).
 * Correlation IDs are used to track requests across multiple services and components.
 * <p>
 * This class provides thread-safe correlation ID management by leveraging MDC,
 * which maintains a per-thread context map.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
public class CorrelationIdHolder {

    /**
     * MDC key for storing correlation ID.
     */
    public static final String CORRELATION_ID_KEY = "correlationId";

    /**
     * HTTP header name for correlation ID.
     */
    public static final String CORRELATION_ID_HEADER = "X-Correlation-ID";

    private CorrelationIdHolder() {
    }

    /**
     * Generates a new correlation ID and sets it in MDC.
     *
     * @return the generated correlation ID
     */
    public static String generate() {
        String correlationId = UUID.randomUUID().toString();
        set(correlationId);
        return correlationId;
    }

    /**
     * Sets the correlation ID in MDC.
     *
     *  correlationId the correlation ID to set
     */
    public static void set(String correlationId) {
        if (correlationId != null && !correlationId.isEmpty()) {
            MDC.put(CORRELATION_ID_KEY, correlationId);
        }
    }

    /**
     * Removes the correlation ID from MDC.
     */
    public static void clear() {
        MDC.remove(CORRELATION_ID_KEY);
    }

}

