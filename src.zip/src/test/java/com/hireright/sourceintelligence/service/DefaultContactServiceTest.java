package com.hireright.sourceintelligence.service;
import com.hireright.sourceintelligence.api.dto.ContactDTO;
import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.exception.InvalidRequestException;
import com.hireright.sourceintelligence.service.impl.ContactServiceImpl;
import com.hireright.sourceintelligence.util.TestDataProvider;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DefaultContactServiceTest {

    @InjectMocks
    private ContactServiceImpl contactService;


    @Mock
    private SourceService sourceOrganizationService;

    @Test
    void updateContactTest() {
        ContactDTO contactDTO = TestDataProvider.getContactDTO();
        SourceOrganizationDTO orgEntity = TestDataProvider.getSourceOrganizationDTO();
        //orgEntity.setId(TestDataProvider.getDummyObjectId());
        when(sourceOrganizationService.getSourceByHon(anyString())).thenReturn(orgEntity);
        assertThatNoException().isThrownBy(() -> contactService.updateContact(contactDTO, TestDataProvider.getUserInfo()));
    }

    @Test
    void updateContactTest_ShouldThrowServiceExceptionTwo() {
        ContactDTO contactDTO = TestDataProvider.getContactDTO();
        SourceOrganizationDTO orgEntity = TestDataProvider.getSourceOrganizationDTO();
        orgEntity.setStatus(SourceOrganizationStatus.INACTIVE);
        when(sourceOrganizationService.getSourceByHon(anyString())).thenReturn(orgEntity);
        final var userInfo = TestDataProvider.getUserInfo();

        assertThatExceptionOfType(InvalidRequestException.class)
                .isThrownBy(() -> contactService.updateContact(contactDTO, userInfo));
    }
}