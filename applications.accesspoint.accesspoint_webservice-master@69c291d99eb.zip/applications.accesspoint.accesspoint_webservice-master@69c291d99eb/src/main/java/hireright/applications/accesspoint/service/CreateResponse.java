/*
 * @(#)$RCSfile: CreateResponse.java,v $ $Revision: 1.2 $ $Date: 2014/07/28 14:56:58 $
 * $Author: aputintsev $
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/service/CreateResponse.java,v $
 *
 * Copyright 2006-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * Toha Bakanovsky	2009-08-06	Created
 */
package hireright.applications.accesspoint.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for createResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="createResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="return" type="{http://hireright.com/applications/accesspoint/service}createResult" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createResponse", propOrder = {
		"_return"
})
public class CreateResponse {

		@XmlElement(name = "return")
		protected CreateResult _return;

		/**
		 * Gets the value of the return property.
		 * 
		 * @return
		 *     possible object is
		 *     {@link CreateResult }
		 *     
		 */
		public CreateResult getReturn() {
				return _return;
		}

		/**
		 * Sets the value of the return property.
		 * 
		 * @param value
		 *     allowed object is
		 *     {@link CreateResult }
		 *     
		 */
		public void setReturn(CreateResult value) {
				this._return = value;
		}

}
