package com.hireright.sourceintelligence.service.notification;

import com.hireright.sourceintelligence.api.dto.notification.EmailNotificationDTO;
import com.hireright.sourceintelligence.api.dto.notification.NotificationRequestDTO;
import com.hireright.sourceintelligence.domain.entity.FailedNotification;
import com.hireright.sourceintelligence.domain.repository.FailedNotificationRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Service for managing the Dead Letter Queue for failed notifications.
 * Follows Single Responsibility Principle - only handles DLQ operations.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DeadLetterQueueService {
    
    private final FailedNotificationRepository failedNotificationRepository;
    private final EmailNotificationService emailNotificationService;
    private final ObjectMapper objectMapper;
    
    @Value("${notification.dlq.enabled:true}")
    private boolean dlqEnabled;
    
    @Value("${notification.dlq.maxRetries:5}")
    private int maxRetries;
    
    @Value("${notification.dlq.retryDelay:300000}")
    private long retryDelayMs; // 5 minutes default
    
    /**
     * Adds a failed notification to the DLQ
     */
    public void addToDeadLetterQueue(NotificationRequestDTO request, 
                                      String notificationId, 
                                      Exception exception) {
        if (!dlqEnabled) {
            log.debug("DLQ is disabled, skipping");
            return;
        }
        
        try {
            log.info("Adding notification to DLQ - ID: {}", notificationId);
            
            FailedNotification failedNotification = FailedNotification.builder()
                    .notificationId(notificationId)
                    .requestId(request.getRequestId())
                    .notificationType(request.getNotificationType().name())
                    .emailContent(serializeEmailContent(request.getEmailNotification()))
                    .recipientList(serializeRecipients(request.getEmailNotification()))
                    .retryCount(0)
                    .maxRetries(maxRetries)
                    .failedAt(LocalDateTime.now())
                    .nextRetryAt(calculateNextRetryTime(0))
                    .errorMessage(exception.getMessage())
                    .exceptionType(exception.getClass().getName())
                    .stackTrace(getStackTrace(exception))
                    .permanentFailure(false)
                    .build();
            
            failedNotificationRepository.save(failedNotification);
            
            log.info("Notification added to DLQ successfully - ID: {}", notificationId);
            
        } catch (Exception e) {
            log.error("Failed to add notification to DLQ", e);
        }
    }
    
    /**
     * Processes the DLQ - retries failed notifications
     * Runs every 5 minutes
     */
    @Scheduled(fixedDelayString = "${notification.dlq.retryDelay:300000}")
    public void processDLQ() {
        if (!dlqEnabled) {
            return;
        }
        
        log.info("Processing Dead Letter Queue");
        
        try {
            List<FailedNotification> retryableNotifications = 
                    failedNotificationRepository.findRetryableNotifications(maxRetries, LocalDateTime.now());
            
            log.info("Found {} notifications to retry", retryableNotifications.size());
            
            for (FailedNotification notification : retryableNotifications) {
                retryNotification(notification);
            }
            
            // Alert on permanent failures
            long permanentFailureCount = failedNotificationRepository.countByPermanentFailureTrue();
            if (permanentFailureCount > 0) {
                log.warn("Total permanent failures in DLQ: {}", permanentFailureCount);
                // In production, this would trigger an alert to operations team
            }
            
        } catch (Exception e) {
            log.error("Error processing DLQ", e);
        }
    }
    
    /**
     * Retries a single failed notification
     */
    private void retryNotification(FailedNotification notification) {
        log.info("Retrying notification - ID: {}, attempt: {}", 
                notification.getNotificationId(), 
                notification.getRetryCount() + 1);
        
        try {
            // Deserialize email content
            EmailNotificationDTO emailDTO = deserializeEmailContent(notification.getEmailContent());
            
            // Attempt to send
            emailNotificationService.sendEmail(emailDTO);
            
            // Success - remove from DLQ
            failedNotificationRepository.delete(notification);
            log.info("Notification retry successful - removed from DLQ: {}", 
                    notification.getNotificationId());
            
        } catch (Exception e) {
            log.error("Notification retry failed - ID: {}", notification.getNotificationId(), e);
            
            // Update retry count and schedule next retry
            notification.incrementRetryCount();
            notification.setErrorMessage(e.getMessage());
            notification.setNextRetryAt(calculateNextRetryTime(notification.getRetryCount()));
            
            failedNotificationRepository.save(notification);
            
            if (notification.getPermanentFailure()) {
                log.error("Notification reached max retries - marked as permanent failure: {}", 
                        notification.getNotificationId());
                // In production, this would trigger an alert
            }
        }
    }
    
    /**
     * Calculates next retry time with exponential backoff
     */
    private LocalDateTime calculateNextRetryTime(int retryCount) {
        // Exponential backoff: 5min, 10min, 20min, 40min, 80min
        long delayMs = retryDelayMs * (long) Math.pow(2, retryCount);
        return LocalDateTime.now().plusSeconds(delayMs / 1000);
    }
    
    /**
     * Serializes email content to JSON
     */
    private String serializeEmailContent(EmailNotificationDTO emailDTO) {
        try {
            return objectMapper.writeValueAsString(emailDTO);
        } catch (JsonProcessingException e) {
            log.error("Failed to serialize email content", e);
            return "{}";
        }
    }
    
    /**
     * Deserializes email content from JSON
     */
    private EmailNotificationDTO deserializeEmailContent(String json) {
        try {
            return objectMapper.readValue(json, EmailNotificationDTO.class);
        } catch (JsonProcessingException e) {
            log.error("Failed to deserialize email content", e);
            return null;
        }
    }
    
    /**
     * Serializes recipient list
     */
    private String serializeRecipients(EmailNotificationDTO emailDTO) {
        if (emailDTO == null || emailDTO.getTo() == null) {
            return "[]";
        }
        try {
            return objectMapper.writeValueAsString(emailDTO.getTo());
        } catch (JsonProcessingException e) {
            return "[]";
        }
    }
    
    /**
     * Gets stack trace as string (limited to 2000 chars)
     */
    private String getStackTrace(Exception e) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        String fullStackTrace = sw.toString();
        
        // Limit to 2000 characters
        return fullStackTrace.length() > 2000 
                ? fullStackTrace.substring(0, 2000) + "..." 
                : fullStackTrace;
    }
    
    /**
     * Cleanup old permanent failures (should be called periodically)
     */
    @Scheduled(cron = "0 0 2 * * ?") // Daily at 2 AM
    public void cleanupOldFailures() {
        if (!dlqEnabled) {
            return;
        }
        
        try {
            // Delete permanent failures older than 30 days
            LocalDateTime cutoff = LocalDateTime.now().minusDays(30);
            failedNotificationRepository.deleteByPermanentFailureTrueAndCreatedAtBefore(cutoff);
            log.info("Cleaned up old permanent failures before {}", cutoff);
        } catch (Exception e) {
            log.error("Error cleaning up old failures", e);
        }
    }
}

