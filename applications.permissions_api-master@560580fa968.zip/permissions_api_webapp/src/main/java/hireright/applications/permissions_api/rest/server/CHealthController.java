package hireright.applications.permissions_api.rest.server;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-16  HRG-330191 initial version
 */

import hireright.applications.permissions_api.api.IPermissionsApiProvider;
import hireright.applications.permissions_api.model.CHealth;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

@Controller
public class CHealthController extends CAbstractController implements HealthApi
{
	public CHealthController(IPermissionsApiProvider apiProvider)
	{
		super(apiProvider);
	}

	@Override
	public ResponseEntity<CHealth> getHealth()
	{
		boolean bOk = checkApi();
		CHealth response = new CHealth(bOk ? CHealth.EStatus.pass : CHealth.EStatus.fail);

		return bOk ?
			ResponseEntity.ok().body(response) :
			ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(response);
	}

	@Override
	public ResponseEntity<CHealth> getHealthLive()
	{
		return ResponseEntity.ok().build();
	}

	@Override
	public ResponseEntity<CHealth> getHealthReady()
	{
		boolean bOk = checkApi();

		return bOk ?
			ResponseEntity.ok().build() :
			ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).build();
	}

	private boolean checkApi()
	{
		return true;
	}
}
