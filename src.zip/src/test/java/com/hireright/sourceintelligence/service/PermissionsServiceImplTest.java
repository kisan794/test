package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.ApproverDTO;
import com.hireright.sourceintelligence.api.v2.dto.PermissionsDTO;
import com.hireright.sourceintelligence.domain.entity.Permissions;
import com.hireright.sourceintelligence.domain.repository.PermissionsRepositary;
import com.hireright.sourceintelligence.service.impl.PermissionsServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PermissionsServiceImplTest {

    @Mock
    private PermissionsRepositary permissionsRepositary;

    @InjectMocks
    private PermissionsServiceImpl permissionsService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetPermissionByNameAndStatus_ReturnsValidDTO() {
        // Arrange
        String userName = "testUser";
        String status = "ACTIVE";

        ApproverDTO approver1 = mock(ApproverDTO.class);
        ApproverDTO approver2 = mock(ApproverDTO.class);

        Permissions mockPermissions = new Permissions();
        mockPermissions.setUserName(userName);
        mockPermissions.setStatus(status);
        mockPermissions.setScope("admin");
        mockPermissions.setTrustScore("85");
        mockPermissions.setPermissions(List.of("READ", "WRITE"));
        mockPermissions.setApprovalGroupList(Arrays.asList(approver1, approver2));
        mockPermissions.setUserEmail("test@example.com");

        when(permissionsRepositary.findByUserNameAndStatus(userName, status)).thenReturn(mockPermissions);

        // Act
        PermissionsDTO result = permissionsService.getPermissionByNameAndStatus(userName, status);

        // Assert
        assertNotNull(result);
        assertEquals(userName, result.getUserName());
        assertEquals("admin", result.getScope());
        assertEquals("85", result.getTrustScore());
        assertEquals("test@example.com", result.getUserEmail());
        assertEquals(List.of("READ", "WRITE"), result.getPermissions());
        assertEquals(Arrays.asList(approver1, approver2), result.getApprovalGroupList());

        verify(permissionsRepositary, times(1)).findByUserNameAndStatus(userName, status);
    }


    @Test
    void testGetPermissionByNameAndStatus_ThrowsExceptionWhenNotFound() {
        // Arrange
        String userName = "notFoundUser";
        String status = "INACTIVE";

        when(permissionsRepositary.findByUserNameAndStatus(userName, status)).thenReturn(null);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () ->
                permissionsService.getPermissionByNameAndStatus(userName, status));

        assertTrue(exception.getMessage().contains("Access denied"));
        verify(permissionsRepositary, times(1)).findByUserNameAndStatus(userName, status);
    }
}
