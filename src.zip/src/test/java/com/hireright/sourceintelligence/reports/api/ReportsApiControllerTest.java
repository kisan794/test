package com.hireright.sourceintelligence.reports.api;

import com.hireright.sourceintelligence.reports.dto.ReportResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;
import com.hireright.sourceintelligence.reports.service.ReportService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ReportsApiControllerTest {

    @InjectMocks
    private ReportsApiController reportsApiController;

    @Mock
    private ReportService reportService;

    @Test
    void testGetDeletedSourceReport() {
        ReportsRequestDTO requestDTO = new ReportsRequestDTO();
        ReportResponseDTO mockResponse = new ReportResponseDTO();

        when(reportService.deleteReport(requestDTO)).thenReturn(mockResponse);

        ResponseEntity<ReportResponseDTO> response =
                reportsApiController.getDeletedSourceReport(requestDTO);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(mockResponse, response.getBody());
        assertNotNull(response.getHeaders());
        assertEquals(0, response.getHeaders().size());
    }
}