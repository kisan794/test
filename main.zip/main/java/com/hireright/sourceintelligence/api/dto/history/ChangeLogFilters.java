package com.hireright.sourceintelligence.api.dto.history;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.hireright.sourceintelligence.api.dto.DateRange;
import java.util.List;

import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value = JsonInclude.Include.NON_EMPTY, content = JsonInclude.Include.NON_NULL)
public class ChangeLogFilters {

  private DateRange dateRange;

  List<String> activities;
  private OrganizationType organizationType;
  private String organizationName;
  private String hon;
  private int pageSize;
  private int startPage;
  private String sort;
  private String order;
}
