package com.hireright.sourceintelligence.domain.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class FieldValueInfo {

    private String value;
    private Boolean outOfBusiness;
    private String doNotContact;
    private String country;
    private String state;
    private String city;
    private String hon;


}
