package org.example.recombointegration.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.example.recombointegration.document.FormFieldConfig.FieldType;

import java.util.List;

/**
 * Request DTO for creating or updating form field configuration.
 *
 * @author Generated
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request object for form field configuration")
public class FormFieldConfigRequest {

    @NotBlank(message = "Field key is required")
    @Schema(description = "Unique identifier for the field", example = "impactAreas", required = true)
    @JsonProperty("fieldKey")
    private String fieldKey;

    @NotBlank(message = "Field label is required")
    @Schema(description = "Display name for the field", example = "Which area does this idea impact?", required = true)
    @JsonProperty("fieldLabel")
    private String fieldLabel;

    @Schema(description = "Description or help text for the field", example = "Select all areas that apply")
    @JsonProperty("fieldDescription")
    private String fieldDescription;

    @NotNull(message = "Field type is required")
    @Schema(description = "Type of field", example = "MULTI_SELECT", required = true)
    @JsonProperty("fieldType")
    private FieldType fieldType;

    @Schema(description = "List of options for the field", required = true)
    @JsonProperty("options")
    private List<FieldOptionRequest> options;

    @Schema(description = "Whether this field is required", example = "false")
    @JsonProperty("required")
    private Boolean required;

    @Schema(description = "Display order in the form", example = "1")
    @JsonProperty("displayOrder")
    private Integer displayOrder;

    @Schema(description = "Whether this field is active/enabled", example = "true")
    @JsonProperty("active")
    private Boolean active;

    @Schema(description = "Section this field belongs to", example = "Area of Impact")
    @JsonProperty("section")
    private String section;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "Field option")
    public static class FieldOptionRequest {

        @NotBlank(message = "Option value is required")
        @Schema(description = "Option value", example = "PROCESS", required = true)
        @JsonProperty("value")
        private String value;

        @NotBlank(message = "Option label is required")
        @Schema(description = "Option label", example = "Process", required = true)
        @JsonProperty("label")
        private String label;

        @Schema(description = "Option description", example = "Streamlining workflows, automation, reducing errors")
        @JsonProperty("description")
        private String description;

        @Schema(description = "Display order", example = "1")
        @JsonProperty("order")
        private Integer order;

        @Schema(description = "Whether this option is active", example = "true")
        @JsonProperty("active")
        private Boolean active;
    }
}

