package hireright.applications.igniting_innovations.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.util.List;

/**
 * Request DTO for creating or updating an idea submission.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request object for submitting a new idea")
public class IdeaSubmissionRequest {

    @NotBlank(message = "Form ID is required")
    @Schema(description = "Id of the form")
    @JsonProperty("formId")
    private String formId;

    @NotBlank(message = "Email address is required")
    @Schema(description = "Email address of the submitter")
    @JsonProperty("emailAddress")
    private String emailAddress;

    @NotBlank(message = "Name is required")
    @Schema(description = "Name of the submitter")
    @JsonProperty("name")
    private String name;

    @NotBlank(message = "Status is required")
    @Schema(description = "Status of the form")
    @JsonProperty("status")
    private String status;

    @NotNull(message = "Form data is required")
    @Valid
    @Schema(description = "Data for this Idea")
    @JsonProperty("formData")
    private IdeaSubmissionFormData formData;
}


