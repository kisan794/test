package com.hireright.sourceintelligence.api.dto;

import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import lombok.Data;

@Data
public class AssignSourceDTO {
    private String hon;
    private String organizationName;
    private String createdBy;
    private ApprovalStatus approvalStatus;
}
