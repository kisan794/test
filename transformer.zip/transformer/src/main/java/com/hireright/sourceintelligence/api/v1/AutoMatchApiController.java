package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.AutoMatchDTO;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchResponseDTO;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.service.AutoMatchRegionService;
import com.hireright.sourceintelligence.service.impl.RegionServiceFactory;
import com.hireright.sourceintelligence.service.impl.helperservices.CountryRegionMappingUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.Arrays;
import java.util.Base64;
import java.util.UUID;

import static com.hireright.sourceintelligence.api.ApiConstants.EMEA_REGION;
import static com.hireright.sourceintelligence.api.ApiConstants.US_REGION;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.VERSION;

@RestController
@EnableRetry
@RequiredArgsConstructor
@Validated
@Slf4j
public class AutoMatchApiController implements AutoMatchApi {

    private final RegionServiceFactory regionServiceFactory;
    private final CountryRegionMappingUtils countryRegionMappingUtils;

    /* TODO -requestId need to change with subRequestId from opTool */
    @Override
    public ResponseEntity<AutoMatchResponseDTO> autoMatch(AutoMatchDTO inputData) {
        Instant requestTime = Instant.now();
        String requestId = UUID.randomUUID().toString().substring(0,8);
        inputData.setRequestId(requestId);
        log.info("[{}] AutoMatch request received at {}, input={}", requestId, requestTime, inputData);
        try{
            ResponseEntity<AutoMatchResponseDTO> validationResponse = validateRequest(inputData, requestTime);
            if (validationResponse != null) {
                return validationResponse;
            }
            AutoMatchRegionService regionService = regionServiceFactory.getService(inputData.getRegion());
            decodeRequest(inputData);
            log.info("[{}] AutoMatch request after decode at {}, input={}", requestId, requestTime, inputData);
            var response = regionService.autoMatch(inputData);
            response.setStartTime(Instant.now().toEpochMilli());
            response.setRequestTime(Duration.between(requestTime, Instant.now()).toMillis());
            log.info("[{}] AutoMatch processing completed in {} ms, response={}", requestId, response.getRequestTime(), response);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }catch (Exception e){
            return buildAndLogResponse(requestId, requestTime, NO_AUTO_MATCH_EXCEPTION);
        }
    }

    private void decodeRequest(AutoMatchDTO inputData){
        if(!inputData.getSourceName().isEmpty()){
            byte[] decodedBytes = Base64.getDecoder().decode(inputData.getSourceName());
            String decodedString = new String(decodedBytes, StandardCharsets.UTF_16);
            inputData.setSourceName(decodedString);
        }
        if(!inputData.getCity().isEmpty()){
            byte[] decodedBytes = Base64.getDecoder().decode(inputData.getCity());
            String decodedString = new String(decodedBytes, StandardCharsets.UTF_16);
            inputData.setCity(decodedString);
        }
    }
    private ResponseEntity<AutoMatchResponseDTO> validateRequest(AutoMatchDTO inputData, Instant requestTime){
        if(!StringUtils.hasText(inputData.getCountry())){
            return buildAndLogResponse(inputData.getRequestId(), requestTime, NO_AUTO_MATCH_MISSING_COUNTRY);
        }
        String region = countryRegionMappingUtils.getRegion(inputData.getCountry().trim());
        if(region.isEmpty()){
            return buildAndLogResponse(inputData.getRequestId(), requestTime, NO_AUTO_MATCH_MISSING_REGION);
        }
        inputData.setRegion(region);
        log.debug("[{}] Resolved region={} for country={}", inputData.getRequestId(), region, inputData.getCountry());
        if (Arrays.asList(EMEA_REGION).contains(region) && !StringUtils.hasText(inputData.getCity())) {
            return buildAndLogResponse(inputData.getRequestId(), requestTime, NO_AUTO_MATCH_MISSING_CITY);
        }
        if(Arrays.asList(US_REGION).contains(region) && inputData.getSourceType().equals(OrganizationType.EDUCATION.getType()) && (!StringUtils.hasText(inputData.getState()) || !StringUtils.hasText(inputData.getCity()))){
            return buildAndLogResponse(inputData.getRequestId(), requestTime, NO_AUTO_MATCH_MISSING_STATE_CITY);
        }
        return null;
    }

    private AutoMatchResponseDTO buildAutoMatchResponseDTO(String requestId, Instant requestTime, String error) {
        return AutoMatchResponseDTO.builder().source(null).success(true).v(VERSION)
                .error(error)
                .requestTime(Duration.between(requestTime, Instant.now()).toMillis())
                .startTime(requestTime.getEpochSecond())
                .requestId(requestId)
                .fromOptool(true)
                .build();
    }

    private ResponseEntity<AutoMatchResponseDTO> buildAndLogResponse(String requestId, Instant requestTime, String message) {
        AutoMatchResponseDTO response = buildAutoMatchResponseDTO(requestId, requestTime, message);
        log.warn("[{}] Validation failed: {}, response={}", requestId, message, response);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
