package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.rds.CountryRegionResponseDTO;
import com.hireright.sourceintelligence.api.dto.rds.CountryResponseDTO;
import com.hireright.sourceintelligence.api.dto.rds.LanguageResponseDTO;
import com.hireright.sourceintelligence.api.dto.rds.VendorResponseDTO;
import com.hireright.sourceintelligence.service.CountryService;
import com.hireright.sourceintelligence.service.RDSService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@Validated
@Slf4j
public class RDSApiController implements RDSApi {

    private final RDSService rdsService;
    private final CountryService countryService;

    @Override
    public ResponseEntity<VendorResponseDTO> getVendorsList() {
        VendorResponseDTO result = rdsService.getVendorList();
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<CountryResponseDTO> getCountries(int startIndex, int batchSize) {
        log.info("Getting countries with startIndex: {} and batchSize: {}", startIndex, batchSize);
        CountryResponseDTO result = countryService.getCountries(startIndex, batchSize);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<CountryRegionResponseDTO> getCountryRegions(int countryId, int startIndex, int batchSize) {
        log.info("Getting country regions for countryId: {} with startIndex: {} and batchSize: {}",
                countryId, startIndex, batchSize);
        CountryRegionResponseDTO result = countryService.getCountryRegions(countryId, startIndex, batchSize);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<LanguageResponseDTO> getLanguages(int startIndex, int batchSize) {
        log.info("Getting languages with startIndex: {} and batchSize: {}", startIndex, batchSize);
        LanguageResponseDTO result = countryService.getLanguages(startIndex, batchSize);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }
}
