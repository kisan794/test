/*
 * @(#)$RCSfile: IEntryPointFramework.java,v $ $Revision: 1.2 $ $Date: 2014/07/28 14:57:12 $ $Author: aputintsev $
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/util/IEntryPointFramework.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *     $Log: IEntryPointFramework.java,v $
 *     Revision 1.2  2014/07/28 14:57:12  aputintsev
 *     forked from production version - projects_src/applications/accesspoint
 *
 *     Revision 1.1.2.1.2.1  2009/08/18 11:09:20  asolntsev
 *     Bugfixing and polishing
 *
 *     Revision 1.1.2.1  2009/08/13 13:24:24  asolntsev
 *     Created by St.Petersburg team
 *
 *     Revision 1.1  2009/08/06 09:37:55  banton
 *     Added simple Finite State Machine support. Tested only for memory storage
 *
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hireright.applications.accesspoint.util;

import hireright.objects.utilities.CEntryPoint;
import org.apache.commons.collections.MultiMap;

/**
 *
 * @author banton
 */
public interface IEntryPointFramework
{
	public void setUp();
	public void tearDown();
	public void commit();
	public void rollback();
	
		public CEntryPoint getEntryPoint(String key);

		public void saveEntryPoint(CEntryPoint entryPoint);

		public CEntryPoint createEntryPointNoAuth( String userID,
																							String userClass,
																							String entryPointType,
																							Integer designNumber,
																							String domainID,
																							MultiMap entryPointParams);


		public CEntryPoint createEntryPointAuth(String userID,
																						String userClass,
																						String login,
																						String entryPointType,
																						Integer designNumber,
																						String domainID,
																						MultiMap entryPointParams);

		public void deleteEntryPointByKey(String key);

		public void deleteEntryPoint(CEntryPoint entryPoint);

}
