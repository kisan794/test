/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents;

import com.fasterxml.jackson.annotation.JsonInclude;
import hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic.BaseResultData;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * Task result data containing decision and result information with polymorphic result data.
 * Supports both Employment and Education verification results through type-safe polymorphism.
 *
 * The resultData field will be deserialized as either:
 * - EmploymentResultData (for employment verification)
 * - EducationResultData (for education verification)
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ResultData
{

    private String decision;

    private Double riskScore;

    private String decisionDescription;

    /**
     * Source reference - only populated for employment verification results.
     * This field will be ignored (not serialized) when null for education results.
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String sourceReference;

    private List<Map<String, Object>> properties;

    /**
     * Polymorphic result data - will be deserialized as either:
     * - EmploymentResultData (for employment verification)
     * - EducationResultData (for education verification)
     */
    private BaseResultData resultData;
}
