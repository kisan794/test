package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.Alias;
import com.hireright.sourceintelligence.api.dto.CycleResult;
import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.api.dto.UIActionsDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.service.impl.MongoSourceService;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import com.hireright.sourceintelligence.service.impl.helperservices.*;
import com.hireright.sourceintelligence.util.Helper;
import com.mongodb.BasicDBObject;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.USED_COUNT;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UpdateSourceServiceTest {

    @InjectMocks
    private UpdateSourceService service;

    @Mock private SourceMapper sourceMapper;
    @Mock private SourceUtils sourceUtils;
    @Mock private CountryRegionMappingUtils countryRegionMappingUtils;
    @Mock private MongoSourceService mongoSourceService;
    @Mock private ElasticsearchService elasticsearchService;
    @Mock private ReportDataUtils reportDataUtils;

    private SourceOrganizationDTO dto;
    private UIActionsDTO ui;
    private Source dbSource;
    private Source mappedSource;

    @BeforeEach
    void setup() {

        dto = new SourceOrganizationDTO();
        dto.setHon(HON_EDUCATION_PREFIX + "123");
        dto.setOrganizationType(OrganizationType.EDUCATION);
        dto.setOrganizationName("Test Org");
        dto.setCountry("US");
        dto.setVersion(1.0);
        dto.setApprovalStatus(PENDING_APPROVAL);
        dto.setAction(UPDATE);
        dto.setOrganizationAlias(new Alias[0]);

        ui = new UIActionsDTO();
        ui.setUserAction(ACTION_SAVE);
        ui.setUserEmail("tester@hr.com");
        ui.setUserName("tester");
        ui.setUserTrustScore(100);

        dbSource = new Source();
        dbSource.setId(new ObjectId());
        dbSource.setHon(dto.getHon());
        dbSource.setVersion(1.0);
        dbSource.setTempVersion(0.0);
        dbSource.setApprovalStatus(PENDING_APPROVAL);
        dbSource.setOrganizationAlias(new Alias[0]);
        dbSource.setPayload(new BasicDBObject(USED_COUNT, 5));
        dbSource.setOrganizationName("Test Org");

        mappedSource = new Source();
        mappedSource.setHon(dto.getHon());
        mappedSource.setOrganizationAlias(new Alias[0]);
        mappedSource.setPayload(new BasicDBObject());
        mappedSource.setOrganizationName("Test Org");
    }

    @Test
    void manualFlow_shouldInsertHistory() throws Exception {

        when(mongoSourceService.findSourceByHonAndApprovalStatus(dto.getHon(), PENDING_APPROVAL))
                .thenReturn(dbSource);

        when(mongoSourceService.findSourceByHonAndApprovalStatus(dto.getHon(), APPROVED))
                .thenReturn(dbSource);

        when(sourceMapper.dtoToEntitySource(any())).thenReturn(mappedSource);
        when(sourceMapper.entitySourceToDTO(any())).thenReturn(dto);

        when(mongoSourceService.isSourceExistsInHistoryByHonAndVersion(dto.getHon(), dbSource.getVersion()))
                .thenReturn(false);

        try (MockedStatic<Helper> helper = mockStatic(Helper.class, CALLS_REAL_METHODS)) {

            helper.when(() -> Helper.checkIsSkipApprovalFlow(any(), any())).thenReturn(true);
            helper.when(() -> Helper.getCollectionName(anyString(), anyString())).thenReturn("test_collection");

            service.updateSource(dto, ui);

            verify(mongoSourceService).insert(any(Source.class), eq("test_collection"));
            verify(mongoSourceService, times(2)).insertSourceHistory(any(Source.class));
        }
    }
    @Test
    void trustCycle_autoApproval_shouldCreateES() throws Exception {

        dto.setVersion(0.0);
        dto.setAction(CREATE);
        ui.setUserAction(ACTION_SAVE);
        dbSource.setVersion(0.0);
        dbSource.setTempVersion(0.0);
        mappedSource.setHon(dto.getHon());

        when(mongoSourceService.findSourceByHonAndApprovalStatus(dto.getHon(), PENDING_APPROVAL))
                .thenReturn(dbSource);

        when(sourceMapper.dtoToEntitySource(any())).thenReturn(mappedSource);
        when(sourceMapper.entitySourceToDTO(any())).thenReturn(dto);

        when(countryRegionMappingUtils.getRegionByCountry("US")).thenReturn("US");

        CycleResult result = new CycleResult(AUTO_APPOVED, null);
        when(sourceUtils.checkForAutoApproval(anyInt(), anyString(), anyString()))
                .thenReturn(result);

        try (MockedStatic<Helper> helper = mockStatic(Helper.class, CALLS_REAL_METHODS)) {

            helper.when(() -> Helper.fromActionForApprovalFlow(anyString()))
                    .thenReturn(null);
            helper.when(() -> Helper.getCollectionName(anyString(), eq(SOURCE_COLLECTION_SUFFIX)))
                    .thenReturn("test_collection");

            service.updateSource(dto, ui);
            verify(elasticsearchService).createSource(any(Source.class));
            verify(elasticsearchService, never()).updateSourceIndex(any(Source.class));
        }
    }

    @Test
    void approvalManager_approved_shouldUpdateMongoAndES() throws Exception {

        ui.setUserAction(ACTION_APPROVED);
        dto.setApprovalStatus(IN_PROGRESS);
        dto.setHon(HON_EDUCATION_PREFIX + "123");
        dbSource.setHon(dto.getHon());
        mappedSource.setHon(dto.getHon());
        mappedSource.setAction(UPDATE);

        when(mongoSourceService.findSourceByHonAndApprovalStatus(dto.getHon(), IN_PROGRESS))
                .thenReturn(dbSource);

        when(sourceMapper.dtoToEntitySource(any())).thenReturn(mappedSource);
        when(sourceMapper.entitySourceToDTO(any())).thenReturn(dto);

        try (MockedStatic<Helper> helper = mockStatic(Helper.class, CALLS_REAL_METHODS)) {
            helper.when(() -> Helper.getCollectionName(anyString(), anyString()))
                    .thenReturn("test_collection");

            service.updateSource(dto, ui);

            verify(mongoSourceService).updateById(any(Source.class), eq("test_collection"));
            verify(elasticsearchService).updateSourceIndex(any(Source.class));
        }
    }


    @Test
    void approvalManager_reject_shouldNotCallES() throws Exception {

        ui.setUserAction(ACTION_REJECTED);
        dto.setApprovalStatus(IN_PROGRESS);

        when(mongoSourceService.findSourceByHonAndApprovalStatus(dto.getHon(), IN_PROGRESS))
                .thenReturn(dbSource);

        when(sourceMapper.dtoToEntitySource(any())).thenReturn(mappedSource);
        when(sourceMapper.entitySourceToDTO(any())).thenReturn(dto);

        try (MockedStatic<Helper> helper = mockStatic(Helper.class, CALLS_REAL_METHODS)) {
            helper.when(() -> Helper.getCollectionName(anyString(), anyString())).thenReturn("test_collection");

            service.updateSource(dto, ui);

            verify(elasticsearchService, never()).createSource(any());
            verify(elasticsearchService, never()).updateSourceIndex(any());
        }
    }

    @Test
    void approvalManager_onHold_shouldNotCallES() throws Exception {

        ui.setUserAction(ACTION_ON_HOLD);
        dto.setApprovalStatus(IN_PROGRESS);

        when(mongoSourceService.findSourceByHonAndApprovalStatus(dto.getHon(), IN_PROGRESS))
                .thenReturn(dbSource);

        when(sourceMapper.dtoToEntitySource(any())).thenReturn(mappedSource);
        when(sourceMapper.entitySourceToDTO(any())).thenReturn(dto);

        try (MockedStatic<Helper> helper = mockStatic(Helper.class, CALLS_REAL_METHODS)) {
            helper.when(() -> Helper.getCollectionName(anyString(), anyString())).thenReturn("test_collection");

            service.updateSource(dto, ui);

            verify(elasticsearchService, never()).createSource(any());
            verify(elasticsearchService, never()).updateSourceIndex(any());
        }
    }
    @Test
    void existingSource_trustCycle_manual_shouldInsertAndDeletePending() throws Exception {
        dto.setVersion(2.0);
        dto.setAction(UPDATE);
        dto.setApprovalStatus(PENDING_APPROVAL);
        ui.setUserAction(ACTION_SAVE);

        dbSource.setApprovalStatus(PENDING_APPROVAL);
        dbSource.setVersion(1.0);
        dbSource.setTempVersion(0.0);
        dbSource.setId(new ObjectId());
        dbSource.setPayload(new BasicDBObject(USED_COUNT, 9));

        Source approvedCompare = new Source();
        approvedCompare.setHon(dto.getHon());
        approvedCompare.setApprovalStatus(APPROVED);
        approvedCompare.setVersion(1.0);
        approvedCompare.setPayload(new BasicDBObject(USED_COUNT, 99));
        approvedCompare.setOrganizationName("Test Org");
        approvedCompare.setOrganizationAlias(new Alias[0]);

        mappedSource.setHon(dto.getHon());
        mappedSource.setPayload(new BasicDBObject());
        mappedSource.setOrganizationName("Test Org");
        mappedSource.setOrganizationAlias(new Alias[0]);

        when(mongoSourceService.findSourceByHonAndApprovalStatus(dto.getHon(), dto.getApprovalStatus()))
                .thenReturn(dbSource);
        when(mongoSourceService.findSourceByHonAndApprovalStatus(dto.getHon(), APPROVED))
                .thenReturn(approvedCompare);
        when(sourceMapper.dtoToEntitySource(any())).thenReturn(mappedSource);
        when(sourceMapper.entitySourceToDTO(any())).thenReturn(dto);

        when(countryRegionMappingUtils.getRegionByCountry(anyString())).thenReturn("US");
        when(sourceUtils.checkForAutoApproval(anyInt(), anyString(), anyString()))
                .thenReturn(new CycleResult("MANUAL", null));

        when(mongoSourceService.isSourceExistsInHistoryByHonAndVersion(dto.getHon(), dbSource.getVersion()))
                .thenReturn(false);

        try (MockedStatic<Helper> helper = mockStatic(Helper.class, CALLS_REAL_METHODS)) {
            helper.when(() -> Helper.checkIsSkipApprovalFlow(any(), any())).thenReturn(false);
            helper.when(() -> Helper.checkIsAutoApproval(any(), any())).thenReturn(false);
            helper.when(() -> Helper.fromActionForApprovalFlow(anyString())).thenReturn(null);

            helper.when(() -> Helper.getCollectionName(
                    anyString(),
                    argThat(suffix -> SOURCE_COLLECTION_SUFFIX.equals(suffix))
            )).thenReturn("test_collection");

            service.updateSource(dto, ui);

            verify(mongoSourceService).deleteSourceById(dbSource.getId(), "test_collection");
            verify(mongoSourceService).insert(any(Source.class), argThat("test_collection"::equals));
            verify(mongoSourceService, times(2)).insertSourceHistory(any(Source.class));

            verify(elasticsearchService, never()).createSource(any());
            verify(elasticsearchService, never()).updateSourceIndex(any());
        }
    }

    @Test
    void existingSource_autoApproval_idNull_shouldNotDeleteOld() throws Exception {
        dto.setVersion(2.0);
        dto.setAction(UPDATE);
        dto.setApprovalStatus(PENDING_APPROVAL);
        ui.setUserAction(ACTION_SAVE);

        dbSource.setApprovalStatus(PENDING_APPROVAL);
        dbSource.setVersion(2.0);
        dbSource.setTempVersion(0.0);
        dbSource.setId(null);
        dbSource.setPayload(new BasicDBObject(USED_COUNT, 4));

        Source approvedCompare = new Source();
        approvedCompare.setHon(dto.getHon());
        approvedCompare.setApprovalStatus(APPROVED);
        approvedCompare.setVersion(2.0);
        approvedCompare.setPayload(new BasicDBObject(USED_COUNT, 77));
        approvedCompare.setOrganizationName("Test Org");
        approvedCompare.setOrganizationAlias(new Alias[0]);

        mappedSource.setHon(dto.getHon());
        mappedSource.setPayload(new BasicDBObject());
        mappedSource.setOrganizationName("Test Org");
        mappedSource.setOrganizationAlias(new Alias[0]);

        when(mongoSourceService.findSourceByHonAndApprovalStatus(dto.getHon(), dto.getApprovalStatus()))
                .thenReturn(dbSource);
        when(mongoSourceService.findSourceByHonAndApprovalStatus(dto.getHon(), APPROVED))
                .thenReturn(approvedCompare);
        when(sourceMapper.dtoToEntitySource(any())).thenReturn(mappedSource);
        when(sourceMapper.entitySourceToDTO(any())).thenReturn(dto);

        when(mongoSourceService.isSourceExistsInHistoryByHonAndVersion(dto.getHon(), dbSource.getVersion()))
                .thenReturn(false);

        try (MockedStatic<Helper> helper = mockStatic(Helper.class, CALLS_REAL_METHODS)) {
            helper.when(() -> Helper.checkIsSkipApprovalFlow(any(), any())).thenReturn(false);
            helper.when(() -> Helper.checkIsAutoApproval(any(), any())).thenReturn(true);
            helper.when(() -> Helper.getCollectionName(anyString(), eq(SOURCE_COLLECTION_SUFFIX)))
                    .thenReturn("test_collection");

            service.updateSource(dto, ui);

            verify(mongoSourceService, never()).deleteSourceById(any(), anyString());
            verify(mongoSourceService).insert(any(Source.class), eq("test_collection"));
            verify(mongoSourceService, times(2)).insertSourceHistory(any(Source.class));
            verify(elasticsearchService).updateSourceIndex(any(Source.class));
        }
    }
    @Test
    void approvalManager_approved_whenApprovedExists_shouldDeleteOldApproved() throws Exception {
        ui.setUserAction(ACTION_APPROVED);
        dto.setApprovalStatus(IN_PROGRESS);

        Source inProgress = new Source();
        inProgress.setHon(dto.getHon());
        inProgress.setApprovalStatus(IN_PROGRESS);
        inProgress.setPayload(new BasicDBObject(USED_COUNT, 1));
        inProgress.setOrganizationName("Test Org");
        inProgress.setId(new ObjectId());
        inProgress.setOrganizationAlias(new Alias[0]);

        Source approvedDb = new Source();
        approvedDb.setHon(dto.getHon());
        approvedDb.setApprovalStatus(APPROVED);
        approvedDb.setVersion(5.0);
        approvedDb.setPayload(new BasicDBObject(USED_COUNT, 123));
        approvedDb.setOrganizationName("Test Org");
        approvedDb.setId(new ObjectId());
        approvedDb.setOrganizationAlias(new Alias[0]);

        Source mapped = new Source();
        mapped.setHon(dto.getHon());
        mapped.setOrganizationName("Test Org");
        mapped.setPayload(new BasicDBObject());
        mapped.setAction(UPDATE);
        mapped.setApprovalStatus(IN_PROGRESS);
        mapped.setOrganizationAlias(new Alias[0]);

        when(mongoSourceService.findSourceByHonAndApprovalStatus(dto.getHon(), IN_PROGRESS))
                .thenReturn(inProgress);
        when(mongoSourceService.findSourceByHonAndApprovalStatus(dto.getHon(), APPROVED))
                .thenReturn(approvedDb);
        when(sourceMapper.dtoToEntitySource(any())).thenReturn(mapped);
        when(sourceMapper.entitySourceToDTO(any())).thenReturn(dto);

        try (MockedStatic<Helper> helper = mockStatic(Helper.class, CALLS_REAL_METHODS)) {
            helper.when(() -> Helper.getCollectionName(
                    anyString(),
                    argThat(s -> SOURCE_COLLECTION_SUFFIX.equals(s))
            )).thenReturn("test_collection");

            service.updateSource(dto, ui);
            verify(mongoSourceService).deleteSourceById(
                    argThat(id -> id.equals(approvedDb.getId())),
                    argThat("test_collection"::equals)
            );

            verify(mongoSourceService).updateById(
                    any(Source.class),
                    argThat("test_collection"::equals)
            );

            verify(mongoSourceService).insertSourceHistory(any(Source.class));
            verify(elasticsearchService).updateSourceIndex(any(Source.class));
        }
    }

    @Test
    void newSource_withAlias_shouldGoManualFlow() throws Exception {
        dto.setAction(CREATE);
        dto.setVersion(0.0);
        dto.setApprovalStatus(PENDING_APPROVAL);
        dto.setOrganizationAlias(new Alias[]{mock(Alias.class)});
        ui.setUserAction(ACTION_SAVE);

        dbSource.setApprovalStatus(PENDING_APPROVAL);
        dbSource.setVersion(0.0);
        dbSource.setTempVersion(0.0);
        dbSource.setId(new ObjectId());
        dbSource.setOrganizationAlias(new Alias[0]);
        dbSource.setPayload(new BasicDBObject(USED_COUNT, 6));
        dbSource.setOrganizationName("Test Org");

        mappedSource.setHon(dto.getHon());
        mappedSource.setPayload(new BasicDBObject());
        mappedSource.setOrganizationName("Test Org");
        mappedSource.setOrganizationAlias(new Alias[0]);

        when(mongoSourceService.findSourceByHonAndApprovalStatus(dto.getHon(), dto.getApprovalStatus()))
                .thenReturn(dbSource);

        when(sourceMapper.dtoToEntitySource(any())).thenReturn(mappedSource);
        when(sourceMapper.entitySourceToDTO(any())).thenReturn(dto);

        when(mongoSourceService.isSourceExistsInHistoryByHonAndVersion(dto.getHon(), dbSource.getVersion()))
                .thenReturn(false);

        try (MockedStatic<Helper> helper = mockStatic(Helper.class, CALLS_REAL_METHODS)) {
            helper.when(() -> Helper.getCollectionName(anyString(), eq(SOURCE_COLLECTION_SUFFIX)))
                    .thenReturn("test_collection");

            service.updateSource(dto, ui);

            verify(mongoSourceService).insert(any(Source.class), eq("test_collection"));
            verify(mongoSourceService, times(2)).insertSourceHistory(any(Source.class));
            verify(elasticsearchService, never()).createSource(any());
            verify(elasticsearchService, never()).updateSourceIndex(any());
        }
    }


    @Test
    void invalidAction_shouldThrow() {

        ui.setUserAction(ACTION_SAVE);
        dto.setAction(UPDATE);
        dto.setVersion(0.0);

        assertThrows(RuntimeException.class,
                () -> service.updateSource(dto, ui));
    }
}
