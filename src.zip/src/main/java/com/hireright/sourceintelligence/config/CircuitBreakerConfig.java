package com.hireright.sourceintelligence.config;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import jakarta.mail.MessagingException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.MailAuthenticationException;
import org.springframework.mail.MailException;

import java.time.Duration;

/**
 * Configuration for Circuit Breaker pattern.
 * Implements fault tolerance for email notification service.
 */
@Slf4j
@Configuration
public class CircuitBreakerConfig {
    
    @Value("${resilience4j.circuitbreaker.instances.emailNotification.slidingWindowSize:20}")
    private int slidingWindowSize;
    
    @Value("${resilience4j.circuitbreaker.instances.emailNotification.minimumNumberOfCalls:10}")
    private int minimumNumberOfCalls;
    
    @Value("${resilience4j.circuitbreaker.instances.emailNotification.failureRateThreshold:50}")
    private float failureRateThreshold;
    
    @Value("${resilience4j.circuitbreaker.instances.emailNotification.waitDurationInOpenState:60s}")
    private String waitDurationInOpenState;
    
    @Value("${resilience4j.circuitbreaker.instances.emailNotification.permittedNumberOfCallsInHalfOpenState:5}")
    private int permittedNumberOfCallsInHalfOpenState;
    
    @Value("${resilience4j.circuitbreaker.instances.emailNotification.automaticTransitionFromOpenToHalfOpenEnabled:true}")
    private boolean automaticTransitionEnabled;
    
    /**
     * Creates and configures the circuit breaker registry
     */
    @Bean
    public CircuitBreakerRegistry circuitBreakerRegistry() {
        log.info("Configuring Circuit Breaker for email notifications");
        
        Duration waitDuration = parseDuration(waitDurationInOpenState);
        
        CircuitBreakerConfig config = CircuitBreakerConfig.custom()
                .slidingWindowSize(slidingWindowSize)
                .minimumNumberOfCalls(minimumNumberOfCalls)
                .failureRateThreshold(failureRateThreshold)
                .waitDurationInOpenState(waitDuration)
                .permittedNumberOfCallsInHalfOpenState(permittedNumberOfCallsInHalfOpenState)
                .automaticTransitionFromOpenToHalfOpenEnabled(automaticTransitionEnabled)
                // Record these exceptions as failures
                .recordExceptions(MailException.class, MessagingException.class)
                // Don't record authentication failures (configuration issue, not transient)
                .ignoreExceptions(MailAuthenticationException.class)
                .build();
        
        CircuitBreakerRegistry registry = CircuitBreakerRegistry.of(config);
        
        // Register event listeners for monitoring
        CircuitBreaker circuitBreaker = registry.circuitBreaker("emailNotification");
        registerEventListeners(circuitBreaker);
        
        log.info("Circuit Breaker configured - slidingWindow: {}, minCalls: {}, failureThreshold: {}%",
                slidingWindowSize, minimumNumberOfCalls, failureRateThreshold);
        
        return registry;
    }
    
    /**
     * Registers event listeners for circuit breaker state changes
     */
    private void registerEventListeners(CircuitBreaker circuitBreaker) {
        circuitBreaker.getEventPublisher()
                .onStateTransition(event -> {
                    log.warn("Circuit Breaker state transition: {} -> {}",
                            event.getStateTransition().getFromState(),
                            event.getStateTransition().getToState());
                })
                .onError(event -> {
                    log.debug("Circuit Breaker recorded error: {}", 
                            event.getThrowable().getMessage());
                })
                .onSuccess(event -> {
                    log.debug("Circuit Breaker recorded success");
                })
                .onCallNotPermitted(event -> {
                    log.warn("Circuit Breaker call not permitted - circuit is OPEN");
                });
    }
    
    /**
     * Parses duration string (e.g., "60s", "2m") to Duration object
     */
    private Duration parseDuration(String durationStr) {
        durationStr = durationStr.trim();
        
        if (durationStr.endsWith("s")) {
            long seconds = Long.parseLong(durationStr.substring(0, durationStr.length() - 1));
            return Duration.ofSeconds(seconds);
        } else if (durationStr.endsWith("m")) {
            long minutes = Long.parseLong(durationStr.substring(0, durationStr.length() - 1));
            return Duration.ofMinutes(minutes);
        } else if (durationStr.endsWith("h")) {
            long hours = Long.parseLong(durationStr.substring(0, durationStr.length() - 1));
            return Duration.ofHours(hours);
        } else {
            // Default to seconds
            return Duration.ofSeconds(Long.parseLong(durationStr));
        }
    }
}

