package com.hireright.sourceintelligence.service.impl.helperservices;

import com.hireright.sourceintelligence.api.dto.UIActionsDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.service.impl.*;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import com.hireright.sourceintelligence.util.Helper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.ACTION_DELETE;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.SOURCE_COLLECTION_SUFFIX;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class DeleteSourceServiceTest {

    @InjectMocks
    private ArchiveSourceService archiveSourceService;

    @Mock
    private CustomSourceRepository<Source> customSourceRepository;
    @Mock
    private MongoSourceService mongoSourceService;

    @Mock
    private ReportDataUtils reportDataUtils;
    @Mock
    private CountryRegionMappingUtils countryRegionMappingUtils;
    @Mock
    private ElasticsearchService elasticsearchService;
    @Mock
    private SourceUtils sourceUtils;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    private UIActionsDTO getUIActions(String userAction) {
        UIActionsDTO dto = new UIActionsDTO();
        dto.setUserAction(userAction);
        dto.setUserName("tester");
        dto.setUserEmail("tester@email.com");
        dto.setUserTrustScore(95);
        return dto;
    }

    private Source getTestSource(ApprovalStatus status, int childCount) {
        Source source = new Source();
        source.setHon("HON123");
        source.setApprovalStatus(status);
        source.setCountry("USA");
        return source;
    }

    @Test
    void testDeleteSource_shouldThrowWhenSourceIsNull() {
        when(mongoSourceService.findSourceByHon("HON123")).thenReturn(null);
        assertThrows(Exception.class, () ->
                archiveSourceService.archiveSource("HON123", getUIActions(ACTION_DELETE))
        );
    }

    @Test
    void testDeleteSource_shouldThrowWhenChildCountGreaterThanZero() {
        Source source = getTestSource(APPROVED, 2);
        when(mongoSourceService.findSourceByHon("HON123")).thenReturn(source);
        assertThrows(Exception.class, () ->
                archiveSourceService.archiveSource("HON123", getUIActions(ACTION_DELETE))
        );
    }

}
