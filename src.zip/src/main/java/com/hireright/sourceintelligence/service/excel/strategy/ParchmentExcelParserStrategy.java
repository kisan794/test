package com.hireright.sourceintelligence.service.excel.strategy;

import com.hireright.sourceintelligence.api.dto.ParchmentRecord;
import com.hireright.sourceintelligence.service.excel.ExcelColumnMapping;
import com.hireright.sourceintelligence.service.excel.ExcelParserStrategy;
import com.hireright.sourceintelligence.service.excel.ExcelRowMapper;
import com.hireright.sourceintelligence.service.excel.GenericExcelParser;
import com.hireright.sourceintelligence.service.excel.mapper.ParchmentRowMapper;
import com.hireright.sourceintelligence.service.excel.mapping.ParchmentColumnMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

import static com.hireright.sourceintelligence.domain.constants.Constants.DataExtractionConstants.DATA_EXTRACTION_TYPE_PARCHMENT;

@Component
@RequiredArgsConstructor
public class ParchmentExcelParserStrategy implements ExcelParserStrategy<ParchmentRecord> {

    private final GenericExcelParser genericExcelParser;
    private final ParchmentRowMapper parchmentRowMapper;

    @Override
    public List<ParchmentRecord> parse(MultipartFile file) throws IOException {
        return genericExcelParser.parseExcelFile(file, getColumnMapping(), getRowMapper());
    }

    @Override
    public String getParserType() {
        return DATA_EXTRACTION_TYPE_PARCHMENT;
    }

    @Override
    public ExcelColumnMapping getColumnMapping() {
        return ParchmentColumnMapping.create();
    }

    @Override
    public ExcelRowMapper<ParchmentRecord> getRowMapper() {
        return parchmentRowMapper;
    }
}