package hireright.applications.permissions_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-17  HRG-330191 initial version
 */

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Objects;

public class COperator
{
	@JsonProperty("username")
	private String m_sUsername;

	@JsonProperty("formattedName")
	private String m_sFormattedName;

	@JsonProperty("trustScore")
	private Integer m_sTrustScore;

	@JsonProperty("sourceVerificationTrustLevel")
	private Integer m_nSourceVerificationTrustLevel;

	@JsonProperty("email")
	private String m_sEmail;

	private COperator()
	{
	}

	private COperator(Builder builder)
	{
		m_sUsername = builder.m_sUsername;
		m_sFormattedName = builder.m_sFormattedName;
		m_sEmail = builder.m_sEmail;
		m_sTrustScore = builder.m_nTrustScore;
		m_nSourceVerificationTrustLevel = builder.m_nSourceVerificationTrustLevel;
	}

	public String getUsername()
	{
		return m_sUsername;
	}

	public String getFormattedName()
	{
		return m_sFormattedName;
	}

	public Integer getTrustScore()
	{
		return m_sTrustScore;
	}

	public Integer getSourceVerificationTrustLevel()
	{
		return m_nSourceVerificationTrustLevel;
	}

	public String getEmail()
	{
		return m_sEmail;
	}

	@Override
	public String toString()
	{
		return "COperator{" + "m_sUsername='" + m_sUsername + '\'' + ", m_sFormattedName='"
			+ m_sFormattedName + '\'' + ", m_sTrustScore=" + m_sTrustScore
			+ ", m_nSourceVerificationTrustLevel=" + m_nSourceVerificationTrustLevel
			+ ", m_sEmail='" + m_sEmail + '\'' + '}';
	}

	@Override
	public boolean equals(Object o)
	{
		if(this == o)
		{
			return true;
		}
		if(o == null || getClass() != o.getClass())
		{
			return false;
		}

		COperator cOperator = (COperator) o;

		if(!Objects.equals(m_sUsername, cOperator.m_sUsername))
		{
			return false;
		}
		return Objects.equals(m_sFormattedName, cOperator.m_sFormattedName);
	}

	@Override
	public int hashCode()
	{
		int result = m_sUsername != null ? m_sUsername.hashCode() : 0;
		result = 31 * result + (m_sFormattedName != null ? m_sFormattedName.hashCode() : 0);
		return result;
	}

	public enum EField
	{
		USERNAME("USERNAME");

		private final String m_sValue;

		EField(String sValue)
		{
			m_sValue = sValue;
		}

		public static EField fromValue(String text)
		{
			if(text == null || text.trim().isEmpty())
			{
				return null;
			}

			for(EField entry : EField.values())
			{
				if(entry.m_sValue.equalsIgnoreCase(text))
				{
					return entry;
				}
			}

			return null;
		}
	}

	public static final class Builder
	{
		private String m_sUsername;
		private String m_sFormattedName;
		private Integer m_nTrustScore;
		private Integer m_nSourceVerificationTrustLevel;
		private String m_sEmail;

		public Builder()
		{
		}

		public Builder(COperator copy)
		{
			if(copy == null)
			{
				return;
			}

			this.m_sUsername = copy.getUsername();
			this.m_sFormattedName = copy.getFormattedName();
			this.m_nTrustScore = copy.getTrustScore();
			this.m_nSourceVerificationTrustLevel = copy.getSourceVerificationTrustLevel();
			this.m_sEmail = copy.getEmail();
		}

		public Builder username(String sUsername)
		{
			this.m_sUsername = sUsername;
			return this;
		}

		public Builder formattedName(String sFormattedName)
		{
			this.m_sFormattedName = sFormattedName;
			return this;
		}

		public Builder trustScore(Integer nTrustScore)
		{
			this.m_nTrustScore = nTrustScore;
			return this;
		}

		public Builder sourceVerificationTrustLevel(Integer nSourceVerificationTrustLevel)
		{
			this.m_nSourceVerificationTrustLevel = nSourceVerificationTrustLevel;
			return this;
		}

		public Builder email(String sEmail)
		{
			this.m_sEmail = sEmail;
			return this;
		}

		public COperator build()
		{
			return new COperator(this);
		}
	}
}
