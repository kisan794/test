package com.hireright.sourceintelligence.api.dto;

import lombok.Data;

import java.util.Map;

@Data
public class SmartSearchRequestDTO {

    private boolean isSearchIndexRequired;
    private boolean isDBSearchRequired;
    private ElasticsearchDTO searchSource;
    private Map<String,String> mapFilters;
}
