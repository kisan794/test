# Form Field Configuration API - Examples

This directory contains example JSON payloads and API testing tools for the Form Field Configuration API.

## 📁 Files

### Form Configuration
- **`form-config-examples.json`** - Comprehensive JSON examples for form field configurations
- **`curl-commands.sh`** - Shell script with cURL commands for form config testing

### Idea Submission
- **`idea-submission-examples.json`** - 10 complete idea submission examples
- **`idea-submission-curl.sh`** - Shell script with cURL commands for idea submission testing

### Postman Collection
- **`Idea-Management-API.postman_collection.json`** - Complete Postman collection with both form config and idea submission endpoints

## 🚀 Quick Start

### 1. Start MongoDB

```bash
# Using Docker
docker run -d -p 27017:27017 --name mongodb mongo:latest

# Or using local MongoDB
mongod --dbpath /path/to/data
```

### 2. Start the Application

```bash
cd /Users/brander/Desktop/transformer
./gradlew bootRun
```

### 3. Initialize Default Configurations

```bash
curl -X POST http://localhost:8080/api/v1/form-config/initialize
```

This creates 6 default configurations:
- **impactAreas** - Process, People, Quality
- **improvementTypes** - Incremental, Innovative, Cost Saving, Quality Enhancement, Other
- **impactCategories** - Time Efficiency, Cost Savings, Employee Engagement, etc.
- **implementationComplexity** - Low, Medium, High
- **timelineType** - Short-term, Long-term
- **ideaStatus** - Submitted, Under Review, Approved, Implemented, Completed, Rejected, On Hold

### 4. Get Active Configurations (for UI)

```bash
curl -X GET http://localhost:8080/api/v1/form-config/active
```

## 📝 Creating New Field Configurations

### Example 1: Department Dropdown

```bash
curl -X POST http://localhost:8080/api/v1/form-config \
  -H "Content-Type: application/json" \
  -d '{
    "fieldKey": "department",
    "fieldLabel": "Department / Function",
    "fieldDescription": "Select your department",
    "fieldType": "DROPDOWN",
    "section": "Basic Information",
    "displayOrder": 3,
    "required": true,
    "active": true,
    "options": [
      {
        "value": "IT",
        "label": "Information Technology",
        "description": "IT Operations, Development, Infrastructure",
        "order": 1,
        "active": true
      },
      {
        "value": "HR",
        "label": "Human Resources",
        "description": "Recruitment, Training, Employee Relations",
        "order": 2,
        "active": true
      },
      {
        "value": "FINANCE",
        "label": "Finance",
        "description": "Accounting, Budgeting, Financial Planning",
        "order": 3,
        "active": true
      }
    ]
  }'
```

### Example 2: Priority Level (Radio Buttons)

```bash
curl -X POST http://localhost:8080/api/v1/form-config \
  -H "Content-Type: application/json" \
  -d '{
    "fieldKey": "priorityLevel",
    "fieldLabel": "Priority Level",
    "fieldDescription": "How urgent is this idea?",
    "fieldType": "RADIO",
    "section": "Implementation Details",
    "displayOrder": 7,
    "required": false,
    "active": true,
    "options": [
      {
        "value": "CRITICAL",
        "label": "Critical",
        "description": "Immediate action required - business critical",
        "order": 1,
        "active": true
      },
      {
        "value": "HIGH",
        "label": "High",
        "description": "Important - should be addressed soon",
        "order": 2,
        "active": true
      },
      {
        "value": "MEDIUM",
        "label": "Medium",
        "description": "Moderate importance - can be scheduled",
        "order": 3,
        "active": true
      },
      {
        "value": "LOW",
        "label": "Low",
        "description": "Nice to have - low priority",
        "order": 4,
        "active": true
      }
    ]
  }'
```

### Example 3: Resources Needed (Multi-Select Checkboxes)

```bash
curl -X POST http://localhost:8080/api/v1/form-config \
  -H "Content-Type: application/json" \
  -d '{
    "fieldKey": "resourcesNeeded",
    "fieldLabel": "Resources Needed",
    "fieldDescription": "Select all resources required for implementation",
    "fieldType": "MULTI_SELECT",
    "section": "Implementation Details",
    "displayOrder": 8,
    "required": false,
    "active": true,
    "options": [
      {
        "value": "BUDGET",
        "label": "Budget / Funding",
        "description": "Financial resources required",
        "order": 1,
        "active": true
      },
      {
        "value": "PERSONNEL",
        "label": "Additional Personnel",
        "description": "Need to hire or assign more people",
        "order": 2,
        "active": true
      },
      {
        "value": "TECHNOLOGY",
        "label": "Technology / Software",
        "description": "New tools, software, or hardware",
        "order": 3,
        "active": true
      }
    ]
  }'
```

## 🔧 Field Types

The API supports three field types:

1. **DROPDOWN** - Single selection dropdown
2. **RADIO** - Radio button group (single selection)
3. **MULTI_SELECT** - Checkbox group (multiple selections)

## 📋 Field Configuration Structure

```json
{
  "fieldKey": "unique_identifier",           // Unique key for the field
  "fieldLabel": "Display Label",             // Label shown to users
  "fieldDescription": "Help text",           // Description/help text
  "fieldType": "DROPDOWN|RADIO|MULTI_SELECT", // Type of field
  "section": "Section Name",                 // Form section grouping
  "displayOrder": 1,                         // Order in the form
  "required": true|false,                    // Is field required?
  "active": true|false,                      // Is field active?
  "options": [                               // Array of options
    {
      "value": "OPTION_VALUE",               // Value stored in database
      "label": "Option Label",               // Label shown to users
      "description": "Option description",   // Optional description
      "order": 1,                            // Display order
      "active": true                         // Is option active?
    }
  ]
}
```

## 🧪 Testing with cURL Script

Make the script executable and run it:

```bash
chmod +x api-examples/curl-commands.sh
./api-examples/curl-commands.sh
```

## 📮 Testing with Postman

1. Open Postman
2. Import the collection: `Idea-Management-API.postman_collection.json`
3. The collection includes all API endpoints with example payloads
4. Base URL is set to `http://localhost:8080` (can be changed in collection variables)

## 🌐 API Endpoints

### Form Configuration Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/form-config/initialize` | Initialize default configurations |
| POST | `/api/v1/form-config` | Create new configuration |
| PUT | `/api/v1/form-config/{fieldKey}` | Update configuration |
| GET | `/api/v1/form-config/{fieldKey}` | Get specific configuration |
| GET | `/api/v1/form-config` | Get all configurations |
| GET | `/api/v1/form-config/active` | Get active configurations (for UI) |
| GET | `/api/v1/form-config/section/{section}` | Get by section |
| DELETE | `/api/v1/form-config/{fieldKey}` | Delete configuration |

## 💡 Usage in Frontend

1. **Fetch active configurations on page load:**
   ```javascript
   const response = await fetch('http://localhost:8080/api/v1/form-config/active');
   const configs = await response.json();
   ```

2. **Render form fields dynamically:**
   ```javascript
   configs.forEach(config => {
     if (config.fieldType === 'DROPDOWN') {
       // Render dropdown
     } else if (config.fieldType === 'RADIO') {
       // Render radio buttons
     } else if (config.fieldType === 'MULTI_SELECT') {
       // Render checkboxes
     }
   });
   ```

3. **Submit idea with selected values:**
   ```javascript
   const ideaData = {
     title: "My Idea",
     description: "Description",
     impactAreas: ["PROCESS", "QUALITY"],  // Multi-select values
     department: "IT",                      // Dropdown value
     priorityLevel: "HIGH",                 // Radio value
     // ... other fields
   };
   ```

## 📊 Swagger UI

Access the interactive API documentation at:
```
http://localhost:8080/swagger-ui.html
```

## 🔍 MongoDB Queries

View configurations in MongoDB:

```javascript
// Connect to MongoDB
use idea_management_db

// View all configurations
db.form_field_configs.find().pretty()

// View active configurations
db.form_field_configs.find({ active: true }).pretty()

// View by section
db.form_field_configs.find({ section: "Implementation Details" }).pretty()
```

## 🎯 Common Use Cases

### Add New Option to Existing Config

```bash
# 1. Get current config
curl -X GET http://localhost:8080/api/v1/form-config/impactAreas

# 2. Update with new option added
curl -X PUT http://localhost:8080/api/v1/form-config/impactAreas \
  -H "Content-Type: application/json" \
  -d '{ ... updated config with new option ... }'
```

### Deactivate a Field

```bash
curl -X PUT http://localhost:8080/api/v1/form-config/priorityLevel \
  -H "Content-Type: application/json" \
  -d '{
    "fieldKey": "priorityLevel",
    "active": false,
    ... other fields ...
  }'
```

### Change Display Order

Update the `displayOrder` field to reorder fields in the form.

## 📝 Notes

- All IDs are MongoDB ObjectIds (String format)
- Timestamps are automatically managed (createdAt, updatedAt)
- Field keys must be unique
- Options within a field are ordered by the `order` property
- Inactive fields/options are not returned by the `/active` endpoint

