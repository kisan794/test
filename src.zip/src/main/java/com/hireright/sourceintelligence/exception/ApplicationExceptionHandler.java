package com.hireright.sourceintelligence.exception;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.hireright.sourceintelligence.service.exception.BusinessException;
import com.hireright.sourceintelligence.service.exception.FileEmptyException;

/**
 * A centralized exception handling mechanism where all kinds of exceptions are
 * handled and wrapped in a result DTO.
 */
@ControllerAdvice
public class ApplicationExceptionHandler {

	private static final Logger logger = LoggerFactory.getLogger(ApplicationExceptionHandler.class);
	

}
