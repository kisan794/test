package hireright.applications.igniting_innovations.service;

import hireright.applications.igniting_innovations.document.FormFieldConfig;
import hireright.applications.igniting_innovations.dto.FormFieldConfigRequest;
import hireright.applications.igniting_innovations.dto.FormFieldConfigResponse;
import hireright.applications.igniting_innovations.exception.ResourceAlreadyExistsException;
import hireright.applications.igniting_innovations.exception.ResourceNotFoundException;
import hireright.applications.igniting_innovations.repository.FormFieldConfigRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class FormFieldConfigService {

    private final FormFieldConfigRepository formFieldConfigRepository;

    public FormFieldConfigResponse createConfig(FormFieldConfigRequest request) {
        log.info("Creating new form field configuration: {}", request.getFieldKey());

        if (formFieldConfigRepository.existsByFieldKey(request.getFieldKey())) {
            throw new ResourceAlreadyExistsException("Field configuration already exists with key: " + request.getFieldKey());
        }

        FormFieldConfig config = mapToDocument(request);
        config.setCreatedAt(LocalDateTime.now());
        config.setUpdatedAt(LocalDateTime.now());

        FormFieldConfig savedConfig = formFieldConfigRepository.save(config);
        log.info("Form field configuration created successfully with ID: {}", savedConfig.getId());

        return mapToResponse(savedConfig);
    }

    public FormFieldConfigResponse updateConfig(String fieldKey, FormFieldConfigRequest request) {
        log.info("Updating form field configuration: {}", fieldKey);

        FormFieldConfig config = formFieldConfigRepository.findByFieldKey(fieldKey)
                .orElseThrow(() -> new ResourceNotFoundException("Field configuration not found with key: " + fieldKey));

        updateConfigFromRequest(config, request);
        config.setUpdatedAt(LocalDateTime.now());

        FormFieldConfig updatedConfig = formFieldConfigRepository.save(config);
        log.info("Form field configuration updated successfully");

        return mapToResponse(updatedConfig);
    }

    public FormFieldConfigResponse getConfigByFieldKey(String fieldKey) {
        log.info("Fetching form field configuration: {}", fieldKey);
        FormFieldConfig config = formFieldConfigRepository.findByFieldKey(fieldKey)
                .orElseThrow(() -> new ResourceNotFoundException("Field configuration not found with key: " + fieldKey));
        return mapToResponse(config);
    }

    public Map<String, List<FormFieldConfigResponse.FieldOptionResponse>> getAllConfigs() {
        log.info("Fetching all form field configurations");

        List<FormFieldConfig> configs = formFieldConfigRepository.findAll();
        Map<String, List<FormFieldConfigResponse.FieldOptionResponse>> result = new HashMap<>();

        configs.forEach(config -> {
            List<FormFieldConfigResponse.FieldOptionResponse> options = config.getOptions() != null
                    ? config.getOptions().stream()
                    .map(opt -> FormFieldConfigResponse.FieldOptionResponse.builder()
                            .value(opt.getValue())
                            .label(opt.getLabel())
                            .build())
                    .collect(Collectors.toList())
                    : List.of();

            result.put(config.getFieldKey(), options);
        });

        return result;
    }

    public void deleteConfig(String fieldKey) {
        log.info("Deleting form field configuration: {}", fieldKey);
        FormFieldConfig config = formFieldConfigRepository.findByFieldKey(fieldKey)
                .orElseThrow(() -> new ResourceNotFoundException("Field configuration not found with key: " + fieldKey));
        formFieldConfigRepository.delete(config);
        log.info("Form field configuration deleted successfully");
    }

    private FormFieldConfig mapToDocument(FormFieldConfigRequest request) {
        List<FormFieldConfig.FieldOption> options = request.getOptions() != null
                ? request.getOptions().stream()
                .map(opt -> FormFieldConfig.FieldOption.builder()
                        .value(opt.getValue())
                        .label(opt.getLabel())
                        .build())
                .collect(Collectors.toList())
                : null;

        return FormFieldConfig.builder()
                .fieldKey(request.getFieldKey())
                .options(options)
                .build();
    }

    private void updateConfigFromRequest(FormFieldConfig config, FormFieldConfigRequest request) {
        if (request.getOptions() != null) {
            List<FormFieldConfig.FieldOption> options = request.getOptions().stream()
                    .map(opt -> FormFieldConfig.FieldOption.builder()
                            .value(opt.getValue())
                            .label(opt.getLabel())
                            .build())
                    .collect(Collectors.toList());
            config.setOptions(options);
        }
    }

    private FormFieldConfigResponse mapToResponse(FormFieldConfig config) {
        List<FormFieldConfigResponse.FieldOptionResponse> options = config.getOptions() != null
                ? config.getOptions().stream()
                .map(opt -> FormFieldConfigResponse.FieldOptionResponse.builder()
                        .value(opt.getValue())
                        .label(opt.getLabel())
                        .build())
                .collect(Collectors.toList())
                : null;

        return FormFieldConfigResponse.builder()
                .id(config.getId())
                .fieldKey(config.getFieldKey())
                .options(options)
                .createdAt(config.getCreatedAt())
                .updatedAt(config.getUpdatedAt())
                .build();
    }
}