package com.hireright.sourceintelligence.exception;

/**
 * Exception thrown when circuit breaker is open.
 */
public class CircuitBreakerOpenException extends NotificationException {
    
    private final int retryAfter;
    private final double failureRate;
    
    public CircuitBreakerOpenException(String message, int retryAfter, double failureRate) {
        super(message, "CIRCUIT_BREAKER_OPEN");
        this.retryAfter = retryAfter;
        this.failureRate = failureRate;
    }
    
    public int getRetryAfter() {
        return retryAfter;
    }
    
    public double getFailureRate() {
        return failureRate;
    }
}

