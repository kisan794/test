/*
 * @(#)$RCSfilev$ $Revision: 1.2 $ $Date: 2014/07/28 14:48:44 $ $Author: aputintsev $
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/resources/src/main/java/hireright/project/accesspoint/model/Fault.java,v $
 *
 * Copyright 2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	J.Burlakova		2012-05-23	Created
 */
package hireright.project.accesspoint.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Jekaterina Burlakova
 */
@XmlRootElement(name = "Fault")
public class Fault
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: aputintsev $";

	private String faultcode;

	private String faultstring;

	public Fault(){}

	public Fault(String faultcode, String faultstring){
		this.faultcode = faultcode;
		this.faultstring = faultstring;
	}

	@XmlElement(name = "faultcode")
	public String getFaultcode()
	{
		return faultcode;
	}

	public void setFaultcode( String faultcode )
	{
		this.faultcode = faultcode;
	}

	@XmlElement(name = "faultstring")
	public String getFaultstring()
	{
		return faultstring;
	}

	public void setFaultstring( String faultstring )
	{
		this.faultstring = faultstring;
	}

}
