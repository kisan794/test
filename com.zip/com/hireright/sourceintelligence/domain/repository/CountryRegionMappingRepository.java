package com.hireright.sourceintelligence.domain.repository;

import com.hireright.sourceintelligence.domain.entity.CountryRegionMapping;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CountryRegionMappingRepository extends MongoRepository<CountryRegionMapping, String> {
    CountryRegionMapping findByCountry(String country);
}
