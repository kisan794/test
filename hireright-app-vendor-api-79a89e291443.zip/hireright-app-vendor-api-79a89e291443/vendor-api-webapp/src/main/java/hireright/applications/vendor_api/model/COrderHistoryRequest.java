/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-08-14	Created
 */
package hireright.applications.vendor_api.model;

import java.util.Date;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import hireright.applications.vendor_api.exchange.handler.objects.CEntityExchangeDTO;

@XmlRootElement(name="OrderHistoryRequest")
public class COrderHistoryRequest extends CEntityExchangeDTO
{
	private String history;
	private String operatorName;
	private String referenceType;
	private String referenceCode;
	private String commentsCode;
	private Date creationDate;

	@XmlElement(name="History")
	public String getHistory()
	{
		return history;
	}

	@XmlElement(name="ReferenceType")
	public String getReferenceType()
	{
		return this.referenceType;
	}

	@XmlElement(name="ReferenceCode")
	public String getReferenceCode()
	{
		return this.referenceCode;
	}

	@XmlElement(name="OperatorName")
	public String getOperatorName()
	{
		return this.operatorName;
	}

	@XmlElement(name="CommentsCode")
	public String getCommentsCode()
	{
		return this.commentsCode;
	}

	@XmlElement(name="Date")
	@XmlJavaTypeAdapter(CDateAdapter.class)
	public Date getCreationDate()
	{
		return this.creationDate;
	}

	public void setHistory(String history)
	{
		this.history = history;
	}

	public void setReferenceType(String referenceType)
	{
		this.referenceType = referenceType;
	}

	public void setReferenceCode(String referenceCode)
	{
		this.referenceCode = referenceCode;
	}

	public void setOperatorName(String operatorName)
	{
		this.operatorName = operatorName;
	}

	public void setCommentsCode(String commentsCode)
	{
		this.commentsCode = commentsCode;
	}

	public void setCreationDate(Date creationDate)
	{
		this.creationDate = creationDate;
	}
}
