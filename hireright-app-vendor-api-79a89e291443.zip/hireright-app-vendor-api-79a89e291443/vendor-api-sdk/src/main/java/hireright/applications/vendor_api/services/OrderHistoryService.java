package hireright.applications.vendor_api.services;
/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	2017-08-16	Created
 *	T.Prikk		2018-04-11	HIVPE-21816: Added EReferenceType.REFERENCE_TYPE/.REFERENCE_CODE
 *	M.Kuznetsov	2025-10-29	HRG-345322. Openjdk21-migration
 */

import org.springframework.web.bind.annotation.RequestMethod;

import hireright.applications.vendor_api.services.validators.CommentValidator;
import hireright.components.domain.dialects.vendor_api.BasicResponse;
import hireright.components.domain.dialects.vendor_api.Comment;

public class OrderHistoryService {
    public static final String VAR_ORDER_REF = "orderRef";

    public static final String PATH_ADD = "/orders/{" + VAR_ORDER_REF + "}/history";

    public enum EReferenceType {
        ORDER_SERVICE,
        ORDER,
        ORDER_HISTORY,
        REFERENCE_TYPE,
        REFERENCE_CODE
    }

    public enum EResponseParam {
        ORDER_HISTORY_ID
    }

    public enum EMethod implements IMethod {
        ADD(PATH_ADD, RequestMethod.POST, Comment.class, BasicResponse.class) {
            @Override
            public boolean isValidRequest(Object request) {
                return super.isValidRequest(request)
                        && (request instanceof Comment)
                        && CommentValidator.isValid((Comment) request);
            }
        };

        private final String path;
        private final RequestMethod requestMethod;
        private final Class<?> requestBodyClass;
        private final Class<?> responseBodyClass;

        EMethod(String sPath,
                RequestMethod requestMethod,
                Class<?> requestBodyClass,
                Class<?> responseBodyClass) {
            this.path = sPath;
            this.requestMethod = requestMethod;
            this.requestBodyClass = requestBodyClass;
            this.responseBodyClass = responseBodyClass;
        }

        public String getPath() {
            return this.path;
        }

        public RequestMethod getRequestMethod() {
            return this.requestMethod;
        }

        public Class<?> getRequestBodyClass() {
            return this.requestBodyClass;
        }

        public Class<?> getResponseBodyClass() {
            return this.responseBodyClass;
        }

        public boolean isValidRequest(Object request) {
            return true;
        }
    }
}
