package hireright.applications.fulfillment_task_api.rest.recombointegration.service;

import hireright.applications.fulfillment_task_api.rest.recombointegration.exception.XmlTransformationException;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl.EducationXmlToJsonConverter;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl.EmploymentXmlToJsonConverter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for XmlConverterFactory
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("XmlConverterFactory Tests")
class XmlConverterFactoryTest {

    @Mock
    private EducationXmlToJsonConverter educationConverter;

    @Mock
    private EmploymentXmlToJsonConverter employmentConverter;

    private XmlConverterFactory factory;

    @BeforeEach
    void setUp() {
        when(educationConverter.getType()).thenReturn(ScreeningType.EDUCATION);
        when(employmentConverter.getType()).thenReturn(ScreeningType.EMPLOYMENT);
    }

    @Test
    @DisplayName("Should initialize factory with education and employment converters")
    void testFactoryInitializationWithBothConverters() {
        // Given
        List<XmlToJsonConverter> converters = Arrays.asList(educationConverter, employmentConverter);

        // When
        factory = new XmlConverterFactory(converters);

        // Then
        assertNotNull(factory);
        assertEquals("education, employment", factory.getSupportedTypesString());
    }

    @Test
    @DisplayName("Should initialize factory with only education converter")
    void testFactoryInitializationWithEducationOnly() {
        // Given
        List<XmlToJsonConverter> converters = Collections.singletonList(educationConverter);

        // When
        factory = new XmlConverterFactory(converters);

        // Then
        assertNotNull(factory);
        assertEquals("education", factory.getSupportedTypesString());
    }

    @Test
    @DisplayName("Should initialize factory with only employment converter")
    void testFactoryInitializationWithEmploymentOnly() {
        // Given
        List<XmlToJsonConverter> converters = Collections.singletonList(employmentConverter);

        // When
        factory = new XmlConverterFactory(converters);

        // Then
        assertNotNull(factory);
        assertEquals("employment", factory.getSupportedTypesString());
    }

    @Test
    @DisplayName("Should initialize factory with empty converter list")
    void testFactoryInitializationWithEmptyList() {
        // Given
        List<XmlToJsonConverter> converters = Collections.emptyList();

        // When
        factory = new XmlConverterFactory(converters);

        // Then
        assertNotNull(factory);
        assertEquals("", factory.getSupportedTypesString());
    }

    @Test
    @DisplayName("Should get education converter by string type")
    void testGetEducationConverterByString() {
        // Given
        List<XmlToJsonConverter> converters = Arrays.asList(educationConverter, employmentConverter);
        factory = new XmlConverterFactory(converters);

        // When
        XmlToJsonConverter result = factory.getConverter("education");

        // Then
        assertNotNull(result);
        assertEquals(educationConverter, result);
    }

    @Test
    @DisplayName("Should get employment converter by string type")
    void testGetEmploymentConverterByString() {
        // Given
        List<XmlToJsonConverter> converters = Arrays.asList(educationConverter, employmentConverter);
        factory = new XmlConverterFactory(converters);

        // When
        XmlToJsonConverter result = factory.getConverter("employment");

        // Then
        assertNotNull(result);
        assertEquals(employmentConverter, result);
    }

    @Test
    @DisplayName("Should get education converter by enum type")
    void testGetEducationConverterByEnum() {
        // Given
        List<XmlToJsonConverter> converters = Arrays.asList(educationConverter, employmentConverter);
        factory = new XmlConverterFactory(converters);

        // When
        XmlToJsonConverter result = factory.getConverter(ScreeningType.EDUCATION);

        // Then
        assertNotNull(result);
        assertEquals(educationConverter, result);
    }

    @Test
    @DisplayName("Should get employment converter by enum type")
    void testGetEmploymentConverterByEnum() {
        // Given
        List<XmlToJsonConverter> converters = Arrays.asList(educationConverter, employmentConverter);
        factory = new XmlConverterFactory(converters);

        // When
        XmlToJsonConverter result = factory.getConverter(ScreeningType.EMPLOYMENT);

        // Then
        assertNotNull(result);
        assertEquals(employmentConverter, result);
    }

    @Test
    @DisplayName("Should throw exception for unsupported string type")
    void testGetConverterWithUnsupportedStringType() {
        // Given
        List<XmlToJsonConverter> converters = Arrays.asList(educationConverter, employmentConverter);
        factory = new XmlConverterFactory(converters);

        // When & Then
        XmlTransformationException exception = assertThrows(
                XmlTransformationException.class,
                () -> factory.getConverter("criminal")
        );

        assertTrue(exception.getMessage().contains("Unknown screening type"));
    }

    @Test
    @DisplayName("Should throw exception when converter not registered for type")
    void testGetConverterWhenNotRegistered() {
        // Given
        List<XmlToJsonConverter> converters = Collections.singletonList(educationConverter);
        factory = new XmlConverterFactory(converters);

        // When & Then
        XmlTransformationException exception = assertThrows(
                XmlTransformationException.class,
                () -> factory.getConverter(ScreeningType.EMPLOYMENT)
        );

        assertTrue(exception.getMessage().contains("No converter registered"));
        assertTrue(exception.getMessage().contains("EMPLOYMENT"));
    }

    @Test
    @DisplayName("Should handle case-insensitive type string")
    void testGetConverterCaseInsensitive() {
        // Given
        List<XmlToJsonConverter> converters = Arrays.asList(educationConverter, employmentConverter);
        factory = new XmlConverterFactory(converters);

        // When
        XmlToJsonConverter result1 = factory.getConverter("EDUCATION");
        XmlToJsonConverter result2 = factory.getConverter("Education");
        XmlToJsonConverter result3 = factory.getConverter("eDuCaTiOn");

        // Then
        assertEquals(educationConverter, result1);
        assertEquals(educationConverter, result2);
        assertEquals(educationConverter, result3);
    }

    @Test
    @DisplayName("Should handle type string with whitespace")
    void testGetConverterWithWhitespace() {
        // Given
        List<XmlToJsonConverter> converters = Arrays.asList(educationConverter, employmentConverter);
        factory = new XmlConverterFactory(converters);

        // When
        XmlToJsonConverter result = factory.getConverter("  education  ");

        // Then
        assertEquals(educationConverter, result);
    }

    @Test
    @DisplayName("Should return supported types string with both converters")
    void testGetSupportedTypesString() {
        // Given
        List<XmlToJsonConverter> converters = Arrays.asList(educationConverter, employmentConverter);
        factory = new XmlConverterFactory(converters);

        // When
        String supportedTypes = factory.getSupportedTypesString();

        // Then
        assertNotNull(supportedTypes);
        assertTrue(supportedTypes.contains("education"));
        assertTrue(supportedTypes.contains("employment"));
    }

    @Test
    @DisplayName("Should handle duplicate converter registration")
    void testDuplicateConverterRegistration() {
        // Given
        XmlToJsonConverter duplicateEducationConverter = mock(XmlToJsonConverter.class);
        when(duplicateEducationConverter.getType()).thenReturn(ScreeningType.EDUCATION);

        List<XmlToJsonConverter> converters = Arrays.asList(
                educationConverter,
                duplicateEducationConverter,
                employmentConverter
        );

        // When
        factory = new XmlConverterFactory(converters);

        // Then - Last registered converter should be used
        XmlToJsonConverter result = factory.getConverter(ScreeningType.EDUCATION);
        assertEquals(duplicateEducationConverter, result);
    }

    @Test
    @DisplayName("Should throw exception for null type string")
    void testGetConverterWithNullString() {
        // Given
        List<XmlToJsonConverter> converters = Arrays.asList(educationConverter, employmentConverter);
        factory = new XmlConverterFactory(converters);

        // When - null defaults to EDUCATION in ScreeningType.fromValue
        XmlToJsonConverter result = factory.getConverter((String) null);

        // Then
        assertEquals(educationConverter, result);
    }

    @Test
    @DisplayName("Should throw exception for empty type string")
    void testGetConverterWithEmptyString() {
        // Given
        List<XmlToJsonConverter> converters = Arrays.asList(educationConverter, employmentConverter);
        factory = new XmlConverterFactory(converters);

        // When - empty string defaults to EDUCATION in ScreeningType.fromValue
        XmlToJsonConverter result = factory.getConverter("");

        // Then
        assertEquals(educationConverter, result);
    }

    @Test
    @DisplayName("Should verify converter types are called during initialization")
    void testConverterTypesCalledDuringInit() {
        // Given
        List<XmlToJsonConverter> converters = Arrays.asList(educationConverter, employmentConverter);

        // When
        factory = new XmlConverterFactory(converters);

        // Then
        verify(educationConverter, atLeastOnce()).getType();
        verify(employmentConverter, atLeastOnce()).getType();
    }
}

