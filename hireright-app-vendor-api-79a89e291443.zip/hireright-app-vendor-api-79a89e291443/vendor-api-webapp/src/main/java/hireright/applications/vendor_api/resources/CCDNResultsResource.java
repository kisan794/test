/*
 *
 * Copyright 2001-2018 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	T.Prikk		2018-10-04	HIVPE-40534: Created to support receiving updates to consent PDF from vendor instance (CDN)
 */
package hireright.applications.vendor_api.resources;

import java.util.Map;
import java.util.concurrent.Callable;

import org.apache.commons.lang.StringUtils;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import hireright.applications.vendor_api.services.CDNResultsService;
import hireright.components.domain.dialects.vendor_api.BasicResponse;
import hireright.document_repository.core.IDocumentRepository;
import hireright.document_repository.core.CMetaData;
import hireright.document_repository.core.document.CDocumentID;
import hireright.document_repository.core.document.IDocument;
import hireright.document_repository.core.document.IDocumentDescription;
import hireright.document_repository.core.document.IDocumentID;
import hireright.document_repository.jackrabbit.CJackrabbitDocumentRepository;
import hireright.document_repository.core.document.IPayload;
import hireright.document_repository.core.document.CPayload;
import hireright.document_repository.v2.core.DMSRepository;
import hireright.objects.application.CApplication;
import hireright.objects.document.CDocument;
import hireright.objects.document.CDocumentFactory;
import hireright.objects.document.injection.CDocumentFieldsContainer;
import hireright.objects.document.injection.CInjectedDocumentBuilder;
import hireright.objects.rollout_feature.CRolloutFeatureFactory;
import hireright.objects.users.CCustomer;
import hireright.project.supporting_documents.objects.document_repository.CSupportingDocument;
import hireright.project.supporting_documents.objects.document_repository.CSupportingDocumentDescription;
import hireright.project.supporting_documents.objects.document_repository_legacy.SupDocRepository;
import hireright.project.supporting_documents.objects.document_repository_legacy.CSupportingDocumentsService;
import hireright.sdk.consts.Mime;
import hireright.sdk.db3.DB;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CStringUtils;


@RestController
public class CCDNResultsResource extends AResource
{
	private static final String JR_PROP_UNOFFICIAL_DOCUMENT_TYPE = "unofficialDocumentType";

	private static final String FIELD_EMPLOYEE_NAME = "police_agency_employee_name";
	private static final String FIELD_EMPLOYEE_SIGNATURE = "police_agency_employee_signature";
	private static final String FIELD_CANADA_POST_ID = "canada_post_request_id";
	
	private static final String RF_HTTP_DOCUMENT_REPOSITORY_PROXY_ENABLED = "HTTP_DOCUMENT_REPOSITORY_PROXY_ENABLED";
	

	@RequestMapping(
			path = CDNResultsService.PATH_CONSENT_DOCUMENT,
			method = RequestMethod.POST,
			consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,
			produces = MediaType.APPLICATION_XML_VALUE
		)
	public @ResponseBody BasicResponse updateConsentForm(
			@PathVariable(CDNResultsService.VAR_DOCUMENT_REF) final String sDocumentRef,
			@RequestParam final Map<String, String> formData
		)
		throws Exception
	{
		return DB.execute(new Callable<BasicResponse>()
		{
			@Override
			public BasicResponse call() throws Exception
			{
				DB.requestTransaction();
				
				// PROXY way
				hireright.document_repository.core.IDocumentRepository dmsRepoCommon = 
						DMSRepository.getInstanceNotLinkedToCustomer();		
				
				// works only for JR
				String sDocumentRefUpd = 
						sDocumentRef.indexOf(":") > 0 ? 
								StringUtils.substringAfterLast(sDocumentRef, ":") :
									sDocumentRef;
						
				IDocumentID documentID = new CDocumentID(sDocumentRefUpd);
				IDocument supportingDocument = null;
				
				try
				{
					supportingDocument = dmsRepoCommon.get(documentID);
				}
				catch(Exception exAny) {}
				
				String sCustomerID = null;
				
				if(supportingDocument != null)
				{
					sCustomerID = (String) supportingDocument.getDescription().getProperty(CMetaData.PROPERTY_CUSTOMER_ID);
				}
				
				// NON Proxy way
				// IDocument supportingDocument = CSupportingDocumentsService.getJRInstance().get(documentID);
				
				if(!CRolloutFeatureFactory.isFeatureGranted(RF_HTTP_DOCUMENT_REPOSITORY_PROXY_ENABLED, 
						CCustomer.OBJECT_CLASS, sCustomerID))
				{
					// update with CJackrabbitDocumentRepository
					dmsRepoCommon = null;
				}
				
				if(supportingDocument == null || dmsRepoCommon == null)
				{
					supportingDocument = CSupportingDocumentsService.getJRInstance().get(documentID);
				}
				
				// any operation with DMS PROXY api require that Application/Order/Customer is exists in DB,
				// so it will not work if we have reference, but not objects, eg if we access it from another DB instance 
				
				if (supportingDocument != null)
				{
					IDocumentDescription description = supportingDocument.getDescription();
					
					Integer nApplicationID = Integer.parseInt((String) description.getProperty(CMetaData.PROPERTY_APPLICATION_ID));
					String sDocumentType = (String) description.getProperty(CMetaData.PROPERTY_DOCUMENT_TYPE); 
					String sUnofficialDocumentType = (String) description.getProperty(JR_PROP_UNOFFICIAL_DOCUMENT_TYPE);
					
					CDocument document = null;
					CDocument unofficialDocument = null;
					byte[] unofficialPayload = null;
					
					if (!CStringUtils.isNumber(sDocumentType))
					{
						unofficialPayload = supportingDocument.getPayload().getBytes();
						
						CTraceLog.warning("Document " + sDocumentRef + " has no document type parameter",
								this.getClass().getName());
					}
					else
					{
						document = CDocumentFactory.getNewestDocument(
								CApplication.OBJECT_CLASS, 
								String.valueOf(nApplicationID), 
								Integer.parseInt(sDocumentType)
							);
						
						if (CStringUtils.isNumber(sUnofficialDocumentType))
						{
							unofficialDocument = CDocumentFactory.getNewestDocument(
									CApplication.OBJECT_CLASS,
									String.valueOf(nApplicationID), 
									Integer.parseInt(sUnofficialDocumentType)
								);
							unofficialPayload = unofficialDocument.getContentDecoded();
						}
						else
						{
							unofficialPayload = document.getContentDecoded();
						}
					}
					
					String sOperatorName = formData.get(CDNResultsService.PARAM_OPERATOR_NAME);
					String sBadgeNumber = formData.get(CDNResultsService.PARAM_BADGE_NUMBER);
					String sCanadaPostID = formData.get(CDNResultsService.PARAM_CANADA_POST_ID);

					CDocumentFieldsContainer.Builder builder = new CDocumentFieldsContainer.Builder();
					
					if (StringUtils.isNotBlank(sOperatorName))
					{
						builder
								.textField(FIELD_EMPLOYEE_SIGNATURE, sOperatorName)
								.textField(FIELD_EMPLOYEE_NAME, sOperatorName + " -#" + sBadgeNumber);
					}
					
					if (StringUtils.isNotBlank(sCanadaPostID))
					{
						builder.textField(FIELD_CANADA_POST_ID, sCanadaPostID);
					}
					
					CInjectedDocumentBuilder documentBuilder = CInjectedDocumentBuilder.document(unofficialPayload)
						.contentType(Mime.APPLICATION_PDF)
						.container(builder.build());
					
					byte[] flattenedContent = documentBuilder.flatten(true).result();
					
					if (document != null)
					{
						document.setContent(flattenedContent);
						CDocumentFactory.storeDocument(document);
					}
					
					if (unofficialDocument != null)
					{
						byte[] content = documentBuilder.flatten(false).result();
						unofficialDocument.setContent(content);
						CDocumentFactory.storeDocument(unofficialDocument);
					}
					
					if(dmsRepoCommon != null)  // should be - DMS PROXY rollout is active 
					{
						hireright.document_repository.core.document.CDocument updatedDocument = 
								new hireright.document_repository.core.document.CDocument(documentID, description, (IPayload) new CPayload(flattenedContent));
						dmsRepoCommon.updatePayload(updatedDocument);
					}
					else // should be - no DMS PROXY
					{
						CSupportingDocument updatedDocument = new CSupportingDocument(SupDocRepository.JR,
							documentID,
							new CSupportingDocumentDescription(description),
							(IPayload) new CPayload(flattenedContent));
					
						IDocumentRepository repository = CSupportingDocumentsService.getJRInstance().getRepository();
						((CJackrabbitDocumentRepository) repository).updatePayload(updatedDocument);
					}
					
				}
				else
				{
					CTraceLog.warning("Document " + sDocumentRef + " could not be retrieved", this.getClass().getName());
				}
				
				return new BasicResponse();
			}
		});
	}
}
