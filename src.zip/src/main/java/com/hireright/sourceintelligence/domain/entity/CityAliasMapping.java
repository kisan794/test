package com.hireright.sourceintelligence.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Document(collection = "city_alias_mapping")
@CompoundIndex(
        def = "{'country': 1, 'city': 1, 'aliases': 1}",
        collation = "{ 'locale': 'en', 'strength': 2 }"
)
public class CityAliasMapping {
    @Id
    private String id;
    private String country;
    private String city;
    private List<String> aliases;
}
