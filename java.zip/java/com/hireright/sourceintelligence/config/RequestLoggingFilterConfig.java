package com.hireright.sourceintelligence.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RequestLoggingFilterConfig {

    @Bean
    public CustomRequestLoggingFilter requestLogFilter() {
        var filter = new CustomRequestLoggingFilter();
        filter.setIncludeQueryString(true);
        filter.setIncludePayload(true);
        filter.setMaxPayloadLength(5024);
        filter.setIncludeHeaders(false);
        filter.setIncludeClientInfo(true);
        return filter;
    }

}
