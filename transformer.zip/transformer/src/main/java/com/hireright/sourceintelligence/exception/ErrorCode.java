package com.hireright.sourceintelligence.exception;

import org.springframework.http.HttpStatus;

public enum ErrorCode {
    BAD_REQUEST("0000", "Bad request. Please refer to API documentation", HttpStatus.BAD_REQUEST),
    INVALID_ARGUMENT("0001", "Invalid Argument specified.", HttpStatus.BAD_REQUEST),
    NOT_FOUND("0002", "The requested resource was not found.", HttpStatus.NOT_FOUND),
    ALREADY_EXISTS("0003", "The resource you are trying to create already exists.", HttpStatus.CONFLICT),
    PERMISSION_DENIED("0004", "The caller does not have permission to execute the specified operation.",
            HttpStatus.FORBIDDEN),
    UNAUTHENTICATED("0005", "The caller does not have valid authentication credentials for the operation.",
            HttpStatus.UNAUTHORIZED),
    UNPROCESSABLE("0006", "The API Payload or URL parameters could not be processed due to a Validation Failure.",
            HttpStatus.UNPROCESSABLE_ENTITY),
    INTERNAL("0007", "An internal error has caused a failure of the operation.", HttpStatus.INTERNAL_SERVER_ERROR);

    private static final String COMMON_ERROR_CODE_PREFIX = "E100";

    private final String code;

    private final String description;

    private final HttpStatus httpStatus;

    ErrorCode(String code, String desc, HttpStatus httpStatus) {
        this.code = code;
        this.description = desc;
        this.httpStatus = httpStatus;
    }

    public String getCode() {
        return COMMON_ERROR_CODE_PREFIX + code;
    }

    public String getDescription() {
        return description;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }
}

