package com.hireright.sourceintelligence.service.notification.impl;

import com.hireright.sourceintelligence.api.dto.notification.AttachmentDTO;
import com.hireright.sourceintelligence.api.dto.notification.EmailNotificationDTO;
import com.hireright.sourceintelligence.service.notification.EmailNotificationService;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.UUID;

/**
 * Implementation of EmailNotificationService
 * Following Single Responsibility Principle - only handles email sending logic
 * Following Dependency Inversion Principle - depends on JavaMailSender abstraction
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class EmailNotificationServiceImpl implements EmailNotificationService {
    
    private final JavaMailSender mailSender;
    
    @Value("${notification.email.from:noreply@sourceintelligence.com}")
    private String fromEmail;
    
    @Value("${notification.email.enabled:true}")
    private boolean emailEnabled;
    
    @Override
    public String sendEmail(EmailNotificationDTO emailNotification) {
        if (!emailEnabled) {
            log.warn("Email notification is disabled. Skipping email send.");
            return null;
        }
        
        if (!validateEmailNotification(emailNotification)) {
            throw new IllegalArgumentException("Invalid email notification details");
        }
        
        try {
            String notificationId = UUID.randomUUID().toString();
            log.info("Sending email notification - ID: {}, To: {}, Subject: {}", 
                    notificationId, emailNotification.getTo(), emailNotification.getSubject());
            
            MimeMessage mimeMessage = createMimeMessage(emailNotification);
            mailSender.send(mimeMessage);
            
            log.info("Email notification sent successfully - ID: {}", notificationId);
            return notificationId;
            
        } catch (MessagingException e) {
            log.error("Failed to send email notification: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to send email notification", e);
        }
    }
    
    @Async("notificationExecutor")
    @Override
    public void sendEmailAsync(EmailNotificationDTO emailNotification) {
        log.info("Sending email notification asynchronously - To: {}, Subject: {}", 
                emailNotification.getTo(), emailNotification.getSubject());
        
        try {
            sendEmail(emailNotification);
        } catch (Exception e) {
            log.error("Failed to send async email notification: {}", e.getMessage(), e);
            // In async mode, we don't throw exception but log it
        }
    }
    
    @Override
    public boolean validateEmailNotification(EmailNotificationDTO emailNotification) {
        if (emailNotification == null) {
            log.warn("Email notification is null");
            return false;
        }
        
        if (CollectionUtils.isEmpty(emailNotification.getTo())) {
            log.warn("Email notification has no recipients");
            return false;
        }
        
        if (emailNotification.getSubject() == null || emailNotification.getSubject().trim().isEmpty()) {
            log.warn("Email notification has no subject");
            return false;
        }
        
        if (emailNotification.getBody() == null || emailNotification.getBody().trim().isEmpty()) {
            log.warn("Email notification has no body");
            return false;
        }
        
        return true;
    }
    
    private MimeMessage createMimeMessage(EmailNotificationDTO emailNotification) throws MessagingException {
        MimeMessage mimeMessage = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
        
        helper.setFrom(fromEmail);
        helper.setTo(emailNotification.getTo().toArray(new String[0]));
        helper.setSubject(emailNotification.getSubject());
        helper.setText(emailNotification.getBody(), emailNotification.isHtmlContent());
        
        if (!CollectionUtils.isEmpty(emailNotification.getCc())) {
            helper.setCc(emailNotification.getCc().toArray(new String[0]));
        }
        
        if (!CollectionUtils.isEmpty(emailNotification.getBcc())) {
            helper.setBcc(emailNotification.getBcc().toArray(new String[0]));
        }
        
        if (!CollectionUtils.isEmpty(emailNotification.getAttachments())) {
            for (AttachmentDTO attachment : emailNotification.getAttachments()) {
                helper.addAttachment(attachment.getFilename(), 
                        () -> new java.io.ByteArrayInputStream(attachment.getContent()));
            }
        }
        
        return mimeMessage;
    }
}

