package com.hireright.sourceintelligence.service.excel.mapper;

import com.hireright.sourceintelligence.api.dto.ParchmentRecord;
import com.hireright.sourceintelligence.service.excel.ExcelCellReader;
import com.hireright.sourceintelligence.service.excel.ExcelColumnMapping;
import com.hireright.sourceintelligence.service.excel.ExcelRowMapper;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.stereotype.Component;

import static com.hireright.sourceintelligence.service.excel.mapping.ParchmentColumnMapping.*;

@Component
public class ParchmentRowMapper implements ExcelRowMapper<ParchmentRecord> {

    @Override
    public ParchmentRecord mapRow(Row row, ExcelColumnMapping columnMapping) {
        return ParchmentRecord.builder()
                .institutionName(getCellValue(row, columnMapping, INSTITUTION_NAME))
                .country(getCellValue(row, columnMapping, COUNTRY))
                .city(getCellValue(row, columnMapping, CITY))
                .stateCountyRegion(getCellValue(row, columnMapping, STATE_COUNTY_REGION))
                .serviceProvider(getCellValue(row, columnMapping, SERVICE_PROVIDER))
                .surchargeAmount(getCellValue(row, columnMapping, SURCHARGE_AMOUNT))
                .paymentMethod(getCellValue(row, columnMapping, PAYMENT_METHOD))
                .code(getCellValue(row, columnMapping, CODE))
                .turnaroundTime(getCellValue(row, columnMapping, TURNAROUND_TIME))
                .followUpAllowed(getCellValue(row, columnMapping, FOLLOW_UP_ALLOWED))
                .build();
    }

    private String getCellValue(Row row, ExcelColumnMapping columnMapping, String fieldName) {
        Integer columnIndex = columnMapping.getColumnIndex(fieldName);
        if (columnIndex == null) {
            return "";
        }
        return ExcelCellReader.getCellValue(row, columnIndex);
    }
}