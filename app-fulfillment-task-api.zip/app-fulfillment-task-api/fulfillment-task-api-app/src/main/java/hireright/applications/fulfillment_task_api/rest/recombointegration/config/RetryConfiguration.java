/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.retry.support.RetryTemplate;

/**
 * Spring Retry configuration.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
@Configuration
@EnableRetry
public class RetryConfiguration
{
	@Bean
	public RetryTemplate retryTemplate()
	{
		return new RetryTemplate();
	}
}