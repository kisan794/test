package com.hireright.sourceintelligence.service.excel;

import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
public class GenericExcelParser {

    public <T> List<T> parseExcelFile(
            MultipartFile file,
            ExcelColumnMapping columnMapping,
            ExcelRowMapper<T> rowMapper) throws IOException {

        List<T> records = new ArrayList<>();

        try (InputStream inputStream = file.getInputStream();
             Workbook workbook = new XSSFWorkbook(inputStream)) {

            Sheet sheet = workbook.getSheetAt(columnMapping.getSheetIndex());

            Row headerRow = sheet.getRow(columnMapping.getHeaderRowIndex());
            ExcelColumnMapping dynamicColumnMapping = columnMapping.buildFromHeaderRow(headerRow);

            int lastRowNum = sheet.getLastRowNum();
            int dataStartRow = dynamicColumnMapping.getDataStartRowIndex();

            for (int rowIndex = dataStartRow; rowIndex <= lastRowNum; rowIndex++) {
                Row row = sheet.getRow(rowIndex);

                if (ExcelCellReader.isRowEmpty(row)) {
                    continue;
                }

                T rowRecord = rowMapper.mapRow(row, dynamicColumnMapping);
                records.add(rowRecord);

                if (log.isDebugEnabled()) {
                    log.debug("Parsed record at row {}", rowIndex);
                }
            }
        }

        log.info("Successfully parsed {} records from Excel file", records.size());
        return records;
    }
}