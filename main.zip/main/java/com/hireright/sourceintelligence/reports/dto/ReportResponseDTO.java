package com.hireright.sourceintelligence.reports.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.hireright.sourceintelligence.reports.domain.entity.ContactReport;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value = JsonInclude.Include.NON_EMPTY, content = JsonInclude.Include.NON_NULL)
public class ReportResponseDTO {
    private String reportType;
    private List<MetaDTO> meta;
    private List<ContactReport> contactUtilizationList;
    private List<GenericResponseDTO> response;
    private int currentPage;
    private long totalItems;
    private int totalPages;
    private int total;
}
