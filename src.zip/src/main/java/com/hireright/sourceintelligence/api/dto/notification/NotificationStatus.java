package com.hireright.sourceintelligence.api.dto.notification;

/**
 * Enum representing the status of a notification.
 */
public enum NotificationStatus {
    /**
     * Notification queued for asynchronous processing
     */
    QUEUED,
    
    /**
     * Notification is currently being processed
     */
    PROCESSING,
    
    /**
     * Notification sent successfully
     */
    SUCCESS,
    
    /**
     * Notification failed to send
     */
    FAILED,
    
    /**
     * Notification retry in progress
     */
    RETRYING,
    
    /**
     * Notification in dead letter queue
     */
    IN_DLQ
}

