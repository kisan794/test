package com.hireright.sourceintelligence.util;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ObjectDiffTest {

    static class TestObject {
        private String name;
        private Integer age;
        private String city;
        private String status;
        private String createdBy;
        private String action;

        public TestObject(String name, Integer age, String city,
                          String status, String createdBy, String action) {
            this.name = name;
            this.age = age;
            this.city = city;
            this.status = status;
            this.createdBy = createdBy;
            this.action = action;
        }

        public String getName() {
            return name;
        }

        public Integer getAge() {
            return age;
        }

        public String getCity() {
            return city;
        }

        public String getStatus() {
            return status;
        }

        public String getCreatedBy() {
            return createdBy;
        }

        public String getAction() {
            return action;
        }
    }

    @Test
    void constructor_shouldThrowIllegalStateException() throws Exception {
        Constructor<ObjectDiff> constructor = ObjectDiff.class.getDeclaredConstructor();
        constructor.setAccessible(true);

        InvocationTargetException exception =
                assertThrows(InvocationTargetException.class, constructor::newInstance);

        assertInstanceOf(IllegalStateException.class, exception.getCause());
        assertEquals("ObjectDiff class", exception.getCause().getMessage());
    }

    @Test
    void findChangedFields_shouldReturnChangedNonSkippedFields() {
        TestObject obj1 = new TestObject("John", 25, "New York", "ACTIVE", "user1", "CREATE");
        TestObject obj2 = new TestObject("Jane", 30, "New York", "INACTIVE", "user2", "UPDATE");

        List<String> changedFields = ObjectDiff.findChangedFields(obj1, obj2);

        assertEquals(2, changedFields.size());
        assertTrue(changedFields.contains("name"));
        assertTrue(changedFields.contains("age"));
    }

    @Test
    void findChangedFields_shouldIgnoreSkippedFieldsEvenIfChanged() {
        TestObject obj1 = new TestObject("John", 25, "Delhi", "ACTIVE", "user1", "CREATE");
        TestObject obj2 = new TestObject("John", 25, "Delhi", "INACTIVE", "user2", "UPDATE");

        List<String> changedFields = ObjectDiff.findChangedFields(obj1, obj2);

        assertNotNull(changedFields);
        assertTrue(changedFields.isEmpty());
    }

    @Test
    void findChangedFields_shouldReturnEmptyListWhenObjectsAreEqualForNonSkippedFields() {
        TestObject obj1 = new TestObject("John", 25, "Mumbai", "ACTIVE", "user1", "CREATE");
        TestObject obj2 = new TestObject("John", 25, "Mumbai", "ACTIVE", "user1", "CREATE");

        List<String> changedFields = ObjectDiff.findChangedFields(obj1, obj2);

        assertNotNull(changedFields);
        assertTrue(changedFields.isEmpty());
    }

    @Test
    void findChangedFields_shouldHandleNullValues() {
        TestObject obj1 = new TestObject(null, 25, null, "ACTIVE", "user1", "CREATE");
        TestObject obj2 = new TestObject("John", 25, null, "INACTIVE", "user2", "UPDATE");

        List<String> changedFields = ObjectDiff.findChangedFields(obj1, obj2);

        assertEquals(1, changedFields.size());
        assertTrue(changedFields.contains("name"));
        assertFalse(changedFields.contains("city"));
        assertFalse(changedFields.contains("status"));
        assertFalse(changedFields.contains("createdBy"));
        assertFalse(changedFields.contains("action"));
    }
}
