package com.hireright.sourceintelligence.service.impl.helperservices;

import com.hireright.sourceintelligence.api.dto.timezone.DropDownDTO;
import com.hireright.sourceintelligence.domain.entity.CountryRegionMapping;
import com.hireright.sourceintelligence.domain.repository.CountryRegionMappingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Primary
@Slf4j
@RequiredArgsConstructor
@Transactional
@Service
public class CountryRegionMappingUtils {

    private final CountryRegionMappingRepository countryRegionMappingRepository;
    private final MongoTemplate mongoTemplate;

    public String getRegionByCountry(String country){
        log.info("getRegionByCountry starts: {}", country);
        CountryRegionMapping countryRegionMapping = countryRegionMappingRepository.findByCountry(country);
        if(countryRegionMapping != null && countryRegionMapping.getRegion() != null){
            log.info("getRegionByCountry ends: {}", countryRegionMapping.getRegion());
            return countryRegionMapping.getRegion();
        }
        return "";
    }

    public List<String> findDistinctCountriesByRegion(String region){
        Query query = new Query();
        query.addCriteria(Criteria.where("region").is(region));
        return mongoTemplate.findDistinct(query,"country", CountryRegionMapping.class, String.class);
    }

    public String getRegion(String country){
        Map<String, String> regionMapping = new HashMap<>();
        regionMapping.put("USA", "US");
        regionMapping.put("United Kingdom", "EMEA");
        String region = regionMapping.getOrDefault(country, "");
        if (region.isEmpty()) {
            region = getRegionByCountry(country);
        }
        return region;
    }

    public List<DropDownDTO> getRegionList(){
        log.info("getRegionList starts");
        List<String> regions = mongoTemplate.query(CountryRegionMapping.class)
                .distinct("region")
                .as(String.class)
                .all();

        List<DropDownDTO> timeZones = new ArrayList<>();
        for (String region : regions) {
            DropDownDTO dropDownDTO = new DropDownDTO();
            dropDownDTO.setLabel(region);
            dropDownDTO.setValue(region);
            timeZones.add(dropDownDTO);
        }
        return timeZones;
    }

}
