package com.hireright.sourceintelligence.service.notification;

import com.hireright.sourceintelligence.api.dto.notification.EmailNotificationDTO;

/**
 * Interface for email notification operations.
 * Follows Interface Segregation Principle - specific to email operations.
 * Follows Dependency Inversion Principle - depend on abstraction, not implementation.
 */
public interface EmailNotificationService {
    
    /**
     * Sends an email notification synchronously
     *
     * @param emailDTO the email notification details
     * @return notification ID
     */
    String sendEmail(EmailNotificationDTO emailDTO);
    
    /**
     * Sends an email notification asynchronously
     *
     * @param emailDTO the email notification details
     * @return notification ID
     */
    String sendEmailAsync(EmailNotificationDTO emailDTO);
}

