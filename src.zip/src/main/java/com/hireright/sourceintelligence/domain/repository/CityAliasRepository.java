package com.hireright.sourceintelligence.domain.repository;

import com.hireright.sourceintelligence.domain.entity.CityAliasMapping;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface CityAliasRepository extends MongoRepository<CityAliasMapping, String> {

    @Query(value = "{ 'country': ?0, $or: [ { 'city': ?1 }, { 'aliases': ?1 } ] }", collation = "{ 'locale': 'en', 'strength': 2 }")
    CityAliasMapping findByCountryAndCityOrAliases(String country, String city);

}
