package com.hireright.sourceintelligence.service.extraction;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class DataExtractionProcessorFactoryTest {

    private DataExtractionProcessorFactory factory;

    @Test
    void constructor_WithEmptyList_ShouldInitializeSuccessfully() {
        List<DataExtractionProcessor> processors = Collections.emptyList();

        factory = new DataExtractionProcessorFactory(processors);

        assertNotNull(factory);
    }

    @Test
    void getProcessor_WithEmptyProcessorsList_ShouldThrowException() {
        List<DataExtractionProcessor> processors = Collections.emptyList();
        factory = new DataExtractionProcessorFactory(processors);

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> factory.getProcessor("parchment"));

        assertTrue(exception.getMessage().contains("Unsupported Data Extraction type: 'parchment'"));
        assertTrue(exception.getMessage().contains("Available types: none"));
    }

    @Test
    void getSupportedTypes_WithEmptyProcessors_ShouldReturnNone() {
        List<DataExtractionProcessor> processors = Collections.emptyList();
        factory = new DataExtractionProcessorFactory(processors);

        String supportedTypes = factory.getSupportedTypes();

        assertEquals("none", supportedTypes);
    }

    @Test
    void isSupported_WithEmptyProcessorsList_ShouldReturnFalse() {
        List<DataExtractionProcessor> processors = Collections.emptyList();
        factory = new DataExtractionProcessorFactory(processors);

        boolean result = factory.isSupported("parchment");

        assertFalse(result);
    }

}