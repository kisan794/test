package com.hireright.sourceintelligence.config;

import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CustomRequestLoggingFilterTest {

    @Test
    void shouldLog_shouldReturnFalse_forActuatorHealth() {
        TestableCustomRequestLoggingFilter filter = new TestableCustomRequestLoggingFilter();
        HttpServletRequest request = mock(HttpServletRequest.class);

        when(request.getRequestURI()).thenReturn("/actuator/health");

        assertFalse(filter.callShouldLog(request));
    }

    @Test
    void shouldLog_shouldReturnFalse_forActuatorHealthLiveness() {
        TestableCustomRequestLoggingFilter filter = new TestableCustomRequestLoggingFilter();
        HttpServletRequest request = mock(HttpServletRequest.class);

        when(request.getRequestURI()).thenReturn("/actuator/health/liveness");

        assertFalse(filter.callShouldLog(request));
    }

    @Test
    void shouldLog_shouldReturnFalse_forTimezones() {
        TestableCustomRequestLoggingFilter filter = new TestableCustomRequestLoggingFilter();
        HttpServletRequest request = mock(HttpServletRequest.class);

        when(request.getRequestURI()).thenReturn("/api/v1/timezones");

        assertFalse(filter.callShouldLog(request));
    }

    @Test
    void shouldLog_shouldReturnFalse_forSwaggerUi() {
        TestableCustomRequestLoggingFilter filter = new TestableCustomRequestLoggingFilter();
        HttpServletRequest request = mock(HttpServletRequest.class);

        when(request.getRequestURI()).thenReturn("/swagger-ui/index.html");

        assertFalse(filter.callShouldLog(request));
    }

    @Test
    void shouldLog_shouldReturnTrue_forOtherUris() {
        TestableCustomRequestLoggingFilter filter = new TestableCustomRequestLoggingFilter();
        HttpServletRequest request = mock(HttpServletRequest.class);

        when(request.getRequestURI()).thenReturn("/api/v1/source/search");

        assertTrue(filter.callShouldLog(request));
    }

    @Test
    void constructor_shouldCreateInstance() {
        CustomRequestLoggingFilter filter = new CustomRequestLoggingFilter();
        assertNotNull(filter);
    }

    private static class TestableCustomRequestLoggingFilter extends CustomRequestLoggingFilter {
        boolean callShouldLog(HttpServletRequest request) {
            return super.shouldLog(request);
        }
    }
}