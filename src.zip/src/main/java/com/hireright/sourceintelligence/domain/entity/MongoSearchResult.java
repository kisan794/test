package com.hireright.sourceintelligence.domain.entity;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MongoSearchResult {

  private List<Source> organizationList;
  private int total;
}
