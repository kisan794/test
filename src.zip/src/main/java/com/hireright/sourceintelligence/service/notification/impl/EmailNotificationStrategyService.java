package com.hireright.sourceintelligence.service.notification.impl;

import com.hireright.sourceintelligence.api.dto.notification.*;
import com.hireright.sourceintelligence.exception.CircuitBreakerOpenException;
import com.hireright.sourceintelligence.exception.EmailValidationException;
import com.hireright.sourceintelligence.exception.NotificationException;
import com.hireright.sourceintelligence.service.notification.DeadLetterQueueService;
import com.hireright.sourceintelligence.service.notification.EmailNotificationService;
import com.hireright.sourceintelligence.service.notification.NotificationService;
import com.hireright.sourceintelligence.service.notification.metrics.NotificationMetrics;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

/**
 * Strategy implementation for email notifications.
 * Follows Strategy Pattern - handles EMAIL notification type.
 * Follows Open/Closed Principle - can add new strategies without modifying this class.
 *
 * Improvements:
 * - Comprehensive exception handling with specific error codes
 * - Dead Letter Queue integration for failed notifications
 * - Enhanced error responses with detailed information
 * - Circuit breaker status propagation
 * - Validation error mapping
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class EmailNotificationStrategyService implements NotificationService {

    private final EmailNotificationService emailNotificationService;

    @Autowired(required = false)
    private DeadLetterQueueService deadLetterQueueService;

    @Autowired(required = false)
    private NotificationMetrics notificationMetrics;
    
    /**
     * Sends email notification based on async flag.
     * Implements comprehensive error handling with DLQ integration.
     */
    @Override
    public NotificationResponseDTO sendNotification(NotificationRequestDTO request) {
        log.info("Processing email notification request - requestId: {}, async: {}",
                request.getRequestId(), request.getAsync());

        EmailNotificationDTO emailDTO = request.getEmailNotification();

        // Validate email notification is present
        if (emailDTO == null) {
            log.error("Email notification details missing in request");
            return buildErrorResponse(
                    request,
                    null,
                    "Email notification details are required",
                    "MISSING_EMAIL_DATA",
                    null
            );
        }

        String notificationId = null;

        try {
            boolean isAsync = request.getAsync() != null && request.getAsync();

            if (isAsync) {
                notificationId = emailNotificationService.sendEmailAsync(emailDTO);
                log.info("Email notification queued successfully - ID: {}", notificationId);
                recordMetricsSuccess("EMAIL", true);
                return buildAsyncResponse(request, notificationId, emailDTO);
            } else {
                notificationId = emailNotificationService.sendEmail(emailDTO);
                log.info("Email notification sent successfully - ID: {}", notificationId);
                recordMetricsSuccess("EMAIL", false);
                return buildSyncResponse(request, notificationId, emailDTO);
            }

        } catch (EmailValidationException e) {
            // Validation errors - don't add to DLQ (client error)
            log.error("Email validation failed - requestId: {}", request.getRequestId(), e);
            recordMetricsValidationError("EMAIL", e.getField());
            return buildValidationErrorResponse(request, notificationId, e);

        } catch (CircuitBreakerOpenException e) {
            // Circuit breaker open - don't add to DLQ, service temporarily unavailable
            log.error("Circuit breaker open - requestId: {}", request.getRequestId(), e);
            recordMetricsCircuitBreakerOpen();
            recordMetricsFailure("EMAIL", e.getErrorCode());
            return buildCircuitBreakerErrorResponse(request, notificationId, e);

        } catch (NotificationException e) {
            // Notification errors - add to DLQ if enabled
            log.error("Notification error - requestId: {}", request.getRequestId(), e);
            recordMetricsFailure("EMAIL", e.getErrorCode());
            addToDeadLetterQueue(request, notificationId, e);
            return buildNotificationErrorResponse(request, notificationId, e);

        } catch (Exception e) {
            // Unexpected errors - add to DLQ if enabled
            log.error("Unexpected error sending email - requestId: {}", request.getRequestId(), e);
            recordMetricsFailure("EMAIL", "EMAIL_SEND_FAILED");
            addToDeadLetterQueue(request, notificationId, e);
            return buildGenericErrorResponse(request, notificationId, e);
        }
    }
    
    /**
     * Checks if this service supports the given notification type
     */
    @Override
    public boolean supports(NotificationRequestDTO request) {
        return request != null && NotificationType.EMAIL.equals(request.getNotificationType());
    }

    /**
     * Adds failed notification to Dead Letter Queue if enabled
     */
    private void addToDeadLetterQueue(NotificationRequestDTO request, String notificationId, Exception exception) {
        if (deadLetterQueueService != null) {
            try {
                deadLetterQueueService.addToDeadLetterQueue(request, notificationId, exception);
                log.info("Notification added to DLQ - ID: {}", notificationId);
                recordMetricsDLQEntry();
            } catch (Exception e) {
                log.error("Failed to add notification to DLQ - ID: {}", notificationId, e);
            }
        } else {
            log.debug("DLQ service not available, skipping");
        }
    }

    /**
     * Records metrics for successful notification
     */
    private void recordMetricsSuccess(String notificationType, boolean isAsync) {
        if (notificationMetrics != null) {
            notificationMetrics.recordSuccess(notificationType, isAsync);
        }
    }

    /**
     * Records metrics for failed notification
     */
    private void recordMetricsFailure(String notificationType, String errorCode) {
        if (notificationMetrics != null) {
            notificationMetrics.recordFailure(notificationType, errorCode);
        }
    }

    /**
     * Records metrics for validation error
     */
    private void recordMetricsValidationError(String notificationType, String field) {
        if (notificationMetrics != null) {
            notificationMetrics.recordValidationError(notificationType, field);
        }
    }

    /**
     * Records metrics for circuit breaker open
     */
    private void recordMetricsCircuitBreakerOpen() {
        if (notificationMetrics != null) {
            notificationMetrics.recordCircuitBreakerOpen();
        }
    }

    /**
     * Records metrics for DLQ entry
     */
    private void recordMetricsDLQEntry() {
        if (notificationMetrics != null) {
            notificationMetrics.recordDLQEntry();
        }
    }
    
    /**
     * Builds response for synchronous email sending
     */
    private NotificationResponseDTO buildSyncResponse(NotificationRequestDTO request,
                                                       String notificationId,
                                                       EmailNotificationDTO emailDTO) {
        int recipientCount = calculateRecipientCount(emailDTO);
        
        Map<String, String> metadata = new HashMap<>();
        metadata.put("async", "false");
        metadata.put("type", "EMAIL");
        metadata.put("provider", "smtp");
        
        return NotificationResponseDTO.builder()
                .status(NotificationStatus.SUCCESS)
                .message("Email notification sent successfully")
                .notificationId(notificationId)
                .requestId(request.getRequestId())
                .sentAt(Instant.now().toString())
                .recipientCount(recipientCount)
                .metadata(metadata)
                .build();
    }
    
    /**
     * Builds response for asynchronous email sending
     */
    private NotificationResponseDTO buildAsyncResponse(NotificationRequestDTO request,
                                                        String notificationId,
                                                        EmailNotificationDTO emailDTO) {
        return NotificationResponseDTO.builder()
                .status(NotificationStatus.QUEUED)
                .message("Email notification queued for processing")
                .notificationId(notificationId)
                .requestId(request.getRequestId())
                .queuedAt(Instant.now().toString())
                .estimatedProcessingTime("5s")
                .recipientCount(calculateRecipientCount(emailDTO))
                .build();
    }
    
    /**
     * Builds validation error response (400 Bad Request)
     */
    private NotificationResponseDTO buildValidationErrorResponse(NotificationRequestDTO request,
                                                                  String notificationId,
                                                                  EmailValidationException e) {
        return NotificationResponseDTO.builder()
                .status(NotificationStatus.FAILED)
                .message("Email validation failed")
                .notificationId(notificationId)
                .requestId(request.getRequestId())
                .errorCode(e.getErrorCode())
                .errorDetails(e.getMessage())
                .field(e.getField())
                .timestamp(Instant.now().toString())
                .build();
    }

    /**
     * Builds circuit breaker error response (503 Service Unavailable)
     */
    private NotificationResponseDTO buildCircuitBreakerErrorResponse(NotificationRequestDTO request,
                                                                      String notificationId,
                                                                      CircuitBreakerOpenException e) {
        return NotificationResponseDTO.builder()
                .status(NotificationStatus.FAILED)
                .message("Email service temporarily unavailable")
                .notificationId(notificationId)
                .requestId(request.getRequestId())
                .errorCode(e.getErrorCode())
                .errorDetails(e.getMessage())
                .retryAfter(e.getRetryAfter())
                .circuitState("OPEN")
                .failureRate(e.getFailureRate())
                .timestamp(Instant.now().toString())
                .build();
    }

    /**
     * Builds notification error response (500 Internal Server Error)
     */
    private NotificationResponseDTO buildNotificationErrorResponse(NotificationRequestDTO request,
                                                                    String notificationId,
                                                                    NotificationException e) {
        Map<String, String> metadata = new HashMap<>();
        metadata.put("addedToDLQ", "true");
        metadata.put("willRetry", "true");

        return NotificationResponseDTO.builder()
                .status(NotificationStatus.FAILED)
                .message("Email notification failed")
                .notificationId(notificationId)
                .requestId(request.getRequestId())
                .errorCode(e.getErrorCode())
                .errorDetails(e.getMessage())
                .metadata(metadata)
                .timestamp(Instant.now().toString())
                .build();
    }

    /**
     * Builds generic error response (500 Internal Server Error)
     */
    private NotificationResponseDTO buildGenericErrorResponse(NotificationRequestDTO request,
                                                               String notificationId,
                                                               Exception e) {
        Map<String, String> metadata = new HashMap<>();
        metadata.put("addedToDLQ", "true");
        metadata.put("willRetry", "true");
        metadata.put("exceptionType", e.getClass().getSimpleName());

        return NotificationResponseDTO.builder()
                .status(NotificationStatus.FAILED)
                .message("Email notification failed")
                .notificationId(notificationId)
                .requestId(request.getRequestId())
                .errorCode("EMAIL_SEND_FAILED")
                .errorDetails(e.getMessage())
                .metadata(metadata)
                .timestamp(Instant.now().toString())
                .build();
    }

    /**
     * Builds error response for missing email data (400 Bad Request)
     */
    private NotificationResponseDTO buildErrorResponse(NotificationRequestDTO request,
                                                        String notificationId,
                                                        String errorMessage,
                                                        String errorCode,
                                                        String field) {
        return NotificationResponseDTO.builder()
                .status(NotificationStatus.FAILED)
                .message("Email notification failed")
                .notificationId(notificationId)
                .requestId(request.getRequestId())
                .errorCode(errorCode)
                .errorDetails(errorMessage)
                .field(field)
                .timestamp(Instant.now().toString())
                .build();
    }
    
    /**
     * Calculates total recipient count
     */
    private int calculateRecipientCount(EmailNotificationDTO emailDTO) {
        int count = 0;
        
        if (emailDTO.getTo() != null) {
            count += emailDTO.getTo().size();
        }
        
        if (emailDTO.getCc() != null) {
            count += emailDTO.getCc().size();
        }
        
        if (emailDTO.getBcc() != null) {
            count += emailDTO.getBcc().size();
        }
        
        return count;
    }
}

