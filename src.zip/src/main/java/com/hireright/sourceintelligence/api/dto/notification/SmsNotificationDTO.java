package com.hireright.sourceintelligence.api.dto.notification;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * DTO for SMS notification details
 * Supports multiple SMS providers (Twilio, AWS SNS, etc.)
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SmsNotificationDTO {
    
    /**
     * Phone numbers in E.164 format (e.g., +14155552671)
     */
    @NotEmpty(message = "At least one recipient phone number is required")
    private List<@Pattern(regexp = "^\\+?[1-9]\\d{1,14}$", message = "Invalid phone number format") String> phoneNumbers;
    
    /**
     * SMS message body (160 characters recommended, 1600 max for concatenated)
     */
    @NotBlank(message = "Message body is required")
    private String message;
    
    /**
     * Sender ID or phone number (provider-specific)
     */
    private String from;
    
    /**
     * SMS provider to use (TWILIO, AWS_SNS, VONAGE, etc.)
     */
    private SmsProvider provider;
    
    /**
     * Message priority (HIGH, NORMAL, LOW)
     */
    @Builder.Default
    private MessagePriority priority = MessagePriority.NORMAL;
    
    /**
     * Schedule delivery time (ISO-8601 format)
     */
    private String scheduledTime;
    
    /**
     * Enable delivery receipt tracking
     */
    @Builder.Default
    private Boolean trackDelivery = false;
    
    /**
     * Maximum retry attempts on failure
     */
    @Builder.Default
    private Integer maxRetries = 3;
    
    /**
     * Additional provider-specific metadata
     */
    private Map<String, Object> metadata;
    
    /**
     * Tags for categorization and reporting
     */
    private List<String> tags;
    
    public enum SmsProvider {
        TWILIO,
        AWS_SNS,
        VONAGE,
        MESSAGEBIRD,
        SINCH,
        DEFAULT
    }
    
    public enum MessagePriority {
        HIGH,
        NORMAL,
        LOW
    }
}

