package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.AutocompleteSearchDTO;
import com.hireright.sourceintelligence.api.dto.SearchResponseDTO;
import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.api.dto.UserInfo;
import com.hireright.sourceintelligence.api.dto.history.ChangeLogFilters;
import com.hireright.sourceintelligence.domain.entity.MongoSearchResult;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.exception.ResourceNotFoundException;
import com.hireright.sourceintelligence.service.impl.CommonSearchImpl;
import com.hireright.sourceintelligence.service.impl.SearchHistoryServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.LAST_MODIFIED_BY;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.ORGANIZATION_NAME;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SearchHistoryServiceTest {

    @InjectMocks
    private SearchHistoryServiceImpl searchHistoryServiceImpl;

    @Mock
    private CustomSourceRepository<Source> customSourceRepository;

    @Mock
    private SourceMapper sourceMapper;

    @Mock
    private CommonSearchImpl commonSearchImpl;

    @Test
    void constructor_shouldCreateInstance() {
        SearchHistoryServiceImpl service =
                new SearchHistoryServiceImpl(sourceMapper, commonSearchImpl, customSourceRepository);

        assertNotNull(service);
    }

    @Test
    void getAutocompletedFilters_shouldDelegateToCommonSearch() {
        List<AutocompleteSearchDTO> expected = Collections.singletonList(new AutocompleteSearchDTO());
        when(commonSearchImpl.getAutocompletedFilters(anyString(), eq(false), anyMap(), anyString()))
                .thenReturn(expected);

        List<AutocompleteSearchDTO> result =
                searchHistoryServiceImpl.getAutocompletedFilters(OrganizationType.EDUCATION, "uni", new UserInfo());

        assertSame(expected, result);
        verify(commonSearchImpl).getAutocompletedFilters(eq("uni"), eq(false), anyMap(), contains("history"));
    }

    @Test
    void getSourceOrganizationsByFilters_shouldReturnResponse_forManager_withEmptySearchFilterAndEmptyApprovalStatuses() {
        UserInfo userInfo = new UserInfo();
        userInfo.setUsername("manager.user");
        userInfo.setRoles(List.of("Manager"));

        Map<String, Set<String>> searchFilter = new HashMap<>();
        List<ApprovalStatus> approvalStatuses = new ArrayList<>();

        Source source = new Source();
        MongoSearchResult mongoSearchResult = MongoSearchResult.builder()
                .organizationList(List.of(source))
                .total(1)
                .build();

        List<SourceOrganizationDTO> mappedList = List.of(mock(SourceOrganizationDTO.class));

        when(customSourceRepository.customAggregate(any(), anyString(), eq(MongoSearchResult.class)))
                .thenReturn(mongoSearchResult);
        when(sourceMapper.toSourceDTOList(anyList())).thenReturn(mappedList);

        SearchResponseDTO result = searchHistoryServiceImpl.getSourceOrganizationsByFilters(
                OrganizationType.EDUCATION, searchFilter, approvalStatuses, 1, 10, userInfo);

        assertNotNull(result);
        assertEquals(1, result.getCurrentPage());
        assertEquals(1, result.getTotalItems());
        assertEquals(1, result.getTotalPages());
        assertEquals(mappedList, result.getSourceList());
    }

    @Test
    void getSourceOrganizationsByFilters_shouldReturnResponse_forQualityAnalystOnly_withSearchFilterAndApprovalStatuses() {
        UserInfo userInfo = new UserInfo();
        userInfo.setUsername("qa.user");
        userInfo.setRoles(List.of("Quality Analyst"));

        Map<String, Set<String>> searchFilter = new HashMap<>();
        searchFilter.put("country", Set.of("India"));

        List<ApprovalStatus> approvalStatuses = List.of(ApprovalStatus.APPROVED);

        Source source = new Source();
        MongoSearchResult mongoSearchResult = MongoSearchResult.builder()
                .organizationList(List.of(source))
                .total(1)
                .build();

        List<SourceOrganizationDTO> mappedList = List.of(mock(SourceOrganizationDTO.class));

        when(customSourceRepository.customAggregate(any(), anyString(), eq(MongoSearchResult.class)))
                .thenReturn(mongoSearchResult);
        when(sourceMapper.toSourceDTOList(anyList())).thenReturn(mappedList);

        SearchResponseDTO result = searchHistoryServiceImpl.getSourceOrganizationsByFilters(
                OrganizationType.EDUCATION, searchFilter, approvalStatuses, 1, 10, userInfo);

        assertNotNull(result);
        assertEquals(1, result.getTotalItems());
        assertEquals(1, result.getTotalPages());
        assertEquals(mappedList, result.getSourceList());
    }

    @Test
    void getSourceOrganizationsByFilters_shouldReturnResponse_forQualityAnalystAndSupervisor_notQaOnly() {
        UserInfo userInfo = new UserInfo();
        userInfo.setUsername("mixed.role.user");
        userInfo.setRoles(List.of("Quality Analyst", "Supervisor"));

        Map<String, Set<String>> searchFilter = new HashMap<>();
        searchFilter.put("state", Set.of("KA"));

        List<ApprovalStatus> approvalStatuses = List.of(ApprovalStatus.APPROVED);

        Source source = new Source();
        MongoSearchResult mongoSearchResult = MongoSearchResult.builder()
                .organizationList(List.of(source))
                .total(2)
                .build();

        List<SourceOrganizationDTO> mappedList = List.of(mock(SourceOrganizationDTO.class));

        when(customSourceRepository.customAggregate(any(), anyString(), eq(MongoSearchResult.class)))
                .thenReturn(mongoSearchResult);
        when(sourceMapper.toSourceDTOList(anyList())).thenReturn(mappedList);

        SearchResponseDTO result = searchHistoryServiceImpl.getSourceOrganizationsByFilters(
                OrganizationType.EMPLOYMENT, searchFilter, approvalStatuses, 1, 2, userInfo);

        assertNotNull(result);
        assertEquals(2, result.getTotalItems());
        assertEquals(1, result.getTotalPages());
        assertEquals(mappedList, result.getSourceList());
    }

    @Test
    void getSourceOrganizationsByFilters_shouldThrowResourceNotFound_whenOrganizationListIsEmpty() {
        UserInfo userInfo = new UserInfo();
        userInfo.setUsername("manager.user");
        userInfo.setRoles(List.of("Manager"));

        Map<String, Set<String>> searchFilter = new HashMap<>();
        searchFilter.put("country", Set.of("India"));

        List<ApprovalStatus> approvalStatuses = List.of(ApprovalStatus.APPROVED);

        MongoSearchResult mongoSearchResult = MongoSearchResult.builder()
                .organizationList(Collections.emptyList())
                .total(0)
                .build();

        when(customSourceRepository.customAggregate(any(), anyString(), eq(MongoSearchResult.class)))
                .thenReturn(mongoSearchResult);

        assertThatExceptionOfType(ResourceNotFoundException.class)
                .isThrownBy(() -> searchHistoryServiceImpl.getSourceOrganizationsByFilters(
                        OrganizationType.EDUCATION, searchFilter, approvalStatuses, 1, 10, userInfo));
    }

    @Test
    void getChangeLogsByFilters_shouldSetDefaultPaginationAndReturnEmptyResponse_whenNoResultsFound() {
        ChangeLogFilters filters = new ChangeLogFilters();
        filters.setOrganizationType(OrganizationType.EDUCATION);
        filters.setStartPage(0);
        filters.setPageSize(0);

        when(customSourceRepository.queryCount(any(), anyString(), eq(Source.class))).thenReturn(0L);
        when(customSourceRepository.aggregate(any(), anyString(), eq(Source.class))).thenReturn(Collections.emptyList());

        SearchResponseDTO result = searchHistoryServiceImpl.getChangeLogsByFilters(filters);

        assertNotNull(result);
        assertEquals(1, filters.getStartPage());
        assertEquals(10, filters.getPageSize());
        assertEquals(0, result.getTotalItems());
        assertEquals(0, result.getTotalPages());
        assertTrue(result.getSourceList().isEmpty());
    }

    @Test
    void getChangeLogsByFilters_shouldReturnResponse_whenSortIsOrganizationName() {
        ChangeLogFilters filters = new ChangeLogFilters();
        filters.setOrganizationType(OrganizationType.EDUCATION);
        filters.setStartPage(1);
        filters.setPageSize(10);
        filters.setSort(ORGANIZATION_NAME);
        filters.setOrder("ASC");

        List<Source> sources = List.of(new Source());
        List<SourceOrganizationDTO> mappedList = List.of(mock(SourceOrganizationDTO.class));

        when(customSourceRepository.queryCount(any(), anyString(), eq(Source.class))).thenReturn(1L);
        when(customSourceRepository.aggregate(any(), anyString(), eq(Source.class))).thenReturn(sources);
        when(sourceMapper.toSourceDTOList(sources)).thenReturn(mappedList);

        SearchResponseDTO result = searchHistoryServiceImpl.getChangeLogsByFilters(filters);

        assertNotNull(result);
        assertEquals(1, result.getCurrentPage());
        assertEquals(1, result.getTotalItems());
        assertEquals(1, result.getTotalPages());
        assertEquals(mappedList, result.getSourceList());
    }

    @Test
    void getChangeLogsByFilters_shouldReturnResponse_whenSortIsLastModifiedBy() {
        ChangeLogFilters filters = new ChangeLogFilters();
        filters.setOrganizationType(OrganizationType.EDUCATION);
        filters.setStartPage(1);
        filters.setPageSize(5);
        filters.setSort(LAST_MODIFIED_BY);
        filters.setOrder("DESC");

        List<Source> sources = List.of(new Source(), new Source());
        List<SourceOrganizationDTO> mappedList = List.of(
                mock(SourceOrganizationDTO.class),
                mock(SourceOrganizationDTO.class)
        );

        when(customSourceRepository.queryCount(any(), anyString(), eq(Source.class))).thenReturn(2L);
        when(customSourceRepository.aggregate(any(), anyString(), eq(Source.class))).thenReturn(sources);
        when(sourceMapper.toSourceDTOList(sources)).thenReturn(mappedList);

        SearchResponseDTO result = searchHistoryServiceImpl.getChangeLogsByFilters(filters);

        assertNotNull(result);
        assertEquals(1, result.getCurrentPage());
        assertEquals(2, result.getTotalItems());
        assertEquals(1, result.getTotalPages());
        assertEquals(mappedList, result.getSourceList());
    }

    @Test
    void getChangeLogsByFilters_shouldReturnResponse_whenSortAndOrderAreNull() {
        ChangeLogFilters filters = new ChangeLogFilters();
        filters.setOrganizationType(OrganizationType.EDUCATION);
        filters.setStartPage(2);
        filters.setPageSize(2);

        List<Source> sources = List.of(new Source(), new Source(), new Source());
        List<SourceOrganizationDTO> mappedList = List.of(
                mock(SourceOrganizationDTO.class),
                mock(SourceOrganizationDTO.class),
                mock(SourceOrganizationDTO.class)
        );

        when(customSourceRepository.queryCount(any(), anyString(), eq(Source.class))).thenReturn(3L);
        when(customSourceRepository.aggregate(any(), anyString(), eq(Source.class))).thenReturn(sources);
        when(sourceMapper.toSourceDTOList(sources)).thenReturn(mappedList);

        SearchResponseDTO result = searchHistoryServiceImpl.getChangeLogsByFilters(filters);

        assertNotNull(result);
        assertEquals(2, result.getCurrentPage());
        assertEquals(3, result.getTotalItems());
        assertEquals(2, result.getTotalPages());
        assertEquals(mappedList, result.getSourceList());
    }
}