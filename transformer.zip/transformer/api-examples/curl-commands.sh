#!/bin/bash

# Form Field Configuration API - cURL Examples
# Base URL
BASE_URL="http://localhost:8080/api/v1/form-config"

echo "=========================================="
echo "Form Field Configuration API Examples"
echo "=========================================="
echo ""

# 1. Initialize Default Configurations
echo "1. Initialize Default Configurations"
echo "POST ${BASE_URL}/initialize"
curl -X POST "${BASE_URL}/initialize" \
  -H "Content-Type: application/json" | jq .
echo ""
echo ""

# 2. Get All Active Configurations
echo "2. Get All Active Configurations (for form rendering)"
echo "GET ${BASE_URL}/active"
curl -X GET "${BASE_URL}/active" \
  -H "Content-Type: application/json" | jq .
echo ""
echo ""

# 3. Create Department Dropdown
echo "3. Create Department Dropdown Configuration"
echo "POST ${BASE_URL}"
curl -X POST "${BASE_URL}" \
  -H "Content-Type: application/json" \
  -d '{
    "fieldKey": "department",
    "fieldLabel": "Department / Function",
    "fieldDescription": "Select your department",
    "fieldType": "DROPDOWN",
    "section": "Basic Information",
    "displayOrder": 3,
    "required": true,
    "active": true,
    "options": [
      {
        "value": "IT",
        "label": "Information Technology",
        "description": "IT Operations, Development, Infrastructure",
        "order": 1,
        "active": true
      },
      {
        "value": "HR",
        "label": "Human Resources",
        "description": "Recruitment, Training, Employee Relations",
        "order": 2,
        "active": true
      },
      {
        "value": "FINANCE",
        "label": "Finance",
        "description": "Accounting, Budgeting, Financial Planning",
        "order": 3,
        "active": true
      },
      {
        "value": "OPERATIONS",
        "label": "Operations",
        "description": "Production, Logistics, Supply Chain",
        "order": 4,
        "active": true
      },
      {
        "value": "SALES",
        "label": "Sales & Marketing",
        "description": "Sales, Marketing, Customer Relations",
        "order": 5,
        "active": true
      }
    ]
  }' | jq .
echo ""
echo ""

# 4. Create Priority Level Radio Buttons
echo "4. Create Priority Level Configuration"
echo "POST ${BASE_URL}"
curl -X POST "${BASE_URL}" \
  -H "Content-Type: application/json" \
  -d '{
    "fieldKey": "priorityLevel",
    "fieldLabel": "Priority Level",
    "fieldDescription": "How urgent is this idea?",
    "fieldType": "RADIO",
    "section": "Implementation Details",
    "displayOrder": 7,
    "required": false,
    "active": true,
    "options": [
      {
        "value": "CRITICAL",
        "label": "Critical",
        "description": "Immediate action required - business critical",
        "order": 1,
        "active": true
      },
      {
        "value": "HIGH",
        "label": "High",
        "description": "Important - should be addressed soon",
        "order": 2,
        "active": true
      },
      {
        "value": "MEDIUM",
        "label": "Medium",
        "description": "Moderate importance - can be scheduled",
        "order": 3,
        "active": true
      },
      {
        "value": "LOW",
        "label": "Low",
        "description": "Nice to have - low priority",
        "order": 4,
        "active": true
      }
    ]
  }' | jq .
echo ""
echo ""

# 5. Create Resources Needed Multi-Select
echo "5. Create Resources Needed Configuration"
echo "POST ${BASE_URL}"
curl -X POST "${BASE_URL}" \
  -H "Content-Type: application/json" \
  -d '{
    "fieldKey": "resourcesNeeded",
    "fieldLabel": "Resources Needed",
    "fieldDescription": "Select all resources required for implementation",
    "fieldType": "MULTI_SELECT",
    "section": "Implementation Details",
    "displayOrder": 8,
    "required": false,
    "active": true,
    "options": [
      {
        "value": "BUDGET",
        "label": "Budget / Funding",
        "description": "Financial resources required",
        "order": 1,
        "active": true
      },
      {
        "value": "PERSONNEL",
        "label": "Additional Personnel",
        "description": "Need to hire or assign more people",
        "order": 2,
        "active": true
      },
      {
        "value": "TECHNOLOGY",
        "label": "Technology / Software",
        "description": "New tools, software, or hardware",
        "order": 3,
        "active": true
      },
      {
        "value": "TRAINING",
        "label": "Training",
        "description": "Employee training or skill development",
        "order": 4,
        "active": true
      },
      {
        "value": "EXTERNAL_SUPPORT",
        "label": "External Support",
        "description": "Consultants, vendors, or partners",
        "order": 5,
        "active": true
      }
    ]
  }' | jq .
echo ""
echo ""

# 6. Get Specific Configuration
echo "6. Get Specific Configuration by Key"
echo "GET ${BASE_URL}/impactAreas"
curl -X GET "${BASE_URL}/impactAreas" \
  -H "Content-Type: application/json" | jq .
echo ""
echo ""

# 7. Update Configuration
echo "7. Update Configuration (Add new option to impactAreas)"
echo "PUT ${BASE_URL}/impactAreas"
curl -X PUT "${BASE_URL}/impactAreas" \
  -H "Content-Type: application/json" \
  -d '{
    "fieldKey": "impactAreas",
    "fieldLabel": "Which area does this idea impact?",
    "fieldDescription": "Select all that apply",
    "fieldType": "MULTI_SELECT",
    "section": "Area of Impact",
    "displayOrder": 1,
    "required": false,
    "active": true,
    "options": [
      {
        "value": "PROCESS",
        "label": "Process",
        "description": "Streamlining workflows, automation, reducing errors",
        "order": 1,
        "active": true
      },
      {
        "value": "PEOPLE",
        "label": "People",
        "description": "Training, morale, collaboration, safety",
        "order": 2,
        "active": true
      },
      {
        "value": "QUALITY",
        "label": "Quality",
        "description": "Product/service quality, customer experience, compliance",
        "order": 3,
        "active": true
      },
      {
        "value": "TECHNOLOGY",
        "label": "Technology",
        "description": "IT systems, digital transformation, innovation",
        "order": 4,
        "active": true
      }
    ]
  }' | jq .
echo ""
echo ""

# 8. Get All Configurations
echo "8. Get All Configurations"
echo "GET ${BASE_URL}"
curl -X GET "${BASE_URL}" \
  -H "Content-Type: application/json" | jq .
echo ""
echo ""

# 9. Get Configurations by Section
echo "9. Get Configurations by Section"
echo "GET ${BASE_URL}/section/Implementation%20Details"
curl -X GET "${BASE_URL}/section/Implementation%20Details" \
  -H "Content-Type: application/json" | jq .
echo ""
echo ""

echo "=========================================="
echo "All examples completed!"
echo "=========================================="

