package com.hireright.sourceintelligence.api.dto;

import lombok.Data;

import java.util.List;

@Data
public class SuggestionsResponseDTO {
    private List<SuggestionsDTO> data;
    private int total;
}
