package com.hireright.sourceintelligence.service.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * A custom exception class to handle erroneous business scenarios.
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class BusinessException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	private String resultMessage;

}