/*
 *
 * Created 2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	sergey.sablin	Oct 25, 2017	Created
 */
package hireright.project.accesspoint.entrypoint;

import hireright.bdk.instance_parameter.CInstanceParameter;
import hireright.objects.utilities.CDomain;
import hireright.objects.utilities.fields.CFEntryPoint;
import hireright.project.accesspoint.model.CreateResponse;
import hireright.project.accesspoint.model.EntryPoint;
import hireright.sdk.util.CRuntimeException;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.StringReader;
import java.io.StringWriter;

/**
 *  The class allows to create cross instance entrypoint.
 *  @author Sablin Sergey
 */
public class CTemporaryEntryPointFactory {

	public static String getEntryPointKey( EntryPoint entrypoint, String instanceID )
	{
		String entrypointToAccessPoint = CDomain.getDomain( CInstanceParameter.getDomainID(instanceID) )
				  .getEntryPoint( CDomain.ENTRY_POINT_ACCESS_POINT_REST, CDomain.EMPTY );

		String responseString = sendPostToRestApi(
				entrypointToAccessPoint,
				marshalClass( entrypoint )
			  );

		CreateResponse response = (CreateResponse)unmarshalString( responseString );

		return response.getReturnBean().getKey();
	};

	public static String getEntryPointURL( String key, String instanceID, String entryPointName )
	{
		String tempEPToSMPattern = CDomain.getDomain( CInstanceParameter.getDomainID(instanceID) )
										  .getEntryPoint( entryPointName, CDomain.EMPTY );

		return tempEPToSMPattern.replace( "%" + CFEntryPoint.FIELD_KEY + "%", key );
	};

	public static String getEntryPointURL( EntryPoint entrypoint, String instanceID, String entryPointName )
	{
		return getEntryPointURL(
					getEntryPointKey( entrypoint, instanceID ),
					instanceID,
					entryPointName
			   );
	};

	private static String sendPostToRestApi( String url, String payload )
	{
		try {
			HttpClient c = new DefaultHttpClient();
	        HttpPost p = new HttpPost( url );

	        StringEntity stringEntity = new StringEntity(payload);

	        p.setEntity( stringEntity );

	        HttpResponse httpResponse = c.execute(p);

	        HttpEntity entity = httpResponse.getEntity();
	        String responseString = EntityUtils.toString(entity, "UTF-8");

			return responseString;
		} catch( Exception e ) {
			throw new CRuntimeException( e );
		}
	}

	private static CreateResponse unmarshalString( String str ) {
		try {
			JAXBContext jaxb = JAXBContext.newInstance( CreateResponse.class );
			Unmarshaller jaxbUnmarshaller = jaxb.createUnmarshaller();
			StringReader reader = new StringReader( str );
			return (CreateResponse)jaxbUnmarshaller.unmarshal( reader );
		} catch( Exception e ) {
			throw new CRuntimeException( e );
		}
	}

	private static String marshalClass( Object object ) {
		try {
			StringWriter sw = new StringWriter();
			JAXBContext jaxb = JAXBContext.newInstance( object.getClass() );
			Marshaller marshaller = jaxb.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);
			marshaller.marshal( object, sw );
			return sw.toString();
		} catch( Exception e ) {
			throw new CRuntimeException( e );
		}
	}
}
