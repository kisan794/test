package com.hireright.sourceintelligence.service.excel;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
@Component
public class ExcelParserFactory {

    private final Map<String, ExcelParserStrategy<?>> parserStrategies;

    public ExcelParserFactory(List<ExcelParserStrategy<?>> strategies) {
        this.parserStrategies = strategies.stream()
                .collect(Collectors.toMap(
                        ExcelParserStrategy::getParserType,
                        Function.identity()
                ));
    }

    @SuppressWarnings("unchecked")
    public <T> ExcelParserStrategy<T> getParser(String parserType) {
        ExcelParserStrategy<?> strategy = parserStrategies.get(parserType);

        if (strategy == null) {
            throw new IllegalArgumentException(
                    String.format("No parser strategy found for type: %s. Available types: %s",
                            parserType,
                            parserStrategies.keySet())
            );
        }

        return (ExcelParserStrategy<T>) strategy;
    }

}