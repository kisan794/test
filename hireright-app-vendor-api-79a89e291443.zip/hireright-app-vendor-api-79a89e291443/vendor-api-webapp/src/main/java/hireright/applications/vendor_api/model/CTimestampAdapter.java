/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-07-25	Created
 */
package hireright.applications.vendor_api.model;

import java.sql.Timestamp;

import jakarta.xml.bind.annotation.adapters.XmlAdapter;

public class CTimestampAdapter extends XmlAdapter<String, Timestamp>
{
	@Override
	public String marshal(Timestamp time) throws Exception
	{
		return time.toString();
	}

	@Override
	public Timestamp unmarshal(String time) throws Exception
	{
		return Timestamp.valueOf(time);
	}
}
