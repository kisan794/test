package org.example.recombointegration.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.recombointegration.document.DynamicFormSubmission.SubmissionStatus;
import org.example.recombointegration.dto.DynamicFormSubmissionRequest;
import org.example.recombointegration.dto.DynamicFormSubmissionResponse;
import org.example.recombointegration.service.DynamicFormSubmissionService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * REST Controller for Dynamic Form Submissions.
 * Provides endpoints for submitting and managing form data dynamically.
 *
 * @author Generated
 * @version 1.0
 */
@Tag(name = "Dynamic Form Submission", description = "APIs for submitting and managing dynamic form data")
@Slf4j
@RestController
@RequestMapping("/api/v1/submissions")
@RequiredArgsConstructor
public class DynamicFormSubmissionController {

    private final DynamicFormSubmissionService submissionService;

    /**
     * Submit a new form.
     */
    @Operation(
            summary = "Submit a form",
            description = "Submit a new form with dynamic data. The form data is validated against the form configuration."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Form submitted successfully",
                    content = @Content(schema = @Schema(implementation = DynamicFormSubmissionResponse.class))),
            @ApiResponse(responseCode = "400", description = "Invalid form data or validation failed")
    })
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<DynamicFormSubmissionResponse> submitForm(
            @Valid @RequestBody DynamicFormSubmissionRequest request) {
        log.info("Received form submission request for formId: {}", request.getFormId());
        DynamicFormSubmissionResponse response = submissionService.submitForm(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * Update an existing form submission.
     */
    @Operation(
            summary = "Update form submission",
            description = "Update an existing form submission with new data."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Form updated successfully",
                    content = @Content(schema = @Schema(implementation = DynamicFormSubmissionResponse.class))),
            @ApiResponse(responseCode = "404", description = "Submission not found")
    })
    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<DynamicFormSubmissionResponse> updateSubmission(
            @Parameter(description = "Submission ID", required = true)
            @PathVariable String id,
            @Valid @RequestBody DynamicFormSubmissionRequest request) {
        log.info("Received request to update submission ID: {}", id);
        DynamicFormSubmissionResponse response = submissionService.updateSubmission(id, request);
        return ResponseEntity.ok(response);
    }

    /**
     * Get submission by ID.
     */
    @Operation(
            summary = "Get submission by ID",
            description = "Retrieve a specific form submission by its ID."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Submission found",
                    content = @Content(schema = @Schema(implementation = DynamicFormSubmissionResponse.class))),
            @ApiResponse(responseCode = "404", description = "Submission not found")
    })
    @GetMapping("/{id}")
    public ResponseEntity<DynamicFormSubmissionResponse> getSubmissionById(
            @Parameter(description = "Submission ID", required = true)
            @PathVariable String id) {
        log.info("Received request to get submission ID: {}", id);
        DynamicFormSubmissionResponse response = submissionService.getSubmissionById(id);
        return ResponseEntity.ok(response);
    }

    /**
     * Get all submissions for a form.
     */
    @Operation(
            summary = "Get submissions by form ID",
            description = "Retrieve all submissions for a specific form with pagination."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Submissions retrieved successfully",
                    content = @Content(schema = @Schema(implementation = Page.class)))
    })
    @GetMapping("/form/{formId}")
    public ResponseEntity<Page<DynamicFormSubmissionResponse>> getSubmissionsByFormId(
            @Parameter(description = "Form ID", required = true)
            @PathVariable String formId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "submissionDate") String sortBy,
            @RequestParam(defaultValue = "DESC") String sortDirection) {
        log.info("Received request to get submissions for formId: {}", formId);
        
        Sort.Direction direction = sortDirection.equalsIgnoreCase("ASC") ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sortBy));
        
        Page<DynamicFormSubmissionResponse> response = submissionService.getSubmissionsByFormId(formId, pageable);
        return ResponseEntity.ok(response);
    }

    /**
     * Get submissions by status.
     */
    @Operation(
            summary = "Get submissions by status",
            description = "Retrieve submissions filtered by status."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Submissions retrieved successfully",
                    content = @Content(schema = @Schema(implementation = Page.class)))
    })
    @GetMapping("/form/{formId}/status/{status}")
    public ResponseEntity<Page<DynamicFormSubmissionResponse>> getSubmissionsByStatus(
            @Parameter(description = "Form ID", required = true)
            @PathVariable String formId,
            @Parameter(description = "Submission status", required = true)
            @PathVariable SubmissionStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        log.info("Received request to get submissions for formId: {} with status: {}", formId, status);
        
        Pageable pageable = PageRequest.of(page, size, Sort.by("submissionDate").descending());
        Page<DynamicFormSubmissionResponse> response = submissionService.getSubmissionsByStatus(formId, status, pageable);
        return ResponseEntity.ok(response);
    }

    /**
     * Search submissions by keyword.
     */
    @Operation(
            summary = "Search submissions",
            description = "Search submissions by keyword in title, description, or submitter name."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Search completed successfully",
                    content = @Content(schema = @Schema(implementation = Page.class)))
    })
    @GetMapping("/form/{formId}/search")
    public ResponseEntity<Page<DynamicFormSubmissionResponse>> searchSubmissions(
            @Parameter(description = "Form ID", required = true)
            @PathVariable String formId,
            @Parameter(description = "Search keyword", required = true)
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        log.info("Received request to search submissions for formId: {} with keyword: {}", formId, keyword);
        
        Pageable pageable = PageRequest.of(page, size, Sort.by("submissionDate").descending());
        Page<DynamicFormSubmissionResponse> response = submissionService.searchSubmissions(formId, keyword, pageable);
        return ResponseEntity.ok(response);
    }

    /**
     * Update submission status.
     */
    @Operation(
            summary = "Update submission status",
            description = "Update the status of a submission (e.g., from SUBMITTED to UNDER_REVIEW)."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Status updated successfully",
                    content = @Content(schema = @Schema(implementation = DynamicFormSubmissionResponse.class))),
            @ApiResponse(responseCode = "404", description = "Submission not found")
    })
    @PatchMapping("/{id}/status")
    public ResponseEntity<DynamicFormSubmissionResponse> updateStatus(
            @Parameter(description = "Submission ID", required = true)
            @PathVariable String id,
            @RequestParam SubmissionStatus status,
            @RequestParam(required = false) String reviewedBy,
            @RequestParam(required = false) String reviewComments) {
        log.info("Received request to update status for submission ID: {} to {}", id, status);
        DynamicFormSubmissionResponse response = submissionService.updateStatus(id, status, reviewedBy, reviewComments);
        return ResponseEntity.ok(response);
    }

    /**
     * Add upvote to submission.
     */
    @Operation(
            summary = "Add upvote",
            description = "Add an upvote to a submission."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Upvote added successfully",
                    content = @Content(schema = @Schema(implementation = DynamicFormSubmissionResponse.class))),
            @ApiResponse(responseCode = "404", description = "Submission not found")
    })
    @PostMapping("/{id}/upvote")
    public ResponseEntity<DynamicFormSubmissionResponse> addUpvote(
            @Parameter(description = "Submission ID", required = true)
            @PathVariable String id,
            @RequestParam String userId) {
        log.info("Received request to add upvote to submission ID: {} by user: {}", id, userId);
        DynamicFormSubmissionResponse response = submissionService.addUpvote(id, userId);
        return ResponseEntity.ok(response);
    }

    /**
     * Add comment to submission.
     */
    @Operation(
            summary = "Add comment",
            description = "Add a comment to a submission."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Comment added successfully",
                    content = @Content(schema = @Schema(implementation = DynamicFormSubmissionResponse.class))),
            @ApiResponse(responseCode = "404", description = "Submission not found")
    })
    @PostMapping("/{id}/comments")
    public ResponseEntity<DynamicFormSubmissionResponse> addComment(
            @Parameter(description = "Submission ID", required = true)
            @PathVariable String id,
            @RequestParam String commenterName,
            @RequestParam(required = false) String commenterEmail,
            @RequestParam String comment) {
        log.info("Received request to add comment to submission ID: {}", id);
        DynamicFormSubmissionResponse response = submissionService.addComment(id, commenterName, commenterEmail, comment);
        return ResponseEntity.ok(response);
    }

    /**
     * Delete submission.
     */
    @Operation(
            summary = "Delete submission",
            description = "Delete a form submission by ID."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Submission deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Submission not found")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSubmission(
            @Parameter(description = "Submission ID", required = true)
            @PathVariable String id) {
        log.info("Received request to delete submission ID: {}", id);
        submissionService.deleteSubmission(id);
        return ResponseEntity.noContent().build();
    }

    /**
     * Get submission statistics.
     */
    @Operation(
            summary = "Get submission statistics",
            description = "Get aggregated statistics for form submissions."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Statistics retrieved successfully")
    })
    @GetMapping("/form/{formId}/statistics")
    public ResponseEntity<Map<String, Object>> getStatistics(
            @Parameter(description = "Form ID", required = true)
            @PathVariable String formId) {
        log.info("Received request to get statistics for formId: {}", formId);
        Map<String, Object> stats = submissionService.getSubmissionStatistics(formId);
        return ResponseEntity.ok(stats);
    }
}

