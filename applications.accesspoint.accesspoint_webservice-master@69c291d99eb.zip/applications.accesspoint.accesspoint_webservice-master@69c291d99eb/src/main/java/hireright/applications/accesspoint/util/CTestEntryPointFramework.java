/*
 * @(#)$RCSfile: CTestEntryPointFramework.java,v $ $Revision: 1.2 $ $Date: 2014/07/28 14:57:11 $ $Author: aputintsev $ 
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/util/CTestEntryPointFramework.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *     $Log: CTestEntryPointFramework.java,v $
 *     Revision 1.2  2014/07/28 14:57:11  aputintsev
 *     forked from production version - projects_src/applications/accesspoint
 *
 *     Revision 1.1.2.1.2.1  2009/08/18 11:09:20  asolntsev
 *     Bugfixing and polishing
 *
 *     Revision 1.1.2.1  2009/08/13 13:24:24  asolntsev
 *     Created by St.Petersburg team
 *
 *     Revision 1.1  2009/08/06 09:37:55  banton
 *     Added simple Finite State Machine support. Tested only for memory storage
 *
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hireright.applications.accesspoint.util;

import hireright.objects.utilities.CEntryPoint;
import org.apache.commons.collections.MultiMap;
import org.apache.commons.collections.map.MultiValueMap;

/**
 *
 * @author banton
 */
public class CTestEntryPointFramework 
		implements IEntryPointFramework
{
	public void setUp()
	{
		// nothing to do
	}
	
	public void tearDown()
	{
		// nothing to do
	}
	
	public void commit()
	{
		// nothing to do
	}
	
	public void rollback()
	{
		// nothing to do
	}

		public CEntryPoint getEntryPoint(String key)
		{
				if (!"4D9BEF301F00292CA1705EB0D50FBEA2".equalsIgnoreCase(key))
						return null;

				return createTestEntryPoint();
		}

		public void saveEntryPoint(CEntryPoint entryPoint)
		{
				// do nothing
		}

		public CEntryPoint createEntryPointNoAuth(String userID, String userClass, String entryPointType,
				Integer designNumber, String domainID, MultiMap entryPointParams)
		{
				return createTestEntryPoint();
		}

		public CEntryPoint createEntryPointAuth(String userID, String userClass, String login, String entryPointType,
				Integer designNumber, String domainID, MultiMap entryPointParams)
		{
				return createTestEntryPoint();
		}

		public void deleteEntryPointByKey(String key)
		{
				// do nothiong
		}

		public void deleteEntryPoint(CEntryPoint entryPoint)
		{
				// do nothiong
		}


		protected static CEntryPoint createTestEntryPoint()
		{
			CEntryPoint entryPoint = new CEntryPoint("4D9BEF301F00292CA1705EB0D50FBEA2");

				entryPoint.setDesignNr(2);
				entryPoint.setDomainID("OPTOOL");
				entryPoint.setRedirectURL("");
				entryPoint.setUserClass("OPERATOR");
				entryPoint.setUserID("23454");
				entryPoint.setAuthenticationMode(CEntryPoint.AUTHENTICATION_MODE_NONE);
				entryPoint.setPassword("*******");

				String[][] parameters = s_TestParameters;
				MultiMap properties = new MultiValueMap();

				for (String[] parameter : parameters)
						properties.put(parameter[0], parameter[1]);

				entryPoint.setMultiProperties(properties);

				return entryPoint;
		}


		static String[][] s_TestParameters =
				{
						{"operatorLogin", "jdoe"},
						{"operatorName", "John Doe"},
						{"operatorFirstName", "John"},
						{"operatorLastNamel", "Doe"},
						{"operatorAlias", ""},
						{"operatorGroupName", "Transworks Mumbai"},
						{"operatorEmail", "jdoe@hireright.com"},
						{"operatorFax", ""},
						{"operatorPhone", "23145252525"},
						{"moduleID", "587,Y,Y,Y,Y"},
						{"moduleID", "588,Y,Y,Y,N"},
						{"moduleID", "818,Y,Y,Y,N"},
				};
}
