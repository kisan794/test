package com.hireright.sourceintelligence.domain.repository;

import com.hireright.sourceintelligence.domain.entity.MongoSearchResult;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.reports.domain.entity.ReportSearchResult;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CustomSourceRepository<T>  {

    //isHonExists
    Boolean isHonExists(String hon, Class<T> entityClass, String collectionName);

    T findOneByHon(String hon, Class<T> entityClass, String collectionName);
    //findAllByHonAndLocation same method will serve
    List<T> findByHon(String hon, Class<T> entityClass, String collectionName);

    public T findLatestByHon(String hon, Class<T> entityClass, String collectionName);

    List<T> findByHonAndStatus(String hon, String status, Class<T> entityClass, String collectionName);

    List<T> findByHonAndStatusAndApprovalStatus(String hon, String status, String approvalStatus, Class<T> entityClass, String collectionName);

    List<T> findByHonForUsedCount(String hon, Class<T> entityClass, String collectionName);

    List<T> findByHonIn(List<String> honIds, Class<T> entityClass, String collectionName);

    List<T> findByHonAndApprovalStatusOrderByVersionDesc(String hon,
                                                         ApprovalStatus approvalStatus, Class<T> entityClass, String collectionName);

    //History Methods
    List<T> findByHonAndApprovalStatusAndVersionLessThanOrderByVersionDesc(String hon, ApprovalStatus approvalStatus, Double version, Class<T> entityClass, String collectionName);
    List<T> findByHonAndVersionInOrderByVersionDesc(String hon, Double[] versions, Class<T> entityClass, String collectionName);

    T create(T entityObj, Class<T> entityClass, String collectionName);
    Boolean update(String queryField,String fieldValue, T entityObj, Class<T> entityClass, String collectionName);
    Boolean patch(String queryField, String fieldValue, Update update, String collectionName);

    T findOneByHonAndVersion(String hon, Double version, Class<T> entityClass, String collectionName);
    T UpdateDateOnIncrementByHon(String hon, String lastUsedDate, Class<T> entityClass, String collectionName);
    List<T> findByQuery(Query query, Class<T> entityClass, String collectionName);
    //Aggregate
    List<T> aggregate(Aggregation aggregation, String collectionName, Class<T> responseClass);
    long queryCount(Query query, String collectionName, Class<T> responseClass);

    T findOneByHonAndApprovalStatus(String hon, String approvalStatus, Class<T> entityClass, String collectionName);
    T findOneByHonAndApprovalStatuses(String hon, List<String> approvalStatus, Class<T> entityClass, String collectionName);
    List<T> findByHonAndApprovalStatuses(String hon, List<String> approvalStatus, Class<T> entityClass, String collectionName);
    T findSourceByHonOrderByLastModifiedBy(String hon, Class<T> entityClass, String collectionName);
    Boolean updateByQuery(Query query, T entityObj, Class<T> entityClass, String collectionName);
    Boolean updateFieldsByQuery(Query query, Update update, Class<T> entityClass, String collectionName);
    long deleteByQuery(Query query, Class<T> entityClass, String collectionName);
    long deleteById(ObjectId id, Class<T> entityClass, String collectionName);
    long delete(T entityObj, Class<T> entityClass, String collectionName);


    T findById(ObjectId id, Class<T> entityClass,String collectionName);
    List<T> getHistoryByHonAndVersion(String hon, Double version, Class<T> entityClass, String collectionName);
    List<T> findByHonOrderByLastModifiedDateDesc(String hon, Class<T> entityClass, String collectionName);

    List<String> findByFieldDistinct(Query query, String fieldName, String collectionName);

    MongoSearchResult customAggregate(Aggregation aggregation, String collectionName, Class<MongoSearchResult> mongoSearchResultClass);
    Document aggregateDocument(Aggregation aggregation, String collectionName);
    void assignApproverToSource(Query query, String appoverName, String approverEmail, String collectionName);

    ReportSearchResult reportCustomAggregate(Aggregation aggregation, String collectionName, Class<ReportSearchResult> reportSearchResultClass);

    List<T> findByHonAndVersionAndApprovalStatus(String hon, double version, Class<T> entityClass, String collectionName);
}
