/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-08-14	Created
 *	T.Prikk			2017-12-12	HIVPE-27993: moved DB.commit() from createEntity(), updateEntity(), deleteEntity() to doCreate(), doUpdate(), doDelete()
 *	T.Prikk			2017-12-12	HIVPE-27993: flush() + refresh() added to doAfterCreateUpdate()
 *	T.Prikk			2018-01-30	HIVPE-32013: Standard DB.session().refresh() causes issues with entities that have nonstandard identification logic (order_history)
 *	T.Prikk			2018-05-04	HIVPE-26547: add mergeProperties() for exchanging properties
 * 	M.Kuznetsov		2025-09-12	HRG-339332: CInstanceDomain support
 */
package hireright.applications.vendor_api.exchange.handler;

import java.io.Serializable;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;

import hireright.applications.vendor_api.EExchangeDirection;
import hireright.applications.vendor_api.EHostReference;
import hireright.applications.vendor_api.EVendorReference;
import hireright.applications.vendor_api.exchange.handler.objects.AEntityExchangeContext;
import hireright.applications.vendor_api.exchange.handler.objects.CEntityExchangeDTO;
import hireright.applications.vendor_api.exchange.handler.objects.CEntityExchangeException;
import hireright.applications.vendor_api.model.CExchangeResponse;
import hireright.objects.order3.model.CNameValue;
import hireright.sdk.db3.DB;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;
import hireright.sdk.util.IContainsProperties;

/**
 * Performs data operations (exchanges) based on input data.
 * 
 * @param <ContextType> Type of object that will wrap context data
 * @param <TransferType> Type of object that will contain transfer (input) data
 * @param <EntityType> Type of object that interfaces with DB
 */
public abstract class AEntityExchanger<ContextType extends AEntityExchangeContext<TransferType>, TransferType extends CEntityExchangeDTO, EntityType extends IContainsProperties>
{
	private Class<EntityType> m_entityClass;

	/** Retrieve identifier to be used to refer to a data entity externally */
	protected abstract String getEntityReference(EntityType entity);
	/**
	 * Transfer data from context to new data object (DB object) 
	 * 
	 * @throws CEntityExchangeException when data is missing or not suitable
	 * */
	protected abstract void doTransferForCreate(ContextType context, EntityType entity) throws CEntityExchangeException;
	/** 
	 * Transfer data from context to existing data object (DB object) in preparation for update
	 * 
	 * @throws CEntityExchangeException when data is missing or not suitable
	 * */
	protected abstract void doTransferForUpdate(ContextType context, EntityType entity) throws CEntityExchangeException; 

	/**
	 * Create a data object using specified context data.
	 * 
	 * @param context data required to perform create
	 * @return if successful, return object with references to created object
	 * @throws CEntityExchangeException in case create or any data transfers fail
	 */
	public CExchangeResponse doCreate(final ContextType context) throws CEntityExchangeException
	{
		return execute(new Callable<CExchangeResponse>()
		{
			public CExchangeResponse call() throws Exception
			{
				// create new entity instance
				EntityType entity = newEntity(context);
				
				// transfer data to new object
				transferData(true, context, entity);
				transferRemoteReferencesToNewEntity(context, entity);
				// create in DB
				createEntity(entity);
				
				// if applicable, transfer non-insertable fields
				doAfterCreateUpdate(context, entity);
				
				DB.commit();
				
				// return response with references to entity
				String reference = getEntityReference(entity);
				return new CExchangeResponse(reference);
			}
		});
	}

	/**
	 * Update data object using specified context data.
	 * 
	 * @param context data required to perform update
	 * @return if successful, return object with references to updated object
	 * @throws CEntityExchangeException in case read, update or any data transfers fail
	 */
	public CExchangeResponse doUpdate(final ContextType context) throws CEntityExchangeException
	{
		return execute(new Callable<CExchangeResponse>()
		{
			public CExchangeResponse call() throws Exception
			{
				// load entity from DB
				EntityType entity = readEntity(context.getEntityID());
				// transfer data to existing object
				transferData(false, context, entity);
				// update data in DB
				updateEntity(entity);
				
				DB.commit();
				
				// return response with references to entity
				String reference = getEntityReference(entity);
				return new CExchangeResponse(reference);
			}
		});
	}

	/**
	 * Delete data object using specified context data
	 * 
	 * @param context data required to perform delete
	 * @return if successful, return empty exchange response
	 * @throws CEntityExchangeException in case delete or read operation fails
	 */
	public CExchangeResponse doDelete(final ContextType context) throws CEntityExchangeException
	{
		return execute(new Callable<CExchangeResponse>()
		{
			public CExchangeResponse call() throws Exception
			{
				// load entity from DB
				EntityType entity = readEntity(context.getEntityID());
				// perform delete in DB
				deleteEntity(entity);
				
				DB.commit();
				
				// return empty response
				return new CExchangeResponse();
			}
		});
	}

	/**
	 * Wrap callable in {@link DB#execute(Callable)}
	 * 
	 * @throws CEntityExchangeException if any exception occurs in callable
	 */
	private CExchangeResponse execute(Callable<CExchangeResponse> callable) throws CEntityExchangeException
	{
		try
		{
			return DB.execute(callable);
		}
		catch (CEntityExchangeException e)
		{
			throw e;
		}
		catch (Throwable t)
		{
			throw new CEntityExchangeException("Unexpected error in DB-wrapped call", t);
		}
	}

	/**
	 * Make a new data object that will end up in DB
	 * 
	 * @throws CEntityExchangeException when reflective instantiation fails
	 */
	protected EntityType newEntity(ContextType context) throws CEntityExchangeException
	{
		try
		{
			return m_entityClass.newInstance();
		}
		catch (Throwable t)
		{
			throw new CEntityExchangeException("Could not instantiate object class", t);
		}
	}

	/**
	 * Perform update of fields that cannot be inserted but are part of the create operation
	 * 
	 * @throws CEntityExchangeException in case transfer or update fails
	 */
	private void doAfterCreateUpdate(ContextType context, EntityType entity) throws CEntityExchangeException
	{
		DB.session().flush();
		
		refreshEntity(entity);
		
		// some fields cannot be inserted (insertable=false in Hibernate config) but still need to be transferred when an object is created
		if (doTransferForPostCreate(context, entity))
		{
			updateEntity(entity);
		}
	}

	/**
	 * Transfer non-insertable fields to newly created data object<br/>
	 * Returning true will result in a data object update attempt.
	 * 
	 * @param entity recently created data object
	 * @return true if transfer was required, false otherwise
	 * @throws CEntityExchangeException
	 */
	protected boolean doTransferForPostCreate(ContextType context, EntityType entity) throws CEntityExchangeException
	{
		// post create transfer is not required by default
		return false;
	}

	/**
	 * Transfer data from context to data object
	 * 
	 * @param isNew if data object has not been created yet
	 * @throws CEntityExchangeException if transfer failed
	 */
	protected void transferData(boolean isNew, ContextType context, EntityType entity) throws CEntityExchangeException
	{
		mergeProperties(context, entity);
		
		if (isNew)
		{
			doTransferForCreate(context, entity);
		}
		else
		{
			doTransferForUpdate(context, entity);
		}
	}

	protected void transferRemoteReferencesToNewEntity(ContextType context, EntityType entity)
	{
		CProperties properties = ((IContainsProperties) entity).getProperties();
		TransferType dataTransferObj = context.getTransferObject();
		EExchangeDirection direction = dataTransferObj.getExchangeDirection();
		
		if (properties == null)
		{
			properties = new CProperties();
		}
		
		properties.setProperty(direction.equals(EExchangeDirection.HOST_TO_VENDOR)
				? EHostReference.HOST_OBJECT_REF.getPropertyName()
				: EVendorReference.VENDOR_OBJECT_REF.getPropertyName(), 
				dataTransferObj.getObjectRef());
		
		properties.setProperty(direction.equals(EExchangeDirection.HOST_TO_VENDOR)
				? EHostReference.HOST_INSTANCE_REF.getPropertyName()
				: EVendorReference.VENDOR_INSTANCE_REF.getPropertyName(), 
				dataTransferObj.getRemoteInstanceDomain().getDomainID());
		
		properties.setProperty(EHostReference.ORIGIN_INSTANCE_REF.getPropertyName(), dataTransferObj.getRemoteInstanceDomain().getDomainID());
		
		entity.setProperties(properties);
	}

	/**
	 * DB objects are required to have parameters.<br/>
	 * This method will transfer parameters from context to data object.<br/>
	 *
	 * @param context
	 * @param entity
	 */
	protected void mergeProperties(ContextType context, EntityType entity)
	{
		TransferType dataTransferObj = context.getTransferObject();
		List<CNameValue> propNameValues = dataTransferObj.getProperties();
		
		if (propNameValues != null)
		{
			CProperties localProps = entity.getProperties();
			CProperties remoteProps = new CProperties();
			
			if (localProps == null)
			{
				localProps = new CProperties();
			}
			
			Set<String> exchangeProps = new HashSet<String>();
			exchangeProps.addAll(Arrays.asList(
				EHostReference.HOST_OBJECT_REF.getPropertyName(),
				EVendorReference.VENDOR_OBJECT_REF.getPropertyName(),
				EHostReference.ORIGIN_INSTANCE_REF.getPropertyName()
			));
			
			for (CNameValue propNameValue : propNameValues)
			{
				String propName = propNameValue.getName();
				String propValue = propNameValue.getValue();
				
				if (CStringUtils.isEmpty(propValue))
				{
					propValue = " "; // "" or null will not clear the prop
				}
				
				// do not copy exchange props which may be sent in exchange
				if (!exchangeProps.contains(propName))
				{
					remoteProps.setProperty(propName, propValue);
				}
			}
			
			entity.setProperties(localProps.setProperties(remoteProps));
		}
	}

	/**
	 * Delete loaded data object from DB.</br>
	 * Override if standard Hibernate delete is not applicable.
	 * 
	 * @throws CEntityExchangeException if not successful
	 */
	protected void deleteEntity(final EntityType entity) throws CEntityExchangeException
	{
		DB.session().delete(entity);
	}

	/**
	 * Read data object from DB.<br/>
	 * Override if standard Hibernate load is not applicable.
	 * 
	 * @throws CEntityExchangeException if not successful
	 */
	@SuppressWarnings("unchecked")
	protected EntityType readEntity(final Serializable entityID) throws CEntityExchangeException
	{
		EntityType dataObject;
		try
		{
			dataObject = (EntityType) DB.session().load(m_entityClass, entityID);
		}
		catch (Throwable t)
		{
			throw new CEntityExchangeException("Could not read data object", t);
		}
		
		if (dataObject == null)
			throw new CEntityExchangeException("Data object of type [" + m_entityClass.getName() + "] with ID [" + entityID + "] not found");
		
		return dataObject;
	}

	/**
	 * Sync data object with remote DB instance.<br/>
	 * Override if standard Hibernate refresh is not applicable.
	 * 
	 * @throws CEntityExchangeException if not successful
	 */
	protected void refreshEntity(EntityType entity) throws CEntityExchangeException
	{
		DB.session().refresh(entity);
	}

	/**
	 * Create data object in DB.<br/>
	 * Override if standard Hibernate save is not applicable.
	 * 
	 * @throws CEntityExchangeException if not successful
	 */
	protected void createEntity(final EntityType entity) throws CEntityExchangeException
	{
		DB.session().save(entity);
	}

	/**
	 * Update data object in DB.<br/>
	 * Override if standard Hibernate update is not applicable.
	 * 
	 * @throws CEntityExchangeException if not successful
	 */
	protected void updateEntity(final EntityType entity) throws CEntityExchangeException
	{
		DB.session().update(entity);
	}

	/**
	 * @param entityClass class of entity data object, will be used to create new entity instances
	 */
	public AEntityExchanger(Class<EntityType> entityClass)
	{
		this.m_entityClass = entityClass;
	}
}
