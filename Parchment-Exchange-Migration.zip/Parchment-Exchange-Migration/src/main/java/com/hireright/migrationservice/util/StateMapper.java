package com.hireright.migrationservice.util;

import java.util.HashMap;
import java.util.Map;

/**
 * Utility class to map US state abbreviations to full state names
 */
public class StateMapper {
    
    private static final Map<String, String> ABBREVIATION_TO_FULL_NAME = new HashMap<>();
    private static final Map<String, String> FULL_NAME_TO_ABBREVIATION = new HashMap<>();
    
    static {
        // Initialize state mappings
        addState("AL", "Alabama");
        addState("AK", "Alaska");
        addState("AS", "American Samoa");
        addState("AZ", "Arizona");
        addState("AR", "Arkansas");
        addState("CA", "California");
        addState("CO", "Colorado");
        addState("CT", "Connecticut");
        addState("DE", "Delaware");
        addState("DC", "District of Columbia");
        addState("FL", "Florida");
        addState("GA", "Georgia");
        addState("GU", "Guam");
        addState("HI", "Hawaii");
        addState("ID", "Idaho");
        addState("IL", "Illinois");
        addState("IN", "Indiana");
        addState("IA", "Iowa");
        addState("KS", "Kansas");
        addState("KY", "Kentucky");
        addState("LA", "Louisiana");
        addState("ME", "Maine");
        addState("MD", "Maryland");
        addState("MA", "Massachusetts");
        addState("MI", "Michigan");
        addState("MN", "Minnesota");
        addState("MS", "Mississippi");
        addState("MO", "Missouri");
        addState("MT", "Montana");
        addState("NE", "Nebraska");
        addState("NV", "Nevada");
        addState("NH", "New Hampshire");
        addState("NJ", "New Jersey");
        addState("NM", "New Mexico");
        addState("NY", "New York");
        addState("NC", "North Carolina");
        addState("ND", "North Dakota");
        addState("MP", "Northern Mariana Islands");
        addState("OH", "Ohio");
        addState("OK", "Oklahoma");
        addState("OR", "Oregon");
        addState("PA", "Pennsylvania");
        addState("PR", "Puerto Rico");
        addState("RI", "Rhode Island");
        addState("SC", "South Carolina");
        addState("SD", "South Dakota");
        addState("TN", "Tennessee");
        addState("TX", "Texas");
        addState("TT", "Trust Territories");
        addState("UT", "Utah");
        addState("VT", "Vermont");
        addState("VA", "Virginia");
        addState("VI", "Virgin Islands");
        addState("WA", "Washington");
        addState("WV", "West Virginia");
        addState("WI", "Wisconsin");
        addState("WY", "Wyoming");
    }
    
    private static void addState(String abbreviation, String fullName) {
        ABBREVIATION_TO_FULL_NAME.put(abbreviation, fullName);
        FULL_NAME_TO_ABBREVIATION.put(fullName, abbreviation);
    }
    
    /**
     * Convert state abbreviation to full name
     * @param abbreviation State abbreviation (e.g., "CA")
     * @return Full state name (e.g., "California") or empty string if not found
     */
    public static String getFullName(String abbreviation) {
        if (abbreviation == null || abbreviation.trim().isEmpty()) {
            return "";
        }
        return ABBREVIATION_TO_FULL_NAME.getOrDefault(abbreviation.trim().toUpperCase(), "");
    }
    
    /**
     * Convert full state name to abbreviation
     * @param fullName Full state name (e.g., "California")
     * @return State abbreviation (e.g., "CA") or empty string if not found
     */
    public static String getAbbreviation(String fullName) {
        if (fullName == null || fullName.trim().isEmpty()) {
            return "";
        }
        return FULL_NAME_TO_ABBREVIATION.getOrDefault(fullName.trim(), "");
    }
    
    /**
     * Check if the given string is a state abbreviation
     * @param value String to check
     * @return true if it's a valid state abbreviation
     */
    public static boolean isAbbreviation(String value) {
        if (value == null || value.trim().isEmpty()) {
            return false;
        }
        return ABBREVIATION_TO_FULL_NAME.containsKey(value.trim().toUpperCase());
    }
}

