package com.hireright.sourceintelligence.api.dto.history;

import lombok.Data;

import java.util.List;

@Data
public class ChangeLogResponse {
    private List<ChangelogResponseDTO> activeSources;

}
