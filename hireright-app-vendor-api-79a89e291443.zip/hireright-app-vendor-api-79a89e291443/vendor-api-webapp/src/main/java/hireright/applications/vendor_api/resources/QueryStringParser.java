/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	msuhhoruki	2017-12-05	Created
 */
package hireright.applications.vendor_api.resources;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

class QueryStringParser
{
	private static final String CHARSET = "UTF-8";
	
	public static Map<String, String> parse(String qs)
		throws UnsupportedEncodingException
	{
		if (qs == null)
		{
			return null;
		}
		
		Map<String, String> map = new HashMap<String, String>();
		String[] nameValues = qs.split("&");
		for (String nameValue : nameValues)
		{
			int n = nameValue.indexOf("=");
			String sName = null;
			String sValue = null;
			if (n > 0)
			{
				sName = URLDecoder.decode(nameValue.substring(0, n), CHARSET);
				sValue = URLDecoder.decode(nameValue.substring(n + 1), CHARSET);
			}
			else
			{
				sName = URLDecoder.decode(nameValue, CHARSET);
			}
			
			map.put(sName, sValue);
		}
		
		return map;
	}
}
