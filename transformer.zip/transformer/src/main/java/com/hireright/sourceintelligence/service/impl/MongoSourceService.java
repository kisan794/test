package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.DeleteRequestDTO;
import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.domain.entity.RegionThreshold;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.domain.repository.RegionThresholdRepository;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import com.hireright.sourceintelligence.service.impl.helperservices.ReportDataUtils;
import com.hireright.sourceintelligence.util.Helper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import org.springframework.dao.DataAccessException;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import jakarta.validation.constraints.NotNull;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.constants.ErrorConstants.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.Regex.EMPTY_STRING;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.Threshold.*;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowInternalServiceException;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowServiceException;

@Slf4j
@RequiredArgsConstructor
@Transactional
@Component
public class MongoSourceService {

    private final CustomSourceRepository<Source> customSourceRepository;
    private final RegionThresholdRepository regionThresholdRepository;
    private final SourceMapper sourceMapper;
    private final ElasticsearchService elasticsearchService;
    private final ReportDataUtils reportDataUtils;

    public Source insert(@NotNull Source entityToPersist, String collectionName) {
        entityToPersist.setId(null);
        return customSourceRepository.create(entityToPersist, Source.class, collectionName);
    }

    public Boolean update(String queryField, String queryValue, @NotNull Source entityToPersist, String collectionName) {
        entityToPersist.setId(null);
        return customSourceRepository.update(queryField, queryValue, entityToPersist, Source.class, collectionName);
    }

    public void updateById(@NotNull Source entityToPersist, String collectionName) {
        Query query = new Query(Criteria.where(ID).is(entityToPersist.getId()));
        customSourceRepository.updateByQuery(query, entityToPersist, Source.class, collectionName);
    }

    public void patch(String queryField, String queryValue, Update update, String collectionName) {
        customSourceRepository.patch(queryField, queryValue, update, collectionName);
    }

    public Source findSourceByHon(@NotNull String hon) {
        try {
            return customSourceRepository.findOneByHon(hon, Source.class, Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX));
        } catch (Exception ex) {
            logAndThrowInternalServiceException(NO_SEARCH_RESULT_FOUND, ex);
        }
        return null;
    }

    protected Source findSourceHistoryByHon(@NotNull String hon) {
        try {
            return customSourceRepository.findLatestByHon(hon, Source.class, Helper.getCollectionName(hon, SOURCE_HISTORY_COLLECTION_SUFFIX));
        } catch (Exception ex) {
            logAndThrowInternalServiceException(NO_SEARCH_RESULT_FOUND, ex);
        }
        return null;
    }

    public SourceOrganizationDTO getPossibleDuplicateSources(SourceOrganizationDTO sourceOrganizationDTO) {

        Query query = new Query();
        List<Criteria> criteria = QueryBuilder.queryCriteriaForNonArrayFields(sourceOrganizationDTO);
        QueryBuilder.queryCriteriaForArrayFields(sourceOrganizationDTO, criteria);
        query.addCriteria(Criteria.where(EMPTY_STRING).andOperator(criteria));
        List<Source> result = new ArrayList<>();
        try {
            String collectionName = Helper.getCollectionName(sourceOrganizationDTO.getOrganizationType().getType(), SOURCE_COLLECTION_SUFFIX);
            result = customSourceRepository.findByQuery(query, Source.class, collectionName);

        } catch (DataAccessException dataAccessException) {
            logAndThrowServiceException(DATA_ACCESS_ERROR, dataAccessException);
        }
        if (result.isEmpty()) {
            return null;
        }
        return sourceMapper.entitySourceToDTO(result.getFirst());
    }
    public int getThresholdForRegion(String region) {
        RegionThreshold regionThreshold = regionThresholdRepository.findByThresholdType(THRESHOLD_VALUE);
        try {
            Field field = RegionThreshold.class.getDeclaredField(region.toUpperCase());
            field.setAccessible(true);
            Object regionValue = field.get(regionThreshold);
            if (regionValue instanceof Integer) {
                return (Integer) regionValue;
            }
        } catch (Exception e) {
            logAndThrowInternalServiceException(REGION_THRESHOLD_NOT_FOUND, e, region);
        }
        return 0;
    }

    public boolean isHonExists(String hon) {
        return customSourceRepository.isHonExists(hon, Source.class, Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX));
    }

    public long hardDeleteSource(String hon, DeleteRequestDTO deleteRequestDTO) throws IOException {
        String collectionName = Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX);
        List<Source> source = customSourceRepository.findByHon(hon,Source.class,collectionName);
        if (!source.isEmpty()) {
            for (Source sourceEntity : source) {
                sourceEntity.setAssignedTo(deleteRequestDTO.getUiAction().getUserName());
                sourceEntity.setAssignedId(deleteRequestDTO.getUiAction().getUserEmail());
                reportDataUtils.reportData(sourceEntity,DELETE.toUpperCase(),SIDB_ORIGIN,0, deleteRequestDTO.getReason());
            }
            String historyCollectionName = Helper.getCollectionName(hon, SOURCE_HISTORY_COLLECTION_SUFFIX);
            List<Source> historySources = customSourceRepository.findByHon(hon,Source.class,historyCollectionName);
            if(!historySources.isEmpty()){
                Query query = new Query().addCriteria(Criteria.where(HON).is(hon));
                customSourceRepository.deleteByQuery(query, Source.class, historyCollectionName);
            }
            elasticsearchService.deleteSourceByHon(hon);
            Query query = new Query().addCriteria(Criteria.where(HON).is(hon));
            return customSourceRepository.deleteByQuery(query, Source.class, collectionName);
        }
        return 0;
    }

    public long delete(@NotNull Source entityToPersist, String collectionName) {
        return customSourceRepository.delete(entityToPersist, Source.class, collectionName);
    }

    public void deleteSourceById(@NotNull ObjectId id, String collectionName) {
        customSourceRepository.deleteById(id, Source.class, collectionName);
    }

    public Source findSourceByHonAndApprovalStatus(@NotNull String hon, ApprovalStatus approvalStatus) {
        try {
            return customSourceRepository.findOneByHonAndApprovalStatus(hon,approvalStatus.getStatus(), Source.class, Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX));
        } catch (Exception ex) {
            return null;
        }
    }
    public Source findSourceByHonAndApprovalStatuses(@NotNull String hon, List<String> approvalStatuses) {
        try {
            return customSourceRepository.findOneByHonAndApprovalStatuses(hon,approvalStatuses, Source.class, Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX));
        } catch (Exception ex) {
            return null;
        }
    }
    public List<Source> getSourceListByHonAndApprovalStatuses(@NotNull String hon, List<String> approvalStatuses) {
        try {
            return customSourceRepository.findByHonAndApprovalStatuses(hon,approvalStatuses, Source.class, Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX));
        } catch (Exception ex) {
            return Collections.emptyList();
        }
    }

    public Source findSourceByHonOrderByLastModifiedBy(@NotNull String hon) {
        try {
            return customSourceRepository.findSourceByHonOrderByLastModifiedBy(hon, Source.class, Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX));
        } catch (Exception ex) {
            logAndThrowInternalServiceException(NO_SEARCH_RESULT_FOUND, ex);
        }
        return null;
    }

    public Boolean updateByIdWithCustomFields(Query query, Update update, String collectionName) {
        return customSourceRepository.updateFieldsByQuery(query, update, Source.class, collectionName);
    }

    public void insertSourceHistory(Source entityFromDb) {
        SourceOrganizationDTO sourceDTO = sourceMapper.entitySourceToDTO(entityFromDb);
        Source sourceHistory = sourceMapper.dtoToEntitySource(sourceDTO);
        Source insertSource = insert(sourceHistory, Helper.getCollectionName(entityFromDb.getOrganizationType().getType(), SOURCE_HISTORY_COLLECTION_SUFFIX));
        log.info("insert history: {}", insertSource.getOrganizationName());
    }

}
