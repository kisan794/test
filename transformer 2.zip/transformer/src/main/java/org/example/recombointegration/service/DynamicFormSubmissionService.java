package org.example.recombointegration.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.recombointegration.document.DynamicFormSubmission;
import org.example.recombointegration.document.DynamicFormSubmission.SubmissionComment;
import org.example.recombointegration.document.DynamicFormSubmission.SubmissionStatus;
import org.example.recombointegration.document.FormTemplate;
import org.example.recombointegration.document.FormTemplate.FormField;
import org.example.recombointegration.dto.DynamicFormSubmissionRequest;
import org.example.recombointegration.dto.DynamicFormSubmissionResponse;
import org.example.recombointegration.repository.DynamicFormSubmissionRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Service for managing dynamic form submissions.
 * Handles validation, submission, and retrieval of form data.
 *
 * @author Generated
 * @version 1.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DynamicFormSubmissionService {

    private final DynamicFormSubmissionRepository submissionRepository;
    private final DynamicFormService dynamicFormService;

    /**
     * Submit a new form.
     */
    public DynamicFormSubmissionResponse submitForm(DynamicFormSubmissionRequest request) {
        log.info("Processing form submission for formId: {}", request.getFormId());

        // Get form configuration
        FormTemplate formTemplate = dynamicFormService.getFormConfiguration(request.getFormId());

        // Validate form data against configuration
        validateFormData(request.getFormData(), formTemplate, request.getIsDraft());

        LocalDateTime now = LocalDateTime.now();

        DynamicFormSubmission submission = DynamicFormSubmission.builder()
                .formId(request.getFormId())
                .formVersion(formTemplate.getVersion())
                .emailAddress(request.getEmailAddress())
                .formData(request.getFormData())
                .status(request.getIsDraft() ? SubmissionStatus.DRAFT : SubmissionStatus.SUBMITTED)
                .submissionDate(now)
                .createdAt(now)
                .updatedAt(now)
                .upvoteCount(0)
                .upvotedBy(new ArrayList<>())
                .comments(new ArrayList<>())
                .metadata(request.getMetadata())
                .build();

        DynamicFormSubmission savedSubmission = submissionRepository.save(submission);
        log.info("Form submission saved successfully with ID: {}", savedSubmission.getId());

        return mapToResponse(savedSubmission);
    }

    /**
     * Update an existing form submission.
     */
    public DynamicFormSubmissionResponse updateSubmission(String id, DynamicFormSubmissionRequest request) {
        log.info("Updating form submission with ID: {}", id);

        DynamicFormSubmission submission = submissionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Submission not found with ID: " + id));

        // Get form configuration
        FormTemplate formTemplate = dynamicFormService.getFormConfiguration(request.getFormId());

        // Validate form data
        validateFormData(request.getFormData(), formTemplate, request.getIsDraft());

        submission.setFormData(request.getFormData());
        submission.setEmailAddress(request.getEmailAddress());
        submission.setStatus(request.getIsDraft() ? SubmissionStatus.DRAFT : SubmissionStatus.SUBMITTED);
        submission.setUpdatedAt(LocalDateTime.now());
        
        if (request.getMetadata() != null) {
            submission.setMetadata(request.getMetadata());
        }

        DynamicFormSubmission updatedSubmission = submissionRepository.save(submission);
        log.info("Form submission updated successfully");

        return mapToResponse(updatedSubmission);
    }

    /**
     * Get submission by ID.
     */
    public DynamicFormSubmissionResponse getSubmissionById(String id) {
        log.info("Fetching submission with ID: {}", id);
        DynamicFormSubmission submission = submissionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Submission not found with ID: " + id));
        return mapToResponse(submission);
    }

    /**
     * Get all submissions for a form with pagination.
     */
    public Page<DynamicFormSubmissionResponse> getSubmissionsByFormId(String formId, Pageable pageable) {
        log.info("Fetching submissions for formId: {}", formId);
        return submissionRepository.findByFormId(formId, pageable)
                .map(this::mapToResponse);
    }

    /**
     * Get submissions by status.
     */
    public Page<DynamicFormSubmissionResponse> getSubmissionsByStatus(
            String formId, 
            SubmissionStatus status, 
            Pageable pageable) {
        log.info("Fetching submissions for formId: {} with status: {}", formId, status);
        return submissionRepository.findByFormIdAndStatus(formId, status, pageable)
                .map(this::mapToResponse);
    }

    /**
     * Search submissions by keyword.
     */
    public Page<DynamicFormSubmissionResponse> searchSubmissions(
            String formId, 
            String keyword, 
            Pageable pageable) {
        log.info("Searching submissions for formId: {} with keyword: {}", formId, keyword);
        return submissionRepository.searchByFormIdAndKeyword(formId, keyword, pageable)
                .map(this::mapToResponse);
    }

    /**
     * Update submission status.
     */
    public DynamicFormSubmissionResponse updateStatus(
            String id, 
            SubmissionStatus status, 
            String reviewedBy, 
            String reviewComments) {
        log.info("Updating status for submission ID: {} to {}", id, status);

        DynamicFormSubmission submission = submissionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Submission not found with ID: " + id));

        submission.setStatus(status);
        submission.setReviewedBy(reviewedBy);
        submission.setReviewedAt(LocalDateTime.now());
        submission.setReviewComments(reviewComments);
        submission.setUpdatedAt(LocalDateTime.now());

        DynamicFormSubmission updatedSubmission = submissionRepository.save(submission);
        log.info("Status updated successfully");

        return mapToResponse(updatedSubmission);
    }

    /**
     * Add upvote to submission.
     */
    public DynamicFormSubmissionResponse addUpvote(String id, String userId) {
        log.info("Adding upvote to submission ID: {} by user: {}", id, userId);

        DynamicFormSubmission submission = submissionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Submission not found with ID: " + id));

        if (submission.getUpvotedBy() == null) {
            submission.setUpvotedBy(new ArrayList<>());
        }

        if (!submission.getUpvotedBy().contains(userId)) {
            submission.getUpvotedBy().add(userId);
            submission.setUpvoteCount(submission.getUpvotedBy().size());
            submission.setUpdatedAt(LocalDateTime.now());

            DynamicFormSubmission updatedSubmission = submissionRepository.save(submission);
            log.info("Upvote added successfully");
            return mapToResponse(updatedSubmission);
        } else {
            log.warn("User {} has already upvoted submission {}", userId, id);
            return mapToResponse(submission);
        }
    }

    /**
     * Add comment to submission.
     */
    public DynamicFormSubmissionResponse addComment(
            String id, 
            String commenterName, 
            String commenterEmail, 
            String comment) {
        log.info("Adding comment to submission ID: {}", id);

        DynamicFormSubmission submission = submissionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Submission not found with ID: " + id));

        SubmissionComment newComment = SubmissionComment.builder()
                .id(UUID.randomUUID().toString())
                .commenterName(commenterName)
                .commenterEmail(commenterEmail)
                .comment(comment)
                .createdAt(LocalDateTime.now())
                .build();

        if (submission.getComments() == null) {
            submission.setComments(new ArrayList<>());
        }

        submission.getComments().add(newComment);
        submission.setUpdatedAt(LocalDateTime.now());

        DynamicFormSubmission updatedSubmission = submissionRepository.save(submission);
        log.info("Comment added successfully");

        return mapToResponse(updatedSubmission);
    }

    /**
     * Delete submission.
     */
    public void deleteSubmission(String id) {
        log.info("Deleting submission with ID: {}", id);
        if (!submissionRepository.existsById(id)) {
            throw new RuntimeException("Submission not found with ID: " + id);
        }
        submissionRepository.deleteById(id);
        log.info("Submission deleted successfully");
    }

    /**
     * Get submission statistics.
     */
    public Map<String, Object> getSubmissionStatistics(String formId) {
        log.info("Fetching statistics for formId: {}", formId);

        Map<String, Object> stats = new HashMap<>();
        stats.put("totalSubmissions", submissionRepository.countByFormId(formId));
        stats.put("submittedCount", submissionRepository.countByFormIdAndStatus(formId, SubmissionStatus.SUBMITTED));
        stats.put("underReviewCount", submissionRepository.countByFormIdAndStatus(formId, SubmissionStatus.UNDER_REVIEW));
        stats.put("approvedCount", submissionRepository.countByFormIdAndStatus(formId, SubmissionStatus.APPROVED));
        stats.put("implementedCount", submissionRepository.countByFormIdAndStatus(formId, SubmissionStatus.IMPLEMENTED));
        stats.put("completedCount", submissionRepository.countByFormIdAndStatus(formId, SubmissionStatus.COMPLETED));
        stats.put("rejectedCount", submissionRepository.countByFormIdAndStatus(formId, SubmissionStatus.REJECTED));
        stats.put("draftCount", submissionRepository.countByFormIdAndStatus(formId, SubmissionStatus.DRAFT));

        return stats;
    }

    /**
     * Validate form data against form configuration.
     */
    private void validateFormData(Map<String, Object> formData, FormTemplate formTemplate, Boolean isDraft) {
        log.debug("Validating form data against configuration");

        List<String> errors = new ArrayList<>();

        // Skip validation for drafts
        if (isDraft != null && isDraft) {
            log.debug("Skipping validation for draft submission");
            return;
        }

        // Get all fields from all sections
        List<FormField> allFields = formTemplate.getSections().stream()
                .flatMap(section -> section.getFields().stream())
                .collect(Collectors.toList());

        // Validate required fields
        for (FormField field : allFields) {
            if (Boolean.TRUE.equals(field.getRequired())) {
                Object value = formData.get(field.getFieldKey());
                if (value == null || (value instanceof String && ((String) value).trim().isEmpty())) {
                    errors.add(String.format("Field '%s' is required", field.getLabel()));
                }
            }

            // Validate field length
            if (formData.containsKey(field.getFieldKey())) {
                Object value = formData.get(field.getFieldKey());
                if (value instanceof String) {
                    String strValue = (String) value;
                    if (field.getMaxLength() != null && strValue.length() > field.getMaxLength()) {
                        errors.add(String.format("Field '%s' exceeds maximum length of %d", 
                                field.getLabel(), field.getMaxLength()));
                    }
                    if (field.getMinLength() != null && strValue.length() < field.getMinLength()) {
                        errors.add(String.format("Field '%s' is below minimum length of %d", 
                                field.getLabel(), field.getMinLength()));
                    }
                }
            }
        }

        if (!errors.isEmpty()) {
            String errorMessage = "Form validation failed: " + String.join(", ", errors);
            log.error(errorMessage);
            throw new RuntimeException(errorMessage);
        }

        log.debug("Form data validation successful");
    }

    /**
     * Map entity to response DTO.
     */
    private DynamicFormSubmissionResponse mapToResponse(DynamicFormSubmission submission) {
        return DynamicFormSubmissionResponse.builder()
                .id(submission.getId())
                .formId(submission.getFormId())
                .formVersion(submission.getFormVersion())
                .emailAddress(submission.getEmailAddress())
                .formData(submission.getFormData())
                .status(submission.getStatus())
                .assignedTo(submission.getAssignedTo())
                .reviewedBy(submission.getReviewedBy())
                .reviewedAt(submission.getReviewedAt())
                .reviewComments(submission.getReviewComments())
                .upvoteCount(submission.getUpvoteCount())
                .upvotedBy(submission.getUpvotedBy())
                .comments(submission.getComments())
                .submissionDate(submission.getSubmissionDate())
                .createdAt(submission.getCreatedAt())
                .updatedAt(submission.getUpdatedAt())
                .metadata(submission.getMetadata())
                .build();
    }
}

