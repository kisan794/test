package hireright.applications.fulfillment_task_api.rest.recombointegration.service;


import hireright.applications.fulfillment_task_api.rest.recombointegration.util.Constant;
import lombok.Getter;

/**
 * Enum representing different types of screening transformations.
 *
 * @author Keshav Ladha
 */
@Getter
public enum ScreeningType {

    /**
     * Education screening type.
     * Handles education verification XML transformations.
     */
    EDUCATION(Constant.SCREENING_TYPE_EDUCATION),

    /**
     * Employment screening type.
     * Handles employment verification XML transformations.
     */
    EMPLOYMENT(Constant.SCREENING_TYPE_EMPLOYMENT);

    private final String value;

    /**
     * Constructor.
     *
     * @param value the string value of the screening type
     */
    ScreeningType(String value) {
        this.value = value;
    }

    /**
     * Converts a string to a ScreeningType enum.
     * Case-insensitive and trims whitespace.
     *
     * @param value the string value
     * @return the corresponding ScreeningType
     * @throws IllegalArgumentException if the value doesn't match any type
     */
    public static ScreeningType fromValue(String value) {
        if (value == null || value.trim().isEmpty()) {
            return EDUCATION; // Default type
        }

        String normalizedValue = value.trim().toLowerCase();

        for (ScreeningType type : ScreeningType.values()) {
            if (type.value.equals(normalizedValue)) {
                return type;
            }
        }

        throw new IllegalArgumentException(
                "Unknown screening type: '" + value + "'. Supported types are: " + getSupportedTypes()
        );
    }

    /**
     * Gets a comma-separated list of all supported types.
     *
     * @return supported types as a string
     */
    public static String getSupportedTypes() {
        StringBuilder sb = new StringBuilder();
        for (ScreeningType type : ScreeningType.values()) {
            if (!sb.isEmpty()) {
                sb.append(", ");
            }
            sb.append(type.value);
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        return value;
    }
}