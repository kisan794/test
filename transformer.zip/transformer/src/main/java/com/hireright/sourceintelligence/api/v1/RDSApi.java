package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.rds.CountryRegionResponseDTO;
import com.hireright.sourceintelligence.api.dto.rds.CountryResponseDTO;
import com.hireright.sourceintelligence.api.dto.rds.LanguageResponseDTO;
import com.hireright.sourceintelligence.api.dto.rds.VendorResponseDTO;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import static com.hireright.sourceintelligence.api.ApiConstants.*;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.*;

@RequestMapping(value = BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH)
@Tag(name = "SourceOrganization", description = "Endpoints for rds services")
public interface RDSApi {

    @ResponseStatus(HttpStatus.OK)
    @GetMapping(value = VENDORS,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<VendorResponseDTO> getVendorsList();

    @ResponseStatus(HttpStatus.OK)
    @GetMapping(value = COUNTRY,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<CountryResponseDTO> getCountries(
            @RequestParam(value = START_INDEX, defaultValue = "1") @Min(1) @Max(MAX_INDEX_VALUE) int startIndex,
            @RequestParam(value = BATCH_SIZE, defaultValue = "300") @Min(1) @Max(999) int batchSize);

    @ResponseStatus(HttpStatus.OK)
    @GetMapping(value = COUNTRY_REGION,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<CountryRegionResponseDTO> getCountryRegions(
            @RequestParam(value = COUNTRY_ID) int countryId,
            @RequestParam(value = START_INDEX, defaultValue = "1") @Min(1) @Max(MAX_INDEX_VALUE) int startIndex,
            @RequestParam(value = BATCH_SIZE, defaultValue = "200") @Min(1) @Max(999) int batchSize);

    @ResponseStatus(HttpStatus.OK)
    @GetMapping(value = LANGUAGE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<LanguageResponseDTO> getLanguages(
            @RequestParam(value = START_INDEX, defaultValue = "1") @Min(1) @Max(MAX_INDEX_VALUE) int startIndex,
            @RequestParam(value = BATCH_SIZE, defaultValue = "500") @Min(1) @Max(999) int batchSize);

}
