package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.InstitutionRecord;
import com.hireright.sourceintelligence.api.dto.MigrationResponseDTO;
import com.hireright.sourceintelligence.service.impl.ExcelParserService;
import com.hireright.sourceintelligence.service.impl.MigrationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DataMigrationApiControllerTest {

    @Mock
    private ExcelParserService excelParserService;

    @Mock
    private MigrationService migrationService;

    @InjectMocks
    private DataMigrationApiController controller;

    private MockMultipartFile validFile;
    private List<InstitutionRecord> sampleRecords;
    private Map<String, Object> sampleProcessingResult;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(controller, "maxFileSizeMb", 10);

        validFile = new MockMultipartFile(
                "file",
                "test-migration.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "test content".getBytes()
        );

        sampleRecords = Arrays.asList(
                InstitutionRecord.builder()
                        .institutionName("Harvard University")
                        .country("USA")
                        .city("Cambridge")
                        .stateCountyRegion("MA")
                        .serviceProvider("Parchment Exchange")
                        .surchargeAmount("5.00")
                        .paymentMethod("Credit Card")
                        .code("HARV001")
                        .turnaroundTime("3")
                        .followUpAllowed("Yes")
                        .build(),
                InstitutionRecord.builder()
                        .institutionName("MIT")
                        .country("USA")
                        .city("Cambridge")
                        .stateCountyRegion("MA")
                        .serviceProvider("Parchment Exchange")
                        .surchargeAmount("5.00")
                        .paymentMethod("Credit Card")
                        .code("MIT001")
                        .turnaroundTime("3")
                        .followUpAllowed("Yes")
                        .build()
        );

        sampleProcessingResult = new HashMap<>();
        sampleProcessingResult.put("totalRecords", 2);
        sampleProcessingResult.put("updatedRecords", 2);
        sampleProcessingResult.put("notFoundRecords", 0);
        sampleProcessingResult.put("notFoundInstitutions", new ArrayList<>());
    }

    @Test
    void testUploadExcelFile_Success() throws IOException {
        when(migrationService.isMigrationTypeSupported("parchment")).thenReturn(true);
        when(excelParserService.parseExcelFile(any(MultipartFile.class))).thenReturn(sampleRecords);
        when(migrationService.processInstitutionRecords(anyList(), eq("parchment")))
                .thenReturn(sampleProcessingResult);

        ResponseEntity<MigrationResponseDTO> response = controller.uploadExcelFile(validFile, "parchment");

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("success", response.getBody().getStatus());
        assertEquals("File processed successfully", response.getBody().getMessage());
        assertEquals("parchment", response.getBody().getMigrationType());
        assertEquals("test-migration.xlsx", response.getBody().getFilename());
        assertEquals(2, response.getBody().getTotalRecords());
        assertEquals(2, response.getBody().getUpdatedRecords());
        assertEquals(0, response.getBody().getNotFoundRecords());
        assertNotNull(response.getBody().getProcessingTimeMs());

        verify(migrationService).isMigrationTypeSupported("parchment");
        verify(excelParserService).parseExcelFile(validFile);
        verify(migrationService).processInstitutionRecords(sampleRecords, "parchment");
    }

    @Test
    void testUploadExcelFile_UnsupportedMigrationType() {
        when(migrationService.isMigrationTypeSupported("unknown")).thenReturn(false);
        when(migrationService.getSupportedMigrationTypes()).thenReturn("parchment");

        assertThrows(Exception.class, () -> {
            controller.uploadExcelFile(validFile, "unknown");
        });

        verify(migrationService).isMigrationTypeSupported("unknown");
        verify(migrationService).getSupportedMigrationTypes();
        verifyNoInteractions(excelParserService);
    }

    @Test
    void testUploadExcelFile_EmptyFile() {
        MockMultipartFile emptyFile = new MockMultipartFile(
                "file",
                "empty.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                new byte[0]
        );
        when(migrationService.isMigrationTypeSupported("parchment")).thenReturn(true);

        assertThrows(Exception.class, () -> {
            controller.uploadExcelFile(emptyFile, "parchment");
        });

        verify(migrationService).isMigrationTypeSupported("parchment");
        verifyNoInteractions(excelParserService);
    }

    @Test
    void testUploadExcelFile_FileTooLarge() {
        byte[] largeContent = new byte[11 * 1024 * 1024]; // 11MB
        MockMultipartFile largeFile = new MockMultipartFile(
                "file",
                "large.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                largeContent
        );
        when(migrationService.isMigrationTypeSupported("parchment")).thenReturn(true);

        assertThrows(Exception.class, () -> {
            controller.uploadExcelFile(largeFile, "parchment");
        });

        verify(migrationService).isMigrationTypeSupported("parchment");
        verifyNoInteractions(excelParserService);
    }

    @Test
    void testUploadExcelFile_InvalidFileFormat() {
        MockMultipartFile invalidFile = new MockMultipartFile(
                "file",
                "test.txt",
                "text/plain",
                "test content".getBytes()
        );
        when(migrationService.isMigrationTypeSupported("parchment")).thenReturn(true);

        assertThrows(Exception.class, () -> {
            controller.uploadExcelFile(invalidFile, "parchment");
        });

        verify(migrationService).isMigrationTypeSupported("parchment");
        verifyNoInteractions(excelParserService);
    }

    @Test
    void testUploadExcelFile_NoRecordsFound() throws IOException {
        when(migrationService.isMigrationTypeSupported("parchment")).thenReturn(true);
        when(excelParserService.parseExcelFile(any(MultipartFile.class))).thenReturn(Collections.emptyList());

        assertThrows(Exception.class, () -> {
            controller.uploadExcelFile(validFile, "parchment");
        });

        verify(migrationService).isMigrationTypeSupported("parchment");
        verify(excelParserService).parseExcelFile(validFile);
        verify(migrationService, never()).processInstitutionRecords(anyList(), anyString());
    }

    @Test
    void testUploadExcelFile_ParseError() throws IOException {
        when(migrationService.isMigrationTypeSupported("parchment")).thenReturn(true);
        when(excelParserService.parseExcelFile(any(MultipartFile.class)))
                .thenThrow(new IOException("Failed to parse Excel file"));

        assertThrows(Exception.class, () -> {
            controller.uploadExcelFile(validFile, "parchment");
        });

        verify(migrationService).isMigrationTypeSupported("parchment");
        verify(excelParserService).parseExcelFile(validFile);
        verify(migrationService, never()).processInstitutionRecords(anyList(), anyString());
    }

    @Test
    void testUploadExcelFile_ProcessingError() throws IOException {
        when(migrationService.isMigrationTypeSupported("parchment")).thenReturn(true);
        when(excelParserService.parseExcelFile(any(MultipartFile.class))).thenReturn(sampleRecords);
        when(migrationService.processInstitutionRecords(anyList(), eq("parchment")))
                .thenThrow(new RuntimeException("Database connection failed"));

        assertThrows(Exception.class, () -> {
            controller.uploadExcelFile(validFile, "parchment");
        });

        verify(migrationService).isMigrationTypeSupported("parchment");
        verify(excelParserService).parseExcelFile(validFile);
        verify(migrationService).processInstitutionRecords(sampleRecords, "parchment");
    }

    @Test
    void testUploadExcelFile_PartialSuccess() throws IOException {
        Map<String, Object> partialResult = new HashMap<>();
        partialResult.put("totalRecords", 2);
        partialResult.put("updatedRecords", 1);
        partialResult.put("notFoundRecords", 1);
        partialResult.put("notFoundInstitutions", List.of("Unknown University"));

        when(migrationService.isMigrationTypeSupported("parchment")).thenReturn(true);
        when(excelParserService.parseExcelFile(any(MultipartFile.class))).thenReturn(sampleRecords);
        when(migrationService.processInstitutionRecords(anyList(), eq("parchment")))
                .thenReturn(partialResult);

        ResponseEntity<MigrationResponseDTO> response = controller.uploadExcelFile(validFile, "parchment");

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("success", response.getBody().getStatus());
        assertEquals(2, response.getBody().getTotalRecords());
        assertEquals(1, response.getBody().getUpdatedRecords());
        assertEquals(1, response.getBody().getNotFoundRecords());
        assertEquals(1, response.getBody().getNotFoundInstitutions().size());
        assertEquals("Unknown University", response.getBody().getNotFoundInstitutions().get(0));
    }

    @Test
    void testUploadExcelFile_DefaultMigrationType() throws IOException {
        when(migrationService.isMigrationTypeSupported("parchment")).thenReturn(true);
        when(excelParserService.parseExcelFile(any(MultipartFile.class))).thenReturn(sampleRecords);
        when(migrationService.processInstitutionRecords(anyList(), eq("parchment")))
                .thenReturn(sampleProcessingResult);

        ResponseEntity<MigrationResponseDTO> response = controller.uploadExcelFile(validFile, "parchment");

        assertNotNull(response);
        assertEquals("parchment", response.getBody().getMigrationType());
    }
}