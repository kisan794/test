package com.hireright.sourceintelligence.service.notification.impl;

import com.hireright.sourceintelligence.api.dto.notification.NotificationRequestDTO;
import com.hireright.sourceintelligence.api.dto.notification.NotificationResponseDTO;
import com.hireright.sourceintelligence.domain.enums.NotificationType;
import com.hireright.sourceintelligence.service.notification.EmailNotificationService;
import com.hireright.sourceintelligence.service.notification.NotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Email notification strategy implementation
 * Following Strategy Pattern - one of many possible notification strategies
 * Following Open/Closed Principle - open for extension (new strategies), closed for modification
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class EmailNotificationStrategyService implements NotificationService {
    
    private final EmailNotificationService emailNotificationService;
    
    @Override
    public NotificationResponseDTO sendNotification(NotificationRequestDTO request) {
        log.info("Processing email notification request - RequestID: {}", request.getRequestId());
        
        try {
            if (request.isAsync()) {
                emailNotificationService.sendEmailAsync(request.getEmailNotification());
                return NotificationResponseDTO.success("ASYNC", request.getRequestId(), 
                        request.getEmailNotification().getTo().size());
            } else {
                String notificationId = emailNotificationService.sendEmail(request.getEmailNotification());
                return NotificationResponseDTO.success(notificationId, request.getRequestId(), 
                        request.getEmailNotification().getTo().size());
            }
        } catch (Exception e) {
            log.error("Failed to send email notification: {}", e.getMessage(), e);
            return NotificationResponseDTO.failure(request.getRequestId(), e.getMessage());
        }
    }
    
    @Override
    public boolean supports(NotificationRequestDTO request) {
        return request != null && 
               request.getNotificationType() == NotificationType.EMAIL &&
               request.getEmailNotification() != null;
    }
}

