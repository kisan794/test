package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.notification.DataExtractionNotificationDTO;
import com.hireright.sourceintelligence.api.dto.notification.NotificationRequestDTO;
import com.hireright.sourceintelligence.api.dto.notification.NotificationResponseDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH;

/**
 * API interface for notification operations
 * Following API First approach - contract defined before implementation
 */
@RequestMapping(value = BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + "/notifications")
@Tag(name = "Notifications", description = "Endpoints for sending notifications")
public interface NotificationApi {
    
    @Operation(
            summary = "Send a notification",
            description = "Send a notification based on the request type (EMAIL, SMS, etc.)",
            responses = {
                    @ApiResponse(
                            description = "Notification sent successfully",
                            responseCode = "200",
                            content = @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = NotificationResponseDTO.class)
                            )
                    ),
                    @ApiResponse(
                            description = "Invalid request",
                            responseCode = "400",
                            content = @Content(mediaType = "application/json")
                    ),
                    @ApiResponse(
                            description = "Internal server error",
                            responseCode = "500",
                            content = @Content(mediaType = "application/json")
                    )
            }
    )
    @ResponseStatus(HttpStatus.OK)
    @PostMapping(
            value = "/send",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    ResponseEntity<NotificationResponseDTO> sendNotification(
            @Valid @RequestBody NotificationRequestDTO request
    );
    
    @Operation(
            summary = "Send data extraction notification",
            description = "Send a notification for data extraction completion",
            responses = {
                    @ApiResponse(
                            description = "Notification sent successfully",
                            responseCode = "200",
                            content = @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = NotificationResponseDTO.class)
                            )
                    ),
                    @ApiResponse(
                            description = "Invalid request",
                            responseCode = "400",
                            content = @Content(mediaType = "application/json")
                    ),
                    @ApiResponse(
                            description = "Internal server error",
                            responseCode = "500",
                            content = @Content(mediaType = "application/json")
                    )
            }
    )
    @ResponseStatus(HttpStatus.OK)
    @PostMapping(
            value = "/data-extraction",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    ResponseEntity<NotificationResponseDTO> sendDataExtractionNotification(
            @Valid @RequestBody DataExtractionNotificationDTO notification
    );
}

