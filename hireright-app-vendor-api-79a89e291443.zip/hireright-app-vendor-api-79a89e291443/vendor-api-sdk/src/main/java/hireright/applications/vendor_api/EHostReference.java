package hireright.applications.vendor_api;
/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	2017-08-22	Created
 *	V.Tsetsnev	2020-10-05	HRG-122983 Added EMPLOYMENT_SHOW_VERIFIED_WITH_DOCS_FLAG
 * 	V.Tsetsnev	2020-12-07	HRG-145580 Added CREATE_ORDER_EDUCATION_GRADES
 * 	V.Tsetsnev	2021-09-23 	HRG-171238 Added regulation constants to enum
 * 	V.Tsetsnev	2021-10-07	HRG-176817 Added REGULATED_EMPLOYMENT_FLAG_7_YEARS
 *  D.Shchur	2025-09-15  VER-575    Added REGULATION_MAS_ROLE_TYPE, REGULATION_MAS_ROLE_TYPE,
 * 				REGULATION_ASIC_ROLE_TYPE, REGULATION_HK_ROLE_TYPE and REGULATION_MALAYSIA_ROLE_TYPE
 *	M.Kuznetsov	2025-10-29	HRG-345322. Openjdk21-migration
 */

public enum EHostReference implements IReference {
    HOST_ORDER_REF("hostOrderRef"),
    HOST_ORDER_SERVICE_REF("hostOrderServiceRef"),
    HOST_INSTANCE_REF("hostInstanceRef"),
    HOST_DELAY_INFO_NOTE_RECIPIENTS("hostDelayInfoNoteRecipients"),
    HOST_DELAY_ACTION_NOTE_RECIPIENTS("hostDelayActionNoteRecipients"),
    HOST_OBJECT_REF("hostObjectRef"),
    ORIGIN_INSTANCE_REF("originInstanceRef"),
    HOST_REQUESTOR_NAME("hostRequestorName"),
    EMPLOYMENT_SHOW_VERIFIED_WITH_DOCS_FLAG("rVerificationMethod"),
    CREATE_ORDER_EDUCATION_GRADES("createOrderEducationGrades"),
    PACK_PROPERTY_MOM_PROCESS("packPropertyMomProcess"),
    REGULATED_EMPLOYMENT_FLAG_7_YEARS("regulatedEmploymentFlag7Years"),
    REGULATION_FCA_ROLE_TYPE("regulationFCARoleType"),
    REGULATION_MAS_ROLE_TYPE("regulationMASRoleType"),
    REGULATION_ASIC_ROLE_TYPE("regulationASICRoleType"),
    REGULATION_HK_ROLE_TYPE("regulationHKRoleType"),
    REGULATION_MALAYSIA_ROLE_TYPE("regulationMalaysiaRoleType"),
    REGULATION_REGISTRATION_NUMBER("regulationRegistrationNumber"),
    REGULATION_COMPANY_NAME("regulationCompanyName"),
    REGULATION_DEPARTMENT("regulationDepartment"),
    REGULATION_CONTACT_INFO("regulationContactInfo"),
    COMMENT_NOTIFICATIONS_SYNCED_WITH_VENDOR("CommentNotificationsSyncedWithVendor"),
    HOST_MAIN_ORDER_REF("hostMainOrderRef");

    private final String parameterName;

    EHostReference(String sParameterName) {
        this.parameterName = sParameterName;
    }

    public String getParameterName() {
        return this.parameterName;
    }

    public String getPropertyName() {
        return this.name();
    }
}
