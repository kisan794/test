package com.hireright.sourceintelligence.service.impl;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.ACTION_SAVE;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.CONTACTS;
import static com.hireright.sourceintelligence.constants.ErrorConstants.INACTIVE_SOURCE;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowInvalidRequest;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.service.ContactService;
import com.hireright.sourceintelligence.service.SearchService;
import com.hireright.sourceintelligence.service.SourceService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Slf4j
@Transactional
@RequiredArgsConstructor
@Service
public class ContactServiceImpl implements ContactService {

    private final SourceService sourceService;
    private final SearchService searchService;

    @Override
    public void updateContact(ContactDTO contactDTO, UserInfo userInfo) {
        String msg = "updateContact received with HON: " + contactDTO.getHon();

        SourceOrganizationDTO sourceDto = sourceService.getSourceByHon(contactDTO.getHon());
        if (sourceDto.getStatus() != SourceOrganizationStatus.ACTIVE) {
            logAndThrowInvalidRequest(INACTIVE_SOURCE,null,msg);
        }
        sourceDto.getPayload().put(CONTACTS, contactDTO.getContacts().toList().toArray());
        UIActionsDTO uiActionsDTO = new UIActionsDTO();
        uiActionsDTO.setUserAction(ACTION_SAVE);
        sourceService.updateSource(sourceDto, uiActionsDTO);
    }

    @Override
    public SearchResponseDTO getSourceContactListByHon(SearchDTO searchDTO) {
        return searchService.getSourceOrganizationContactListByHon(searchDTO);
    }
}
