package com.hireright.sourceintelligence.api.dto.rds;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CountryDTO {

    @JsonProperty("CountryId")
    private String countryId;

    @JsonProperty("Name")
    private String name;

    @JsonProperty("CourtIntlCharge")
    private String courtIntlCharge;

    @JsonProperty("EduIntlCharge")
    private String eduIntlCharge;

    @JsonProperty("EmplIntlCharge")
    private String emplIntlCharge;

    @JsonProperty("MvrIntlCharge")
    private String mvrIntlCharge;

    @JsonProperty("RefIntlCharge")
    private String refIntlCharge;

    @JsonProperty("Currency")
    private String currency;

    @JsonProperty("DateFormat")
    private String dateFormat;

    @JsonProperty("PhoneCountryCode")
    private String phoneCountryCode;

    @JsonProperty("SsnEquivalent")
    private String ssnEquivalent;

    @JsonProperty("StateEquivalent")
    private String stateEquivalent;

    @JsonProperty("ZipEquivalent")
    private String zipEquivalent;

    @JsonProperty("CourtSearchLevel")
    private String courtSearchLevel;

    @JsonProperty("DobRequired")
    private String dobRequired;

    @JsonProperty("Timezone")
    private String timezone;

    @JsonProperty("DobInquiry")
    private String dobInquiry;

    @JsonProperty("NidInquiry")
    private String nidInquiry;

    @JsonProperty("NidRequired")
    private String nidRequired;

    @JsonProperty("BirthPlaceRequired")
    private String birthPlaceRequired;

    @JsonProperty("BirthPlaceSendToVerifier")
    private String birthPlaceSendToVerifier;

    @JsonProperty("Obsolete")
    private String obsolete;

    @JsonProperty("FinanceRegion")
    private String financeRegion;

    @JsonProperty("SupportRegion")
    private String supportRegion;

    @JsonProperty("Table")
    private String table;

    @JsonProperty("Scn")
    private String scn;

    @JsonProperty("OpType")
    private String opType;

    @JsonProperty("OpTs")
    private Object opTs;

    @JsonProperty("CurrentTs")
    private Object currentTs;

    @JsonProperty("RowId")
    private String rowId;

    @JsonProperty("Username")
    private String username;
}

