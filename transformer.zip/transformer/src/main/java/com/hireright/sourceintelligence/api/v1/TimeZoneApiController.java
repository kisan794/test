package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.timezone.DropDownDTO;
import com.hireright.sourceintelligence.api.dto.timezone.TimeZoneResponseDTO;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.TextStyle;
import java.util.*;

import static com.hireright.sourceintelligence.api.ApiConstants.GMT;
import static com.hireright.sourceintelligence.api.ApiConstants.TIMEZONE_ID_PREFIXES;

@Slf4j
@Controller
public class TimeZoneApiController implements TimeZoneApi{


    @Override
    public ResponseEntity<TimeZoneResponseDTO> getTimeZones() {
        List<DropDownDTO> dropDownDTOList = new ArrayList<>();
        String[] timeZonesList = TimeZone.getAvailableIDs();
        for(String id : timeZonesList)
        {
            if(id.matches(TIMEZONE_ID_PREFIXES)){
                ZoneId zoneId = ZoneId.of(id);
                ZonedDateTime now = ZonedDateTime.now(zoneId);
                DropDownDTO dropDownDTO = getDropDownDTO(id, now, zoneId);
                dropDownDTOList.add(dropDownDTO);
            }
        }
        TimeZoneResponseDTO timeZoneResponseDTO = new TimeZoneResponseDTO();
        timeZoneResponseDTO.setData(dropDownDTOList);
        return ResponseEntity.ok(timeZoneResponseDTO);
    }

    private static @NotNull DropDownDTO getDropDownDTO(String id, ZonedDateTime now, ZoneId zoneId) {
        int offsetInSeconds = now.getOffset().getTotalSeconds();
        int hours = offsetInSeconds / 3600;
        int minutes = Math.abs((offsetInSeconds / 60) % 60);
        String offset = String.format(GMT, hours, minutes);

        String displayName = zoneId.getDisplayName(TextStyle.FULL, Locale.ENGLISH);
        String finalValue = "( "+ offset +" ) "+ id +" - "+displayName;

        DropDownDTO dropDownDTO = new DropDownDTO();
        dropDownDTO.setLabel(finalValue);
        dropDownDTO.setValue(id);
        return dropDownDTO;
    }
}
