package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.InstitutionRecord;
import com.hireright.sourceintelligence.service.migration.MigrationProcessor;
import com.hireright.sourceintelligence.service.migration.MigrationProcessorFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MigrationServiceTest {

    @Mock
    private MigrationProcessorFactory processorFactory;

    @Mock
    private MigrationProcessor mockProcessor;

    @InjectMocks
    private MigrationService migrationService;

    private List<InstitutionRecord> sampleRecords;

    @BeforeEach
    void setUp() {
        sampleRecords = Arrays.asList(
                InstitutionRecord.builder()
                        .institutionName("Harvard University")
                        .country("USA")
                        .city("Cambridge")
                        .stateCountyRegion("MA")
                        .build(),
                InstitutionRecord.builder()
                        .institutionName("MIT")
                        .country("USA")
                        .city("Cambridge")
                        .stateCountyRegion("MA")
                        .build()
        );
    }

    @Test
    void testProcessInstitutionRecords_Success() {
        Map<String, Object> expectedResult = new HashMap<>();
        expectedResult.put("totalRecords", 2);
        expectedResult.put("updatedRecords", 2);
        expectedResult.put("notFoundRecords", 0);
        expectedResult.put("notFoundInstitutions", new ArrayList<>());

        when(processorFactory.getProcessor("parchment")).thenReturn(mockProcessor);
        when(mockProcessor.processInstitutionRecords(anyList())).thenReturn(expectedResult);

        Map<String, Object> result = migrationService.processInstitutionRecords(sampleRecords, "parchment");

        assertNotNull(result);
        assertEquals(2, result.get("totalRecords"));
        assertEquals(2, result.get("updatedRecords"));
        assertEquals(0, result.get("notFoundRecords"));
        assertEquals("parchment", result.get("migrationType"));

        verify(processorFactory).getProcessor("parchment");
        verify(mockProcessor).processInstitutionRecords(sampleRecords);
    }

    @Test
    void testProcessInstitutionRecords_AddsMigrationTypeToResult() {
        Map<String, Object> processorResult = new HashMap<>();
        processorResult.put("totalRecords", 1);

        when(processorFactory.getProcessor("parchment")).thenReturn(mockProcessor);
        when(mockProcessor.processInstitutionRecords(anyList())).thenReturn(processorResult);

        Map<String, Object> result = migrationService.processInstitutionRecords(sampleRecords, "parchment");

        assertTrue(result.containsKey("migrationType"));
        assertEquals("parchment", result.get("migrationType"));
    }

    @Test
    void testProcessInstitutionRecords_ProcessorNotFound() {
        when(processorFactory.getProcessor("unknown"))
                .thenThrow(new IllegalArgumentException("Unsupported migration type"));

        assertThrows(IllegalArgumentException.class, () -> {
            migrationService.processInstitutionRecords(sampleRecords, "unknown");
        });

        verify(processorFactory).getProcessor("unknown");
        verify(mockProcessor, never()).processInstitutionRecords(anyList());
    }

    @Test
    void testGetSupportedMigrationTypes() {
        when(processorFactory.getSupportedTypes()).thenReturn("parchment, clearinghouse");

        String supportedTypes = migrationService.getSupportedMigrationTypes();

        assertEquals("parchment, clearinghouse", supportedTypes);
        verify(processorFactory).getSupportedTypes();
    }

    @Test
    void testIsMigrationTypeSupported_True() {
        when(processorFactory.isSupported("parchment")).thenReturn(true);

        boolean isSupported = migrationService.isMigrationTypeSupported("parchment");

        assertTrue(isSupported);
        verify(processorFactory).isSupported("parchment");
    }

    @Test
    void testIsMigrationTypeSupported_False() {
        when(processorFactory.isSupported("unknown")).thenReturn(false);

        boolean isSupported = migrationService.isMigrationTypeSupported("unknown");

        assertFalse(isSupported);
        verify(processorFactory).isSupported("unknown");
    }

    @Test
    void testProcessInstitutionRecords_EmptyList() {
        List<InstitutionRecord> emptyList = Collections.emptyList();
        Map<String, Object> expectedResult = new HashMap<>();
        expectedResult.put("totalRecords", 0);
        expectedResult.put("updatedRecords", 0);
        expectedResult.put("notFoundRecords", 0);
        expectedResult.put("notFoundInstitutions", new ArrayList<>());

        when(processorFactory.getProcessor("parchment")).thenReturn(mockProcessor);
        when(mockProcessor.processInstitutionRecords(anyList())).thenReturn(expectedResult);

        Map<String, Object> result = migrationService.processInstitutionRecords(emptyList, "parchment");

        assertNotNull(result);
        assertEquals(0, result.get("totalRecords"));
        verify(mockProcessor).processInstitutionRecords(emptyList);
    }

    @Test
    void testProcessInstitutionRecords_ProcessorThrowsException() {
        when(processorFactory.getProcessor("parchment")).thenReturn(mockProcessor);
        when(mockProcessor.processInstitutionRecords(anyList()))
                .thenThrow(new RuntimeException("Database error"));

        assertThrows(RuntimeException.class, () -> {
            migrationService.processInstitutionRecords(sampleRecords, "parchment");
        });

        verify(processorFactory).getProcessor("parchment");
        verify(mockProcessor).processInstitutionRecords(sampleRecords);
    }

    @Test
    void testProcessInstitutionRecords_DifferentMigrationType() {
        Map<String, Object> expectedResult = new HashMap<>();
        expectedResult.put("totalRecords", 2);

        when(processorFactory.getProcessor("clearinghouse")).thenReturn(mockProcessor);
        when(mockProcessor.processInstitutionRecords(anyList())).thenReturn(expectedResult);

        Map<String, Object> result = migrationService.processInstitutionRecords(sampleRecords, "clearinghouse");

        assertEquals("clearinghouse", result.get("migrationType"));
        verify(processorFactory).getProcessor("clearinghouse");
    }
}