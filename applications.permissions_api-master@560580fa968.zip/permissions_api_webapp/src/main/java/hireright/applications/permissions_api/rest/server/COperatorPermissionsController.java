package hireright.applications.permissions_api.rest.server;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-16  HRG-330191 initial version
 */

import hireright.applications.permissions_api.api.IPermissionsApiProvider;
import hireright.applications.permissions_api.api.management.IOperatorPermissionsManager;
import hireright.applications.permissions_api.model.CCollection;
import hireright.applications.permissions_api.model.COperatorPermission;
import hireright.applications.permissions_api.model.COperatorPermissionFilter;
import hireright.applications.permissions_api.model.COperatorPermissionResources;
import hireright.applications.permissions_api.model.CSort;
import hireright.sdk.util.CStringUtils;
import hireright.spring.transaction.db.ReadOnlyTransaction;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

@Controller
public class COperatorPermissionsController extends CAbstractController
	implements OperatorPermissionsApi
{
	public COperatorPermissionsController(IPermissionsApiProvider apiProvider)
	{
		super(apiProvider);
	}

	@Override
	@ReadOnlyTransaction
	public ResponseEntity<COperatorPermissionResources> getOperatorPermissions(Long lOffset,
		Integer nLimit, String sSort, String sOrder, String sSubject, String sScope)
	{
		IOperatorPermissionsManager manager = getApi().getOperatorPermissionsManager();

		CSort<COperatorPermission.EField> sort;
		if(!CStringUtils.isEmpty(sSort) && !CStringUtils.isEmpty(sOrder))
		{
			sort = new CSort<>(COperatorPermission.EField.fromValue(sSort),
				CSort.EOrder.fromValue(sOrder));
		}
		else
		{
			sort = manager.getDefaultSort();
		}

		COperatorPermissionFilter.Builder filter = new COperatorPermissionFilter.Builder();
		filter.scope(sScope);
		filter.subject(sSubject);

		CCollection<COperatorPermission> records =
			manager.list(lOffset, nLimit, sort, filter.build());

		COperatorPermissionResources.Builder response = new COperatorPermissionResources.Builder();

		response.data(records.getItems());
		response.offset(records.getOffset());
		response.limit(records.getLimit());
		response.total(records.getTotal());

		return ResponseEntity.ok().body(response.build());
	}
}
