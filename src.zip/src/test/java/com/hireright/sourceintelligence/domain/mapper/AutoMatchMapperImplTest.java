package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.Alias;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchSourceDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;

import static org.junit.jupiter.api.Assertions.*;

class AutoMatchMapperImplTest {

    private AutoMatchMapperImpl mapper;

    @BeforeEach
    void setUp() {
        mapper = new AutoMatchMapperImpl();
    }

    @Test
    void toAutoMatchDTO_shouldReturnNull_whenSourceIsNull() {
        assertNull(mapper.toAutoMatchDTO(null));
    }

    @Test
    void toAutoMatchDTO_shouldSkipTypeAndDates_whenNullableFieldsAreNull() {
        SourceOrganizationStatus status = SourceOrganizationStatus.values()[0];

        BasicDBObject additionalInfoObj = new BasicDBObject();
        additionalInfoObj.put("verificationValidationProcess", "Process-B");
        additionalInfoObj.put("releaseType", "Auto");
        additionalInfoObj.put("sourceLanguage", "Spanish");
        additionalInfoObj.put("contactPersonName", "Jane");
        additionalInfoObj.put("contactPersonTitle", "Director");
        additionalInfoObj.put("contactTimeFrom", "10:00");
        additionalInfoObj.put("contactTimeTo", "18:00");
        additionalInfoObj.put("contactTimeZone", "CST");
        additionalInfoObj.put("doNotContact", "");

        BasicDBList additionalInfo = new BasicDBList();
        additionalInfo.add(additionalInfoObj);

        BasicDBObject payload = new BasicDBObject();
        payload.put("departmentName", "Registrar");
        payload.put("website", "https://example.org");
        payload.put("notes", "Another note");
        payload.put("unAccreditedSource", false);
        payload.put("lastUsedDateTime", "2026-04-02T00:00:00Z");
        payload.put("addionalInfo", additionalInfo);

        Source source = Source.builder()
                .hon("HON999")
                .organizationName("Another University")
                .status(status)
                .version(1.0)
                .organizationType(null)
                .city("Dallas")
                .country("USA")
                .state("Texas")
                .postalCode("75001")
                .organizationAlias(null)
                .payload(payload)
                .lastModifiedBy("user2")
                .approvedBy("approver2")
                .lastModifiedDate(null)
                .lastApprovedDate(null)
                .createdDate(null)
                .build();

        AutoMatchSourceDTO result = mapper.toAutoMatchDTO(source);

        assertNotNull(result);

        assertEquals("sidb2", result.getPlatform());
        assertNull(result.getType());
        assertEquals("HON999", result.getHon());
        assertEquals("USA", result.getCountry());
        assertEquals("Texas", result.getRegion());
        assertEquals("75001", result.getPostalCode());
        assertEquals("user2", result.getLastModifierName());
        assertEquals("approver2", result.getLastApproverName());

        assertNull(result.getLastModified());
        assertNull(result.getLastApproved());
        assertNull(result.getCreated());

        assertEquals(encodeUtf16BeBase64("Another University"), result.getName());
        assertEquals(encodeUtf16BeBase64("Dallas"), result.getCity());

        assertNotNull(result.getAliases());
        assertTrue(result.getAliases().isEmpty());

        assertEquals(encodeUtf16BeBase64("Registrar"), result.getDepartment());
        assertEquals("https://example.org", result.getWebsite());
        assertEquals(encodeUtf16BeBase64("Another note"), result.getComment());

        assertEquals(String.valueOf(status), result.getStatus());
        assertEquals("Process-B", result.getVerificationValidationProcess());
        assertEquals("Auto", result.getReleaseType());
        assertEquals("Spanish", result.getLanguage());
        assertFalse(result.isUnaccredited());
        assertEquals("2026-04-02T00:00:00Z", result.getLastUsed());
        assertEquals("Jane", result.getContactPersonName());
        assertEquals("Director", result.getContactPersonTitle());
        assertEquals("10:00", result.getContactTimeFrom());
        assertEquals("18:00", result.getContactTimeTo());
        assertEquals("CST", result.getContactTimeZone());
        assertFalse(result.getDoNotContact());

        assertNotNull(result.getContactAutomatedServices());
        assertTrue(result.getContactAutomatedServices().isEmpty());

        assertNull(result.getContactPhones());
        assertNull(result.getContactFaxes());
        assertNull(result.getContactEmails());
        assertNull(result.getContactWebsites());
        assertNull(result.getContactMails());
    }



    @Test
    void toAutoMatchDTO_shouldMapAllFields_whenSourceHasValues() {
        OrganizationType organizationType = OrganizationType.values()[0];
        SourceOrganizationStatus status = SourceOrganizationStatus.values()[0];

        Instant lastModified = Instant.parse("2026-04-07T10:15:30Z");
        Instant lastApproved = Instant.parse("2026-04-06T10:15:30Z");
        Instant created = Instant.parse("2026-04-05T10:15:30Z");

        Alias alias1 = new Alias();
        alias1.setName("Alias One");

        Alias alias2 = new Alias();
        alias2.setName("");

        BasicDBObject additionalInfoObj = new BasicDBObject();
        additionalInfoObj.put("verificationValidationProcess", "Process-A");
        additionalInfoObj.put("releaseType", "Manual");
        additionalInfoObj.put("sourceLanguage", "English");
        additionalInfoObj.put("contactPersonName", "John");
        additionalInfoObj.put("contactPersonTitle", "Manager");
        additionalInfoObj.put("contactTimeFrom", "09:00");
        additionalInfoObj.put("contactTimeTo", "17:00");
        additionalInfoObj.put("contactTimeZone", "UTC");
        additionalInfoObj.put("doNotContact", "");

        BasicDBList additionalInfo = new BasicDBList();
        additionalInfo.add(additionalInfoObj);

        BasicDBObject addressObj = new BasicDBObject();
        addressObj.put("line", "123 Main Street");

        BasicDBList address = new BasicDBList();
        address.add(addressObj);

        BasicDBObject payload = new BasicDBObject();
        payload.put("departmentName", "Admissions");
        payload.put("website", "https://example.com");
        payload.put("notes", "Important note");
        payload.put("unAccreditedSource", true);
        payload.put("lastUsedDateTime", "2026-04-01T00:00:00Z");
        payload.put("addionalInfo", additionalInfo);
        payload.put("address", address);

        Source source = Source.builder()
                .hon("HON123")
                .organizationName("Test University")
                .status(status)
                .version(3.0)
                .organizationType(organizationType)
                .city("Chicago")
                .country("USA")
                .state("Illinois")
                .postalCode("60601")
                .organizationAlias(new Alias[]{alias1, alias2})
                .payload(payload)
                .lastModifiedBy("modifierUser")
                .approvedBy("approverUser")
                .lastModifiedDate(lastModified)
                .lastApprovedDate(lastApproved)
                .createdDate(created)
                .build();

        AutoMatchSourceDTO result = mapper.toAutoMatchDTO(source);

        assertNotNull(result);

        assertEquals("sidb2", result.getPlatform());
        assertEquals(organizationType.name(), result.getType());
        assertEquals("HON123", result.getHon());
        assertEquals("USA", result.getCountry());
        assertEquals("Illinois", result.getRegion());
        assertEquals("60601", result.getPostalCode());
        assertEquals("modifierUser", result.getLastModifierName());
        assertEquals("approverUser", result.getLastApproverName());
        assertEquals(lastModified.toString(), result.getLastModified());
        assertEquals(lastApproved.toString(), result.getLastApproved());
        assertEquals(created.toString(), result.getCreated());

        assertEquals(encodeUtf16BeBase64("Test University"), result.getName());
        assertEquals(encodeUtf16BeBase64("Chicago"), result.getCity());

        assertNotNull(result.getAliases());
        assertEquals(1, result.getAliases().size());
        assertEquals(encodeUtf16BeBase64("Alias One"), result.getAliases().get(0));

        assertEquals(encodeUtf16BeBase64("Admissions"), result.getDepartment());
        assertEquals("https://example.com", result.getWebsite());
        assertEquals("123 Main Street", result.getAddress());
        assertEquals(encodeUtf16BeBase64("Important note"), result.getComment());

        assertEquals(String.valueOf(status), result.getStatus());
        assertEquals("Process-A", result.getVerificationValidationProcess());
        assertEquals("Manual", result.getReleaseType());
        assertEquals("English", result.getLanguage());
        assertTrue(result.isUnaccredited());
        assertEquals("2026-04-01T00:00:00Z", result.getLastUsed());
        assertEquals("John", result.getContactPersonName());
        assertEquals("Manager", result.getContactPersonTitle());
        assertEquals("09:00", result.getContactTimeFrom());
        assertEquals("17:00", result.getContactTimeTo());
        assertEquals("UTC", result.getContactTimeZone());
        assertFalse(result.getDoNotContact());

        assertNotNull(result.getContactAutomatedServices());
        assertTrue(result.getContactAutomatedServices().isEmpty());

        assertNull(result.getContactPhones());
        assertNull(result.getContactFaxes());
        assertNull(result.getContactEmails());
        assertNull(result.getContactWebsites());
        assertNull(result.getContactMails());
    }

    private String encodeUtf16BeBase64(String value) {
        return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_16BE));
    }
}