package com.hireright.sourceintelligence.service.notification.impl;

import com.hireright.sourceintelligence.api.dto.notification.NotificationRequestDTO;
import com.hireright.sourceintelligence.api.dto.notification.NotificationResponseDTO;
import com.hireright.sourceintelligence.api.dto.notification.SmsNotificationDTO;
import com.hireright.sourceintelligence.domain.enums.NotificationType;
import com.hireright.sourceintelligence.service.notification.NotificationService;
import com.hireright.sourceintelligence.service.notification.SmsNotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.concurrent.CompletableFuture;

/**
 * Strategy implementation for SMS notifications
 * Following Strategy Pattern - provides SMS-specific notification handling
 * 
 * This service acts as a bridge between the generic NotificationService interface
 * and the SMS-specific SmsNotificationService implementation
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class SmsNotificationStrategyService implements NotificationService {
    
    private final SmsNotificationService smsNotificationService;
    
    @Override
    public NotificationResponseDTO sendNotification(NotificationRequestDTO request) {
        log.info("Processing SMS notification request. Request ID: {}", request.getRequestId());
        
        try {
            SmsNotificationDTO smsNotification = request.getSmsNotification();
            
            if (smsNotification == null) {
                return buildErrorResponse(request, "SMS notification details are missing");
            }
            
            String notificationId;
            
            if (Boolean.TRUE.equals(request.getAsync())) {
                log.debug("Sending SMS notification asynchronously");
                CompletableFuture<String> future = smsNotificationService.sendSmsAsync(smsNotification);
                
                // Return immediately for async operations
                return NotificationResponseDTO.builder()
                        .status("QUEUED")
                        .message("SMS notification queued for async delivery")
                        .requestId(request.getRequestId())
                        .sentAt(LocalDateTime.now())
                        .recipientCount(smsNotification.getPhoneNumbers().size())
                        .build();
            } else {
                log.debug("Sending SMS notification synchronously");
                notificationId = smsNotificationService.sendSms(smsNotification);
                
                return buildSuccessResponse(request, notificationId, smsNotification.getPhoneNumbers().size());
            }
            
        } catch (Exception e) {
            log.error("Failed to send SMS notification: {}", e.getMessage(), e);
            return buildErrorResponse(request, e.getMessage());
        }
    }
    
    @Override
    public boolean supports(NotificationRequestDTO request) {
        return request != null && request.getNotificationType() == NotificationType.SMS;
    }
    
    private NotificationResponseDTO buildSuccessResponse(NotificationRequestDTO request, 
                                                         String notificationId, 
                                                         int recipientCount) {
        return NotificationResponseDTO.builder()
                .status("SUCCESS")
                .message("SMS notification sent successfully")
                .notificationId(notificationId)
                .requestId(request.getRequestId())
                .sentAt(LocalDateTime.now())
                .recipientCount(recipientCount)
                .build();
    }
    
    private NotificationResponseDTO buildErrorResponse(NotificationRequestDTO request, String errorMessage) {
        return NotificationResponseDTO.builder()
                .status("FAILURE")
                .message("Failed to send SMS notification")
                .error(errorMessage)
                .requestId(request.getRequestId())
                .sentAt(LocalDateTime.now())
                .recipientCount(0)
                .build();
    }
}

