package com.hireright.sourceintelligence.reports.domain.entity;

import com.hireright.sourceintelligence.reports.dto.OperatorReportFlatDTO;
import com.hireright.sourceintelligence.reports.dto.OperatorReviewerReportDTO;
import com.hireright.sourceintelligence.reports.dto.ReviewerReportDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReportSearchResult {

    private List<ContactReport> contactUtilizationList;
    private List<ResponseReport> responseReportList;
    private List<OperatorReportFlatDTO> operatorReportFlatList;
    private List<ReviewerReportDTO> reviewerReportList;
    private List<OperatorReviewerReportDTO> operatorReviewerReportList;
    private List<TATReport> tatResponseReportList;
    private int total;
}
