package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.rds.LanguageDTO;
import com.hireright.sourceintelligence.domain.entity.Language;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class LanguageMapperTest {

    private final LanguageMapper mapper = Mappers.getMapper(LanguageMapper.class);

    @Test
    void convertBigDecimalToString_shouldReturnNullWhenValueIsNull() {
        assertNull(mapper.convertBigDecimalToString(null));
    }

    @Test
    void convertBigDecimalToString_shouldReturnPlainStringWhenValueIsNotNull() {
        assertEquals("123.45", mapper.convertBigDecimalToString(new BigDecimal("123.4500")));
        assertEquals("100", mapper.convertBigDecimalToString(new BigDecimal("100.000")));
    }

    @Test
    void entityToDTO_shouldMapAllFields() {
        Language entity = new Language();
        entity.setLanguageId(new BigDecimal("101.000"));
        entity.setName("English");
        entity.setIso6391("en");
        entity.setIso6392t("eng");
        entity.setLanguageTag("en-US");

        LanguageDTO dto = mapper.entityToDTO(entity);

        assertNotNull(dto);
        assertEquals("101", dto.getId());
        assertEquals("English", dto.getName());
        assertEquals("en", dto.getIso6391());
        assertEquals("eng", dto.getIso6392t());
        assertEquals("en-US", dto.getLanguageTag());
    }

    @Test
    void entityToDTO_shouldHandleNullBigDecimal() {
        Language entity = new Language();
        entity.setLanguageId(null);
        entity.setName("Hindi");
        entity.setIso6391("hi");
        entity.setIso6392t("hin");
        entity.setLanguageTag("hi-IN");

        LanguageDTO dto = mapper.entityToDTO(entity);

        assertNotNull(dto);
        assertNull(dto.getId());
        assertEquals("Hindi", dto.getName());
        assertEquals("hi", dto.getIso6391());
        assertEquals("hin", dto.getIso6392t());
        assertEquals("hi-IN", dto.getLanguageTag());
    }

    @Test
    void entityToDTOList_shouldMapList() {
        Language entity1 = new Language();
        entity1.setLanguageId(new BigDecimal("1"));
        entity1.setName("English");
        entity1.setIso6391("en");
        entity1.setIso6392t("eng");
        entity1.setLanguageTag("en-US");

        Language entity2 = new Language();
        entity2.setLanguageId(new BigDecimal("2"));
        entity2.setName("Hindi");
        entity2.setIso6391("hi");
        entity2.setIso6392t("hin");
        entity2.setLanguageTag("hi-IN");

        List<LanguageDTO> result = mapper.entityToDTOList(List.of(entity1, entity2));

        assertNotNull(result);
        assertEquals(2, result.size());

        assertEquals("1", result.get(0).getId());
        assertEquals("English", result.get(0).getName());
        assertEquals("en", result.get(0).getIso6391());
        assertEquals("eng", result.get(0).getIso6392t());
        assertEquals("en-US", result.get(0).getLanguageTag());

        assertEquals("2", result.get(1).getId());
        assertEquals("Hindi", result.get(1).getName());
        assertEquals("hi", result.get(1).getIso6391());
        assertEquals("hin", result.get(1).getIso6392t());
        assertEquals("hi-IN", result.get(1).getLanguageTag());
    }
}
