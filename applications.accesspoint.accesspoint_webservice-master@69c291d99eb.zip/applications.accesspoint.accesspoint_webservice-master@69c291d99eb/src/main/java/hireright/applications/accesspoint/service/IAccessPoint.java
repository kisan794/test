/*
 * @(#)$RCSfile: IAccessPoint.java,v $ $Revision: 1.3 $ $Date: 2015/01/23 13:52:49 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/service/IAccessPoint.java,v $
 *
 * Copyright 2001-2014 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Putintsev		2014-09-22	Created
 *	A.Putintsev		2015-01-16	success parameter in doLogin() is removed
 */
package hireright.applications.accesspoint.service;

import hireright.applications.accesspoint.types.CAccessPointException;
import hireright.applications.accesspoint.types.CParametersListWrapper;

import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Interface for the AccessPoint service
 */
public interface IAccessPoint {
	
	public CreateResult create(String userID, String userClass,
			String entryPointType, String domainID,
			int designNr, String authenticationMode,
			String login, Integer entriesAllowed,
			Integer failuresAllowed,
			XMLGregorianCalendar expirationDate,
			Boolean createSession,
			CParametersListWrapper parametersListWrapper ) throws CAccessPointException;
	
	public CEntryPointBean doLogin( String key )
			throws CAccessPointException;
	
}
