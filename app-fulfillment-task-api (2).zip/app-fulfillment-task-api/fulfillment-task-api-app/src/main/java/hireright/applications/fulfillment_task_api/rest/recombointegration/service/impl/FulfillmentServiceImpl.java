/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.education.Request;
import hireright.applications.fulfillment_task_api.rest.recombointegration.helper.ReadEducationMockResponse;
import hireright.applications.fulfillment_task_api.rest.recombointegration.helper.ReadEmploymentMockResponse;
import hireright.applications.fulfillment_task_api.rest.recombointegration.http.client.Http2ClientService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.Direction;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.RecipientName;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.service.LoggingService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.FulfillmentService;
import hireright.lib.logging.log_trace.CTraceLogger;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static hireright.applications.fulfillment_task_api.rest.recombointegration.util.Constant.EDUCATION;
import static hireright.applications.fulfillment_task_api.rest.recombointegration.util.Constant.EMPLOYMENT;

@Service
@Slf4j
public class FulfillmentServiceImpl implements FulfillmentService
{

	private final Http2ClientService http2ClientService;
	private final ObjectMapper objectMapper;
	private final LoggingService loggingService;

	// Cache for education verification data
	private Map<String, Request> educationCache;

	// Cache for employment verification data
	private Map<String, hireright.applications.fulfillment_task_api.model.recombointegration.employment.Request>
		employmentCache;

	// Recombo service configuration
	@Value("${recombo.service.base-url}")
	private String recomboServiceBaseUrl;

	@Value("${recombo.third-party.submit-endpoint}")
	private String recomboSubmitEndpoint;

	public FulfillmentServiceImpl(Http2ClientService http2ClientService, ObjectMapper objectMapper,
		LoggingService loggingService)
	{
		this.http2ClientService = http2ClientService;
		this.objectMapper = objectMapper;
		this.loggingService = loggingService;
	}

	/**
	 * Initialize caches on application startup
	 */
	@PostConstruct
	public void initializeCaches()
	{
		log.info("Initializing fulfillment task caches...");
		educationCache = ReadEducationMockResponse.readAllEducationMockResponses();
		employmentCache = ReadEmploymentMockResponse.readAllEmploymentMockResponses();
		log.info("Fulfillment task caches initialized successfully - Education: {}, Employment: {}", educationCache.size(), employmentCache.size());
	}

	/**
	 * Process the task asynchronously
	 *
	 * @param requestId The task ID to process
	 */
	@Async
	@Override
	public void fulfill(String requestId) {

		log.info("Starting async processing - Request ID: {}", requestId);

		// Step 1: Get verification data from cache @TODO DB call and Transformation
		Object verificationData = getVerificationData(requestId);

		// Step 2: Send async POST to third-party submit endpoint
		sendAsyncSubmitRequest(requestId, verificationData);

		log.info("Async task processing completed - Task ID: {}", requestId);
	}

	/**
	 * Get verification data from cache based on requestId
	 ** @return Verification data or null if not found
	 */
	private Object getVerificationData(String requestId)
	{
		String sourceType = getSourceType(requestId);
		Object verificationData = null;
		if(EDUCATION.equals(sourceType)) {
			log.debug("Fetching education verification data for Task ID: {}", requestId);
			verificationData =  educationCache.get(requestId);
		} else if(EMPLOYMENT.equals(sourceType)) {
			log.debug("Fetching employment verification data for Task ID: {}", requestId);
			verificationData =  employmentCache.get(requestId);
		}
		if (verificationData == null) {
			throw new IllegalArgumentException("Verification data not found for request ID:" + requestId);
		}
		return verificationData;
	}

	private String getSourceType(String requestId) {
		if(requestId.contains("edu") || requestId.contains("EDU")) {
			return EDUCATION;
		} else if(requestId.contains("emp") || requestId.contains("EMP")) {
			return EMPLOYMENT;
		} else {
			return "";
		}
	}

	/**
	 * Send async POST request to third-party submit endpoint
	 *
	 * @param requestId           Task ID
	 * @param verificationData Verification data to submit
	 */
	private void sendAsyncSubmitRequest(String requestId, Object verificationData)
	{

		String submitUrl = recomboServiceBaseUrl + recomboSubmitEndpoint.replace("{sourceType}", getSourceType(requestId));
		log.debug("Sending async POST to submit endpoint - URL: {}, Request ID: {}", submitUrl, requestId);

		String jsonPayload;
		try {
			jsonPayload = objectMapper.writeValueAsString(verificationData);
		} catch(JsonProcessingException e) {
			throw new RuntimeException(e);
		}

		// Log the request for auditing
		loggingService.log(jsonPayload, requestId, RecipientName.FULFILLMENT_REQUEST, Direction.OUT);

		// Send async POST request
		CompletableFuture<HttpResponse<String>> futureResponse = http2ClientService.postAsync(submitUrl, jsonPayload, new HashMap<>());

		// Handle async response (non-blocking)
		futureResponse.thenAccept(response -> {
			if(response.statusCode() >= 200 && response.statusCode() < 300) {
				log.info("Successfully submitted verification data to third-party - Task ID: {}, Status: {}", requestId, response.statusCode());
			} else {
				log.warn("Third-party submit returned non-success status: {} for Task ID: {}", response.statusCode(), requestId);
				CTraceLogger.error(this.getClass().getName(), jsonPayload);
			}
		}).exceptionally(ex -> {
			log.error("Failed to submit verification data to third-party - Task ID: {}", requestId, ex);
			return null;
		});

		log.info("Async submit request initiated for Task ID: {}", requestId);
		}
}