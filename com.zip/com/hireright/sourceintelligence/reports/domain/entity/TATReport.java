package com.hireright.sourceintelligence.reports.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TATReport {
    private Object id;
    private List<ResponseReport> data;
}
