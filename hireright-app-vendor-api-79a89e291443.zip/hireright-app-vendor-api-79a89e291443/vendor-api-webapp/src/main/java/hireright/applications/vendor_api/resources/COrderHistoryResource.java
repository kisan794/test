/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk		2017-08-14	Created
 *	T.Prikk			2018-04-10	HIVPE-21816: Fix transformHistoryEntry() (support reference_type = 'ORDER')
 * 	M.Kuznetsov		2025-09-12	HRG-339332: CInstanceDomain support
 */
package hireright.applications.vendor_api.resources;

import java.util.Collections;

import hireright.bdk.instance_parameter.CInstanceDomain;
import hireright.bdk.instance_parameter.CInstanceDomainFactory;
import hireright.sdk.db3.DB;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import hireright.applications.vendor_api.EExchangeDirection;
import hireright.applications.vendor_api.exchange.handler.impl.COrderHistoryExchanger;
import hireright.applications.vendor_api.exchange.handler.objects.COrderEntityExchangeContext;
import hireright.applications.vendor_api.exchange.handler.utils.CExchangeUtils;
import hireright.applications.vendor_api.facades.IdValueFacade;
import hireright.applications.vendor_api.model.CExchangeResponse;
import hireright.applications.vendor_api.model.COrderHistoryRequest;
import hireright.applications.vendor_api.services.OrderHistoryService;
import hireright.components.domain.dialects.vendor_api.BasicResponse;
import hireright.components.domain.dialects.vendor_api.Comment;
import hireright.sdk.db.CMultitenantDB;

@RestController
public class COrderHistoryResource extends AResource
{
	// CREATE
	@RequestMapping(path = OrderHistoryService.PATH_ADD,
			method = RequestMethod.POST,
			consumes = MediaType.APPLICATION_XML_VALUE,
			produces = MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity<BasicResponse> add(
			@PathVariable(name=OrderHistoryService.VAR_ORDER_REF) final String orderRef,
			@RequestBody final Comment orderHistoryEntry) throws Exception
	{
		
		// prepare context data
		COrderEntityExchangeContext<COrderHistoryRequest> context = new COrderEntityExchangeContext<COrderHistoryRequest>();
		String sTenantCode = CExchangeUtils.getTenantCodeByOrderCode(orderRef);
		
		CExchangeResponse exchangeResponse = CMultitenantDB.execute(sTenantCode, () -> {
			Long orderID = CExchangeUtils.getOrderID(orderRef);
			context.setOrderID(orderID);
			context.setTransferObject(DB.execute(() -> transformHistoryEntry(orderHistoryEntry)));
			// perform requested data operation
			return new COrderHistoryExchanger().doCreate(context);
		});
		
		BasicResponse response = transformResponse(exchangeResponse, OrderHistoryService.EResponseParam.ORDER_HISTORY_ID.name());
		
		return new ResponseEntity<BasicResponse>(response, HttpStatus.OK);
	}

	private COrderHistoryRequest transformHistoryEntry(Comment orderHistoryEntry)
	{
		IdValueFacade references = new IdValueFacade(orderHistoryEntry.getReferences() !=null 
				? orderHistoryEntry.getReferences().getIdValues()
				: Collections.EMPTY_LIST);
		
		COrderHistoryRequest request = new COrderHistoryRequest();
		request.setCommentsCode(orderHistoryEntry.getCode());
		request.setHistory(orderHistoryEntry.getText());
		request.setOperatorName(orderHistoryEntry.getAuthor());
		
		request.setReferenceType(references.value(OrderHistoryService.EReferenceType.REFERENCE_TYPE.name()));
		request.setReferenceCode(references.value(OrderHistoryService.EReferenceType.REFERENCE_CODE.name()));
		
		if (orderHistoryEntry.getDate() != null)
		{
			request.setCreationDate(orderHistoryEntry.getDate().toGregorianCalendar().getTime());
		}
		
		request.setObjectRef(references.value(OrderHistoryService.EReferenceType.ORDER_HISTORY.name()));
		request.setRemoteInstanceDomain(CInstanceDomainFactory.search(references.value(CInstanceDomain.PROPERTY_NATIONAL_INSTANCE_ID)));
		request.setExchangeDirection(EExchangeDirection.valueOf(references.value(EExchangeDirection.PROPERTY_NAME)));
		
		return request;
	}
}
