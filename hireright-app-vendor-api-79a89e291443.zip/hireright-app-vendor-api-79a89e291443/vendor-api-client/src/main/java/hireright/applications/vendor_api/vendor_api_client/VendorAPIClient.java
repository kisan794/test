package hireright.applications.vendor_api.vendor_api_client;
/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	2017-08-16	Created
 */
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.io.IOUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import hireright.applications.vendor_api.EExchangeDirection;
import hireright.applications.vendor_api.ENationalInstanceID;
import hireright.applications.vendor_api.responses.FileResponse;
import hireright.applications.vendor_api.services.IMethod;
import hireright.applications.vendor_api.vendor_api_client.exceptions.ValidationException;

public class VendorAPIClient {
    public static final String PARAM_DOMAIN = "VENDOR_DOMAIN";
    public static final String PARAM_DIRECTION = "EXCHANGE_DIRECTION";
    public static final String PARAM_NATIONAL_INSTANCE_ID = "NATIONAL_INSTANCE_ID";

    private static final String VENDOR_API_WEBAPP = "/vendor_api";
    private static final String PARAM_INTERNAL_APP_HOST = "APP_INTERNAL_HTTP_HOST";

    public static final String PARAM_VENDOR_API_HOST = "VENDOR_API_HOST";
    private static final String PARAM_AUTH_TYPE = "AUTH_TYPE";
    private static final String PARAM_VALUE_API_KEY = "API_KEY";
    private static final String PARAM_X_APIGW_API_ID = "x-apigw-api-id";
    private static final String PARAM_X_API_KEY = "x-api-key";

    private final Map<String, Object> properties = new HashMap<>();

    private VendorAPIClient() {}

    public static VendorAPIClient getInstance(String sVendorDomainID, Map<String, Object> properties) {
        Map<String, Object> props = new HashMap<>(properties);
        props.put(PARAM_DOMAIN, sVendorDomainID);
        return getInstance(props);
    }

    public static VendorAPIClient getInstance(Map<String, Object> properties) {
        VendorAPIClient instance = new VendorAPIClient();
        instance.setProperties(properties);
        return instance;
    }

    private void setProperties(Map<String, Object> properties) {
        this.properties.clear();
        this.properties.putAll(properties);
    }

    public String getDomainID() {
        return (String) this.properties.get(PARAM_DOMAIN);
    }

    public ENationalInstanceID getNationalInstance() {
        return ENationalInstanceID.valueOf((String) this.properties.get(PARAM_NATIONAL_INSTANCE_ID));
    }

    public EExchangeDirection getDirection() {
        return EExchangeDirection.valueOf((String) this.properties.get(PARAM_DIRECTION));
    }

    public <T> T execute(IMethod method, Map<String, ?> requestParams, Object requestBody, boolean bValidateRequestBody)
            throws ValidationException {
        if (bValidateRequestBody && !method.isValidRequest(requestBody)) {
            throw new ValidationException("Invalid request");
        }

        return execute(method, requestParams, requestBody);
    }

    public <T> T execute(IMethod method, Map<String, ?> requestParams, Object requestBody) {
        return (T) execute(method, requestParams, Collections.EMPTY_MAP, requestBody);
    }

    public String createPath(IMethod method, Map<String, ?> optionalQueryParams) {
        String sPath = (this.properties.get(PARAM_VENDOR_API_HOST) == null
                ? this.properties.get(PARAM_INTERNAL_APP_HOST)
                : this.properties.get(PARAM_VENDOR_API_HOST))
                + VENDOR_API_WEBAPP + method.getPath();

        if (optionalQueryParams != null) {
            UriComponentsBuilder builder = UriComponentsBuilder.newInstance();

            for (Entry<String, ?> paramEntry : optionalQueryParams.entrySet()) {
                builder.queryParam(paramEntry.getKey(), paramEntry.getValue());
            }

            sPath = sPath + builder.toUriString();
        }
        return sPath;
    }

    public <T> T execute(IMethod method,
            Map<String, ?> requestParams,
            Map<String, ?> optionalQueryParams,
            Object requestBody) {
        String sPath = createPath(method, optionalQueryParams);

        RestTemplate rt = new RestTemplate();
        rt.setErrorHandler(new ResponseErrorHandler() {
            public boolean hasError(ClientHttpResponse response) throws IOException {
                return !String.valueOf(response.getStatusCode().value()).startsWith("2");
                //TODO return response.getStatusCode().is4xxClientError();
            }

            @Override
            public void handleError(URI url, HttpMethod method, ClientHttpResponse response) throws IOException {
                InputStream inputStream = response.getBody();

                //Pure java to work w/o commons-io within smx
                ByteArrayOutputStream result = new ByteArrayOutputStream();
                byte[] buffer = new byte[1024];
                int length;

                while ((length = inputStream.read(buffer)) != -1) {
                    result.write(buffer, 0, length);
                }

                throw new RuntimeException(result.toString(StandardCharsets.UTF_8));
            }
        });

        //Jaxb converter has the highest priority
        rt.getMessageConverters().add(0, new Jaxb2RootElementHttpMessageConverter());

        HttpEntity<?> entity;

        RequestMethod requestMethod = method.getRequestMethod();

        if (RequestMethod.DELETE.equals(requestMethod) || requestBody == null) {
            entity = HttpEntity.EMPTY;
        }
        else if (requestBody instanceof String) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(new MediaType("application", "xml", StandardCharsets.UTF_8));
            headers.add(HttpHeaders.ACCEPT, "application/xml");

            if (PARAM_VALUE_API_KEY.equals(this.properties.get(PARAM_AUTH_TYPE))) {
                headers.add(PARAM_X_APIGW_API_ID, String.valueOf(this.properties.get(PARAM_X_APIGW_API_ID.toUpperCase())));
                headers.add(PARAM_X_API_KEY, String.valueOf(this.properties.get(PARAM_X_API_KEY.toUpperCase())));
            }

            entity = new HttpEntity<>(requestBody, headers);
        }
        else {
            entity = new HttpEntity<>(requestBody);
        }

        switch (method.getRequestMethod()) {
        case GET:
        case POST:
        case PUT:
        case DELETE: {
            if (FileResponse.class.getCanonicalName().equals(method.getResponseBodyClass().getCanonicalName())) {
                return (T) rt.execute(sPath,
                        HttpMethod.valueOf(method.getRequestMethod().name()),
                        (ClientHttpRequest requestCallback) -> {},
                        responseExtractor -> {
                            return new FileResponse(responseExtractor.getHeaders(),
                                    IOUtils.toByteArray(responseExtractor.getBody()));
                        },
                        requestParams);
            }

            ResponseEntity<T> responseEntity = (ResponseEntity<T>) rt.exchange(sPath,
                    HttpMethod.valueOf(method.getRequestMethod().name()),
                    entity,
                    method.getResponseBodyClass(),
                    requestParams);

            return responseEntity.getBody();
        }
        default:
            throw new UnsupportedOperationException();
        }
    }

    public static XMLGregorianCalendar getXMLGregorianCalendarFromClientDate(Date date) {
        if (date == null) {
            return null;
        }

        try {
            GregorianCalendar calendar = new GregorianCalendar();
            calendar.setTime(date);
            return DatatypeFactory.newInstance().newXMLGregorianCalendar(calendar);
        } catch (Throwable ex) {
            throw new RuntimeException(ex);
        }
    }
}
