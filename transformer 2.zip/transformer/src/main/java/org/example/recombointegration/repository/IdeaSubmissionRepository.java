package org.example.recombointegration.repository;

import org.example.recombointegration.document.IdeaSubmission;
import org.example.recombointegration.document.IdeaSubmission.IdeaStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * MongoDB repository interface for IdeaSubmission document.
 * Provides database operations for idea submissions.
 *
 * @author Generated
 * @version 1.0
 */
@Repository
public interface IdeaSubmissionRepository extends MongoRepository<IdeaSubmission, String> {

    /**
     * Find all ideas by status.
     */
    Page<IdeaSubmission> findByStatus(IdeaStatus status, Pageable pageable);

    /**
     * Find all ideas submitted by a specific person.
     */
    Page<IdeaSubmission> findBySubmittedBy(String submittedBy, Pageable pageable);

    /**
     * Find all ideas by department.
     */
    Page<IdeaSubmission> findByDepartment(String department, Pageable pageable);

    /**
     * Find ideas by status and department.
     */
    Page<IdeaSubmission> findByStatusAndDepartment(IdeaStatus status, String department, Pageable pageable);

    /**
     * Find ideas submitted within a date range.
     */
    Page<IdeaSubmission> findBySubmissionDateBetween(LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);

    /**
     * Search ideas by title or description containing keyword.
     */
    @Query("{ $or: [ { 'title': { $regex: ?0, $options: 'i' } }, { 'description': { $regex: ?0, $options: 'i' } } ] }")
    Page<IdeaSubmission> searchByKeyword(String keyword, Pageable pageable);

    /**
     * Find top ideas by upvote count.
     */
    Page<IdeaSubmission> findAllByOrderByUpvoteCountDesc(Pageable pageable);

    /**
     * Find ideas by implementation complexity.
     */
    Page<IdeaSubmission> findByImplementationComplexity(
            IdeaSubmission.ImplementationComplexity complexity, 
            Pageable pageable);

    /**
     * Find ideas by timeline type.
     */
    Page<IdeaSubmission> findByTimelineType(
            IdeaSubmission.TimelineType timelineType, 
            Pageable pageable);

    /**
     * Count ideas by status.
     */
    long countByStatus(IdeaStatus status);

    /**
     * Count ideas by department.
     */
    long countByDepartment(String department);

    /**
     * Count ideas by submitter.
     */
    long countBySubmittedBy(String submittedBy);
}

