package hireright.applications.fulfillment_task_api.model.serialization;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-13  HRG-332327 initial version
 */

public interface ISerializer<SOURCE, TARGET> {
    TARGET serialize(SOURCE source);

    SOURCE deserialize(TARGET source);
}
