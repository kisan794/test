package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.InstitutionRecord;
import com.hireright.sourceintelligence.api.dto.MigrationResponseDTO;
import com.hireright.sourceintelligence.service.impl.ExcelParserService;
import com.hireright.sourceintelligence.service.impl.MigrationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

import static com.hireright.sourceintelligence.constants.ErrorConstants.*;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowInvalidRequest;

/**
 * Controller for data migration operations.
 * Handles Excel file uploads and delegates processing to the appropriate migration processor
 * based on the specified migration type.
 */
@Slf4j
@RestController
@RequiredArgsConstructor
@Validated
@CrossOrigin
public class DataMigrationApiController implements DataMigrationApi {

    private final ExcelParserService excelParserService;
    private final MigrationService migrationService;

    @Value("${migration.file.max-size-mb:10}")
    private int maxFileSizeMb;

    @Override
    public ResponseEntity<MigrationResponseDTO> uploadExcelFile(MultipartFile file, String migrationType) {
        long startTime = System.currentTimeMillis();
        String filename = file.getOriginalFilename();

        log.info("Received migration file upload request - filename: {}, size: {} bytes, type: {}",
                filename, file.getSize(), migrationType);

        // Validate migration type
        if (!migrationService.isMigrationTypeSupported(migrationType)) {
            logAndThrowInvalidRequest(MIGRATION_TYPE_UNSUPPORTED, null,
                    migrationType, migrationService.getSupportedMigrationTypes());
        }

        // Validate file is not empty
        if (file.isEmpty()) {
            logAndThrowInvalidRequest(MIGRATION_FILE_EMPTY, null);
        }

        // Validate file size
        long fileSizeInMb = file.getSize() / (1024 * 1024);
        if (fileSizeInMb > maxFileSizeMb) {
            logAndThrowInvalidRequest(MIGRATION_FILE_TOO_LARGE, null, maxFileSizeMb);
        }

        // Validate file format
        if (filename == null || (!filename.endsWith(".xlsx") && !filename.endsWith(".xls"))) {
            logAndThrowInvalidRequest(MIGRATION_FILE_INVALID_FORMAT, null);
        }

        try {
            log.info("Parsing Excel file: {}", filename);
            List<InstitutionRecord> records = excelParserService.parseExcelFile(file);

            if (records.isEmpty()) {
                logAndThrowInvalidRequest(MIGRATION_NO_RECORDS_FOUND, null);
            }

            log.info("Found {} records in Excel file for migration type: {}", records.size(), migrationType);

            // Process records using the appropriate migration processor
            Map<String, Object> processingResult = migrationService.processInstitutionRecords(records, migrationType);

            long processingTime = System.currentTimeMillis() - startTime;

            // Build response DTO
            MigrationResponseDTO response = buildSuccessResponse(
                    filename,
                    migrationType,
                    processingResult,
                    processingTime
            );

            log.info("Migration completed successfully - type: {}, total: {}, updated: {}, not found: {}, time: {}ms",
                    migrationType,
                    response.getTotalRecords(),
                    response.getUpdatedRecords(),
                    response.getNotFoundRecords(),
                    processingTime);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("Error processing migration file: {}", filename, e);
            logAndThrowInvalidRequest(MIGRATION_PROCESSING_ERROR, e, e.getMessage());
            return null; // Never reached due to exception
        }
    }

    /**
     * Build a success response DTO from processing results.
     */
    private MigrationResponseDTO buildSuccessResponse(
            String filename,
            String migrationType,
            Map<String, Object> processingResult,
            long processingTime) {

        return MigrationResponseDTO.builder()
                .status("success")
                .message("File processed successfully")
                .migrationType(migrationType)
                .filename(filename)
                .totalRecords((Integer) processingResult.get("totalRecords"))
                .updatedRecords((Integer) processingResult.get("updatedRecords"))
                .notFoundRecords((Integer) processingResult.get("notFoundRecords"))
                .notFoundInstitutions((List<String>) processingResult.get("notFoundInstitutions"))
                .processingTimeMs(processingTime)
                .build();
    }
}