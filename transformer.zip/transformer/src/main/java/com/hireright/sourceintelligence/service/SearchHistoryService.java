package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.dto.history.ChangeLogFilters;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;

import java.util.*;

public interface SearchHistoryService {

  //TODO - Remove - Not needed
  SearchResponseDTO getSourceOrganizationsByFilters(OrganizationType organizationType, Map<String, Set<String>> searchFilter,
                                                    List<ApprovalStatus> approvalStatuses, int startPage, int pageSize, UserInfo userInfo);


  List<AutocompleteSearchDTO> getAutocompletedFilters(OrganizationType organizationType, String keyword, UserInfo userInfo);

  //List<SourceOrganizationHistory> getAggregationHits(String keyword, UserInfo userInfo);

  SearchResponseDTO getChangeLogsByFilters(ChangeLogFilters changeLogFilters);
}
