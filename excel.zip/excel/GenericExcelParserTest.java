package com.hireright.sourceintelligence.service.excel;

import com.hireright.sourceintelligence.api.dto.ParchmentRecord;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class GenericExcelParserTest {

    private GenericExcelParser parser;
    private ExcelColumnMapping columnMapping;
    private ExcelRowMapper<ParchmentRecord> rowMapper;

    @BeforeEach
    void setUp() {
        parser = new GenericExcelParser();
        
        columnMapping = ExcelColumnMapping.builder()
                .addHeaderMapping("Institution Name", "institutionName")
                .addHeaderMapping("Country", "country")
                .addHeaderMapping("City", "city")
                .addHeaderMapping("State/County/Region", "stateCountyRegion")
                .addHeaderMapping("Service Provider", "serviceProvider")
                .addHeaderMapping("Surcharge Amount", "surchargeAmount")
                .addHeaderMapping("Payment Method", "paymentMethod")
                .addHeaderMapping("Code", "code")
                .addHeaderMapping("Turnaround Time", "turnaroundTime")
                .addHeaderMapping("Follow Up Allowed", "followUpAllowed")
                .headerRowIndex(0)
                .dataStartRowIndex(1)
                .sheetIndex(0)
                .build();

        rowMapper = (row, mapping) -> ParchmentRecord.builder()
                .institutionName(getCellValue(row, mapping, "institutionName"))
                .country(getCellValue(row, mapping, "country"))
                .city(getCellValue(row, mapping, "city"))
                .stateCountyRegion(getCellValue(row, mapping, "stateCountyRegion"))
                .serviceProvider(getCellValue(row, mapping, "serviceProvider"))
                .surchargeAmount(getCellValue(row, mapping, "surchargeAmount"))
                .paymentMethod(getCellValue(row, mapping, "paymentMethod"))
                .code(getCellValue(row, mapping, "code"))
                .turnaroundTime(getCellValue(row, mapping, "turnaroundTime"))
                .followUpAllowed(getCellValue(row, mapping, "followUpAllowed"))
                .build();
    }

    private String getCellValue(Row row, ExcelColumnMapping mapping, String fieldName) {
        Integer columnIndex = mapping.getColumnIndex(fieldName);
        if (columnIndex == null) {
            return "";
        }
        return ExcelCellReader.getCellValue(row, columnIndex);
    }

    @Test
    void parseExcelFile_WithValidFile_ShouldParseRecords() throws IOException {
        MultipartFile file = createTestExcelFile();

        List<ParchmentRecord> records = parser.parseExcelFile(file, columnMapping, rowMapper);

        assertNotNull(records);
        assertEquals(2, records.size());
        assertEquals("Harvard University", records.get(0).getInstitutionName());
        assertEquals("MIT", records.get(1).getInstitutionName());
    }

    @Test
    void parseExcelFile_WithEmptyDataRows_ShouldSkipEmptyRows() throws IOException {
        MultipartFile file = createExcelFileWithEmptyRows();

        List<ParchmentRecord> records = parser.parseExcelFile(file, columnMapping, rowMapper);

        assertNotNull(records);
        assertEquals(2, records.size());
        assertEquals("Harvard University", records.get(0).getInstitutionName());
        assertEquals("MIT", records.get(1).getInstitutionName());
    }

    @Test
    void parseExcelFile_WithOnlyHeaderRow_ShouldReturnEmptyList() throws IOException {
        MultipartFile file = createExcelFileWithOnlyHeader();

        List<ParchmentRecord> records = parser.parseExcelFile(file, columnMapping, rowMapper);

        assertNotNull(records);
        assertTrue(records.isEmpty());
    }

    @Test
    void parseExcelFile_WithMultipleSheets_ShouldParseFirstSheet() throws IOException {
        MultipartFile file = createExcelFileWithMultipleSheets();

        List<ParchmentRecord> records = parser.parseExcelFile(file, columnMapping, rowMapper);

        assertNotNull(records);
        assertEquals(1, records.size());
        assertEquals("Harvard University", records.get(0).getInstitutionName());
    }

    @Test
    void parseExcelFile_WithDifferentSheetIndex_ShouldParseCorrectSheet() throws IOException {
        ExcelColumnMapping secondSheetMapping = ExcelColumnMapping.builder()
                .addHeaderMapping("Institution Name", "institutionName")
                .addHeaderMapping("Country", "country")
                .headerRowIndex(0)
                .dataStartRowIndex(1)
                .sheetIndex(1)
                .build();

        MultipartFile file = createExcelFileWithMultipleSheets();

        List<ParchmentRecord> records = parser.parseExcelFile(file, secondSheetMapping, rowMapper);

        assertNotNull(records);
        assertEquals(1, records.size());
        assertEquals("Stanford University", records.get(0).getInstitutionName());
    }

    @Test
    void parseExcelFile_WithLargeFile_ShouldParseAllRecords() throws IOException {
        MultipartFile file = createLargeExcelFile(100);

        List<ParchmentRecord> records = parser.parseExcelFile(file, columnMapping, rowMapper);

        assertNotNull(records);
        assertEquals(100, records.size());
    }

    @Test
    void parseExcelFile_WithMissingColumns_ShouldHandleGracefully() throws IOException {
        MultipartFile file = createExcelFileWithPartialColumns();

        List<ParchmentRecord> records = parser.parseExcelFile(file, columnMapping, rowMapper);

        assertNotNull(records);
        assertEquals(1, records.size());
        assertEquals("Harvard University", records.get(0).getInstitutionName());
        assertEquals("USA", records.get(0).getCountry());
        assertEquals("", records.get(0).getCity());
    }

    @Test
    void parseExcelFile_WithNullFile_ShouldThrowException() {
        assertThrows(NullPointerException.class, () -> 
            parser.parseExcelFile(null, columnMapping, rowMapper)
        );
    }

    @Test
    void parseExcelFile_WithInvalidFile_ShouldThrowIOException() {
        MockMultipartFile invalidFile = new MockMultipartFile(
                "file",
                "test.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "invalid content".getBytes()
        );

        assertThrows(IOException.class, () -> 
            parser.parseExcelFile(invalidFile, columnMapping, rowMapper)
        );
    }

    private MultipartFile createTestExcelFile() throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Test");

        // Header row
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Institution Name");
        headerRow.createCell(1).setCellValue("Country");
        headerRow.createCell(2).setCellValue("City");
        headerRow.createCell(3).setCellValue("State/County/Region");

        // Data rows
        Row dataRow1 = sheet.createRow(1);
        dataRow1.createCell(0).setCellValue("Harvard University");
        dataRow1.createCell(1).setCellValue("USA");
        dataRow1.createCell(2).setCellValue("Cambridge");
        dataRow1.createCell(3).setCellValue("MA");

        Row dataRow2 = sheet.createRow(2);
        dataRow2.createCell(0).setCellValue("MIT");
        dataRow2.createCell(1).setCellValue("USA");
        dataRow2.createCell(2).setCellValue("Cambridge");
        dataRow2.createCell(3).setCellValue("MA");

        return convertWorkbookToMultipartFile(workbook);
    }

    private MultipartFile createExcelFileWithEmptyRows() throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Test");

        // Header row
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Institution Name");
        headerRow.createCell(1).setCellValue("Country");

        // Data row 1
        Row dataRow1 = sheet.createRow(1);
        dataRow1.createCell(0).setCellValue("Harvard University");
        dataRow1.createCell(1).setCellValue("USA");

        // Empty row 2
        sheet.createRow(2);

        // Data row 3
        Row dataRow3 = sheet.createRow(3);
        dataRow3.createCell(0).setCellValue("MIT");
        dataRow3.createCell(1).setCellValue("USA");

        return convertWorkbookToMultipartFile(workbook);
    }

    private MultipartFile createExcelFileWithOnlyHeader() throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Test");

        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Institution Name");
        headerRow.createCell(1).setCellValue("Country");

        return convertWorkbookToMultipartFile(workbook);
    }

    private MultipartFile createExcelFileWithMultipleSheets() throws IOException {
        Workbook workbook = new XSSFWorkbook();
        
        // First sheet
        Sheet sheet1 = workbook.createSheet("Sheet1");
        Row headerRow1 = sheet1.createRow(0);
        headerRow1.createCell(0).setCellValue("Institution Name");
        headerRow1.createCell(1).setCellValue("Country");
        
        Row dataRow1 = sheet1.createRow(1);
        dataRow1.createCell(0).setCellValue("Harvard University");
        dataRow1.createCell(1).setCellValue("USA");

        // Second sheet
        Sheet sheet2 = workbook.createSheet("Sheet2");
        Row headerRow2 = sheet2.createRow(0);
        headerRow2.createCell(0).setCellValue("Institution Name");
        headerRow2.createCell(1).setCellValue("Country");
        
        Row dataRow2 = sheet2.createRow(1);
        dataRow2.createCell(0).setCellValue("Stanford University");
        dataRow2.createCell(1).setCellValue("USA");

        return convertWorkbookToMultipartFile(workbook);
    }

    private MultipartFile createLargeExcelFile(int rowCount) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Test");

        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Institution Name");
        headerRow.createCell(1).setCellValue("Country");

        for (int i = 0; i < rowCount; i++) {
            Row dataRow = sheet.createRow(i + 1);
            dataRow.createCell(0).setCellValue("University " + i);
            dataRow.createCell(1).setCellValue("USA");
        }

        return convertWorkbookToMultipartFile(workbook);
    }

    private MultipartFile createExcelFileWithPartialColumns() throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Test");

        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Institution Name");
        headerRow.createCell(1).setCellValue("Country");

        Row dataRow = sheet.createRow(1);
        dataRow.createCell(0).setCellValue("Harvard University");
        dataRow.createCell(1).setCellValue("USA");

        return convertWorkbookToMultipartFile(workbook);
    }

    private MultipartFile convertWorkbookToMultipartFile(Workbook workbook) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            workbook.write(bos);
            byte[] bytes = bos.toByteArray();
            return new MockMultipartFile(
                    "file",
                    "test.xlsx",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    bytes
            );
        } finally {
            workbook.close();
            bos.close();
        }
    }
}

