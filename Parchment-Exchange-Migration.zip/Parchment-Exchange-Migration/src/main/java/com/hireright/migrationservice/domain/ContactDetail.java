package com.hireright.migrationservice.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ContactDetail {
    private String followUpAllowed;
    private String type;
    private Integer priority;
    private String version;
    private String turnAroundTime;
    private String surChargeAmount;
    private String name;
    private String paymentMethod;
    private String turnAroundTimeUnit;
    private String surChargeCurrency;
    private List<Communication> communication;
    private String fromYear;
    private String toYear;
    private String followUpAllowedAfter;
    private String recipient;
}

