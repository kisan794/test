/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.Data;
/**
 * Position History DTO for employment position history information
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PositionHistory {

	private String title;

	private String startDate;

	private String endDate;

	private String mostRecentHireDate;

	private String employeeStatusCode;

	private String employeeStatus;

	private String spokeWith;

	private String reasonForLeaving;
}
