package com.hireright.sourceintelligence.service.impl.elasticsearch;

import com.hireright.sourceintelligence.api.dto.Alias;
import com.hireright.sourceintelligence.domain.entity.CityAliasMapping;
import com.hireright.sourceintelligence.domain.repository.CityAliasRepository;
import com.hireright.sourceintelligence.searchindex.entity.ElasticsearchSource;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.util.Helper;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import java.util.*;

import static com.hireright.sourceintelligence.domain.constants.Constants.SmartSearchKeys.*;
import static com.hireright.sourceintelligence.domain.mapper.SourceMapper.mapToJSONObject;
import static com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchConstants.SearchFields.ALL;
import static com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchConstants.SearchFields.AUTOMATED_SERVICE;
import static com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchConstants.SearchFields.CODE;

@AllArgsConstructor
@Component
public class ElasticsearchMapper {

    private CityAliasRepository cityAliasRepository;

    public ElasticsearchSource sourceToSearchSourceMapping(Source source) {
        ElasticsearchSource searchSource = new ElasticsearchSource();
        if (ApprovalStatus.APPROVED.equals(source.getApprovalStatus())) {
            mapSourceDetails(source, searchSource);
            mapAddress(source, searchSource);
            mapContactsFromPayload(mapToJSONObject(source.getPayload()), searchSource);
        }
        return searchSource;
    }

    public Map<String, Object> extractAutomatedServiceAndCode(Source source) {
        Map<String, Object> result = new HashMap<>();
        List<String> automatedService = new ArrayList<>();
        List<String> codes = new ArrayList<>();

        if (source.getPayload() == null) {
            result.put(AUTOMATED_SERVICE, automatedService);
            result.put(CODE, codes);
            return result;
        }

        JSONObject payload = mapToJSONObject(source.getPayload());
        if (!payload.has(CONTACTS) || payload.get(CONTACTS) == null) {
            result.put(AUTOMATED_SERVICE, automatedService);
            result.put(CODE, codes);
            return result;
        }

        JSONArray contacts = (JSONArray) payload.get(CONTACTS);
        if (contacts.isEmpty()) {
            result.put(AUTOMATED_SERVICE, automatedService);
            result.put(CODE, codes);
            return result;
        }

        JSONObject firstContact = (JSONObject) contacts.get(0);
        if (!firstContact.has(CONTACT_DETAILS)) {
            result.put(AUTOMATED_SERVICE, automatedService);
            result.put(CODE, codes);
            return result;
        }

        JSONArray contactDetails = (JSONArray) firstContact.get(CONTACT_DETAILS);
        if (contactDetails == null || contactDetails.isEmpty()) {
            result.put(AUTOMATED_SERVICE, automatedService);
            result.put(CODE, codes);
            return result;
        }

        getAutomatedServiceAndCode(contactDetails, automatedService, codes);

        result.put(AUTOMATED_SERVICE, automatedService);
        result.put(CODE, codes);
        return result;
    }

    private static void getAutomatedServiceAndCode(JSONArray contactDetails, List<String> automatedService, List<String> codes) {
        for (Object contactDetail : contactDetails) {
            JSONObject contactDetailJson = (JSONObject) contactDetail;
            if (!contactDetailJson.has(TYPE) || contactDetailJson.isNull(TYPE)) continue;

            String type = (String) contactDetailJson.get(TYPE);
            if (!CONTACT_AUTOMATED_SERVICES.equals(type)) continue;

            if (!contactDetailJson.has(COMMUNICATION) || contactDetailJson.get(COMMUNICATION) == null) continue;

            JSONArray communication = (JSONArray) contactDetailJson.get(COMMUNICATION);
            if (communication.isEmpty()) continue;

            getAutomatedService(automatedService, codes, communication);
        }
    }

    private static void getAutomatedService(List<String> automatedService, List<String> codes, JSONArray communication) {
        for (Object item : communication) {
            JSONObject communicationObj = (JSONObject) item;

            if (communicationObj.has(NAME)) {
                automatedService.add(((String) communicationObj.get(NAME)).trim());
            }

            getAutomatedCodes(codes, communicationObj);
        }
    }

    private static void getAutomatedCodes(List<String> codes, JSONObject communicationObj) {
        if (communicationObj.has(COMMUNICATION_INFO)) {
            JSONArray communicationInfoDetails = (JSONArray) communicationObj.get(COMMUNICATION_INFO);
            if (communicationInfoDetails != null && !communicationInfoDetails.isEmpty()) {
                getAutomatedCode(codes, communicationInfoDetails);
            }
        }
    }

    private static void getAutomatedCode(List<String> codes, JSONArray communicationInfoDetails) {
        for (Object info : communicationInfoDetails) {
            if (!(info instanceof JSONObject communicationInfoJson)) continue;
            if (!communicationInfoJson.has(TYPE)) continue;

            String infoType = (String) communicationInfoJson.get(TYPE);
            if (CODES.equals(infoType)) {
                Object value = !communicationInfoJson.isNull(VALUE) ? communicationInfoJson.get(VALUE) : "";
                if (!value.toString().isEmpty()) {
                    Collections.addAll(codes, ((String) value).trim().toLowerCase().split(";"));
                }
            }
        }
    }


    private void mapContactsFromPayload(JSONObject payload, ElasticsearchSource searchSource) {
        if (!payload.has(CONTACTS) || payload.get(CONTACTS) == null) return;
        var contacts = (JSONArray) payload.get(CONTACTS);
        if (contacts.isEmpty()) return;
        var contactDetails = ((JSONObject) contacts.get(0)).has(CONTACT_DETAILS)
                ? (JSONArray) ((JSONObject) contacts.get(0)).get(CONTACT_DETAILS)
                : new JSONArray();
        if (contactDetails == null || contactDetails.isEmpty()) return;
        for (Object contactDetail : contactDetails) {
            processContactDetail((JSONObject) contactDetail, searchSource);
        }
    }

    private void processContactDetail(JSONObject contactDetailJson, ElasticsearchSource searchSource) {
        if (!contactDetailJson.has(TYPE) || contactDetailJson.isNull(TYPE)) return;
        String key = (String) contactDetailJson.get(TYPE);
        if (!contactDetailJson.has(COMMUNICATION) || contactDetailJson.get(COMMUNICATION) == null) return;
        var communication = (JSONArray) contactDetailJson.get(COMMUNICATION);
        if (communication.isEmpty()) return;
        processCommunication(key, communication, searchSource);
    }

    private void processCommunication(String key, JSONArray communication, ElasticsearchSource searchSource) {
        List<String> automatedService = new ArrayList<>();
        List<String> codes = new ArrayList<>();
        List<String> phoneNumbers = new ArrayList<>();
        List<String> faxNumbers = new ArrayList<>();
        List<String> emailList = new ArrayList<>();
        for (Object item : communication) {
            processCommunicationItem(key, (JSONObject) item, automatedService, phoneNumbers, faxNumbers, emailList, codes);
            updateSearchSource(searchSource, phoneNumbers, faxNumbers, emailList, automatedService, codes);
        }
    }

    private void processCommunicationItem(String key, JSONObject communicationObj,
                                          List<String> automatedService, List<String> phoneNumbers,
                                          List<String> faxNumbers, List<String> emailList, List<String> codes) {
        if (!communicationObj.has(COMMUNICATION_INFO)) return;
        if (key.equals(CONTACT_AUTOMATED_SERVICES) && communicationObj.has(NAME)) {
            automatedService.add(((String) communicationObj.get(NAME)).trim());
        }
        JSONArray communicationInfoDetails = (JSONArray) communicationObj.get(COMMUNICATION_INFO);
        if (communicationInfoDetails == null || communicationInfoDetails.isEmpty()) return;
        String[] components = {"", "", "", ""}; // [countryCode, areaCode, number, extension]
        for (Object info : communicationInfoDetails) {
            processCommunicationInfoElement(key, info, emailList, codes, components);
        }
        buildPhoneOrFaxNumbers(key, components, phoneNumbers, faxNumbers);
    }

    private void processCommunicationInfoElement(String key, Object communicationInfo,
                                                 List<String> emailList, List<String> codes, String[] components) {
        if (!(communicationInfo instanceof JSONObject communicationInfoJson)) return;
        if (!communicationInfoJson.has(TYPE)) return;
        String type = (String) communicationInfoJson.get(TYPE);
        var value = !communicationInfoJson.isNull(VALUE) ? communicationInfoJson.get(VALUE) : "";
        if (key.equals(CONTACT_PHONES) || key.equals(CONTACT_FAXES)) {
            extractPhoneFaxField(type, value, components);
        }
        if (key.equals(CONTACT_EMAILS) && type.equals(ADDRESS)) {
            emailList.add(((String) value).trim().toLowerCase());
        }
        if (key.equals(CONTACT_AUTOMATED_SERVICES) && type.equals(CODES)) {
            Collections.addAll(codes, ((String) value).trim().toLowerCase().split(";"));
        }
    }

    private void extractPhoneFaxField(String type, Object value, String[] components) {
        if (type.equals(AREA_CODE)) components[1] = ((String) value).trim();
        if (type.equals(PHONE_COUNTRY_CODE)) components[0] = ((String) value).trim();
        if (type.equals(PHONE_NUMBER)) components[2] = ((String) value).trim();
        if (type.equals(EXTENSION)) components[3] = ((String) value).trim();
    }

    private void buildPhoneOrFaxNumbers(String key, String[] components,
                                        List<String> phoneNumbers, List<String> faxNumbers) {
        String countryCode = components[0].contains("+") ? components[0] : "+" + components[0];
        String compositeNumber = countryCode + components[1] + components[2];
        if (key.equals(CONTACT_PHONES)) buildPhoneNumberList(compositeNumber, components[3], phoneNumbers);
        if (key.equals(CONTACT_FAXES)) buildFaxNumberList(compositeNumber, components[3], faxNumbers);
    }

    private void buildPhoneNumberList(String phoneNumber, String extension, List<String> phoneNumbers) {
        if (!StringUtils.isEmpty(phoneNumber) && !StringUtils.isEmpty(extension)) {
            phoneNumbers.add(phoneNumber);
            phoneNumbers.add(phoneNumber + ":" + extension);
        } else if (!StringUtils.isEmpty(phoneNumber) && StringUtils.isEmpty(extension)) {
            phoneNumbers.add(phoneNumber);
        }
    }

    private void buildFaxNumberList(String faxNumber, String extension, List<String> faxNumbers) {
        if (!StringUtils.isEmpty(faxNumber) && !StringUtils.isEmpty(extension)) {
            faxNumbers.add(faxNumber);
            faxNumbers.add(faxNumber + ":" + extension);
        } else if (!StringUtils.isEmpty(faxNumber) && StringUtils.isEmpty(extension)) {
            faxNumbers.add(faxNumber);
        } else {
            faxNumbers.add(faxNumber);
        }
    }

    private void updateSearchSource(ElasticsearchSource searchSource, List<String> phoneNumbers,
                                    List<String> faxNumbers, List<String> emailList,
                                    List<String> automatedService, List<String> codes) {
        if (!phoneNumbers.isEmpty()) searchSource.setPhoneNumber(phoneNumbers);
        if (!faxNumbers.isEmpty()) searchSource.setFaxNumber(faxNumbers);
        if (!emailList.isEmpty()) searchSource.setEmail(emailList);
        if (!automatedService.isEmpty()) searchSource.setAutomatedService(automatedService);
        if (!codes.isEmpty()) searchSource.setCode(codes);
    }

    private void mapSourceDetails(Source source, ElasticsearchSource searchSource){
        searchSource.setHon(source.getHon());
        searchSource.setOrganizationName(source.getOrganizationName().trim());
        if(!ObjectUtils.isEmpty(source.getOrganizationAlias())){
            Alias[] aliases = source.getOrganizationAlias();
            List<String> aliasList = new ArrayList<>();
            for (Alias alias : aliases) {
                if (!StringUtils.isEmpty(alias.getName()) && !alias.getName().isBlank()) {
                    aliasList.add(alias.getName().trim());
                }
            }
            searchSource.setOrganizationAlias(aliasList);
        }
        searchSource.setStatus(source.getStatus().getStatus());
        if(source.getApprovalStatus().equals(ApprovalStatus.APPROVED) || source.getApprovalStatus().equals(ApprovalStatus.REJECTED)){
            searchSource.setApprovalStatus(source.getApprovalStatus().getStatus());
        }else{
            searchSource.setApprovalStatus(ApprovalStatus.PENDING_APPROVAL.getStatus());
        }
        JSONObject payload = mapToJSONObject(source.getPayload());
        if (payload.has(DEPARTMENT_NAME) && !StringUtils.isEmpty((String) payload.get(DEPARTMENT_NAME))) {
            searchSource.setDepartment(((String) payload.get(DEPARTMENT_NAME)).trim());
        }
        if (payload.has(WEBSITE) && !StringUtils.isEmpty((String) payload.get(WEBSITE))) {
            searchSource.setWebsite(((String) payload.get(WEBSITE)).trim().toLowerCase());
        }
    }

    private void mapAddress(Source source, ElasticsearchSource searchSource){
        searchSource.setCountry(source.getCountry().trim());
        if(StringUtils.isNotEmpty(source.getState())){
            searchSource.setState(source.getState().trim());
        }
        if(StringUtils.isNotEmpty(source.getCity())){
            searchSource.setCity(getCities(source.getCity(), source.getCountry()));
        }
        if(StringUtils.isNotEmpty(source.getPostalCode())){
            searchSource.setPostalCode(source.getPostalCode().trim().toLowerCase());
        }
        JSONObject payload = mapToJSONObject(source.getPayload());
        if (payload.has(ADDRESS)) {
            JSONArray address = payload.getJSONArray(ADDRESS);
            if(!address.isEmpty()){
                JSONObject addr = (JSONObject) address.get(0);
                if(addr.get(LINE) != null && addr.get(LINE) != ""){
                    searchSource.setAddressLine(((String) addr.get(LINE)).trim());
                }
            }
        }
    }

    private List<String> getCities(String city, String country){
        Set<String> cities = new HashSet<>();
        city = Helper.removeExtraSpaces(city.trim().toLowerCase());
        List<String> splitCities = city.contains("/") ? List.of(city.split("/")) : List.of(city);
        for (String s : splitCities) {
            if(!s.equalsIgnoreCase(ALL)){
                CityAliasMapping cityAliasMapping = cityAliasRepository.findByCountryAndCityOrAliases(country, s.trim());
                if(cityAliasMapping != null){
                    cities.add(cityAliasMapping.getCity().trim().toLowerCase());
                    cities.addAll(cityAliasMapping.getAliases().stream().map(a -> a.trim().toLowerCase()).toList());
                }else{
                    cities.add(s.trim().toLowerCase());
                }
            }
        }
        if(cities.isEmpty()){
            cities.addAll(splitCities.stream()
                    .map(String::trim)
                    .toList());
        }
        if(!cities.contains(city.toLowerCase())){
            cities.add(city);
        }
        return cities.stream().toList();
    }

}
