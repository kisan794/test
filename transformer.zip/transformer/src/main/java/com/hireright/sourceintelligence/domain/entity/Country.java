package com.hireright.sourceintelligence.domain.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Document(collection = "country")
public class Country {

    @Id
    @Field("_id")
    private ObjectId id;

    @Field("COUNTRY_ID")
    private BigDecimal countryId;

    @Field("NAME")
    private String name;

    @Field("COURT_INTL_CHARGE")
    private BigDecimal courtIntlCharge;

    @Field("EDU_INTL_CHARGE")
    private BigDecimal eduIntlCharge;

    @Field("EMPL_INTL_CHARGE")
    private BigDecimal emplIntlCharge;

    @Field("MVR_INTL_CHARGE")
    private BigDecimal mvrIntlCharge;

    @Field("REF_INTL_CHARGE")
    private BigDecimal refIntlCharge;

    @Field("CURRENCY")
    private String currency;

    @Field("DATE_FORMAT")
    private String dateFormat;

    @Field("PHONE_COUNTRY_CODE")
    private String phoneCountryCode;

    @Field("SSN_EQUIVALENT")
    private String ssnEquivalent;

    @Field("STATE_EQUIVALENT")
    private String stateEquivalent;

    @Field("ZIP_EQUIVALENT")
    private String zipEquivalent;

    @Field("COURT_SEARCH_LEVEL")
    private String courtSearchLevel;

    @Field("DOB_REQUIRED")
    private String dobRequired;

    @Field("TIMEZONE")
    private BigDecimal timezone;

    @Field("DOB_INQUIRY")
    private String dobInquiry;

    @Field("NID_INQUIRY")
    private String nidInquiry;

    @Field("NID_REQUIRED")
    private String nidRequired;

    @Field("BIRTH_PLACE_REQUIRED")
    private String birthPlaceRequired;

    @Field("BIRTH_PLACE_SEND_TO_VERIFIER")
    private String birthPlaceSendToVerifier;

    @Field("OBSOLETE")
    private String obsolete;

    @Field("FINANCE_REGION")
    private String financeRegion;

    @Field("SUPPORT_REGION")
    private String supportRegion;

    @Field("table")
    private String table;

    @Field("scn")
    private String scn;

    @Field("op_type")
    private String opType;

    @Field("op_ts")
    private String opTs;

    @Field("current_ts")
    private String currentTs;

    @Field("row_id")
    private String rowId;

    @Field("username")
    private String username;

    @Field("location")
    private String location;
}

