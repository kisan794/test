package org.example.recombointegration.document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.index.Indexed;

import java.time.LocalDateTime;
import java.util.List;

/**
 * MongoDB document for storing form field configuration metadata.
 * This allows dynamic management of dropdown options, checkboxes, and other form field configurations.
 *
 * @author Generated
 * @version 1.0
 */
@Document(collection = "form_field_configs")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FormFieldConfig {

    @Id
    private String id;

    /**
     * Unique identifier for the field (e.g., "impactAreas", "improvementTypes", "implementationComplexity")
     */
    @Indexed(unique = true)
    private String fieldKey;

    /**
     * Display name for the field
     */
    private String fieldLabel;

    /**
     * Description or help text for the field
     */
    private String fieldDescription;

    /**
     * Type of field (DROPDOWN, MULTI_SELECT, RADIO, CHECKBOX)
     */
    private FieldType fieldType;

    /**
     * List of options for the field
     */
    private List<FieldOption> options;

    /**
     * Whether this field is required
     */
    @Builder.Default
    private Boolean required = false;

    /**
     * Display order in the form
     */
    private Integer displayOrder;

    /**
     * Whether this field is active/enabled
     */
    @Builder.Default
    private Boolean active = true;

    /**
     * Section this field belongs to
     */
    private String section;

    /**
     * Created timestamp
     */
    private LocalDateTime createdAt;

    /**
     * Last updated timestamp
     */
    private LocalDateTime updatedAt;

    /**
     * Field option inner class
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FieldOption {
        /**
         * Option value (stored in database)
         */
        private String value;

        /**
         * Option label (displayed to user)
         */
        private String label;

        /**
         * Option description/help text
         */
        private String description;

        /**
         * Display order
         */
        private Integer order;

        /**
         * Whether this option is active
         */
        @Builder.Default
        private Boolean active = true;
    }

    /**
     * Field type enum
     */
    public enum FieldType {
        DROPDOWN,
        MULTI_SELECT,
        RADIO,
        CHECKBOX,
        TEXT,
        TEXTAREA
    }
}

