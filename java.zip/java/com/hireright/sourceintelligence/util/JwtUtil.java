package com.hireright.sourceintelligence.util;


import java.io.ByteArrayOutputStream;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Date;
import java.util.zip.GZIPOutputStream;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hireright.sourceintelligence.api.dto.UserKeyDTO;
import com.hireright.sourceintelligence.api.dto.UserLoginDetailsDTO;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JwtUtil {

    public static String generateToken(UserKeyDTO data) {
        byte[] key = new byte[32];
        SecureRandom secureRandom = new SecureRandom();
        secureRandom.nextBytes(key);
        String SECRET_KEY = Base64.getEncoder().encodeToString(key);
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            String subjectJson = objectMapper.writeValueAsString(data);
            log.info("Json before keeping in Jwt {}", subjectJson);
            String newJwt =  Jwts.builder()
                    .setSubject(subjectJson)  // Set the response data as the subject
                    .setIssuedAt(new Date(System.currentTimeMillis() - 1000)) // Add slight backdate
                    .setNotBefore(new Date(System.currentTimeMillis() - 1000)) // Ensure it's valid immediately
                    .setExpiration(new Date(System.currentTimeMillis() + 3600000)) // Expiry after 1 hour
                    .signWith(SignatureAlgorithm.HS256, SECRET_KEY)  // Use HMAC SHA-256
                    .compact();
            log.info("new Jwt {}", newJwt);
            return newJwt;
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    public static String compressAndEncode(UserLoginDetailsDTO data) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            String jwtToken = objectMapper.writeValueAsString(data);
            ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
            try (GZIPOutputStream gzip = new GZIPOutputStream(byteStream)) {
                gzip.write(jwtToken.getBytes());
            }
            byte[] compressedBytes = byteStream.toByteArray();
            return Base64.getUrlEncoder().encodeToString(compressedBytes); // Safe for URLs
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
