package com.hireright.sourceintelligence.service.extraction;

import com.hireright.sourceintelligence.api.dto.Alias;
import com.hireright.sourceintelligence.api.dto.ParchmentRecord;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.entity.Vendors;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.repository.VendorsRepository;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoException;
import com.mongodb.bulk.BulkWriteResult;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import java.io.IOException;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ParchmentDataExtractionProcessorTest {

    @Mock
    private VendorsRepository vendorsRepository;

    @Mock
    private MongoTemplate mongoTemplate;

    @Mock
    private ElasticsearchService elasticsearchService;

    @Mock
    private BulkOperations bulkOperations;

    @Mock
    private BulkWriteResult bulkWriteResult;

    @InjectMocks
    private ParchmentDataExtractionProcessor processor;

    private Vendors parchmentVendor;

    @BeforeEach
    void setUp() {
        parchmentVendor = createParchmentVendor();
    }

    private Vendors createParchmentVendor() {
        Vendors vendor = new Vendors();
        vendor.setVendor("Parchment Exchange");
        vendor.setProviderId(123);
        vendor.setWebsite("https://www.parchment.com");
        return vendor;
    }

    private ParchmentRecord createParchmentRecord(String name, String city, String state, String country) {
        return ParchmentRecord.builder()
                .institutionName(name)
                .country(country)
                .city(city)
                .stateCountyRegion(state)
                .serviceProvider("Parchment Exchange")
                .surchargeAmount("5.00")
                .paymentMethod("Credit Card")
                .code("HARV001")
                .turnaroundTime("3")
                .followUpAllowed("Yes")
                .build();
    }

    private Source createSource(String hon, String name, String city, String state, String country) {
        Source source = new Source();
        source.setId(new ObjectId());
        source.setHon(hon);
        source.setOrganizationName(name);
        source.setCity(city);
        source.setState(state);
        source.setCountry(country);
        source.setOrganizationType(OrganizationType.EDUCATION);
        source.setPayload(new BasicDBObject());
        return source;
    }

    @Test
    void testGetDataExtractionTypeType() {
        String dataExtractionType = processor.getDataExtractionTypeType();
        assertEquals("parchment", dataExtractionType);
    }

    @Test
    void testProcessRecords_VendorNotFound() {
        List<ParchmentRecord> records = List.of(createParchmentRecord("Harvard", "Cambridge", "MA", "USA"));
        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            processor.processRecords(records);
        });

        assertTrue(exception.getMessage().contains("Vendor 'Parchment Exchange' not found"));
        verify(vendorsRepository).findByVendor("Parchment Exchange");
        verifyNoInteractions(mongoTemplate);
        verifyNoInteractions(elasticsearchService);
    }

    @Test
    void testProcessRecords_EmptyList() {
        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));

        Map<String, Object> result = processor.processRecords(Collections.emptyList());

        assertNotNull(result);
        assertEquals(0, result.get("totalRecords"));
        assertEquals(0, result.get("totalSourcesUpdated"));
        assertEquals(0, result.get("notFoundRecords"));
        assertTrue(((List<?>) result.get("notFoundRecordsData")).isEmpty());
        assertNotNull(result.get("excelMetadata"));

        verify(vendorsRepository).findByVendor("Parchment Exchange");
        verifyNoInteractions(mongoTemplate);
        verifyNoInteractions(elasticsearchService);
    }

    @Test
    void testProcessRecords_NoMatchingInstitutions() {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalRecords"));
        assertEquals(0, result.get("totalSourcesUpdated"));
        assertEquals(1, result.get("notFoundRecords"));
        assertEquals(1, ((List<?>) result.get("notFoundRecordsData")).size());

        verify(vendorsRepository).findByVendor("Parchment Exchange");
        verify(mongoTemplate).find(any(Query.class), eq(Source.class), anyString());
    }

    @Test
    void testProcessRecords_SuccessfulMatch_NewCommunication() throws IOException {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.upsert(any(Query.class), any())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalRecords"));
        assertEquals(1, result.get("totalSourcesUpdated"));
        assertEquals(0, result.get("notFoundRecords"));

        verify(vendorsRepository).findByVendor("Parchment Exchange");
        verify(mongoTemplate).find(any(Query.class), eq(Source.class), anyString());
        verify(mongoTemplate).bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString());
        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testProcessRecords_SuccessfulMatch_ExistingCommunication() throws IOException {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");

        // Add existing Parchment communication
        BasicDBObject payload = new BasicDBObject();
        BasicDBObject contact = new BasicDBObject();
        BasicDBObject contactDetail = new BasicDBObject();
        contactDetail.put("type", "contactAutomatedServices");

        BasicDBObject communication = new BasicDBObject();
        communication.put("name", "Parchment Exchange");
        communication.put("priority", 1);

        contactDetail.put("communication", List.of(communication));
        contact.put("contactDetails", List.of(contactDetail));
        payload.put("contacts", List.of(contact));
        source.setPayload(payload);

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalRecords"));
        assertEquals(0, result.get("totalSourcesUpdated")); // No update because communication exists
        assertEquals(0, result.get("notFoundRecords"));

        verify(vendorsRepository).findByVendor("Parchment Exchange");
        verifyNoInteractions(bulkOperations);
    }

    @Test
    void testProcessRecords_MultipleMatches() throws IOException {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source1 = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");
        Source source2 = createSource("EDU-456", "Harvard University", "Cambridge", "Massachusetts", "USA");

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source1, source2));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.upsert(any(Query.class), any())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(2);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalRecords"));
        assertEquals(2, result.get("totalSourcesUpdated"));
        assertEquals(0, result.get("notFoundRecords"));

        verify(vendorsRepository).findByVendor("Parchment Exchange");
        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testProcessRecords_MatchByAlias() throws IOException {
        ParchmentRecord record = createParchmentRecord("Harvard Univ", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");
        source.setOrganizationAlias(new Alias[]{new Alias("Harvard Univ", "en")});

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.upsert(any(Query.class), any())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalRecords"));
        assertEquals(1, result.get("totalSourcesUpdated"));
        assertEquals(0, result.get("notFoundRecords"));

        verify(vendorsRepository).findByVendor("Parchment Exchange");
        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testProcessRecords_StateCodeResolution() throws IOException {
        ParchmentRecord record = createParchmentRecord("MIT", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-789", "MIT", "Cambridge", "Massachusetts", "USA");

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalRecords"));
        assertEquals(1, result.get("totalSourcesUpdated"));

        verify(vendorsRepository).findByVendor("Parchment Exchange");
        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testProcessRecords_ElasticsearchFailure_RollbackTransaction() throws IOException {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());
        doThrow(new RuntimeException("ES sync failed")).when(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());

        assertThrows(RuntimeException.class, () -> {
            processor.processRecords(List.of(record));
        });

        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testProcessRecords_MongoExceptionRetry() {
        ParchmentRecord record = createParchmentRecord("Harvard", "Cambridge", "MA", "USA");
        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString()))
                .thenThrow(new MongoException("Connection timeout"));

        assertThrows(MongoException.class, () -> {
            processor.processRecords(List.of(record));
        });

        verify(vendorsRepository).findByVendor("Parchment Exchange");
    }

    @Test
    void testProcessRecords_MultipleRecords_MixedResults() throws IOException {
        ParchmentRecord record1 = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        ParchmentRecord record2 = createParchmentRecord("Unknown College", "Boston", "MA", "USA");
        ParchmentRecord record3 = createParchmentRecord("MIT", "Cambridge", "MA", "USA");

        Source source1 = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");
        Source source3 = createSource("EDU-789", "MIT", "Cambridge", "Massachusetts", "USA");

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source1, source3));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(2);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record1, record2, record3));

        assertNotNull(result);
        assertEquals(3, result.get("totalRecords"));
        assertEquals(2, result.get("totalSourcesUpdated"));
        assertEquals(1, result.get("notFoundRecords"));

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> notFoundData = (List<Map<String, Object>>) result.get("notFoundRecordsData");
        assertEquals(1, notFoundData.size());

        verify(vendorsRepository).findByVendor("Parchment Exchange");
        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testProcessRecords_WithNullValues() {
        ParchmentRecord record = ParchmentRecord.builder()
                .institutionName("Test University")
                .country("USA")
                .city("Boston")
                .stateCountyRegion("MA")
                .serviceProvider(null)
                .surchargeAmount(null)
                .paymentMethod(null)
                .code(null)
                .turnaroundTime(null)
                .followUpAllowed(null)
                .build();

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalRecords"));
        assertEquals(0, result.get("totalSourcesUpdated"));
        assertEquals(1, result.get("notFoundRecords"));

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> notFoundData = (List<Map<String, Object>>) result.get("notFoundRecordsData");
        assertNotNull(notFoundData);
        assertEquals(1, notFoundData.size());
    }

    @Test
    void testProcessRecords_CustomServiceProvider() throws IOException {
        ParchmentRecord record = ParchmentRecord.builder()
                .institutionName("Harvard University")
                .country("USA")
                .city("Cambridge")
                .stateCountyRegion("MA")
                .serviceProvider("Custom Provider")
                .surchargeAmount("10.00")
                .paymentMethod("Debit Card")
                .code("CUSTOM001")
                .turnaroundTime("5")
                .followUpAllowed("No")
                .build();

        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalRecords"));
        assertEquals(1, result.get("totalSourcesUpdated"));

        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testProcessRecords_USACountry_WithSurcharge() throws IOException {
        ParchmentRecord record = ParchmentRecord.builder()
                .institutionName("Harvard University")
                .country("USA")
                .city("Cambridge")
                .stateCountyRegion("MA")
                .serviceProvider("Parchment Exchange")
                .surchargeAmount("15.00")
                .paymentMethod("Credit Card")
                .code("HARV001")
                .turnaroundTime("3")
                .followUpAllowed("Yes")
                .build();

        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalSourcesUpdated"));

        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testProcessRecords_NonUSACountry_NoUSD() throws IOException {
        ParchmentRecord record = ParchmentRecord.builder()
                .institutionName("Oxford University")
                .country("United Kingdom")
                .city("Oxford")
                .stateCountyRegion("Oxfordshire")
                .serviceProvider("Parchment Exchange")
                .surchargeAmount("10.00")
                .paymentMethod("Credit Card")
                .code("OX001")
                .turnaroundTime("5")
                .followUpAllowed("Yes")
                .build();

        Source source = createSource("EDU-456", "Oxford University", "Oxford", "Oxfordshire", "United Kingdom");

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalSourcesUpdated"));

        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testProcessRecords_EmptyStateResolution() {
        ParchmentRecord record = ParchmentRecord.builder()
                .institutionName("Harvard University")
                .country("USA")
                .city("Cambridge")
                .stateCountyRegion("")
                .serviceProvider("Parchment Exchange")
                .surchargeAmount("5.00")
                .paymentMethod("Credit Card")
                .code("HARV001")
                .turnaroundTime("3")
                .followUpAllowed("Yes")
                .build();

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalRecords"));
        assertEquals(0, result.get("totalSourcesUpdated"));
        assertEquals(1, result.get("notFoundRecords"));
    }

    @Test
    void testProcessRecords_UnknownStateCode_UsedAsIs() {
        ParchmentRecord record = ParchmentRecord.builder()
                .institutionName("Test University")
                .country("International")
                .city("TestCity")
                .stateCountyRegion("UnknownRegion")
                .serviceProvider("Parchment Exchange")
                .surchargeAmount("5.00")
                .paymentMethod("Credit Card")
                .code("TEST001")
                .turnaroundTime("3")
                .followUpAllowed("Yes")
                .build();

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalRecords"));
        assertEquals(1, result.get("notFoundRecords"));
    }

    @Test
    void testExcelMetadata_CorrectStructure() {
        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));

        Map<String, Object> result = processor.processRecords(Collections.emptyList());

        @SuppressWarnings("unchecked")
        List<Map<String, String>> metadata = (List<Map<String, String>>) result.get("excelMetadata");

        assertNotNull(metadata);
        assertEquals(10, metadata.size());

        // Verify specific metadata entries
        Map<String, String> firstMeta = metadata.get(0);
        assertEquals("Institution Name", firstMeta.get("label"));
        assertEquals("institutionName", firstMeta.get("key"));
    }

    @Test
    void testPayloadStructure_EmptyPayload() throws IOException {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");
        source.setPayload(null); // Null payload

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalSourcesUpdated"));
        assertNotNull(source.getPayload()); // Payload should be created

        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testPayloadStructure_EmptyBasicDBObject() throws IOException {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");

        // Set payload as empty BasicDBObject
        BasicDBObject emptyPayload = new BasicDBObject();
        source.setPayload(emptyPayload);

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalSourcesUpdated"));

        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testContactDetails_ExistingContactsAsList() throws IOException {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");

        BasicDBObject payload = new BasicDBObject();
        List<Object> contactsList = new ArrayList<>();
        BasicDBObject contact = new BasicDBObject();
        contactsList.add(contact);
        payload.put("contacts", contactsList);
        source.setPayload(payload);

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalSourcesUpdated"));

        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testContactDetails_ContactsWithBasicDBObjectInList() throws IOException {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");

        BasicDBObject payload = new BasicDBObject();
        List<Object> contactsList = new ArrayList<>();
        BasicDBObject contactObj = new BasicDBObject();
        contactObj.put("purpose", "");
        contactsList.add(contactObj);
        payload.put("contacts", contactsList);
        source.setPayload(payload);

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalSourcesUpdated"));

        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testContactDetails_ExistingPriorities() throws IOException {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");

        BasicDBObject payload = new BasicDBObject();
        BasicDBObject contact = new BasicDBObject();

        BasicDBObject contactDetail1 = new BasicDBObject();
        contactDetail1.put("type", "otherType");
        contactDetail1.put("priority", 2);

        BasicDBObject contactDetail2 = new BasicDBObject();
        contactDetail2.put("type", "anotherType");
        contactDetail2.put("priority", "3");

        contact.put("contactDetails", List.of(contactDetail1, contactDetail2));
        payload.put("contacts", List.of(contact));
        source.setPayload(payload);

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalSourcesUpdated"));

        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testContactDetails_PrioritiesWithoutExisting() throws IOException {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");

        BasicDBObject payload = new BasicDBObject();
        BasicDBObject contact = new BasicDBObject();

        BasicDBObject contactDetail1 = new BasicDBObject();
        contactDetail1.put("type", "otherType");
        // No priority set

        contact.put("contactDetails", List.of(contactDetail1));
        payload.put("contacts", List.of(contact));
        source.setPayload(payload);

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalSourcesUpdated"));

        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testCommunication_ExistingCommunicationsWithPriorities() throws IOException {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");

        BasicDBObject payload = new BasicDBObject();
        BasicDBObject contact = new BasicDBObject();
        BasicDBObject contactDetail = new BasicDBObject();
        contactDetail.put("type", "contactAutomatedServices");

        BasicDBObject communication1 = new BasicDBObject();
        communication1.put("name", "OtherProvider");
        communication1.put("priority", 2);

        BasicDBObject communication2 = new BasicDBObject();
        communication2.put("name", "AnotherProvider");
        communication2.put("priority", "3");

        contactDetail.put("communication", List.of(communication1, communication2));
        contact.put("contactDetails", List.of(contactDetail));
        payload.put("contacts", List.of(contact));
        source.setPayload(payload);

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalSourcesUpdated"));

        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testMatchesRecord_NullAlias() {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");
        source.setOrganizationAlias(null);

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("notFoundRecords"));
    }

    @Test
    void testMatchesRecord_AliasWithNullEntry() throws IOException {
        ParchmentRecord record = createParchmentRecord("Harvard", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");
        source.setOrganizationAlias(new Alias[]{null, new Alias("Harvard", "en")});

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalSourcesUpdated"));

        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testMatchesRecord_NullCityMismatch() {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", null, "Massachusetts", "USA");

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(0, result.get("totalSourcesUpdated"));
        assertEquals(1, result.get("notFoundRecords"));
    }

    @Test
    void testMatchesRecord_NullCountryMismatch() {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", null);

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(0, result.get("totalSourcesUpdated"));
        assertEquals(1, result.get("notFoundRecords"));
    }

    @Test
    void testMatchesRecord_BothNullValuesMatch() {
        ParchmentRecord record = ParchmentRecord.builder()
                .institutionName("Harvard University")
                .country("India")
                .city("Delhi")
                .stateCountyRegion("MA")
                .serviceProvider("Parchment Exchange")
                .build();

        Source source = createSource("EDU-123", "Harvard University", null, "Massachusetts", null);

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("notFoundRecords"));
    }

    @Test
    void testNormalizeFunction_NullValue() {
        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));

        Map<String, Object> result = processor.processRecords(Collections.emptyList());

        assertNotNull(result);
        assertNotNull(result.get("excelMetadata"));
    }

    @Test
    void testBulkUpdate_VerifyQueryParameters() throws IOException {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        processor.processRecords(List.of(record));

        verify(mongoTemplate).bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString());
        verify(bulkOperations).execute();
        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testUpdateSource_VerifyUpdateOperations() throws IOException {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.upsert(any(Query.class), any())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        processor.processRecords(List.of(record));

        verify(bulkOperations).upsert(any(Query.class), any());
        verify(bulkOperations).execute();
    }

    @Test
    void testContactDetailsType_WithDifferentTypes() throws IOException {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");

        BasicDBObject payload = new BasicDBObject();
        BasicDBObject contact = new BasicDBObject();

        BasicDBObject contactDetail1 = new BasicDBObject();
        contactDetail1.put("type", "contactPhysicalAddress");

        BasicDBObject contactDetail2 = new BasicDBObject();
        contactDetail2.put("type", "contactEmail");

        contact.put("contactDetails", List.of(contactDetail1, contactDetail2));
        payload.put("contacts", List.of(contact));
        source.setPayload(payload);

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalSourcesUpdated"));

        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testContactDetailsWithNullCommunication() throws IOException {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");

        BasicDBObject payload = new BasicDBObject();
        BasicDBObject contact = new BasicDBObject();
        BasicDBObject contactDetail = new BasicDBObject();
        contactDetail.put("type", "contactAutomatedServices");
        contactDetail.put("communication", null);

        contact.put("contactDetails", List.of(contactDetail));
        payload.put("contacts", List.of(contact));
        source.setPayload(payload);

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalSourcesUpdated"));

        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testCommunicationWithNullName() throws IOException {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");

        BasicDBObject payload = new BasicDBObject();
        BasicDBObject contact = new BasicDBObject();
        BasicDBObject contactDetail = new BasicDBObject();
        contactDetail.put("type", "contactAutomatedServices");

        BasicDBObject communication = new BasicDBObject();
        communication.put("name", null);

        contactDetail.put("communication", List.of(communication));
        contact.put("contactDetails", List.of(contactDetail));
        payload.put("contacts", List.of(contact));
        source.setPayload(payload);

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalSourcesUpdated"));

        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testNoSourcesUpdated_WhenAllAlreadyHaveCommunication() {
        ParchmentRecord record = createParchmentRecord("Harvard University", "Cambridge", "MA", "USA");
        Source source = createSource("EDU-123", "Harvard University", "Cambridge", "Massachusetts", "USA");

        BasicDBObject payload = new BasicDBObject();
        BasicDBObject contact = new BasicDBObject();
        BasicDBObject contactDetail = new BasicDBObject();
        contactDetail.put("type", "contactAutomatedServices");

        BasicDBObject communication = new BasicDBObject();
        communication.put("name", "Parchment Exchange");

        contactDetail.put("communication", List.of(communication));
        contact.put("contactDetails", List.of(contactDetail));
        payload.put("contacts", List.of(contact));
        source.setPayload(payload);

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(0, result.get("totalSourcesUpdated"));

        verify(vendorsRepository).findByVendor("Parchment Exchange");
        verify(mongoTemplate).find(any(Query.class), eq(Source.class), anyString());
        verifyNoInteractions(bulkOperations);
    }

    @Test
    void testOrEmpty_WithNullValue() throws IOException {
        ParchmentRecord record = ParchmentRecord.builder()
                .institutionName("Test University")
                .country("USA")
                .city("Boston")
                .stateCountyRegion("MA")
                .serviceProvider("Parchment Exchange")
                .surchargeAmount(null)  // Null surcharge amount
                .paymentMethod(null)    // Null payment method
                .code("TEST001")
                .turnaroundTime(null)   // Null turnaround time
                .followUpAllowed(null)  // Null follow-up allowed
                .build();

        Source source = createSource("EDU-123", "Test University", "Boston", "Massachusetts", "USA");

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalSourcesUpdated"));

        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testSurchargeAmount_USACountry_WithNullSurcharge() throws IOException {
        ParchmentRecord record = ParchmentRecord.builder()
                .institutionName("Test University")
                .country("USA")
                .city("Boston")
                .stateCountyRegion("MA")
                .serviceProvider("Parchment Exchange")
                .surchargeAmount(null)  // Null surcharge - should not set USD currency
                .paymentMethod("Credit Card")
                .code("TEST001")
                .turnaroundTime("3")
                .followUpAllowed("Yes")
                .build();

        Source source = createSource("EDU-123", "Test University", "Boston", "Massachusetts", "USA");

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalSourcesUpdated"));

        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testSurchargeAmount_USACountry_WithEmptySurcharge() throws IOException {
        ParchmentRecord record = ParchmentRecord.builder()
                .institutionName("Test University")
                .country("USA")
                .city("Boston")
                .stateCountyRegion("MA")
                .serviceProvider("Parchment Exchange")
                .surchargeAmount("")  // Empty surcharge - should not set USD currency
                .paymentMethod("Credit Card")
                .code("TEST001")
                .turnaroundTime("3")
                .followUpAllowed("Yes")
                .build();

        Source source = createSource("EDU-123", "Test University", "Boston", "Massachusetts", "USA");

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalSourcesUpdated"));

        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }

    @Test
    void testBuildOrgNameCriteria_WithNullInstitutionName() {
        ParchmentRecord record = ParchmentRecord.builder()
                .institutionName(null)  // Null institution name
                .country("USA")
                .city("Boston")
                .stateCountyRegion("MA")
                .serviceProvider("Parchment Exchange")
                .build();

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("notFoundRecords"));

        verify(vendorsRepository).findByVendor("Parchment Exchange");
    }

    @Test
    void testBuildOrgNameCriteria_WithEmptyInstitutionName() {
        ParchmentRecord record = ParchmentRecord.builder()
                .institutionName("")  // Empty institution name
                .country("USA")
                .city("Boston")
                .stateCountyRegion("MA")
                .serviceProvider("Parchment Exchange")
                .build();

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("notFoundRecords"));

        verify(vendorsRepository).findByVendor("Parchment Exchange");
    }

    @Test
    void testEqualsIgnoreCase_BothNull() {
        // Testing equalsIgnoreCase with both null values
        ParchmentRecord record = ParchmentRecord.builder()
                .institutionName("Test University")
                .country("India")
                .city("Delhi")
                .stateCountyRegion("MA")
                .serviceProvider("Parchment Exchange")
                .build();

        Source source = createSource("EDU-123", "Test University", null, "Massachusetts", null);

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("notFoundRecords"));
    }

    @Test
    void testEqualsIgnoreCase_OneNullOneNotNull() {
        // Testing equalsIgnoreCase with one null and one non-null
        ParchmentRecord record = createParchmentRecord("Test University", "Boston", "MA", "USA");
        Source source = createSource("EDU-123", "Test University", null, "Massachusetts", "USA");

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(0, result.get("totalSourcesUpdated"));
        assertEquals(1, result.get("notFoundRecords"));
    }

    @Test
    void testNormalize_WithNullValue() {
        // Testing normalize function with null values
        ParchmentRecord record = ParchmentRecord.builder()
                .institutionName(null)
                .country("India")
                .city("Delhi")
                .stateCountyRegion("MA")
                .serviceProvider("Parchment Exchange")
                .build();

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("notFoundRecords"));
    }

    @Test
    void testResolveStateName_EmptyStateInput_WithEmptyStateFullName() {
        // Testing resolveStateName when both stateFullName.isEmpty() && !stateInput.isEmpty() is false
        ParchmentRecord record = ParchmentRecord.builder()
                .institutionName("Test University")
                .country("USA")
                .city("Boston")
                .stateCountyRegion("")  // Empty state
                .serviceProvider("Parchment Exchange")
                .build();

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("notFoundRecords"));
    }

    @Test
    void testResolveStateName_WithValidStateMapping() throws IOException {
        // Testing resolveStateName when StateMapper returns a valid full name
        ParchmentRecord record = createParchmentRecord("Test University", "Boston", "MA", "USA");
        Source source = createSource("EDU-123", "Test University", "Boston", "Massachusetts", "USA");

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalSourcesUpdated"));
    }

    @Test
    void testFindMatchingInstitutions_WithNullOrEmptyState() {
        // Testing when stateFullName is null or empty - should skip the record
        ParchmentRecord record = ParchmentRecord.builder()
                .institutionName("Test University")
                .country("USA")
                .city("Boston")
                .stateCountyRegion("AL")  // Null state
                .serviceProvider("Parchment Exchange")
                .build();

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("notFoundRecords"));
    }

    @Test
    void testPerformBulkSaveMongoDB_EmptySources() throws IOException {
        // Testing performBulkSaveMongoDB when sources list is empty - should skip bulk update
        ParchmentRecord record = createParchmentRecord("Test University", "Boston", "MA", "USA");
        Source source = createSource("EDU-123", "Test University", "Boston", "Massachusetts", "USA");

        // Setup existing Parchment communication so no update happens
        BasicDBObject payload = new BasicDBObject();
        BasicDBObject contact = new BasicDBObject();
        BasicDBObject contactDetail = new BasicDBObject();
        contactDetail.put("type", "contactAutomatedServices");

        BasicDBObject communication = new BasicDBObject();
        communication.put("name", "Parchment Exchange");

        contactDetail.put("communication", List.of(communication));
        contact.put("contactDetails", List.of(contactDetail));
        payload.put("contacts", List.of(contact));
        source.setPayload(payload);

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(0, result.get("totalSourcesUpdated"));

        // Should not call bulkOps since sources list is empty
        verify(mongoTemplate, never()).bulkOps(any(), anyString());
    }

    @Test
    void testUpdateElasticsearchWithRollback_EmptySources() {
        // Testing updateElasticsearchWithRollback when sources list is empty
        ParchmentRecord record = createParchmentRecord("Test University", "Boston", "MA", "USA");
        Source source = createSource("EDU-123", "Test University", "Boston", "Massachusetts", "USA");

        // Setup existing Parchment communication so no update happens
        BasicDBObject payload = new BasicDBObject();
        BasicDBObject contact = new BasicDBObject();
        BasicDBObject contactDetail = new BasicDBObject();
        contactDetail.put("type", "contactAutomatedServices");

        BasicDBObject communication = new BasicDBObject();
        communication.put("name", "Parchment Exchange");

        contactDetail.put("communication", List.of(communication));
        contact.put("contactDetails", List.of(contactDetail));
        payload.put("contacts", List.of(contact));
        source.setPayload(payload);

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(0, result.get("totalSourcesUpdated"));

        // Should not call elasticsearchService since sources list is empty
        verifyNoInteractions(elasticsearchService);
    }

    @Test
    void testServiceProvider_EmptyString() throws IOException {
        // Testing when serviceProvider is empty string - should use PARCHMENT_EXCHANGE as default
        ParchmentRecord record = ParchmentRecord.builder()
                .institutionName("Test University")
                .country("USA")
                .city("Boston")
                .stateCountyRegion("MA")
                .serviceProvider("")  // Empty service provider
                .surchargeAmount("5.00")
                .paymentMethod("Credit Card")
                .code("TEST001")
                .turnaroundTime("3")
                .followUpAllowed("Yes")
                .build();

        Source source = createSource("EDU-123", "Test University", "Boston", "Massachusetts", "USA");

        when(vendorsRepository.findByVendor("Parchment Exchange")).thenReturn(Optional.of(parchmentVendor));
        when(mongoTemplate.find(any(Query.class), eq(Source.class), anyString())).thenReturn(List.of(source));
        when(mongoTemplate.bulkOps(eq(BulkOperations.BulkMode.UNORDERED), anyString())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.getModifiedCount()).thenReturn(1);
        when(bulkWriteResult.getUpserts()).thenReturn(Collections.emptyList());

        Map<String, Object> result = processor.processRecords(List.of(record));

        assertNotNull(result);
        assertEquals(1, result.get("totalSourcesUpdated"));

        verify(elasticsearchService).bulkUpdateAutomatedService(anyString(), anyList());
    }
}