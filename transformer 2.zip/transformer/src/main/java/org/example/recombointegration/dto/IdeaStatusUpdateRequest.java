package org.example.recombointegration.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.example.recombointegration.document.IdeaSubmission.IdeaStatus;

/**
 * Request DTO for updating the status of an idea submission.
 *
 * @author Generated
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request object for updating idea status")
public class IdeaStatusUpdateRequest {

    @NotNull(message = "Status is required")
    @Schema(description = "New status for the idea", 
            example = "UNDER_REVIEW",
            allowableValues = {"SUBMITTED", "UNDER_REVIEW", "APPROVED", "IMPLEMENTED", "COMPLETED", "REJECTED", "ON_HOLD"},
            required = true)
    @JsonProperty("status")
    private IdeaStatus status;

    @Schema(description = "Name of the reviewer", example = "Jane Smith")
    @JsonProperty("reviewedBy")
    private String reviewedBy;

    @Schema(description = "Review comments", example = "Approved for implementation in Q2")
    @JsonProperty("reviewComments")
    private String reviewComments;
}

