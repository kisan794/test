package org.example.recombointegration.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.recombointegration.document.FormTemplate;
import org.example.recombointegration.document.FormTemplate.*;
import org.example.recombointegration.repository.FormTemplateRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Service for managing dynamic form configurations.
 * Builds and retrieves complete form structures for UI rendering.
 *
 * @author Generated
 * @version 1.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DynamicFormService {

    private final FormTemplateRepository formTemplateRepository;

    /**
     * Get form configuration by formId.
     */
    public FormTemplate getFormConfiguration(String formId) {
        log.info("Fetching form configuration for formId: {}", formId);
        return formTemplateRepository.findByFormId(formId)
                .orElseThrow(() -> new RuntimeException("Form configuration not found for formId: " + formId));
    }

    /**
     * Get all active form configurations.
     */
    public List<FormTemplate> getAllActiveFormConfigurations() {
        log.info("Fetching all active form configurations");
        return formTemplateRepository.findByActiveTrue();
    }

    /**
     * Create or update form configuration.
     */
    public FormTemplate saveFormConfiguration(FormTemplate formTemplate) {
        log.info("Saving form configuration: {}", formTemplate.getFormId());

        if (formTemplate.getId() == null) {
            formTemplate.setCreatedAt(LocalDateTime.now());
        }
        formTemplate.setUpdatedAt(LocalDateTime.now());

        return formTemplateRepository.save(formTemplate);
    }

    /**
     * Initialize default Idea Submission form configuration.
     */
    public FormTemplate initializeIdeaSubmissionForm() {
        log.info("Initializing Idea Submission form configuration");

        FormTemplate formTemplate = FormTemplate.builder()
                .formId("idea-submission-form")
                .formTitle("Idea Submission Form")
                .formDescription("Submit your innovative ideas for continuous improvement")
                .version("1.0")
                .active(true)
                .formSettings(buildFormSettings())
                .sections(Arrays.asList(
                        buildBasicInformationSection(),
                        buildIdeaDetailsSection(),
                        buildAreaOfImpactSection(),
                        buildTypeOfImprovementSection(),
                        buildExpectedImpactSection(),
                        buildImplementationDetailsSection(),
                        buildSupportingInformationSection()
                ))
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        return formTemplateRepository.save(formTemplate);
    }

    /**
     * Build form settings.
     */
    private FormSettings buildFormSettings() {
        Map<String, Object> customSettings = new HashMap<>();
        customSettings.put("theme", "default");
        customSettings.put("layout", "vertical");
        customSettings.put("showSectionNumbers", true);

        return FormSettings.builder()
                .allowDraft(true)
                .showProgressBar(true)
                .enableAutoSave(true)
                .autoSaveInterval(30)
                .submitButtonText("Submit Idea")
                .draftButtonText("Save Draft")
                .successMessage("Your idea has been submitted successfully!")
                .errorMessage("There was an error submitting your idea. Please try again.")
                .enableEmailCapture(true)
                .emailFieldLabel("Email Address")
                .emailRequired(false)
                .customSettings(customSettings)
                .build();
    }

    /**
     * Build Section 1: Basic Information.
     */
    private FormSection buildBasicInformationSection() {
        return FormSection.builder()
                .sectionId("section-1")
                .sectionTitle("Section 1: Basic Information")
                .sectionDescription("Provide basic details about yourself and your idea")
                .displayOrder(1)
                .collapsible(false)
                .defaultExpanded(true)
                .fields(Arrays.asList(
                        FormField.builder()
                                .fieldId("title")
                                .fieldKey("title")
                                .label("1. Title of Idea")
                                .fieldType("text")
                                .placeholder("Enter a concise title for your idea")
                                .helpText("Provide a concise and clear summary of your idea.")
                                .required(true)
                                .displayOrder(1)
                                .maxLength(100)
                                .validation(Map.of(
                                        "maxLength", 100,
                                        "minLength", 5,
                                        "pattern", "^[a-zA-Z0-9\\s\\-_.,!?]+$"
                                ))
                                .build(),

                        FormField.builder()
                                .fieldId("submittedBy")
                                .fieldKey("submittedBy")
                                .label("2. Submitted By")
                                .fieldType("text")
                                .placeholder("Enter your name")
                                .helpText("Specify your name and department so the idea can be tracked.")
                                .required(true)
                                .displayOrder(2)
                                .maxLength(100)
                                .build(),

                        FormField.builder()
                                .fieldId("department")
                                .fieldKey("department")
                                .label("Department/Function")
                                .fieldType("text")
                                .placeholder("Enter your department or function")
                                .helpText("Specify your department or functional area")
                                .required(false)
                                .displayOrder(3)
                                .maxLength(100)
                                .build(),

                        FormField.builder()
                                .fieldId("submissionDate")
                                .fieldKey("submissionDate")
                                .label("3. Date of Submission")
                                .fieldType("date")
                                .required(false)
                                .displayOrder(4)
                                .defaultValue("auto-current-date")
                                .attributes(Map.of("readonly", true, "autoFill", true))
                                .helpText("Auto-filled with current date")
                                .build()
                ))
                .build();
    }


    /**
     * Build Section 2: Idea Details.
     */
    private FormSection buildIdeaDetailsSection() {
        return FormSection.builder()
                .sectionId("section-2")
                .sectionTitle("Section 2: Idea Details")
                .sectionDescription("Explain your idea in detail")
                .displayOrder(2)
                .collapsible(true)
                .defaultExpanded(true)
                .fields(Arrays.asList(
                        FormField.builder()
                                .fieldId("description")
                                .fieldKey("description")
                                .label("4. Description of Idea")
                                .fieldType("textarea")
                                .placeholder("Describe your idea in detail...")
                                .helpText("Explain the problem you see and how your idea addresses it. Include examples if possible.")
                                .required(true)
                                .displayOrder(1)
                                .maxLength(2000)
                                .attributes(Map.of("rows", 6))
                                .build(),

                        FormField.builder()
                                .fieldId("objective")
                                .fieldKey("objective")
                                .label("5. Objective / Goal")
                                .fieldType("textarea")
                                .placeholder("What is the main goal of this idea?")
                                .helpText("Describe the main goal of this idea. Examples: improve efficiency, reduce errors, enhance customer satisfaction, increase employee engagement.")
                                .required(true)
                                .displayOrder(2)
                                .maxLength(1000)
                                .attributes(Map.of("rows", 4))
                                .build()
                ))
                .build();
    }

    /**
     * Build Section 3: Area of Impact.
     */
    private FormSection buildAreaOfImpactSection() {
        return FormSection.builder()
                .sectionId("section-3")
                .sectionTitle("Section 3: Area of Impact")
                .sectionDescription("Select the areas this idea will impact")
                .displayOrder(3)
                .collapsible(true)
                .defaultExpanded(true)
                .fields(Arrays.asList(
                        FormField.builder()
                                .fieldId("impactAreas")
                                .fieldKey("impactAreas")
                                .label("6. Which area does this idea impact? (Select all that apply)")
                                .fieldType("checkbox")
                                .required(true)
                                .displayOrder(1)
                                .multiSelect(true)
                                .options(Arrays.asList(
                                        FieldOption.builder()
                                                .value("PROCESS")
                                                .label("Process")
                                                .description("Streamlining workflows, automation, reducing errors")
                                                .build(),
                                        FieldOption.builder()
                                                .value("PEOPLE")
                                                .label("People")
                                                .description("Training, morale, collaboration, safety")
                                                .build(),
                                        FieldOption.builder()
                                                .value("QUALITY")
                                                .label("Quality")
                                                .description("Product/service quality, customer experience, compliance")
                                                .build()
                                ))
                                .build()
                ))
                .build();
    }

    /**
     * Build Section 4: Type of Improvement.
     */
    private FormSection buildTypeOfImprovementSection() {
        return FormSection.builder()
                .sectionId("section-4")
                .sectionTitle("Section 4: Type of Improvement")
                .sectionDescription("Categorize your improvement idea")
                .displayOrder(4)
                .collapsible(true)
                .defaultExpanded(true)
                .fields(Arrays.asList(
                        FormField.builder()
                                .fieldId("improvementTypes")
                                .fieldKey("improvementTypes")
                                .label("7. Type of Improvement (Select one or more)")
                                .fieldType("checkbox")
                                .required(true)
                                .displayOrder(1)
                                .multiSelect(true)
                                .allowOther(true)
                                .otherFieldKey("improvementTypeOther")
                                .options(Arrays.asList(
                                        FieldOption.builder()
                                                .value("INCREMENTAL")
                                                .label("Incremental")
                                                .description("Small improvements to existing systems")
                                                .build(),
                                        FieldOption.builder()
                                                .value("INNOVATIVE")
                                                .label("Innovative")
                                                .description("Completely new ways of doing things")
                                                .build(),
                                        FieldOption.builder()
                                                .value("COST_SAVING")
                                                .label("Cost Saving / Efficiency")
                                                .description("Reduces resources or time")
                                                .build(),
                                        FieldOption.builder()
                                                .value("QUALITY_ENHANCEMENT")
                                                .label("Quality Enhancement")
                                                .description("Improves product/service quality or compliance")
                                                .build(),
                                        FieldOption.builder()
                                                .value("OTHER")
                                                .label("Other (please specify)")
                                                .build()
                                ))
                                .build(),

                        FormField.builder()
                                .fieldId("improvementTypeOther")
                                .fieldKey("improvementTypeOther")
                                .label("Please specify other improvement type")
                                .fieldType("text")
                                .placeholder("Specify other improvement type")
                                .required(false)
                                .displayOrder(2)
                                .maxLength(200)
                                .dependsOn(Arrays.asList("improvementTypes"))
                                .conditionalLogic(Map.of(
                                        "field", "improvementTypes",
                                        "operator", "contains",
                                        "value", "OTHER"
                                ))
                                .build()
                ))
                .build();
    }


    /**
     * Build Section 5: Expected Impact.
     */
    private FormSection buildExpectedImpactSection() {
        return FormSection.builder()
                .sectionId("section-5")
                .sectionTitle("Section 5: Expected Impact")
                .sectionDescription("Describe the expected benefits and impact")
                .displayOrder(5)
                .collapsible(true)
                .defaultExpanded(true)
                .fields(Arrays.asList(
                        FormField.builder()
                                .fieldId("expectedBenefit")
                                .fieldKey("expectedBenefit")
                                .label("8. Expected Benefit / Impact")
                                .fieldType("textarea")
                                .placeholder("Describe the expected benefits...")
                                .helpText("Quantify the improvement wherever possible. Example: Reduce processing time by 30%, decrease errors by 20%, improve customer satisfaction scores by 10%.")
                                .required(true)
                                .displayOrder(1)
                                .maxLength(1500)
                                .attributes(Map.of("rows", 5))
                                .build(),

                        FormField.builder()
                                .fieldId("impactCategories")
                                .fieldKey("impactCategories")
                                .label("9. Impact Areas (Select all that apply)")
                                .fieldType("checkbox")
                                .required(true)
                                .displayOrder(2)
                                .multiSelect(true)
                                .allowOther(true)
                                .otherFieldKey("impactCategoryOther")
                                .options(Arrays.asList(
                                        FieldOption.builder()
                                                .value("TIME_EFFICIENCY")
                                                .label("Time efficiency")
                                                .build(),
                                        FieldOption.builder()
                                                .value("COST_SAVINGS")
                                                .label("Cost savings")
                                                .build(),
                                        FieldOption.builder()
                                                .value("EMPLOYEE_ENGAGEMENT")
                                                .label("Employee engagement")
                                                .build(),
                                        FieldOption.builder()
                                                .value("CUSTOMER_SATISFACTION")
                                                .label("Customer satisfaction")
                                                .build(),
                                        FieldOption.builder()
                                                .value("COMPLIANCE_RISK")
                                                .label("Compliance / Risk reduction")
                                                .build(),
                                        FieldOption.builder()
                                                .value("OTHER")
                                                .label("Other (please specify)")
                                                .build()
                                ))
                                .build(),

                        FormField.builder()
                                .fieldId("impactCategoryOther")
                                .fieldKey("impactCategoryOther")
                                .label("Please specify other impact area")
                                .fieldType("text")
                                .placeholder("Specify other impact area")
                                .required(false)
                                .displayOrder(3)
                                .maxLength(200)
                                .dependsOn(Arrays.asList("impactCategories"))
                                .conditionalLogic(Map.of(
                                        "field", "impactCategories",
                                        "operator", "contains",
                                        "value", "OTHER"
                                ))
                                .build()
                ))
                .build();
    }

    /**
     * Build Section 6: Implementation Details.
     */
    private FormSection buildImplementationDetailsSection() {
        return FormSection.builder()
                .sectionId("section-6")
                .sectionTitle("Section 6: Implementation Details")
                .sectionDescription("Provide details about implementation")
                .displayOrder(6)
                .collapsible(true)
                .defaultExpanded(true)
                .fields(Arrays.asList(
                        FormField.builder()
                                .fieldId("implementationComplexity")
                                .fieldKey("implementationComplexity")
                                .label("10. Implementation Complexity")
                                .fieldType("dropdown")
                                .required(true)
                                .displayOrder(1)
                                .options(Arrays.asList(
                                        FieldOption.builder()
                                                .value("LOW")
                                                .label("Low")
                                                .description("Quick win, minimal resources needed")
                                                .build(),
                                        FieldOption.builder()
                                                .value("MEDIUM")
                                                .label("Medium")
                                                .description("Requires planning, moderate resources")
                                                .build(),
                                        FieldOption.builder()
                                                .value("HIGH")
                                                .label("High")
                                                .description("Significant changes or investment needed")
                                                .build()
                                ))
                                .build(),

                        FormField.builder()
                                .fieldId("suggestedSteps")
                                .fieldKey("suggestedSteps")
                                .label("11. Suggested Steps / Actions")
                                .fieldType("textarea")
                                .placeholder("Outline the implementation steps...")
                                .helpText("Provide a high-level roadmap for implementation. Include dependencies or resources required.")
                                .required(false)
                                .displayOrder(2)
                                .maxLength(2000)
                                .attributes(Map.of("rows", 6))
                                .build(),

                        FormField.builder()
                                .fieldId("timelineType")
                                .fieldKey("timelineType")
                                .label("12. Short-term or Long-term Idea?")
                                .fieldType("dropdown")
                                .required(true)
                                .displayOrder(3)
                                .options(Arrays.asList(
                                        FieldOption.builder()
                                                .value("SHORT_TERM")
                                                .label("Short-term (Quick Win)")
                                                .build(),
                                        FieldOption.builder()
                                                .value("LONG_TERM")
                                                .label("Long-term (Strategic Impact)")
                                                .build()
                                ))
                                .build()
                ))
                .build();
    }


    /**
     * Build Section 7: Supporting Information.
     */
    private FormSection buildSupportingInformationSection() {
        return FormSection.builder()
                .sectionId("section-7")
                .sectionTitle("Section 7: Supporting Information")
                .sectionDescription("Provide any additional supporting information")
                .displayOrder(7)
                .collapsible(true)
                .defaultExpanded(true)
                .fields(Arrays.asList(
                        FormField.builder()
                                .fieldId("supportingDocuments")
                                .fieldKey("supportingDocuments")
                                .label("13. Supporting Documents / References")
                                .fieldType("file")
                                .helpText("Attach any files, screenshots, flowcharts, or links that help explain your idea.")
                                .required(false)
                                .displayOrder(1)
                                .fileUploadType("multiple")
                                .maxFileSize(10485760) // 10MB in bytes
                                .acceptedFileTypes(Arrays.asList(
                                        "application/pdf",
                                        "image/jpeg",
                                        "image/png",
                                        "application/vnd.ms-excel",
                                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                        "application/msword",
                                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                                ))
                                .attributes(Map.of(
                                        "accept", ".pdf,.jpg,.jpeg,.png,.xls,.xlsx,.doc,.docx",
                                        "multiple", true
                                ))
                                .build(),

                        FormField.builder()
                                .fieldId("additionalComments")
                                .fieldKey("additionalComments")
                                .label("14. Additional Comments / Notes")
                                .fieldType("textarea")
                                .placeholder("Any additional information...")
                                .helpText("Include any extra information, suggestions, or clarifications for reviewers.")
                                .required(false)
                                .displayOrder(2)
                                .maxLength(1000)
                                .attributes(Map.of("rows", 5))
                                .build()
                ))
                .build();
    }
}
