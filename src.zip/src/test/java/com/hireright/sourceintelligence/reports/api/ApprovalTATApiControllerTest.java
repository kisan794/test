package com.hireright.sourceintelligence.reports.api;

import com.hireright.sourceintelligence.reports.dto.ReportResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;
import com.hireright.sourceintelligence.reports.service.ApprovalTATService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ApprovalTATApiControllerTest {

    @Mock
    private ApprovalTATService approvalTATService;

    @InjectMocks
    private ApprovalTATApiController approvalTATApiController;

    private ReportsRequestDTO requestDTO;
    private ReportResponseDTO responseDTO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        requestDTO = new ReportsRequestDTO();

        responseDTO = new ReportResponseDTO();

    }

    @Test
    void testGetApprovalAverageTAT_returnsExpectedResponse() {
        // Arrange
        when(approvalTATService.getApprovalAverageTAT(requestDTO)).thenReturn(responseDTO);

        // Act
        ResponseEntity<ReportResponseDTO> responseEntity =
                approvalTATApiController.getApprovalAverageTAT(requestDTO);

        // Assert
        assertNotNull(responseEntity);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(responseDTO, responseEntity.getBody());
        verify(approvalTATService, times(1)).getApprovalAverageTAT(requestDTO);
    }
}
