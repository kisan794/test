package com.hireright.sourceintelligence.api.dto;

import com.hireright.sourceintelligence.domain.entity.UserCycle;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CycleResult {

    private String status;
    private UserCycle cycle;
}
