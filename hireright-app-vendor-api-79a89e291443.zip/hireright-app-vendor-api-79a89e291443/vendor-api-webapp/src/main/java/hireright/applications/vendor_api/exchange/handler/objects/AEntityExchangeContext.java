/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-08-14	Created
 */
package hireright.applications.vendor_api.exchange.handler.objects;

import java.io.Serializable;

public abstract class AEntityExchangeContext<TransferType extends CEntityExchangeDTO>
{
	private Serializable m_entityID;
	private TransferType m_transferObject;

	/**
	 * Retrieve entity ID for exchange
	 */
	public Serializable getEntityID()
	{
		return m_entityID;
	}

	/**
	 * Set entity ID for exchange
	 */
	public void setEntityID(Serializable entityID)
	{
		this.m_entityID = entityID;
	}

	/**
	 * Retrieve DTO for exchange
	 */
	public TransferType getTransferObject()
	{
		return m_transferObject;
	}

	/**
	 * Set DTO for exchange
	 */
	public void setTransferObject(TransferType transferObject)
	{
		this.m_transferObject = transferObject;
	}
}
