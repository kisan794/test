package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.service.notification.metrics.NotificationMetrics;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * REST API for notification system metrics.
 * Provides insights into notification performance, success/failure rates,
 * and circuit breaker status.
 */
@Slf4j
@RestController
@RequestMapping("/sourceintelligence-service/api/v1/notifications/metrics")
@RequiredArgsConstructor
public class NotificationMetricsApiController {
    
    @Autowired(required = false)
    private NotificationMetrics notificationMetrics;
    
    /**
     * Get overall metrics summary
     * 
     * @return Metrics summary including success/failure rates
     */
    @GetMapping
    public ResponseEntity<Map<String, Object>> getMetricsSummary() {
        log.debug("Retrieving notification metrics summary");
        
        if (notificationMetrics == null) {
            log.warn("NotificationMetrics bean not available");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                    .body(Map.of("error", "Metrics not available"));
        }
        
        try {
            Map<String, Object> summary = notificationMetrics.getMetricsSummary();
            return ResponseEntity.ok(summary);
        } catch (Exception e) {
            log.error("Error retrieving metrics summary", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Failed to retrieve metrics"));
        }
    }
    
    /**
     * Get metrics for a specific notification type
     * 
     * @param notificationType The notification type (EMAIL, SMS, etc.)
     * @return Metrics for the specified type
     */
    @GetMapping("/{notificationType}")
    public ResponseEntity<Map<String, Object>> getMetricsForType(
            @PathVariable String notificationType) {
        
        log.debug("Retrieving metrics for notification type: {}", notificationType);
        
        if (notificationMetrics == null) {
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                    .body(Map.of("error", "Metrics not available"));
        }
        
        try {
            Map<String, Object> typeMetrics = notificationMetrics.getMetricsForType(notificationType);
            
            if (typeMetrics.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(Map.of("error", "No metrics found for type: " + notificationType));
            }
            
            return ResponseEntity.ok(typeMetrics);
        } catch (Exception e) {
            log.error("Error retrieving metrics for type: {}", notificationType, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Failed to retrieve metrics"));
        }
    }
    
    /**
     * Reset all metrics (admin operation)
     * 
     * @return Confirmation message
     */
    @PostMapping("/reset")
    public ResponseEntity<Map<String, String>> resetMetrics() {
        log.info("Resetting notification metrics");
        
        if (notificationMetrics == null) {
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                    .body(Map.of("error", "Metrics not available"));
        }
        
        try {
            notificationMetrics.reset();
            return ResponseEntity.ok(Map.of(
                    "message", "Metrics reset successfully",
                    "status", "success"
            ));
        } catch (Exception e) {
            log.error("Error resetting metrics", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Failed to reset metrics"));
        }
    }
    
    /**
     * Get health status of notification system
     * 
     * @return Health status with key indicators
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> getHealthStatus() {
        log.debug("Retrieving notification system health status");
        
        if (notificationMetrics == null) {
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                    .body(Map.of(
                            "status", "DOWN",
                            "reason", "Metrics not available"
                    ));
        }
        
        try {
            Map<String, Object> summary = notificationMetrics.getMetricsSummary();
            double successRate = notificationMetrics.getSuccessRate();
            long circuitBreakerOpens = (Long) summary.get("totalCircuitBreakerOpen");
            
            // Determine health status
            String status;
            String reason;
            
            if (circuitBreakerOpens > 0 && circuitBreakerOpens > notificationMetrics.getTotalNotifications() * 0.1) {
                status = "DEGRADED";
                reason = "Circuit breaker frequently opening";
            } else if (successRate < 80.0) {
                status = "DEGRADED";
                reason = "Success rate below 80%";
            } else if (successRate < 95.0) {
                status = "WARNING";
                reason = "Success rate below 95%";
            } else {
                status = "UP";
                reason = "All systems operational";
            }
            
            return ResponseEntity.ok(Map.of(
                    "status", status,
                    "reason", reason,
                    "successRate", String.format("%.2f%%", successRate),
                    "totalNotifications", notificationMetrics.getTotalNotifications(),
                    "circuitBreakerOpens", circuitBreakerOpens,
                    "dlqEntries", summary.get("totalDLQEntries")
            ));
            
        } catch (Exception e) {
            log.error("Error retrieving health status", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of(
                            "status", "UNKNOWN",
                            "error", "Failed to determine health status"
                    ));
        }
    }
}

