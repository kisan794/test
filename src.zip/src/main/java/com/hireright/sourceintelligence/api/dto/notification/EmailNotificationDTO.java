package com.hireright.sourceintelligence.api.dto.notification;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Data Transfer Object for email notifications.
 * Follows Single Responsibility Principle - only handles email notification data.
 * Uses validation annotations for declarative validation.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EmailNotificationDTO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * Primary recipients (To field)
     */
    @NotEmpty(message = "At least one recipient is required")
    @Size(max = 100, message = "Maximum 100 recipients allowed")
    private List<@Email(message = "Invalid email format") @NotBlank String> to;
    
    /**
     * Carbon copy recipients (CC field)
     */
    @Size(max = 100, message = "Maximum 100 CC recipients allowed")
    private List<@Email(message = "Invalid email format") String> cc;
    
    /**
     * Blind carbon copy recipients (BCC field)
     */
    @Size(max = 100, message = "Maximum 100 BCC recipients allowed")
    private List<@Email(message = "Invalid email format") String> bcc;
    
    /**
     * Email subject
     */
    @NotBlank(message = "Email subject cannot be blank")
    @Size(max = 200, message = "Subject cannot exceed 200 characters")
    private String subject;
    
    /**
     * Email body content
     */
    @NotBlank(message = "Email body cannot be blank")
    @Size(max = 1048576, message = "Email body cannot exceed 1MB")
    private String body;
    
    /**
     * Whether the body contains HTML content
     */
    @Builder.Default
    private Boolean htmlContent = false;
    
    /**
     * Reply-To email address
     */
    @Email(message = "Invalid reply-to email format")
    private String replyTo;
    
    /**
     * Email attachments
     */
    @Size(max = 10, message = "Maximum 10 attachments allowed")
    @Valid
    private List<AttachmentDTO> attachments;
    
    /**
     * Custom metadata for tracking and categorization
     */
    private Map<String, String> metadata;
    
    /**
     * Email importance (HIGH, NORMAL, LOW)
     */
    private String importance;
}

