package org.example.recombointegration.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Response DTO for idea comment.
 *
 * @author Generated
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Response object containing comment details")
public class IdeaCommentResponse {

    @Schema(description = "Unique identifier of the comment", example = "507f1f77bcf86cd799439011")
    @JsonProperty("id")
    private String id;

    @Schema(description = "Name of the commenter", example = "Jane Smith")
    @JsonProperty("commenterName")
    private String commenterName;

    @Schema(description = "Email of the commenter", example = "jane.smith@company.com")
    @JsonProperty("commenterEmail")
    private String commenterEmail;

    @Schema(description = "The comment text", example = "Great idea!")
    @JsonProperty("comment")
    private String comment;

    @Schema(description = "Timestamp when comment was created", example = "2026-01-16T11:00:00")
    @JsonProperty("createdAt")
    private LocalDateTime createdAt;
}

