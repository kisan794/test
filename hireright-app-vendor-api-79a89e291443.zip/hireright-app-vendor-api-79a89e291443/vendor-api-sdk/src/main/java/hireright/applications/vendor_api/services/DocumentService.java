package hireright.applications.vendor_api.services;
/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	2017-08-16	Created
 *	M.Kuznetsov	2025-10-29	HRG-345322. Openjdk21-migration
 */

import org.springframework.web.bind.annotation.RequestMethod;

import hireright.applications.vendor_api.responses.FileResponse;
import hireright.components.domain.dialects.vendor_api.DocumentBundle;

public class DocumentService {
    public static final String VAR_ORDER_REF = "orderRef";
    public static final String VAR_ORDER_SERVICE_REF = "orderServiceRef";
    public static final String VAR_DOCUMENT_REF = "documentRef";
    public static final String VAR_STORAGE_REF = "storageRef";

    public static final String PATH_GET_CONTENT =
            "/documents/{" + VAR_ORDER_REF + "}/{" + VAR_STORAGE_REF + "}/{" + VAR_DOCUMENT_REF + "}";
    public static final String PATH_GET = "/documents/{" + VAR_ORDER_REF + "}";
    public static final String PATH_SYNC = "/documents/{" + VAR_ORDER_REF + "}/{" + VAR_ORDER_SERVICE_REF + "}/sync";

    public static final String PATH_POST = "/documents/{" + VAR_ORDER_REF + "}";

    public enum EMethod implements IMethod {
        GET_CONTENT(PATH_GET_CONTENT, RequestMethod.GET, String.class, FileResponse.class),
        GET(PATH_GET, RequestMethod.GET, String.class, DocumentBundle.class),
        GET_SYNC(PATH_SYNC, RequestMethod.POST, String.class, String.class);

        private final String path;
        private final RequestMethod requestMethod;
        private final Class<?> requestBodyClass;
        private final Class<?> responseBodyClass;

        EMethod(String sPath,
                RequestMethod requestMethod,
                Class<?> requestBodyClass,
                Class<?> responseBodyClass) {
            this.path = sPath;
            this.requestMethod = requestMethod;
            this.requestBodyClass = requestBodyClass;
            this.responseBodyClass = responseBodyClass;
        }

        public String getPath() {
            return this.path;
        }

        public RequestMethod getRequestMethod() {
            return this.requestMethod;
        }

        public Class<?> getRequestBodyClass() {
            return this.requestBodyClass;
        }

        public Class<?> getResponseBodyClass() {
            return this.responseBodyClass;
        }

        public boolean isValidRequest(Object request) {
            return true;
        }
    }
}
