package com.hireright.sourceintelligence.reports.service.impl;

import com.hireright.sourceintelligence.reports.dto.NestedMetaDTO;

import java.util.ArrayList;
import java.util.List;

public class SourceInformationMetaUtils {

    private SourceInformationMetaUtils() {
    }

    public static List<NestedMetaDTO> getOperatorMetadata() {
        List<NestedMetaDTO> metaList = new ArrayList<>();

        metaList.add(NestedMetaDTO.builder()
                .header("Operator Name")
                .accessorKey("operatorName")
                .build());

        List<NestedMetaDTO> addedColumns = new ArrayList<>();
        addedColumns.add(NestedMetaDTO.builder().header("New").accessorKey("added.newCount").build());
        addedColumns.add(NestedMetaDTO.builder().header("In Progress").accessorKey("added.inProgress").build());
        addedColumns.add(NestedMetaDTO.builder().header("On Hold").accessorKey("added.onHold").build());
        addedColumns.add(NestedMetaDTO.builder().header("Cancelled").accessorKey("added.cancelled").build());
        addedColumns.add(NestedMetaDTO.builder().header("Completed").accessorKey("added.completed").build());
        addedColumns.add(NestedMetaDTO.builder().header("Total").accessorKey("added.total").build());

        metaList.add(NestedMetaDTO.builder()
                .header("Added")
                .accessorKey("added")
                .columns(addedColumns)
                .build());

        List<NestedMetaDTO> changedColumns = new ArrayList<>();
        changedColumns.add(NestedMetaDTO.builder().header("New").accessorKey("changed.newCount").build());
        changedColumns.add(NestedMetaDTO.builder().header("In Progress").accessorKey("changed.inProgress").build());
        changedColumns.add(NestedMetaDTO.builder().header("On Hold").accessorKey("changed.onHold").build());
        changedColumns.add(NestedMetaDTO.builder().header("Cancelled").accessorKey("changed.cancelled").build());
        changedColumns.add(NestedMetaDTO.builder().header("Completed").accessorKey("changed.completed").build());
        changedColumns.add(NestedMetaDTO.builder().header("Total").accessorKey("changed.total").build());

        metaList.add(NestedMetaDTO.builder()
                .header("Changed")
                .accessorKey("changed")
                .columns(changedColumns)
                .build());

        List<NestedMetaDTO> archivedColumns = new ArrayList<>();
        archivedColumns.add(NestedMetaDTO.builder().header("New").accessorKey("archived.newCount").build());
        archivedColumns.add(NestedMetaDTO.builder().header("In Progress").accessorKey("archived.inProgress").build());
        archivedColumns.add(NestedMetaDTO.builder().header("On Hold").accessorKey("archived.onHold").build());
        archivedColumns.add(NestedMetaDTO.builder().header("Cancelled").accessorKey("archived.cancelled").build());
        archivedColumns.add(NestedMetaDTO.builder().header("Completed").accessorKey("archived.completed").build());
        archivedColumns.add(NestedMetaDTO.builder().header("Total").accessorKey("archived.total").build());

        metaList.add(NestedMetaDTO.builder()
                .header("Archived")
                .accessorKey("archived")
                .columns(archivedColumns)
                .build());

        List<NestedMetaDTO> deletedColumns = new ArrayList<>();
        deletedColumns.add(NestedMetaDTO.builder().header("New").accessorKey("deleted.newCount").build());
        deletedColumns.add(NestedMetaDTO.builder().header("In Progress").accessorKey("deleted.inProgress").build());
        deletedColumns.add(NestedMetaDTO.builder().header("On Hold").accessorKey("deleted.onHold").build());
        deletedColumns.add(NestedMetaDTO.builder().header("Cancelled").accessorKey("deleted.cancelled").build());
        deletedColumns.add(NestedMetaDTO.builder().header("Completed").accessorKey("deleted.completed").build());
        deletedColumns.add(NestedMetaDTO.builder().header("Total").accessorKey("deleted.total").build());

        metaList.add(NestedMetaDTO.builder()
                .header("Deleted")
                .accessorKey("deleted")
                .columns(deletedColumns)
                .build());

        metaList.add(NestedMetaDTO.builder()
                .header("Total")
                .accessorKey("total")
                .build());

        return metaList;
    }

}