package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.notification.NotificationRequestDTO;
import com.hireright.sourceintelligence.api.dto.notification.NotificationResponseDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * API interface for notification operations.
 * Defines the contract for notification endpoints.
 */
@Tag(name = "Notifications", description = "Enterprise-grade notification management API")
@RequestMapping("/sourceintelligence-service/api/v1/notifications")
public interface NotificationApi {
    
    /**
     * Sends a notification based on the request type
     *
     * @param request the notification request
     * @return response with notification status
     */
    @Operation(
            summary = "Send Notification",
            description = "Sends a notification via the specified channel (EMAIL, SMS, etc.). " +
                         "Supports synchronous and asynchronous processing with comprehensive error handling, " +
                         "retry mechanisms, and circuit breaker protection."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Notification sent successfully (synchronous)",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = NotificationResponseDTO.class)
                    )
            ),
            @ApiResponse(
                    responseCode = "202",
                    description = "Notification queued for processing (asynchronous)",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = NotificationResponseDTO.class)
                    )
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Invalid request - validation failed",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = NotificationResponseDTO.class)
                    )
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Forbidden - domain blacklisted or not whitelisted",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = NotificationResponseDTO.class)
                    )
            ),
            @ApiResponse(
                    responseCode = "413",
                    description = "Payload too large - attachment or body size exceeded",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = NotificationResponseDTO.class)
                    )
            ),
            @ApiResponse(
                    responseCode = "500",
                    description = "Internal server error - notification failed to send",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = NotificationResponseDTO.class)
                    )
            ),
            @ApiResponse(
                    responseCode = "503",
                    description = "Service unavailable - circuit breaker open",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = NotificationResponseDTO.class)
                    )
            )
    })
    @PostMapping("/send")
    ResponseEntity<NotificationResponseDTO> sendNotification(
            @Valid @RequestBody NotificationRequestDTO request
    );
}

