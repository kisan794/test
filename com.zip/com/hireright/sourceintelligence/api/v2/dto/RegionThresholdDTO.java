package com.hireright.sourceintelligence.api.v2.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RegionThresholdDTO {

//    @JsonProperty("AMERICAS")
//    private int AMERICAS;

    @JsonProperty("EMEA")
    private int EMEA;

    @JsonProperty("LATAM")
    private int LATAM;

    @JsonProperty("CANADA")
    private int CANADA;

    @JsonProperty("APAC")
    private int APAC;

    @JsonProperty("AUSTRALIA")
    private int AUSTRALIA;

    @JsonProperty("INDIA")
    private int INDIA;

    @JsonProperty("US")
    private int US;

    public int getValueByRegion(String region)  {
        switch (region.toUpperCase()) {
            //case "AMERICAS": return AMERICAS;
            case "EMEA": return EMEA;
            case "LATAM": return LATAM;
            case "CANADA": return CANADA;
            case "APAC": return APAC;
            case "AUSTRALIA": return AUSTRALIA;
            case "INDIA": return INDIA;
            case "US": return US;
            default: return 0;
        }
    }
}
