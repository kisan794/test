package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.rds.LanguageDTO;
import com.hireright.sourceintelligence.domain.entity.Language;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

import static org.mapstruct.ReportingPolicy.IGNORE;

@Mapper(componentModel = "spring", unmappedTargetPolicy = IGNORE)
public interface LanguageMapper {

    @Mapping(target = "id", expression = "java(convertObjectIdToString(entity.getId()))")
    @Mapping(target = "name", expression = "java(entity.getLanguageEn())")
    @Mapping(target = "iso6391", expression = "java(entity.getLanguageCode())")
    @Mapping(target = "iso6392t", expression = "java(entity.getLanguageCode())")
    @Mapping(target = "languageTag", expression = "java(null)")
    LanguageDTO entityToDTO(Language entity);

    List<LanguageDTO> entityToDTOList(List<Language> entityList);

    default String convertObjectIdToString(org.bson.types.ObjectId objectId) {
        if (objectId == null) {
            return null;
        }
        return objectId.toHexString();
    }
}

