/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.model.recombointegration.education.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProvidedSource {
    private String id;

    private Context context;

    private Institution institution;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<ReferenceObjects> referenceObjects;

    private List<ProvidedSourceNote> notes;

}

