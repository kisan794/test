package com.hireright.sourceintelligence.reports.api;

import com.hireright.sourceintelligence.api.ApiConstants;
import com.hireright.sourceintelligence.reports.dto.*;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.API_PATH_REPORTS;

@RequestMapping(value = API_PATH_REPORTS)
@Tag(name = "Reports", description = "Endpoints for managing Reports")
public interface ContactUtilizationApi {

    @PostMapping(value = ApiConstants.ApiPath.CONTACT_UTILIZATION, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    ResponseEntity<ReportResponseDTO> getContactUtilization(@RequestBody ReportsRequestDTO reportsRequestDTO);



}
