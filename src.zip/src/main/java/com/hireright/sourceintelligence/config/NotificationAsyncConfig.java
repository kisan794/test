package com.hireright.sourceintelligence.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * Configuration for asynchronous notification processing.
 * Configures thread pool for handling async email notifications.
 */
@Slf4j
@Configuration
@EnableAsync
public class NotificationAsyncConfig {
    
    @Value("${notification.async.corePoolSize:10}")
    private int corePoolSize;
    
    @Value("${notification.async.maxPoolSize:50}")
    private int maxPoolSize;
    
    @Value("${notification.async.queueCapacity:500}")
    private int queueCapacity;
    
    @Value("${notification.async.threadNamePrefix:notification-async-}")
    private String threadNamePrefix;
    
    @Value("${notification.async.keepAliveSeconds:60}")
    private int keepAliveSeconds;
    
    @Value("${notification.async.awaitTerminationSeconds:30}")
    private int awaitTerminationSeconds;
    
    /**
     * Creates the thread pool task executor for async notification processing
     */
    @Bean(name = "notificationTaskExecutor")
    public Executor notificationTaskExecutor() {
        log.info("Configuring notification task executor - core: {}, max: {}, queue: {}", 
                corePoolSize, maxPoolSize, queueCapacity);
        
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(corePoolSize);
        executor.setMaxPoolSize(maxPoolSize);
        executor.setQueueCapacity(queueCapacity);
        executor.setThreadNamePrefix(threadNamePrefix);
        executor.setKeepAliveSeconds(keepAliveSeconds);
        
        // Rejection policy: CallerRunsPolicy allows graceful degradation
        // If the queue is full, the calling thread will execute the task
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        
        // Wait for tasks to complete on shutdown
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(awaitTerminationSeconds);
        
        executor.initialize();
        
        log.info("Notification task executor configured successfully");
        return executor;
    }
}

