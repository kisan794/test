package com.hireright.sourceintelligence.api.dto.optool;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Data
public class EmailDTO {
    private String address;
    private String comment;

    @JsonIgnore
    public boolean isEmpty() {
        return (isBlank(address)) ;
    }

    private boolean isBlank(String str) {
        return str == null || str.isBlank();
    }
}
