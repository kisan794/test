package com.hireright.sourceintelligence.api.dto.optool;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Duration;
import java.time.Instant;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.VERSION;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AutoMatchResponseDTO {
    private boolean success;
    private AutoMatchSourceDTO source;
    private String error;
    private String serverError;
    private boolean fromOptool;
    private long requestTime;
    private String v;
    private long startTime;
    private String requestId;

    public static AutoMatchResponseDTOBuilder baseBuilder(String requestId, Instant requestTime) {
        return AutoMatchResponseDTO.builder()
                .source(null)
                .success(true)
                .v(VERSION)
                .serverError(null)
                .fromOptool(true)
                .requestTime(Duration.between(requestTime, Instant.now()).toMillis())
                .startTime(requestTime.toEpochMilli())
                .requestId(requestId);
    }
}
