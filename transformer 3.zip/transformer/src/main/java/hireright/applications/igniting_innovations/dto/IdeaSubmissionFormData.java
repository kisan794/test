package hireright.applications.igniting_innovations.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
public class IdeaSubmissionFormData {
    // Section 1: Basic Information
    @NotBlank(message = "Title is required")
    @Size(max = 100, message = "Title must not exceed 100 characters")
    @Schema(description = "Title of the idea")
    @JsonProperty("title")
    private String title;

    @NotBlank(message = "Submitted by is required")
    @Schema(description = "Name of the person submitting the idea")
    @JsonProperty("submittedBy")
    private String submittedBy;

    @NotBlank(message = "Department is required")
    @Schema(description = "Department or function of the submitter")
    @JsonProperty("department")
    private String department;

    // Section 2: Idea Details
    @NotBlank(message = "Description is required")
    @Schema(description = "Detailed description of the idea and problem it solves")
    @JsonProperty("description")
    private String description;

    @NotBlank(message = "Objective is required")
    @Schema(description = "Main goal or objective of the idea")
    @JsonProperty("objective")
    private String objective;

    // Section 3: Area of Impact
    @NotNull(message = "Impact areas are required")
    @Schema(description = "Areas impacted by this idea")
    @JsonProperty("impactAreas")
    private List<String> impactAreas;

    // Section 4: Type of Improvement
    @NotNull(message = "Improvement types are required")
    @Schema(description = "Types of improvement this idea provides")
    @JsonProperty("improvementTypes")
    private List<String> improvementTypes;

    @NotBlank(message = "Improvement type other is required")
    @Schema(description = "Other improvement type if 'OTHER' is selected")
    @JsonProperty("improvementTypeOther")
    private String improvementTypeOther;

    // Section 5: Expected Impact
    @NotBlank(message = "Expected benefit is required")
    @Schema(description = "Expected benefits and quantified impact")
    @JsonProperty("expectedBenefit")
    private String expectedBenefit;

    @NotNull(message = "Impact categories are required")
    @Schema(description = "Categories of impact")
    @JsonProperty("impactCategories")
    private List<String> impactCategories;

    @NotBlank(message = "Impact category other is required")
    @Schema(description = "Other impact category if 'OTHER' is selected")
    @JsonProperty("impactCategoryOther")
    private String impactCategoryOther;

    // Section 6: Implementation Details
    @NotBlank(message = "Implementation complexity is required")
    @Schema(description = "Implementation complexity level")
    @JsonProperty("implementationComplexity")
    private String implementationComplexity;

    @NotBlank(message = "Suggested steps are required")
    @Schema(description = "Suggested steps or roadmap for implementation")
    @JsonProperty("suggestedSteps")
    private String suggestedSteps;

    @NotBlank(message = "Timeline type is required")
    @Schema(description = "Timeline type for implementation")
    @JsonProperty("timelineType")
    private String timelineType;

    // Section 7: Supporting Information
    @NotNull(message = "Supporting documents are required")
    @Schema(description = "URLs or file paths to supporting documents")
    @JsonProperty("supportingDocuments")
    private List<String> supportingDocuments;

    @NotBlank(message = "Additional comments are required")
    @Schema(description = "Additional comments or notes")
    @JsonProperty("additionalComments")
    private String additionalComments;
}