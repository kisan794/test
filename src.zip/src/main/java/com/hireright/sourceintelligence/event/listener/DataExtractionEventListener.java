package com.hireright.sourceintelligence.event.listener;

import com.hireright.sourceintelligence.api.dto.notification.DataExtractionNotificationDTO;
import com.hireright.sourceintelligence.event.DataExtractionEvent;
import com.hireright.sourceintelligence.service.notification.DataExtractionNotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;

/**
 * Event listener for DataExtractionEvent
 * Following Observer Pattern - observer that reacts to data extraction events
 * Following Single Responsibility Principle - only handles event listening and notification triggering
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DataExtractionEventListener {
    
    private final DataExtractionNotificationService dataExtractionNotificationService;
    
    @Value("${notification.dataextraction.enabled:false}")
    private boolean notificationEnabled;
    
    @Value("${notification.dataextraction.recipients:}")
    private String defaultRecipients;
    
    @Async("notificationExecutor")
    @EventListener
    public void handleDataExtractionEvent(DataExtractionEvent event) {
        log.info("Received DataExtractionEvent - Type: {}, Filename: {}, Status: {}", 
                event.getDataExtractionType(), event.getFilename(), event.getStatus());
        
        if (!notificationEnabled) {
            log.info("Data extraction notifications are disabled");
            return;
        }
        
        if (!event.isSuccessful()) {
            log.warn("Data extraction was not successful. Skipping notification.");
            return;
        }
        
        List<String> recipients = getRecipients();
        if (CollectionUtils.isEmpty(recipients)) {
            log.warn("No recipients configured for data extraction notifications");
            return;
        }
        
        try {
            DataExtractionNotificationDTO notification = buildNotificationFromEvent(event, recipients);
            dataExtractionNotificationService.sendDataExtractionNotification(notification);
            log.info("Data extraction notification sent successfully");
        } catch (Exception e) {
            log.error("Failed to send data extraction notification: {}", e.getMessage(), e);
        }
    }
    
    private List<String> getRecipients() {
        if (defaultRecipients == null || defaultRecipients.trim().isEmpty()) {
            return List.of();
        }
        return Arrays.stream(defaultRecipients.split(","))
                .map(String::trim)
                .filter(email -> !email.isEmpty())
                .toList();
    }
    
    private DataExtractionNotificationDTO buildNotificationFromEvent(DataExtractionEvent event, List<String> recipients) {
        return DataExtractionNotificationDTO.builder()
                .recipients(recipients)
                .dataExtractionType(event.getDataExtractionType())
                .filename(event.getFilename())
                .totalRecords(event.getTotalRecords())
                .totalSourcesUpdated(event.getTotalSourcesUpdated())
                .notFoundRecords(event.getNotFoundRecords())
                .processingTimeMs(event.getProcessingTimeMs())
                .includeNotFoundRecords(false)
                .build();
    }
}

