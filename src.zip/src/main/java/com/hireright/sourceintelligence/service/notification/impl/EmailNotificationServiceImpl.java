package com.hireright.sourceintelligence.service.notification.impl;

import com.hireright.sourceintelligence.api.dto.notification.EmailNotificationDTO;
import com.hireright.sourceintelligence.service.notification.EmailNotificationService;
import com.hireright.sourceintelligence.service.notification.provider.EmailNotificationProvider;
import com.hireright.sourceintelligence.service.notification.util.EmailSanitizer;
import com.hireright.sourceintelligence.service.notification.validator.AttachmentValidator;
import com.hireright.sourceintelligence.service.notification.validator.EmailValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * Implementation of EmailNotificationService.
 * Follows Single Responsibility Principle - coordinates email sending.
 * Delegates validation to validators and sending to provider.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class EmailNotificationServiceImpl implements EmailNotificationService {
    
    private final EmailValidator emailValidator;
    private final AttachmentValidator attachmentValidator;
    private final EmailNotificationProvider emailProvider;
    private final EmailSanitizer emailSanitizer;
    
    /**
     * Sends an email notification synchronously
     */
    @Override
    public String sendEmail(EmailNotificationDTO emailDTO) {
        String notificationId = generateNotificationId();
        log.info("Sending email notification synchronously - ID: {}", notificationId);
        
        try {
            // Validate email
            validateEmail(emailDTO);
            
            // Send email
            emailProvider.sendEmail(emailDTO);
            
            log.info("Email notification sent successfully - ID: {}", notificationId);
            return notificationId;
            
        } catch (Exception e) {
            log.error("Failed to send email notification - ID: {}", notificationId, e);
            throw e;
        }
    }
    
    /**
     * Sends an email notification asynchronously
     */
    @Override
    @Async("notificationTaskExecutor")
    public String sendEmailAsync(EmailNotificationDTO emailDTO) {
        String notificationId = generateNotificationId();
        log.info("Queuing email notification for async processing - ID: {}", notificationId);
        
        CompletableFuture.runAsync(() -> {
            try {
                // Validate email
                validateEmail(emailDTO);
                
                // Send email
                emailProvider.sendEmail(emailDTO);
                
                log.info("Async email notification sent successfully - ID: {}", notificationId);
                
            } catch (Exception e) {
                log.error("Failed to send async email notification - ID: {}", notificationId, e);
                // In a production system, this would go to DLQ
            }
        });
        
        return notificationId;
    }
    
    /**
     * Validates email notification
     */
    private void validateEmail(EmailNotificationDTO emailDTO) {
        log.debug("Validating email notification");

        // Sanitize email content
        sanitizeEmail(emailDTO);

        // Validate email fields
        emailValidator.validate(emailDTO);

        // Validate attachments if present
        if (emailDTO.getAttachments() != null && !emailDTO.getAttachments().isEmpty()) {
            attachmentValidator.validate(emailDTO.getAttachments());
        }

        log.debug("Email notification validation completed");
    }

    /**
     * Sanitizes email content to prevent injection attacks
     */
    private void sanitizeEmail(EmailNotificationDTO emailDTO) {
        // Sanitize subject
        if (emailDTO.getSubject() != null) {
            emailDTO.setSubject(emailSanitizer.sanitizeSubject(emailDTO.getSubject()));
        }

        // Sanitize body
        if (emailDTO.getBody() != null) {
            if (Boolean.TRUE.equals(emailDTO.getHtmlContent())) {
                emailDTO.setBody(emailSanitizer.sanitizeHtmlBody(emailDTO.getBody()));
            } else {
                emailDTO.setBody(emailSanitizer.sanitizePlainTextBody(emailDTO.getBody()));
            }
        }

        // Sanitize reply-to
        if (emailDTO.getReplyTo() != null) {
            emailDTO.setReplyTo(emailSanitizer.sanitizeEmailAddress(emailDTO.getReplyTo()));
        }
    }
    
    /**
     * Generates a unique notification ID
     */
    private String generateNotificationId() {
        return UUID.randomUUID().toString();
    }
}

