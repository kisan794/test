package hireright.applications.fulfillment_task_api.model.recombointegration.transformer;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Request DTO for XML transformation.
 * Contains the XML content to be transformed and the type of screening.
 * <p>
 * Supported types:
 * - "education" - Education screening transformation
 * - "employment" - Employment screening transformation
 *
 * @author Keshav Ladha
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransformRequest {

    @JsonProperty("content")
    private String content;

    @JsonProperty("type")
    private String type;

    @Override
    public String toString() {
        return "TransformRequest{" +
                "type='" + type + "', " +
                "content='" + (content != null ? content.substring(0, Math.min(100, content.length())) + "..." : "null") +
                "'}";
    }
}