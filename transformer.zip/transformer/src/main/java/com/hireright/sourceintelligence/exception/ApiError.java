package com.hireright.sourceintelligence.exception;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static com.hireright.sourceintelligence.exception.SetIfNotNull.setIfNotNull;

@Data
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiError {
    private String errorCode;
    private HttpStatus status;
    private OffsetDateTime timestamp;
    private String message;
    private String traceId;
    private List<ApiErrorDetail> errors;
    private List<ApiValidationError> validationErrors;

    private ApiError() {
        timestamp = OffsetDateTime.now();
    }

    public ApiError(@NotNull ErrorCode errorCode) {
        this();
        setIfNotNull(errorCode.getCode(), this::setErrorCode);
        setIfNotNull(errorCode.getDescription(), this::setMessage);
        setIfNotNull(errorCode.getHttpStatus(), this::setStatus);
    }

    public ApiError(HttpStatus status) {
        this();
        this.status = status;
    }

    public ApiError(ErrorCode code, Throwable ex) {
        this(code);
        this.addError(new ApiErrorDetail(ex.getClass().getCanonicalName(), ex.getMessage()));
    }

    public ApiError(HttpStatus status, Throwable ex) {
        this();
        this.status = status;
        this.message = ex.getMessage();
    }

    public ApiError(HttpStatus status, String message) {
        this();
        this.status = status;
        this.message = message;
    }

    public ApiError(ErrorCode code, String message) {
        this(code);
        this.addError(new ApiErrorDetail(null, message));
    }

    public void addErrors(List<String> detailList) {
        if (errors == null) {
            errors = new ArrayList<>();
        }
        if (!CollectionUtils.isEmpty(detailList)) {
            detailList.forEach(error -> this.errors.add(new ApiErrorDetail(null, error)));
        }
    }

    public void addFieldErrors(List<FieldError> fieldErrors) {
        if (validationErrors == null) {
            validationErrors = new ArrayList<>();
        }
        if (!CollectionUtils.isEmpty(fieldErrors)) {
            fieldErrors.forEach(error -> this.validationErrors.add(new ApiValidationError(error)));
        }
    }

    public void addValidationErrors(Set<ConstraintViolation<?>> constraintViolations) {
        if (validationErrors == null) {
            validationErrors = new ArrayList<>();
        }
        if (!CollectionUtils.isEmpty(constraintViolations)) {
            constraintViolations.forEach(error -> this.validationErrors.add(new ApiValidationError(error)));
        }
    }

    public void addGlobalErrors(List<ObjectError> globalErrors) {
        if (CollectionUtils.isEmpty(globalErrors)) {
            return;
        }
        if (errors == null) {
            errors = new ArrayList<>();
        }
        globalErrors.forEach(error -> this.errors.add(new ApiErrorDetail(error.getObjectName(),
                error.getDefaultMessage())));
    }

    public void addError(ApiErrorDetail detail) {
        if (errors == null) {
            errors = new ArrayList<>();
        }
        errors.add(detail);
    }


    @Data
    @AllArgsConstructor
    public static class ApiErrorDetail {
        private final String name;
        private final String message;
    }
}
