package com.hireright.sourceintelligence.api.dto.notification;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.Instant;
import java.util.Map;

/**
 * Response DTO for notification operations.
 * Provides comprehensive information about the notification status.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NotificationResponseDTO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * Status of the notification
     */
    private NotificationStatus status;
    
    /**
     * Human-readable message
     */
    private String message;
    
    /**
     * Unique notification identifier
     */
    private String notificationId;
    
    /**
     * Original request identifier
     */
    private String requestId;
    
    /**
     * Timestamp when notification was sent/queued
     */
    @Builder.Default
    private String timestamp = Instant.now().toString();
    
    /**
     * Timestamp when notification was sent (for successful notifications)
     */
    private String sentAt;
    
    /**
     * Timestamp when notification was queued (for async notifications)
     */
    private String queuedAt;
    
    /**
     * Number of recipients
     */
    private Integer recipientCount;
    
    /**
     * Estimated processing time for async operations (e.g., "5s")
     */
    private String estimatedProcessingTime;
    
    /**
     * Additional metadata about the notification
     */
    private Map<String, String> metadata;
    
    /**
     * Error code (if failed)
     */
    private String errorCode;
    
    /**
     * Error details (if failed)
     */
    private String errorDetails;
    
    /**
     * Field that caused the error (if validation failure)
     */
    private String field;
    
    /**
     * Retry after duration in seconds (if circuit breaker open)
     */
    private Integer retryAfter;
    
    /**
     * Circuit breaker state (if applicable)
     */
    private String circuitState;
    
    /**
     * Failure rate percentage (if circuit breaker open)
     */
    private Double failureRate;
}

