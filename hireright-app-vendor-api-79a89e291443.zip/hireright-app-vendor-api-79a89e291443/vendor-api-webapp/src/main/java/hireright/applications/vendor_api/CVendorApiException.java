/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	msuhhoruki	2017-06-16	Created
 */
package hireright.applications.vendor_api;

import hireright.sdk.util.CException;

@SuppressWarnings("serial")
public class CVendorApiException extends CException
{
	public CVendorApiException(String sClientMessage)
	{
		super(sClientMessage);
	}
	
	public CVendorApiException(Exception e, String sClientMessage)
	{
		super(sClientMessage, e);
	}
	
	public CVendorApiException(Exception e)
	{
		super(e);
	}
}
