package hireright.applications.vendor_api;
/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-09-06	Created
 *	M.Kuznetsov	2025-10-29	HRG-345322. Openjdk21-migration
 */
import java.time.ZoneId;

/**
 * @deprecated Use CInstanceDomain instead
 */
@Deprecated
public enum ENationalInstanceID {
    HR_AUS("HR-AUS", ZoneId.of("Australia/Canberra")),
    HR_GBR("HR-GBR", ZoneId.of("Europe/London")),
    HR_USA("HR-USA", ZoneId.of("US/Pacific"));

    public static final String PROPERTY_NAME = "NATIONAL_INSTANCE_ID";
    public static final String PARAMETER_NAME = "nationalInstanceID";

    private final String m_sValue;
    private final ZoneId m_tz;

    public static ENationalInstanceID of(String id) {
        for (ENationalInstanceID value : values()) {
            if (value.name().equals(id) || value.getValue().equals(id)) {
                return value;
            }
        }

        return null;
    }

    ENationalInstanceID(String sValue, ZoneId tz) {
        this.m_sValue = sValue;
        this.m_tz = tz;
    }

    public String getValue() {
        return this.m_sValue;
    }

    public ZoneId getTimeZone() {
        return this.m_tz;
    }
}
