package hireright.applications.igniting_innovations.exception;

/**
 * @author Keshav Ladha
 * @version 1.0
 */
public class ResourceAlreadyExistsException extends RuntimeException {

    public ResourceAlreadyExistsException(String message) {
        super(message);
    }

}