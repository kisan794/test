package hireright.applications.fulfillment_task_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-13  HRG-332327 initial version
 */

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

@XmlAccessorType (XmlAccessType.NONE)
@XmlRootElement (name = "resources")
public class CResources<T> extends CResource<CResourcesMeta, Collection<T>> implements Iterable<T> {
    protected CResources() {
        super();
    }

    protected CResources(Builder<T> builder) {
        super(builder);
    }

    @Override
    public String toString() {
        return "CResources{} " + super.toString();
    }

    @Override
    public Collection<T> getData() {
        Collection<T> data = super.getData();
        return data != null ? new ArrayList<>(data) : Collections.emptySet();
    }

    @Override
    public Iterator<T> iterator() {
        return getData().iterator();
    }

    public static class Builder<T> extends CResource.Builder<CResourcesMeta, Collection<T>> {
        protected CResourcesMeta.Builder m_metaBuilder;

        public Builder() {
            super();
            this.m_data = new ArrayList<>();
        }

        public Builder(CResource<CResourcesMeta, Collection<T>> copy) {
            super(copy);
        }

        public Builder(CResources<T> copy) {
            super(copy);
        }

        public Builder<T> item(T entry) {
            if (entry != null) {
                this.m_data.add(entry);
            }
            return this;
        }

        public Builder<T> items(Collection<T> entries) {
            this.m_data.clear();
            if (entries != null) {
                this.m_data.addAll(entries);
            }
            return this;
        }

        public Builder<T> offset(Long lOffset) {
            if (this.m_metaBuilder == null) {
                this.m_metaBuilder = new CResourcesMeta.Builder();
            }
            this.m_metaBuilder.offset(lOffset);
            return this;
        }

        public Builder<T> limit(Integer nLimit) {
            if (this.m_metaBuilder == null) {
                this.m_metaBuilder = new CResourcesMeta.Builder();
            }
            this.m_metaBuilder.limit(nLimit);
            return this;
        }

        public Builder<T> total(Long lTotal) {
            if (this.m_metaBuilder == null) {
                this.m_metaBuilder = new CResourcesMeta.Builder();
            }
            this.m_metaBuilder.total(lTotal);
            return this;
        }

        @Override
        public CResources<T> build() {
            super.build();

            if (this.m_metaBuilder != null) {
                this.m_metaBuilder.count(this.m_data.size());
                meta(this.m_metaBuilder.build());
            }

            return new CResources<>(this);
        }
    }
}
