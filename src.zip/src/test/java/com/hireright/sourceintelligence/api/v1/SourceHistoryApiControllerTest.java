package com.hireright.sourceintelligence.api.v1;

import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.ALL_VERSIONS;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.APPROVAL_WORKFLOW;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.SOURCE_ORGANIZATION;
import static com.hireright.sourceintelligence.api.ApiConstants.FORWARD_SLASH;
import static com.hireright.sourceintelligence.api.ApiConstants.VERSION;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.api.dto.history.ChangeLogResponse;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.exception.GlobalApiExceptionHandler;
import com.hireright.sourceintelligence.service.CommonUtilService;
import com.hireright.sourceintelligence.service.SearchService;
import com.hireright.sourceintelligence.service.SourceHistoryService;
import com.hireright.sourceintelligence.util.TestDataProvider;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class SourceHistoryApiControllerTest {

  private MockMvc mockMvc;

  @InjectMocks
  private SourceHistoryApiController sourceOrganizationController;

  @Mock
  private SourceHistoryService sourceHistoryService;

  @Mock
  private SearchService searchOrganizationService;


  @Mock
  private CommonUtilService commonUtilService;


  @BeforeEach
  public void setup() {
    JacksonTester.initFields(this, new ObjectMapper());
    mockMvc =
        MockMvcBuilders.standaloneSetup(sourceOrganizationController)
            .setControllerAdvice(new GlobalApiExceptionHandler())
            .build();
  }

  @Test
  void getSourceOrganizationsForDiffTest() throws Exception {
    String hon = TestDataProvider.getHon();
    Double version = 1.0;
    mockMvc.perform(MockMvcRequestBuilders
        .get(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + APPROVAL_WORKFLOW + SOURCE_ORGANIZATION  + "/"+hon+"/" + VERSION + FORWARD_SLASH + version + "/diff")
        .accept(MediaType.APPLICATION_JSON_VALUE))
        .andDo(print())
        .andExpect(status().isOk());
  }

  @Test
  void getSourceOrganizationHistoryByHonAndVersionTest() throws Exception {
    String hon = TestDataProvider.getHon();
    mockMvc.perform(MockMvcRequestBuilders
        .get(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + APPROVAL_WORKFLOW + SOURCE_ORGANIZATION  + "/"+hon+"/" + VERSION + FORWARD_SLASH + 1.0 )
        .accept(MediaType.APPLICATION_JSON_VALUE))
        .andDo(print())
        .andExpect(status().isOk());
  }
  @Test
  public void testGetSourcesByHonAndApprovalStatus() throws Exception {

    String hon = "hon456";
    Double version = 1.0;
    ApprovalStatus approvalStatus = ApprovalStatus.APPROVED;

    ChangeLogResponse mockResponse = new ChangeLogResponse();

    when(sourceHistoryService.getChangeLogByHon(hon, approvalStatus))
            .thenReturn(mockResponse);

    mockMvc.perform(MockMvcRequestBuilders
                    .get(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + APPROVAL_WORKFLOW
                            + SOURCE_ORGANIZATION + "/" + hon + "/" + ALL_VERSIONS)
                    .param("approvalStatus", approvalStatus.toString())
                    .param("version", version.toString())
                    .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON));
  }



  @Test
  public void testGetSourcesByHonAndApprovalStatus_WithVersionNull() {

    ChangeLogResponse mockChangeLogResponse = new ChangeLogResponse();

    when(sourceHistoryService.getChangeLogByHon(anyString(), any(ApprovalStatus.class)))
            .thenReturn(mockChangeLogResponse);

    ResponseEntity<ChangeLogResponse> responseEntity =
            sourceOrganizationController.getSourcesByHonAndApprovalStatus(
                    "hon123", null, ApprovalStatus.APPROVED);

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(mockChangeLogResponse, responseEntity.getBody());
  }
}
