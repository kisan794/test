package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.v2.dto.RegionThresholdDTO;
import com.hireright.sourceintelligence.service.RegionThresholdService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.openMocks;
import org.springframework.http.ResponseEntity;

class RegionThresholdApiControllerTest {

    @Mock
    private RegionThresholdService regionThresholdService;

    @InjectMocks
    private RegionThresholdApiController controller;

    private RegionThresholdDTO mockDto;

    @BeforeEach
    void setUp() {
        openMocks(this);
        mockDto = new RegionThresholdDTO();
    }

    @Test
    void testGetRegions_ShouldReturnRegionThresholdDTO() {
        when(regionThresholdService.getRegions()).thenReturn(mockDto);

        ResponseEntity<RegionThresholdDTO> response = controller.getRegions();

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(mockDto, response.getBody());
        verify(regionThresholdService, times(1)).getRegions();
    }

    @Test
    void testUpdateRegions_ShouldReturnUpdatedDTO() {
        when(regionThresholdService.updateRegionThreshold(any(RegionThresholdDTO.class))).thenReturn(mockDto);

        ResponseEntity<RegionThresholdDTO> response = controller.updateRegions(mockDto);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(mockDto, response.getBody());
        verify(regionThresholdService, times(1)).updateRegionThreshold(mockDto);
    }
}
