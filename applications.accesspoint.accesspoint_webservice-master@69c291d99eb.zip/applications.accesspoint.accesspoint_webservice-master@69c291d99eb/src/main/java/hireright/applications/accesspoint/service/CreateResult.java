/*
 * @(#)$RCSfile: CreateResult.java,v $ $Revision: 1.2 $ $Date: 2014/07/28 14:56:58 $ $Author: aputintsev $ 
 *
 * $Source: /usr/local/cvsroot/projects_src/applications/accesspoint4/webservice/src/main/java/hireright/applications/accesspoint/service/CreateResult.java,v $
 *
 * History:
 *     $Log: CreateResult.java,v $
 *     Revision 1.2  2014/07/28 14:56:58  aputintsev
 *     forked from production version - projects_src/applications/accesspoint
 *
 *     Revision 1.1.2.1.2.1  2009/08/18 18:05:22  asolntsev
 *     Bugfixing and polishing
 *
 *     Revision 1.1.2.1  2009/08/13 13:24:22  asolntsev
 *     Created by St.Petersburg team
 *
 *     Revision 1.1.1.1  2009/07/31 11:24:26  banton
 *     Task 39986 1.1
 *
 *     Revision 1.3  2009/07/29 09:50:13  banton
 *     Fixed WSDL. Added WSDL for 'light' Service
 *
 *
 */

package hireright.applications.accesspoint.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for createResult complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="createResult">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="key" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="password" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createResult", propOrder = {
		"key",
		"password"
})
public class CreateResult {

		protected String key;
		protected String password;

		public CreateResult()
		{
		}

		public CreateResult(String key, String password)
		{
				this.key = key;
				this.password = password;
		}

		/**
		 * Gets the value of the key property.
		 * 
		 * @return
		 *     possible object is
		 *     {@link String }
		 *     
		 */
		public String getKey() {
				return key;
		}

		/**
		 * Sets the value of the key property.
		 * 
		 * @param value
		 *     allowed object is
		 *     {@link String }
		 *     
		 */
		public void setKey(String value) {
				this.key = value;
		}

		/**
		 * Gets the value of the password property.
		 * 
		 * @return
		 *     possible object is
		 *     {@link String }
		 *     
		 */
		public String getPassword() {
				return password;
		}

		/**
		 * Sets the value of the password property.
		 * 
		 * @param value
		 *     allowed object is
		 *     {@link String }
		 *     
		 */
		public void setPassword(String value) {
				this.password = value;
		}

}
