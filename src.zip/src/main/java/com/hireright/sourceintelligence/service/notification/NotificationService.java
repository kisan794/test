package com.hireright.sourceintelligence.service.notification;

import com.hireright.sourceintelligence.api.dto.notification.NotificationRequestDTO;
import com.hireright.sourceintelligence.api.dto.notification.NotificationResponseDTO;

/**
 * Base interface for notification service
 * Following Interface Segregation Principle (ISP) - clients depend on minimal interface
 * Following Dependency Inversion Principle (DIP) - high-level modules depend on abstraction
 */
public interface NotificationService {
    
    /**
     * Send a notification based on the request
     * 
     * @param request notification request
     * @return notification response with status
     */
    NotificationResponseDTO sendNotification(NotificationRequestDTO request);
    
    /**
     * Check if this service supports the given notification type
     * Following Strategy Pattern
     * 
     * @param request notification request
     * @return true if supported, false otherwise
     */
    boolean supports(NotificationRequestDTO request);
}

