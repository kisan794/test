package hireright.applications.vendor_api.facades;
/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	2017-08-18	Created
 *	M.Kuznetsov	2025-10-29	HRG-345322. Openjdk21-migration
 */

import hireright.components.domain.dialects.vendor_api.BasicResponse;

public class ErrorResponseFacade {
    public static final String PARAM_LOG_TRACE_ID = "LogTraceID";
    public static final String PARAM_ERROR_MESSAGE = "ErrorMessage";

    private final BasicResponse m_basicResponse;
    private final IdValueFacade m_idValues;

    public ErrorResponseFacade(String sLogTraceID, String sErrorMessage) {
        this.m_basicResponse = new BasicResponse();

        this.m_idValues = new IdValueFacade()
                .set(PARAM_LOG_TRACE_ID, sLogTraceID)
                .set(PARAM_ERROR_MESSAGE, sErrorMessage);

        this.m_basicResponse.getIdValues().addAll(this.m_idValues.getAll());
    }

    public ErrorResponseFacade(BasicResponse response) {
        this.m_basicResponse = response;
        this.m_idValues = new IdValueFacade(this.m_basicResponse.getIdValues());
    }

    public boolean isError() {
        return getLogTraceID() != null
                || getErrorMessage() != null;
    }

    public String getLogTraceID() {
        return this.m_idValues.value(PARAM_LOG_TRACE_ID);
    }

    public String getErrorMessage() {
        return this.m_idValues.value(PARAM_ERROR_MESSAGE);
    }

    public BasicResponse getBasicResponse() {

        return this.m_basicResponse;
    }
}
