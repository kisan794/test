package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.AutoMatchDTO;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;

import static com.hireright.sourceintelligence.service.impl.SearchConstants.PayloadFields.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.PayloadFields.CITY_CONSTANT;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.*;

public class AutoMatchQueryBuilder {

    private AutoMatchQueryBuilder() {
        throw new IllegalStateException("AutoMatch Query Builder class");
    }

    public static Aggregation autoMatchUSRegionForOrg(AutoMatchDTO autoMatchDTO){
        SortOperation sort = Aggregation.sort(Sort.Direction.DESC, USED_COUNT);
        LimitOperation limit = Aggregation.limit(1);
        return Aggregation.newAggregation(matchPrimary(autoMatchDTO),addUsedCountPrimary(), sort, limit);
    }

    public static Aggregation autoMatchUSRegionForOrgAlias(AutoMatchDTO autoMatchDTO){
        SortOperation sort = Aggregation.sort(Sort.Direction.DESC, USED_COUNT);
        LimitOperation limit = Aggregation.limit(1);
        return Aggregation.newAggregation(matchWithAlias(autoMatchDTO), addUsedCountPrimary(), sort, limit);
    }

    public static Aggregation autoMatchUSRegion(AutoMatchDTO autoMatchDTO, String collection){
        SortOperation sort = Aggregation.sort(Sort.Direction.DESC, USED_COUNT);
        LimitOperation limit = Aggregation.limit(1);
        return Aggregation.newAggregation(matchPrimary(autoMatchDTO),addUsedCountPrimary(),sort, limit, unionWithSource(autoMatchDTO, collection), sort, limit);
    }

    private static MatchOperation matchPrimary(AutoMatchDTO autoMatchDTO){
        Criteria criteria = new Criteria();
        criteria.and(ORGANIZATION_NAME).is(autoMatchDTO.getSourceName());
        criteria.and(COUNTRY).is(autoMatchDTO.getCountry());
        criteria.and(STATUS).is(SourceOrganizationStatus.ACTIVE.getStatus());
        if(autoMatchDTO.getSourceType().equals(OrganizationType.EDUCATION.getType())){
            if(!StringUtils.isEmpty(autoMatchDTO.getState())){
                criteria.and(STATE).in(autoMatchDTO.getState(),STATE_CONSTANT);
            }
            if(!StringUtils.isEmpty(autoMatchDTO.getCity()) && !autoMatchDTO.getCity().equals(CITY_CONSTANT)){
                criteria.and(CITY).in(autoMatchDTO.getCity(), CITY_CONSTANT);
            }
        }
        criteria.and(APPROVAL_STATUS).is(ApprovalStatus.APPROVED.getStatus());
        return Aggregation.match(criteria);
    }

    private static MatchOperation matchWithAlias(AutoMatchDTO autoMatchDTO){
        Criteria criteria = new Criteria();
        criteria.and(ORGANIZATION_ALIAS_NAME).is(autoMatchDTO.getSourceName());
        criteria.and(COUNTRY).is(autoMatchDTO.getCountry());
        criteria.and(STATUS).is(SourceOrganizationStatus.ACTIVE.getStatus());
        if(autoMatchDTO.getSourceType().equals(OrganizationType.EDUCATION.getType())){
            if(!StringUtils.isEmpty(autoMatchDTO.getState())){
                criteria.and(STATE).in(autoMatchDTO.getState(),STATE_CONSTANT);
            }
            if(!StringUtils.isEmpty(autoMatchDTO.getCity()) && !autoMatchDTO.getCity().equals(CITY_CONSTANT)){
                criteria.and(CITY).in(autoMatchDTO.getCity(), CITY_CONSTANT);
            }
        }
        criteria.and(APPROVAL_STATUS).is(ApprovalStatus.APPROVED.getStatus());
        return Aggregation.match(criteria);
    }

    private static AddFieldsOperation addUsedCountPrimary(){
        return  Aggregation.addFields()
                .addField(USED_COUNT)
                .withValueOf(ConditionalOperators.ifNull(PAYLOAD_USED_COUNT).then(0))
                .build();
    }

    private static UnionWithOperation unionWithSource(AutoMatchDTO autoMatchDTO, String collectionName){
        Criteria criteria = new Criteria();
        criteria.and(ORGANIZATION_ALIAS_NAME).is(autoMatchDTO.getSourceName());
        criteria.and(COUNTRY).is(autoMatchDTO.getCountry());
        if(autoMatchDTO.getSourceType().equals(OrganizationType.EDUCATION.getType())){
            if(!StringUtils.isEmpty(autoMatchDTO.getState())){
                criteria.and(STATE).in(autoMatchDTO.getState(),STATE_CONSTANT);
            }
            if(!StringUtils.isEmpty(autoMatchDTO.getCity()) && !autoMatchDTO.getCity().equals(CITY_CONSTANT)){
                criteria.and(CITY).in(autoMatchDTO.getCity(), CITY_CONSTANT);
            }
        }
        MatchOperation matchSecondary = Aggregation.match(criteria);

        AddFieldsOperation addUsedCountSecondary = Aggregation.addFields()
                .addField(USED_COUNT)
                .withValueOf(ConditionalOperators.ifNull(PAYLOAD_USED_COUNT).then(0))
                .build();

        SortOperation sortSecondary = Aggregation.sort(Sort.Direction.DESC, USED_COUNT);
        LimitOperation limitSecondary = Aggregation.limit(1);

        return UnionWithOperation.unionWith(collectionName)
                .pipeline(matchSecondary, addUsedCountSecondary, sortSecondary, limitSecondary);

    }

}
