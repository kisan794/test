package com.hireright.sourceintelligence.api.dto;

import lombok.Data;

@Data
public class ElasticsearchDTO {

    private String organizationName;
    private String country;
    private String state;
    private String city;
    private String postalCode;
    private String addressLine;
    private String department;
    private String website;
    private String automatedService;
    private String code;
    private String phoneNumber;
    private String faxNumber;
    private String email;
    private String organizationAlias;
    private String status;
    private String approvalStatus;

    public boolean isEmpty(){
        return organizationName == null && organizationAlias == null && department == null && addressLine == null && automatedService ==null && code == null && phoneNumber == null && faxNumber == null && email == null && status == null && approvalStatus == null;
    }

}
