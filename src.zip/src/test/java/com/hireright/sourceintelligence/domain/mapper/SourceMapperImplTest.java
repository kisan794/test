package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.Alias;
import com.hireright.sourceintelligence.api.dto.FieldErrorsDTO;
import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.domain.entity.FieldErrors;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.mongodb.BasicDBObject;
import org.bson.types.ObjectId;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class SourceMapperImplTest {

    private final TestableSourceMapperImpl mapper = new TestableSourceMapperImpl();

    static class TestableSourceMapperImpl extends SourceMapperImpl {
        FieldErrors callFieldErrorsDTOToFieldErrors(FieldErrorsDTO dto) {
            return fieldErrorsDTOToFieldErrors(dto);
        }

        List<FieldErrors> callFieldErrorsDTOListToFieldErrorsList(List<FieldErrorsDTO> list) {
            return fieldErrorsDTOListToFieldErrorsList(list);
        }

        FieldErrorsDTO callFieldErrorsToFieldErrorsDTO(FieldErrors entity) {
            return fieldErrorsToFieldErrorsDTO(entity);
        }

        List<FieldErrorsDTO> callFieldErrorsListToFieldErrorsDTOList(List<FieldErrors> list) {
            return fieldErrorsListToFieldErrorsDTOList(list);
        }
    }

    @Test
    void dtoToEntitySource_shouldReturnNull_whenDtoIsNull() {
        assertThat(mapper.dtoToEntitySource(null)).isNull();
    }

    @Test
    void entitySourceToDTO_shouldReturnNull_whenEntityIsNull() {
        assertThat(mapper.entitySourceToDTO(null)).isNull();
    }

    @Test
    void toSourceDTOList_shouldReturnNull_whenEntityListIsNull() {
        assertThat(mapper.toSourceDTOList(null)).isNull();
    }

    @Test
    void toSourceDTOList_shouldMapList_whenEntityListHasValues() {
        Source source = Source.builder()
                .id(new ObjectId("507f1f77bcf86cd799439011"))
                .hon("HON-1")
                .organizationName("Org One")
                .version(1.0)
                .tempVersion(2.0)
                .build();

        List<SourceOrganizationDTO> result = mapper.toSourceDTOList(List.of(source));

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getHon()).isEqualTo("HON-1");
        assertThat(result.get(0).getOrganizationName()).isEqualTo("Org One");
        assertThat(result.get(0).getId()).isEqualTo("507f1f77bcf86cd799439011");
    }

    @Test
    void dtoToEntitySource_shouldMapAllFields_whenPresent() {
        Instant lastModifiedDate = Instant.parse("2026-04-07T10:15:30Z");

        Alias alias1 = new Alias();
        alias1.setName("AliasOne");
        Alias alias2 = new Alias();
        alias2.setName("AliasTwo");

        FieldErrorsDTO generalError = new FieldErrorsDTO();
        generalError.setLabel("g-label");
        generalError.setValue("g-value");

        FieldErrorsDTO fieldError = new FieldErrorsDTO();
        fieldError.setLabel("f-label");
        fieldError.setValue("f-value");

        JSONObject payload = new JSONObject();
        payload.put("key", "value");

        SourceOrganizationDTO dto = SourceOrganizationDTO.builder()
                .id("507f1f77bcf86cd799439012")
                .payload(payload)
                .hon("HON999")
                .organizationName("Org")
                .status(SourceOrganizationStatus.values()[0])
                .version(1.0)
                .organizationType(OrganizationType.values()[0])
                .city("Dallas")
                .country("USA")
                .state("Texas")
                .organizationAlias(new Alias[]{alias1, alias2})
                .approvalStatus(ApprovalStatus.values()[0])
                .reviewRequired("true")
                .postalCode("75001")
                .location("Remote")
                .outOfBusiness(Boolean.TRUE)
                .comments("comments")
                .generalErrors(List.of(generalError))
                .fieldErrors(List.of(fieldError))
                .flagPriority(Boolean.TRUE)
                .logFlag("false")
                .action("UPDATE")
                .isLockEnabled(Boolean.TRUE)
                .createdBy("creator")
                .creatorId("creator-id")
                .createdDate("2026-04-06T10:15:30Z")
                .lastModifiedBy("modifier")
                .lastModifierId("modifier-id")
                .lastModifiedDate(lastModifiedDate)
                .requestedBy("requester")
                .requesterId("requester-id")
                .approvedBy("approver")
                .approverId("approver-id")
                .assignedTo("assignee")
                .assignedId("assigned-id")
                .lastLockedBy("locker")
                .lastLockedId("locker-id")
                .lastUnLockedBy("unlocker")
                .lastUnLockedId("unlocker-id")
                .lastLockedDate("2026-04-05T10:15:30Z")
                .lastUnLockedDate("2026-04-05T11:15:30Z")
                .lastApprovedDate("2026-04-05T12:15:30Z")
                .tempVersion(2.0)
                .lastActionDate("2026-04-05T13:15:30Z")
                .systemComments("system-comments")
                .build();

        Source result = mapper.dtoToEntitySource(dto);

        assertThat(result).isNotNull();
        assertThat(result.getId().toHexString()).isEqualTo("507f1f77bcf86cd799439012");
        assertThat(result.getPayload()).isNotNull();
        assertThat(result.getHon()).isEqualTo("HON999");
        assertThat(result.getOrganizationName()).isEqualTo("Org");
        assertThat(result.getStatus()).isEqualTo(dto.getStatus());
        assertThat(result.getVersion()).isEqualTo(1.0);
        assertThat(result.getOrganizationType()).isEqualTo(dto.getOrganizationType());
        assertThat(result.getCity()).isEqualTo("Dallas");
        assertThat(result.getCountry()).isEqualTo("USA");
        assertThat(result.getState()).isEqualTo("Texas");
        assertThat(result.getOrganizationAlias()).hasSize(2);
        assertThat(result.getOrganizationAlias()).isNotSameAs(dto.getOrganizationAlias());
        assertThat(result.getApprovalStatus()).isEqualTo(dto.getApprovalStatus());
        assertThat(result.getReviewRequired()).isEqualTo("true");
        assertThat(result.getPostalCode()).isEqualTo("75001");
        assertThat(result.getLocation()).isEqualTo("Remote");
        assertThat(result.getOutOfBusiness()).isTrue();
        assertThat(result.getComments()).isEqualTo("comments");
        assertThat(result.getGeneralErrors()).hasSize(1);
        assertThat(result.getGeneralErrors().get(0).getLabel()).isEqualTo("g-label");
        assertThat(result.getGeneralErrors().get(0).getValue()).isEqualTo("g-value");
        assertThat(result.getFieldErrors()).hasSize(1);
        assertThat(result.getFieldErrors().get(0).getLabel()).isEqualTo("f-label");
        assertThat(result.getFieldErrors().get(0).getValue()).isEqualTo("f-value");
        assertThat(result.getFlagPriority()).isTrue();
        assertThat(result.getLogFlag()).isEqualTo("false");
        assertThat(result.getAction()).isEqualTo("UPDATE");
        assertThat(result.getIsLockEnabled()).isTrue();
        assertThat(result.getCreatedBy()).isEqualTo("creator");
        assertThat(result.getCreatorId()).isEqualTo("creator-id");
        assertThat(result.getCreatedDate()).isEqualTo(Instant.parse("2026-04-06T10:15:30Z"));
        assertThat(result.getLastModifiedBy()).isEqualTo("modifier");
        assertThat(result.getLastModifierId()).isEqualTo("modifier-id");
        assertThat(result.getLastModifiedDate()).isEqualTo(lastModifiedDate);
        assertThat(result.getRequestedBy()).isEqualTo("requester");
        assertThat(result.getRequesterId()).isEqualTo("requester-id");
        assertThat(result.getApprovedBy()).isEqualTo("approver");
        assertThat(result.getApproverId()).isEqualTo("approver-id");
        assertThat(result.getAssignedTo()).isEqualTo("assignee");
        assertThat(result.getAssignedId()).isEqualTo("assigned-id");
        assertThat(result.getLastLockedBy()).isEqualTo("locker");
        assertThat(result.getLastLockedId()).isEqualTo("locker-id");
        assertThat(result.getLastUnLockedBy()).isEqualTo("unlocker");
        assertThat(result.getLastUnLockedId()).isEqualTo("unlocker-id");
        assertThat(result.getLastLockedDate()).isEqualTo(Instant.parse("2026-04-05T10:15:30Z"));
        assertThat(result.getLastUnLockedDate()).isEqualTo(Instant.parse("2026-04-05T11:15:30Z"));
        assertThat(result.getLastApprovedDate()).isEqualTo(Instant.parse("2026-04-05T12:15:30Z"));
        assertThat(result.getTempVersion()).isEqualTo(2.0);
        assertThat(result.getLastActionDate()).isEqualTo(Instant.parse("2026-04-05T13:15:30Z"));
        assertThat(result.getSystemComments()).isEqualTo("system-comments");
    }

    @Test
    void dtoToEntitySource_shouldSkipOptionalFields_whenMostlyNull() {
        SourceOrganizationDTO dto = SourceOrganizationDTO.builder()
                .version(0.0)
                .tempVersion(0.0)
                .build();

        Source result = mapper.dtoToEntitySource(dto);

        assertThat(result).isNotNull();
        assertThat(result.getVersion()).isEqualTo(0.0);
        assertThat(result.getTempVersion()).isEqualTo(0.0);

        assertThat(result.getId()).isNull();
        assertThat(result.getPayload()).isNull();
        assertThat(result.getHon()).isNull();
        assertThat(result.getOrganizationName()).isNull();
        assertThat(result.getStatus()).isNull();
        assertThat(result.getOrganizationType()).isNull();
        assertThat(result.getCity()).isNull();
        assertThat(result.getCountry()).isNull();
        assertThat(result.getState()).isNull();
        assertThat(result.getOrganizationAlias()).isNull();
        assertThat(result.getApprovalStatus()).isNull();
        assertThat(result.getReviewRequired()).isNull();
        assertThat(result.getPostalCode()).isNull();
        assertThat(result.getLocation()).isNull();
        assertThat(result.getOutOfBusiness()).isNull();
        assertThat(result.getComments()).isNull();
        assertThat(result.getGeneralErrors()).isNull();
        assertThat(result.getFieldErrors()).isNull();
        assertThat(result.getFlagPriority()).isNull();
        assertThat(result.getLogFlag()).isNull();
        assertThat(result.getAction()).isNull();
        assertThat(result.getIsLockEnabled()).isFalse();
        assertThat(result.getCreatedBy()).isNull();
        assertThat(result.getCreatorId()).isNull();
        assertThat(result.getCreatedDate()).isNull();
        assertThat(result.getLastModifiedBy()).isNull();
        assertThat(result.getLastModifierId()).isNull();
        assertThat(result.getLastModifiedDate()).isNull();
        assertThat(result.getRequestedBy()).isNull();
        assertThat(result.getRequesterId()).isNull();
        assertThat(result.getApprovedBy()).isNull();
        assertThat(result.getApproverId()).isNull();
        assertThat(result.getAssignedId()).isNull();
        assertThat(result.getLastLockedBy()).isNull();
        assertThat(result.getLastLockedId()).isNull();
        assertThat(result.getLastUnLockedBy()).isNull();
        assertThat(result.getLastUnLockedId()).isNull();
        assertThat(result.getLastLockedDate()).isNull();
        assertThat(result.getLastUnLockedDate()).isNull();
        assertThat(result.getLastApprovedDate()).isNull();
        assertThat(result.getLastActionDate()).isNull();
        assertThat(result.getSystemComments()).isNull();
    }

    @Test
    void entitySourceToDTO_shouldMapAllFields_whenPresent() {
        Instant createdDate = Instant.parse("2026-04-06T10:15:30Z");
        Instant lastModifiedDate = Instant.parse("2026-04-07T10:15:30Z");
        Instant lastLockedDate = Instant.parse("2026-04-05T10:15:30Z");
        Instant lastUnlockedDate = Instant.parse("2026-04-05T11:15:30Z");
        Instant lastApprovedDate = Instant.parse("2026-04-05T12:15:30Z");
        Instant lastActionDate = Instant.parse("2026-04-05T13:15:30Z");

        Alias alias = new Alias();
        alias.setName("AliasOne");

        FieldErrors generalError = new FieldErrors();
        generalError.setLabel("g-label");
        generalError.setValue("g-value");

        FieldErrors fieldError = new FieldErrors();
        fieldError.setLabel("f-label");
        fieldError.setValue("f-value");

        Source entity = Source.builder()
                .id(new ObjectId("507f1f77bcf86cd799439099"))
                .payload(BasicDBObject.parse("{\"key\":\"value\"}"))
                .hon("HON123")
                .status(SourceOrganizationStatus.values()[0])
                .version(1.5)
                .organizationType(OrganizationType.values()[0])
                .organizationName("Entity Org")
                .city("Austin")
                .country("USA")
                .state("Texas")
                .organizationAlias(new Alias[]{alias})
                .approvalStatus(ApprovalStatus.values()[0])
                .assignedTo("user1")
                .assignedId("id1")
                .logFlag("true")
                .flagPriority(Boolean.FALSE)
                .requestedBy("requester")
                .requesterId("req-id")
                .approvedBy("approver")
                .approverId("app-id")
                .lastModifiedDate(lastModifiedDate)
                .reviewRequired("required")
                .postalCode("73301")
                .createdDate(createdDate)
                .createdBy("creator")
                .creatorId("creator-id")
                .lastModifierId("modifier-id")
                .lastModifiedBy("modifier")
                .outOfBusiness(Boolean.TRUE)
                .location("HQ")
                .comments("comments")
                .generalErrors(List.of(generalError))
                .fieldErrors(List.of(fieldError))
                .action("CREATE")
                .isLockEnabled(Boolean.TRUE)
                .lastLockedBy("locker")
                .lastLockedId("locker-id")
                .lastUnLockedBy("unlocker")
                .lastUnLockedId("unlocker-id")
                .lastLockedDate(lastLockedDate)
                .lastUnLockedDate(lastUnlockedDate)
                .lastApprovedDate(lastApprovedDate)
                .lastActionDate(lastActionDate)
                .tempVersion(2.5)
                .systemComments("sys-comments")
                .build();

        SourceOrganizationDTO result = mapper.entitySourceToDTO(entity);

        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo("507f1f77bcf86cd799439099");
        assertThat(result.getPayload()).isNotNull();
        assertThat(result.getHon()).isEqualTo("HON123");
        assertThat(result.getStatus()).isEqualTo(entity.getStatus());
        assertThat(result.getVersion()).isEqualTo(1.5);
        assertThat(result.getOrganizationType()).isEqualTo(entity.getOrganizationType());
        assertThat(result.getOrganizationName()).isEqualTo("Entity Org");
        assertThat(result.getCity()).isEqualTo("Austin");
        assertThat(result.getCountry()).isEqualTo("USA");
        assertThat(result.getState()).isEqualTo("Texas");
        assertThat(result.getOrganizationAlias()).hasSize(1);
        assertThat(result.getOrganizationAlias()).isNotSameAs(entity.getOrganizationAlias());
        assertThat(result.getApprovalStatus()).isEqualTo(entity.getApprovalStatus());
        assertThat(result.getAssignedTo()).isEqualTo("user1");
        assertThat(result.getAssignedId()).isEqualTo("id1");
        assertThat(result.getLogFlag()).isEqualTo("true");
        assertThat(result.getFlagPriority()).isFalse();
        assertThat(result.getRequestedBy()).isEqualTo("requester");
        assertThat(result.getRequesterId()).isEqualTo("req-id");
        assertThat(result.getApprovedBy()).isEqualTo("approver");
        assertThat(result.getApproverId()).isEqualTo("app-id");
        assertThat(result.getLastModifiedDate()).isEqualTo(lastModifiedDate);
        assertThat(result.getReviewRequired()).isEqualTo("required");
        assertThat(result.getPostalCode()).isEqualTo("73301");
        assertThat(result.getCreatedDate()).isEqualTo(createdDate.toString());
        assertThat(result.getCreatedBy()).isEqualTo("creator");
        assertThat(result.getCreatorId()).isEqualTo("creator-id");
        assertThat(result.getLastModifierId()).isEqualTo("modifier-id");
        assertThat(result.getLastModifiedBy()).isEqualTo("modifier");
        assertThat(result.getOutOfBusiness()).isTrue();
        assertThat(result.getLocation()).isEqualTo("HQ");
        assertThat(result.getComments()).isEqualTo("comments");
        assertThat(result.getGeneralErrors()).hasSize(1);
        assertThat(result.getGeneralErrors().get(0).getLabel()).isEqualTo("g-label");
        assertThat(result.getGeneralErrors().get(0).getValue()).isEqualTo("g-value");
        assertThat(result.getFieldErrors()).hasSize(1);
        assertThat(result.getFieldErrors().get(0).getLabel()).isEqualTo("f-label");
        assertThat(result.getFieldErrors().get(0).getValue()).isEqualTo("f-value");
        assertThat(result.getAction()).isEqualTo("CREATE");
        assertThat(result.getIsLockEnabled()).isTrue();
        assertThat(result.getLastLockedBy()).isEqualTo("locker");
        assertThat(result.getLastLockedId()).isEqualTo("locker-id");
        assertThat(result.getLastUnLockedBy()).isEqualTo("unlocker");
        assertThat(result.getLastUnLockedId()).isEqualTo("unlocker-id");
        assertThat(result.getLastLockedDate()).isEqualTo(lastLockedDate.toString());
        assertThat(result.getLastUnLockedDate()).isEqualTo(lastUnlockedDate.toString());
        assertThat(result.getLastApprovedDate()).isEqualTo(lastApprovedDate.toString());
        assertThat(result.getLastActionDate()).isEqualTo(lastActionDate.toString());
        assertThat(result.getTempVersion()).isEqualTo(2.5);
        assertThat(result.getSystemComments()).isEqualTo("sys-comments");
    }

    @Test
    void entitySourceToDTO_shouldSkipOptionalFields_whenMostlyNull() {
        Source entity = Source.builder()
                .id(new ObjectId("507f1f77bcf86cd799439013"))
                .version(0.0)
                .tempVersion(0.0)
                .build();

        SourceOrganizationDTO result = mapper.entitySourceToDTO(entity);

        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo("507f1f77bcf86cd799439013");
        assertThat(result.getVersion()).isEqualTo(0.0);
        assertThat(result.getTempVersion()).isEqualTo(0.0);

        assertThat(result.getPayload()).isNull();
        assertThat(result.getHon()).isNull();
        assertThat(result.getStatus()).isNull();
        assertThat(result.getOrganizationType()).isNull();
        assertThat(result.getOrganizationName()).isNull();
        assertThat(result.getCity()).isNull();
        assertThat(result.getCountry()).isNull();
        assertThat(result.getState()).isNull();
        assertThat(result.getOrganizationAlias()).isNull();
        assertThat(result.getApprovalStatus()).isNull();
        assertThat(result.getAssignedId()).isNull();
        assertThat(result.getLogFlag()).isNull();
        assertThat(result.getFlagPriority()).isNull();
        assertThat(result.getRequestedBy()).isNull();
        assertThat(result.getRequesterId()).isNull();
        assertThat(result.getApprovedBy()).isNull();
        assertThat(result.getApproverId()).isNull();
        assertThat(result.getLastModifiedDate()).isNull();
        assertThat(result.getReviewRequired()).isNull();
        assertThat(result.getPostalCode()).isNull();
        assertThat(result.getCreatedDate()).isNull();
        assertThat(result.getCreatedBy()).isNull();
        assertThat(result.getCreatorId()).isNull();
        assertThat(result.getLastModifierId()).isNull();
        assertThat(result.getLastModifiedBy()).isNull();
        assertThat(result.getOutOfBusiness()).isNull();
        assertThat(result.getLocation()).isNull();
        assertThat(result.getComments()).isNull();
        assertThat(result.getGeneralErrors()).isNull();
        assertThat(result.getFieldErrors()).isNull();
        assertThat(result.getAction()).isNull();
        assertThat(result.getIsLockEnabled()).isFalse();
        assertThat(result.getLastLockedBy()).isNull();
        assertThat(result.getLastLockedId()).isNull();
        assertThat(result.getLastUnLockedBy()).isNull();
        assertThat(result.getLastUnLockedId()).isNull();
        assertThat(result.getLastLockedDate()).isNull();
        assertThat(result.getLastUnLockedDate()).isNull();
        assertThat(result.getLastApprovedDate()).isNull();
        assertThat(result.getLastActionDate()).isNull();
        assertThat(result.getSystemComments()).isNull();

        // if Source has a builder default for assignedTo, assert that actual default here
        assertThat(result.getAssignedTo()).isIn((String) null, "UNASSIGNED");
    }

    @Test
    void fieldErrorsDTOToFieldErrors_shouldHandleNullAndValues() {
        assertThat(mapper.callFieldErrorsDTOToFieldErrors(null)).isNull();

        FieldErrorsDTO dto = new FieldErrorsDTO();
        dto.setLabel("label");
        dto.setValue("value");

        FieldErrors result = mapper.callFieldErrorsDTOToFieldErrors(dto);

        assertThat(result).isNotNull();
        assertThat(result.getLabel()).isEqualTo("label");
        assertThat(result.getValue()).isEqualTo("value");
    }

    @Test
    void fieldErrorsDTOToFieldErrors_shouldSkipNullFields() {
        FieldErrorsDTO dto = new FieldErrorsDTO();

        FieldErrors result = mapper.callFieldErrorsDTOToFieldErrors(dto);

        assertThat(result).isNotNull();
        assertThat(result.getLabel()).isNull();
        assertThat(result.getValue()).isNull();
    }

    @Test
    void fieldErrorsToFieldErrorsDTO_shouldHandleNullAndValues() {
        assertThat(mapper.callFieldErrorsToFieldErrorsDTO(null)).isNull();

        FieldErrors entity = new FieldErrors();
        entity.setLabel("label");
        entity.setValue("value");

        FieldErrorsDTO result = mapper.callFieldErrorsToFieldErrorsDTO(entity);

        assertThat(result).isNotNull();
        assertThat(result.getLabel()).isEqualTo("label");
        assertThat(result.getValue()).isEqualTo("value");
    }

    @Test
    void fieldErrorsToFieldErrorsDTO_shouldSkipNullFields() {
        FieldErrors entity = new FieldErrors();

        FieldErrorsDTO result = mapper.callFieldErrorsToFieldErrorsDTO(entity);

        assertThat(result).isNotNull();
        assertThat(result.getLabel()).isNull();
        assertThat(result.getValue()).isNull();
    }

    @Test
    void fieldErrorsDTOListToFieldErrorsList_shouldHandleNullEmptyAndValues() {
        assertThat(mapper.callFieldErrorsDTOListToFieldErrorsList(null)).isNull();

        assertThat(mapper.callFieldErrorsDTOListToFieldErrorsList(List.of())).isEmpty();

        FieldErrorsDTO dto = new FieldErrorsDTO();
        dto.setLabel("label");
        dto.setValue("value");

        List<FieldErrors> result = mapper.callFieldErrorsDTOListToFieldErrorsList(List.of(dto));

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getLabel()).isEqualTo("label");
        assertThat(result.get(0).getValue()).isEqualTo("value");
    }

    @Test
    void fieldErrorsListToFieldErrorsDTOList_shouldHandleNullEmptyAndValues() {
        assertThat(mapper.callFieldErrorsListToFieldErrorsDTOList(null)).isNull();

        assertThat(mapper.callFieldErrorsListToFieldErrorsDTOList(List.of())).isEmpty();

        FieldErrors entity = new FieldErrors();
        entity.setLabel("label");
        entity.setValue("value");

        List<FieldErrorsDTO> result = mapper.callFieldErrorsListToFieldErrorsDTOList(List.of(entity));

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getLabel()).isEqualTo("label");
        assertThat(result.get(0).getValue()).isEqualTo("value");
    }
}