package com.hireright.sourceintelligence.api.v2;

import com.hireright.sourceintelligence.api.v2.dto.SourceDTO;
import com.hireright.sourceintelligence.exception.ApiError;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import static com.hireright.sourceintelligence.api.ApiConstants.*;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.*;

@RequestMapping(value = BASE_SI_SERVICE_V2_API_PATH)
@Tag(name = "Source", description = "Endpoints for managing Source")
public interface SourceApi {

    @Operation(summary = "Create a new source (The source can be Education/Employment)", tags = {"Source"},
            responses = {
                    @ApiResponse(description = "Created", responseCode = "201",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = SourceDTO.class))),
                    @ApiResponse(description = "Source Not found", responseCode = "404",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Internal error", responseCode = "500",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))})
    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping(value = SOURCES, consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<SourceDTO> createSourceOrganization(
            @Valid @RequestBody SourceDTO sourceDTO, HttpServletRequest httpServletRequest);

    @Operation(summary = "Update the existing source", tags = {"Source"},
            responses = {
                    @ApiResponse(description = "OK", responseCode = "200",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = SourceDTO.class))),
                    @ApiResponse(description = "Invalid JSON Payload", responseCode = "401",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Source Not found", responseCode = "404",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Internal error", responseCode = "500",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))})
    @ResponseStatus(HttpStatus.OK)
    @PutMapping(value = SOURCES + HON_PATH_VAR,
            consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<SourceDTO> updateSourceOrganization(
            @PathVariable(value = HON) @NotBlank final String hon,
            @Valid @RequestBody SourceDTO sourceOrg, HttpServletRequest httpServletRequest);

    @Operation(summary = "Toggle the record state from ACTIVE to INACTIVE (soft delete ) or change from INACTIVE to ACTIVE state (live record)",
            tags = {"Source"},
            responses = {
                    @ApiResponse(description = "Source Soft Deleted.", responseCode = "204"),
                    @ApiResponse(description = "Source Not found", responseCode = "404",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(description = "Internal error", responseCode = "500",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))})
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @PatchMapping(value = SOURCES + HON_PATH_VAR)
    ResponseEntity<Void> updateSourceOrganizationStatus(
            @PathVariable(value = HON) @NotNull final String hon, @RequestBody SourceDTO sourceDTO,
            HttpServletRequest httpServletRequest);

}
