/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.controller;

import hireright.applications.fulfillment_task_api.model.recombointegration.education.response.EducationResultRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.education.response.EducationResultResponse;
import hireright.applications.fulfillment_task_api.model.recombointegration.employment.response.EmploymentResultRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.employment.response.EmploymentResultResponse;
import hireright.applications.fulfillment_task_api.rest.controller.ResultApi;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ResultService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ScreeningType;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.factory.ResultServiceFactory;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * Results Controller for receiving fulfillment task results.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@RestController
@EnableRetry
@Validated
@Slf4j
public class ResultApiController implements ResultApi {

    private final ResultServiceFactory factory;

    public ResultApiController(ResultServiceFactory factory) {
        this.factory = factory;
    }

    @Override
    public ResponseEntity<EducationResultResponse> submitEducationResult(
            @PathVariable("request_id") @NonNull final String requestId,
            @Valid @RequestBody EducationResultRequest resultRequest) {
        ResultService resultService = factory.getService(ScreeningType.EDUCATION.getValue());
        resultService.processEducationSubmission(requestId, resultRequest);
        return ResponseEntity.accepted().body(EducationResultResponse.accepted(requestId));
    }

    @Override
    public ResponseEntity<EmploymentResultResponse> submitEmploymentResult(
            @PathVariable("request_id") @NonNull final String requestId,
            @Valid @RequestBody EmploymentResultRequest resultRequest) {
        ResultService resultService = factory.getService(ScreeningType.EMPLOYMENT.getValue());
        resultService.processEmploymentSubmission(requestId, resultRequest);
        return ResponseEntity.accepted().body(EmploymentResultResponse.accepted(requestId));
    }
}