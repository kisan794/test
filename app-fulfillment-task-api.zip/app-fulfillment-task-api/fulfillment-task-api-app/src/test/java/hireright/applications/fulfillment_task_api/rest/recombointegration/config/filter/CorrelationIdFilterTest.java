/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.config.filter;

import hireright.applications.fulfillment_task_api.rest.recombointegration.util.CorrelationIdHolder;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * Unit tests for CorrelationIdFilter
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("CorrelationIdFilter Tests")
class CorrelationIdFilterTest
{

	@Mock
	private FilterChain filterChain;

	@Mock
	private FilterConfig filterConfig;

	private CorrelationIdFilter filter;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;

	@BeforeEach
	void setUp()
	{
		filter = new CorrelationIdFilter();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();
	}

	@AfterEach
	void tearDown()
	{
		// Clean up MDC after each test
		CorrelationIdHolder.clear();
	}

	@Test
	@DisplayName("Should generate new correlation ID when not present in request")
	void testGenerateNewCorrelationId() throws ServletException, IOException
	{
		// Given - no correlation ID in request

		// When
		filter.doFilter(request, response, filterChain);

		// Then
		verify(filterChain, times(1)).doFilter(request, response);

		String correlationId = response.getHeader(CorrelationIdHolder.CORRELATION_ID_HEADER);
		assertNotNull(correlationId);
		assertFalse(correlationId.isEmpty());

		// Verify it's a valid UUID format
		assertTrue(
			correlationId.matches("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"));
	}

	@Test
	@DisplayName("Should use existing correlation ID from request header")
	void testUseExistingCorrelationId() throws ServletException, IOException
	{
		// Given
		String existingCorrelationId = "test-correlation-id-123";
		request.addHeader(CorrelationIdHolder.CORRELATION_ID_HEADER, existingCorrelationId);

		// When
		filter.doFilter(request, response, filterChain);

		// Then
		verify(filterChain, times(1)).doFilter(request, response);

		String responseCorrelationId =
			response.getHeader(CorrelationIdHolder.CORRELATION_ID_HEADER);
		assertEquals(existingCorrelationId, responseCorrelationId);
	}

	@Test
	@DisplayName("Should add correlation ID to response header")
	void testAddCorrelationIdToResponse() throws ServletException, IOException
	{
		// Given
		String correlationId = "my-correlation-id";
		request.addHeader(CorrelationIdHolder.CORRELATION_ID_HEADER, correlationId);

		// When
		filter.doFilter(request, response, filterChain);

		// Then
		String responseHeader = response.getHeader(CorrelationIdHolder.CORRELATION_ID_HEADER);
		assertEquals(correlationId, responseHeader);
	}

	@Test
	@DisplayName("Should clear MDC after request processing")
	void testClearMdcAfterProcessing() throws ServletException, IOException
	{
		// Given
		request.addHeader(CorrelationIdHolder.CORRELATION_ID_HEADER, "test-id");

		// When
		filter.doFilter(request, response, filterChain);

		// Then
		// MDC should be cleared after filter execution
		assertNull(CorrelationIdHolder.get());
	}

	@Test
	@DisplayName("Should clear MDC even when exception occurs")
	void testClearMdcOnException() throws ServletException, IOException
	{
		// Given
		request.addHeader(CorrelationIdHolder.CORRELATION_ID_HEADER, "test-id");
		doThrow(new ServletException("Test exception")).when(filterChain)
			.doFilter(request, response);

		// When & Then
		assertThrows(ServletException.class, () -> filter.doFilter(request, response, filterChain));

		// MDC should still be cleared
		assertNull(CorrelationIdHolder.get());
	}

	@Test
	@DisplayName("Should handle empty correlation ID header")
	void testEmptyCorrelationIdHeader() throws ServletException, IOException
	{
		// Given
		request.addHeader(CorrelationIdHolder.CORRELATION_ID_HEADER, "");

		// When
		filter.doFilter(request, response, filterChain);

		// Then
		String responseCorrelationId =
			response.getHeader(CorrelationIdHolder.CORRELATION_ID_HEADER);
		assertNotNull(responseCorrelationId);
		assertFalse(responseCorrelationId.isEmpty());

		// Should generate new ID when header is empty
		assertTrue(responseCorrelationId.matches(
			"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"));
	}

	@Test
	@DisplayName("Should handle null correlation ID header")
	void testNullCorrelationIdHeader() throws ServletException, IOException
	{
		// Given - no header added (null)

		// When
		filter.doFilter(request, response, filterChain);

		// Then
		String responseCorrelationId =
			response.getHeader(CorrelationIdHolder.CORRELATION_ID_HEADER);
		assertNotNull(responseCorrelationId);
		assertFalse(responseCorrelationId.isEmpty());
	}

	@Test
	@DisplayName("Should call filter chain exactly once")
	void testFilterChainCalledOnce() throws ServletException, IOException
	{
		// Given
		request.addHeader(CorrelationIdHolder.CORRELATION_ID_HEADER, "test-id");

		// When
		filter.doFilter(request, response, filterChain);

		// Then
		verify(filterChain, times(1)).doFilter(request, response);
	}

	@Test
	@DisplayName("Should initialize filter successfully")
	void testFilterInitialization()
	{
		// When & Then
		assertDoesNotThrow(() -> filter.init(filterConfig));
	}

	@Test
	@DisplayName("Should destroy filter successfully")
	void testFilterDestroy()
	{
		// When & Then
		assertDoesNotThrow(() -> filter.destroy());
	}

	@Test
	@DisplayName("Should handle multiple requests with different correlation IDs")
	void testMultipleRequestsWithDifferentIds() throws ServletException, IOException
	{
		// First request
		request.addHeader(CorrelationIdHolder.CORRELATION_ID_HEADER, "correlation-id-1");
		filter.doFilter(request, response, filterChain);
		assertEquals("correlation-id-1",
			response.getHeader(CorrelationIdHolder.CORRELATION_ID_HEADER));

		// Second request with new objects
		MockHttpServletRequest request2 = new MockHttpServletRequest();
		MockHttpServletResponse response2 = new MockHttpServletResponse();
		request2.addHeader(CorrelationIdHolder.CORRELATION_ID_HEADER, "correlation-id-2");
		filter.doFilter(request2, response2, filterChain);
		assertEquals("correlation-id-2",
			response2.getHeader(CorrelationIdHolder.CORRELATION_ID_HEADER));

		// Verify filter chain called twice
		verify(filterChain, times(2)).doFilter(any(), any());
	}

	@Test
	@DisplayName("Should preserve correlation ID format from request")
	void testPreserveCorrelationIdFormat() throws ServletException, IOException
	{
		// Given - non-UUID format correlation ID
		String customCorrelationId = "custom-format-12345-abcde";
		request.addHeader(CorrelationIdHolder.CORRELATION_ID_HEADER, customCorrelationId);

		// When
		filter.doFilter(request, response, filterChain);

		// Then
		assertEquals(customCorrelationId,
			response.getHeader(CorrelationIdHolder.CORRELATION_ID_HEADER));
	}

	@Test
	@DisplayName("Should handle very long correlation ID")
	void testVeryLongCorrelationId() throws ServletException, IOException
	{
		// Given
		String longCorrelationId = "a".repeat(500);
		request.addHeader(CorrelationIdHolder.CORRELATION_ID_HEADER, longCorrelationId);

		// When
		filter.doFilter(request, response, filterChain);

		// Then
		assertEquals(longCorrelationId,
			response.getHeader(CorrelationIdHolder.CORRELATION_ID_HEADER));
	}

	@Test
	@DisplayName("Should handle special characters in correlation ID")
	void testSpecialCharactersInCorrelationId() throws ServletException, IOException
	{
		// Given
		String specialCorrelationId = "test-id_123.456:789";
		request.addHeader(CorrelationIdHolder.CORRELATION_ID_HEADER, specialCorrelationId);

		// When
		filter.doFilter(request, response, filterChain);

		// Then
		assertEquals(specialCorrelationId,
			response.getHeader(CorrelationIdHolder.CORRELATION_ID_HEADER));
	}

	@Test
	@DisplayName("Should generate different correlation IDs for different requests")
	void testGenerateDifferentIdsForDifferentRequests() throws ServletException, IOException
	{
		// First request without correlation ID
		filter.doFilter(request, response, filterChain);
		String firstId = response.getHeader(CorrelationIdHolder.CORRELATION_ID_HEADER);

		// Second request without correlation ID
		MockHttpServletRequest request2 = new MockHttpServletRequest();
		MockHttpServletResponse response2 = new MockHttpServletResponse();
		filter.doFilter(request2, response2, filterChain);
		String secondId = response2.getHeader(CorrelationIdHolder.CORRELATION_ID_HEADER);

		// IDs should be different
		assertNotEquals(firstId, secondId);
	}
}
